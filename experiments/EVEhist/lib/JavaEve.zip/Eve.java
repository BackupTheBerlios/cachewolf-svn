import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import eve.applet.EveApplet;

/*
 * Created on Feb 8, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Eve{


	public static void main(String[] args) throws Exception
	{
		if (args.length >= 3 && args[0].equals("-hybrid-"))try{
			System.out.println("Must build: "+args[1]+", "+args[2]);
			File src = new File(args[1]+".tmp");
			File dest = new File(args[1]);
			File exe = new File(args[2]);
			ZipFile zf = new ZipFile(src);
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(dest));
			int max = 100000;
			byte[] buff = new byte[max];
			for (Enumeration e = zf.entries(); e.hasMoreElements();){
				ZipEntry nz = (ZipEntry)e.nextElement();
				String nm = nz.getName();
				if (nm.startsWith("_J_/"))
					nm = nm.substring(4);
				else if (zf.getEntry("_J_/"+nm) != null)
					continue;
				else if (nm.startsWith("java/"))
					continue;
				InputStream in = zf.getInputStream(nz);
				ZipEntry ze = new ZipEntry(nm);
				out.putNextEntry(ze);
				while(true){
					int got = in.read(buff,0,max);
					if (got == -1) break;
					out.write(buff,0,got);
				}
				in.close();
				out.closeEntry();
			}
			out.close();
			dest.setLastModified(exe.lastModified());
			System.exit(0);
		}catch(Exception e){
			PrintWriter pw = new PrintWriter(new FileOutputStream("F:\\Exception.txt"));
			e.printStackTrace(pw);
			pw.close();
			System.exit(-1);
		}
		EveApplet.main(args);
	}
}

//####################################################
