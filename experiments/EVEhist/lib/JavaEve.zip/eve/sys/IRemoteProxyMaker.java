package eve.sys;

import java.io.IOException;

public interface IRemoteProxyMaker {

	public final int OPTION_IS_MULTITHREADED = 0x1;
	public final int OPTION_CLOSE_ON_TIMEOUT = 0x2;
	
	/**
	 * Set the timeout for receiving responses from remote calls.
	 * @param timeoutInMillis the maximum time in milliseconds
	 * to wait for a response from the remote object.
	 */
	public void setTimeOut(long timeoutInMillis);
	/**
	 * Get the timeout for receiving responses from remote calls in
	 * milliseconds.
	 */
	public long getTimeOut();
	/**
	 * Create and return an Object that implements the interface supported by this
	 * IRemoteProxyMaker.
	 */
	public Object createProxy();
	/**
	 * Get a Handle that can be used to monitor the connection. If the Stopped
	 * bit is set in the handle, this indicates the connection has closed.
	 * @return a Handle that can be used to monitor the connection.
	 */
	public Handle getRunningHandle();
	/**
	 * Close the connection, after which calls to any proxies created will fail.
	 */	
	public void close();
	/**
	 * Return if the connection is open.
	 */
	public boolean isOpen();
	/**
	 * Setup the connection for the client. 
	 * After calling this, use createProxy() to create an Object that implements
	 * the interface supported by this IRemoteProxyMaker.
	 * @param inputChannel - this can be an InputStream, a BlockInputStream or a Socket.
	 * @param outputChannel - this can be an OutputStream, a BlockOutputStream or a Socket.
	 * @throws IOException on any IO error.
	 */
	public void setConnection(Object inputChannel,Object outputChannel) throws IOException;
	/**
	 * Used on the server side to make a connection over the input/output channels such that the
	 * specified serverObject acts as a server Object for incoming remote
	 * method calls on the inputChannel. The connection will be multithreaded
	 * only if this IRemoteProxyMaker is multithreaded.<p>
	 * @param serverObject the object that implements the interface.
	 * @param inputChannel this can be an InputStream, a BlockInputStream or
	 * a Socket.
	 * @param outputChannel this can be an OutputStream, a BlockOutputStream or
	 * a Socket.
	 * @return a Handle that indicates if the connection is still active. You
	 * can call stop(int reason) on the Handle to stop and close the connection.
	 * @throws IOException on any IO error.
	 */
	public Handle makeServerObject(Object serverObject,Object inputChannel,Object outputChannel) throws IOException;
	
	/**
	 * Create a local MemoryStream connection across which remote calls will
	 * be made. Then setup a RemoteProxyServer which will have the serverObject
	 * added as the default target object. Then create and return a proxy that
	 * implements this RemoteProxy's interfaces and which will invoke the
	 * methods on the serverObject across the MemoryStream connection. 
	 * @param serverObject the serverObject that will have calls invoked on it
	 * over the connection link.
	 * @return a proxy Object which implements the interfaces.
	 * @throws IOException on any IO error, which should be none since a 
	 * MemoryStream is used.
	 */
	public Object createTestConnection(Object serverObject) throws IOException;
	
}
