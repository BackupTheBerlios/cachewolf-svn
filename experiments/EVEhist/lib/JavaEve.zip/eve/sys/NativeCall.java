/*
 * Created on Nov 20, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * This class is meant to be used when implementing native methods
 * that may block and therefore require a separate Thread to operate
 * in. That is normally accomplished via a ttask object (see Eve Native Interface
 * documentation).
 * <p>
 * You should use this class as an interface object, both holding the native task
 * and using this Object as a monitor to wait on the result from the task.
 *
 * @author Michael L Brereton
 *
 */
//####################################################
public class NativeCall {
//
// This will be used to store the native pointer to the native ttask object.
//
protected int nativeTask;
/**
 * This will unref() the native Task.
 */
protected native void finalize(); 
}
//####################################################
