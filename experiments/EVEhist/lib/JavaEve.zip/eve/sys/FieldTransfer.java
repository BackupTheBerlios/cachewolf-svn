package eve.sys;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Hashtable;

import eve.data.Transferrable;
import eve.data.Value;
import eve.util.mString;

//##################################################################
public class FieldTransfer{
//##################################################################
/**
* This is the Control used for the field in an Editor.
**/
public Object dataInterface;
/**
* The set() method used on the data interface - this is not used on the data object.
**/
public Method setMethod;
/**
* The get() method used on the data interface - this is not used on the data object.
**/
public Method getMethod;
/**
* The combined getSet() method used on the data interface.
**/
public Method getSetMethod;
/**
* The combined getSetField() method used on the data object.
**/
public Method getSetFieldMethod;
/**
* The field in the Object (if one exists).
**/
public Field field;
/**
* The full name of the field along with sub specifier. Therefore if the full
* field name is "birthday:date$Leve/sys/Time;" then fieldName will be
* "birthday:date". 
**/
public String fieldName;
/**
* The type of the field.
**/
public Class fieldType;
/**
* The type of the data being transfered.
**/
public Class transferType;
/**
* The type of the data used by the interface object.
**/
public Class ifType;
/**
* The pure Java name of the field without any extra specifiers.
* Therefore if the full field name is "birthday:date$Leve/sys/Time;" 
* then pureName will be
* "birthday". 
**/
public String pureName;
/**
* The full field name with all specifiers as specified in the constructor.
* Therefore if the full field name is "birthday:date$Leve/sys/Time;" 
* then fullFieldName will be that same value.
**/
public String fullFieldName;
/*
protected Wrapper objWrapper = new Wrapper(), ifWrapper = new Wrapper();
protected Wrapper fWrapper = new Wrapper(), retWrapper = new Wrapper(), gsWrapper = new Wrapper();
protected Wrapper [] oneParameter = new Wrapper[1], threeParameters = new Wrapper[3];
*/
private Wrapper objWrapper, ifWrapper, fWrapper, retWrapper, gsWrapper;
private Wrapper [] oneParameter, threeParameters;
/**
* An optional DataConverter.
**/
public DataConverter converter;
/**
* The field event that occured.
**/
public Object fieldEvent;
/**
* The data object being used.
**/
public Object dataObject;
/**
 * If this option is set in transferOptions, then whenever data is transferred
 * from the dataInterface to the Object it is automatically sent back from the
 * Object to the dataInterface. This is useful for automatic reformatting of
 * data entered by the user.
 */
public static final int TRANSFER_OPTION_AUTO_REFRESH_DATA_INTERFACE = 0x1; 
/**
 * Any of the TRANSFER_OPTION_XXX values can be used here.
 */
public int transferOptions = 0;

private static Hashtable found = new Hashtable();
private static Member ensurePublic(Member m)
{
	if (m == null) return m;
	Class dc = m.getDeclaringClass();
	if (!Modifier.isPublic(dc.getModifiers())){
		//System.out.println("Can't access class for: "+m);
		return null;
	}else{
		/*
		if (found.get(dc) == null){
			System.out.println("Public: "+dc);
			found.put(dc,dc);
			if (dc.getName().endsWith("ListEditor")){
				System.out.println("m: "+m);
			}
				
		}
		*/
	}
	if (!Modifier.isPublic(m.getModifiers())){
		//System.out.println("Can't access method for: "+m);
		return null;
	}
	return m;
}

private static Method getMethod(Class classType, String nameAndSig, boolean declared)
{
	return (Method)ensurePublic(Reflection.getMethod(classType,nameAndSig,declared));
}
private static Method getMethod(Class classType, String name, String sig, boolean declared)
{
	return (Method)ensurePublic(Reflection.getMethod(classType,name,sig,declared));
}
//===================================================================
public boolean setMethodsFor(Class classType,String getMethodNameAndSignature,String setMethodNameAndSignature)
//===================================================================
{
	if (classType == null) return false;
	if (!classType.equals(fieldType)) return false;
	ifType = classType;
	getMethod = setMethod = null;
	boolean ret = true;
	Class dr = dataInterface.getClass();
	if (getMethodNameAndSignature != null){
		getMethod = getMethod(dr,getMethodNameAndSignature,false);
		if (getMethod == null) ret = false;
	}
	if (setMethodNameAndSignature != null)
		if ((setMethod = getMethod(dr,setMethodNameAndSignature,false)) == null) ret = false;
	return ret;
}
/**
* This is only used to create a dummy field transfer.
**/
//===================================================================
public FieldTransfer(String fieldName){this.fieldName = fieldName;}
//===================================================================

//===================================================================
public FieldTransfer(Object objectOrClass,String fieldName) {this(objectOrClass,fieldName,null);}
//===================================================================

//===================================================================
public FieldTransfer(Object objectOrClass,String fieldName,DataInterface dataInterface)
//===================================================================
{
	this(Reflection.toClass(objectOrClass),Reflection.toObject(objectOrClass),fieldName,dataInterface,null);
	if (dataInterface != null) dataInterface.setFieldTransfer(this);
}

public FieldTransfer updateFrom(Object data, DataInterface di)
{
	if (di != null){
		dataObject = data;
		changeDataInterfaceWithSameClass(di);
		di.setFieldTransfer(this);
		di.updateFrom(this);
	}
	return this;
}
//===================================================================
public FieldTransfer getFor(Object data,DataInterface dataInterface)
//===================================================================
{
	FieldTransfer ft = new FieldTransfer(data,fullFieldName,dataInterface);
	dataInterface.updateFrom(ft);
	//control.fromField(ft);
	//control.updateData();
	return ft;
}

//-------------------------------------------------------------------
private boolean getFieldType(Class objectClass,String ft)
//-------------------------------------------------------------------
{
	if (fieldType != null) return true;
	Class theFieldType = ft == null ? null : Reflection.forEncodedName(ft);
	if (theFieldType != null) fieldType = theFieldType;
	else{
		Method getFieldType = dataObject == null ? null : getMethod(objectClass,"_getFieldType","(Ljava/lang/String;)Ljava/lang/Class;",false);
		if (getFieldType != null){
			if (oneParameter == null) oneParameter = new Wrapper[1];
			oneParameter[0] = new Wrapper().setObject(pureName);
			if (ifWrapper == null) ifWrapper = new Wrapper();
			try{
				Reflection.invoke(dataObject,getFieldType,oneParameter,ifWrapper);
				fieldType = (Class)ifWrapper.getObject();
			}catch(Exception e){
				fieldType = null;
			}
		}
	}
	return fieldType != null;
}
//===================================================================
public FieldTransfer(Class objectClass,Object sampleOrDataObject,String fieldName,Object dataInterface,DataConverter converter)
//===================================================================
{
	this.converter = converter;
	fullFieldName = fieldName;
	dataObject = sampleOrDataObject;
	char fspec = '$';
	String theFieldType = mString.rightOf(fieldName,fspec);
	if (theFieldType.length() == 0)
 		if (fieldName.indexOf('$') != -1)
			theFieldType = "Ljava/lang/String;";
		else
			theFieldType = null;
	else if (theFieldType.charAt(0) == 'L' && !theFieldType.endsWith(";"))
		theFieldType += ";";
	fieldName = mString.leftOf(fieldName,fspec);
	pureName = mString.leftOf(fieldName,':');
	getSetFieldMethod = getMethod(objectClass,"_getSetField","(Ljava/lang/String;Leve/sys/Wrapper;Z)Z",false);
	//
	// If we are using methods to get/set the field value then we need to know the type.
	//
	if (getSetFieldMethod != null){
		getFieldType(objectClass,theFieldType);
		if (fieldType != null){
			fWrapper = new Wrapper();
			retWrapper = new Wrapper();
		}else
			getSetFieldMethod = null;
	}
	//
	//
	//
	if (pureName.equals("this")){
		field = null;
		fieldType = objectClass;//Reflection.getEncodedName(objectClass);
		getSetFieldMethod = null;
	}else{
		field = Reflection.getField(objectClass,pureName,false);
		if (field != null) {
			getSetFieldMethod = null;
			fieldType = null;
		}
	}
	//
	this.fieldName = fieldName;
	if (field != null && fieldType == null) fieldType = field.getType();
	transferType = fieldType;

	newDataInterface(dataInterface);
	/*
	if (transferType != null && dataInterface != null){
		Class dr = dataInterface.getClass();
		if (dr == null) return;
		Class lookType = transferType;
		if ((getSetMethod = getMethod(dr,"_getSetValue","(Ljava/lang/String;Leve/sys/Wrapper;Z)Z",false)) != null){
			;
		}else if (lookType == Integer.TYPE || lookType == Long.TYPE || lookType == Byte.TYPE || lookType == Character.TYPE || lookType == Short.TYPE){
			if (lookType == Long.TYPE){
				getMethod = getMethod(dr,"getLong","()J",false);
				setMethod = getMethod(dr,"setLong","(J)V",false);
			}
			if (getMethod == null) getMethod = getMethod(dr,"getInt","()I",false);
			if (setMethod == null) setMethod = getMethod(dr,"setInt","(I)V",false);
		}else if (lookType == Double.TYPE) {
			getMethod = getMethod(dr,"getDouble","()D",false);
			setMethod = getMethod(dr,"setDouble","(D)V",false);
		}else if (lookType == Float.TYPE) {
			getMethod = getMethod(dr,"getFloat","()F",false);
			setMethod = getMethod(dr,"setFloat","(F)V",false);
		}else if (lookType == Boolean.TYPE) {
			getMethod = getMethod(dr,"getState","()Z",false);
			setMethod = getMethod(dr,"setState","(Z)V",false);
		}else if (Value.class.isAssignableFrom(lookType)){
			getMethod = getMethod(dr,"getValue","(Leve/data/Value;)V",false);
			setMethod = getMethod(dr,"setValue","(Leve/data/Value;)V",false);
		}else if (!lookType.isPrimitive()){
			getMethod = getMethod(dr,"getData","(Ljava/lang/Object;)V",false);
			if (getMethod == null)
				getMethod = getMethod(dr,"getData","()Ljava/lang/Object;",false);
			setMethod = getMethod(dr,"setData","(Ljava/lang/Object;)V",false);
		}
		if (getMethod == null && setMethod == null && getSetMethod == null){
			lookType = String.class;
		}
		if (lookType.equals(String.class)){
			getMethod = getMethod(dr,"getText","()Ljava/lang/String;",false);
			setMethod = getMethod(dr,"setText","(Ljava/lang/String;)V",false);
		}
		ifType = lookType;
	}
	*/
}
/**
 * Change the DataInterface for the FieldTransfer assuming it is the same
 * Class as the one used when it was created.
 * @param dataInterface the new dataInterface.
 */
public void changeDataInterfaceWithSameClass(Object dataInterface)
{
	this.dataInterface = dataInterface;
	if (fieldType == null) return;
	if (fieldType.equals(Transferrable.class)){
		Object ov = getFieldValue(dataObject);
		if (ov instanceof Transferrable){
			try{
				if (objWrapper == null) objWrapper = new Wrapper();
				if (((Transferrable)ov).getSetTransferData(dataInterface,objWrapper,true)){
					transferType = objWrapper.getDataClass();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}
public void changeDataInterfaceClass(Class dataInterfaceClass)
{
	if (transferType != null){
		Class dr = dataInterfaceClass;
		if (dr == null) return;
		Class lookType = transferType;
		if ((getSetMethod = getMethod(dr,"_getSetValue","(Ljava/lang/String;Leve/sys/Wrapper;Z)Z",false)) != null){
			;
		}else if (lookType == Integer.TYPE || lookType == Long.TYPE || lookType == Byte.TYPE || lookType == Character.TYPE || lookType == Short.TYPE){
			if (lookType == Long.TYPE){
				getMethod = getMethod(dr,"getLong","()J",false);
				setMethod = getMethod(dr,"setLong","(J)V",false);
			}
			if (getMethod == null) getMethod = getMethod(dr,"getInt","()I",false);
			if (setMethod == null) setMethod = getMethod(dr,"setInt","(I)V",false);
		}else if (lookType == Double.TYPE) {
			getMethod = getMethod(dr,"getDouble","()D",false);
			setMethod = getMethod(dr,"setDouble","(D)V",false);
		}else if (lookType == Float.TYPE) {
			getMethod = getMethod(dr,"getFloat","()F",false);
			setMethod = getMethod(dr,"setFloat","(F)V",false);
		}else if (lookType == Boolean.TYPE) {
			getMethod = getMethod(dr,"getState","()Z",false);
			setMethod = getMethod(dr,"setState","(Z)V",false);
		}else if (Value.class.isAssignableFrom(lookType)){
			getMethod = getMethod(dr,"getValue","(Leve/data/Value;)V",false);
			setMethod = getMethod(dr,"setValue","(Leve/data/Value;)V",false);
		/*
		}else if (lookType.equals(Wrapper.doubleClass)){
			getMethod = dr.getMethod("getDouble","("+Wrapper.doubleClass+")V",0);
			setMethod = dr.getMethod("setDouble","("+Wrapper.doubleClass+")V",0);
		*/
		}else if (!lookType.isPrimitive()){
			getMethod = getMethod(dr,"getData","(Ljava/lang/Object;)V",false);
			if (getMethod == null)
				getMethod = getMethod(dr,"getData","()Ljava/lang/Object;",false);
			setMethod = getMethod(dr,"setData","(Ljava/lang/Object;)V",false);
		}
		if (getMethod == null && setMethod == null && getSetMethod == null){
			lookType = String.class;
		}
		if (lookType.equals(String.class)){
			getMethod = getMethod(dr,"getText","()Ljava/lang/String;",false);
			setMethod = getMethod(dr,"setText","(Ljava/lang/String;)V",false);
		}
		ifType = lookType;
	}
}
public void newDataInterface(Object dataInterface)
{
	changeDataInterfaceWithSameClass(dataInterface);
	if (dataInterface != null)
		changeDataInterfaceClass(dataInterface.getClass());
}
public static final int TO_OBJECT = 1;
public static final int FROM_OBJECT = 0;


/**
 * Returns true if this FieldTransfer can actually do a transfer.
 */
//===================================================================
public boolean isValid()
//===================================================================
{
	if (field != null && fieldType != null) return true;
	return getSetFieldMethod != null;
}
//===================================================================
public boolean isField(String field)
//===================================================================
{
	if (field == null) return false;
	if (!fieldName.startsWith(field)) return false;
	int len = field.length();
	if (fieldName.length() == len) return true;
	return fieldName.charAt(len) == ':';
}
private boolean getFieldValue(Field f, Object obj, Wrapper dest)
{
	dest.zero(fieldType);
	try{
		//System.out.println(this+" = Field type: "+(char)dest.getType());
		Reflection.getFieldValue(obj,field,dest);
		return true;
	}catch(Exception e){
		return false;
	}
}
private Reflection.InstanceField fld;

private boolean setFieldValue(Field f, Object obj, Wrapper src)
{
	try{
		fld = Reflection.InstanceField.match(fld, obj, f);
		fld.setData(src).set();
		//Reflection.setFieldValue(obj,f,src);
		return true;
	}catch(Exception e){
		return false;
	}
}
private void setupWrappers()
{
	if (threeParameters == null) {
		threeParameters = new Wrapper[3];
		oneParameter = new Wrapper[1];
		objWrapper = new Wrapper();
		fWrapper = new Wrapper();
		ifWrapper = new Wrapper();
		gsWrapper = new Wrapper();
		retWrapper = new Wrapper();
		threeParameters[0] = fWrapper;
		threeParameters[1] = ifWrapper;
		threeParameters[2] = gsWrapper;
	}
}
//===================================================================
public synchronized boolean getFieldValue(Object obj,Wrapper dest)
//===================================================================
{
	// This should not use objWrapper
	//
	if (obj == null) return false;
	dest.zero(fieldType);
	if (pureName.equals("this")){
		dest.setObject(obj);
		return true;
	}else if (getSetFieldMethod != null){
		setupWrappers();
		fWrapper.setObject(pureName);
		ifWrapper.setObject(dest);
		gsWrapper.setBoolean(true);
		try{
			Reflection.invoke(obj,getSetFieldMethod,threeParameters,retWrapper);
		}catch(Exception e){
			retWrapper.setBoolean(false);
		}
		if (retWrapper.getBoolean()) return true;
		if (field != null)
			return getFieldValue(field,obj,dest);
		else
			return false;
	}else if (field != null){
		return getFieldValue(field,obj,dest);
	}else
		return false;
}
//===================================================================
public Object getFieldValue(Object obj)
//===================================================================
{
	Wrapper got = Wrapper.getCached();
	try{
		if (!getFieldValue(obj,got)) return null;
		if (got.getType() != got.OBJECT) return null;
		Object ret = got.getObject();
		return ret;
	}finally{
		got.cache();
	}
}
/**
* This uses the "dataObject" variable as the object for field transfer.
**/
//===================================================================
public void transfer(int direction) {transfer(dataObject,direction);}
//===================================================================

private boolean invoke(Object target, Method method, Wrapper[] pars, Wrapper dest)
{
	try{
		Reflection.invoke(target,method,pars,dest);
		return true;
	}catch(Exception e){
		e.printStackTrace();
		return false;
	}
}
private Transferrable gsmt;

public synchronized Wrapper[] getSetMethodSetupForGet(Object obj)
{
	if (fieldType == null) return null;
	setupWrappers();
	objWrapper.zero(fieldType);
	if (obj == null || (getMethod == null && getSetMethod == null)) return null;
	Object ov = getFieldValue(obj);
	gsmt = (ov instanceof Transferrable) ? (Transferrable)gsmt : null;
	objWrapper.setObject(ov);
	getFieldValue(obj,objWrapper);
	threeParameters[0] = fWrapper.setObject(pureName);
	threeParameters[1] = ifWrapper.setObject(objWrapper);
	threeParameters[2] = gsWrapper.setBoolean(true);
	return threeParameters;
}
public synchronized boolean getSetMethodAfterGet(Object obj)
{
	ifWrapper.copyFrom(objWrapper);
	try{
		if (gsmt != null){
			if (gsmt.getSetTransferData(dataInterface,ifWrapper,false))
				return true;
		}
		if (converter == null) Wrapper.doConvertData(ifWrapper,ifType,objWrapper,fieldType);
		else converter.convertData(ifWrapper,ifType,objWrapper,fieldType);
		//
		// At this point the objWrapper contains the data.
		//
		if (getSetFieldMethod != null){
			threeParameters[0] = fWrapper.setObject(pureName);
			threeParameters[1] = ifWrapper.setObject(objWrapper);
			threeParameters[2] = gsWrapper.setBoolean(false);
			invoke(obj,getSetFieldMethod,threeParameters,retWrapper);
			if (retWrapper.getBoolean()) return true;
			if (field != null)
				return setFieldValue(field,obj,objWrapper);
			else
				return false;
		}else if (field != null){
			return setFieldValue(field,obj,objWrapper);
		}else
			return false;
	}finally{
		if ((transferOptions & TRANSFER_OPTION_AUTO_REFRESH_DATA_INTERFACE) != 0)
			transfer(obj,FROM_OBJECT);
	}
}
//===================================================================
public synchronized boolean transfer(Object obj,int direction)
//===================================================================
{
	if (fieldType == null) return false;
	setupWrappers();
	objWrapper.zero(fieldType);
	//===================================================================
	if (direction == FROM_OBJECT){
	//===================================================================
		/*
		if (setMethod == null && getSetMethod == null) return;
		if (pureName.equals("this")){
				objWrapper.setObject(obj);
		}else if (getSetFieldMethod != null){
			if (obj != null) {
				threeParameters[0] = fWrapper.setObject(pureName);
				threeParameters[1] = ifWrapper.setObject(objWrapper);
				threeParameters[2] = gsWrapper.setBoolean(true);
				try{
					Reflection.invoke(obj,getSetFieldMethod,threeParameters,retWrapper);
				}catch(Exception e){
					retWrapper.setBoolean(false);
				}
				if (!retWrapper.getBoolean() && field != null)
					field.getValue(obj,objWrapper);
			}
		}else if (field != null){
			if (obj != null)
				field.getValue(obj,objWrapper);
		}else
			return;
		*/
		if (!getFieldValue(obj,objWrapper)) return false;
		//
		//At this point, the field value is in objWrapper.
		//
		Class transferType = fieldType;
		if (Transferrable.class.isAssignableFrom(fieldType)){
			Transferrable t = (Transferrable)objWrapper.getObject();
			try{
				if (t != null && t.getSetTransferData(dataInterface,objWrapper,true)) 
						transferType = objWrapper.getDataClass();
			}catch(Exception e){}
		}
		//
		// Convert if necessary.
		//
		//System.out.println(fieldName+": "+converter);
		if (converter == null) Wrapper.doConvertData(objWrapper,transferType,ifWrapper,ifType);
		else converter.convertData(objWrapper,transferType,ifWrapper,ifType);
		objWrapper.copyFrom(ifWrapper);
		//
		// Now put the data in the dataInterface.
		// The objWrapper is now a copy of the ifWrapper.
		//
		if (getSetMethod != null){
			threeParameters[0] = fWrapper.setObject(pureName);
			threeParameters[1] = ifWrapper.setObject(objWrapper);
			threeParameters[2] = gsWrapper.setBoolean(false);
			return invoke(dataInterface,getSetMethod,threeParameters,retWrapper);
		}else if (setMethod != null){
			oneParameter[0] = objWrapper;
			return invoke(dataInterface,setMethod,oneParameter,retWrapper);
		}else{
			//System.out.println("No set method: "+this);
			return false;
		}
	//===================================================================
	}else try{ // TO_OBJECT;
	//===================================================================
		//objWrapper.setType(fieldType);
		if (obj == null || (getMethod == null && getSetMethod == null)) return false;
		Object ov = getFieldValue(obj);
		objWrapper.setObject(ov);
		if (getSetMethod != null){
			getFieldValue(obj,objWrapper);
			threeParameters[0] = fWrapper.setObject(pureName);
			threeParameters[1] = ifWrapper.setObject(objWrapper);
			threeParameters[2] = gsWrapper.setBoolean(true);
			invoke(dataInterface,getSetMethod,threeParameters,retWrapper);
			ifWrapper.copyFrom(objWrapper);
		}else if (getMethod.getReturnType() != Void.TYPE){
			if (pureName.equals("this")) return true;
			ifWrapper.zero(ifType);
			invoke(dataInterface,getMethod,Wrapper.noParameter,ifWrapper);
		}else{ //Get method does not return.
			//This would be used for void setData(Object) and void getData(Object)
			//Note that no conversion is done here.
			if (ov != null){
				objWrapper.setObject(ov);
				oneParameter[0] = objWrapper;
				invoke(dataInterface,getMethod,oneParameter,null);
			}
			if (getSetFieldMethod == null) return false;
			ifWrapper.setObject(ov);
		}
		//
		// Now have the new data in the ifWrapper and possibly the old data
		// (as a destination object) in objWrapper
		//
		if (ov instanceof Transferrable){
			if (((Transferrable)ov).getSetTransferData(dataInterface,ifWrapper,false))
				return true;
		}
		if (converter == null) Wrapper.doConvertData(ifWrapper,ifType,objWrapper,fieldType);
		else converter.convertData(ifWrapper,ifType,objWrapper,fieldType);
		//
		// At this point the objWrapper contains the data.
		//
		if (getSetFieldMethod != null){
			threeParameters[0] = fWrapper.setObject(pureName);
			threeParameters[1] = ifWrapper.setObject(objWrapper);
			threeParameters[2] = gsWrapper.setBoolean(false);
			invoke(obj,getSetFieldMethod,threeParameters,retWrapper);
			if (retWrapper.getBoolean()) return true;
			if (field != null)
				return setFieldValue(field,obj,objWrapper);
			else
				return false;
		}else if (field != null){
			return setFieldValue(field,obj,objWrapper);
		}else
			return false;
	}finally{
		if ((transferOptions & TRANSFER_OPTION_AUTO_REFRESH_DATA_INTERFACE) != 0)
			transfer(obj,FROM_OBJECT);
	}
}
//===================================================================
public String toString()
//===================================================================
{
	if (field == null) return "<no field>";
	String ret = fieldType+" "+field.getName()+"<=>[";
	if (getSetMethod != null) ret += getSetMethod.toString();
	else ret += mString.toString(getMethod)+","+mString.toString(setMethod);
	ret += "]";
	return ret;
}
//##################################################################
}
//##################################################################

