/*
 * Created on Aug 1, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Vector;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class MethodCall {
	
	public String method;
	public String name;
	public Class [] parameterTypes;
	public Class retType;
	//public String id;
	
	private Vector parameters = new Vector();
	private int curType = 0;

	/**
	* Create a new MethodCall targeted at the specified method. Parameter
	* and return specs MUST be provided e.g.<br><br>
	* new MethodCall("aMethod(IILjava/lang/String;)Z");<p>
	* Standard Java type specifiers are used, specifically.
	* <p>
	* B - byte, C - char, S - short, I - int, J - long, F - float, D - Double
	* Z - boolean, V - void (for method types only)<br>
	* [<i>type-specifier</i> - for an array.<br>
	* L<i>className</i>; - for object (NOTE the ending semi-colon).<p> 
	* For object (L) you should use / instead of . as the package separator.
	* <p>
	* The format for a method is: <i>method_name</i>(<i>concatenated parameter type specifiers</i>)<i>return_type</i>
	* <p>
	* There are no separators between the parameter type specifiers. If the the method is void you should
	* use V as the return type.
	**/
//	===================================================================
	public MethodCall(String method)
//	===================================================================
	{
		setMethod(method);
	}
	/**
	 * Clear the parameter list to make it ready for a new
	 * set of parameters.
	 * @return itself.
	 */
	public MethodCall reset()
	{
		parameters.clear();
		return this;
	}
//	-------------------------------------------------------------------
	private void setMethod(String method)
//	-------------------------------------------------------------------
	{
		this.method = method;
		int idx = method.indexOf('(');
		if (idx == -1) throw new IllegalArgumentException("Bad method name: "+method);
		name = method.substring(0,idx);
		parameterTypes = Reflection.getParameterTypes(method);
		retType = Reflection.getReturnOrFieldType(method);
		curType = 0;
	}
//	-------------------------------------------------------------------
	private Class getCurType()
//	-------------------------------------------------------------------
	{
		try{
			return parameterTypes[parameters.size()];
		}catch(IndexOutOfBoundsException e){
			throw new IllegalStateException("Too many parameters - only "+parameterTypes.length+" expected.");
		}
	}
	private MethodCall incompatibleArgument()
	{
		throw new IllegalArgumentException("Expected type: "+parameterTypes[parameters.size()].getName()+" for parameter: "+parameters.size());
	}
	/**
	* Use this to add a boolean parameter.
	* @param value The boolean parameter
	* @exception IllegalArgumentException if the current parameter
	* is not of a boolean type.
	* @return itself.
	*/
//	===================================================================
	public MethodCall add(boolean value)
//	===================================================================
	{
		try{
			return add(Reflection.toWrapper(getCurType(),value));
		}catch(IllegalArgumentException e){
			return incompatibleArgument();
		}
	}
	/**
	* Use this to add a char parameter.
	* @param value The character parameter
	* @exception IllegalArgumentException if the current parameter
	* is not of a char type.
	* @return itself.
	*/
//	===================================================================
	public MethodCall add(char value)
//	===================================================================
	{
		try{
			return add(Reflection.toWrapper(getCurType(),value));
		}catch(IllegalArgumentException e){
			return incompatibleArgument();
		}
	}
	/**
	* Use this to add a parameter of type byte, short, char, int and long.
	* @param value The value to add.
	* @return itself.
	* @exception IllegalArgumentException if the current parameter
	* is not of an integer type.
	*/
//	===================================================================
	public MethodCall add(long value)
//	===================================================================
	{
		try{
			return add(Reflection.toWrapper(getCurType(),value));
		}catch(IllegalArgumentException e){
			return incompatibleArgument();
		}
	}
	/**
	* Use this to add a parameter of type double or float.
	* @param value The value to add.
	* @return itself.
	* @exception IllegalArgumentException if the current parameter
	* is not of a float or double type.
	*/
//	===================================================================
	public MethodCall add(double value)
//	===================================================================
	{
		try{
			return add(Reflection.toWrapper(getCurType(),value));
		}catch(IllegalArgumentException e){
			return incompatibleArgument();
		}
	}

	private void checkPrimitiveType(Class primitive, Class object)
	{
		if (object == null || !primitive.equals(object)) incompatibleArgument();
	}
	
	/**
	 * Use this to add an Object or array parameter, or to add a primitive parameter
	 * that is wrapped in Java Wrapper object.
	 * @param obj the Object to add.
	 * @return this MethodCall.
	 */
	public MethodCall add(Object obj)
	{
		Class c = getCurType();
		Class oc = obj == null ? null : obj.getClass();
		if (c == Byte.TYPE) checkPrimitiveType(Byte.class,oc);
		else if (c == Short.TYPE) checkPrimitiveType(Short.class,oc);
		else if (c == Character.TYPE) checkPrimitiveType(Character.class,oc);
		else if (c == Integer.TYPE) checkPrimitiveType(Integer.class,oc);
		else if (c == Long.TYPE) checkPrimitiveType(Long.class,oc);
		else if (c == Float.TYPE) checkPrimitiveType(Float.class,oc);
		else if (c == Double.TYPE) checkPrimitiveType(Double.class,oc);
		else if (c == Boolean.TYPE) checkPrimitiveType(Boolean.class,oc);
		else if (obj != null && !c.isInstance(obj)) return incompatibleArgument();
		parameters.add(obj);
		return this;
	}
	/**
	 * Use this to invoke a static method on a Class.
	 * @param cls the Class to invoke the static method on.
	 * @return the Object returned by the invocation.
	 * @throws NoSuchMethodException if the method does not exist.
	 * @throws IllegalAccessException if the underlying method is inaccessible.
	 * @throws InvocationTargetException if the underlying method threw an exception.
	 */
	public Object invokeStatic(Class cls)
	throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		return invokeItOn(cls);
	}
	/**
	 * Use this to invoke a method on an object (which should not be null). Use
	 * invokeStatic() to invoke a static method. 
	 * @param obj the Object to invoke the method on.
	 * @return the Object returned by the invocation.
	 * @throws NoSuchMethodException if the method does not exist.
	 * @throws IllegalAccessException if the underlying method is inaccessible.
	 * @throws InvocationTargetException if the underlying method threw an exception.
	 */
	public Object invokeOn(Object obj)
	throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		return invokeItOn(obj);
	}
	/**
	 * Use this to invoke a static method on a Class.
	 * @param cls the Class to invoke the static method on.
	 * @param defaultReturn a default value to return in case the 
	 * method is not found or any other exception is thrown.
	 * @return the Object returned by the invocation.
	 * @throws NoSuchMethodException if the method does not exist.
	 * @throws IllegalAccessException if the underlying method is inaccessible.
	 * @throws InvocationTargetException if the underlying method threw an exception.
	 */
	public Object invokeStatic(Class cls,Object defaultReturn)
	{
		try{
			return invokeItOn(cls);
		}catch(Exception e){
			return defaultReturn;
		}
	}
	/**
	 * Use this to invoke a method on an object (which should not be null). Use
	 * invokeStatic() to invoke a static method. 
	 * @param obj the Object to invoke the method on.
	 * @param defaultReturn a default value to return in case the 
	 * @return the Object returned by the invocation.
	 * @throws NoSuchMethodException if the method does not exist.
	 * @throws IllegalAccessException if the underlying method is inaccessible.
	 * @throws InvocationTargetException if the underlying method threw an exception.
	 */
	public Object invokeOn(Object obj,Object defaultReturn)
	{
		try{
			return invokeItOn(obj);
		}catch(Exception e){
			return defaultReturn;
		}
	}
	/**
	 * Use this to invoke a method on an object (which should not be null). Use
	 * invokeStatic() to invoke a static method. 
	 * @param obj the Object to invoke the method on.
	 * @param defaultReturn a default value to return in case the 
	 * @return the unwrapped long value returned by the invocation.
	 * @throws NoSuchMethodException if the method does not exist.
	 * @throws IllegalAccessException if the underlying method is inaccessible.
	 * @throws InvocationTargetException if the underlying method threw an exception.
	 */
	public long invokeOn(Object obj,long defaultReturn)
	{
		try{
			return Reflection.unwrapLong(invokeItOn(obj));
		}catch(Exception e){
			return defaultReturn;
		}
	}
	/**
	 * Use this to invoke a method on an object (which should not be null). Use
	 * invokeStatic() to invoke a static method. 
	 * @param obj the Object to invoke the method on.
	 * @param defaultReturn a default value to return in case the 
	 * @return the unwrapped double value returned by the invocation.
	 * @throws NoSuchMethodException if the method does not exist.
	 * @throws IllegalAccessException if the underlying method is inaccessible.
	 * @throws InvocationTargetException if the underlying method threw an exception.
	 */
	public double invokeOn(Object obj,double defaultReturn)
	{
		try{
			return Reflection.unwrapDouble(invokeItOn(obj));
		}catch(Exception e){
			return defaultReturn;
		}
	}
	/**
	 * Use this to invoke a method on an object (which should not be null). Use
	 * invokeStatic() to invoke a static method. 
	 * @param obj the Object to invoke the method on.
	 * @param defaultReturn a default value to return in case the 
	 * @return the unwrapped boolean returned by the invocation.
	 * @throws NoSuchMethodException if the method does not exist.
	 * @throws IllegalAccessException if the underlying method is inaccessible.
	 * @throws InvocationTargetException if the underlying method threw an exception.
	 */
	public boolean invokeOn(Object obj,boolean defaultReturn)
	{
		try{
			return Reflection.unwrapBoolean(invokeItOn(obj));
		}catch(Exception e){
			return defaultReturn;
		}
	}
	/**
	 * Use this to invoke a method on an object (which should not be null). Use
	 * invokeStatic() to invoke a static method. 
	 * @param obj the Object to invoke the method on.
	 * @param defaultReturn a default value to return in case the 
	 * @return the unwrapped char value returned by the invocation.
	 * @throws NoSuchMethodException if the method does not exist.
	 * @throws IllegalAccessException if the underlying method is inaccessible.
	 * @throws InvocationTargetException if the underlying method threw an exception.
	 */
	public char invokeOn(Object obj,char defaultReturn)
	{
		try{
			return (char)Reflection.unwrapLong(invokeItOn(obj));
		}catch(Exception e){
			return defaultReturn;
		}
	}
	
	private Object invokeItOn(Object obj) 
	throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Class oc = obj instanceof Class ? (Class)obj : obj.getClass();
		Method m = oc.getMethod(name,parameterTypes);
		if (oc == obj && !Modifier.isStatic(m.getModifiers())) 
			throw new IllegalArgumentException("Method is not static.");
		Object[] pars = new Object[parameters.size()];
		parameters.copyInto(pars);
		return m.invoke(oc == obj ? null : obj, pars);
	}
}
//####################################################
