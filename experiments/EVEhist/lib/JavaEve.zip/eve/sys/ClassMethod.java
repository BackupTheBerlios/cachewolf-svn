/*
 * Created on Apr 1, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author Michael L Brereton
 *
 * This class is <b>not</b> synchronized, the Wrapper values are re-used. Synchronize
 * with the instance if you are going to use this among different Threads.
 */
//####################################################
public class ClassMethod {

	private Method method;
	private Wrapper dest;
	private Wrapper[] pars;
	private static Wrapper[] empty = new Wrapper[0];
	private int wrapperType;
	
	public boolean exists()
	{
		return method != null;
	}
	public Method getMethod()
	{
		return method;
	}
	public Wrapper getResult()
	{
		return dest;
	}
	public Wrapper[] getParameters()
	{
		return pars;
	}
	private void setMethod(Method m)
	{
		method = m;
		if (m == null) return;
		dest = new Wrapper();
		Class[] pt = m.getParameterTypes();
		if (pt.length != 0) {
			pars = new Wrapper[pt.length];
			for (int i = 0; i<pars.length; i++)
				pars[i] = new Wrapper();
		}else
			pars = empty;
		wrapperType = Wrapper.toWrapperType(m.getReturnType());
	}
	public ClassMethod(String className, String methodNameAndSpecs,boolean declaredOnly)
	{
		try{
			setMethod(Reflection.getMethod(Type.loadForName(className),methodNameAndSpecs,declaredOnly));
		}catch(Exception e){
			setMethod(null);
		}
	}
	public ClassMethod(Method m)
	{
		setMethod(m);
	}
	public ClassMethod getCopy()
	{
		return new ClassMethod(method);
	}
	public Wrapper invokeOn(Object target,Wrapper[] parameters, Wrapper dest) 
	throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	{
		if (parameters == null) parameters = pars;
		if (dest == null) dest = this.dest;
		Reflection.invoke(target,method,parameters,dest);
		return dest;
	}
	public Wrapper invokeOn(Object target) 
	throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	{
		return invokeOn(target,null,null);
	}
	public Wrapper invoke(Object target)
	{
		if (dest == null) dest = new Wrapper();
		if (method == null) return dest.zero(wrapperType);
		try{
			return invokeOn(target);
		}catch(Exception e){
			return dest.zero(wrapperType);
		}
	}
	public boolean canInvokeOn(Object obj)
	{
		if (method == null) return false;
		return method.getDeclaringClass().isInstance(obj);
	}
}
//####################################################
