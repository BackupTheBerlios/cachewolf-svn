/*
 * Created on Mar 2, 2005
 *
 */
package eve.sys;

/**
 * This is thrown if a wait is attempted within a System thread. Under a native
 * Eve VM, the system thread is the one that calls eveMain(), or one that is
 * called from a native method.
 * 
 * @author Mike
 *
 */
public class InvalidThreadException extends RuntimeException {

	/**
	 * @param message
	 */
	public InvalidThreadException(String message) {
		super(message);
	}

	/**
	 * 
	 */
	public InvalidThreadException() {
		super();
	}

	/**
	 * @param cause
	 */
	public InvalidThreadException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public InvalidThreadException(String message, Throwable cause) {
		super(message, cause);
	}

}
