/*
 * Created on Mar 24, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;

/**
 * A WeakRef is a weak OR soft reference to an Object that is mutable. You can change
 * the object being referred to using the set() method.
 * <p>
 * You specify whether it should be a weak or soft reference in the constructor. The
 * difference between the two is that if an Object is only reachable by Weak references
 * then the Object will be garbage collected and the weak references cleared as soon
 * as possible. An object that is soft referenced will not be immediately garbage
 * collected but may be kept until a later time. The only guarantee is that should
 * the VM run out of memory, all soft references will be cleared and their objects
 * garbage collected before the VM throws an out of memory error.
 * @author Michael L Brereton
 *
 */
//####################################################
public class WeakRef {
	private Reference ref;
	private boolean isSoft;
	private static boolean hasNative = true;
	private static native void setRef(Reference r, Object who);
	/**
	 * Returns if this Ref is a soft reference.
	 */
	public boolean isSoftRef()
	{
		return isSoft;
	}
	/**
	 * Create a WeakRef initially set to be referencing an Object.
	 * @param forWho the object to reference (which may be null).
	 * @param isSoft set true for this to act as a soft reference.
	 */
	public WeakRef(Object forWho,boolean isSoft)
	{
		ref = isSoft ? (Reference)new SoftReference(forWho) : (Reference)new WeakReference(forWho);
	}
	/**
	 * Create a WeakRef initially set to be referencing an Object.
	 * @param forWho the object to reference (which may be null).
	 */
	public WeakRef(Object forWho)
	{
		this(forWho,false);
	}
	/**
	 * Create a WeakRef initially set to be referencing nothing which may
	 * be soft or weak.
	 * @param isSoft set true for this to act as a soft reference.
	 */
	public WeakRef(boolean isSoft)
	{
		this.isSoft = isSoft;
	}
	/**
	 * Create a WeakRef initially set to be referencing nothing.
	 */
	public WeakRef()
	{
	}
	/**
	 * Set the WeakRef to reference a different object (which may be null).
	 * @param who the new Object to reference.
	 * @return itself.
	 */
	public WeakRef set(Object who)
	{
		//
		// ref will never be set to null once it is non-null.
		//
		if (ref == null){
			ref = isSoft ? (Reference)new SoftReference(who) : (Reference)new WeakReference(who);
			return this;
		}
		if (hasNative)try{
			setRef(ref,who);
			return this;
		}catch (Throwable t){
			Device.checkNoNativeMethod(t);
			hasNative = false;
		}
		ref = isSoft ? (Reference)new SoftReference(who) : (Reference)new WeakReference(who); 
		return this;
	}
	/**
	 * Set the WeakRef to reference nothing.
	 * @return itself.
	 */
	public WeakRef clear()
	{
		//
		// ref will never be set to null once it is non-null.
		//
		if (ref != null) ref.clear();
		return this;
	}
	/**
	 * Get the object being referred to as long as it has not been cleared.
	 * @return the object being referred to which may be null if it has been
	 * cleared.
	 */
	public Object get()
	{
		//
		// ref will never be set to null once it is non-null.
		//
		return ref == null ? null : ref.get();  
	}
	public static Object get(WeakRef from)
	{
		if (from == null) return null;
		return from.get();
	}
	public static WeakRef set(WeakRef to, Object newObject)
	{
		if (to == null && newObject == null) return null;
		if (to == null) return new WeakRef(newObject);
		return to.set(newObject);
	}
	public static WeakRef clear(WeakRef wr)
	{
		if (wr != null) wr.clear();
		return wr;
	}
}

//####################################################
