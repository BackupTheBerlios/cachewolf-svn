package eve.sys;

/**
 * This is a convenience class that can be used to cause the current Thread
 * to yield to GUI events (if any are present) during processor intesive tasks
 * (e.g. decoding HTML text).<p>
 * The class allows you to specify the minimum interval to wait between yields
 * and the maximum length of time to wait during a yield.<p>
 * The class calls the Device.yieldToEvents() method to accomplish this. This
 * method will call the GUI yieldToEvents() method if one exists, otherwise
 * the default yieldToEvents() is used.
 */
public class YieldToEvents {

	private int howLong;
	private int interval;
	private long nextYield;
	/**
	 * Create a new YieldToEvents.
	 * @param forHowLong the maximum length of time in milliseconds to yield.
	 * @param atIntervalsOf the minimum length of time in milliseconds to elpase
	 * between yields.
	 */
	public YieldToEvents(int forHowLong, int atIntervalsOf)
	{
		set(forHowLong,atIntervalsOf);
	}
	/**
	 * Modify the parameters of this YieldToEvents.
	 * @param forHowLong the maximum length of time in milliseconds to yield.
	 * @param atIntervalsOf the minimum length of time in milliseconds to elpase
	 * between yields.
	 */
	public void set(int forHowLong, int atIntervalsOf)
	{
		howLong = forHowLong;
		interval = atIntervalsOf;
		nextYield = System.currentTimeMillis()+interval;
	}
	/**
	 * Yield to events if there are pending events and if the minimum interval has
	 * elapsed.
	 * @return true if the minimum interval has elapsed and a yield was at least
	 * attempted. false if not.
	 */
	public boolean yield()
	{
		long now = System.currentTimeMillis();
		if (now >= nextYield){
			nextYield = now+interval;
			Device.yieldToEvents(howLong);
			return true;
		}
		return false;
	}
}
