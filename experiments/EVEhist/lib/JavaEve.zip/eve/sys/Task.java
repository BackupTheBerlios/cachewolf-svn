package eve.sys;

//##################################################################
public abstract class Task extends Handle implements Runnable{
//##################################################################

private Thread myThread;
private boolean shouldInterrupt;
private boolean isDaemon;

/**
 * This must be called before the Task is started. Use it to specify
 * that the Task should run in a Daemon Thread.
 * @param on true to set the Task as a Daemon, false if not.
 */
public void setDaemon(boolean on)
{
	isDaemon = on;
}
public boolean getDaemon()
{
	return isDaemon;
}
protected void interrupt()
{
	super.interrupt();
	synchronized(this){
		if (myThread == null) shouldInterrupt = true;
		else try{
			myThread.interrupt();
		}catch(SecurityException e){}
	}
}
/**
* Start the Task at normal priority. This will cause the Running flag
* to be set and then the doRun() method will be called. When doRun()
* returns the Stopped flat will be set (if not already done so).
* @return this Task as a Handle.
*/
//===================================================================
public synchronized Handle start()
//===================================================================
{
	return start(Thread.NORM_PRIORITY);
}
/**
* Start the Task at normal priority. This will cause the Running flag
* to be set and then the doRun() method will be called. When doRun()
* returns the Stopped flat will be set (if not already done so).
* @param priority a Thread.XXX_PRIORITY value.
* @return this Task.
*/
//===================================================================
public synchronized Task start(int priority)
//===================================================================
{
	if (myThread != null) return this;
	setFlags(Running,Stopped);
	myThread = new Thread(this);
	try{
		myThread.setDaemon(isDaemon);
	}catch(Throwable t){}
	try{
		myThread.setPriority(priority);
	}catch(Throwable t){}
	myThread.start();
	if (shouldInterrupt) try{
		myThread.interrupt();
	}catch(SecurityException e){}
	shouldInterrupt = false;
	return this;
}
/**
 * Do not override this method, override the doRun() method to provide
 * Task functionality.
 */
//===================================================================
public final void run()
//===================================================================
{
	setFlags(Running,Stopped);
	try{
		doRun();
	}catch(Throwable t){
		fail(t);
	}finally{
		setFlags(Stopped,Running);
		complete();
	}
}
/**
 * This is called after doRun() has exited and the Stopped flags have been set. 
 */
protected void complete()
{
	
}

/**
* Override this to provide functionality for the Task.
**/
//-------------------------------------------------------------------
protected abstract void doRun();
//-------------------------------------------------------------------

/**
 * Cause the current thread to sleep for a certain length of time.
 * @param milliseconds The time to sleep for.
 * @return false if it was interrupted, true if it was not.
 */
//-------------------------------------------------------------------
protected boolean sleep(int milliseconds)
//-------------------------------------------------------------------
{
	try{
		Thread.sleep(milliseconds);
		return true;
	}catch(InterruptedException e){
		return false;
	}
}
/**
 * This can be used after a call to waitOn() or waitOnAny() has failed.
 * If the shouldStop variable OR if the wasWaitingOn handle has the Aborted flag set,
 * then the handle for this task will be set to Aborted and true will be returned.
 * Otherwise this task's handle will be set to Failure, and its errorObject set to the
 * same error object as wasWaitingOn. If stopWaitingOn is true then the stop() metod
 * will be called on wasWaitingOn.
 * <p><b>Only call this from within the TaskObject's thread.</b>
 * @param wasWaitingOn The Handle that this task was waiting on.
 * @param stopWaitingOn If this is true then wasWaitingOn will have its stop() method called.
 * @return true if this task or the wasWaitingOn task was aborted, false if wasWaitingOn had
 * failed.
 */
	/*
//===================================================================
public boolean checkAbortFail(Handle wasWaitingOn,boolean stopWaitingOn)
//===================================================================
{
	try{
		if (shouldStop || ((wasWaitingOn.check() & Handle.Aborted) != 0)){
			set(Aborted);
			return true;
		}
		error = wasWaitingOn.error;
		set(Failure);
		return false;
	}finally{
		if (stopWaitingOn) wasWaitingOn.stop(0);
	}
}
*/
/**
 * Call this to check on the result of a waitOn() or waitOnAny() and automatically set the
 * Failure or Abort flag of the handle of this task, based on the failure/success of waitOn.
 * <p><b>Only call this from within the TaskObject's thread.</b>
 * @param resultOfWait The result of the waitOn() or waitOnAny() call.
 * @param wasWaitingOn The hande the task was waiting on.
 * @param stopWaitingOn If this is true then the task will be stopped on failure.
 * @return will always be resultOfWait.
 */
	/*
//===================================================================
public boolean checkFailure(boolean resultOfWait,Handle wasWaitingOn,boolean stopWaitingOn)
//===================================================================
{
	if (resultOfWait) return true;
	checkAbortFail(wasWaitingOn,stopWaitingOn);
	return false;
}
*/
/**
 * This calls waitOn(waitFor,Handle.Success,copyProgress) and then calls checkFailure() on it.
 * This will basically wait until either the waitFor handle has the Success flag set or until
 * it has stopped without that flag being set (which usually indicates failure) or until the
 * task has the stop method called (by shouldStop being set true).
 * In the case of failure this task's handle will be set to either Failure or Aborted depending
 * on whether the stop() method was called on this task's handle or whether the waitFor handle
 * failed or aborted.
 * <p><b>Only call this from within the TaskObject's thread.</b>
 * @param waitFor The handle to wait for.
 * @param copyProgress True if you want this task's handle to reflect the progress of the waitFor handle.
 * @return true on success, false on failure.
 */
	/*
//===================================================================
public boolean waitOnSuccess(Handle waitFor,boolean copyProgress)
//===================================================================
{
	return checkFailure(waitOn(waitFor,Handle.Success,TimeOut.Forever,copyProgress),waitFor,true);
}
*/
/**
 * Get the thread that is executing this task.
 */
//===================================================================
public final Thread getThread()
//===================================================================
{
	return myThread;
}
/*
//=================================================================
public static void main(String[] args) throws InterruptedException
//=================================================================
{
Handle t = new Task(){
	protected void doRun(){
		System.out.println("Pausing...\n");
		this.sleep(3000);
		System.out.println("Out!\n");
	}
}.start();
System.out.println("Wating...\n");
t.waitUntilStopped();
System.out.println("Done...\n");
}
*/

/*
//=================================================================
public static void main(String[] args) throws InterruptedException
//=================================================================
{
	final Object lock = new Object();
	
	new Thread(){
				public void run(){
					synchronized(lock){
						try{
							System.out.println("Holding for 3 seconds.");
							Thread.sleep(3000);
						}catch(Exception e){}
					}
				}
	}.start();
	Thread.sleep(1000);
	Thread t1 = new Thread(){
		public void run(){
			System.out.println("Attempting to lock.");
			synchronized(lock){
				try{
					System.out.println("Locked!");
					//Thread.interrupted(); <- Put this and InterruptedException will not be generated
					Thread.sleep(3000);
				}catch(Exception e){
					System.out.println("Caught: "+e);
				}
			}
		}
	};
	t1.start();
	t1.interrupt();
	System.out.println("Interrupted!");
}
	*/
//##################################################################
}
//##################################################################


