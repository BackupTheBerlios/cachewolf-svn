/*
 * Created on Mar 14, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Iterator;

/**
 * This Interface is used by the Object returned by Vm.getApplet() 
 * and will be only available if the Eve application is actually
 * running as an Applet within a Web Browser.
 */
public interface Applet
{
	  /**
	   * Tests whether or not this applet is currently active. An applet is active
	   * just before the browser invokes start(), and becomes inactive just
	   * before the browser invokes stop().
	   *
	   * @return <code>true</code> if this applet is active
	   */
	  boolean isActive();

	  /**
	   * Returns the basename URL of the document this applet is embedded in. This
	   * is everything up to the final '/'.
	   *
	   * @return the URL of the document this applet is embedded in
	   * @see #getCodeBase()
	   */
	  URL getDocumentBase();

	  /**
	   * Returns the URL of the code base for this applet.
	   *
	   * @return the URL of the code base for this applet
	   */
	  URL getCodeBase();

	  /**
	   * Returns the value of the specified parameter that was specified in
	   * the <code>&lt;APPLET&gt;</code> tag for this applet.
	   *
	   * @param name the parameter name
	   * @return the parameter value, or null if the parameter does not exist
	   * @throws NullPointerException if name is null
	   */
	  String getParameter(String name);

	  /**
	   * Returns the applet context for this applet.
	   *
	   * @return the applet context for this applet
	   */
	  //AppletContext getAppletContext();

	  /**
	   * Requests that the applet window for this applet be resized.
	   *
	   * @param width the new width in pixels
	   * @param height the new height in pixels
	   */
	  boolean appletResize(int width, int height);
	  /**
	   * Displays the web page pointed to by the specified URL in the window
	   * for this object.  This page replaces the document that is currently
	   * there.
	   *
	   * @param url the URL of the web page to load; unspecified on an error
	   */
	  boolean showDocument(URL url);

	  /**
	   * Displays the web page pointed to be the sepcified URL in the window
	   * with the specified name.  The standard names "_top", "_blank",
	   * "_parent", and "_self" are allowed. An applet viewer may disregard
	   * this request.
	   *
	   * @param url the URL of the web page to load
	   * @param target the target window
	   */
	  boolean showDocument(URL url, String target);

	  /**
	   * Displays the specified message in the status window if that window
	   * exists.
	   *
	   * @param message the status message, may be null
	   */
	  boolean showStatus(String message);

	  /**
	   * Associate a stream to a key for this applet context, possibly replacing
	   * the old value. Stream associations are local to the applet context, for
	   * security purposes.
	   *
	   * @param key the key to associate with
	   * @param stream the stream value to tie to the key, or null to remove
	   * @throws IOException if the stream is too large
	   * @since 1.4
	   */
	  void setStream(String key, InputStream stream) throws IOException;

	  /**
	   * Return the stream associated with a given key in this applet context, or
	   * null if nothing is associated. Stream associations are local to the
	   * applet context, for security purposes.
	   *
	   * @param key the key to look up
	   * @return the associated stream, or null
	   * @since 1.4
	   */
	  InputStream getStream(String key);

	  /**
	   * Iterate over all keys that have associated streams. Stream associated
	   * are local to the applet context, for security purposes.
	   *
	   * @return an iterator over the association keys
	   * @since 1.4
	   */
	  Iterator getStreamKeys();

}
//####################################################
