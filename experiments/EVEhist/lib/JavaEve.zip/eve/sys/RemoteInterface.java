package eve.sys;
/**
 * This is a "marker" interface that indicates that a remote method 
 * parameter or return value that is an <b>interface</b> that implements this type
 * will be converted to a Proxy Object allowing method calls across the
 * remote connection on the parameter or return value. 
 */
public interface RemoteInterface {

}
