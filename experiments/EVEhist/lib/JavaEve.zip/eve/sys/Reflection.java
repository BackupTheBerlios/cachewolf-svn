package eve.sys;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Hashtable;
import java.util.Vector;

import eve.data.DataUnit;
import eve.data.DataUtils;
import eve.nativeaccess.NativeAccess;
import eve.util.CharArray;
import eve.util.Copyable;
import eve.util.SubString;
import eve.util.mClassLoader;

/**
This class provides a number of useful static methods that can simplify a
number of common tasks that use the Java Reflection API.
**/
//
// TODO add forName();
//
//TODO make isTypeOf() native.
//
//##################################################################
public class Reflection{
//##################################################################

//-------------------------------------------------------------------
private Reflection(){}
//-------------------------------------------------------------------
private static int hasWrapperMethods = -1;

//private static final ResourceCache cachedObjects = new ResourceCache();
/**
 * Cache an Object for later re-use.
 * @param obj the object to cache.
 */
/*
public static void cache(Object obj)
{
	Cache.put(obj);
}
*/
/**
 * Retrieve a cached Object for later re-use, requesting that a new one be
 * created using the default constructor.
 * @param type the type of the object to retrieve.
 * @return a cached or a new Object. This should never return null - it will throw
 * a RuntimeException if a new instance could not be created.
 */
/*
public static Object getCached(Class type)
{
	return Cache.get(type);
}
*/
/**
 * Retrieve a cached Object for later re-use, requesting that a new one be
 * created using the default constructor.
 * @param type the type of the object to retrieve.
 * @param makeNew true to request that a new one be created if one is not found.
 * @return a cached or a new Object if makeNew is true, or null if no new Object
 * was found and makeNew is false. If a makeNew is true but a new one could not
 * be created a RuntimeException is thrown.
 */
/*
public static Object getCached(Class type,boolean makeNew)
{
	return cachedObjects.getCached(cachedObjects,type,makeNew);
}
*/

static class MethodCache{

	Class[] parameterTypes;
	String name;
	Class src;
	
	MethodCache set(Class c, Method m)
	{
		src = c;
		parameterTypes = (Class[])m.getParameterTypes().clone();
		name = m.getName();
		return this;
	}
	MethodCache set(Class c, String nm, Class[] pt)
	{
		src = c;
		parameterTypes = pt;
		name = nm;
		return this;
	}
	public int hashCode()
	{
		return name.hashCode();
	}
	public boolean equals(Object other)
	{
		MethodCache mc = (MethodCache)other;
		if (!name.equals(mc.name)) return false;
		if (!src.equals(mc.src)) return false;
		if (parameterTypes.length != mc.parameterTypes.length) return false;
		for (int i = 0; i<parameterTypes.length; i++)
			if (!parameterTypes[i].equals(mc.parameterTypes[i]))
				return false;
		return true;
	}
}
private static Hashtable methodCache;
private static MethodCache search;

public static Object newProxyInstance(ClassLoader c, Class[] interfaces,InvocationHandler h)
{
	if (c != null) return Proxy.newProxyInstance(c,interfaces,h);
	try{
		return Proxy.newProxyInstance(interfaces[0].getClassLoader(),interfaces,h);
	}catch(Exception e){
	}
	Vector v = new Vector();
	mClassLoader.getClassLoaders(v);
	for (int i = 0; i<v.size(); i++){
		ClassLoader cl = (ClassLoader)v.get(i);
		try{
			return Proxy.newProxyInstance(cl,interfaces,h);
		}catch(Exception e){}
	}
	return Proxy.newProxyInstance(mClassLoader.getSystemClassLoader(),interfaces,h);
}
public static synchronized void cacheMethod(Class c, Method m)
{
	if (c == null) return;
	if (m == null) return;
	if (methodCache == null){
		methodCache = new Hashtable();
		search = new MethodCache();
	}
	Method cm = getCachedMethod(c,m.getName(),m.getParameterTypes());
	if (cm == m) return;
	MethodCache mc = new MethodCache().set(c,m);
	methodCache.put(mc,m);
}

public static synchronized Method getCachedMethod(Class c, String name, Class[] pars)
{
	if (c == null) return null;
	if (methodCache == null) return null;
	search.set(c,name,pars);
	return (Method)methodCache.get(search); 
}
public static synchronized void cacheMethod(Class c, String nameAndSpecs)
{
	if (c == null) return;
	Method m = getMethod(c,nameAndSpecs,false);
	if (m != null) cacheMethod(c,m);
}
/**
 * Get a copy of an Object from cached re-used objects if possible. This should
 * not be called on a Copyable object if that object uses special copying. This
 * method will create a new Object or reuse an old Object and then call 
 * copy(Object source, Object dest) on it - which may not be the proper way to copy.
 * @param obj the object to copy using a Cache if possible.
 * @return a copy of the object if possible.
 * @throws RuntimeException if it could not create a new version of the Object.
 */
public static Object getCachedCopy(Object obj)
{
	if (obj instanceof DataUnit){
		DataUnit du = (DataUnit)obj;
		Object cp = Cache.tryGet(obj.getClass());
		if (cp == null) cp = du.getNew();
		((DataUnit)cp).copyFrom(du);
		return cp;
	}
	Object cp = Cache.get(obj.getClass());
	copy(obj,cp);
	return cp;
}
//private static native void wrapperInvoke(Object target, Object methodOrConstructor, Wrapper[] parameters, Wrapper dest);
//private static native void wrapperGetSetField(Object target, Field field, Wrapper data, boolean isGet);

private static void checkHasWrapperMethods()
{
	try{
		NativeAccess.getSetVariable(Reflection.class,null,true);
		hasWrapperMethods = 1;
		//System.out.println("Has wrapper methods.");
		return;
	}catch(Throwable t){
		//t.printStackTrace(); 
		//System.out.println("Ok - No wrapper methods.");
	}
	hasWrapperMethods = 0;
}
//===================================================================
public static final String encodedStringClass = "Ljava/lang/String;";
/** A zero length Class array. **/
public static final Class[] emptyClasses = new Class[0];
/** A zero length Object array. **/
public static final Object[] emptyParameters = new Object[0];
//===================================================================

/**
Get all the public fields for the data object, using the "_fields" variables for
the object if present. This method makes use of eve.data.DataObject.getCachedFieldList().
@param dataObject The dataObject to get the fields for.
@return all the public fields for the data object, using the "_fields" variables for
the object if present.
*/

//===================================================================
public static Field [] fieldsFor(Object dataObject)
//===================================================================
{
	Class c = dataObject.getClass();
	return DataUtils.getCachedFieldList(c,dataObject,false);
}

/**
 * Construct a new Object using Eve Wrapper values. This is useful for large number
 * of invocations, because Eve Wrappers are re-usable - unlike Java Wrappers which 
 * are immutable.
 * @param c The Constructor to use.
 * @param parameters the parameters as an array of Wrapper values.
 * @return the created Object.
 * @throws IllegalAccessException
 * @throws IllegalArgumentException
 * @throws InvocationTargetException
 * @throws InstantiationException
 */
public static Object newInstance(Constructor c, Wrapper[] parameters)
throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException
{
	if (parameters == null) parameters = Wrapper.noParameter;
	if (hasWrapperMethods == -1) checkHasWrapperMethods();
	if (hasWrapperMethods == 0){
		//Must use Java methods.
		return c.newInstance(Wrapper.toJavaWrappers(parameters));
	}
	eve.reflect.Constructor ec = (eve.reflect.Constructor)NativeAccess.getSetVariable(c,null,true);
	return ec.newInstance(parameters);
}

/**
 * Invoke a method using Eve Wrapper values. This is useful for large number
 * of invocations, because Eve Wrappers are re-usable - unlike Java Wrappers which 
 * are immutable.
 * @param target the target Object. This can be null for static methods.
 * @param method the Method to invoke.
 * @param parameters the parameters as Wrapper values.
 * @param result a Wrapper to hold the destination.
 * @throws IllegalAccessException
 * @throws IllegalArgumentException
 * @throws InvocationTargetException
 */
public static void invoke(Object target, Method method, Wrapper[] parameters, Wrapper result)
throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
{
	if (parameters == null) parameters = Wrapper.noParameter;
	if (result == null) result = new Wrapper();
	if (hasWrapperMethods == -1) checkHasWrapperMethods();
	if (hasWrapperMethods == 0){
		//Must use Java methods.
		try{
			result.fromJavaWrapper(method.invoke(target,Wrapper.toJavaWrappers(parameters)),method.getReturnType());
		return;
		}catch(RuntimeException re){
			throw re;
		}catch(IllegalAccessException ia){
			//System.out.println("Bad call of: "+method+" on: "+target.getClass());
			//System.out.println("Bad call of: "+method+" on: "+target.getClass().getSuperclass());
			throw ia;
		}
	}
	eve.reflect.Method em = (eve.reflect.Method)NativeAccess.getSetVariable(method,null,true);
	em.invoke(target,parameters,result);
}
/**
This method invokes the method in the background returning a Handle used to monitor
the running task.
@param targetOrClass The target object or a Class object if the target method
is static. 
@param nameAndParametersAndType the fully encoded name and type of the method: e.g. 
invokeMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;Z)Leve/sys/Wrapper;
@param parameters the parameters to be sent to the method. Leave the parameter which
is supposed to be a provided Handle as null and a new Handle will be created and
provided. 
@return a Handle to the task which is executing the Method.
*/
public static Handle invokeAsync(Object targetOrClass, String nameAndParametersAndType, Object[] parameters)
{
	return new AsyncTask().invoke(targetOrClass,nameAndParametersAndType, parameters);
}
/**
This method invokes the method in the background returning a Handle used to monitor
the running task.
@param targetOrClass The target object or a Class object if the target method
is static. 
@param nameAndParametersAndType the fully encoded name and type of the method: e.g. 
invokeMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;Z)Leve/sys/Wrapper;
@param parameters the parameters to be sent to the method. Leave the parameter which
is supposed to be a provided Handle as null and a new Handle will be created and
provided. 
@return a Handle to the task which is executing the Method.
*/
public static Handle invokeAsync(Object target, Method method, Object[] parameters)
{
	return new AsyncTask().setMethod(method).invoke(target,parameters);
}
/**
 * Get a field value using a eve.sys.Wrapper instead of a standard Java wrapper.
 * @param target the target Object.
 * @param field the Field to get.
 * @param destination the Wrapper that will hold the data read in.
 * @return the destination or a new Wrapper if the destination was null.
 * @throws IllegalAccessException
 * @throws IllegalArgumentException
 */
public static Wrapper getFieldValue(Object target, Field field, Wrapper destination)
throws IllegalAccessException, IllegalArgumentException
{
	if (destination == null) destination = new Wrapper();
	if (hasWrapperMethods == -1) checkHasWrapperMethods();
	if (hasWrapperMethods == 0){
		//Must use Java methods.
		destination.fromJavaWrapper(field.get(target),field.getType());
		return destination;
	}
	eve.reflect.Field ef = (eve.reflect.Field)NativeAccess.getSetVariable(field,null,true);
	ef.getValue(target,destination);
	return destination;
}
/**
 * Set a field value using a eve.sys.Wrapper instead of a standard Java wrapper.
 * @param target the target Object.
 * @param field the Field to set.
 * @param data the Wrapper containing the data to be set.
 * @throws IllegalAccessException
 */
public static void setFieldValue(Object target, Field field, Wrapper data)
throws IllegalAccessException, IllegalArgumentException
{
	if (data == null) throw new NullPointerException();
	if (hasWrapperMethods == -1) checkHasWrapperMethods();
	if (hasWrapperMethods == 0){
		//Must use Java methods.
		field.set(target,data.toJavaWrapper());
		return;
	}
	eve.reflect.Field ef = (eve.reflect.Field)NativeAccess.getSetVariable(field,null,true);
	ef.setValue(target,data);
}
/**
Create a new instance of an object, but do not throw an exception on failure,
return null instead.
@param c The class to create the new instance of.
@param parameterSpecs The java encoded parameter list for the constructor (e.g. "[BII").
@param parameters the list of parameters using standard Java wrappers or you can use eve.sys.Wrapper objects.
If you use eve.sys.Wrapper objects, the array must be of the type Wrapper[].
@return The new Object if successful or null if not.
*/
//===================================================================
public static Object newInstance(Class c,String parameterSpecs,Object[] parameters)
//===================================================================
{
	if (parameters == null) parameters = emptyParameters;
	Constructor cs = parameterSpecs != null ? getConstructor(c,parameterSpecs) : getDefaultConstructor(c);
	if (cs == null) return null;
	try{
		if (parameters instanceof Wrapper[] || parameters == null) return newInstance(cs,(Wrapper[])parameters);
		else return cs.newInstance(parameters);
	}catch(Exception e){
		return null;
	}
}
/**
Create a new instance of an object, but do not throw an exception on failure,
return null instead.
@param c The class to create the new instance of.
@param parameterSpecs The java encoded parameter list for the constructor (e.g. "[BII").
@param parameters The parameters for the constructor in an array.
@return The new Object if successful or null if not.
*/
/*
//===================================================================
public static Object newInstance(Class c,String parameterSpecs,Wrapper[] parameters)
//===================================================================
{
	if (parameters == null) parameters = Wrapper.noParameter;
	if (hasWrapperMethods == -1) checkHasWrapperMethods();
	if (hasWrapperMethods == 0){
		//Must use Java methods.
		
	}
	Constructor cs = parameterSpecs != null ? getConstructor(c,parameterSpecs) : getDefaultConstructor(c);
	if (cs == null) return null;
	try{
		return cs.newInstance(parameters);
	}catch(Exception e){
		return null;
	}
}
*/
/**
Create a new instance of an object, but do not throw an exception on failure,
return null instead.
@param c The class to create the new instance of.
@return The new Object if successful or null if not.
*/
//===================================================================
public static Object newInstance(Class c)
//===================================================================
{
	try{
		return c.newInstance();
	}catch(Exception e){
		return null;
	}
	//return newInstance(c,null,null);
}

/**
 * Attempt to get a class using all possible class loaders.
 * @param name The class name. This can be a Java encoded name or a non-encoded
 * name, and can specify an array, but it must not be a primitive value. For primitive
 * values use Reflection.forEncodedName()
 * @return a Class or null if it is not found.
 */
//===================================================================
public static Class forName(String name)
//===================================================================
{
	/*
	if (hasWrapperMethods == -1) checkHasWrapperMethods();
	if (hasWrapperMethods == 0)
		try{
			return Class.forName(name);
		}catch(ClassNotFoundException e){
		}
	else{ 
		Class ret = NativeAccess.systemForName(name);
		if (ret != null) return ret;
	}
	*/
	try{
		return Type.loadForName(name);
	}catch(ClassNotFoundException e){
		return null;
	}
}
/**
 * Attempt to get a class using the system class loader and the class loader
 * of the requestor class.
 * @param name The class name. This can be a Java encoded name or a non-encoded
 * name, and can specify an array, but it must not be a primitive value. For primitive
 * values use Reflection.forEncodedName().
 * @param requestor The requesting class.
 * @return a Class or null if it is not found.
 */
//===================================================================
public static Class forName(String name,Class requestor)
//===================================================================
{
	try{
		return Type.forName(name,requestor);
	}catch(ClassNotFoundException e2){
		return null;
	}
}

/**
Convert a Java encoded type into a Class representing the type.
 * @param name the Java encoded type name.
 * @return a Class representing the name or null if the class was not found.
 */
//===================================================================
public static Class forEncodedName(String name)
//===================================================================
{
	switch(name.charAt(0)){
		case 'V': return Void.TYPE;
		case 'Z': return Boolean.TYPE;
		case 'B': return Byte.TYPE;
		case 'C': return Character.TYPE;
		case 'S': return Short.TYPE;
		case 'I': return Integer.TYPE;
		case 'J': return Long.TYPE;
		case 'F': return Float.TYPE;
		case 'D': return Double.TYPE;
		case '[': return forName(name.replace('/','.'));
		case 'L': return forName(name.substring(1,name.length()-1).replace('/','.'));
		default: return null;
	}
}
/**
 * Convert a Java type represented by the Class as the first letter of the java encoded type of the class.
 * @param type The class to represent as an encoded type.
 * @return the first letter of the java encoded type of the class. These are the same
 * values as the Wrapper data types (e.g. Wrapper.INT which is the same as 'I').
 */
//===================================================================
public static char getEncodedType(Class type)
//===================================================================
{
	if (type.isPrimitive()){
		if (type == Void.TYPE) return 'V';
		else if (type == Boolean.TYPE) return 'Z';
		else if (type == Byte.TYPE) return 'B';
		else if (type == Character.TYPE) return 'C';
		else if (type == Short.TYPE) return 'S';
		else if (type == Integer.TYPE) return 'I';
		else if (type == Long.TYPE) return 'J';
		else if (type == Float.TYPE) return 'F';
		else if (type == Double.TYPE) return 'D';
		else throw new IllegalArgumentException();
	}else if (type.isArray()) return '[';
	else return 'L';
}
/**
 * Exactly the same as getEncodedType(). Converts a Java type represented by the Class as the first letter of the java encoded type of the class.
 * @param type The class to represent as an encoded type.
 * @return the first letter of the java encoded type of the class. These are the same
 * values as the Wrapper data types (e.g. Wrapper.INT which is the same as 'I').
 */
public static char getWrapperType(Class type)
{
	return getEncodedType(type);
}
/**
 * Convert a Java type represented by the Class as a java encoded type string.
 * @param type The class to represent as an encoded type.
 * @param destination a destination StringBuffer to append the type to.
 * @return  the destination StringBuffer or a new one if it is null.
 */
public static StringBuffer getEncodedName(Class type, StringBuffer destination)
{
	if (destination == null) destination = new StringBuffer();
	if (type == Void.TYPE || type == null) destination.append('V'); 
	else if (type == Boolean.TYPE) destination.append('Z'); 
	else if (type == Byte.TYPE) destination.append('B'); 
	else if (type == Character.TYPE) destination.append('C'); 
	else if (type == Short.TYPE) destination.append('S'); 
	else if (type == Integer.TYPE) destination.append('I'); 
	else if (type == Long.TYPE) destination.append('J');
	else if (type == Float.TYPE) destination.append('F');
	else if (type == Double.TYPE) destination.append('D');
	else if (type.isArray())
		destination.append(type.getName().replace('.','/'));
	else{
		destination.append('L');
		destination.append(type.getName().replace('.','/'));
		destination.append(';');
	}
	return destination;
}
/**
 * Convert a Java type represented by the Class as a java encoded type string.
 * @param type The class to represent as an encoded type.
 * @return  a java encoded type string.
 */
//===================================================================
public static String getEncodedName(Class type)
//===================================================================
{
	return getEncodedName(type,new StringBuffer()).toString();
}
/**
 * This returns an encoded class name, but <b>without</b> the leading 'L' and
 * trailing ';' unless the class is an array of objects, in which case the 'L'
 * and ';' are left in the component specifier.
 * <p>
 * This will only work for arrays and classes - not primitive values. 
 * @param type the Class to get the encoded name of.
 * @return the encoded name without a leading 'L' or trailing ';'
 * @throws IllegalArgumentException if the type is primitive.
 */
public static String getEncodedClassNameOnly(Class type) throws IllegalArgumentException
{
	if (type.isPrimitive()) throw new IllegalArgumentException();
	return type.getName().replace('.','/');
}
/**
Given a Class, find the superclass which ends with targetName.
 * @param actualClass the Class to search for.
 * @param targetName the target class name.
 * @return the Class found or null if not found.
 */
//===================================================================
public static Class getBaseClass(Class actualClass,String targetName)
//===================================================================
{
	for (Class c = actualClass; c != null; c = c.getSuperclass()){
		String n = c.getName();
		//Vm.debug("Name: "+n+", Target: "+targetName);
		if (!n.endsWith(targetName)) continue;
		int before = n.length()-targetName.length()-1;
		if (before < 0) return c;
		char ch = n.charAt(before);
		if (ch == '$' || ch == '.') return c;
	}
	return null;
}
public static StringBuffer getEncodedParameters(Class[] parameters, boolean encloseInBrackets, StringBuffer b)
{
	if (b == null) b = new StringBuffer();
	if (encloseInBrackets) b.append('(');
	if (parameters != null)
		for (int i = 0; i<parameters.length; i++)
			getEncodedName(parameters[i],b);
	if (encloseInBrackets) b.append(')');
	return b;
}
/**
 * Create a Java encoded parameter list from a list of Class types.
 * @param parameters the parameter list as an array of Classes.
 * @param encloseInBrackets true to place '(' around the list.
 * @return the Java encoded parameter list.
 */
public static String getEncodedParameters(Class[] parameters,boolean encloseInBrackets)
{
	return getEncodedParameters(parameters,encloseInBrackets,new StringBuffer()).toString();
}
public static StringBuffer getEncodedMethod(String name,Class[] parameters,Class returnType,StringBuffer dest)
{
	StringBuffer b = dest;
	if (b == null) b = new StringBuffer();
	if (name != null) b.append(name);
	getEncodedParameters(parameters,true,b);
	getEncodedName(returnType,b);
	return b;
}
public static String getEncodedMethod(String name,Class[] parameters,Class returnType)
{
	return getEncodedMethod(name,parameters,returnType,new StringBuffer()).toString();
}
/**
 * Convert a Method into a Java encoded method.
 * @param m the Method to convert.
 * @return a Java encoded method String.
 */
public static String getEncodedMethod(Method m)
{
	return getEncodedMethod(m.getName(),m.getParameterTypes(),m.getReturnType());
}
/*
//===================================================================
public static Class encodedTypeToClass()
//===================================================================
*/
/**
Convert an encoded paramter list into an array of chars representing the
parameter types as encoded types.
 * @param encodedTypes a list of parameter types which may or may not be enclosed in "()" brackets.
 * @return An array of chars representing the
parameter types as encoded types.
 */
//===================================================================
public static char[] getParameterTypesAsEncodedType(String encodedTypes)
//===================================================================
{
	SubString ss = ((SubString)Cache.get(SubString.class)).set(encodedTypes);
	try{
		return getParameterTypesAsEncodedType(ss);
	}finally{
		Cache.put(ss);
	}
}
//===================================================================
public static char[] getParameterTypesAsEncodedType(SubString encodedTypes)
//===================================================================
{
	CharArray buff = (CharArray)Cache.get(CharArray.class);
	buff.clear();
	char[] got = encodedTypes.data;
	int e = encodedTypes.indexOf('(');
	if (e == -1) e = 0;
	e += encodedTypes.start;
	if (got[e] == '(') e++;
	int max = encodedTypes.length+encodedTypes.start;
	while(e < max && got[e] != ')'){
		if (got[e] == '['){
			while(got[e] == '[') e++;
			if (got[e] == 'L') 
				while(got[e] != ';') e++;
			buff.append('[');
		}else if (got[e] == 'L'){
			while(got[e] != ';') e++;
			buff.append('L');
		}else
			buff.append(got[e]);
		e++;
	}
	char[] ret = buff.toChars();
	Cache.put(buff);
	return ret;
}

/**
Convert an encoded paramter list into an array of Classes representing the
parameter types.
 * @param encodedTypes a list of parameter types which may or may not be enclosed in "()" brackets.
 * @return An array of Class objects representing the types or null if any type is not found.
 */
//===================================================================
public static Class[] getParameterTypes(String encodedTypes)
//===================================================================
{
	if (encodedTypes == null || encodedTypes.length() == 0)
		return emptyClasses;
	Vector v = null;
	char[] got = Vm.getStringChars(encodedTypes);
	int s = encodedTypes.indexOf('(');
	if (s == -1) s = 0;
	if (got[s] == '(') s++;
	int e = s;
	while(e < got.length && got[e] != ')'){
		if (got[e] == '['){
			while(got[e] == '[') e++;
			if (got[e] == 'L') 
				while(got[e] != ';') e++;
		}else if (got[e] == 'L'){
			while(got[e] != ';') e++;
		}
		e++;
		Class c = forEncodedName(new String(got,s,e-s));
		if (c == null) return null;
		if (v == null) {
			v = (Vector)Cache.get(Vector.class);
			v.removeAllElements();
		}
		v.add(c);
		s = e;
	}
	if (v == null) return emptyClasses;
	else{
		Class[] ret = new Class[v.size()];
		v.copyInto(ret);
		Cache.put(v);
		return ret;
	}
}
/**
	Get the return or field type as a class.
 * @param encodedParameterSpecsOrType either a single encoded type or parameters in brackets
	 followed by a single encoded type.
 * @return a Class representing the field or return type.
 */
//===================================================================
public static Class getReturnOrFieldType(String encodedParameterSpecsOrType)
//===================================================================
{
	int idx = encodedParameterSpecsOrType.lastIndexOf(')');
	if (idx == -1) idx = encodedParameterSpecsOrType.lastIndexOf(':');
	if (idx != -1) encodedParameterSpecsOrType = encodedParameterSpecsOrType.substring(idx+1);
	if (encodedParameterSpecsOrType.length() == 0) return null;
	return forEncodedName(encodedParameterSpecsOrType);
}

/**
This will find and invoke a method on an object or a static method on a class.
@param cl The class of the Object.
@param target The target Object, which may be null for static methods.
@param nameAndParametersAndType the fully encoded name and type of the method: e.g. 
invokeMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;Z)Leve/sys/Wrapper;
@param parameters the list of parameters using standard Java wrappers or you can use eve.sys.Wrapper objects,
but the array must be of the type Wrapper[].
@param declaredOnly set true if you are looking for methods declared by that Class.
@return if unsuccessful for any reason this returns null otherwise a Wrapper containing the
returned value is returned, or if the method is a void method, a Wrapper with type Wrapper.VOID
is returned.
@return 
*/
//===================================================================
public static Wrapper invokeMethod(Class cl, Object target, String nameAndParametersAndType, Object[] parameters, boolean declaredOnly, Wrapper dest)
//===================================================================
{
	if (dest == null) dest = new Wrapper();
	try{
		if (parameters == null) parameters = emptyParameters;
		if (parameters instanceof Wrapper[]){
			Object[] tp = new Object[parameters.length];
			for (int i = 0; i<tp.length; i++){
				Wrapper w = (Wrapper)parameters[i];
				tp[i] = w == null ? null : w.toJavaWrapper();
			}
			parameters = tp;
		}
		Method got = getMethod(cl,nameAndParametersAndType,declaredOnly);
		if (got == null) return null;
		Object ret = got.invoke(target,parameters);
		return dest.fromJavaWrapper(ret,got.getReturnType());
	}catch(Exception e){
		return null;
	}
}
/**
This will find and invoke a method on an object or a static method on a class.
@param objectOrClass for a static method this should be a Class object, for an instance method
it should be an instance of the class.
@param nameAndParametersAndType the fully encoded name and type of the method: e.g. 
invokeMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;Z)Leve/sys/Wrapper;
@param parameters the list of parameters using standard Java wrappers or you can use eve.sys.Wrapper objects,
but the array must be of the type Wrapper[].
@return if unsuccessful for any reason this returns null otherwise a Wrapper containing the
returned value is returned, or if the method is a void method, a Wrapper with type Wrapper.VOID
is returned.
*/
//===================================================================
public static Wrapper invokeMethod(Object objectOrClass, String nameAndParametersAndType, Object[] parameters)
//===================================================================
{
	return invokeMethod(toClass(objectOrClass),toObject(objectOrClass),nameAndParametersAndType,parameters,false,null);
}
/**
 * Find a Class method and optionally confirm the return type.
 * @param c The Class to look in.
 * @param name the name of the method.
 * @param parameters The parameter list of the method.
 * @param returnType The optional return type. If it is null the return type is not checked.
 * @param declaredOnly set true if you are looking for methods declared by that Class.
 * @return the matching method or null if none was found.
 */
//===================================================================
public static Method getMethod(Class c,String name,Class[] parameters,Class returnType,boolean declaredOnly)
//===================================================================
{
	try{
		Method m = declaredOnly ? c.getDeclaredMethod(name,parameters) : c.getMethod(name,parameters);
		if (returnType == null) return m;
		if (!m.getReturnType().equals(returnType)) return null;
		return m;
	}catch(Exception e){
		return null;
	}
}
/**
 * Find a Class method and optionally confirm the return type.
 * @param c The Class to look in.
 * @param name the name of the method.
 * @param parametersAndReturnType The parameter list and optional return type of the method as a Java encoded string.
 * @param declaredOnly set true if you are looking for methods declared by that Class.
 * @return the matching method or null if none was found.
 */
//===================================================================
public static Method getMethod(Class c,String name,String parametersAndReturnType,boolean declaredOnly)
//===================================================================
{
	Class[] parameters = getParameterTypes(parametersAndReturnType);
	Class returnType = getReturnOrFieldType(parametersAndReturnType);
	return getMethod(c,name,parameters,returnType,declaredOnly);
}
/**
 * Find a Class method and optionally confirm the return type.
 * @param c The Class to look in.
 * @param nameAndParametersAndReturnType The name and parameter list and optional return type of the method as a Java encoded string.
 * @param declaredOnly set true if you are looking for methods declared by that Class.
 * @return the matching method or null if none was found.
 */
//===================================================================
public static Method getMethod(Class c,String nameAndParametersAndReturnType,boolean declaredOnly)
//===================================================================
{
	int idx = nameAndParametersAndReturnType.indexOf('(');
	if (idx == -1) return null;
	String name = nameAndParametersAndReturnType.substring(0,idx);
	String parametersAndReturnType = nameAndParametersAndReturnType.substring(idx);
	Class[] parameters = getParameterTypes(parametersAndReturnType);
	Class returnType = getReturnOrFieldType(parametersAndReturnType);
	return getMethod(c,name,parameters,returnType,declaredOnly);
}
/**
 * This is used in InvocationHandler objects to handle standard Object
 * methods. This applies default behavior to those methods.
 * @param proxy  the proxy being used.
 * @param method the method being called.
 * @param parameters the parameters for the method call.
 * @return if it is an Object method, then a Wrapper that can be re-converted
 * to a Java wrapper using toJavaWrapper(). Otherwise, if it is not an Object
 * method, null is returned.
 */
public static Wrapper handleProxyObjectMethod(Object proxy, Method method, Object[] parameters) throws Throwable
{
	if (!method.getDeclaringClass().equals(Object.class)) return null;
	String nm = method.getName();
	if (nm.equals("hashCode")){
		return new Wrapper().setInt(System.identityHashCode(proxy));
	}else if (nm.equals("equals")){
		return new Wrapper().setBoolean(proxy == parameters[0]);
	}else if (nm.equals("toString")){
		return new Wrapper().setObject(""+System.identityHashCode(proxy)); 
	}else if (nm.equals("clone")){
		throw new CloneNotSupportedException();
	}else{
		return new Wrapper().setType(Wrapper.VOID);
	}
}
/**
 * Find a Class constructor.
 * @param c The Class to look in.
 * @return the matching Constructor or null if none was found.
 */
//===================================================================
public static Constructor getDefaultConstructor(Class c)
//===================================================================
{
	return getConstructor(c,emptyClasses);
}
/**
 * Find a Class constructor.
 * @param c The Class to look in.
 * @param parameters The parameter list of the constructor.
 * @return the matching Constructor or null if none was found.
 */
//===================================================================
public static Constructor getConstructor(Class c,Class[] parameters)
//===================================================================
{
	try{
		return c.getConstructor(parameters);
	}catch(Exception e){
		return null;
	}
}
/**
 * Find a Class constructor.
 * @param c The Class to look in.
 * @param parameters The parameter list of the constructor as a Java Type Encoded String - with
 * or without the brackets - i.e. "BII" or "(BII)".
 * @return the matching Constructor or null if none was found.
 */
//===================================================================
public static Constructor getConstructor(Class c,String parameters)
//===================================================================
{
	Class[] pars = getParameterTypes(parameters);
	return getConstructor(c,pars);
}
/**
Get a class Field and optionally verify its type.
 * @param c The class to search for the field.
 * @param name the name of the field.
 * @param type the optional type of the field. If it is null the type of the field will not
	 be verified.
 * @param declaredOnly set true if you are looking for fields declared by that Class.
 * @return the Field found or null if not found.
 */
//===================================================================
public static Field getField(Class c,String name,Class type,boolean declaredOnly)
//===================================================================
{
	try{
		Field f = declaredOnly ? c.getDeclaredField(name) : c.getField(name);
		if (type == null) return f;
		if (!f.getType().equals(type)) return null;
		return f;
	}catch(Exception e){
		return null;
	}
}
/**
Get a class Field and optionally verify its type.
 * @param c The class to search for the field.
 * @param name the name of the field.
 * @param type the optional type of the field in Java type encoded format. 
 	If the type of the field is '$' it is assumed to mean java.lang.String.
	If it is null the type of the field will not be verified.
 * @param declaredOnly set true if you are looking for fields declared by that Class.
 * @return the Field found or null if not found.
 */
//===================================================================
public static Field getField(Class c,String name,String type,boolean declaredOnly)
//===================================================================
{
	if (type != null && type.equals("$")) type = encodedStringClass;
	return getField(c,name,type == null ? null : forEncodedName(type),declaredOnly);
}
/**
Get a class Field and optionally verify its type.
 * @param c The class to search for the field.
 * @param nameAndType the name of the field optionally followed by a ':' and the type of the field.
 If the type of the field is '$' it is assumed to mean java.lang.String. If no ':' and
field type is present the type of the field will not be verified.
 * @param declaredOnly set true if you are looking for fields declared by that Class.
 * @return the Field found or null if not found.
 */
//===================================================================
public static Field getField(Class c,String nameAndType,boolean declaredOnly)
//===================================================================
{
	int idx = nameAndType.indexOf(':');
	String name = idx == -1 ? nameAndType : nameAndType.substring(0,idx);
	String type = idx == -1 ? null : nameAndType.substring(idx+1);
	return getField(c,name,type == null ? null : forEncodedName(type),declaredOnly);
}
/**
Get a field value.
@param cl The class to get the field value from.
@param target The target object to get the field value from, which can be null for static fields.
@param fieldNameAndType the name of the field optionally followed by a ':' and the type of the field.
If the type of the field is '$' it is assumed to mean java.lang.String. If no ':' and
field type is present the type of the field will not be verified.
@param declaredOnly set true if you are looking for fields declared by that Class.
@return the field value stored in a Wrapper object, or null if the method fails for any reason.
*/
//===================================================================
public static Wrapper getFieldValue(Class cl, Object target, String fieldNameAndType, boolean declaredOnly)
//===================================================================
{
	try{
		Field f = getField(cl,fieldNameAndType,declaredOnly);
		if (f == null) return null;
		Object got = f.get(target);
		return new Wrapper().fromJavaWrapper(got,f.getType());
	}catch(Exception e){
		return null;
	}
}
/**
Get a field value.
@param objectOrClass for a static field this should be a Class object, for an instance field
it should be an instance of the class.
@param fieldNameAndType the name of the field optionally followed by a ':' and the type of the field.
If the type of the field is '$' it is assumed to mean java.lang.String. If no ':' and
field type is present the type of the field will not be verified.
@param declaredOnly set true if you are looking for fields declared by that Class.
@return the field value stored in a Wrapper object, or null if the method fails for any reason.
*/
//===================================================================
public static Wrapper getFieldValue(Object classOrObject, String fieldNameAndType)
//===================================================================
{
	return getFieldValue(toClass(classOrObject),toObject(classOrObject),fieldNameAndType,false);
}
/**
Set a field value.
@param cl The class to set the field value.
@param target The target object to set the field value, which can be null for static fields.
@param fieldNameAndType the name of the field optionally followed by a ':' and the type of the field.
If the type of the field is '$' it is assumed to mean java.lang.String. If no ':' and
field type is present the type of the field will not be verified.
@param declaredOnly set true if you are looking for fields declared by that Class.
@param value the value to set as a Java Wrapper object or an eve.sys.Wrapper object.
@return true on success, false if the method fails for any reason.
*/
//===================================================================
public static boolean setFieldValue(Class cl, Object target, String fieldNameAndType, boolean declaredOnly, Object value)
//===================================================================
{
	try{
		Field f = getField(cl,fieldNameAndType,declaredOnly);
		if (f == null) return false;
		Object toSet = value instanceof Wrapper ? ((Wrapper)value).toJavaWrapper() : value;
		f.set(target,toSet);
		return true;
	}catch(Exception e){
		return false;
	}
}
/**
Set a field value.
@param objectOrClass for a static field this should be a Class object, for an instance field
it should be an instance of the class.
@param fieldNameAndType the name of the field optionally followed by a ':' and the type of the field.
If the type of the field is '$' it is assumed to mean java.lang.String. If no ':' and
field type is present the type of the field will not be verified.
@param value the value to set as a Java Wrapper object or an eve.sys.Wrapper object.
@return true on success, false if the method fails for any reason.
*/
//===================================================================
public static boolean setFieldValue(Object classOrObject, String fieldNameAndType, Object value)
//===================================================================
{
	return setFieldValue(toClass(classOrObject),toObject(classOrObject),fieldNameAndType,false,value);
}
//public static 
/**
Create a zero value Java wrapper object.
@param type the Class representing the type of the data.
@return a zero value Java wrapper object. 
*/
//===================================================================
public static Object createZeroValue(Class type)
//===================================================================
{
	Object value = null;
	if (type.isPrimitive()){
		if (type == Boolean.TYPE) value = Boolean.FALSE;
		else if (type == Byte.TYPE) value = new Byte((byte)0);
		else if (type == Character.TYPE) value = new Character((char)0);
		else if (type == Short.TYPE) value = new Short((short)0);
		else if (type == Integer.TYPE) value = new Integer(0);
		else if (type == Long.TYPE) value = new Long(0);
		else if (type == Float.TYPE) value = new Float(0);
		else if (type == Double.TYPE) value = new Double(0);
	}
	return value;
}
/**
See if the Class c is of the type aType. This simply calls aType.isAssignableFrom(c);
@param c The class to check.
@param aType the type.
@return true if c is of the specified type, false if not.
*/
//===================================================================
public static boolean isTypeOf(Class c, Class aType) 
//===================================================================
{
	if (aType == null) return false; 
	return aType.isAssignableFrom(c);
}
/**
Check if a Class is of the type aType, where aType is a Java encoded name.
@param c The class to check.
@param aType the Java encoded name of a type. 
@return true if c is of the specified type, false if not.
*/
//===================================================================
public static boolean isTypeOf(Class c, String aType)
//===================================================================
{
	Class at = forEncodedName(aType);
	if (at == null) return false;
	return isTypeOf(c,at);
}
/**
Check if a Class is of the type aType, where aType is a Java encoded name.
@param c The class to check.
@param aType the Java encoded name of a type. 
@return true if c is of the specified type, false if not.
*/
//===================================================================
public static boolean isTypeOf(String c,String aType)
//===================================================================
{
	if (c.length() == 1){
		if (aType.length() == 1) return c.charAt(0) == aType.charAt(0);
		return false;
	}
	Class cc = forEncodedName(c);
	if (c == null) return false;
	return isTypeOf(c,aType);
}
/**
* This copies one field from the source object to the destination object using the
* provided Reflect Object as the class specifier. If the 
* field value being copied implements the Copyable interface, then getCopy() is called
* on the Object and the copy is assigned to the destination field. Otherwise the destination
* field is made equal to the source field.
* <p>
* In order for this to work the Class AND the Field must be public.
* @param field The field name.
* @param source The source object.
* @param dest The destination object.
* @param theClass A Class object representing the exact class which is having its field copied.
@param buffer an optional Wrapper that can be used as a buffer for the field transfer.
@return true if the copy was successful, false if not.
*/
//===================================================================
public static boolean copyField(String field,Object source,Object dest,Class theClass)
//===================================================================
{
	return copyField(field,source,dest,theClass,null);
}
/**
* This copies one field from the source object to the destination object using the
* provided Reflect Object as the class specifier. If the 
* field value being copied implements the Copyable interface, then getCopy() is called
* on the Object and the copy is assigned to the destination field. Otherwise the destination
* field is made equal to the source field.
* <p>
* In order for this to work the Class AND the Field must be public.
* @param field The field name.
* @param source The source object.
* @param dest The destination object.
* @param theClass A Class object representing the exact class which is having its field copied.
@param buffer an optional Wrapper that can be used as a buffer for the field transfer.
@return true if the copy was successful, false if not.
*/
//===================================================================
public static boolean copyField(Field f,Object source,Object dest,Class theClass,Wrapper buffer)
//===================================================================
{
	try{
		if (buffer == null) buffer = new Wrapper();
		if (!buffer.getFromField(f,source)) return false;
		if (buffer.getType() == buffer.OBJECT){
			Object got = buffer.getObject();
			if (got instanceof Copyable) {
				Object obj = ((Copyable)got).getCopy();
				buffer.setObject(obj);
			}
		}
		return buffer.putInField(f,dest);
	}catch(Throwable e){
		return false;
	}
}

/**
* This copies one field from the source object to the destination object using the
* provided Reflect Object as the class specifier. If the 
* field value being copied implements the Copyable interface, then getCopy() is called
* on the Object and the copy is assigned to the destination field. Otherwise the destination
* field is made equal to the source field.
* <p>
* In order for this to work the Class AND the Field must be public.
* @param field The field name.
* @param source The source object.
* @param dest The destination object.
* @param theClass A Class object representing the exact class which is having its field copied.
@param buffer an optional Wrapper that can be used as a buffer for the field transfer.
@return true if the copy was successful, false if not.
*/
//===================================================================
public static boolean copyField(String field,Object source,Object dest,Class theClass,Wrapper buffer)
//===================================================================
{
	try{
		return copyField(theClass.getDeclaredField(field),source,dest,theClass,buffer);
	}catch(Exception e){
		return false;
	}
}

/**
* This copies data from the source to the destination. Copying is done as
* follows. The class of the source is determined using the Reflection API. If 
* that class DECLARES a "_fields" String variable (which must be public to
* work under Java) then a copyField() is done on each of the fields listed in
* the "_fields" variable. If no "_fields" variable is declared, all public fields
* will be copied. The value of this variable should be a comma separated
* list of fields. This process is repeated for each successive superclass of
* the source object.
**/
//===================================================================
public static boolean copy(Object source,Object dest)
//===================================================================
{
	if (source == null || dest == null) return false;
	Wrapper w = Wrapper.getCached(); try{
		for (Class r = source.getClass(); r != null; r = r.getSuperclass()){
			Field[] fs = DataUtils.getCachedFieldList(r,source,true);
			for (int i = 0; i<fs.length; i++)
				if (!copyField(fs[i],source,dest,r,w))
					;//System.out.println("CF failed!");
		}
	}finally{
		w.cache();
	}
	/*
	Vector fields = new Vector();
	for (Class r = source.getClass(); r != null; r = r.getSuperclass()){
		String s = DataUtils.getFieldList(r,source,true);
		if (s.length() == 0) continue;
		fields.clear();
		mString.split(s,',',fields);
		int l = fields.size();
		for (int i = 0; i<l; i++)
			copyField((String)fields.get(i),source,dest,r,w);
	}
	*/
	return true;
}

/**
A number of methods take either a Class specifying a type or an example object of the
type as a parameter. If the sampleObjectOrClass is a Class it will return that, otherwise
it will call getClass() on it and return that (if it is not null).
@param sampleObjectOrClass The Class of a type of an example object of the type.
@return The Class of the type.
*/
//===================================================================
public static Class toClass(Object sampleObjectOrClass)
//===================================================================
{
	if (sampleObjectOrClass instanceof Class) return (Class)sampleObjectOrClass;
	if (sampleObjectOrClass == null) return null;
	return sampleObjectOrClass.getClass();
}
/**
A number of methods take either a Class specifying a type or an example object of the
type as a parameter. If the sampleObjectOrClass is a Class it will return null, otherwise
it will return the sampleObjectOrClass.
@param sampleObjectOrClass The Class of a type of an example object of the type.
@return The sampleObjectOrClass if it is not a Class.
*/
//===================================================================
public static Object toObject(Object sampleObjectOrClass)
//===================================================================
{
	if (sampleObjectOrClass instanceof Class) return null;
	return sampleObjectOrClass;
}
/**
 * Convert an integer value into a Wrapper appropriate for
 * the specified primitive type, which should be byte, short, char, int, long or boolean
 * @param primitiveType the primitive type.
 * @param value the value to be wrapped.
 * @return the wrapper value.
 * @throws IllegalArgumentException if the value cannot be converted
 * to the primitive type.
 */
public static Object toWrapper(Class primitiveType, long value)
throws IllegalArgumentException
{
	Class c = primitiveType;
	if (c == Byte.TYPE) return new Byte((byte)value);
	if (c == Short.TYPE) return new Short((short)value);
	if (c == Character.TYPE) return new Character((char)value);
	if (c == Integer.TYPE) return new Integer((int)value);
	if (c == Long.TYPE) return new Long((long)value);
	if (c == Boolean.TYPE) return value == 0 ? Boolean.FALSE : Boolean.TRUE;
	throw new IllegalArgumentException();
}
/**
 * Convert a floating point value into a Wrapper appropriate for
 * the specified primitive type, which should be double or float.
 * @param primitiveType the primitive type.
 * @param value the value to be wrapped.
 * @return the wrapper value.
 * @throws IllegalArgumentException if the value cannot be converted
 * to the primitive type.
 */
public static Object toWrapper(Class primitiveType, double value)
throws IllegalArgumentException
{
	Class c = primitiveType;
	if (c == Double.TYPE) return new Double((double)value);
	if (c == Float.TYPE) return new Float((float)value);
	throw new IllegalArgumentException();
}
/**
 * Convert an char value into a Wrapper appropriate for
 * the specified primitive type, which should be byte, short, char, int, long or boolean
 * @param primitiveType the primitive type.
 * @param value the value to be wrapped.
 * @return the wrapper value.
 * @throws IllegalArgumentException if the value cannot be converted
 * to the primitive type.
 */
public static Object toWrapper(Class primitiveType, char value)
throws IllegalArgumentException
{
	return toWrapper(primitiveType,(long)value);
}
/**
 * Convert a boolean value into a Wrapper appropriate for
 * the specified primitive type, which should be boolean.
 * @param primitiveType the primitive type.
 * @param value the value to be wrapped.
 * @return the wrapper value.
 * @throws IllegalArgumentException if the value cannot be converted
 * to the primitive type.
 */
public static Object toWrapper(Class primitiveType, boolean value)
throws IllegalArgumentException
{
	Class c = primitiveType;
	if (c == Boolean.TYPE) return value ? Boolean.TRUE : Boolean.FALSE;
	throw new IllegalArgumentException();
}
public static long unwrapLong(Object value)
throws IllegalArgumentException
{
	if (value instanceof Byte) return ((Byte)value).longValue();
	if (value instanceof Short) return ((Short)value).longValue();
	if (value instanceof Character) return ((Character)value).charValue();
	if (value instanceof Integer) return ((Integer)value).longValue();
	if (value instanceof Long) return ((Long)value).longValue();
	if (value instanceof Boolean) return ((Boolean)value).booleanValue() ? 1 : 0;
	throw new IllegalArgumentException();
}
public static double unwrapDouble(Object value)
throws IllegalArgumentException
{
	if (value instanceof Float) return ((Float)value).doubleValue();
	if (value instanceof Double) return ((Double)value).doubleValue();
	throw new IllegalArgumentException();
}
public static boolean unwrapBoolean(Object value)
{
	if (value instanceof Boolean) return ((Boolean)value).booleanValue();
	throw new IllegalArgumentException();
}
/**
 * This returns the best object to get reference info on a particular class.
 * if data is null it will return classOrReflect, otherwise it will return data.
 * @param data An instance of a class.
 * @param classOrReflect A Class or Reflect object for the class.
 * @return the data if it is not null, or the classOrReflect object.
 */
//===================================================================
public static Object bestReference(Object data,Object classOrReflect)
//===================================================================
{
	if (data != null) return data;
	return classOrReflect;
}
/**
 * Return a Task, which, when started or run() will invoke the specified
 * method on the specified target. When the method returns the Object
 * returned will be set to be the "returnValue" field of the Task.
 * If an exception is thrown it is placed in the error field of the Task.
 * @param target the target object, which can be null for a static method.
 * @param method the method to invoke.
 * @param parameters the parameters to invoke on. This can be null for
 * an empty parameter list.
 * @return a Task that will invoke the method once run.
 */
public static Task invokeMethodTask(final Object target, final Method method,Object[] parameters)
{
	final Object[] p = parameters == null ? emptyParameters : parameters;
	return new Task(){
		protected void doRun(){
			try{
				succeed(method.invoke(target,p));
			}catch(IllegalAccessException e){
				fail(e);
			} catch (IllegalArgumentException e) {
				fail(e);
			} catch (InvocationTargetException e) {
				fail(e.getTargetException());
			}
		}
	};
}
/**
 * Check if a thrown exception is acceptable as being thrown by the method -
 * i.e. if it is in its list of throws exception types.
 * @param m the method.
 * @param t the thrown exception.
 * @return true if it is, false if not.
 */
public static boolean methodThrows(Method m, Throwable t)
{
	Class tc = t.getClass();
	if (t instanceof RuntimeException || t instanceof Error)
		return true;
	Class[] all = m.getExceptionTypes();
	for (int i = 0; i<all.length; i++){
		if (all[i].isAssignableFrom(tc))
			return true;
	}
	return false;
}
/**
 * Attempt to get the encoded field or method type.
 * @param cl the Class to look for the field.
 * @param fieldOrMethod the name of the field or the name of the method
 * followed by '(' and then the Java type encoded parameters followed by
 * ')'.
 * @return the encoded type of the field or method, or null if not found. 
 */
public static String findEncodedFieldOrMethodType(Class cl, String fieldOrMethod)
{
	try{
		int idx = fieldOrMethod.indexOf('('); 
		if (idx == -1) return getEncodedName(cl.getField(fieldOrMethod).getType());
		Class[] all = getParameterTypes(fieldOrMethod);
		return getEncodedName(cl.getMethod(fieldOrMethod.substring(0,idx), all).getReturnType());
	}catch(Throwable t){
		return null;
	}
}
/**
 * This represents a Field that is tied to an instance of an Object. It is validated
 * on creation but thereafter no validation is done. This allows for the fastest
 * possible field access.
 */
public static class InstanceField {

	private Object myObject;
	private Field myField;
	private eve.reflect.Field myEveField;
	private Wrapper wrapper = new Wrapper();
	
	/**
	 * Get the Wrapper that data will be passed to and from the field.
	 */
	public Wrapper getData() {return wrapper;}
	
	/**
	 * Set the internal data wrapper to be equal to the provided wrapper.
	 * @param w the data that will be set using set() or trySet().
	 * @return this InstanceField.
	 */
	public InstanceField setData(Wrapper w)
	{
		if (w == null) wrapper.zero();
		else wrapper.copyFrom(w);
		return this;
	}
/**
 * Returns if this InstanceField matches the Object and Field
 * specified.
 */	
	public boolean matches(Object obj, Field field)
	{
		return myObject.equals(obj) && myField.equals(field);
	}
	/**
	 * Create the InstanceField. If the specified field is not compatible with
	 * the specified Object an exception is thrown.
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	public InstanceField(Object obj, Field field) throws IllegalArgumentException, IllegalAccessException
	{
		//System.out.println("Creating: "+obj+" - "+field);
		myObject = obj;
		myField = field;
		//
		field.get(obj);
		//
		if (hasWrapperMethods == -1) checkHasWrapperMethods();
		if (hasWrapperMethods != 0){
			myEveField = (eve.reflect.Field)NativeAccess.getSetVariable(field,null,true);
		}
	}
	//
	public Wrapper get() throws IllegalArgumentException, IllegalAccessException
	{
		if (myEveField != null) return myEveField.getValueDontCheckObject(myObject, wrapper);
		wrapper.fromJavaWrapper(myField.get(myObject), myField.getType());
		return wrapper;
	}
	//
	public Wrapper tryGet()
	{
		try{
			return get();
		}catch(Exception e){
			return null;
		}
	}
	public void set() throws IllegalArgumentException, IllegalAccessException 
	{
		if (myEveField != null) myEveField.setValueDontCheckObject(myObject, wrapper);
		else{
			myField.set(myObject, wrapper.toJavaWrapper());
		}
	}
	public boolean trySet()
	{
		try{
			set();
			return true;
		}catch(Exception e){
			return false;
		}
	}
	/**
	 * If the current InstanceField matches the object and field exactly, then
	 * return the current InstanceField. Otherwise create and return a new one.
	 * @param current the current InstanceField.
	 * @param obj the possibly new Object to access.
	 * @param field the possibly new Field to access.
	 * @return an InstanceField that matches the Object and Field.
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	public static InstanceField match(InstanceField current, Object obj, Field field) throws IllegalArgumentException, IllegalAccessException
	{
		if (current != null && current.myObject.getClass() == obj.getClass() && current.myField == field){
			current.myObject = obj;
			return current;
		}
		return new InstanceField(obj,field);
	}
}
private static boolean isInstanceOf(String targetClass, Class testClass, boolean checkInterfaces)
{
	if (testClass == null) return false;
	if (testClass.getName().equals(targetClass)) {
		//System.out.println(targetClass+" == "+testClass);
		return true;
	}else{
		//System.out.println(targetClass+" != "+testClass);
	}
	Class sc = testClass.getSuperclass();
	if (sc != null)
		if (isInstanceOf(targetClass,sc,true))
			return true;
	if (checkInterfaces){
		Class[] all = testClass.getInterfaces();
		if (all != null)
			for (int i = 0; i<all.length; i++)
				if (isInstanceOf(targetClass, all[i], true)){
					return true;
				}
	}
	return false;
}
/**
 * Test if testClass is an instance of targetClass <b>without</b> loading
 * the Class for targetClass. A purely String comparison of super classes
 * and implemented methods is done.
 * @param targetClass the target class.
 * @param testClass the test class.
 * @return true if testClass is an instance of the targetClass.
 */
public static boolean isInstanceof(String targetClass, Class testClass)
{
	//if (isInstanceOf(targetClass,testClass,false)) return true;
	return isInstanceOf(targetClass,testClass,true);
}
/**
 * Return a Task, which, when started or run() will invoke the specified
 * method on the specified target. When the method returns the Object
 * returned will be set to be the "returnValue" field of the Task.
 * If an exception is thrown it is placed in the error field of the Task.
 * @param target the target object, which can be null for a static method.
 * @param method the method to invoke.
 * @param parameters the parameters to invoke on. This can be null for
 * an empty parameter list.
 * @return a Task that will invoke the method once run.
 */
/*
public static Task invokeMethodTask(final Object target,String method,Object[] parameters)
{
	final Method m = getMethod(target instanceof Class ? (Class)target:target.getClass(),method,false); 
	final Object[] p = parameters == null ? emptyParameters : parameters;
	return new Task(){
		protected void doRun(){
			try{
				succeed(m.invoke(target,p));
			}catch(IllegalAccessException e){
				fail(e);
			} catch (IllegalArgumentException e) {
				fail(e);
			} catch (InvocationTargetException e) {
				fail(e.getTargetException());
			} catch (Throwable t){
				fail(t);
			}
		}
	};
}
*/
//##################################################################
}
//##################################################################

