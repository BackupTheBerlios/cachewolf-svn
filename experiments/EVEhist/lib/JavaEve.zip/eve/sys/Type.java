package eve.sys;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Hashtable;
import java.util.WeakHashMap;

/**
This class provides an easy way to refer to and link to a Class that may
not be present at run time.<p>
You create and use a Type object like so:
<p><pre>
Type tp = new Type("eve.security.Decryptor");
boolean wasFound = tp.exists();
boolean isAnInstance = tp.isInstance(anObject);
</pre>
**/
//##################################################################
public class Type implements InvocationHandler{
//##################################################################
private Class r;
private String className;
public String toString()
{
	if (r != null) return r.getName();
	else return className;
}
/**
 * This Type is always of a non-existent class.
 */
public final static Type nullType = new Type((String)null);
/**
Return a new Instance of the class if the class exists.
**/
//===================================================================
public Object newInstance()
//===================================================================
{
	if (r == null) return null;
	return Reflection.newInstance(r);
}
/**
Return a new Instance of the class if the class exists.
 * @param constructorSpecs the method specs for the constructor to use.
 * @param parameters parameters to send to the method.
 * @return the object if created or null if not.
 */
public Object newInstance(String constructorSpecs, Object[] parameters)
//===================================================================
{
	if (r == null) return null;
	return Reflection.newInstance(r,constructorSpecs,parameters);
}
//===================================================================
/**
 * Invoke a method on the Object which must be of this Type.
 * @param dest the Object to invoke on, or null for static methods.
 * @param nameAndSpecs the name and parameter specs for the method.
 * @param parameters the list of parameters to pass to the method. This can be null
 * if there are no parameters.
 * @return the return value of the method as a standard Java wrapper if any.
 */
public Object invoke(Object dest, String nameAndSpecs, Object[] parameters)
//===================================================================
{
	if (r == null) return null;
	Wrapper ow = Wrapper.getCached();
	try{
		Wrapper w = Reflection.invokeMethod(r,dest,nameAndSpecs,parameters,false,ow);
		if (w == null || w.getType() == w.VOID) return null;
		return w.toJavaWrapper();
	}finally{
		ow.cache();
	}
}
/**
 * Get a named Method but don't throw an exception on error.
 * @param nameAndSpecs
 * @param declaredOnly
 * @return
 */
public Method getMethod(String nameAndSpecs,boolean declaredOnly)
{
	if (r == null) return null;
	return Reflection.getMethod(r,nameAndSpecs,declaredOnly);
}
/**
Returns the ewe.reflect.Reflect object that represents the class,
if the class was found during the construction of this Type. If the
class was not found during the cunstruction, this will return null.
**/
/*
//===================================================================
public Reflect getReflection()
//===================================================================
{
	return r;
}
*/
/**
* Return the name of the Class this Type represents.
**/
//===================================================================
public String getClassName()
//===================================================================
{
	return className;
}
/**
 * Return the Class this type represents if present.
 */
public Class getReflectedClass()
{
	return r;
}

/**
 * Load a <b>System</b> class - i.e. one that can be loaded by the VM through
 * the System class loaders and not through an application ClassLoader. Use this
 * method rather than Class.forName() - because under some Java VMs, this will fail
 * if the class is located in a .ewe file.
 * @param className the name of the Class.
 * @return the found Class
 * @throws ClassNotFoundException if the Class was not found.
 */
public static Class forName(String className) throws ClassNotFoundException
{
	if (className.charAt(0) == 'L' && className.charAt(className.length()-1) == ';') 
		className = className.substring(1,className.length()-1).replace('/','.');
	return Classes.forName(className);
}
/**
 * Load a class via the System class loader or through any created eve.util.mClassLoader
 * Objects the application created.
 * @param className the name of the Class.
 * @return the found Class
 * @throws ClassNotFoundException if the Class was not found.
 */
public static Class loadForName(String className) throws ClassNotFoundException
{
	if (className.charAt(0) == 'L' && className.charAt(className.length()-1) == ';') 
		className = className.substring(1,className.length()-1).replace('/','.');
	return Classes.loadForName(className);
}
/**
 * Load a class via the System class loader or 
 * through the same ClassLoader that loaded the requestor class.
 * Objects the application created.
 * @param className the name of the Class.
 * @param requestor the requesting Class.
 * @return the found Class
 * @throws ClassNotFoundException if the Class was not found.
 */

public static Class forName(String className, Class requestor) throws ClassNotFoundException
{
	if (className.charAt(0) == 'L' && className.charAt(className.length()-1) == ';') 
		className = className.substring(1,className.length()-1).replace('/','.');
	try{
		return Classes.forName(className);
	}catch(ClassNotFoundException e){
		if (requestor == null) throw new ClassNotFoundException(className);
		ClassLoader cl = requestor.getClassLoader();
		if (cl == null) throw new ClassNotFoundException(className);
		return cl.loadClass(className);
	}
}
/**
Create a Type for the specified className - which should be specified in standard "." 
notation. If the class is not found the Type will be still be created, but the isInstance()
method will always return false. The exists() method can be used to check if the class
actually was found.
**/
//===================================================================
public Type(String className)
//===================================================================
{
	if (className == null) return;
	String name = className;
	if (name.charAt(0) == 'L' && name.charAt(name.length()-1) == ';') 
		name = name.substring(1,name.length()-1).replace('/','.');
	try{
		r = loadForName(name);
	}catch(ClassNotFoundException e){
		r = null;
	}
	this.className = name;
}
public Type(Class theClass)
{
	r = theClass;
	this.className = theClass.getName();
}
/**
 * Create a Type that represents a named class, but only if the class
 * ifThisIsInstance is an instance of that class. The check that is
 * done to verify that ifThisIsInstance is actually an instance of the
 * class is done without loading the class specified by className. If
 * it fails therefore, then the target class is not loaded.
 * @param className the name of the target class.
 * @param ifThisIsInstance the test class.
 */
public Type(String className, Class ifThisIsInstance)
{
	if (className == null) return;
	String name = className;
	if (name.charAt(0) == 'L' && name.charAt(name.length()-1) == ';') 
		name = name.substring(1,name.length()-1).replace('/','.');
	if (Reflection.isInstanceof(name, ifThisIsInstance)){
		try{
			r = loadForName(name);
		}catch(ClassNotFoundException e){
			r = null;
		}
		this.className = name;
	}
}

/**
Return if the class of the Type was actually found.
**/
//===================================================================
public boolean exists()
//===================================================================
{
	return r != null;
}
/**
 * Return if the specified Object is an instance of the Class represented by this Type.
 * @param obj the object to check.
 * @return true if the object is an instance of the Class represented by this Type or false
 * if not, or if obj is null, or if the Class for this type was not found.
 */
//===================================================================
public boolean isInstance(Object obj)
//===================================================================
{
	if (r == null || obj == null) return false;
	return r.isInstance(obj);
}

public void cacheMethod(String methodNameAndSpecs)
{
	if (r != null) Reflection.cacheMethod(r,methodNameAndSpecs);
}
public Method getMethod(String methodNameAndSpecs)
{
	if (r == null) return null;
	return Reflection.getMethod(r,methodNameAndSpecs,false);
}
/*
//=================================================================
public static void main(String[] args)
//=================================================================
{
	ewe.sys.Vm.startEwe(args);
	Type t = new Type("java.lang.String");
	ewe.sys.Vm.debug(t.isInstance("hello") +", "+ t.isInstance(t));
	ewe.sys.mThread.nap(2000);
	ewe.sys.Vm.exit(0);
}
*/
private Hashtable myMethods;
private WeakHashMap targets;

synchronized Method getTargetMethod(Method interfaceMethod) throws NoSuchMethodException
{
	if (r == null) return null;
	if (myMethods == null) myMethods = new Hashtable();
	Method t = (Method)myMethods.get(interfaceMethod);
	if (t != null) return t;
	t = r.getMethod(interfaceMethod.getName(), interfaceMethod.getParameterTypes());
	myMethods.put(interfaceMethod,t);
	return t;
}

public Object invoke(Object proxy, Method method, Object[] args)
		throws Throwable {
	Wrapper w = Reflection.handleProxyObjectMethod(proxy,method,args);
	if (w != null) return w.toJavaWrapper();
	//
	try{
		Method t = getTargetMethod(method);
		Object target = targets.get(proxy);
		if (target == null) throw new NullPointerException();
		return t.invoke(target,args);
	}catch(NoSuchMethodException e){
		throw new NoSuchMethodError(r+" does not implement method: "+method.getName());
	}catch(InvocationTargetException e){
		Throwable tt = e.getTargetException();
		tt.fillInStackTrace();
		if (tt != null && Reflection.methodThrows(method,tt))
			throw tt;
		throw e;
	}catch(Throwable tt){
		throw tt;
	}
}
/**
 * Create a new instance of the class represented by this Type and then
 * create a Proxy object that implements the specified interfaces by
 * calling methods of the same signature in the created target.
 * @param target an Object that is of the class represented by this Type.
 * @param interfacesToImplement the Interfaces to implement.
 * @return an Object that can be cast to the specified Interface or
 * null if no Object could be created.
 */
public synchronized Object newProxy(Object target, Class[] interfacesToImplement)
{
	if (target == null || r == null || !r.isInstance(target)) return null;
	Object p = Reflection.newProxyInstance(null, interfacesToImplement, this);
	if (p == null) return p;
	if (targets == null) targets = new WeakHashMap();
	targets.put(p, target);
	return p;
}
/**
 * Create a new instance of the class represented by this Type and then
 * create a Proxy object that implements the specified interface by
 * calling methods of the same signature in the created target.
 * @param interfaceToImplement the Interface to implement.
 * @param constructorSpecs the constructor signature.
 * @param args arguments for the constructor.
 * @return an Object that can be cast to the specified Interface or
 * null if no Object could be created.
 */
public Object newProxyInstance(Class interfaceToImplement, String constructorSpecs, Object[] args)
{
	return newProxy(newInstance(constructorSpecs,args),new Class[]{interfaceToImplement});
}
/**
 * Create a new instance of the class represented by this Type 
 * using the default constructor, and then
 * create a Proxy object that implements the specified interface by
 * calling methods of the same signature in the created target.
 * @param interfaceToImplement the Interface to implement.
 * @return an Object that can be cast to the specified Interface or
 * null if no Object could be created.
 */
public Object newProxyInstance(Class interfaceToImplement)
{
	return newProxy(newInstance(),new Class[]{interfaceToImplement});
}
}
//##################################################################

