/*
 * Created on Feb 26, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.io.Reader;
import java.io.Writer;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface IConsole {

	/**
	 * This is an option to show the Stop button, AND the event type generated
	 * when that button is pressed. There is no default action for this button.
	 */
	public static int BUTTON_STOP = 0x1;
	/**
	 * This is an option to show the Close button, AND the event type generated
	 * when that button is pressed. The default action is to close and destroy the console.
	 */
	public static int BUTTON_CLOSE = 0x2;
	/**
	 * This is an option to show the Clear button, AND the event type generated
	 * when that button is pressed. The default action is to clear the console.
	 */
	public static int BUTTON_CLEAR = 0x4;
	/**
	 * This is an option to show the Hide button, AND the event type generated
	 * when that button is pressed. The default action is to hide the console.
	 */
	public static int BUTTON_HIDE = 0x8;
	
	//public static int OPTION_DONT_DO_DEFAULT_ACTIONS = 0x10;
	
	public static int OPTION_READ_ONLY = 0x80000000;
	public static int OPTION_DONT_PUT_IN_WINDOW = 0x40000000;
	
	public Writer getWriter();
	public Reader getReader();
	public void setVisible(boolean vis);
	public void close();
	public void clear();
	public EventDispatcher getEventDispatcher();
	public void doDefaultAction(Event ev);
	
}
//####################################################
