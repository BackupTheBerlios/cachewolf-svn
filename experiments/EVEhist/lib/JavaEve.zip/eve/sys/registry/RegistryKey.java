package eve.sys.registry;

import eve.sys.Device;
import eve.util.CharArray;

//##################################################################
class RegistryKey {
//##################################################################
/* Do not move these */
int nativeObject;
boolean isRemote;
int root;
String path;
boolean fullAccess = true;
boolean createIfDoesntExist;
/***************************/

/*
 * A root of 0 indicates the top level IRegistryKey - i.e. the entire registry.
 * Otherwise an empty path indicates the top of a root.
 */
//boolean isValid = false;
private RegistryData data = new RegistryData();

//-------------------------------------------------------------------
protected RegistryKey()
//-------------------------------------------------------------------
{
}
boolean update()
{
	if (root == 0) return true;
	if (path == null) path = "";
	return checkValid();
}
//-------------------------------------------------------------------
RegistryKey(boolean isRemote,int root,String path)//,boolean fullAccess,boolean createIfDoesntExist)
//-------------------------------------------------------------------
{
	this.root = root;
	this.path = path;
	this.fullAccess = true;//fullAccess;
	this.createIfDoesntExist = false;//createIfDoesntExist;
	this.isRemote = isRemote;
	update(); //Necessary to setup or create the key in the Eve native VM.
	/*
	try{
		isValid = checkValid();
	}catch(Throwable t){
		isValid = true;
	}
	*/
}

public RegistryKey getRootKey()
{
	if (root == 0) return this;
	return new RegistryKey(isRemote,0,"");
}
/*
//===================================================================
public IRegistryKey getCopy()
//===================================================================
{
	return new RegistryKey(isRemote,root,path);//,fullAccess,createIfDoesntExist);
}
*/
/**
 * Get a new RegistryKey that is a subkey of this key.
 * @param subkeyPath
 * @return
 */
public RegistryKey getSubKey(String subkeyPath)
//===================================================================
{
	StringBuffer sb = new StringBuffer();
	if (root == 0) {
		int r = Registry.toRootAndPath(subkeyPath,sb);
		if (r == 0) return null;
		return new RegistryKey(isRemote,r,sb.toString());
	}
	sb.append(path);
	if (sb.length() != 0) sb.append('\\');
	sb.append(subkeyPath);
	return new RegistryKey(isRemote,root,sb.toString());
}

//===================================================================
public int getRoot() {return root;}
//===================================================================
public String getPath() {return path;}
//===================================================================
public String getFullPath() 
{
	if (root == 0 || path.length() == 0) return getName();
	return Registry.roots[root]+'\\'+path;
}
//===================================================================
/**
* This returns the name of the subkey without the parent path.
**/
//===================================================================
public String getName()
//===================================================================
{
	if (root == 0) return isRemote ? "Remote Registry" : "Registry";
	if (path.length() == 0) return Registry.roots[root];
	int idx = path.lastIndexOf('\\');
	return path.substring(idx+1);
}
//===================================================================
public String toString()
//===================================================================
{
	return getFullPath();
}


/**
* This returns either a String or a byte array, or an Integer (representing a 32-bit value)
* or a StringBuffer indicating an expanding String, or null. If valueName
* is null or an empty String then the default value will be returned.
**/
//===================================================================
public Object getValue(String valueName)
//===================================================================
{
	synchronized(data){
		if (valueName == null) valueName = "";
		data.expanding = null;
		data.value = data.name = null;
		if (!getNamedValue(valueName,data)) return null;
		if (data.value != null) return data.value;
		if (data.expanding != null) return new StringBuffer(data.expanding);
		return new Integer(data.intValue);
	}
}

/**
* Get a value at the specified index. The name of the value is placed in the
* valueName StringBuffer. The return value is either a String or a byte array
* or an Integer (representing a 32-bit value) or null.
**/
//===================================================================
public Object getValue(int index,StringBuffer valueName) throws IndexOutOfBoundsException
//===================================================================
{
	synchronized(data){
		data.expanding = null;
		data.value = data.name = null;
		data.intValue = 0;
		if (valueName == null) valueName = new StringBuffer();
		valueName.setLength(0);
		if (!getIndexedValue(index,data)) return null;
		if (data.name != null) valueName.append(data.name);
		if (data.value != null) return data.value;
		if (data.expanding != null) return new StringBuffer(data.expanding);
		return new Integer(data.intValue);
	}
}
/**
* Delete a value with the specified name.
**/
//===================================================================
public boolean deleteValue(String name)
//===================================================================
{
	return deleteAValue(name == null ? "" : name);
}
/**
* Delete the entire key and all its subkeys (if possible).
**/
//===================================================================
public boolean delete()
//===================================================================
{
	return deleteAKey();
}
/**
* Set a String value.
**/
//===================================================================
public boolean setValue(String name,String value)
//===================================================================
{
	return setAStringValue(name == null ? "" : name,value == null ? new String() : value,false);
}
public boolean setExpandingString(String name, String value)
{
	return setAStringValue(name == null ? "" : name,value == null ? new String() : value,true);
}
/**
* Set a binary data value.
**/
//===================================================================
public boolean setValue(String name,byte [] value)
//===================================================================
{
	return setABinaryValue(name == null ? "" : name,value == null ? new byte[0] : value);
}
/**
* Set a 32-bit data value in the default little-endian format.
**/
//===================================================================
public boolean setValue(String name,int value) 
//===================================================================
{
	return setAnIntValue(name == null ? "" : name,value);
}
/**
* Set a 32-bit data value in either little-endian or big-endian format.
**/
//===================================================================
//public boolean setValue(String name,int value,boolean bigEndian)
//===================================================================
//{
//	return registryKeySetInt(name,value,bigEndian);
//}
//-------------------------------------------------------------------
protected native boolean getIndexedValue(int index,RegistryData data) throws IndexOutOfBoundsException;
protected native boolean getNamedValue(String name,RegistryData data);
protected native boolean setAStringValue(String name,String value,boolean expanding);
protected native boolean setABinaryValue(String name,byte [] value);
protected native boolean setAnIntValue(String name,int value);
protected native boolean deleteAValue(String name);
protected native boolean deleteAKey();
protected native boolean checkValid();
protected native void finalize();
public native Object getSubKeys(int options);
public native int getSubKeyCount();
public native int getValueCount();
//-------------------------------------------------------------------
/**
 * Return the NAME of the subkey at the specified index.
 */
public native String getSubKey(int index) throws IndexOutOfBoundsException;

protected native boolean nativeGetSubKey(int index, CharArray appendTo);
//-------------------------------------------------------------------
public boolean getSubKey(int index, CharArray appendTo)
{
	if (appendTo == null) throw new NullPointerException();
	try{
		return nativeGetSubKey(index,appendTo);
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		try{
			String got = getSubKey(index);
			if (got == null) return true;
			appendTo.append(got);
			return true;
		}catch(IndexOutOfBoundsException e){
			return false;
		}
	}
}

/* (non-Javadoc)
 * @see eve.sys.IRegistryKey#create(boolean)
 */
public boolean create(boolean createFullPath) {
	if (exists()) return true;
	if (!createFullPath){
		RegistryKey rk = getParentKey();
		if (rk == null || !rk.exists()) return false;
	}
	createIfDoesntExist = true;
	boolean ret = update();
	createIfDoesntExist = false;
	return ret;
}
/* (non-Javadoc)
 * @see eve.sys.IRegistryKey#exists()
 */
public synchronized boolean exists() {
	return update();
}
/* (non-Javadoc)
 * @see eve.sys.IRegistryKey#getParentKey()
 */
public RegistryKey getParentKey() 
{
	if (root == 0) return null;
	if (path.length() == 0) return new RegistryKey(isRemote,0,"");
	int idx = path.lastIndexOf('\\');
	if (idx == -1) return new RegistryKey(isRemote,root,"");
	return new RegistryKey(isRemote,root,path.substring(0,idx));
}

//-------------------------------------------------------------------
//##################################################################
}
//##################################################################

//##################################################################
class RegistryData{
//##################################################################
public String name = null;
public Object value = null;
public int intValue;
public String expanding = null;
//##################################################################
}
//##################################################################




