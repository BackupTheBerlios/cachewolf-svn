/*
 * Created on Feb 25, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys.registry;

import eve.sys.IRegistryKey;
import eve.util.IntArray;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
class RegistryKeyImp implements IRegistryKey{

	RegistryKey key;
	int[] availableRoots;
	static int[] localAvailableRoots;
	
	static synchronized int[] getAvailableRoots(boolean remote)
	{
		if (!remote && localAvailableRoots != null)
			return localAvailableRoots;
		IntArray ia = new IntArray();
		for (int i = 1; i<Registry.roots.length; i++){
			RegistryKey rk = new RegistryKey(remote,i,"");
			if (rk.exists()) ia.append(i);
		}
		int[] ret = ia.toIntArray();
		if (!remote) localAvailableRoots = ret;
		return ret;
	}
	
	RegistryKeyImp(RegistryKey key)
	{
		this.key = key;
		if (key.root == 0) availableRoots = getAvailableRoots(key.isRemote);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getRootKey()
	 */
	public IRegistryKey getRootKey() {
		RegistryKey k = key.getRootKey();
		if (k == key) return this;
		return new RegistryKeyImp(k);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getSubKey(java.lang.String)
	 */
	public IRegistryKey getSubKey(String subkeyPath) {
		RegistryKey rk = key.getSubKey(subkeyPath);
		return new RegistryKeyImp(rk);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#createKey(boolean)
	 */
	public boolean createKey(boolean createFullPath) {
		return key.create(createFullPath);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#keyExists()
	 */
	public boolean keyExists() {
		return key.exists();
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getFullKeyPath()
	 */
	public String getFullKeyPath() {
		return key.getFullPath();
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getKeyName()
	 */
	public String getKeyName() {
		return key.getName();
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getParentKey()
	 */
	public IRegistryKey getParentKey() {
		RegistryKey rk = key.getParentKey();
		if (rk == null) return null;
		return new RegistryKeyImp(rk);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getValue(java.lang.String)
	 */
	public Object getValue(String valueName) {
		if (key.root == 0) return null;
		return key.getValue(valueName);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getValue(int, java.lang.StringBuffer)
	 */
	public Object getValue(int index, StringBuffer valueName) throws IndexOutOfBoundsException {
		if (key.root == 0) return null;
		return key.getValue(index,valueName);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#deleteValue(java.lang.String)
	 */
	public boolean deleteValue(String name) {
		if (key.root == 0) return false;
		return key.deleteValue(name);
	}

	private static boolean deleteIt(RegistryKeyImp k)
	{
		String [] subs = (String[])k.getSubKeys(0);
		if (subs != null)
			for (int i = 0; i<subs.length; i++){
				RegistryKeyImp kk = (RegistryKeyImp)k.getSubKey(subs[i]);
				if (!deleteIt(kk)) return false;
			}
		return k.key.delete();
	}
	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#deleteKey()
	 */
	public boolean deleteKey() {
		if (key.root == 0) return false;
		if (key.path.length() == 0) return false;
		if (key.delete()) return true;
		return deleteIt(this);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#setValue(java.lang.String, java.lang.String)
	 */
	public boolean setValue(String name, String value) {
		if (key.root == 0) return false;
		return key.setValue(name,value);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#setValue(java.lang.String, byte[])
	 */
	public boolean setValue(String name, byte[] value) {
		if (key.root == 0) return false;
		return key.setValue(name,value);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#setValue(java.lang.String, int)
	 */
	public boolean setValue(String name, int value) {
		if (key.root == 0) return false;
		return key.setValue(name,value);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getSubKey(int)
	 */
	public String getSubKey(int index) throws IndexOutOfBoundsException {
		if (key.root == 0) return Registry.roots[availableRoots[index]];
		return key.getSubKey(index);
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getSubKeyCount()
	 */
	public int getSubKeyCount() {
		if (key.root == 0) return availableRoots.length;
		return key.getSubKeyCount();
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getValueCount()
	 */
	public int getValueCount() {
		if (key.root == 0) return 0;
		return key.getValueCount();
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getSubKeys(int)
	 */
	public Object getSubKeys(int options) {
		if (key.root != 0) {
			Object ret = key.getSubKeys(options);
			if (ret != null) return ret;
			if ((options & GET_INDEXES_AS_LONGS) != 0)
				return new long[0];
			if ((options & GET_INDEXES) != 0)
				return new int[0];
			return new String[0];
		}
		if ((options & GET_INDEXES_AS_LONGS) != 0){
			long[] ret = new long[availableRoots.length];
			for (int i = 0; i<availableRoots.length; i++)
				ret[i] = i;
			return ret;
		}
		if ((options & GET_INDEXES) != 0){
			int[] ret = new int[availableRoots.length];
			for (int i = 0; i<availableRoots.length; i++)
				ret[i] = i;
			return ret;
		}
		String[] ret = new String[availableRoots.length];
		for (int i = 0; i<availableRoots.length; i++)
			ret[i] = Registry.roots[availableRoots[i]];
		return ret;
	}

	public String toString()
	{
		return key.toString();
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#setExpandingString(java.lang.String, java.lang.String)
	 */
	public boolean setExpandingString(String name, String value) {
		if (key.root == 0) return false;
		return key.setExpandingString(name,value);
	}
}
//####################################################
