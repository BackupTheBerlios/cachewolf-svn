package eve.sys.registry;
import java.io.IOException;

import eve.io.File;
import eve.sys.IRegistryKey;
import eve.sys.Rapi;
import eve.sys.TimeOut;
import eve.sys.Vm;
/**
**/
//##################################################################
public class Registry{
//##################################################################

public static double testValue = 1234567.89012;

static IRegistryKey local;//, remote;

synchronized static IRegistryKey getRegistry(final boolean isRemote)
{
	if (isRemote){
		if (!Rapi.tryConnect(1000)) return null;
		return new RegistryKeyImp(new RegistryKey(true,0,""));
	}
	if (local == null) local = new RegistryKeyImp(new RegistryKey(false,0,""));
	return local;
}
public static IRegistryKey getLocalRegistry(){return getRegistry(false);} 
public static IRegistryKey getRemoteRegistry(){return getRegistry(true);} 
//
// Should return true if native registry access is possible.
//
private static native boolean initializeNative();

static boolean initialized = false;
static boolean nativeInitialized = false;
static {
	initialized = nativeInitialized = Vm.javaEveLibraryLoaded();
}
//static String registryFile = null;
static String registryDatabase = null;
static boolean triedFile = false;

//static ewe.sys.Lock timeoutLock = new ewe.sys.Lock();
//static ewe.datastore.DataStorage registry;
//static ewe.database.Database registry;
static Object registry;
static TimeOut accessTimeout;
static boolean closeRegistry = false;

//-------------------------------------------------------------------
static synchronized boolean openRegistry()
//-------------------------------------------------------------------
{
 	if (accessTimeout == null) {
		accessTimeout = new TimeOut(100);
		/*
		new ewe.sys.mThread(){
			public void run(){
				timeoutLock.synchronize(); try{
					while(true){
						try{
							if (closeRegistry) return;
							if (accessTimeout.hasExpired()){
								if (registry != null) {
									//ewe.sys.Vm.debug("Closing.");
									registry.close();
									registry = null;
								}
								timeoutLock.waitOn(ewe.sys.TimeOut.Forever);
							}else{
								timeoutLock.waitOn(accessTimeout);
							}
						}catch(Exception e){
						}
						
					}
				}finally{
					timeoutLock.release();
				}
			}
		}.start();
	*/
	}
	if (registryDatabase == null) {
		/*
		if (registry != null) return true; //Will still have the lock when we leave this method.
		try{
			for (int i = 0; i<10; i++){
				try{
					registry = DatabaseManager.initializeDatabase(null,registryDatabase,null);
					if (registry != null){
						//ewe.sys.Vm.debug("Initializing!");
						int pathField = registry.addField("path",Database.STRING);
						int nameField = registry.addField("name",Database.STRING);
						int typeField = registry.addField("type",Database.INTEGER);
						registry.addField("value",Database.STRING);
						int sort = registry.addSort("ByPath",Database.SORT_IGNORE_CASE,pathField,nameField,typeField,0);
						registry.indexBy(null,sort,"ByPath");
						registry.setObjectClass(new RegistryEntry());
						registry.save();
						registry.close();
					}
					registry = DatabaseManager.openDatabase(null,registryDatabase,"rw");
					//ewe.sys.Vm.debug("Opened: "+registry+" at "+registryDatabase);
					accessTimeout.reset();
					return true; //Will still have the lock when we leave this method.
				}catch(IOException e){
					e.printStackTrace();
					//ewe.sys.Vm.debug("Can't open now.");
					ewe.sys.mThread.nap(100);
				}catch(Exception e2){
					e2.printStackTrace();
				}
			}
		}catch(Exception e){}
		timeoutLock.release();
		*/
		return false;
	}else{
		//ewe.sys.Vm.debug("Could not open!");
		return false;
	}
}

//-------------------------------------------------------------------
static synchronized void closeRegistry()
//-------------------------------------------------------------------
{
	try{
		if (registry != null){
			//ewe.sys.Vm.debug("Closing.");
			//FIXME!
			//registry.close();
			//registry = null;
		}
	}catch(Exception e){
		//ewe.sys.Vm.debug(e.getMessage());
	}
}

//-------------------------------------------------------------------
protected static boolean loadLibrary(String libraryName)
//-------------------------------------------------------------------
{
	try{
		Vm.loadLibrary(libraryName);
		return true;
	}catch(Throwable t){
		return false;
	}
}
public static final int ROOT_NAME_SPECIFIED_IN_PATH = 0;
public static final int HKEY_CLASSES_ROOT = 1;
public static final int HKEY_CURRENT_USER = 2;
public static final int HKEY_LOCAL_MACHINE = 3;
public static final int HKEY_USERS = 4;
public static final int HKEY_CURRENT_CONFIG = 5;
public static final int HKEY_DYN_DATA = 6;

public static String [] roots  =
{"","HKEY_CLASSES_ROOT","HKEY_CURRENT_USER","HKEY_LOCAL_MACHINE","HKEY_USERS","HKEY_CURRENT_CONFIG","HKEY_DYN_DATA"};

/**
* This converts a path that starts with a string representation of one of the roots to an int value which is one
* of the HKEY_ values. It will return 0 if a valid root was not found.
**/
//===================================================================
public static int toRootAndPath(String path,StringBuffer pathWithoutRoot)
//===================================================================
{
	int idx = path.indexOf('\\');
	if (idx != -1){
		pathWithoutRoot.append(path.substring(idx+1));
		path = path.substring(0,idx).toUpperCase();
	}else{
		path = path.toUpperCase();
	}
	String hk = "HKEY_";
	if (!path.startsWith(hk)) path = hk+path;
	for (int i = 0; i<roots.length; i++)
		if (roots[i].equals(path)) return i;
	return 0;
}
static IRegistryKey getKey(boolean remote, int root, String path, boolean create)
{
	RegistryKey key = 
		//registryDatabase != null ? new FileRegistryKey(false,root,path,fullAccess,createIfDoesntExist):
		new RegistryKey(remote,root,path);//,fullAccess,createIfDoesntExist);
	if (!key.exists() && create) {
		if (!key.create(true))
			return null;
	}
	if (!key.exists()){
		//ewe.sys.Vm.debug("Key was not valid!",0);
		return null;
	}else{
		//ewe.sys.Vm.debug("Got valid key!",0);
		return new RegistryKeyImp(key);
	}
}
/**
* Get a key in the local registry. If the path or root specified is invalid for any reason, it will
* return null. If there is no native registry access it will return null.<p>
* Note that the path MUST be separated by '\' characters and NOT '/' characters.<p>
* If a <b>root</b> of ROOT_NAME_SPECIFIED_IN_PATH is used, it will be assumed that the path will start with "HKEY_CLASSES_ROOT\\..."
* or one of the other text representation of the roots. These roots are:<br>
* "HKEY_CLASSES_ROOT","HKEY_CURRENT_USER","HKEY_LOCAL_MACHINE","HKEY_USERS","HKEY_CURRENT_CONFIG","HKEY_DYN_DATA"
**/
//===================================================================
public static IRegistryKey getLocalKey(int root,String path,boolean fullAccess,boolean createIfDoesntExist)
//===================================================================
{
	//
	if (!initialized) return null; //FIXME 
	//
	/*
	if (!initialized) {
		if (registryDatabase == null && triedFile) return null;
		else if (registryDatabase == null){
			try{
				File ep = ewe.io.File.getNewFile(ewe.sys.Vm.getPathToEweVM()).getParentFile();
				ep = ep.getChild("Registry"); // Registry.dat for datastore.
				registryDatabase = ep.getAbsolutePath();
				if (!openRegistry()){
					triedFile = true;
					closeRegistry = true;
					timeoutLock.notifyAllWaiting();
					registryDatabase = null;
				}else{
					initialized = true;
					closeRegistry();
				}
			}catch(Exception e){
				triedFile = true;
				return null;
			}
		}
	}
	*/
	if (root == 0) {
		StringBuffer sb = new StringBuffer();
		root = toRootAndPath(path,sb);
		path = sb.toString();
	}
	return getKey(false,root,path,createIfDoesntExist);
}
static boolean remoteLoaded = false;
static boolean remoteInitialized = false;
/**
* Gets a remote key. evex.Rapi.initialize() must be called first. If the evex_remote_registry.dll could not
* be loaded, this will return null.<p>If the path or root specified is invalid for any reason, it will
* return null. If the evex_registry.dll could not be loaded, it will return null.<p>
* Note that the path MUST be separated by '\' characters and NOT '/' characters.<p>
* If a <b>root</b> of 0 is used, it will be assumed that the path will start with "HKEY_CLASSES_ROOT\..."
* or one of the other text representation of the roots. These roots are:<br>
* "HKEY_CLASSES_ROOT","HKEY_CURRENT_USER","HKEY_LOCAL_MACHINE","HKEY_USERS","HKEY_CURRENT_CONFIG","HKEY_DYN_DATA"
**/
//===================================================================
public static IRegistryKey getRemoteKey(int root,String path,boolean fullAccess,boolean createIfDoesntExist)
//===================================================================
{
	if (!remoteLoaded){
		remoteLoaded = true;
		remoteInitialized = loadLibrary("evex_remote_registry");
	}
	if (!remoteInitialized) return null;
	if (root == 0) {
		StringBuffer sb = new StringBuffer();
		root = toRootAndPath(path,sb);
		path = sb.toString();
	}
	return getKey(true,root,path,createIfDoesntExist);
}

//===================================================================
public static boolean isInitialized(boolean forRemote)
//===================================================================
{
	if (forRemote){
		if (!remoteLoaded){
			remoteLoaded = true;
			remoteInitialized = loadLibrary("evex_remote_registry");
		}
		return remoteInitialized;
	}
	else
		return initialized;
}

/**
* Returns true if a TRUE native registry is available. False if not.
**/
//===================================================================
public static boolean isNativeInitialized()
//===================================================================
{
	return nativeInitialized;	
}
public static final int PLATFORM_WIN32s             = 0;
public static final int PLATFORM_WIN32_WINDOWS      = 1;
public static final int PLATFORM_WIN32_NT           = 2;
public static final int PLATFORM_LINUX           = 100;
public static final int PLATFORM_UNKNOWN           = -1;

public static final int NOT_INITIALIZED_ERROR = -1;

//===================================================================
public static int getPlatform()
//===================================================================
{
	if (!initialized) return NOT_INITIALIZED_ERROR;
	return nativeGetPlatform();
}
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_WINDOWS            = -1;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_DESKTOP            = 0x0000;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_PROGRAMS           = 0x0002;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_CONTROLS           = 0x0003;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_PRINTERS           = 0x0004;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_PERSONAL           = 0x0005;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_FAVORITES          = 0x0006;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_STARTUP            = 0x0007;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_RECENT             = 0x0008;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_SENDTO             = 0x0009;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_BITBUCKET          = 0x000a;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_STARTMENU          = 0x000b;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_DESKTOPDIRECTORY   = 0x0010;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_DRIVES             = 0x0011;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_NETWORK            = 0x0012;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_NETHOOD            = 0x0013;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_FONTS		 	  = 0x0014;
/**@deprecated - use getSystemFolder() with a SYSTEM_FOLDER_XXX value instead. **/
public static final int FOLDER_TEMPLATES          = 0x0015;
//===================================================================

//-------------------------------------------------------------------
private native static String nativeGetSpecialFolder(int folder);
//-------------------------------------------------------------------

/**
 * A value of folder for getSystemFolder().
 */
public static final int SYSTEM_FOLDER_WINDOWS = -1;//FOLDER_WINDOWS;
/**
 * A value of folder for getSystemFolder().
 */
public static final int SYSTEM_FOLDER_DESKTOP = 0;//FOLDER_DESKTOP
/**
 * A value of folder for getSystemFolder().
 */
public static final int SYSTEM_FOLDER_STARTMENU = 0x000b;//FOLDER_STARTMENU
/**
 * A value of folder for getSystemFolder().
 */
public static final int SYSTEM_FOLDER_DOCUMENTS_AND_SETTINGS = 1;
/**
 * A value of folder for getSystemFolder().
 */
public static final int SYSTEM_FOLDER_MY_DOCUMENTS = 100;

/**
 * An option for getSpecialFolder() - indicates that the folder for "All Users"
 * should be used. If it is not specified then the folder for the current user
 * is used.
 */
public static final int OPTION_ALL_USERS = 0x1;

private static String getWindowsDir() throws IOException
{
	String windows = nativeGetSpecialFolder(FOLDER_WINDOWS);
	if (windows == null){
		if (getPlatform() == PLATFORM_WIN32_NT){
			windows = "C:\\Winnt";
			if (!File.getNewFile(windows).isDirectory()) windows = "C:\\Windows";
		}else
			windows = "C:\\Windows";
	}
	if (!File.getNewFile(windows).isDirectory()) return null;
	return windows;
}
private static String cantFind(String what) throws IOException
{
	throw new IOException("Could not determine "+what+" directory.");
}
private static File getSubFolder(int folder, File src)
{
	if (folder != SYSTEM_FOLDER_DOCUMENTS_AND_SETTINGS){
		String sub = "My Documents";
		switch(folder){
			case SYSTEM_FOLDER_DESKTOP: sub = "Desktop"; break;
			case SYSTEM_FOLDER_STARTMENU: sub = "Start Menu"; break;
			case SYSTEM_FOLDER_MY_DOCUMENTS: sub = "My Documents"; break;
		}
		src = src.getChild(sub);
	}
	if (src.isDirectory()) return src;
	return null;
}
/**
 * Get the path to the specified system folder.
 * @param folder one of the SYSTEM_FOLDER_XXX values.
 * @param options any of the OPTION_XXX values OR'ed together.
 * @return the path to the specified folder.
 * @throw java.io.IOException if the folder could not be determined or an IOException
 * occured trying to find it.
 */
public static String getSystemFolder(int folder, int options) throws IOException
{
	boolean allUsers = (options & OPTION_ALL_USERS) != 0;
	String lookFor = "Windows";
	switch(folder){
	case SYSTEM_FOLDER_DESKTOP: lookFor = "Desktop"; break;
	case SYSTEM_FOLDER_STARTMENU: lookFor = "Start Menu"; break;
	case SYSTEM_FOLDER_WINDOWS: lookFor = "Windows"; break;
	case SYSTEM_FOLDER_DOCUMENTS_AND_SETTINGS: lookFor = "Documents and Settings"; break;
	case SYSTEM_FOLDER_MY_DOCUMENTS: lookFor = "My Documents"; break;
	default:
		throw new IOException("Unknown folder: "+folder);
	}
	if (folder == SYSTEM_FOLDER_WINDOWS){
		String ret = getWindowsDir();
		if (ret == null) return cantFind(lookFor); 
	}
	//
	if (false){
		IRegistryKey rk = getLocalKey(HKEY_CURRENT_USER, "Volatile Environment", false, false);
		if (rk != null){
			StringBuffer user = new StringBuffer();
			Object got = rk.getValue("HOMEDRIVE");
			if (got != null) user.append(got);
			got = rk.getValue("HOMEPATH");
			if (got != null) user.append(got);
			File f = new File(user.toString());
			if (f.isDirectory()){
				if (allUsers){
					File forAll = f.getParentFile();
					if (forAll != null) forAll = forAll.getChild("All Users");
					if (forAll.isDirectory()) f = forAll;
				}
				f = getSubFolder(folder, f);
				if (f != null) return f.getAbsolutePath();
			}
		}
	}
	//
	String windows = getWindowsDir();
	if (windows == null) return cantFind(lookFor);
	//
	String base = null;
	String user = Vm.getProperty("user", null);
	if (user == null) user = Vm.getProperty("username", null);
	if (allUsers) user = "All Users";
	if (getPlatform() == PLATFORM_WIN32_NT){
		base = windows+"\\Documents and Settings\\"+user;
		if (!File.getNewFile(base).isDirectory())
			base = "c:\\Documents and Settings\\"+user;
		if (!File.getNewFile(base).isDirectory())
			base = windows+"\\Profiles\\"+user;
	}else{
		base = windows+"\\"+user;
	}
	//
	File f = getSubFolder(folder,File.getNewFile(base));
	if (f != null) return f.getAbsolutePath();
	if (folder == SYSTEM_FOLDER_MY_DOCUMENTS) f = File.getNewFile("C:\\My Documents");
	if (f.isDirectory()) return f.getAbsolutePath();
	return cantFind(lookFor);
}
/**
 * @deprecated use getSystemFolder() with the SYSTEM_FOLDER_XXX values instead.
 */
public static String getSpecialFolder(int folder)
//===================================================================
{
	try{
		switch(folder){
		case FOLDER_DESKTOP: return getSystemFolder(SYSTEM_FOLDER_DESKTOP, OPTION_ALL_USERS);
		case FOLDER_STARTMENU: return getSystemFolder(SYSTEM_FOLDER_STARTMENU, OPTION_ALL_USERS);
		case FOLDER_WINDOWS: return getSystemFolder(SYSTEM_FOLDER_WINDOWS, OPTION_ALL_USERS);
		}
	}catch(IOException e){
		return null;
	}
	
	if (folder == FOLDER_DESKTOP || folder == FOLDER_STARTMENU){
		IRegistryKey rk = getLocalKey(HKEY_CURRENT_USER, "Volatile Environment", false, false);
		if (rk != null){
			StringBuffer user = new StringBuffer();
			Object got = rk.getValue("HOMEDRIVE");
			if (got != null) user.append(got);
			got = rk.getValue("HOMEPATH");
			if (got != null) user.append(got);
			File f = new File(user.toString());
			if (f.isDirectory()){
				File forAll = f.getParentFile();
				if (forAll != null) forAll = forAll.getChild("All Users");
				if (forAll.isDirectory()) f = forAll;
				String sub = folder == FOLDER_DESKTOP ? "Desktop" : "Start Menu";
				return f.getChild(sub).getAbsolutePath();
			}
		}
	}
	String got = nativeGetSpecialFolder(folder);
	if (got != null) return got;
	String windows = nativeGetSpecialFolder(FOLDER_WINDOWS);
	if (windows == null){
		if (getPlatform() == PLATFORM_WIN32_NT){
			windows = "C:\\Winnt";
			if (!File.getNewFile(windows).exists()) windows = "C:\\Windows";
		}else
			windows = "C:\\Windows";
	}
	if (getPlatform() == PLATFORM_WIN32_NT){
		switch(folder){
			case FOLDER_STARTMENU:
				String ret = windows+"\\Profiles\\All Users\\Start Menu";
				if (!File.getNewFile(ret).exists()) ret = "C:\\Documents and Settings\\All Users\\Start Menu";
				return ret;
			case FOLDER_PROGRAMS:
				return "C:\\Program Files";
		}
	}else{
		switch(folder){
			case FOLDER_STARTMENU:
				return windows+"\\Start Menu";
			case FOLDER_PROGRAMS:
				return "C:\\Program Files";
		}
	}
	return null;
}
//-------------------------------------------------------------------
private native static int nativeGetPlatform();
//-------------------------------------------------------------------
/**
 * An option for createShortcut() - specifies that the name should be 
 * used exactly as is without any attempt to modify it by adding or
 * changing the extension.
 */
public static final int SHORTCUT_OPTION_USE_EXACT_NAME = 0x1;
/**
 * A return value for createShortcut() - indicates that the description
 * was not used because it is not supported by the OS.
 */
public static final int SHORTCUT_RETURN_DESCRIPTION_NOT_USED = 0x1;
/**
 * Create a shortcut (link) to a target executable.
 * @param targetExe the full path to the target executable.
 * @param targetArguments the full argument string to pass to the executable.
 * @param shortcutPath the full path to the created shortcut.
 * @param description a user description for the shortcut. 
 * @param options any of the SHORTCUT_OPTION_XXX values OR'ed together.
 * @return any of the SHORTCUT_RETURN_XXX values OR'ed together.
 * @throws IOException if it could not be created.
 */
public native static int createShortcut(String targetExe, String targetArguments, String shortcutPath, String description, int options)
throws IOException;

/**
 * @deprecated
 * @param target
 * @param arguments
 * @param shortcutPath
 * @return
 */
public static boolean createShortcut(String target,String arguments,String shortcutPath)
{
	try{
		createShortcut(target,arguments,shortcutPath,null,0);
		return true;
	}catch(IOException e){
		return false;
	}
}
//===================================================================


//##################################################################
}
//##################################################################

/*
//##################################################################
class FileRegistryKey extends RegistryKey{
//##################################################################

//-------------------------------------------------------------------
FileRegistryKey(boolean isRemote,int root,String path,boolean fullAccess,boolean createIfDoesntExist)
//-------------------------------------------------------------------
{
	this.root = root;
	this.path = path;
	this.fullAccess = fullAccess;
	this.createIfDoesntExist = createIfDoesntExist;
	this.isRemote = isRemote;
	
	this.isValid = checkValid();
}

private DataEntry myEntry;
private DataEntryData myData;
private TextDecoder myEncodedData;

//-------------------------------------------------------------------
private DataEntry toDataEntry()
//-------------------------------------------------------------------
{
	myEntry = null;
	myData = null;
	myEncodedData = null;
	String path = Registry.roots[root]+"\\"+this.path;
	if (!Registry.openRegistry()) return null;
	else try{
		DataEntry root = Registry.registry.getRootEntry();
		myEntry = root.find(path.replace('/','_').replace('\\','/'),createIfDoesntExist);
		if (myEntry == null) throw new NullPointerException();
		myData = myEntry.getData();
		if (myData != null)
			myEncodedData = new TextDecoder(myData.getFieldString(Database.OBJECT_TEXT_FIELD,""));
		else
			myEncodedData = new TextDecoder("");
		return myEntry;
	}catch(Exception e){
		Registry.closeRegistry();
		return null;
	}
}

//-------------------------------------------------------------------
private boolean update()
//-------------------------------------------------------------------
{
	try{
		String updated = myEncodedData.encode();
		myData.setFieldValue(Database.OBJECT_TEXT_FIELD,updated);
		myData.save();
		//ewe.sys.Vm.debug(updated);
		return true;
	}catch(Exception e){
		return false;
	}
}
//-------------------------------------------------------------------
private boolean updateAndSave(String name,String value)
//-------------------------------------------------------------------
{
	if (name == null) name = "";
	if (value == null) value = "";
	try{
		//ewe.sys.Vm.debug("Setting: "+name+" to be "+value);
		myEncodedData.setValue(name,value);
		return update();
	}catch(Exception e){
		return false;
	}
}
//-------------------------------------------------------------------
protected  boolean getIndexedValue(int index,RegistryData data)
//-------------------------------------------------------------------
{
	DataEntry key = toDataEntry();
	if (key == null) return false;
	else try{
		String value = myEncodedData.getValue(index);
		if (value == null) return false;
		String name = myEncodedData.getName(index);
		if (name == null) name = "";
		if (name.endsWith("$i")){
			data.name = name.substring(0,name.length()-2);
			data.intValue = ewe.sys.Convert.toInt(value);
		}else{
			data.name = name;
			data.value = value;
		}
		return true;
	}catch(Exception e){
		return false;
	}finally{
		Registry.closeRegistry();
	}
}
//-------------------------------------------------------------------
protected boolean getNamedValue(String name,RegistryData data)
//-------------------------------------------------------------------
{
	DataEntry key = toDataEntry();
	if (key == null) return false;
	else try{
		try{		
			String value = myEncodedData.getValue(name);
			if (value == null) {
				value = myEncodedData.getValue(name+"$i");
				if (value != null){
					data.intValue = ewe.sys.Convert.toInt(value);
					return true;
				}else
					return false;
			}else{
				data.value = value;
			}
		}catch(Exception e){
			return false;
		}
		return true;
	}finally{
		Registry.closeRegistry();
	}
}

//-------------------------------------------------------------------
protected boolean setAStringValue(String name,String value)
//-------------------------------------------------------------------
{
	DataEntry key = toDataEntry();
	if (key == null) return false;
	else try{
		return updateAndSave(name,value);
	}finally{
		Registry.closeRegistry();
	}
}
//-------------------------------------------------------------------
protected boolean setABinaryValue(String name,byte [] value)
//-------------------------------------------------------------------
{
	if (true) return false;
	try{
		DataEntry key = toDataEntry();
		if (key == null) 
			return false;
		return true;
	}finally{
		Registry.closeRegistry();
	}
}
//-------------------------------------------------------------------
protected boolean setAnIntValue(String name,int value)
//-------------------------------------------------------------------
{
	return setAStringValue(name+"$i",""+value);
}
//-------------------------------------------------------------------
protected boolean deleteAValue(String name)
//-------------------------------------------------------------------
{
	DataEntry key = toDataEntry();
	if (key == null) return false;
	else try{
		if (name == null) name = "";
		myEncodedData.deleteValue(name);
		return update();
	}catch(Exception e){
		return false;
	}
}
//-------------------------------------------------------------------
protected boolean deleteAKey()
//-------------------------------------------------------------------
{
	DataEntry key = toDataEntry();
	if (key == null) return false;
	else try{
		try{
			return key.delete();
		}catch(Exception e){
			return false;
		}
	}finally{
		Registry.closeRegistry();
	}
}
//-------------------------------------------------------------------
protected boolean checkValid()
//-------------------------------------------------------------------
{
	DataEntry key = toDataEntry();
	if (key == null) return false;
	else try{
		return true;
	}finally{
		Registry.closeRegistry();
	}
}

//===================================================================
public String getSubKey(int index)
//===================================================================
{
	DataEntry key = toDataEntry();
	if (key == null) return null;
	else try{
		try{
			int i = 0;
			for (DataEntry de = key.getFirstChild(); de != null; de = de.getNext()){
				if (i == index) return de.getName();
				else i++;
			}
			return null;
		}catch(Exception e){
			return null;
		}
	}finally{
		Registry.closeRegistry();
	}
}

//===================================================================
public Object getSubKeys(int options)
//===================================================================
{
	DataEntry key = toDataEntry();
	if (key == null) return null;
	else try{
		String [] names = null;
		Vector v = new Vector();
		int num = 0;
		//
		boolean sorted = (options & SORT_DONT_SORT) == 0;
		boolean indexes = (options & (GET_INDEXES_AS_LONGS|GET_INDEXES)) != 0;
		boolean keepNames = sorted || !indexes;
		int sort = 0;
		if ((options & SORT_CASE_SENSITIVE) == 0) sort |= ewe.sys.Locale.IGNORE_CASE;
		//
		DataEntry de = key.getFirstChild();
		for (num = 0; de != null; num++){
			if (keepNames) v.add(de.getName());
			de = de.getNext();
		}
		//
		if (keepNames) {
			names = new String[num];
			v.copyInto(names);
			v.clear();
		}
		//
		int [] ids = new int[num];
		ewe.util.Utils.getIntSequence(ids,0);
		if (sorted){
			boolean descending = ((options & SORT_DESCENDING) != 0);
			ewe.util.Utils.sort(ids,ids.length,new CompareArrayElements(names,ewe.sys.Vm.getLocale().getStringComparer(sort)),descending);
			Object [] newVals = new Object[names.length];
			for (int i = 0; i<num; i++) newVals[i] = names[ids[i]];
			ewe.sys.Vm.copyArray(newVals,0,names,0,num);
		}
		//
		if (!indexes) return names;
		//
		if ((options & GET_INDEXES_AS_LONGS) != 0){
			long [] ret = new long[num];
			for (int i = 0; i<num; i++)
				ret[i] = ids[i];
			return ret;
		}else{
			return ids;
		}
	}catch(Exception e){
		return null;
	}finally{
		Registry.closeRegistry();
	}
}
//===================================================================
public int getSubKeyCount()
//===================================================================
{
	DataEntry key = toDataEntry();
	if (key == null) return 0;
	else try{
		try{
			int i = 0;
			for (DataEntry de = key.getFirstChild(); de != null; de = de.getNext())
				i++;
			return i;
		}catch(Exception e){
			return 0;
		}
	}finally{
		Registry.closeRegistry();
	}
}
//===================================================================
public RegistryKey getCopy()
//===================================================================
{
	return new FileRegistryKey(isRemote,root,path,fullAccess,createIfDoesntExist);
}

//##################################################################
}
//##################################################################
*/
/*
//##################################################################
class FileRegistryKey extends RegistryKey{
//##################################################################
public String name = "";
public String savedData = "";
public int type = 0;

public static final int TYPE_NODE = 0;
public static final int TYPE_STRING = 1;
public static final int TYPE_INTEGER = 2;
public static final int TYPE_BYTE_ARRAY = 3;

//-------------------------------------------------------------------
String stripSlashes(String path)
//-------------------------------------------------------------------
{
	while (path.startsWith("\\")) path = path.substring(1);
	while (path.endsWith("\\")) path = path.substring(0,path.length()-1);
	return path;
}
//-------------------------------------------------------------------
FileRegistryKey(boolean isRemote,int root,String path,boolean fullAccess,boolean createIfDoesntExist)
//-------------------------------------------------------------------
{
	this.root = root;
	this.path = stripSlashes(path);
	this.fullAccess = fullAccess;
	this.createIfDoesntExist = createIfDoesntExist;
	this.isRemote = isRemote;
	this.isValid = checkValid();
}

//private DatabaseEntry myEntry;

//===================================================================
public RegistryKey getCopy()
//===================================================================
{
	return new FileRegistryKey(isRemote,root,path,fullAccess,createIfDoesntExist);
}
//-------------------------------------------------------------------
private Database openRegistry()
//-------------------------------------------------------------------
{
	if (!Registry.openRegistry()) return null;
	return Registry.registry;
}
//-------------------------------------------------------------------
private void closeRegistry()
//-------------------------------------------------------------------
{
	Registry.closeRegistry();
}
//-------------------------------------------------------------------
private DatabaseEntry getEntryFor(String fullPath)
//-------------------------------------------------------------------
{
	Database db = openRegistry();
	if (db == null) return null;
	try{
		int sort = db.findSort("ByPath");
		FoundEntries fe = db.getFoundEntries(null,sort,new EntrySelector(db,fullPath,sort,false));
		if (fe.size() != 0) return fe.get(0);
		if (createIfDoesntExist) return fe.getNew();
		return null;
	}catch(IOException e){
		return null;
	}
}
//-------------------------------------------------------------------
private String toFullPath(String name)
//-------------------------------------------------------------------
{
	String full = path;
	if (root != 0) {
		full = Registry.roots[root];
		if (path != null && path.length() != 0)
			full += "\\"+path;
	}
	full += "\\"+(name == null ? "" : stripSlashes(name));
	return full;
}
//-------------------------------------------------------------------
private String toFullPath()
//-------------------------------------------------------------------
{
	String full = path;
	if (root != 0) {
		full = Registry.roots[root];
		if (path != null && path.length() != 0)
			full += "\\"+path;
	}
	return full;
}
//-------------------------------------------------------------------
protected boolean setAnIntValue(String name,int value)
//-------------------------------------------------------------------
{
	return setAValue(name,Convert.toString(value),TYPE_INTEGER);
}
//-------------------------------------------------------------------
protected boolean setAStringValue(String name,String value)
//-------------------------------------------------------------------
{
	return setAValue(name,value,TYPE_STRING);
}

//-------------------------------------------------------------------
private FoundEntries getEntries()
//-------------------------------------------------------------------
{
	Database db = openRegistry();
	if (db == null) return null;
	try{
		int sort = db.findSort("ByPath");
		return db.getFoundEntries(null,sort);
	}catch(IOException e){
		return null;
	}
}
//-------------------------------------------------------------------
protected boolean setAValue(String name, String textValue, int type)
//-------------------------------------------------------------------
{
	String full = toFullPath();
	name = stripSlashes(name);
	try{
		FoundEntries fe = getEntries();
		if (fe == null) return false;
		int first = fe.findFirst(null,new Object[]{full,name},false);
		int last = fe.findLast(null,new Object[]{full,name},false);
		DatabaseEntry de = null;
		RegistryEntry re = new RegistryEntry();
		for (int i = first; i >= 0 && i<=last; i++){
			fe.getData(i,re);
			if (re.type == TYPE_NODE) continue;
			de = fe.get(i);
			break;
		}
		if (de == null) de = fe.getNew(); 
		re.path = full;
		re.name = name;
		re.value = textValue;
		re.type = type;
		de.setData(re);
		try{
			de.save();
		}catch(IOException e){
			e.printStackTrace();
			return false;
		}
	}catch(Exception e){
		e.printStackTrace();
		return false;
	}finally{
		closeRegistry();
	}
	return true;
}

//-------------------------------------------------------------------
private String[] getSubKeys() throws IOException
//-------------------------------------------------------------------
{
	try{
		String mask = toFullPath("*");
		FoundEntries fe = getEntries();
		int first = fe.findFirst(null,mask,true);
		if (first == -1) return new String[0];
		int last = fe.findLast(null,mask,true);
		Vector v = new Vector();
		RegistryEntry re = new RegistryEntry();
		int lookFrom = mask.length()-1;
		for (int i = first; i <= last; i++){
			fe.getData(i,re);
			if (re.path.indexOf('\\',lookFrom) != -1) continue;
			if (re.type != TYPE_NODE) continue;
			v.add(re.path.substring(lookFrom));
		}
		String[] ret = new String[v.size()];
		v.copyInto(ret);
		return ret;
	}catch(HandleStoppedException e){
		return new String[0];
	}finally{
		closeRegistry();
	}
}
//===================================================================
public int getSubKeyCount()
//===================================================================
{
	try{
		return getSubKeys().length;
	}catch(IOException e){
		return 0;
	}
}
//===================================================================
public String getSubKey(int index)
//===================================================================
{
	try{
		return getSubKeys()[index];
	}catch(Exception e){
		return null;
	}
}
//===================================================================
public Object getSubKeys(int options)
//===================================================================
{
	try{
		boolean indexes = (options & (GET_INDEXES_AS_LONGS|GET_INDEXES)) != 0;
		String[] all = getSubKeys();
		int num = all.length;
		int [] ids = new int[num];
		if ((options & SORT_DESCENDING) != 0)
			ewe.util.Utils.getIntSequence(ids,0,num-1,-1,num);
		else
			ewe.util.Utils.getIntSequence(ids,0);
		//
		if (!indexes) return all;
		//
		if ((options & GET_INDEXES_AS_LONGS) != 0){
			long [] ret = new long[num];
			for (int i = 0; i<num; i++)
				ret[i] = ids[i];
			return ret;
		}else{
			return ids;
		}
	}catch(Exception e){
		return null;
	}
}
//-------------------------------------------------------------------
protected boolean checkValid()
//-------------------------------------------------------------------
{
	String path = toFullPath();
	try{
		FoundEntries fe = getEntries();
		if (fe == null) return false;
		int last = -1;
		RegistryEntry re = new RegistryEntry();
		while(true){
			last = path.indexOf('\\',last+1);
			String toCheck = last == -1 ? path : path.substring(0,last);
			try{
				int got = fe.findFirst(null,new Object[]{toCheck,""},false);
				if (got == -1){
					//Not found - so add if necessary.
					if (!createIfDoesntExist) return false;
					DatabaseEntry de = fe.getNew();
					re.path = toCheck;
					re.name = re.value = "";
					re.type = TYPE_NODE;
					de.setData(re);
					fe.add(de);
				}
			}catch(HandleStoppedException e){}
			if (last == -1) return true;
		}
	}catch(IOException e){
		return false;
	}finally{
		closeRegistry();
	}
}
//-------------------------------------------------------------------
private EntriesView getValues(String name) throws IOException
//-------------------------------------------------------------------
{
	FoundEntries fe = getEntries();
	EntriesView ev = fe.getEmptyView();
	Object search = toFullPath();
 	if (name != null) search = new Object[]{search,name};
	ev.search(null,search,false);
	if (ev.size() > 0){
		RegistryEntry re = new RegistryEntry();
		ev.getData(0,re);
		if (re.type == TYPE_NODE) ev.excludeAt(0);
	}
	return ev;
}
//-------------------------------------------------------------------
protected boolean getIndexedValue(int index,RegistryData data)
//-------------------------------------------------------------------
{
	try{
		EntriesView ev = getValues(null);
		if (index >= ev.size() || index < 0)
			return false;
		RegistryEntry re = new RegistryEntry();
		ev.getData(index,re);
		data.name = re.name;
		if (re.type == TYPE_INTEGER)
			data.intValue = ewe.sys.Convert.toInt(re.value);
		else
			data.value = re.value;
		return true;
	}catch(Exception e){
		return false;
	}finally{
		closeRegistry();
	}
}
//-------------------------------------------------------------------
protected boolean getNamedValue(String name,RegistryData data)
//-------------------------------------------------------------------
{
	try{
		EntriesView ev = getValues(name);
		if (ev.size() == 0) return false;
		RegistryEntry re = new RegistryEntry();
		ev.getData(0,re);
		data.name = re.name;
		if (re.type == TYPE_INTEGER)
			data.intValue = ewe.sys.Convert.toInt(re.value);
		else
			data.value = re.value;
		return true;
	}catch(Exception e){
		return false;
	}finally{
		closeRegistry();
	}
}
//##################################################################
}
//##################################################################
*/

