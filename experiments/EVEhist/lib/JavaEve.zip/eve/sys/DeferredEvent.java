/*
 * Created on Apr 6, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;


/**
 * @author Michael L Brereton
 * This is an Event that is an explicit <i>carrier</i> of another Event. The <b>cause</b>
 * field of this Event holds the origial Event that is being deferred somehow.
 */
//####################################################
public class DeferredEvent extends Event {

	public DeferredEvent(Event toDefer, EventListener destination)
	{
		cause = toDefer;
		target = destination;
	}
}
//####################################################
