package eve.sys;

import eve.util.Tag;
import java.util.Vector;
/**
* A ThreadPool represents a pool of running Threads that are waiting for tasks to run.
* You call addTask() to add a Task Object to the pool and an idle Thread is assigned
* to run the task. If no idle Thread is available a new one is created and used. ThreadPools
* can greatly improve performance in server applications since it reduces the overhead of
* creating new Threads. 
* <p>
* You can specify a minimum number of idle Threads and Threads are added to the pool
* to make up to that minimum.
* <p>
* You can specify a maximum number of Threads. If the maximum is reached all new tasks
* will have to wait until older ones are finished and their Threads are freed. If all
* Threads are idle and there are more idle threads than the specified minimum, the Threads
* will eventually terminate and be discarded until only the minimum number of Threads
* remain.
**/
//##################################################################
public class ThreadPool extends Task{
//##################################################################
/**
* The minimum number of allowed threads. By default this is 10.
**/
public int minThreads = 10;
/**
* The maximum number of allowed threads. If this is <0 there is no maximum (the default).
**/
public int maxThreads = -1;
/**
* How long (in <b>seconds</b>) before an idle thread decides to exit (if there are no tasks
* to run and if the number of threads is already greater than the minimum). By default it
* is 5.
**/
public int waitTime = 5;

int totalCreated = 0;
boolean threadsAreDaemon;

/**
 * Create a ThreadPool with a minimum of 10 threads and no maximum.
 */
//==================================================================
public ThreadPool() {this(10,-1);}
//==================================================================
/**
 * Create a ThreadPool specifying the minimum and maximum number of threads.
 */
//==================================================================
public ThreadPool(int min,int max)
//==================================================================
{
	this(min,max,false,false);
}
public ThreadPool(int min,int max,boolean iAmDaemon,boolean threadsAreDaemon)
//==================================================================
{
	minThreads = min;
	maxThreads = max;
	makeUpToMinimum();
	setDaemon(iAmDaemon);
	this.threadsAreDaemon = threadsAreDaemon;
	start();
	Thread.yield();
}
// There IS a reason I do not use this ThreadPool Object to synchronize the 
// pool threads. I use this waitOn object instead.
Object waitOn = new Object();

Vector waitingJobs = new Vector(), runningJobs = new Vector();
int active, waiting;

//------------------------------------------------------------------
void addToPool()
//------------------------------------------------------------------
{
	synchronized(waitOn){
		poolThread t = new poolThread();
		t.setDaemon(threadsAreDaemon);
		//t.index = ++totalCreated;
		t.start();
		active++;
		//System.out.println("Added: "+t.index);
	}
}
/**
* Add threads until the minimum has been achieved. If you have increased the minimum
* then you can optionally call this.
**/
//==================================================================
public void	makeUpToMinimum()
//==================================================================
{
	synchronized(waitOn){
		int min = minThreads;
		if (min > maxThreads && maxThreads > 0) min = maxThreads;
		if (min < 0) min = 4;
		int toAdd = min-active;
		for (int i = 0; i<toAdd; i++) addToPool();
	}
}

//-------------------------------------------------------------------
protected void doRun()
//-------------------------------------------------------------------
{
	//new addJobThread().start();
	try{
		while(!shouldStop || runningJobs.size() != 0){
			if (!shouldStop) makeUpToMinimum();
			checkTimeOuts();
			
//			Do not wait on waitOn - I only call watOn.notify(), not waitOn.notifyAll()
//			when I want to indicate that there is a task to run. Therefore only
//          Threads should be waiting on waitOn.
			
			sleep(1000); 
		}
	}finally{
		synchronized(waitOn){
			shouldStop = true;
			waitOn.notifyAll();
		}
	}
}
//-------------------------------------------------------------------
void checkTimeOuts()
//-------------------------------------------------------------------
{
	synchronized(waitOn){
		try{
			int sz = runningJobs.size();
			for (int i = 0; i<sz; i++){
				poolThread pt = (poolThread)runningJobs.get(i);
				pt.checkTimeOut();
			}
		}catch(Exception e){}
	}
}
/**
* Use this to add a task to run. This should be a Runnable, including a TaskObject.
* @param toRun The task to run.
* @param timeOutInSeconds A maximum length of time for the task to run for. If this is
* zero or less then the task will have no maximum time.
* @exception IllegalStateException if the ThreadPool is closed.
*/
//==================================================================
public void addTask(Runnable toRun,int timeOutInSeconds)  throws IllegalStateException
//==================================================================
{
	if (shouldStop) throw new IllegalStateException("The ThreadPool is closed."); 
	if (toRun == null) return;
	synchronized(waitOn){
		Tag t = new Tag();
		t.tag = timeOutInSeconds;
		t.value = toRun;
		waitingJobs.add(t);
		//System.out.println("Waiting threads: "+waiting);
		//System.out.println("W: "+waiting+" A: "+active);			
		if ((waiting < waitingJobs.size()) && ((active < maxThreads) || (maxThreads <= 0)))
			addToPool();
		if (waiting != 0) waiting--;
		waitOn.notify(); //Only notifying one! Therefore ONLY a poolThread should wait on it.
	}
}
/*
private boolean creating; 
private Runnable created;

private static final String ReusedName = "-reused-";
private RunReusedTask runReused = new RunReusedTask();
//
class RunReusedTask implements Runnable{
	public void run(){
		Runnable r = (Runnable)mThread.getResource(ReusedName);
		if (r == null) {
			r = createReusedTask();
			mThread.putResource(ReusedName,r);
		}
		if (r instanceof Handle){
			((Handle)r).set(Handle.Running);
			((Handle)r).setProgress(0);
		}
		synchronized(ThreadPool.this){
			created = r;
			ThreadPool.this.notifyAll();
		}
		r.run();
	}
}
//
protected Runnable createReusedTask()
{
	return new Runnable(){
		public void run(){
			System.out.println("There is no task to run!");
		}
	};
}
*/
/**
* Use this to add a task to run. This should be a Runnable, including a TaskObject.
* @param toRun The task to run.
* @exception IllegalStateException if the ThreadPool is closed.
*/
//==================================================================
public void addTask(Runnable toRun) throws IllegalStateException
//==================================================================
{
	addTask(toRun,-1);
}
/*
public void runReusedTask() throws IllegalStateException
{
	addTask(runReused,-1);
}
*/
/**
 * Start running a re-used task and wait until the task is known.
 * @return the re-used task that is being run. If it is a Task or a Handle of any
 * kind, its state is reset to Running and the progress to zero by the external
 * Thread before being available.
 * @throws IllegalStateException if the ThreadPool is closed.
 */
/*
public synchronized Runnable startReusedTask() throws IllegalStateException
{
	while(creating){ 
		try{
			wait();
		}catch(InterruptedException e){}
	}
	creating = true;
	created = null;
	runReusedTask();
	while(created == null){
		try{
			wait();
		}catch(InterruptedException e){}
	}
	Runnable ret = created;
	created = null;
	creating = false;
	notifyAll();
	return ret;
}
*/
static int numberAlive = 0;
/**
* After calling this no more tasks can be added and any spare threads
* will eventually die.
**/
//===================================================================
public void close()
//===================================================================
{
	stop(0);
}
//##################################################################
class poolThread extends Task{
//##################################################################

//int index;
TimeOut curTimeout;
Handle curHandle;

poolThread()
{
	numberAlive++;
	//ewe.sys.Vm.debug("Starting: "+numberAlive);
}

void checkTimeOut()
{
	if (curTimeout == null || curHandle == null) return;
	if (curTimeout.hasExpired()) {
		//ewe.sys.Vm.debug("Have to timeout!");
		curHandle.stop(0);
		curTimeout = null;
	}
}
protected void doRun()
{
	try{
		boolean idle = false;
		while(true) {
			Runnable toRun = null;
			synchronized(waitOn){
				if (waitingJobs.size() == 0) {
					if (ThreadPool.this.shouldStop || shouldStop || ((active > minThreads) && idle)) {
						active--;
						return;
					}
					idle = true;
					waiting++;
					try {
						waitOn.wait(waitTime*1000);
					}catch(Exception e){}
					if (waitingJobs.size() == 0) waiting--;
					continue;
				}else {
					Tag got = (Tag)waitingJobs.get(0);
					waitingJobs.removeElementAt(0);
					curTimeout = (got.tag <= 0) ? null : new TimeOut(got.tag*1000);
					curHandle = (got.value instanceof Task) ? ((Task)got.value) : null;
					runningJobs.add(this);
					toRun = (Runnable)got.value;
				}
			}
			if (toRun != null) {
				idle = false;
				try{
					toRun.run();
				}catch(RuntimeException e){
				}finally{
					toRun = null;
					Thread.interrupted();
					synchronized(waitOn){
						runningJobs.remove(this);
					}
				}
			}
		}	
	}finally{
		numberAlive--;
		//ewe.sys.Vm.debug("Leaving: "+numberAlive);
	}
}
//##################################################################
}
//##################################################################


//##################################################################
}
//##################################################################

