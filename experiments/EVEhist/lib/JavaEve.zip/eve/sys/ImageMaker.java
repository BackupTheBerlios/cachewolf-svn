/*
 * Created on Jan 2, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface ImageMaker {

/**
 * This is called at the start of decoding - to let the ImageMaker know the parameters
 * of the image to be created. The minimum this will provide is the width and height
 * of the image - but other information may not be available. No matter what type of
 * image is being decoded the pixels are always provided in ARGB int format using
 * setScanLinePixels.
 * @param imageInfo information on the image to be decoded.
 * @throws IllegalArgumentException if the ImageMaker decides it cannot create the image.
 */
public void createImageFor(ImageDataInfo imageInfo) throws IllegalArgumentException;
/**
 * This is used when decoding images. 
 * For certain interlaced images the pixels on a scan line are not
 * available as a single sequence of pixels, but rather as pixels that
 * are spaced at fixed distances apart on the scan line.<p>
 * @param scanLine the scan line being set.
 * @param pixels an array containing the scan line ARGB pixel values.
 * @param offset the start of the pixel within the pixels array.
 * @param destX the x location where the first pixel should be placed.
 * @param destFrequency the distance between the pixels being provided. If this
 * value is 1, then the pixels are actually right next to each other. A value of
 * 2 means that every other pixel is being done.
 * @param numPixels the number of pixels being set. 
 * @param srcFrequency the distance between the pixels in the <b>pixels</b> array.
 * This will usually be 1 but may be any other distance.
 * @return true if the pixels were successfully set.
 */
public boolean setScanLinePixels(int scanLine, int[] pixels, int offset,int destX, int destFrequency, int numPixels, int srcFrequency);

/**
 * After decoding is done this is used to retrieve the fully decoded image.
 * @return the fully decoded image.
 */
public ImageData getImageData(); 
}
//####################################################
