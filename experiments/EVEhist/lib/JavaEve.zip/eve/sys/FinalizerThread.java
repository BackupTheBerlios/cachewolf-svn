/*
 * Created on Mar 13, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;
import eve.reflect.Method;
import eve.reflect.Reflect;
import eve.sys.Wrapper;
/**
 * @author Michael L Brereton
 *
 * This class is only used in the Native VM.
 */
//####################################################
class FinalizerThread extends Thread {

	private static native Object getNext();
	public void run()
	{
		Method m = null;
		try{
			m = new Reflect(Object.class).getMethod("finalize","()V",Reflect.SYSTEM);
		}catch(Exception e){
			return;
		}
		Wrapper[] args = new Wrapper[0];
		Wrapper dest = new Wrapper();
		while(true){
			Object obj = null;
			synchronized(this){
				while(true){
					mThread.nap(1);
					obj = getNext();
					if (obj != null) break;
					try{wait();} catch(Exception e){}
				}
			}
			try{
				//Vm.debug("--F");
				m.invoke(obj,args,dest);
			}catch(Throwable t){}
		}
	}
}
//####################################################
