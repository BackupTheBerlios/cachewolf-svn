/*
 * Created on Aug 13, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public final class Timer extends Thread{

	private WeakRef client;
	private long howLong;
	private long started;
	private Timer(TimerProc client, long howLong)
	{
		this.client = new WeakRef(client);
		this.howLong = howLong;
		started = System.currentTimeMillis();
		setDaemon(true);
		start();
	}
	public void run()
	{
		if (howLong != 0)
			try{
				sleep(howLong);
			}catch(Exception e){}
		long elapsed = System.currentTimeMillis()-started;
		if (elapsed < 0) elapsed = 0;
		TimerProc tp = (TimerProc)client.get();
		if (tp != null) tp.ticked(this,elapsed);
	}
	public static Object requestTick(TimerProc client,long durationInMillis)
	{
		if (client == null) throw new NullPointerException();
		if (durationInMillis < 0) throw new IllegalArgumentException();
		return new Timer(client,durationInMillis);
	}
}
//####################################################
