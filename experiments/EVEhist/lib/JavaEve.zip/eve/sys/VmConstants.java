package eve.sys;

//##################################################################
public interface VmConstants{
//##################################################################
/*
 *  flag values for fuSound and fdwSound arguments on [snd]PlaySound
 */
	/*
public static final int SND_SYNC            = 0x0000  ; // play synchronously (default) 
public static final int SND_ASYNC           = 0x0001  ; // play asynchronously 
public static final int SND_NODEFAULT       = 0x0002  ; // silence (!default) if sound not found 
public static final int SND_MEMORY          = 0x0004  ; // pszSound points to a memory file 
public static final int SND_LOOP            = 0x0008  ; // loop the sound until next sndPlaySound 
public static final int SND_NOSTOP          = 0x0010  ; // don't stop any currently playing sound 

public static final int SND_NOWAIT	= 0x00002000 ; // don't wait if the driver is busy 
public static final int SND_ALIAS       = 0x00010000 ; // name is a registry alias 
public static final int SND_ALIAS_ID	= 0x00110000 ; // alias is a predefined ID *
public static final int SND_FILENAME    = 0x00020000 ; // name is file name 
public static final int SND_RESOURCE    = 0x00040004 ; // name is resource name or atom *
*/
      static final int VM_NUM_OBJECTS = 200;
      static final int VM_NUM_THREADS = 201;
      static final int VM_OBJECT_MEMORY = 202;
      static final int VM_CLASS_MEMORY = 203;
/**
* Used with getParameter() it gets VM flag bits.
**/
public static final int VM_FLAGS = 4;
/**
* This is a VM flag bit which indicates that the main program class was
* loaded from a class file rather than from a ewe file. This only works
* from the desktop.
**/
public static final int VM_FLAG_USING_CLASSES = 0x1;
/**
* This is a VM flag bit which indicates that the VM is running on a Mobile PC.
**/
public static final int VM_FLAG_IS_MOBILE = 0x2;
/**
* This is a VM flag bit which indicates that the VM is running on a slow machine.
**/
public static final int VM_FLAG_SLOW_MACHINE = 0x4;
/**
* This is a VM flag bit which indicates that the VM is running on a system with a monochrome display.
**/
public static final int VM_FLAG_IS_MONOCHROME = 0x8;
/**
* This is a VM flag bit which indicates that the VM is running on a system that has no keyboard.
**/
public static final int VM_FLAG_NO_KEYBOARD = 0x10;
/**
* This is a VM flag bit which indicates that the VM is running on a system that has no mouse pointer.
**/
public static final int VM_FLAG_NO_MOUSE_POINTER = 0x20;
/**
* This is a VM flag bit which indicates that the VM is running as an Applet in a browser.
**/
public static final int VM_FLAG_IS_APPLET = 0x40;
/**
* This is a VM flag bit which indicates that multiple native windows are not supported.
**/
public static final int VM_FLAG_NO_WINDOWS = 0x80;
/**
* This is a VM flag bit which indicates that the platform has a SipButton at the bottom that may overwrite
* program controls (only PocketPC has this).
**/
public static final int VM_FLAG_SIP_BUTTON_ON_SCREEN = 0x100;
/**
* This is a VM flag bit which indicates that the platform does not want CR characters in its text files. Generally
* this indicates a Unix system.
**/
public static final int VM_FLAG_NO_CR = 0x200;
/**
* This is a VM flag bit which indicates that the program was run with a command line requesting the screen
* to be rotated by 90 degrees clockwise.
**/
//public static final int VM_FLAG_ROTATE_SCREEN = 0x400;
/**
* This is a VM flag bit which indicates that the program is running on the Sharp Zaurus Jeode(R) EVM. If it is
* then a number of bug fixes must be implemented and other flags set.
**/
public static final int VM_FLAG_IS_ZAURUS_EVM = 0x800;
/**
* This is a VM flag bit which indicates that the program is running on low-memory device
* such as the Casio BE300. Your application should minimize on the complexity of its user
* interface in such cases.
**/
public static final int VM_FLAG_LOW_MEMORY = 0x1000;
/**
* This is a VM flag bit which indicates that the program was run with a command line requesting the screen
* to be rotated by 90 degrees anti-clockwise.
**/
//public static final int VM_FLAG_COUNTER_ROTATE_SCREEN = 0x2000;
/**
This is a VM flag bit which indicates that the platform has no mouse OR touchscreen capabilities and
only keyboard navigation is possible - for example on many SmartPhone devices.
**/
public static final int VM_FLAG_NO_PEN = 0x4000;
/**
This is a VM flag bit which indicates that text input is not possible unless a native platform
input box is used. This is necessary for certain platforms such as MS SmartPhone devices.
**/
public static final int VM_FLAG_USE_NATIVE_TEXT_INPUT = 0x8000;
/**
This is a VM flag bit which indicates that the device has at least 2 general purpose
"Soft" keys, such as MS SmartPhone devices.
**/
public static final int VM_FLAG_HAS_SOFT_KEYS = 0x10000;
/**
This is a VM flag bit which indicates that the device will ALWAYS display the SIP
button. This flag can be explicitly set using Vm.setParameter(SET_ALWAYS_SHOW_SIP_BUTTON,1);
**/
public static final int VM_FLAG_SIP_BUTTON_ALWAYS_SHOWN = 0x20000;
/**
This is a VM flag bit which indicates that the device does not have a
functioning GUI even though the eve.fx.WindowSurface exists and eve.fx.WindowSurface.getNew()
returns a valid Object.
**/
public static final int VM_FLAG_NO_GUI = 0x40000;
/**
This is a VM flag bit which indicates that the device has a dedicated "Back" button.
This is usually present on SmartPhones but not on touch-screen devices.
**/
public static final int VM_FLAG_HAS_BACK_BUTTON = 0x80000;
/**
This is a VM flag bit which indicates that the device should not show
a visible window.
**/
public static final int VM_FLAG_NO_VISIBLE_WINDOW = 0x100000;
/**
This is a VM flag bit which indicates that applications windows should
be maximized.
**/
public static final int VM_FLAG_MAXIMIZE_APPS = 0x200000;
public static final int VM_FLAG_LOAD_FAKE_FILE = 0x400000;
public static final int VM_FLAG_SIP_DISABLED = 0x800000;
public static final int VM_FLAG_SYSTEM_FONTS_ONLY = 0x1000000;
public static final int VM_FLAG_USE_SOFT_KEYPAD = 0x2000000;
public static final int VM_FLAG_HIDDEN_SOFTKEYS = 0x4000000;
public static final int VM_FLAG_HAS_SOFTKEY_MENU_BUTTON = 0x8000000;

/**
* Used with getParameter() or setParameter() it determines whether the VM will use the SIP (Supplementary Input Panel).
* When used as ParameterId with setParameter() a value of 0 will disable the use of the SIP and a value of 1 will enable it.
**/
//public static final int VM_USE_SIP = 5;

public static final int VM_FILE_SEPARATOR = 6;
public static final int VM_PATH_SEPARATOR = 7;

/**
* Used with setParameter() it adjusts the minimum timer tick.
**/
public static final int TIMER_TICK = 1;
/**
* Used with setParameter() it switches on (1) or off (0) SIP simulation for
* Java and ewe on the PC.
**/
public static final int SIMULATE_SIP = 2;
/**
* Used with setParameter() and a value of 1, it switches on simulation of single 
* windowing.
**/
//public static final int SET_NO_WINDOWS = 4;
/**
* Used with setParameter() and a value of 1, it tells the VM to always show the SIP
* button.
**/
//public static final int SET_ALWAYS_SHOW_SIP_BUTTON = 5;
/**
* Used with getParameter() or setParameter() it determines whether the VM will use the SIP (Supplementary Input Panel).
* When used as ParameterId with setParameter() a value of 0 will disable the use of the SIP and a value of 1 will enable it.
**/
public static final int SET_USE_SIP = 10;

/**
* This is the only one apart from DEFAULT_CURSOR you should use directly with
* ewe.sys.Vm.setCursor(). All others should be used with Control.setCursor().
**/
public static final int WAIT_CURSOR  = 1;
public static final int IBEAM_CURSOR  = 2;
public static final int HAND_CURSOR  = 3;
public static final int CROSS_CURSOR  = 4;
public static final int LEFT_RIGHT_CURSOR  = 5;
public static final int UP_DOWN_CURSOR  = 6;
/**
* This cursor is an arrow and an hour glass. Use this when an individual component
* will not respond because it is busy, but other components will work.
**/
public static final int BUSY_CURSOR = 7;
public static final int DRAG_SINGLE_CURSOR = 8;
public static final int DRAG_MULTIPLE_CURSOR = 9;
public static final int COPY_SINGLE_CURSOR = 10;
public static final int COPY_MULTIPLE_CURSOR = 11;
public static final int DONT_DROP_CURSOR = 12;
public static final int MOVE_CURSOR = 13;
public static final int RESIZE_CURSOR = 14;
public static final int INVISIBLE_CURSOR = 15;
/**
* This means no <b>special</b> cursor;
**/
public static final int NO_CURSOR = 0;
public static final int DEFAULT_CURSOR = 0;

/**
 * Used with setParameter() the specified VM flag bits will be set in the
 * VM flags value.
 */
public static final int TURN_ON_VM_FLAG_BITS = 20;
/**
 * Used with setParameter() the specified VM flag bits will be cleared in the
 * VM flags value.
 */
public static final int TURN_OFF_VM_FLAG_BITS = 21;

static final int JAR_RESOURCE_ID = 22;

public static final int GET_PARAMATER_SIP_BUTTON_HEIGHT = 23;
public static final int GET_PARAMATER_SOFTKEY_BAR_HEIGHT = 24;

public static final int GET_SET_PARAMATER_PEN_MOVE_BUFFER_TIME = 100;
public static final int GET_SET_PARAMATER_RESIZE_BUFFER_TIME = 101;
public static final int GET_SET_PARAMATER_PAINT_BUFFER_TIME = 102;

//##################################################################
}
//##################################################################

