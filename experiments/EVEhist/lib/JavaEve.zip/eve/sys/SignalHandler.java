package eve.sys;

/**
 * Defines a class that can handle OS signals trapped by the VM.
 * Register signal handlers using eve.sys.Vm.addSignalHandler().
 */
public interface SignalHandler {

	/**
	 * Usually caused when Ctrl-C is pressed.
	 */
	public static final int SIGINT = 1;
	/**
	 * Usually caused when OS requests program termination.
	 */
	public static final int SIGTERM = 2;
	/**
	 * Called when the signal is trapped by the OS.
	 * @param signal the signal that was trapped.
	 * You can call eve.sys.Vm.handleSignal(int signal) to
	 * tell the VM to do the default signal handling for the
	 * specified signal.
	 */
	public void handleSignal(int signal);
	/**
	 * Called when the SignalHandler is installed.
	 * @param forSignal the signal it is installed for.
	 * @param oldHandler the old SignalHandler for that signal.
	 */
	public void installed(int forSignal, SignalHandler oldHandler);
}
