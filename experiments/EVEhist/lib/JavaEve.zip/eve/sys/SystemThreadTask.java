package eve.sys;
/**
* This class is used to execute a method within the System (native window message) Thread (which
* is needed to do certain operations on certain operating systems).<p>
* To use it you simply override doTask(). This method will get called in the System Message Thread
* when the execute() method of the SystemThreadTask is executed.<p>
* If execute() is called when the system is already in the System Thread, then the doTask()
* method is called immediately. Otherwise, the current Thread is halted and a CallBack is
* requested, which will then execute doTask(). After doTask() has been executed the current
* Thread continues and returns the value returned by doTask().
**/
//##################################################################
public abstract class SystemThreadTask implements CallBack{
//##################################################################
private boolean succeeded = false;
private boolean didIt = false;
/**
* This is the only thing to override. Do the task and return true
* if successful or false otherwise.
**/
protected abstract boolean doTask(Object data);
/**
This is the number of milliseconds to wait before the callBack() completes.
By default it is 5000 (5 seconds). If you set it to a value < 0 then there
will be no timeout.
**/
public int timeout = 5000;

//===================================================================
public final void callBack(Object data){
//===================================================================
	succeeded = doTask(data);
	synchronized(this){
		didIt = true;
		notifyAll();
	}
}


/**
 * Execute the doTask() method in a System Thread. 
 * @param data The data to be passed to doTask().
 * @return the value returned by doTask() or false if the Thread
 * was interrupted while waiting for the task to complete in the System Thread.
 */
//===================================================================
public final boolean execute(Object data)
//===================================================================
{
	try{
		return execute(data,false);
	}catch(InterruptedException e){
		return false;
	}
}
/**
 * Execute the doTask() method in a System Thread or in the current thread - depending on the value
 * of alwaysExecuteNow.
 * @param data The data to be passed to doTask().
 * @param alwaysExecuteNow If this is true then doTask() will always be executed in the current thread.
 * @return The value returned by doTask().
 * @exception InterruptedException if the Thread was interrupted while
 * waiting for the task to complete in the System Thread.
 */
//===================================================================
public final synchronized boolean execute(Object data,boolean alwaysExecuteNow)
throws InterruptedException
//===================================================================
{
	if (Vm.inSystemThread() || alwaysExecuteNow) return doTask(data);
	Vm.callBackInSystemThread(this,data);
	while(!didIt){
		if (timeout >= 0) wait(timeout);
		else wait();
		if (!didIt) return false; //Implies it timed out.
	}
	return succeeded;
}

//##################################################################
}
//##################################################################


