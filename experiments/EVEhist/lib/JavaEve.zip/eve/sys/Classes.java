/*
 * Created on Jun 30, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.util.Vector;

import eve.applet.EveApplet;
import eve.util.mClassLoader;

/**
 * @author Michael L Brereton
 *
 * TODO Java version of Classes must load from .eve files.
 */
//
// JAVA Version!
//
//####################################################
public class Classes {

	/**
	 * This returns System classes only.
	 * The Java version of this is different - it has to load from .ewe files.
	 */
	public static Class forName(String className) throws ClassNotFoundException
	{
		try{
			return Class.forName(className);
		}catch(ClassNotFoundException e){
			Class ret = EveApplet.loadClass(className);
			if (ret != null) return ret;
			throw new ClassNotFoundException(className);
		}/*catch(Throwable t){
			System.out.println("Problem with: "+className);
			t.printStackTrace();
			throw (Error)t;
		}*/
	}
	/**
	 * This returns any class loaded via the system or an mClassLoader.
	 * The Java version of this is the same.
	 */
	public static Class loadForName(String className) throws ClassNotFoundException
	{
		try{
			return forName(className);
		}catch(ClassNotFoundException e){
			
		}
		Vector v = new Vector();
		mClassLoader.getClassLoaders(v,true);
		int s = v.size();
		for (int i = 0; i<s; i++){
			ClassLoader cl = (ClassLoader)v.get(i);
			if (cl == null) continue;
			try{
				return cl.loadClass(className);
			}catch(ClassNotFoundException e){}
		}
		throw new ClassNotFoundException(className);
	}
	
}
//####################################################
