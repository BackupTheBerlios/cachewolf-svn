/*
 * Created on Mar 20, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Hashtable;

import eve.util.WeakCache;

/**
 * @author Michael L Brereton
 *
 A ResourceCache is a collection of named resources that are associated with an Object
 (used as a key). However only a weak reference is kept to the key Objects so when the
 Object is garbage collected the resources are released from the cache (and garbage
 collected if no other object refers to them).
 <p>
 One of the most useful uses of a ResourceCache is to attribute properties and resources
 to a particular thread. This allows the safe re-use of data objects during frequently
 repeated tasks (such as those run by a server thread) thereby reducing the need
 to create and discard temporary objects. Using a ThreadPool for Thread re-use along
 with a ResourceCache can significantly improve the runtime performance of server
 applications.
 <p>
 A ResourceCache is generally better to use than a WeakCache for two reasons. One is 
 that multiple resources can be attributed to an object, each with a distinct name.
 The other reason is that on a native Eve VM the ResourceCache is backed by a native
 implementation that makes accessing data from the cache very efficient.
 <p> 
 */
//####################################################
public class ResourceCache {
//Don't move this single variable.
int nativeObject;
//
private WeakCache cache;
//
private static boolean hasNative = true;
private static final int OP_PUT = 1;
private static final int OP_GET = 2;
private static final int OP_DEL = 3;
private native Object doOp(Object forWho, String type, Object data, int op);
private native void setup(int ic,float lf,Object objForWho);
private static Hashtable methods = new Hashtable();

public ResourceCache()
{
	this(17,(float)0.75);
}
public ResourceCache(int initialCapacity)
{
	this(initialCapacity,(float)0.75);
}

public ResourceCache(int initialCapacity, float loadFactor)
{
	if (hasNative)try{
		setup(initialCapacity,loadFactor,null);
		return;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	cache = new WeakCache(initialCapacity,loadFactor);
}
public synchronized void setupFor(Object forObject, int initialCapacity, float loadFactor)
{
	if (hasNative)try{
		setup(initialCapacity,loadFactor,null);
		return;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	Hashtable ht = (Hashtable)cache.get(forObject);
	if (ht == null) {
		ht = new Hashtable(initialCapacity,loadFactor);
		cache.put(forObject,ht);
	}
}
public synchronized void put(Object forObject, String resourceType, Object data)
{
	if (forObject == null || resourceType == null) throw new NullPointerException();
	resourceType = resourceType.intern();
	if (hasNative)try{
		doOp(forObject,resourceType,data,OP_PUT);
		return;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	Hashtable ht = (Hashtable)cache.get(forObject);
	if (ht == null) {
		ht = new Hashtable();
		cache.put(forObject,ht);
	}
	ht.put(resourceType,data);
}

public synchronized Object get(Object forObject, String resourceType)
{
	if (forObject == null || resourceType == null) throw new NullPointerException();
	String key = resourceType.intern();
	if (hasNative)try{
		return doOp(forObject,resourceType,null,OP_GET);
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	Hashtable ht = (Hashtable)cache.get(forObject);
	if (ht == null) return null;
	return ht.get(key);
}

public synchronized void remove(Object forObject, String resourceType)
{
	if (forObject == null || resourceType == null) throw new NullPointerException();
	String key = resourceType.intern();
	if (hasNative)try{
		doOp(forObject,resourceType,null,OP_DEL);
		return;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	Hashtable ht = (Hashtable)cache.get(forObject);
	if (ht == null) return;
	ht.remove(key);
}

public synchronized void cache(Object forWho, Object obj)
{
	if (obj == null) return;
	String tag = obj.getClass().getName();
	WeakSet ws = (WeakSet)get(forWho,tag);
	if (ws == null){
		ws = new WeakSet(true);
		put(forWho,tag,ws);
		Method m = Reflection.getMethod(obj.getClass(),"cached",Reflection.emptyClasses,Void.TYPE,false);
		if (m != null && !Modifier.isPublic(m.getModifiers())) m = null;
		if (m != null) methods.put(tag,m);
	}
	ws.add(obj);
	Method m = (Method)methods.get(tag);
	if (m != null) 
		try{ 
			m.invoke(obj,Reflection.emptyParameters);
		}catch(InvocationTargetException it){
			RuntimeException r = new RuntimeException();
			Vm.setCause(r,it.getCause());
			throw r;
		}catch(IllegalAccessException ia){
		}
}
public synchronized Object getCached(Object forWho, Class type, boolean makeNew)
{
	String tag = type.getName();
	WeakSet ws = (WeakSet)get(forWho,tag);
	Object got = ws == null ? null : ws.takeRef();
	if (got == null && makeNew) return Cache.makeNew(type);
	return got;
}
public synchronized void clearCache(Object forWho, Class type)
{
	String tag = type.getName();
	WeakSet ws = (WeakSet)get(forWho,tag);
	if (ws != null) ws.clear();
}
public Object getCached(Object forWho, Class type)
{
	return getCached(forWho,type,true);
}

}
//####################################################
