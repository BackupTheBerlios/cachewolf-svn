/*
 * Created on Mar 21, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import eve.net.Net;
import eve.net.RemoteServer;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class VmServer extends Task{

ServerSocket ss;
static final String location = "HKEY_LOCAL_MACHINE\\Software\\EweSoft\\EveVM";
static IConsole serverIConsole;
static PrintWriter serverConsole;
static VmServer server;

public static boolean serverIsRunning()
{
	return server != null;
}
public static synchronized IConsole getIConsole()
{
	return serverIConsole;
}
public static synchronized PrintWriter getConsole()
{
	/*
	if (serverConsole == null) {
		IConsole ic = Device.createConsole("Eve Server",0,100);
		if (ic == null) return null;
		serverConsole = new PrintWriter(ic.getWriter()); 
	}
	*/
	return serverConsole;
}
public static synchronized void setConsole(PrintWriter pw)
{
	serverConsole = pw;
}
public Handle start()
{
	if (serverIConsole == null){
		serverIConsole = Device.createConsole("Eve Server",IConsole.OPTION_DONT_PUT_IN_WINDOW|IConsole.OPTION_READ_ONLY,100);
		if (serverIConsole != null){
			serverConsole = new PrintWriter(serverIConsole.getWriter());
			serverConsole.println("Eve Server Started.");
		}
	}
	server = this;
	try{
		ss = new ServerSocket(0,0,InetAddress.getByName("127.0.0.1"));//getLocalHost());
		Registry.writeRegistryValue(location,"ServerName",Net.getLocalAddress(ss).getHostAddress());
		Registry.writeRegistryValue(location,"ServerPort",new Integer(ss.getLocalPort()));
	}catch(Exception e){
		fail(e);
		return this;
	}
	return super.start();
}
protected void handleCommand(Socket com)
{
	PrintWriter pw = getConsole();
	BufferedReader br = null;
	try{
		br = new BufferedReader(new InputStreamReader(com.getInputStream()));
		String line = br.readLine();
		int idx = line.indexOf(':');
		if (idx == -1) return;
		String toDo = line.substring(0,idx).toLowerCase();
		String specs = line.substring(idx+1);
		if (toDo.equals("activesyncmobile")){
			if (pw != null) {
				RemoteServer.setupConsole(pw);
			}
			Handle h = RemoteServer.startActiveSyncMobile(specs);
			h.waitUntilCompletion();
			if (pw != null) pw.println("EveSync Ended");
		}
	}catch(Exception e){
		if (pw != null) e.printStackTrace(pw);
	}finally{
		try{
			if (br != null) br.close();
			com.close();
		}catch(Exception e){}
	}
}
protected void doRun()
{
	try{
		while(true){
			try{
				final Socket got = ss.accept();
				new Thread(){
					public void run(){
						handleCommand(got);
					}
				}.run();
			}catch(Exception e){
				return;
			}
		}
	}catch(Throwable e){
		fail(e);
	}
}
}
//####################################################
