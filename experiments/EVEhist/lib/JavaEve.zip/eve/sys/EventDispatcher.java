package eve.sys;
import java.util.Vector;

/**
* An EventDispatcher is a utility class that can be used to keep track of a set of
* ewe.ui.EventListener objects that wish to listen to some kind of event via their
* onEvent(Event ev) method.
* <p>
* The EventDispatcher can be configured to dispatch events in the current thread or
* via one or more background threads.
* <p>
* Listeners can also be added weakly, where a reference to them is kept only as long
* as they are referenced by other objects other than the EventDispatcher. So when they
* are garbage collected they will automatically be removed from the EventDispatcher.
**/
//##################################################################
public class EventDispatcher extends Task implements EventListener{
//##################################################################
private Vector listeners;
private WeakSet weakListeners;
private Vector toSend;
private Vector queue;
private static ThreadPool pool; 
private Event ev;
private EventListener dest;
private Thread queueThread;
/**
* If this is set true then events are not delivered via a separate
* thread, but within the same thread that called dispatch().
* <p>
* By default a single thread is used to dispatch all events - this thread waits
* until events comes in and then dispatches them to listeners one by one. Therefore
* if any listener blocks within the onEvent() method the rest of the events will not
* be delivered.
**/
public boolean dontUseSeparateThread;
/**
 * If this is set true then each event is delivered in its own thread.
* <p>
* By default a single thread is used to dispatch all events - this thread waits
* until events comes in and then dispatches them to listeners one by one. Therefore
* if any listener blocks within the onEvent() method the rest of the events will not
* be delivered.
 */
public boolean useSeparateThreadForEach;

//-------------------------------------------------------------------
private EventDispatcher(EventListener dest,Event ev)
//-------------------------------------------------------------------
{
	this.dest = dest;
	this.ev = ev;
}
//-------------------------------------------------------------------
protected final void doRun()
//-------------------------------------------------------------------
{
	if (!ev.consumed)
		dest.onEvent(ev);
}

//===================================================================
public EventDispatcher()
//===================================================================
{
	this(1);
}
/**
 * Create an EventDispatcher specifying the number of threads used to deliver events.
 * @param maxParallelDeliveries the maximum number of threads used to deliver evetns simultaneously.
 */
//===================================================================
public EventDispatcher(int maxParallelDeliveries)
//===================================================================
{
	if (maxParallelDeliveries < 1) maxParallelDeliveries = 1;
	this.maxParallelDeliveries = maxParallelDeliveries;
}
/**
 * This is the maximum number of parallel event deliveries allowed.
 */
private int maxParallelDeliveries = 1;
/**
 * Add an event listener.
 * @param listener The listener to add.
 * @param addToWeakSet If this is true the listener will be added to an internal
 * WeakSet. This means that if no other object is referring to that listener it will
 * eventually be garbage collected and removed from the list.
 */
//===================================================================
public synchronized void addListener(EventListener listener,boolean addToWeakSet)
//===================================================================
{
	if (listener == null) return;
	if (addToWeakSet){
		if (weakListeners == null) weakListeners = new WeakSet();
		weakListeners.add(listener);
	}else{
		if (listeners == null) listeners = new Vector();
		if (listeners.contains(listener)) return;
		listeners.add(listener);
	}
}
/**
 * Add an event listener.
 * @param listener The listener to add.
 */
//===================================================================
public synchronized void addListener(EventListener listener)
//===================================================================
{
	addListener(listener,false);
}
/**
 * Remove an event listener.
 * @param listener The listener to remove.
 */
//===================================================================
public synchronized void removeListener(EventListener listener)
//===================================================================
{
	if (weakListeners != null) {
		weakListeners.remove(listener);
		if (weakListeners.isEmpty()) weakListeners = null;
	}
	if (listeners != null) {
		listeners.remove(listener);
		if (listeners.size() == 0) listeners = null;
	}
}
/**
* Get all current listeners.
* @param destination A destination Vector, which will be cleared first, to hold the listeners. This can be null in which case a new one will be created.
* @return The destination or new Vector containing all active listeners.
*/
//===================================================================
public synchronized Vector getCurrentListeners(Vector destination)
//===================================================================
{
	if (destination == null)  destination = new Vector();
	destination.clear();
	if (listeners != null && listeners.size() != 0){
		int max = listeners.size();
		for (int i = 0; i<max; i++)
			destination.add(listeners.get(i));
	}else
		listeners = null;
	if (weakListeners != null){
		int did = weakListeners.getRefs(destination);
		if (did == 0) weakListeners = null;
	}
	return destination;
}
/**
 * Send off the event to the listeners. This is done via a separate thread unless
 * dontUseSeparateThread is true, in which case the onEvent() method of each
 * listener is called directly.
 * @param ev the event to send.
 */
//===================================================================
public synchronized void dispatch(Event ev)
//===================================================================
{
	if (ev == null) return;
	ev.consumed = false;
	if (listeners == null && weakListeners == null) return;
	toSend = getCurrentListeners(toSend);
	if (toSend.size() == 0){
		//toSend = null;
		return;
	}
	if (useSeparateThreadForEach) synchronized(EventListener.class){
		if (pool != null){
			if (pool.hasStopped()){
				pool = null;
			}else{
			}
		}
		if (pool == null) {
			pool = new ThreadPool(0,maxParallelDeliveries);
		}
	}else if (!dontUseSeparateThread){
		if (queue == null) queue = new Vector();
		synchronized(queue){
			if (queueThread == null){
				queueThread = new Thread(){
					public void run(){
						try{
							Vector ts = new Vector();
							while(true){
								Event ev = null;
								synchronized(queue){
									if (queue.size() == 0){
										try{
											queue.wait(1000);
										}catch(Exception e){}
										if (queue.size() == 0){
											queueThread = null;
											return;
										}
									}
									ev = (Event)queue.get(0);
									queue.removeElementAt(0);
								}
								ts = getCurrentListeners(ts);
								for (int i = 0; i<ts.size() && !ev.consumed; i++)
									((EventListener)toSend.get(i)).onEvent(ev);
							}
						}finally{
							synchronized(queue){
								if (queueThread == this)
									queueThread = null;
							}
						}
					}
				};
				queueThread.start();
			}
			queue.add(ev);
			queue.notifyAll();
		}
		
		return;
	}
	for (int i = 0; i<toSend.size() && !ev.consumed; i++){
		if (dontUseSeparateThread){
			try{
				((EventListener)toSend.get(i)).onEvent(ev);
			}catch(Throwable t){
				t.printStackTrace();
			}
		}
		else //if (useSeparateThreadForEach)
			pool.addTask(new EventDispatcher((EventListener)toSend.get(i),ev));
	}
}
/**
 * Check if there are any listeners in the Dispatcher. If this returns
 * true it indicates that there are definitely no listeners. If it returns
 * false it indicates that there <b>may</b> be some listeners.
 */
//===================================================================
public synchronized boolean isEmpty()
//===================================================================
{
	int count = listeners == null ? 0 : listeners.size();
	if (weakListeners != null && !weakListeners.isEmpty()) count++;
	if (count == 0){
		listeners = null;
		weakListeners = null;
		return true;
	}
	return false;
}
/**
* Close the EventDispatcher.
**/
//===================================================================
public synchronized void close()
//===================================================================
{
	//if (pool != null) pool.stop(0);
	//pool = null;
}
//===================================================================
public void finalize()
//===================================================================
{
	close();
}
//##################################################################

/**
 * This method calls dispatch(ev) directly.
 */
public void onEvent(Event ev) {
	dispatch(ev);
}
}
//##################################################################

