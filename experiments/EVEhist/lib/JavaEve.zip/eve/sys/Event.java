/*
 * Created on Apr 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import eve.data.DataObject;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Event extends DataObject{

/**
 * This is the Object considered to be the target for this Event.
 */
public Object target;
/**
 * This specifies when the Event was generated.
 */
public long timeStamp;
/**
 * This value is set depending on the class of the Event.
 */
public int type;
/**
 * This indicates whether or not the Event should be considered as being consumed.
 */
public boolean consumed;
/**
 * This indicates what Event may have caused this one.
 */
public Event cause;
/**
 * This is the higher level window that is associated with the event, if any.
 */
public Object window;

public int flags;

private boolean reused;

public boolean isReused()
{
	return reused;
}

public boolean setReused(boolean isReused)
{
	boolean ret = reused;
	reused = isReused;
	return ret;
}
}
//####################################################
