/*
 * Created on Dec 11, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import eve.data.DataObject;

/**
 * This class contains the same information that you get from an ImageData, but
 * as publicly accessible fields instead of via method calls. This can be used
 * to improve performance when making multiple calls to methods that need this
 * information. 
 */
//####################################################
public class ImageDataInfo extends DataObject implements ImageData {
// Do not move these 8 fields - they are used by native methods.
public int width;
public int height;
public int type;
public int scanLineType;
public int scanLineLength;
public boolean isReadable;
public boolean isWriteable;
public int[] colorTable;
//================================================================
/**
 * Returns the value of the field "type"
 */
public int getImageType() {
	return type;
}
/**
 * Returns the value of the field "scanLineType"
 */
public int getImageScanLineType() {
	return scanLineType;
}
/**
 * Returns the value of the field "scanLineLength"
 */
public int getImageScanLineLength() {
	return scanLineLength;
}
/**
 * This does nothing at all.
 */
public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength) throws IllegalStateException {
}
/**
 * This does nothing at all.
 */
public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength) throws IllegalStateException {
}
/**
 * Returns the value of the field "width"
 */
public int getImageWidth() {
	return width;
}
/**
 * Returns the value of the field "height"
 */
public int getImageHeight() {
	return height;
}
/**
 * Returns the value of the field "colorTable"
 */
public int[] getImageColorTable() {
	return colorTable;
}
/**
 * Returns the value of the field "isWriteable"
 */
public boolean isWriteableImage() {
	return isWriteable;
}
/**
 * Returns the value of the field "isReadable"
 */
public boolean isReadableImage() {
	return isReadable;
}
/**
 * This does nothing at all.
 */
public void freeImage() {
}

public ImageDataInfo fromImageData(ImageData source)
{
	if (source instanceof ImageDataInfo)
		copyFrom(source);
	else{
		type = source.getImageType();
		scanLineType = source.getImageScanLineType();
		scanLineLength = source.getImageScanLineLength();
		width = source.getImageWidth();
		height = source.getImageHeight();
		if (true) return this;
		isReadable = source.isReadableImage();
		isWriteable = source.isWriteableImage();
		colorTable = source.getImageColorTable();
	}
	return this;
}
public static ImageDataInfo toImageDataInfo(ImageData source, ImageDataInfo destination)
{
	if (source instanceof ImageDataInfo) return (ImageDataInfo)source;
	if (destination == null) destination = new ImageDataInfo();
	return destination.fromImageData(source);
}
public static ImageDataInfo toImageDataInfo(ImageData source)
{
	if (source instanceof ImageDataInfo) return (ImageDataInfo)source;
	return (new ImageDataInfo()).fromImageData(source);
}
/**
 * This does nothing at all - always returns null.
 */
public int[] getPixels(int[] dest, int offset, int x, int y, int width, int height, int rowStride) {
	return null;
}
/**
 * This does nothing at all - always returns false.
 */
public boolean setPixels(int[] src, int offset, int x, int y, int width, int height, int rowStride) {
	return false;
}
/**
 * This does nothing at all - always returns false.
 */
public boolean setScanLinePixels(int scanLine,int[] pixels, int offset, int destX, int destFrequency, int numPixels, int srcFrequency) {
	return false;
}

}
//####################################################
