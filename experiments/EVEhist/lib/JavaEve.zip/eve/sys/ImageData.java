package eve.sys;

/**
This is a Interface that provides image scan line data and can optionally
accept image scan line data.<p>
**/
//##################################################################
public interface ImageData{
//##################################################################
/**
 * An option that may be used when creating images/pictures that
 * will be scaled.
 */
public static final int CREATE_OPTION_KEEP_ASPECT_RATIO = 0x1000000;
/**
 * An option that may be used when creating images/pictures. It indicates
 * that all transparency information should be ignored and that all
 * pixels should be considered fully opaque.
 */
public static final int CREATE_OPTION_IGNORE_ALPHA = 0x2000000;
/**
 * An option that may be used when creating images/pictures that
 * will be scaled.
 */
public static final int CREATE_OPTION_ROUGH_SCALING = 0x4000000;
/**
 * An option that may be used when creating images/pictures that
 * will be scaled. It indicates that if the original image is
 * smaller than the new requested size, then the original size
 * should be used.
 */
public static final int CREATE_OPTION_DONT_SCALE_UP = 0x8000000;

//public static final int IS_AN_IMAGE_DATA_TYPE = 0x40000000;
/** An image type - the type could not be determined **/
public static final int TYPE_UNKNOWN = 0;
/** An image type - one byte per color component, three bytes per pixel. **/
public static final int TYPE_RGB = 1;
/** An image type - one byte per color component, four bytes per pixel. **/
public static final int TYPE_ARGB = 2;
/** An image type - one bit per pixel. **/
public static final int TYPE_MONO = 3;
/** An image type - one bit per pixel - the same as TYPE_MONO.**/
public static final int TYPE_GRAY_SCALE_2 = TYPE_MONO;
/** An image type - 2 bits per pixel gray scale. **/
public static final int TYPE_GRAY_SCALE_4 = 4;
/** An image type - 4 bits per pixel gray scale. **/
public static final int TYPE_GRAY_SCALE_16 = 5;
/** An image type - one byte per pixel gray scale. **/
public static final int TYPE_GRAY_SCALE_256 = 6;

//public static final int FIRST_GRAY = TYPE_GRAY_SCALE_2;
//public static final int LAST_GRAY = TYPE_GRAY_SCALE_256;

/** An image type - 1 bit per pixel indexed color. **/
public static final int TYPE_INDEXED_2 = 7;
/** An image type - 2 bits per pixel indexed color. **/
public static final int TYPE_INDEXED_4 = 8;
/** An image type - 4 bits per pixel indexed color. **/
public static final int TYPE_INDEXED_16 = 9;
/** An image type - one byte per pixel indexed color. **/
public static final int TYPE_INDEXED_256 = 10;
/** This is a mask  you can use to determine TYPE_XXX values **/
public static final int TYPE_MASK = 0xff;

//public static final int FIRST_INDEX = TYPE_INDEXED_2;
//public static final int LAST_INDEX = TYPE_INDEXED_256;


/** A Scan line type that is always used by TYPE_MONO, TYPE_INDEXED_XXX and TYPE_GRAY_SCALE_XXX. MAY be used
by TYPE_RGB and TYPE_ARGB **/
public static final int SCAN_LINE_BYTE_ARRAY = 1;
/** A Scan line type that may be used by TYPE_RGB and TYPE_ARGB, but not by any other types. **/
public static final int SCAN_LINE_INT_ARRAY = 2;

/**
This returns one of the TYPE_XXX values
**/
//===================================================================
public int getImageType();
//===================================================================
/**
Get the type of scan line used by the image - either SCAN_LINE_BYTE_ARRAY or SCAN_LINE_INT_ARRAY
**/
//===================================================================
public int getImageScanLineType();
//===================================================================
/**
If the scan line type is SCAN_LINE_BYTE_ARRAY then this indicates
the number of bytes is needed for one complete scan line. 
**/
//===================================================================
public int getImageScanLineLength();
//===================================================================
/**
Place a set of scan lines into a destination array.
The type of the destination array must be either byte[] or int[] depending on the value
of getImageScanLineType().
**/
//===================================================================
public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength)
throws IllegalStateException;
//===================================================================
/**
Place a set of scan lines from a source Array into the ImageData.
The type of the destination array must be either byte[] or int[] depending on the value
of getImageScanLineType().
**/
//===================================================================
public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength)
throws IllegalStateException;
//===================================================================

//===================================================================
public int getImageWidth();
//===================================================================

//===================================================================
public int getImageHeight();
//===================================================================
/**
Open the source to retrieve or optionally set scan lines.
**/
//===================================================================
//public boolean openImageData(boolean forWriting);
//===================================================================
/**
Close the source when you have finished retrieving scan lines.
**/
//===================================================================
//public boolean closeImageData();
//===================================================================
/**
For indexed images, this retrieves the color table as an array of ARGB integers.
If the image type is not TYPE_INDEXED_XXX, then null will be returned.
**/
//===================================================================
public int[] getImageColorTable();
//===================================================================
/**
Returns if you can write data to the ImageData.
**/
//===================================================================
public boolean isWriteableImage();
//===================================================================
/**
Returns if you can read data from the ImageData.
**/
//===================================================================
public boolean isReadableImage();
//===================================================================
/**
 * Free any resource associated with the ImageData object.
 */
//===================================================================
public void freeImage();
//===================================================================

/**
 * Retrieve the pixels from the Image in encoded ARGB values. If the usesAlpha() method
 * returns false, then the A component of each pixel value (the top 8 bits) should be ignored.
 * @param dest The destination int array. If this is null then a new array should be created. 
* @param offset The offset into the array to start placing pixels.
* @param x the x co-ordinate within the image.
* @param y the y co-ordinate within the image.
* @param width the width of the pixel block to get.
* @param height the height of the pixel block to get.
* @param rowStride the number of int values between each row in the destination int array. If this is 0 it
* will be assumed to be equal to width.
 * @return The array containing the pixels, or null if getting pixels is not supported.
*/
public int [] getPixels(int[] dest,int offset,int x,int y,int width,int height,int rowStride);
/**
 * Set the pixels in the IImage in encoded ARGB values. If the usesAlpha() method
 * returns false, then the A component of each pixel value (the top 8 bits) will be ignored.
 * @param src The source int array. 
* @param offset The offset into the array to start retrieving pixels.
* @param x the x co-ordinate within the image.
* @param y the y co-ordinate within the image.
* @param width the width of the pixel block to get.
* @param height the height of the pixel block to get.
* @param rowStride the number of int values between each row in the destination int array. If this is 0 it
* will be assumed to be equal to width.
 * @return true if setting pixel values is supported, false if not.
*/
public boolean setPixels(int[] src,int offset,int x,int y,int width,int height,int rowStride);

/**
 * If this ImageData maintains its data using an array of integers,
 * then this method requests that a portion of the data is exposed. 
 * @param x
 * @param y
 * @param width
 * @param height
 * @param pixelData
 * @return
 */
//public boolean exposePixels(int x, int y, int width, int height, PixelData pixelData);
//##################################################################
}
//##################################################################

