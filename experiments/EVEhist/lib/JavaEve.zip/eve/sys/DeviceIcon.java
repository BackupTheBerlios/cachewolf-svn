/*
 * Created on Nov 8, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public abstract class DeviceIcon{

	public abstract void free();
	
}
//####################################################
