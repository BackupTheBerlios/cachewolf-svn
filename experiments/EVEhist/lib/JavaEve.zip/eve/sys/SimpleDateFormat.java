package eve.sys;

import java.text.ParseException;
import java.util.Calendar;
import java.util.SimpleTimeZone;
import java.util.TimeZone;
/**
 * This class is meant to be a replacement for java.text.SimpleDateFormat
 * which requires too many extra classes to implement correctly.
* The format string uses the convention as the java.util.SimpleDateFormat with some specifiers left
* out. What is included are:<p>
* <pre>
* Symbol   Meaning                 Presentation        Example
* ------   -------                 ------------        -------
* y        year                    (Number)            1996
* M        month in year           (Text & Number)     July & 07
* d        day in month            (Number)            10
* h        hour in am/pm (1~12)    (Number)            12
* H        hour in day (0~23)      (Number)            0
* m        minute in hour          (Number)            30
* s        second in minute        (Number)            55
* S        millisecond             (Number)            978
* E        day in week             (Text)              Tuesday
* a        am/pm marker            (Text)              PM
* z        GMT TimeZone            (Text & Number)     GMT+04:00
* Z        RFC 822 Time Zones      (Number)            -0400
* '        escape for text
* </pre>
 */
public class SimpleDateFormat {

	private String format;
	private static Calendar cal;
	private static Time t;
	private Locale locale;
	/**
	 * Set the Locale used for the SimpleDateFormat.
	 * @param locale the Locale to use.
	 */
	public void setLocale(Locale locale)
	{
		this.locale = locale;
	}
	/**
	 * Get the Locale used for the SimpleDateFormat.
	 */
	public Locale getLocale()
	{
		return locale == null ? Locale.getDefault() : locale;
	}
	private static void setup()
	{
		if (cal != null) return;
		cal = Calendar.getInstance();
		t = new Time();
	}
	/**
	 * Create a SimpleDateFormat using the specified format and the default
	 * Locale.
	 * @param format the format string to use.
	 */
	public SimpleDateFormat(String format)
	{
		this(format,null);
	}
	/**
	 * Create a SimpleDateFormat using the specified format and the default
	 * specified Locale.
	 * @param format the format string to use.
	 * @param locale the Locale to use.
	 */
	public SimpleDateFormat(String format,Locale locale)
	{
		if (format == null) throw new NullPointerException();
		this.format = format;
		setLocale(locale);
	}
	/**
	 * Convert this to a LocaleFormat.
	 * @param dest an optional destination LocaleFormat.
	 * @return the dest LocaleFormat or a new one if it was null.
	 */
	public LocaleFormat toLocaleFormat(LocaleFormat dest)
	{
		if (dest == null) dest = new LocaleFormat();
		dest.locale = getLocale();
		dest.format = format;
		dest.options = 0;
		return dest;
	}
	/**
	 * Copy to the dest LocaleFormat the data from the LocaleFormat src
	 * adjusting the values such that the locale field is valid, the
	 * format field is a String or is null and the options field is zero.
	 * @param src the source LocaleFormat.
	 * @param dest the destination LocaleFormat.
	 * @return the destination LocaleFormat or a new one if it is null.
	 */
	public static LocaleFormat fixLocaleFormat(LocaleFormat src, LocaleFormat dest)
	{
		if (dest == null) dest = new LocaleFormat();
		if (src != null) {
			dest.locale = src.locale;
			dest.format = src.format;
		}
		Object lf = dest.format;
		if (lf instanceof SimpleDateFormat) dest.format = ((SimpleDateFormat)lf).getFormat();
		else if (!(lf instanceof String)) dest.format = null;
		if (dest.locale == null) dest.locale = Locale.getDefault();
		return dest;
	}
	/**
	 * Returns the format.
	 */
	public String toString()
	{
		return format;
	}
	/**
	 * Returns the format.
	 */
	public String getFormat()
	{
		return format;
	}
	public int hashCode()
	{
		return format.hashCode();
	}
	/**
	 * Returns a java.util.Date value and is kept only
	 * for compatibility with java.util.SimpleDateFormat. 
	 * This is deprecated because
	 * you should be using Calendar instead of Date.
	 * @param str the String to parse.
	 * @return a java.util.Date Object.
	 * @throws ParseException if the string is badly formatted.
	 * @deprecated use parse(String str, Calendar destination) instead.
	 */
	public Object parseObject(String str) throws ParseException
	{
		return parse(str);
	}
	
	/**
	 * Returns a java.util.Date value and is kept only
	 * for compatibility with java.util.SimpleDateFormat. 
	 * This is deprecated because
	 * you should be using Calendar instead of Date.
	 * @param str the String to parse.
	 * @return a java.util.Date Object.
	 * @throws ParseException if the string is badly formatted.
	 * @deprecated use parse(String str, Calendar destination) instead.
	 */
	public java.util.Date parse(String str) throws ParseException
	{
		synchronized(SimpleDateFormat.class){
			setup();
			parse(str,cal,0);
			return cal.getTime();
		}
	}
	/**
	 * An option to parse(String,Calendar,options). If there is no TimeZone
	 * information in the String to parse (no 'z' or 'Z' in the format String)
	 * this option tells parse() to set
	 * the destination Calendar's TimeZone value to the default TimeZone. 
	 * This is exclusive of OPTION_PARSE_MISSING_TIME_ZONE_TO_GMT.
	 * If neither value is specified as an option, the TimeZone information
	 * in the destination Calendar is not changed.
	 */
	public static final int OPTION_PARSE_MISSING_TIME_ZONE_TO_DEFAULT = 0x1;
	/**
	 * An option to parse(String,Calendar,options). If there is no TimeZone
	 * information in the String to parse (no 'z' or 'Z' in the format String)
	 * this option tells parse() to set
	 * the destination Calendar's TimeZone value to the GMT (zero offset) TimeZone.
	 * This is exclusive of OPTION_PARSE_MISSING_TIME_ZONE_TO_DEFAULT.
	 * If neither value is specified as an option, the TimeZone information
	 * in the destination Calendar is not changed.
	 */
	public static final int OPTION_PARSE_MISSING_TIME_ZONE_TO_GMT = 0x2;
	
	/**
	 * This is used to parse a String for the TimeZone offset value. It
	 * is meant to parse the offset in the form "GMT+HH:MM" or "+HHMM"
	 * If "GMT" is used data before the GMT is considered a description
	 * of the TimeZone and ignored.
	 * <p>
	 * You can override this if you want to change how TimeZones are parsed.
	 * 
	 * @param src the source String.
	 * @param startPosition the starting index in the String.
	 * @param destination the non-null destination SimpleTimeZone. Call
	 * setRawOffset() to set the raw offset.
	 * @return the index of the character after the TimeZone section of the
	 * String.
	 * @throws ParseException if the TimeZone is missing or badly formatted.
	 */
	protected int parseTimeZoneOffset(String src, int startPosition, SimpleTimeZone destination) throws ParseException
	{
		try{
			char[] ch = Vm.getStringChars(src);
			int len = src.length();
			boolean isGMT = false;
			int sp = startPosition;
			int idx = src.indexOf("GMT",sp);
			if (idx != -1){
				isGMT = true;
				sp = idx+3;
			}
			int sign = ch[sp];
			if (sign != '+' && sign != '-') throw new ParseException(src,sp);
			
			//
			// GMT time allows for a single digit hour but always
			// a double digit minute.
			//
			int h = -1, m = -1;
			int c = sp+1;
			if (!Character.isDigit(ch[c])) throw new ParseException(src,c);
			h = ch[c]-'0';
			c++;
			if (ch[c] != ':'){
				if (!Character.isDigit(ch[c])) throw new ParseException(src,c);
				h *= 10;
				h += ch[c]-'0';
				c++;
			}else{
				if (!isGMT) throw new ParseException(src,c);
			}
			if (h > 23) throw new ParseException(src,c);
			//
			if (isGMT){
				if (ch[c] != ':') throw new ParseException(src,c);
				c++;
			}
			//
			if (!Character.isDigit(ch[c])) throw new ParseException(src,c);
			m = ch[c++]-'0';
			if (!Character.isDigit(ch[c])) throw new ParseException(src,c);
			m *= 10; m += ch[c++]-'0';
			if (m > 59) throw new ParseException(src,c);
			//
			if (c < ch.length && Character.isDigit(ch[c]))
				throw new ParseException(src,c);
			//
			int offset = h*60*60*1000;
			offset += m*60*1000;
			if (sign == '-') offset = -offset;
			//
			destination.setRawOffset(offset);
			StringBuffer sb = new StringBuffer();
			sb.append("GMT");
			sb.append((char)sign);
			sb.append(h/10); sb.append(h%10);
			sb.append(":");
			sb.append(m/10); sb.append(m%10);
			destination.setID(sb.toString());
			return c;
		}catch(IndexOutOfBoundsException ob){
			throw new ParseException(src,startPosition);
		}
	}
	/**
	 * Parse the String using this Object's formatting.
	 * @param str the String to parse.
	 * @param dest an optional destination Calendar. If it is null a new
	 * one is created and returned.
	 * @param options the OPTION_PARSE_XXX values OR'ed together. 
	 * @return the destination Calendar.
	 * @throws ParseException if the String was not properly formatted for
	 * the date.
	 */
	public Calendar parse(String str,Calendar dest,int options) throws ParseException
	{
		if (dest == null) dest = Calendar.getInstance();
		TimeZone tz = null;
		synchronized(SimpleDateFormat.class){
			setup();
			String source = str;
			try{
				Locale locale = getLocale();
				StringBuffer sb = new StringBuffer();
				char spec = 0;
				int count = 0;
				int l = format.length();
				int src = 0;
				for(int i = 0; i<l+1; i++){
					char ch = i == l ? 0 : format.charAt(i);
					if (ch == spec) count++;
					else {
						if (spec != 0){
							boolean digit = false;
							int sl = source.length();
							for(;src<sl;src++) if (source.charAt(src) != ' ') break;
							int st;
							for (st = src; src<sl; src++){
								char sc = source.charAt(src);
								if (st == src) digit = (sc >= '0' && sc <= '9');
								else if (digit) {
									if (sc < '0'|| sc > '9') break;
								}else{
									if (sc == '.') continue;
									if ((sc | 0x20) < 'a' || (sc | 0x20) > 'z') break;
								}
							}
							String data = st < sl ? source.substring(st,src) : "";
							int val = Convert.toInt(data);
							if (count >= 3 && spec == 'd') spec = 'E';
							//System.out.println(spec+" = "+data);
							switch(spec){
								case 'y':
									if (!digit) throw new ParseException(str,i);
									t.year = val;
									if (t.year < 1000)
										if (count < 4) 
											if (t.year <= 49) t.year += 2000;
											else t.year += 1900;
									break;
								case 'M':
									if (count > 2){
										if (digit) throw new ParseException(str,i);
										val = locale.fromString(count == 3 ? locale.SHORT_MONTH:locale.MONTH,data,0);
									}else{
										if (!digit) throw new ParseException(str,i);
									}
									if (val < 1 || val > 12) throw new ParseException(str,i);
									t.month = val;
									break;
								case 'd':
									if (!digit) throw new ParseException(str,i);
									t.day = val;
									break;
								case 'H':
								case 'h':
									if (val < 0 || val > 23) throw new ParseException(str,i);
									t.hour = val;
									break;
								case 'm':
									if (val < 0 || val > 59) throw new ParseException(str,i);
									t.minute = val;
									break;
								case 's':
									if (val < 0 || val > 59) throw new ParseException(str,i);
									t.second = val;
									break;
								case 'S':
									if (val < 0 || val > 999) throw new ParseException(str,i);
									t.millis = val;
									break;
								case 't':
								case 'a':
									val = locale.fromString(locale.AM_PM,data,0);
									if (val == -1) throw new ParseException(str,i);
									if (val == 0) {
										if (t.hour == 12) t.hour = 0;
										else if (t.hour > 12) throw new ParseException(str,i);
									}else{
										if (t.hour < 12) t.hour += 12;
									}
									break;
								case 'z':
								case 'Z':
									if (data.length() == 0) throw new ParseException(str,i);
									tz = new SimpleTimeZone(0,"");
									i = parseTimeZoneOffset(str, st, (SimpleTimeZone)tz);
									i--;
									break;
							}
						}
						spec = 0;
						count = 0;
			// Starting a new sequence			
						if (ch == 0) break;
						if ((ch | 0x20) >= 'a' && (ch | 0x20) <= 'z') {
							spec = ch;
							count = 1;
							continue;
						}else if (ch == '\''){
							int did = 0;
							for (i++;i<l;i++){
								char c2 = format.charAt(i);
								if (c2 == '\'') {
									if (did == 0) src++;
									break;
								}else{
									src++;
									did++;
								}
							}
							continue;
						}
						src++;
					}
				}
				}finally{
				}
			}
		t.toCalendar(dest);
		if (tz == null){
			if ((options & OPTION_PARSE_MISSING_TIME_ZONE_TO_DEFAULT) != 0)
				tz = TimeZone.getDefault();
			else if ((options & OPTION_PARSE_MISSING_TIME_ZONE_TO_GMT) != 0)
				tz = new SimpleTimeZone(0,"GMT+00:00");
		}
		if (tz != null) dest.setTimeZone(tz);
		return dest;
	}
	/**
	 * Parse the String using this Object's formatting.
	 * @param str the String to parse.
	 * @param dest an optional destination Time. If it is null a new
	 * one is created and returned.
	 * @return the destination Time.
	 * @throws ParseException if the String was not properly formatted for
	 * the date.
	 */
	public Time parse(String str,Time dest) throws ParseException
	{
		synchronized (SimpleDateFormat.class) {
			setup();
			parse(str,cal,OPTION_PARSE_MISSING_TIME_ZONE_TO_DEFAULT);
			dest.fromCalendar(cal);
			return dest;
		}
		/*
		if (dest == null) dest = new Time();
    	if (!Time.fromString(str, dest, format, locale))
    		throw new ParseException(str,0);
    	return dest;
    	*/
	}
	
	/**
	 * Format the specified date. It is deprecated because you should use
	 * a Calendar instead.
	 * @param date the Date to format.
	 * @return the Date formatted for this SimpleDateFormat.
	 * @deprecated use format(java.util.Calendar) instead.
	 */
	public String format(java.util.Date date)
	{
		synchronized(SimpleDateFormat.class){
			setup();
			cal.setTime(date);
	    	t.fromCalendar(cal);
	    	return Time.toString(t,format,locale);
		}
	}
	/**
	 * Format the date specified in the Calendar as a String.
	 * @param c the date in the Calendar.
	 * @return the date formatted as a String.
	 */
	public String format(Calendar c)
	{
		synchronized(SimpleDateFormat.class){
			setup();
	    	t.fromCalendar(c);
	    	return t.format(c.getTimeZone(), format, locale);
		}
	}
	/**
	 * Format the date specified in the Time as a String.
	 * @param t the date in the Time.
	 * @return the date formatted as a String.
	 */
	public String format(Time t)
	{
	    return t.format(TimeZone.getDefault(),format,locale);
	}
	/**
	 * Format the date specified in the Time as a String.
	 * @param t the date in the Time.
	 * @param tz the TimeZone for the Time.
	 * @return the date formatted as a String.
	 */
	public String format(Time t, TimeZone tz)
	{
	    return t.format(tz,format,locale);
	}
	public static void main(String[] args) throws ParseException
	{
		Vm.startEve(args);
		try{
			String fm = "EEE dd/MMM/yyyy HH:mm";
			SimpleDateFormat sdf = new SimpleDateFormat(fm);
			Time t = new Time();
			String s = sdf.format(t)+" -0112";
			System.out.println("Original: "+s);
			t = new Time(22,8,2000);
			t.format = fm;
			if (!Time.fromString(s,t,t.format,null))
				System.out.println("Did not get it!");
			System.out.println("Got: "+t);
			sdf = new SimpleDateFormat(fm+" z");
			sdf.locale = Vm.getLocale();
			Calendar got = sdf.parse(s, (Calendar)null,0);
			System.out.println("Parsed  : "+sdf.format(got));
		}catch(ParseException pe){
			System.out.println("Parse error: "+pe.getMessage().substring(pe.getErrorOffset()));
		}
		//Vm.exit(0);
	}
	
}
