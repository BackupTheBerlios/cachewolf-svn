package eve.sys;
//##################################################################
public interface IRegistryKey{
//##################################################################
	
/**
 * Return the topmost key.
 */
public IRegistryKey getRootKey();
/**
 * This should never return null, even if the subkey does not exist
 * or is illegal in some way.
 * @param subkeyPath the subkey path relative to this key.
 * @return a new IRegistryKey that is the subkey of this one.
 */
public IRegistryKey getSubKey(String subkeyPath);
/**
 * If the key does not exist, create it.
 * @param createFullPath if this is true then create all parent keys too.
 * @return true if it was created, false if not.
 */
public boolean createKey(boolean createFullPath);
/**
 * Return true if the key already exists.
 */
public boolean keyExists();

public String getFullKeyPath();
/**
 * Get the name to dipslay for the key. This is not necessarily be its subname in the path.
 */
public String getKeyName();
/**
 * This should only return null for the root key.
 * @return
 */
public IRegistryKey getParentKey();

/**
* This returns either a String or a byte array, or an Integer (representing a 32-bit value)
* or a StringBuffer for an expanding String or null. If valueName
* is null or an empty String then the default value will be returned.
**/
//===================================================================
public Object getValue(String valueName);

/**
* Get a value at the specified index. The name of the value is placed in the
* valueName StringBuffer. The return value is either a String or a byte array
* or an Integer (representing a 32-bit value) or a StringBuffer for an expanding String or null.
*
 * @param index the index of the value.
 * @param valueName a StringBuffer to hold the value name.
 * @return the return value.
 * @throws IndexOutOfBoundsException if the index is too high.
 */
public Object getValue(int index,StringBuffer valueName) throws IndexOutOfBoundsException;
//===================================================================
/**
* Delete a value with the specified name.
**/
//===================================================================
public boolean deleteValue(String name);
//===================================================================
/**
* Delete the entire key and all its subkeys (if possible).
**/
//===================================================================
public boolean deleteKey();
//===================================================================
public boolean setExpandingString(String name,String value);
/**
* Set a String value.
**/
//===================================================================
public boolean setValue(String name,String value);
//===================================================================
/**
* Set a binary data value.
**/
//===================================================================
public boolean setValue(String name,byte [] value);
//===================================================================
/**
* Set a 32-bit data value in the default little-endian format.
**/
//===================================================================
public boolean setValue(String name,int value); 
//===================================================================
//-------------------------------------------------------------------
public String getSubKey(int index) throws IndexOutOfBoundsException;
//-------------------------------------------------------------------
public int getSubKeyCount();
public int getValueCount();
/**
* This is an option for getSubKeys(int options).
**/
public static final int SORT_DONT_SORT = 0x1;
/**
* This is an option for getSubKeys(int options).
**/
public static final int SORT_CASE_SENSITIVE = 0x2;
/**
* This is an option for getSubKeys(int options).
**/
public static final int SORT_DESCENDING = 0x4;
/**
* This is an option for getSubKeys(int options) - when used getSubKey() will return
* an array of integers representing the indexes of all the sub-keys.
**/
public static final int GET_INDEXES = 0x8;
/**
/**
* This is an option for getSubKeys(int options) - when used getSubKey() will return
* an array of longs representing the indexes of all the sub-keys.
**/
public static final int GET_INDEXES_AS_LONGS = 0x10;


/**
 * Return an array of Strings or an array of integers or array of longs representing the
 * subkeys of this key.
 * @param options By default this will return an array of sorted Strings. If the GET_INDEXES
 * option is used, then an array of integer indexes (sorted by the sub-key name) will be returned.
 * If the GET_INDEXES_AS_LONGS option isused, then an array of long indexes (sorted by the sub-key name) will be returned.
 & <p>If SORT_DONT_SORT is used then the subkey list returned is not sorted.
 * @return an array of Strings or an array of integers or array of longs representing the
 * subkeys of this key. 
 */

public Object getSubKeys(int options);

//-------------------------------------------------------------------
//##################################################################
}
//##################################################################
