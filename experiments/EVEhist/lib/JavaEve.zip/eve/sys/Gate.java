package eve.sys;
import java.util.Vector;
import java.util.Hashtable;
/** 
* This allows only a single Thread to hold a Gate at a time.
**/
//##################################################################
public class Gate{
//##################################################################
/**
* If this is true then a thread can call hold()/grab() on a gate
* multiple times - defaults to true. 
* There must be a matching release() call for every hold()/grab() call.
**/
public boolean multipleEntry = true;
//
private int entered = 0;
private Thread owner = null;
private Vector waitingToHold;
private Hashtable left;
public String name = null;
//
public Gate()
{
	
}
public Gate(String name)
{
	this.name = name;
}
/**
 * This attempts to hold the gate, waiting an indefinite time to do so. Unlike
 * the hold/grab methods, this method returns no value and will throw a run-time exception
 * if the gate could not be held for any reason (since this will represent a severe error).
 */
//===================================================================
public void synchronize()
//===================================================================
{
	while(true){
		try{
			if (!doHold(TimeOut.Forever,true)) throw new RuntimeException("synchronize() failure!");
			return;
		}catch(InterruptedException e){
			continue;
			 //throw new RuntimeException("synchronize() failure!");
		}
	}
}
/**
* This tries to get ownership of the gate, but will not wait
* if it cannot get ownership immediately. It returns true if it got ownership,
* false if it did not. This method CAN be called by threads of execution which
* are NOT mThreads since it never attempts to wait for ownership. There must
* be a matching release() for every grab().
* @return true if the gate was acquired - false if not.
*/
//===================================================================
public boolean grab() 
//===================================================================
{
	try{
		return doHold(null,false);
	}catch(InterruptedException e){
		return false;
	}
}
/**
 * Attempt to acquire ownership of the Gate, waiting for a specific length of time.
 * @param t The length of time to wait for.
 * @return true if it acquired the gate, false if it did not.
 * @exception InterruptedException If the Thread was interrupted.
 */
//===================================================================
public boolean lock(TimeOut t) throws InterruptedException
//===================================================================
{
	return doHold(t,true);
}
/**
 * Attempt to acquire ownership of the Gate, waiting indefinitely.
 * @exception InterruptedException If the Thread was interrupted while waiting for the gate.
 */
//===================================================================
public void lock() throws InterruptedException
//===================================================================
{
	doHold(TimeOut.Forever,true);
}
/**
Return the owner of the gate.
*/
//===================================================================
public Thread getOwner()
//===================================================================
{
	return owner;	
}
/**
Return if the current thread is the owner of the gate.
*/
//===================================================================
public synchronized boolean amOwner()
//===================================================================
{
	return Thread.currentThread() == owner;
}
//-------------------------------------------------------------------
private boolean own(Thread newOwner)
//-------------------------------------------------------------------
{
	owner = newOwner;
	entered++;
	return true;
}
//-------------------------------------------------------------------
private synchronized boolean doHold(TimeOut t,boolean waitForIt) throws InterruptedException
//-------------------------------------------------------------------
{
	Thread cr = Thread.currentThread();
	if (entered == 0) return own(cr);
	//
	if (t == null) t = TimeOut.Forever;
	if (cr == owner){
 		if (multipleEntry) {
			entered++;
			return true;
		}else if ((t.remaining() == t.Infinite) && waitForIt) 
			throw new IllegalThreadStateException("Gate Deadlock!");
	}
//......................................................
// Have to wait.
//......................................................
	//
	if (!waitForIt || t == TimeOut.Immediate) return false;
	//
	if (Vm.inSystemThread()) throw new InvalidThreadException();
	return doWait(cr,t,true);
}
/*
private void debug(String message,Thread cr)
{
	String nm = name;
	if (nm == null) nm = "";
	System.out.println(cr+" "+message+" "+nm);
}
*/
//-------------------------------------------------------------------
private boolean doWait(Thread cr,TimeOut t,boolean allowInterrupt) throws InterruptedException
//-------------------------------------------------------------------
{
	if (waitingToHold == null) waitingToHold = new Vector();
	waitingToHold.add(cr);
	while(true){
		if (waitingToHold.indexOf(cr) == -1) {
			//debug("Held",cr);
			return true;
		}
		if (t.hasExpired()) return false;
		try{
			t.waitOn(this);
		}catch(InterruptedException e){
			if (waitingToHold.indexOf(cr) == -1) return true;
			if (!allowInterrupt) continue;
			waitingToHold.removeElement(cr);
			throw e;
		}
	}
	
}
//-------------------------------------------------------------------
private void wakeWaiting()
//-------------------------------------------------------------------
{
	notifyAll();
	if (waitingToHold == null) return;
	if (waitingToHold.size() == 0) return;
	Thread cr = (Thread)waitingToHold.get(0);
	waitingToHold.removeElementAt(0);
	own(cr);
}
/**
* Release the gate. This can only be called by the owning thread.
* This is the same as unlock() except unlock will throw an exception
* if the calling thread is not the gate owner.
**/
//-------------------------------------------------------------------
public synchronized final boolean release()
//-------------------------------------------------------------------
{
	Thread cr = Thread.currentThread();
	if (cr != owner || entered <= 0) return false;
	entered--;
	//debug("release",cr);
	if (entered == 0){
		owner = null;
		wakeWaiting();
	}
	return true;
}
/**
* Release the gate. This can only be called by the owning thread.
**/
//===================================================================
public synchronized void unlock() throws IllegalThreadStateException
//===================================================================
{
	if (!release()) throw new IllegalThreadStateException("The calling thread does not own the gate.");
}
/**
Temporarily leave the Gate, to re-enter it again later.
Every call of leave() must be eventually followed by a call to reEnter()
before the Thread can call unlock(). You can call this even if the Thread does not
currently own the Gate. It will have no effect.
*/
//===================================================================
public synchronized void leave() throws IllegalThreadStateException
//===================================================================
{
	Thread t = Thread.currentThread();
	if (owner != t) return;
	Integer held = new Integer(entered);
	if (left == null) left = new Hashtable();
	left.put(t,held);
	entered = 0;
	owner = null;
	wakeWaiting();
}
/**
Re-enter the Gate having left with the leave() call. Even if the Thread did not own the
gate you can still make this call. It will return false if the Thread did not previously
own the gate.
*/
//===================================================================
public synchronized boolean reEnter()
//===================================================================
{
	Thread t = Thread.currentThread();
	Object got = left == null ? null : left.get(t);
	if (got == null) return false;
	left.remove(t);
	int toReenter = ((Integer)got).intValue();
	if (owner != null) try{
		doWait(t,TimeOut.Forever,false);
	}catch(InterruptedException e){
		//This should never happen.
	}
	owner = t;
	entered = toReenter;
	return true;
}
/**
 * Hand off ownership of this gate to another Thread.
 * @param other the other Thread to hand off to.
 * @throws IllegalThreadStateException if the current thread does not hold the gate.
 */
public synchronized void handoff(Thread other) throws IllegalThreadStateException
{
	Thread t = Thread.currentThread();
	if (owner != t) throw new IllegalThreadStateException();
	owner = other;
	return;
}
//##################################################################
}
//##################################################################

