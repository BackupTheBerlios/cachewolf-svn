/*
 * Created on Nov 8, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface ITaskbarEntry {
	/**
	 * Get an event dispatcher to add listeners.
	 */
	public EventDispatcher getEventDispatcher();
	public static int SET_ICON_IS_VALID = 0x1;
	public static int SET_TIP_IS_VALID = 0x2;
	/**
	 * This is an event that may be generated.
	 */
	public static final int PEN_PRESSED_ON_ICON = 1;
	/**
	 * Set the icon and/or tip.
	 * @param icon the icon to set. If this is null both the icon an the tip will disappear.
	 * @param tip the tip for the icon. This can be null for no tip.
	 * @param validItems one or more of the SET_XXX values ORed together.
	 * @return true if successful, false if not.
	 */
	public boolean setIconAndTip(DeviceIcon icon, String tip, int validItems);
	/**
	 * A quick way to remove the icon. This just calls setIconAndTip(with a null icon and tip).
	 */
	public boolean removeIcon();
	/**
	 * Close the taskbar Entry - remove the icon and tip.
	 */
	public void close();
}
//####################################################
