/*
 * Created on Apr 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public abstract class WeakResource extends WeakReference {

private static ReferenceQueue queue;

private static synchronized ReferenceQueue getQueue()
{
	if (queue == null){
		queue = new ReferenceQueue();
		new Thread(){
			public void run(){
				try{
					while(true){
						WeakResource wr = (WeakResource)queue.remove();
						wr.cleared();
					}
				}catch(Throwable t){}
			}
		}.start();
	}
	return queue;
}

protected WeakResource(Object forOwner)
{
	super(forOwner, getQueue());
	if (forOwner == null) throw new NullPointerException();
}

/**
 * Return the owner of the resources - unless the owner is no longer being
 * referred to by any other strong references and may have been garbage
 * collected. In this case the method return null. The cleared() method will
 * be called at some point once the owner has been garbage collected.
 */
public Object getResourceOwner()
{
	return get();
}
/**
 * This is called when the owner object has been garbage collected. 
 */
protected abstract void cleared();
}

//####################################################
