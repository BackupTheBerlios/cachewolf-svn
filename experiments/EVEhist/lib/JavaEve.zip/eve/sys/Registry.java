/*
 * Created on Feb 25, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Hashtable;
import java.util.Vector;

import eve.io.File;
import eve.io.Io;
import eve.io.StreamUtils;
import eve.util.ByteArray;
import eve.util.mString;

/**
 * This class provides a simplified interface to the eve.sys.registry 
 * functions, but this Registry class will always be present
 * even if eve.sys.registry is not.
 */
//####################################################
public class Registry {
	public static final String REGISTRY_LOCAL = "local_registry";
	public static final String REGISTRY_REMOTE = "remote_registry";
	
	/**
	 * This is a hashtable of all the IRegistryKey objects representing the top level
	 * key available to the System. You can
	 * add to it or remove from it as needed. There are two reserved key names for the 
	 * native local (REGISTRY_LOCAL) and remote (REGISTRY_REMOTE) registries. These will
	 * be present if the eve.sys.registry package is available.
	 */
	public static Hashtable registries = new Hashtable();
	
	private static Type regType;
	static{
		Type regType = new Type("eve.sys.registry.Registry");
		if (regType.exists()){
			Object got = regType.invoke(null,"getLocalRegistry()Leve.sys.IRegistryKey;",null);
			registries.put(REGISTRY_LOCAL,got != null ? got : new RegistryKeyObject("No Local Registry Access"));
			//got = regType.invoke(null,"getRemoteRegistry()Leve.sys.IRegistryKey;",null);
			//registries.put(REGISTRY_REMOTE,got != null ? got : new RegistryKeyObject("No Remote Registry Access"));
		}
	}

	public static IRegistryKey getLocalRegistry()
	{
		return (IRegistryKey)registries.get(REGISTRY_LOCAL);
	}
	public static IRegistryKey getRemoteRegistry()
	{
		Type regType = new Type("eve.sys.registry.Registry");
		if (regType.exists()){
			return (IRegistryKey)regType.invoke(null,"getRemoteRegistry()Leve.sys.IRegistryKey;",null);
		}else
			return new RegistryKeyObject("No Remote Registry Access");
		//return (IRegistryKey)registries.get(REGISTRY_REMOTE);
	}
	/**
	* An option for associateFile().
	**/
	public static final int ASSOCIATE_VM_APPLICATION = 0x1;
	/**
	* An option for associateFile().
	**/
	//public static final int ASSOCIATE_ICON_IS_RESOURCE = 0x2;

//	-------------------------------------------------------------------
	private static IRegistryKey makeClassesRoot(String name) throws IOException
//	-------------------------------------------------------------------
	{
		boolean create = true;
		try{
			IRegistryKey key = getLocalRegistry();
			if (key == null) throw new Exception(); 
			key = key.getSubKey("HKEY_CLASSES_ROOT\\"+name);
			if (!key.keyExists() && create) key.createKey(true);
			if (!key.keyExists()) throw new Exception();
			return key;
		}catch(Exception e){
			throw new IOException("Could not create registry key.");
		}
	}
//	-------------------------------------------------------------------
	private static void checkValue(boolean value) throws IOException
//	-------------------------------------------------------------------
	{
		if (!value) throw new IOException("Could not set registry value.");
	}

//	-------------------------------------------------------------------
	private static String quotedVmPath(String commandLine) throws IOException
//	-------------------------------------------------------------------
	{
		String path = Device.getPathToVm();
		if (path == null) throw new IOException("Could not get path to VM");
		if (!(path.charAt(0) == '"')) path = "\""+path+"\"";
		if (commandLine != null) commandLine = path+" "+commandLine;
		else commandLine = path;
		return File.toSystemDependantPath(commandLine);
	}
	/**
	 * This associates files with a certain extension to a particular application.
	 * @param extension This is the file extension (e.g. ".pnf")
	 * @param shortFileDescription This is a mandatory short file description (e.g. "JewelFile");
	 * @param fileDescription This is an optional long file description (e.g. "Jewel Program Specs")
	 * @param commandLine This is the command line to execute - it will usually include "%1" (including the quotes)
		within it to indicate where the file name gets inserted into the command line passed to the application. If you want to execute a .eve file,
		then set the command line to point to the .eve file (in quotes) and then set options to
		be ASSOCIATE_VM_APPLICATION.
	 * @param icon The file name of an optional icon to associate with files of this extension.
	 * @param options Can be any of the following values ORed together: <br>
		<b>ASSOCIATE_ICON_IS_RESOURCE</b> - this indicates that the specified icon resides as a resource
		with the application and should be extracted and saved to the file system if necessary. 
		If this is not selected then the icon is assumed to be an absoulte file name.<br>
	  <b>ASSOCIATE_VM_APPLICATION</b> - this indicates that the Eve VM should be used to start
		the application.
	 * @exception IOException If an error occurs saving the registry information.
	 */
//	===================================================================
	public static void associateFile(String extension,String shortFileDescription,String fileDescription,String commandLine,String icon,int options)
	throws IOException
//	===================================================================
	{
		IRegistryKey key;
		if (extension.charAt(0) != '.') extension = "."+extension;
		if (shortFileDescription == null) throw new IllegalArgumentException();
		shortFileDescription = shortFileDescription.replace(' ','_');
		extension = extension.toLowerCase();
		checkValue(makeClassesRoot(extension).setValue(null,shortFileDescription));
		key = makeClassesRoot(shortFileDescription);
		if (fileDescription != null) checkValue(key.setValue(null,fileDescription));
		if (icon != null){
			File f = File.getNewFile(icon);
			if (!f.exists()) f = File.getNewFile(File.getProgramDirectory()).getChild(icon);
			if (f.exists()) icon = f.getAbsolutePath();
			if (!f.exists()){// || (options & ASSOCIATE_ICON_IS_RESOURCE) != 0)){
				icon = icon.replace('\\','/');
				String iconName = icon;
				int last = icon.lastIndexOf("/");
				if (last != 0) iconName = icon.substring(last+1);
				try{
					File outFile = File.getNewFile(File.getProgramDirectory()).getChild(iconName);
					if (!outFile.exists()){
						InputStream in = Vm.openResource(null,icon);
						OutputStream out = outFile.toWritableStream(false);
						StreamUtils.transfer(null,in,out);
						in.close();
						out.close();
					}
					icon = outFile.getAbsolutePath();
				}catch(RuntimeException e){
					throw new IOException("Could not access or save icon.");
				}
			}
			checkValue(makeClassesRoot(shortFileDescription+"\\DefaultIcon").setValue(null,"\""+File.toSystemDependantPath(icon)+"\""));
		}
		if (commandLine != null){
			if ((options & ASSOCIATE_VM_APPLICATION) != 0)
				commandLine = quotedVmPath(commandLine);
			checkValue(makeClassesRoot(shortFileDescription+"\\Shell\\Open\\Command").setValue(null,commandLine));
		}
	}
	/**
	 * This associates files with a certain extension to the running application. The running
	 * application should be run from a ".eve" file or from a ".exe" file created from a ".eve" file.
	 * @param extension This is the file extension (e.g. ".pnf")
	 * @param shortFileDescription This is a mandatory short file description (e.g. "JewelFile");
	 * @param fileDescription This is an optional long file description (e.g. "Jewel Program Specs")
	 * @param arguments These are the arguments to pass to the application - it will usually include "%1" (including the quotes)
		within it to indicate where the file name gets inserted into the command line passed to the application.
	 * @param icon The file name of an optional icon to associate with files of this extension.
	 * @param options Can be any of the following values ORed together: <br>
		<b>ASSOCIATE_ICON_IS_RESOURCE</b> - this indicates that the specified icon resides as a resource
		with the application and should be extracted and saved to the file system if necessary. 
		If this is not selected then the icon is assumed to be an absolute file name.<br>
	 * @exception IOException If an error occurs saving the registry information.
	 */
//	===================================================================
	static void associateFileWithMe(String extension,String shortFileDescription,String fileDescription,String arguments,String icon,int options)
	throws IOException
//	===================================================================
	{
		String command = getCommandLineToMe();
		if (command == null) throw new IOException("Command line to running program could not be found.");
		command += " \"%1\"";
		associateFile(extension,shortFileDescription,fileDescription,command,icon,options);
		if (true) return;
		
		
		options &= ~ASSOCIATE_VM_APPLICATION;
		//boolean isVm = false;
		//
		// NOTE: the Vm.getProperty() method will return null for this call IF
		// the path of this exe matches the path of the VM exe.
		// In that case we will assume it is running from a .eve file.
		//
		String exe = Vm.getProperty("this.exe.path",null);
		if (exe == null){
			//isVm = true;
			options |= ASSOCIATE_VM_APPLICATION;
			exe = Vm.getProperty("this.eve.path",null);
			if (exe == null) throw new IOException("The application is not being run in a eve or exe file.");
		}else
			exe = File.toSystemDependantPath(exe);
		exe = "\""+exe+"\"";
		if (arguments != null) exe += " "+arguments;
		else exe += " \"%1\"";
		//ewe.sys.Vm.debug("Associate: "+exe);
		associateFile(extension,shortFileDescription,fileDescription,exe,icon,options);
	}
	/**
	 * This associates files with a certain extension to the running application. The running
	 * application should be run from a ".eve" file or from a ".exe" file created from a ".eve" file.
	 * @param extension This is the file extension (e.g. ".pnf")
	 * @param shortFileDescription This is a mandatory short file description (e.g. "JewelFile");
	 * @param fileDescription This is an optional long file description (e.g. "Jewel Program Specs")
	 * @param arguments These are the arguments to pass to the application - it will usually include "%1" (including the quotes)
		within it to indicate where the file name gets inserted into the command line passed to the application.
	 * @param icon The file name of an optional icon to associate with files of this extension.
	 * @exception IOException If an error occurs saving the registry information.
	 */
//	===================================================================
	public static void associateFileWithMe(String extension,String shortFileDescription,String fileDescription,String icon)
	throws IOException
//	===================================================================
	{
		associateFileWithMe(extension,shortFileDescription,fileDescription,null,icon,0);
	}
//	public native static Object nativeTest(Object who);
//	===================================================================
	/**
	 * This is the same as Vm.execCommandLine(). Runs a command line with quoted executable. 
	 * It is always safest to place the executable in quotes (") in case it has
	 * spaces in it. This will remove those quotes and place it as a single String
	 * as the first command. If there are quotes in any other arguments, those
	 * other quotes are preserved. The path of the executable is also corrected
	 * to use the correct system directory separators. 
	 * @param commandLine the command line to use, the executable may
	 * be placed in quotes.
	 * @return the Process executed.
	 * @throws IOException if the command line could not be executed.
	 */
	public static Process execCommandLine(String commandLine) throws IOException
	{
		return Vm.execCommandLine(commandLine);
	}
	/**
	 * Get the command line to the preferred Eve VM, given additional commands
	 * to run.
	 * @param commandsToRun the user command line to give to the VM.
	 * @return a new command line that you should execute using execCommandLine(String commandLine)
	 * or null if the path to the VM could not be determined.
	 */
	public static String getVmCommandLine(String commandsToRun)
	{
		return getVmCommandLine(commandsToRun,null);
	}
	/**
	 * Get the command line to the preferred Eve VM, given additional commands
	 * to run.
	 * @param commandsToRun the user command line to give to the VM.
	 * @param vmCommands VM options (like -R90, etc) which can be null.
	 * @return a new command line that you should execute using execCommandLine(String commandLine)
	 * or null if the path to the VM could not be determined.
	 */
	public static String getVmCommandLine(String commandsToRun, String vmCommands)
	{
		String got = getShellCommandForExtension("eve");
		if (commandsToRun == null) commandsToRun = "";
		if (vmCommands == null) vmCommands = "";
		if (got == null) {
			got = Device.getPathToVm();
			if (got == null) return null;
			File f = File.getNewFile(got).getParentFile();
			File child = f.getChild("eve.eve");
			if (child.exists()) commandsToRun = "\""+child.getAbsolutePath()+"\" "+commandsToRun;
			return (got + vmCommands+" "+commandsToRun).trim();
		}
		int idx = got.indexOf("%1");
		if (idx != -1) {
			if (idx != 0 && got.charAt(idx-1) == '\"') idx--;
			got = got.substring(0,idx);
		}
		return (got + vmCommands+" "+commandsToRun).trim();
	}
	/**
	* Create an absolute command line to execute the Eve VM on my Eve file. 
	* @param myEveFile the name (without a path specification) of the Eve file this application
	* is packaged in. If it is null the VM will attempt to lookup the name of the currently running
	* .eve file.
	* @param extraArguments Additional application arguments - can be null.
	* @param vmArguments Additional VM arguments - can be null.
	* @param includePathToVM Set this true to include the path to the VM.
	* @return An absolute command line for executing the currently running application.
	* @exception IOException if there is a problem with any of the data.
	* @deprecated 
	*/
	/*
//	===================================================================
	public static String getVmCommandLine(String myEveFile,String extraArguments,String vmArguments,boolean includePathToVM)
	throws IOException
//	===================================================================
	{
		String myName = null;
		if (myEveFile != null){
			File pd = File.getNewFile(File.getProgramDirectory()).getChild(myEveFile);
			myName = "\""+pd.getAbsolutePath()+"\"";
		}else{
			myEveFile = Vm.getProperty("this.eve.path",null);
			if (myEveFile == null) throw new IOException("Cannot determine Eve file.");
			myName = "\""+myEveFile+"\"";
		}
		if (vmArguments != null) myName = vmArguments+" "+myName;
		if (extraArguments != null) myName += " "+extraArguments;
		if (includePathToVM) return quotedVmPath(myName);
		else return myName;
	}
	*/
	/**
	 * Get the shell command for running a file with a particular extension.
	 */
	public static String getShellCommandForExtension(String extension)
	{
		if (extension.startsWith(".")) extension = extension.substring(1);
		if (extension.length() < 1) return null;
		String ty = readRegistryString("HKEY_CLASSES_ROOT\\."+extension.toLowerCase(),null);
		if (ty == null) {
			File f = new File("/usr/share/applications/defaults.list");
			if (!f.exists()) return null;
			try{
				extension = extension.toLowerCase();
				BufferedReader br = Io.getBufferedReader(f);
				String look = "/"+extension+"=";
				while(true){
					String line = br.readLine();
					if (line == null) break;
					int w = line.indexOf(look);
					if (w == -1) continue;
					String dt = line.substring(w+look.length());
					f = new File("/usr/share/applications/"+dt);
					if (!f.exists()) continue;
					br.close();
					br = Io.getBufferedReader(f);
					while(true){
						line = br.readLine();
						if (line == null) break;
						if (line.indexOf("Exec=") == -1) continue;
						int idx = line.indexOf('=');
						String cmd = line.substring(idx+1);
						br.close();
						return cmd;
					}
					br.close();
					return null;
				}
				br.close();
				return null;
			}catch(Exception e){
				return null;
			}
		}
		return readRegistryString("HKEY_CLASSES_ROOT\\"+ty+"\\Shell\\Open\\Command",null);
	}
	public static String getShellCommand(String fileName)
	{
		int idx = fileName.lastIndexOf('.');
		if (idx == -1) return null;
		String sh = getShellCommandForExtension(fileName.substring(idx+1));
		//System.out.println("Got: "+sh);
		if (sh == null) return null;
		idx = sh.indexOf("%*");
		if (idx != -1) sh = sh.substring(0,idx)+sh.substring(idx+2,sh.length());
		idx = sh.indexOf("%1");
		if (idx == -1) idx = sh.indexOf("%L");
		if (idx == -1) idx = sh.indexOf("%f");
		if (idx == -1) idx = sh.indexOf("%F");
		if (idx == -1) idx = sh.indexOf("%u");
		if (idx == -1) idx = sh.indexOf("%U");
		if (idx == -1) return sh+" "+File.toSystemDependantPath(fileName);
		return sh.substring(0,idx)+File.toSystemDependantPath(fileName)+sh.substring(idx+2);
	}
	public static Process executeShellCommand(String fileName) throws IOException
	{
		String got = getShellCommand(fileName);
		if (got == null) throw new IOException("Could not find shell command for: "+fileName);
		//System.out.println("Got: "+got);
		return Runtime.getRuntime().exec(got);
	}
	/**
	* Create an absolute command line to execute the Eve VM on my Eve file. 
	* @param extraArguments Additional application arguments - can be null.
	* @param vmArguments Additional VM arguments - can be null.
	* @param includePathToVM Set this true to include the path to the Eve VM.
	* @return An absolute command line for executing the currently running application.
	* @exception IOException if there is a problem with any of the data.
	*/
	/*
//	===================================================================
	public static String getVmCommandLineToMe(String extraArguments,String vmArguments,boolean includePathToVM)
	throws IOException
//	===================================================================
	{
		return getVmCommandLine(null,extraArguments,vmArguments,includePathToVM);
	}
	*/
	static void check(IRegistryKey rk)
	{
		System.out.println(rk+", Exists: "+rk.keyExists()+", with "+rk.getValueCount()+" values.");
		System.out.println(mString.toString(rk.getSubKeys(0)));
	}
	/**
	 * A quick and easy way to read a registry value. Returns null
	 * if it does not exist or if the registry could not be read.
	 * @param keyName the full path of the key include "HKEY_XXXX" values,
	 * using '\' as separators.
	 * @param valueName the name of the value or null for the default value.
	 * @return the registry value as a String, int or byte[]
	 */
	public static Object readRegistryValue(String keyName, String valueName)
	{
		IRegistryKey rk = getLocalRegistry();
		if (rk == null)  return null;
		rk = rk.getSubKey(keyName);
		return rk.getValue(valueName);
	}
	/**
	 * A quick and easy way to read a registry value as a formatted String. Returns null
	 * if it does not exist or if the registry could not be read.
	 * @param keyName the full path of the key include "HKEY_XXXX" values,
	 * using '\' as separators.
	 * @param valueName the name of the value or null for the default value.
	 * @return the String value or null if the value could not be read. If
	 * the value was not a String it is converted to a String.
	 */
	public static String readRegistryString(String keyName, String valueName)
	{
		Object obj = readRegistryValue(keyName,valueName);
		if (obj == null) return null;
		else if (obj instanceof byte[]) return ByteArray.toString((byte[])obj,true);
		else if (obj instanceof StringBuffer) return expandString(obj.toString());
		return obj.toString();
	}
	/**
	 * A quick and easy way to write a registry value as a formatted String. 
	 * Returns false if it could not be written.
	 * @param keyName the full path of the key include "HKEY_XXXX" values,
	 * using '\' as separators.
	 * @param valueName the name of the value or null for the default value.
	 * @param value the value to write.
	 * @return true on success, false on failure.
	 */
	public static boolean writeRegistryString(String keyName, String valueName, String value)
	{
		return writeRegistryValue(keyName,valueName,value);
	}
	/**
	 * A quick and easy way to write a registry value. 
	 * Returns false if it could not be written.
	 * @param keyName the full path of the key include "HKEY_XXXX" values,
	 * using '\' as separators.
	 * @param valueName the name of the value or null for the default value.
	 * @param value the value to write. This should be an Integer, or a byte[]/ByteArray,
	 * or a StringBuffer for an "Expanding String". Anything else is converted
	 * to a String and saved as a String.
	 * @return true on success, false on failure.
	 */
	public static boolean writeRegistryValue(String keyName, String valueName, Object value)
	{
		IRegistryKey rk = getLocalRegistry();
		if (rk == null)  return false;
		rk = rk.getSubKey(keyName);
		rk.createKey(true);
		if (value instanceof Integer) return rk.setValue(valueName,((Integer)value).intValue());
		else if (value instanceof byte[]) return rk.setValue(valueName,(byte[])value);
		else if (value instanceof ByteArray) return rk.setValue(valueName,((ByteArray)value).toBytes());
		else if (value instanceof StringBuffer) return rk.setExpandingString(valueName,value.toString());
		else return rk.setValue(valueName,value.toString());
	}
	/**
	 * Expand a String containing environment variables. 
	 * @param src the source string.
	 * @return the expanded String.
	 */
	public static String expandString(String src)
	{
		StringBuffer sb = new StringBuffer();
		int len = src.length();
		for (int i = 0; i<len;){
			// Find opening %
			int w = src.indexOf('%',i);
			if (w == -1 || w == len-1){
				sb.append(src.substring(i));
				break;
			}
			// Find closing %
			int e = src.indexOf('%',w+1);
			if (e == -1) {
				sb.append(src.substring(i));
				break;
			}
			if (e == w+1){
				// a %% sequence. This translates to %
				sb.append('%');
				i = w+2;
				continue;
			}
			String look = src.substring(w+1,e);
			if (look.indexOf(' ') != -1){
				// There was a space in between, so this % is not
				// an opening %.
				sb.append(src.substring(i,e));
				i = e;
				continue;
			}
			String got = Vm.getenv(look);
			if (got == null) sb.append(src.substring(i,e+1));
			else sb.append(got);
			i = e+1;
		}
		return sb.toString();
	}
/**
 * A quick and easy way to set a registry value.
 * @param keyName the name of the key.
 * @param valueName the name of the value or null for the default value.
 * @param value a String or byte[] or Integer or StringBuffer (for expanding string) only.
 * @return true on success, false on failure.
 */	
	public static boolean setRegistryValue(String keyName,String valueName,Object value)
	{
		IRegistryKey rk = getLocalRegistry();
		if (rk == null)  return false;
		rk = rk.getSubKey(keyName);
		if (!rk.keyExists()) rk.createKey(true);
		if (!rk.keyExists()) return false;
		if (value instanceof byte[]) return rk.setValue(valueName,(byte[])value);
		else if (value instanceof String) return rk.setValue(valueName,(String)value);
		else if (value instanceof StringBuffer) return rk.setExpandingString(valueName,value.toString());
		else if (value instanceof Integer) return rk.setValue(valueName,((Integer)value).intValue());
		else return false;
	}
	
	/**
	 * Get the Java executable on the system. On a PC this will be
	 * the "javaw.exe" or "java.exe" if javaw is not found.
	 * @return the File representing the Java VM executable or null if not found.
	 */
	public static File getJavaVM()
	{
		String jre = "HKEY_LOCAL_MACHINE\\SOFTWARE\\JavaSoft\\Java Runtime Environment";
		String jh = null;//readRegistryString(jre+"\\1.4","JavaHome");
		if (jh == null){
			jh = readRegistryString(jre,"CurrentVersion");
			if (jh == null) return null;
			jre += "\\"+jh;
			jh = readRegistryString(jre,"JavaHome");
			if (jh == null) return null;
		}
		File bin = File.getNewFile(jh).getChild("bin");
		String[] tries = mString.split("javaw.exe|javaw|java.exe|java",'|');
		for (int i = 0; i<tries.length; i++){
			File ex = bin.getChild(tries[i]);
			if (ex.exists()) return ex;
		}
		return null;
	}
	/**
	 * Get the executable file of the currently running VM. If it is running
	 * under a JavaVM, this will look up the latest Java VM in the
	 * registry. If it is running a native executable it will return
	 * the location of that executable.
	 * @return the File representing the best guess of the currently running
	 * VM or null if it cannot be determined.
	 */
	public static File getRunningVM()
	{
		String got = Vm.getProperty("this.exe.path",null);
		if (got == null && Vm.isJavaVM()) return getJavaVM();
		if (got == null) return null;
		return File.getNewFile(got);
	}
	/**
	 * Return the class paths for the running VM as a set of absolute
	 * system dependant file paths. 
	 * @return an array of Strings indicating the class paths.
	 */
	public static String[] getClassPaths()
	{
		String[] all = 
			mString.split(Vm.getProperty("java.class.path",""),File.pathSeparatorChar);
		Vector v = new Vector();
		for (int i = 0; i<all.length; i++){
			if (all[i].startsWith("\"")) all[i] = all[i].substring(1);
			if (all[i].endsWith("\"")) all[i] = all[i].substring(0,all[i].length()-1);
			File f = File.getNewFile(all[i]);
			if (!v.contains(f)) v.add(f);
		}
		all = new String[v.size()]; 
		for (int i = 0; i<all.length; i++){
			File f = (File)v.get(i);
			all[i] = File.toSystemDependantPath(f.getAbsolutePath());
		}
		return all;
	}
	static void addQuoted(StringBuffer sb, String what)
	{
		if (sb.length() != 0) sb.append(' ');
		boolean q = what.indexOf(' ') != -1;
		if (q) sb.append('"');
		sb.append(what);
		if (q) sb.append('"');
	}
	/**
	 * Return the best command line to the running application, using
	 * quotes where necessary.
	 * @return the best command line to the running application, using
	 * quotes where necessary or null if it could not be discovered.
	 */
	public static String getCommandLineToMe()
	{
		File ret = getRunningVM();
		String[] got = getClassPaths();
		String me = Vm.getProperty("vm.commands",null);
		if (me == null || ret == null) return null;
		StringBuffer sb = new StringBuffer();
		addQuoted(sb,File.toSystemDependantPath(ret.getAbsolutePath()));
		if (got.length != 0){
			addQuoted(sb,"-cp");
			String s2 = "";
			for (int i = 0; i<got.length; i++){
				if (i != 0) s2 += File.pathSeparator;
				s2 += got[i];
			}
			addQuoted(sb,s2);
		}
		sb.append(' ');
		sb.append(me);
		return sb.toString();
	}
	
	/*
	public static void main(String[] args)
	{
		Vm.startEve(args);
		IRegistryKey rk = getLocalRegistry();
		check(rk);
		rk = rk.getSubKey("HKEY_CLASSES_ROOT\\.eve");
		check(rk);
		rk = rk.getSubKey("Zoid\\MLB");
		check(rk);
		if (!rk.keyExists()) rk.createKey(true);
		check(rk);
		//System.exit(0);
	}
	*/
	/**
	 * Return the current users name.
	 */
	public static String getUserName()
	{
		String got = Vm.getenv("USER");
		if (got == null) got = Vm.getenv("USERNAME");
		return got;
	}
	/**
	 * Return the current users home directory if possible.
	 * On a Windows system if the eve.sys.registry package is available, then
	 * you should use the eve.sys.registry.Registry.getSystemFolder() instead.
	 * @return the home directory of the current user or null if it could
	 * not be determined. 
	 */
	public static String getUserHomeDirectory()
	{
		String hp = Vm.getenv("HOMEPATH");
		if (hp != null) {
			String hd = Vm.getenv("HOMEDRIVE");
			if (hd != null) hp = hd+hp;
		}
		if (hp == null) hp = Vm.getenv("HOME");
		if (hp == null){
			String md = "c:/My Documents";
			if (File.getNewFile(md).exists())
				return md;
			md = "/My Documents";
			if (File.getNewFile(md).exists())
				return md;
		}
		if (hp != null) hp.replace('\\', '/');
		return hp;
	}

}

//####################################################
