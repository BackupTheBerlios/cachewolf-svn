/*
 * Created on Aug 13, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.Vector;

import eve.io.File;
import eve.nativeaccess.nativeIcon;
import eve.sys.options.VMOptions;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Device implements VmConstants{

	private Device() {}
	
	/**
	 * If this is set to a class
	 */
	public Class yieldToEventsClass;
	
	/**
	 * This is used to check if the thrown exception indicates that native methods
	 * are not allowed. If t is a SecurityException or a NoSuchMethodError or a
	 * UseNonNativeMethodException or a UnsatisfiedLinkError then the exception is
	 * trapped and the method returns normally - indicating that it was one of these
	 * exceptions. Otherwise if the actual exception is a RuntimeException or an Error
	 * the exception is thrown, otherwise a new UndeclaredThrowableException is thrown
	 * linking to the Throwable.<p>
	 * You would use it in your code like this:
	 * <pre>
private static boolean haveNative = true;

private native int myNativeMethod(Object parameter) throws IOException;

public int myMethod(Object parameter) throws IOException
{
	int result = 0;
	if (haveNative) try{
		result = myNativeMethod(parameter);
	}catch(IOException e){ // I must handle all the expected exceptions first.
		throw e;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		haveNative = false; // I won't attempt a native method again.
	}
	//
	if (!haveNative){
		// Now I must use a non-native way of doing the method.
		//result = something;
	}
	return result;
}
	</pre>

	 * @param t the Throwable thrown.
	 */
	public static void checkNoNativeMethod(Throwable t)
	{
		//System.out.println(t.getMessage());
		if (t instanceof SecurityException) return;
		if (t instanceof UnsatisfiedLinkError) return;
		if (t instanceof NoSuchMethodError) return;
		if (t instanceof UseNonNativeMethodException) return;
		if (t instanceof RuntimeException) throw (RuntimeException)t;
		if (t instanceof Error) throw (Error)t;
		throw new UndeclaredThrowableException(t);
	}
	
	private static native int nativeMessageBox(String title, String text, int type);
	private static native int nativeGetGUICapabilities();
	private static native void nativeFlashMessage(String message,int howLongInMillis);
	private static native boolean nativeResetIdleState();
	private static native int nativeGetBatteryState(int options);
	/**
	 * A possible return value for getGUICapabilities().
	 */
	public static final int GUI_CAN_MESSAGEBOX = 0x1;
	/**
	 * A possible return value for getGUICapabilities().
	 */
	public static final int GUI_CAN_FLASHMESSAGE = 0x2;
	/**
	 * A possible return value for getGUICapabilities().
	 */
	public static final int GUI_CAN_HAVE_TASKBARICON = 0x4;
	/**
	 * A possible return value for getGUICapabilities(). If it is true
	 * the Vm.debug() will display text, if not the Vm.debug() has no effect.
	 */
	public static final int GUI_CAN_DISPLAYTEXT = 0x8;
	/**
	 * A possible return value for getGUICapabilities().
	 * If it is true then the system can do standard message beeps.
	 * If not then you should use another method for generating beeps.
	 */
	public static final int GUI_CAN_BEEP = 0x10;
	/**
	 * Get the GUI capabilities of the currently running VM.
	 * @return a value with any of the GUI_CAN_XXXX values ORed together.
	 */
	public static int getGUICapabilities()
	{
		try{
			return nativeGetGUICapabilities();
		}catch(Throwable t){
			checkNoNativeMethod(t);
			if (Vm.isJavaVM()) return GUI_CAN_DISPLAYTEXT|GUI_CAN_BEEP;
		}
		return 0;
	}
	public static boolean isMobile()
	{
		return (Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_IS_MOBILE) != 0;
	}
	public static boolean hasFlag(int vmFlag)
	{
		return (Vm.getParameter(Vm.VM_FLAGS) & vmFlag) != 0;
	}
	public static boolean hasGUI()
	{
		return (Vm.getParameter(Vm.VM_FLAGS) & VM_FLAG_NO_GUI) == 0;
	}
	/**
	 * Create a DeviceIcon for use with Windows and Taskbars and other 
	 * OS functions. When possible, a DeviceIcon will display the image
	 * that is the closest in size to the icon that is expected for that situation.
	 * For example in the top window bar a 16x16 icon is best but when using Alt-Tab
	 * to switch between apps a 32x32 or 48x48 is preferred.
	 * <p>
	 * However if the underlying system does not support multiple images in an icon
	 * then the preferredImage should specify which one to use.
	 * 
	 * @param images the images making up the icon.
	 * @param preferredImage the index of the preferred image. 
	 * @return an opaque DeviceIcon object.
	 */
	public static DeviceIcon createIcon(ImageData[] images, int preferredImage)
	{
		for (int i = 0; i<images.length; i++)
			if (images[i] == null) throw new NullPointerException();
		return new nativeIcon(images,preferredImage);
	}
	/**
	 * Create a device icon from a variety of objects.
	 * @param image this can be: <pre>
	 * a DeviceIcon - in which case it is returned as is.
	 * an ImageData - in which case a DeviceIcon is created from it.
	 * a String - in which case it is converted to an ImageData via loadPicture()
	 * and then converted to a DeviceIcon.
	 * a FormattedDataSource - in which case it is converted to an ImageData via loadPicture()
	 * and then converted to a DeviceIcon.
	 * an Array of ImageData, String or FormattedDataSource objects. In which case
	 * they are all converted to an array of ImageData using loadPicture
	 * </pre>
	 * @return a DeviceIcon or null if no conversion could be done.
	 */
	public static DeviceIcon toDeviceIcon(Object image)
	{
		if (image == null) return null;
		else if (image instanceof DeviceIcon) 
			return (DeviceIcon)image;
		else if (image instanceof Object[]){
			Object[] a = (Object[])image;
			if (a.length == 0) return null;
			ImageData[] im = new ImageData[a.length];
			for (int i = 0; i<a.length; i++){
				im[i] = loadPicture(a[i]);
				if (im[i] == null) return null;
			}
			return createIcon(im,0);
		}
		else{
			ImageData id = loadPicture(image);
			if (id == null) return null;
			return createIcon(new ImageData[]{id},0);
		}
			
	}
	/**
	 * Return a system dependant icon. Only use this with the command line version
	 * of the VM.
	 * @param iconName the name of a resource icon.
	 * @return an object that can be used as an icon for certain Device method calls, or
	 * null if the icon could not be found or created.
	 */
	/*
	public static DeviceIcon getIcon(String iconName)
	{
		return null;
	}
	*/
	/**
	 * Return a system dependant icon. Only use this with the command line version
	 * of the VM.
	 * @param data the native icon bytes.
	 * @param offset the start of the bytes.
	 * @param length the number of bytes.
	 * @return an object that can be used as an icon for certain Device method calls, or
	 * null if the icon could not be found or created.
	 */
	/*
	public static DeviceIcon getIcon(byte[] data, int offset, int length)
	{
		return null;
	}
	*/
	/**
	 * Get a TaskBar entry (an icon in the system tray on most systems) that can have
	 * an icon and text tip displayed.
	 * @param title a title for the entry - which may or may not be displayed.
	 * @param listener an optional listener to listen to events from the TaskbarEntry.
	 * Usually this is will be an event that indicates when the icon is clicked or
	 * double clicked.
	 * @return an opaque TaskBar entry object if available, or null if not.
	 */
	public static ITaskbarEntry getTaskbarEntry(String title)
	{
		return null;
	}
	
	public static int messageBox(String title, String text, int type) throws UnsupportedOperationException
	{
		Type ty = new Type("eve.applet.EveApplet");
		if (ty.exists()){
			Object obj = ty.invoke(null,"messageBox(Ljava/lang/String;Ljava/lang/String;I)I",new Object[]{title,text,new Integer(type)});
			if (obj instanceof Integer)
				return ((Integer)obj).intValue();
			else
				throw new UnsupportedOperationException();
		}
		try{
			return nativeMessageBox(title,text,type);
		}catch(UnsupportedOperationException e){
			throw e;
		}catch(Throwable t){
			checkNoNativeMethod(t);
		}
		throw new UnsupportedOperationException();
	}
	
	public static void flashMessage(String message, int howLongInMillis) throws UnsupportedOperationException
	{
		try{
			nativeFlashMessage(message,howLongInMillis);
		}catch(UnsupportedOperationException e){
			throw e;
		}catch(Throwable t){
			checkNoNativeMethod(t);
		}
		throw new UnsupportedOperationException();
	}
	//public static void setTaskbarEntry

	/** A possible return value from messageBox() */
	public static final int IDABORT = 3;
	/** A possible return value from messageBox() */
	public static final int IDCANCEL = 2;
	/** A possible return value from messageBox() */
	public static final int IDIGNORE = 5;
	/** A possible return value from messageBox() */
	public static final int IDNO = 7;
	/** A possible return value from messageBox() */
	public static final int IDOK = 1;
	/** A possible return value from messageBox() */
	public static final int IDRETRY = 4;
	/** A possible return value from messageBox() */
	public static final int IDYES = 6;
	/** A type for use with messageBox() */
	//public static final int MB_ABORTRETRYIGNORE = 0x00000002;
	/** A type for use with messageBox() */
	public static final int MB_OPTION_APPLMODAL = 0x00000000;
	/** A type for use with messageBox() */
	//public static final int MB_DEFBUTTON1 = 0x00000000;
	/** A type for use with messageBox() */
	//public static final int MB_DEFBUTTON2 = 0x00000100;
	/** A type for use with messageBox() */
	//public static final int MB_DEFBUTTON3 = 0x00000200;
	/** Can be OR'ed with the MB_XXX types for messageBox() */
	public static final int MB_OPTION_ICONASTERISK = 0x00000040;
	/** Can be OR'ed with the MB_XXX types for messageBox() */
	public static final int MB_OPTION_ICONHAND = 0x00000010;
	/** Can be OR'ed with the MB_XXX types for messageBox() */
	public static final int MB_OPTION_ICONERROR = MB_OPTION_ICONHAND;
	/** Can be OR'ed with the MB_XXX types for messageBox() */
	public static final int MB_OPTION_ICONEXCLAMATION = 0x00000030;
	/** Can be OR'ed with the MB_XXX types for messageBox() */
	public static final int MB_OPTION_ICONINFORMATION = MB_OPTION_ICONASTERISK;
	/** Can be OR'ed with the MB_XXX types for messageBox() */
	public static final int MB_OPTION_ICONQUESTION = 0x00000020;
	/** Can be OR'ed with the MB_XXX types for messageBox() */
	public static final int MB_OPTION_ICONSTOP = MB_OPTION_ICONHAND;
	/** Can be OR'ed with the MB_XXX types for messageBox() */
	public static final int MB_OPTION_ICONWARNING = MB_OPTION_ICONEXCLAMATION;
	/** A type for use with messageBox() */
	public static final int MB_TYPE_OK = 0x00000000;
	/** A type for use with messageBox() */
	public static final int MB_TYPE_OKCANCEL = 0x00000001;
	/** A type for use with messageBox() */
	//public static final int MB_RETRYCANCEL = 0x00000005;
	/** A type for use with messageBox() */
	public static final int MB_OPTION_SYSTEMMODAL = 0x00001000;
	/** A type for use with messageBox() */
	public static final int MB_OPTION_TASKMODAL = 0x00002000;
	/** A type for use with messageBox() */
	public static final int MB_TYPE_YESNO = 0x00000004;
	/** A type for use with messageBox() */
	public static final int MB_TYPE_YESNOCANCEL = 0x00000003;
	
	public static final int MB_MASK_FOR_TYPE = 0x7;
	/**
	 * Display a message - either as a MessageBox or on standard output if no MessageBox
	 * is possible. The message box will always be a simple box with a single OK button
	 * or as similar to that as possible. No input from the user is possible.
	 * @param title the title for the MessageBox.
	 * @param text the main text for the message.
	 * @param showTitleOnOutput if the message must be output on standard output, then
	 * if this is true the title followed by a ':' is output before the text. Otherwise
	 * only the text is output.
	 * @return true if a MessageBox was shown, false if output was sent to standard output.
	 */
	public static boolean tryMessageBox(String title, String text, boolean showTitleOnOutput)
	{
		try{
			messageBox(title,text,MB_TYPE_OK);
			return true;
		}catch(UnsupportedOperationException e){
			if (showTitleOnOutput) System.out.println(title+": "+text);
			else System.out.println(text);
			return false;
		}
	}
	/**
	 * This will attempt to load an Image/Picture <b>if</b> the eve.fx package is present.
	 * @param source either the name of the image or a eve.util.FormattedDataSource
	 * @return an Object implementing eve.fx.IImage or null if not successful.
	 */
	public static ImageData loadPicture(Object source)
	{
		if (source instanceof ImageData) return (ImageData)source;
		Type fx = getFx();
		if (!fx.exists()) return null;
		return (ImageData)fx.invoke(null,"loadPicture(Ljava/lang/Object;)Leve/fx/IImage;",new Object[]{source});
	}
	
	private static native void nativeMessageBeep(int whichBeep);  
	/**
	 * Note - you should usually use Sound.beep() produce a beep. Produce a system dependant beep, if possible.
	 * @param whichBeep this should be one of the MB_ICONXXX values. On a Linux
	 * system this will usually just beep on the speaker.
	 * @return true if it can play a beep, false if not.
	 */
	public static boolean messageBeep(int whichBeep)
	{
		try{
			nativeMessageBeep(whichBeep);
			return true;
		}catch(Throwable t){
			if (Vm.isJavaVM()){
				Type ty = new Type("java.awt.Toolkit");
				if (ty.exists()) {
					Object got = ty.invoke(null,"getDefaultToolkit()Ljava/awt/Toolkit;",Reflection.emptyParameters); 
					if (got != null) ty.invoke(got,"beep()V",Reflection.emptyParameters);
				}
			}
			return false;
		}
	}
	
	private static IOException toIOException(Throwable t,String message)
	{
		if (t instanceof IOException) return (IOException)t;
		return (IOException)Vm.setCause(new IOException(message),t);
	}
	
	/**
	 * Get the path to the Eve VM on this system or null if it cannot be determined.
	 * The path returned is NOT a system dependant path.
	 * @return
	 */
	public static String getPathToVm()
	{
		try{
			String got = null;
			if (VMOptions.shouldUsePathToEve())
				got = VMOptions.vmOptions.pathToEve;
			if (got != null) return got;
			got = Vm.getProperty("eve.vm.path",null);
			if (got != null) return got;
			IRegistryKey rk = Vm.getRegistryKey(true,"HKEY_CLASSES_ROOT\\EveFile10\\DLL",false,false);
			if (rk == null) return null;
			String dll = ((String)rk.getValue(null)).replace('\\','/');
			int where = dll.lastIndexOf('.');
			if (where != -1) dll = dll.substring(0,where+1);
			return dll+"exe";
		}catch(Exception e){
			return null;
		}
	}
//	-------------------------------------------------------------------
	private static String quotedVmPath(String commandLine) throws IOException
//	-------------------------------------------------------------------
	{
		String path = getPathToVm();
		if (path == null) throw new IOException("Could not get path to VM");
		path = File.toSystemDependantPath(path);
		
		if (!(path.charAt(0) == '"')) path = "\""+path+"\"";
		if (commandLine != null) commandLine = path+" "+commandLine;
		else commandLine = path;
		return File.toSystemDependantPath(commandLine);
	}
	/**
	 * Return a path to the native VM.
	 * @param arguments
	 * @return
	 * @throws IOException
	 */
	public static String[] getVmCommandLine(String arguments) throws IOException
	{
		Vector v = new Vector();
		String path = getPathToVm();
		if (path == null) throw new IOException("Could not get path to VM");
		path = File.toSystemDependantPath(path);
		v.add(path);
		if (arguments != null){
			char[] r = Vm.getStringChars(arguments);
			int last = 0;
			char q = 0;
			for (int i = 0; i<r.length; i++){
				char c = r[i];
				if (q != 0){
					if (c == q) q = 0; 
					continue;
				}
				if (c == '\'' || c == '\"') {
					q = c;
					continue;
				}
				if (c == ' '){
					if (last != i){
						v.add(arguments.substring(last,i));
					}
					last = i+1;
				}
			}
			if (last != r.length) v.add(arguments.substring(last,r.length));
		}
		String[] ret = new String[v.size()];
		v.copyInto(ret);
		return ret;
	}
	/**
	* Create an absolute command line to execute the Eve VM on my Eve file. 
	* @param myEveFile the name (without a path specification) of the Eve file this application
	* is packaged in. If it is null the VM will attempt to lookup the name of the currently running
	* .eve file. If it is an empty string it will assume no eve file.
	* @param extraArguments Additional application arguments - can be null.
	* @param vmArguments Additional VM arguments - can be null.
	* @param includePathToVM Set this true to include the path to the VM.
	* @return An absolute command line for executing the currently running application.
	* @exception IOException if there is a problem with any of the data.
	*/
	/*
//	===================================================================
	public static String getVmCommandLine(String myEveFile,String extraArguments,String vmArguments,boolean includePathToVM)
	throws IOException
//	===================================================================
	{
		String myName = "";
		if (myEveFile != null){
			myEveFile = myEveFile.trim();
			if (myEveFile.length() != 0){
				if (myEveFile.indexOf('/') != -1 || myEveFile.indexOf('\\') != -1){
					myName = "\""+myEveFile+"\"";
				}else{
					File pd = File.getNewFile(File.getProgramDirectory()).getChild(myEveFile);
					myName = "\""+pd.getAbsolutePath()+"\"";
				}
			}
		}else if (myEveFile == null){
			myEveFile = Vm.getProperty("this.eve.path",null);
			if (myEveFile == null) throw new IOException("Cannot determine Eve file.");
			myName = "\""+myEveFile+"\"";
		}
		if (vmArguments != null) myName = vmArguments+" "+myName;
		if (extraArguments != null) myName += " "+extraArguments;
		if (includePathToVM) return quotedVmPath(myName);
		else return myName;
	}
	*/
	/**
	 * 
	 */
	public static void createShortcut(String targetExecutable, String arguments, String shortcutName) throws IOException
	{
		//new Type()
		Method m = new Type("eve.sys.registry.Registry").getMethod("createShortcut(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z",false);
		try{
			if (m == null || !((Boolean)m.invoke(null,new Object[]{})).booleanValue())
				throw new IOException("This VM cannot create a shortcut.");
		}catch(Throwable e){
			throw toIOException(e,"Could not create shortcut.");
		}
	}
	
	private static native int getPreloadState(boolean doUnload);
	public static boolean preloadVm(boolean onOrOff)
	{
		int state = -1;
		try{
			state = getPreloadState(!onOrOff);
		}catch(Throwable t){
			state = -1;
		}
		if (state == -1) return false;
		if (state == 1 && onOrOff) return true;
		if (state == 0 && !onOrOff) return true;
		try{
			String[] cmd = getVmCommandLine(onOrOff ? "--" : "-");
			Runtime.getRuntime().exec(cmd);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	/**
	 * When the preventIdleState method is called a Thread is started
	 * that calls resetIdleState() at an interval determined by this value
	 * measured in milliseconds. By default it is 1000 (1 second).
	 */
	public static int idleTimeOut = 1000;

	private static Thread idleState;
	private static int idleCount = 0;

	/**
	 * Reset the devices countdown to idle state - thereby preventing the device
	 * from entering an idle state until the device's countdown completes again.
	 * Calling this method periodically should prevent the device from entering
	 * an idle state. You can also call preventIdleState() to create a Thread
	 * that will do this for you.
	 * @return true if the idle state was reset or if the device (or computer)
	 * never goes idle, false if the idle state could
	 * not be reset.
	 */
	public static boolean resetIdleState()
	{
		try{
			return nativeResetIdleState();
		}catch(Throwable t){
			checkNoNativeMethod(t);
			return false;
		}
	}
	/**
	Enter or leave a period where you wish for the Device to not power down due
	to being in an idle state.
	* @param startPrevent true to enter the protected period, false to leave it.
	* @return true if you <b>can</b> prevent the idle state, false if you cannot.
	*/
//	===================================================================
	public synchronized static boolean preventIdleState(boolean startPrevent)
//	===================================================================
	{
		if (idleCount == 0 && !resetIdleState()) return false;
		if (startPrevent){
			idleCount++;
			if (idleCount == 1){
				idleState = new Thread(){
			//		===================================================================
					public void run()
			//		===================================================================
					{
						while(true){
							synchronized(Device.class){
								if (idleState != this) return;
							}
							resetIdleState();
							mThread.nap(idleTimeOut);
						}
					}
				};
				idleState.start();
			}
		}else{
			if (idleCount > 0){
				idleCount--;
				if (idleCount == 0){
					idleState = null;
				}
			}
		}
		return true;
	}
	/**
	* This is a possible parameter for getBatteryState().
	**/
	public static final int BATTERY_MAIN = 1;
	/**
	* This is a possible parameter for getBatteryState().
	**/
	public static final int BATTERY_BACKUP = 2;
	/**
	* This is a possible parameter for getBatteryState().
	**/
	public static final int BATTERY_AC = 3;

	public static final int BATTERY_OPTION_POWER_LEFT = 0x100;
	public static final int BATTERY_OPTION_FLAGS = 0x200;
	private static final int BATTERY_OPTION_MASK = 0xffffff00;
	/**
	* This is a possible return value for getBatteryState.
	**/
	public static final int BATTERY_STATE_UNKNOWN = -1;
	/**
	 * Return the state of the battery.
	 * @param battery one of the BATTERY_XXX OR'ed with one of the BATTERY_OPTION_XXX flags. A value of zero
	 * defaults to returning the power left on the main battery.
	 * @return if the battery parameter is OR'ed with BATTERY_OPTION_POWER_LEFT, a value between 0 (empty) and 100 (fully charged) or BATTERY_STATE_UNKNOWN if not known. BATTERY_AC will return
	 * either 0 or 100. if the battery parameter is OR'ed with BATTERY_OPTION_FLAGS, a value with some of the BATTERY_STATE_XXX flags set, or BATTERY_STATE_UNKNOWN if not known.
	 */
//	===================================================================
	public static int getBatteryState(int battery)
//	===================================================================
	{
		if ((battery & ~BATTERY_OPTION_MASK) == 0)
			battery |= BATTERY_MAIN;
		if ((battery & BATTERY_OPTION_MASK) == 0)
			battery |= BATTERY_OPTION_POWER_LEFT;
		try{
			return nativeGetBatteryState(battery);
		}catch(Throwable t){
			checkNoNativeMethod(t);
			return BATTERY_STATE_UNKNOWN;
		}
	}
	public static IConsole createConsole(String title, int iconsoleOptions, int maxLines)
	{
		Type fx = getFx();
		if (!fx.exists()) return null;
		return (IConsole)fx.invoke(null,"getConsole(Ljava/lang/String;II)Leve/sys/IConsole;",
				new Object[]{
				title, new Integer(iconsoleOptions), new Integer(maxLines)
				});
	}
	
	private static Type fxtype;
	
	private static Type getFx()
	{
		if (fxtype == null) fxtype = new Type("eve.fx.Fx");
		return fxtype;
	}
	static Integer miny = new Integer(10), maxy = new Integer(100);
	static Object[] mm = new Object[2];
	
	public static ITaskbarEntry createTaskbarEntry()
	{
		Type fx = getFx();
		if (fx.exists()) return (ITaskbarEntry)fx.invoke(null,"getTaskbarEntry()Leve/sys/ITaskbarEntry;",null);
		return null;
	}
	public static void yield()
	{
		yieldToEvents(100);
	}
	public static void setThreadIsEventHandler()
	{
		try{
			pendingEvents(2);
		}catch(Throwable t){}
	}
	public static void yieldToEvents(int max)
	{
		Type fx = getFx();
		if (fx.exists()) {
			Object got = fx.invoke(null,"yieldToEvents(I)Z",new Object[]{new Integer(max)});
			if (got instanceof Boolean && ((Boolean)got).booleanValue())
				return;
		}
		try{
			if (!pendingEvents(1)) return;
			long now = System.currentTimeMillis();
			while(true){
				if (!hasPendingEvents()) return;
				try{
					Thread.sleep(5);
				}catch(InterruptedException e){
					return;
				}
				if (System.currentTimeMillis()-now >= max) return;
			}
		}catch(Throwable t){}
	}
	private static native boolean pendingEvents(int op);
	public static boolean hasPendingEvents()
	{
		try{
			return pendingEvents(0);
		}catch(Throwable e){
			return false;
		}
	}
	
	static native int getSetRotation(int rotation,boolean isGet);

	private static int rotation = 0;
	
	public static final int ROTATION_NONE = 0;
	public static final int ROTATION_90 = 1;
	public static final int ROTATION_180 = 2;
	public static final int ROTATION_270 = 3;
	
	public static void setScreenRotation(int rotation)
	{
		Device.rotation = rotation;
		try{
			getSetRotation(rotation,false);
		}catch(Throwable t){}
	}
	public static int getScreenRotation()
	{
		try{
			Device.rotation = getSetRotation(0,true);
		}catch(Throwable t){}
		return rotation;
	}
	public static ImageData scaleImage(ImageData src, int newWidth, int newHeight)
	{
		Type fx = getFx();
		if (!fx.exists()) return src;
		return (ImageData)fx.invoke(null,"scaleImage(Leve/sys/ImageData;II)Leve/sys/ImageData;",new Object[]{src,new Integer(newWidth),new Integer(newHeight)});
	}
}

//####################################################
