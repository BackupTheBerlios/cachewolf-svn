package eve.sys;
import java.text.ParseException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

import eve.data.DataObject;
import eve.data.IDate;
import eve.data.ITime;
import eve.data.PlainDate;
import eve.data.PlainTime;
import eve.data.Value;
import eve.util.CharArray;
/**
* Time identifies a <b>local</b> date and time, storing information to millisecond precision only.
* <p>
* <i>As of Eve vesion 1.14 you should use eve.sys.SimpleDateFormat to format and parse
* Time values.</i>
* <p> 
* A Time
* object is displayed as a string in a manner specified by the "format" string. If this value is
* null it will be formatted as by the "defaultFormat" string.<p>
* The format string uses the convention as the java.util.SimpleDateFormat with some specifiers left
* out. What is included are:<p>
* <pre>
* Symbol   Meaning                 Presentation        Example
* ------   -------                 ------------        -------
* y        year                    (Number)            1996
* M        month in year           (Text & Number)     July & 07
* d        day in month            (Number)            10
* h        hour in am/pm (1~12)    (Number)            12
* H        hour in day (0~23)      (Number)            0
* m        minute in hour          (Number)            30
* s        second in minute        (Number)            55
* S        millisecond             (Number)            978
* E        day in week             (Text)              Tuesday
* a        am/pm marker            (Text)              PM
* z        GMT TimeZone            (Text & Number)     GMT+00:00
* Z        RFC 822 Time Zones      (Number)            -0400
* '        escape for text
* </pre>
* <p>
* Time also implements Textable and getText()/setText() encodes the object in a numeric form that is independant of the format
* used for toString()/fromString().
* </p>
**/

//##################################################################
public class Time extends DataObject implements IDate, ITime, Comparable, Value{
//##################################################################
//Do not move any variables up to: format	
/** The year as its full set of digits (year 2010 is 2010). */
public int year;

/** The month in the range of 1 to 12. */
public int month;

/** The day in the range of 1 to the last day in the month. */
public int day;

/** The hour in the range of 0 to 23. */
public int hour;

/** The minute in the range of 0 to 59. */
public int minute;

/** The second in the range of 0 to 59. */
public int second;

/** Milliseconds in the range of 0 to 999. */
public int millis;

/** The day of the week in the range 1 to 7, with 1 being Monday and 7 being Sunday*/
public int dayOfWeek;
/**
* The date format to use for I/O with this Time object.
**/
public String format = null;
/**
* The default format to use if one is not specified.
**/
public static String defaultFormat = 
	new Locale().getString(Locale.LONG_DATE_FORMAT,0,0);

/**
 * Used for user interfaces to mark an invalid/unentered time.
 */
public static long invalidTime = -5361120000000L;// -> causes an error. new Time(1,1,1800).getTime();

//"EEE d-MMMM-yyyy h:mm:ss a";

public String _fields = 
"year,month,day,hour,minute,second,millis,dayOfWeek,format";

private static boolean hasNative = true;
/**
 * Constructs a time object set to the current date and time.
 */
//===================================================================
public Time()
//===================================================================
{
	setToCurrentTime();
}
//===================================================================
public Time(int day,int month,int year)
//===================================================================
{
	this.day = day;
	this.month = month;
	this.year = year;
	minute = second = hour = millis = 0;
	update();
}
public void copyFrom(Object other)
{
	if (other instanceof Time)
		setTime(((Time)other).getTime());
}
//===================================================================
/**
 * This method returns the UTC time in milliseconds using the default
 * TimeZone - which means that the value this returns for a given
 * set of Y/M/D/h/m/s values will be different depending on the default
 * TimeZone. To get the UTC time in milliseconds for a particular TimeZone
 * using this Time's Y/M/D/h/m/s values use getUTCMillis(TimeZone tz).
 */
public long getTime()
//===================================================================
{
	return doGetSetTime(0,true,false);
}
/**
 * This methods sets the Y/M/D/h/m/s values of this Time value based on the
 * UTC time given and the default TimeZone. Therefore these values will be
 * set differently on different Time Zoned systems given the same time parameter.
 * To find out the Y/M/D/h/m/s values for a particular UTC time at a particular
 * TimeZone use setUTCMillis(TimeZone tz,long millis);
 * @param time the UTC time in milliseconds.
 * @return this Time Object.
 */
public Time setTime(long time)
//===================================================================
{
	doGetSetTime(time,false,false);
	return this;
}
/**
 * See if the long millisecond value of this Time is the one marked for invalid time 
 * (equal to the invalidTime field).
 * @return true if the millisecond value of this Time is the same as "invalidTime"
 */
public boolean isInvalidTime()
{
	return getTime() == invalidTime;
}
/**
* Update values like dayOfWeek from the year, month, day and time values. It should also
* check for validity. You should call isValid() after doing update.
**/
//===================================================================
public Time update()
//===================================================================
{
	int dy = day, m = month, y = year;
	setTime(getTime());
	if (day != dy || m != month || y != year) {
		//eve.sys.Vm.debug("Was: "+dy+" is: "+day);
		day = 0;
	}
	return this;
}
//===================================================================
public boolean isValid() {return day > 0;}
//===================================================================

static int dim[] = new int[]{31,28,31,30,31,30,31,31,30,31,30,31};

//-------------------------------------------------------------------
private static int getDays(int day,int month, int year)
//-------------------------------------------------------------------
{
	int ret = -1;
	if (year < 1600) return ret;
	int yearsPast = (year-1600-1);
	int leaps = yearsPast/4-(yearsPast/100)+(yearsPast/400);
	if (yearsPast >= 1) leaps++;
	if (month > 2 && isLeapYear(year)) leaps++;
	int daysPast = leaps;
	for (int i = 1; i<month; i++) 
		daysPast += dim[i-1];
	daysPast += day-1;
	daysPast += (yearsPast+1)*365;
	return daysPast;
}

//===================================================================
public Time setFormat(String format)
//===================================================================
{
	this.format = format;
	return this;
}
//===================================================================
public String getFormat()
//===================================================================
{
	return format != null ? format : getDefaultFormat();
}
//===================================================================
public String getDefaultFormat()
//===================================================================
{
	return defaultFormat;
}

//===================================================================
public void parse(String dateValue,String dateFormat) throws IllegalArgumentException
//===================================================================
{
	if (dateFormat == null) dateFormat = getFormat();
	if (fromString(dateValue,this,dateFormat,Locale.getDefault())){
		update();
		if (isValid()) 
			return;
	}
	throw new IllegalArgumentException();
}
//===================================================================
public void parse(String dateValue) throws IllegalArgumentException
//===================================================================
{
	parse(dateValue,null);	
}
//===================================================================
public String format(String dateFormat)
//===================================================================
{
	return toString(this,dateFormat,Locale.getDefault());
}
//===================================================================
public void fromString(String source)
//===================================================================
{
	fromString(source,Vm.getLocale());
}
//===================================================================
public void fromString(String source,Locale locale)
//===================================================================
{
	setTime(0);
	if (!fromString(source,this,(format == null ? getDefaultFormat() : format),locale))
		day = 0;
	else
		update();
}

public static final int SECOND = 1;
public static final int MINUTE = 2;
public static final int HOUR = 3;
public static final int DAY = 4;
public static final int MONTH = 5;
public static final int YEAR = 6;

/**
* Rounds this time down.
* @param roundTo should be SECOND, MINUTE, HOUR, ...
**/
//===================================================================
public Time roundTo(int roundTo)
//===================================================================
{
		millis = 0;
		if (roundTo == SECOND) return update();
		second = 0;
		if (roundTo == MINUTE) return update();
		minute = 0;
		if (roundTo == HOUR) return update();
		hour = 0;
		if (roundTo == DAY) return update();
		day = 1;
		if (roundTo == MONTH) return update();
		month = 1;
		return update();
}
//===================================================================
public int compareTo(Object other)
//===================================================================
{
	if (!(other instanceof Time)) return 1;
	long me = getTime();
	long you = ((Time)other).getTime();
	if (me > you) return 1;
	else if (me < you) return -1;
	return 0;
}
//===================================================================
public boolean before(Time other)
//===================================================================
{
	return compareTo(other) < 0;
}
//===================================================================
public boolean after(Time other)
//===================================================================
{
	return compareTo(other) > 0;
}
//===================================================================
public String toString()
//===================================================================
{
	return toString(Locale.getDefault());
}
//===================================================================
public String toString(Locale locale)
//===================================================================
{
	return toString(this,(format == null ? getDefaultFormat() : format),locale);
}
//===================================================================
private static CharArray toString(int value,int digits,boolean zeroFill,CharArray dest)
//===================================================================
{
	int need = Convert.formatInt(value,null,0);
	int where = dest.length;
	int toFill = digits-need;
	if (toFill < 0) toFill = 0;
	if (need < digits) need = digits;
	dest.makeSpace(where,need);
	Convert.formatInt(value,dest.data,where+toFill);
	for (int i = 0; i<toFill; i++)
		dest.data[where+i] = zeroFill ? '0':' ';
	return dest;
}
/**
 * Format this Time object with a particular format and particular locale.
 * @param format the format String.
 * @param locale the Locale to use.
 * @return the Time formatted with the specified format for the specified locale.
 */
public String format(String format, Locale locale)
{
	return toString(this,null,format,locale,null).toString();
}
public String format(TimeZone tz, String format, Locale locale)
{
	return toString(this,tz,format,locale,null).toString();
}
/**
 * Format a Time object with a particular format and particular locale.
 * @param t the Time Object to format.
 * @param format the format String.
 * @param locale the Locale to use.
 * @return the Time formatted with the specified format for the specified locale.
 */
public static String toString(Time t,String format,Locale locale)
//===================================================================
{
	return toString(t,null,format,locale,null).toString();
}
//===================================================================
public static CharArray toString(Time t,String format,Locale locale,CharArray dest)
//===================================================================
{
	return toString(t,null,format,locale,dest);
}
//===================================================================
public static CharArray toString(Time t,TimeZone tz,String format,Locale locale,CharArray dest)
//===================================================================
{
	dest = CharArray.unNull(dest);
	if (locale == null) locale = Vm.getLocale();
	if (format == null) format = locale.getString(Locale.SHORT_DATE_FORMAT,0,0);
	if (format == null) 
		return dest.append(t.day).append('/').append(t.month).append('/')
		.append(t.year).append(", ").append(t.hour).append(':')
		.append(t.minute).append(':').append(t.second).append(';').append(t.millis);
	char spec = 0;
	int count = 0;
	int l = format.length();
	for(int i = 0; i<l+1; i++){
		char ch = i == l ? 0 : format.charAt(i);
		if (ch == spec) count++;
		else {
			//System.out.println(count+":"+spec);
			if (spec != 0){
				//String add = "????";
				CharArray add = dest;
				int h = t.hour;
				if (count < 2) count = 0;
				if (count >= 3 && spec == 'd') spec = 'E';
				switch(spec){
				case 'y':
					int y = t.year;
					if (count < 4) y = y%100;
					add = toString(y,count,true,dest);
					break;
				case 'M':
					int m = t.month;
					//if (count < 2) count = 0;
					if (count >= 3) add = dest.append(locale.getString(count == 3 ? locale.SHORT_MONTH:locale.MONTH,m,0));
					else add = toString(m,count,true,dest);
					break;
				case 'd':
					//if (count < 2) count = 0;
					add = toString(t.day,count,true,dest);
					break;
				case 'h':
					h = h%12;
					if (h == 0) h = 12;
				case 'H':
					//if (count < 2) count = 0;
					add = toString(h,count,true,dest);
					break;
				case 'm':
					//if (count < 2) count = 0;
					add = toString(t.minute,count,true,dest);
					break;
				case 'E':
					add = dest.append(locale.getString(count == 3 ? locale.SHORT_DAY : locale.DAY,t.dayOfWeek,0));
					break;
				case 's':
					add = toString(t.second,count,true,dest);
					break;
				case 'S':
					add = toString(t.millis,count,true,dest);
					break;
				case 't':
				case 'a':
					//add = locale.getString(locale.AM_PM,t.hour >= 12 ? 1 : 0,0);
					add = dest.append(locale.getString(locale.AM_PM,t.hour >= 12 ? 1 : 0,0));
					break;
				case 'z':
				case 'Z':
				{
					if (spec == 'z') add = dest.append("GMT");
					if (tz == null) tz = TimeZone.getDefault();
					int off = t.getTimeZoneUTCOffset(tz)/60000;
					if (true || off != 0 || spec == 'Z'){
						if (off < 0) {
							dest.append('-');
							off = -off;
						}else
							dest.append('+');
						add = toString(off/60,2,true,dest);
						if (spec == 'z') add = dest.append(':');
						add = toString(off%60,2,true,dest);
					}
					break;
				}
				default:
						add = dest.append("????");
				}
				//sb.append(add);
				spec = 0;
				count = 0;
			}
			if (ch == 0) break;
			if ((ch | 0x20) >= 'a' && (ch | 0x20) <= 'z') {
				spec = ch;
				count = 1;
				continue;
			}else if (ch == '\''){
				int did = 0;
				for (i++;i<l;i++){
					char c2 = format.charAt(i);
					if (c2 == '\'') {
						if (did == 0) dest.append('\'');
						break;
					}else{
						dest.append(c2);
						did++;
					}
				}
				continue;
			}
			dest.append(ch);
		}
	}
	return dest;
}
//
private static Hashtable formats;
//
private synchronized static SimpleDateFormat getSDF(String format)
{
	if (formats == null) formats = new Hashtable();
	SimpleDateFormat sdf = (SimpleDateFormat)formats.get(format); 
	if (sdf == null){
		sdf = new SimpleDateFormat(format);
		formats.put(format,sdf);
	}
	return sdf;
}
//===================================================================
public static boolean fromString(String source,Time t,String format,Locale locale)
//===================================================================
{
	synchronized(Time.class){
		try{
			SimpleDateFormat sdf = getSDF(format);
			sdf.setLocale(locale);
			sdf.parse(source,t);
			return true;
		}catch(ParseException pe){
			return false;
		}
	}
	/*
	try{
	if (locale == null) locale = Vm.getLocale();
	StringBuffer sb = new StringBuffer();
	char spec = 0;
	int count = 0;
	int l = format.length();
	int src = 0;
	for(int i = 0; i<l+1; i++){
		char ch = i == l ? 0 : format.charAt(i);
		if (ch == spec) count++;
		else {
			if (spec != 0){
				boolean digit = false;
				int sl = source.length();
				for(;src<sl;src++) if (source.charAt(src) != ' ') break;
				int st;
				for (st = src; src<sl; src++){
					char sc = source.charAt(src);
					if (st == src) digit = (sc >= '0' && sc <= '9');
					else if (digit) {
						if (sc < '0'|| sc > '9') break;
					}else{
						if ((sc | 0x20) < 'a' || (sc | 0x20) > 'z') break;
					}
				}
				String data = st < sl ? source.substring(st,src) : "";
				int val = Convert.toInt(data);
				if (count >= 3 && spec == 'd') spec = 'E';
				switch(spec){
					case 'y':
						if (!digit) return false;
						t.year = val;
						if (t.year < 1000)
							if (count < 4) 
								if (t.year <= 49) t.year += 2000;
								else t.year += 1900;
						break;
					case 'M':
						if (count > 2){
							if (digit) return false;
							val = locale.fromString(count == 3 ? locale.SHORT_MONTH:locale.MONTH,data,0);
						}else{
							if (!digit) return false;
						}
						if (val < 1 || val > 12) return false;
						t.month = val;
						break;
					case 'd':
						if (!digit) return false;
						t.day = val;
						break;
					case 'H':
					case 'h':
						if (val < 0 || val > 23) return false;
						t.hour = val;
						break;
					case 'm':
						if (val < 0 || val > 59) return false;
						t.minute = val;
						break;
					case 's':
						if (val < 0 || val > 59) return false;
						t.second = val;
						break;
					case 'S':
						if (val < 0 || val > 999) return false;
						t.millis = val;
						break;
					case 't':
					case 'a':
						val = locale.fromString(locale.AM_PM,data,0);
						if (val == -1) return false;
						if (val == 0) {
							if (t.hour == 12) t.hour = 0;
							else if (t.hour > 12) return false;
						}else{
							if (t.hour < 12) t.hour += 12;
						}
						break;
				}
			}
			spec = 0;
			count = 0;
// Starting a new sequence			
			if (ch == 0) break;
			if ((ch | 0x20) >= 'a' && (ch | 0x20) <= 'z') {
				spec = ch;
				count = 1;
				continue;
			}else if (ch == '\''){
				int did = 0;
				for (i++;i<l;i++){
					char c2 = format.charAt(i);
					if (c2 == '\'') {
						if (did == 0) src++;
						break;
					}else{
						src++;
						did++;
					}
				}
				continue;
			}
			//System.out.println("Skipping: "+ch+" as "+(char)source.charAt(src));
			src++;
		}
	}
	return true;
	}finally{
		//System.out.println(t.day+","+t.month+","+t.year);
	}
	*/
}
/**
* This returns the index of the day in the week. The input parameter is a value of
* 1 = Monday to 7 = Sunday. The output value is 1 = First day of week to 7 = Last day of week.
**/
//===================================================================
public static int indexOfDayInWeek(int dayOfWeek,Locale locale)
//===================================================================
{
	int firstDay = Convert.toInt(locale.getString(Locale.FIRST_DAY_OF_WEEK,0,0));
	//System.out.println("dayOfWeek: "+dayOfWeek+" firstDay: "+firstDay);
	int diff = dayOfWeek-firstDay;
	if (diff < 0) diff += 7;
	return diff+1;
}
/**
* This converts to a 64-bit encoded values saving the year, month, day, hours, min, sec, millisec in
* a platform independent manner. This value should not be used for calculations but only for storage
* or transmission.
* @param forZone - the TimeZone to encode. The value of the offset from UTC
* time is calculated (to a 15 minute resolution) and encoded along with
* the time fields. Note that this can only be in the range +/-15 hours and 45 minutes.
**/
//===================================================================
public long getEncodedTime(TimeZone forZone)
//===================================================================
{
	if (forZone == null) forZone = TimeZone.getDefault();
	long ret = getEncodedTime();
	long off = getTimeZoneUTCOffset(forZone)/(900000);
	// Have 7 bits for offset. Reserve -64 to indicate zero offset (UTC)
	// and all zeros to indicate not TimeZone information saved (which is
	// compatible with older saved values).
	if (off == 0) off = -64;
	else if (off > 63) off = 63;
	else if (off < -63) off = -63;
	off = (off << 57) & 0xfe00000000000000L;
	return ret | off;
}

/**
* This converts to a 64-bit encoded values saving the year, month, day, hours, min, sec, millisec in
* a platform independent manner. This value should not be used for calculations but only for storage
* or transmission.<p>
* Note that this version will save NO TimeZone information.
**/
//===================================================================
public long getEncodedTime()
//===================================================================
{
	long lowWord = (millis & 0x3ff)| ((second << 10) & 0xfc00) | ((minute << 16) & 0x3f0000) | ((hour << 22) & 0x7c00000);
	long highWord = (day & 0x1f) | ((month << 5) & 0x1e0) | ((year << 9) & 0x1fffe00);
	return highWord << 32 | lowWord;
}
/**
* This converts from a 64-bit encoded values saving the year, month, day, hours, min, sec, millisec in
* a platform independent manner. This value should not be used for calculations but only for storage
* or transmission.
**/
//===================================================================
public Time setEncodedTime(long from)
//===================================================================
{
	long lowWord = from & 0xffffffff;
	millis = (int)(lowWord & 0x3ff); 
	lowWord = lowWord >> 10; second = (int)(lowWord & 0x3f);
	lowWord = lowWord >> 6; minute = (int)(lowWord & 0x3f);
	lowWord = lowWord >> 6; hour = (int)(lowWord & 0x1f);
	
	long highWord = (from >> 32) & 0xffffffff;
	day = (int)(highWord & 0x1f);
	highWord >>= 5; month = (int)(highWord & 0xf);
	highWord >>= 4; year = (int)(highWord & 0xffff);
	
	update();
	return isValid() ? this : null;
}
/**
 * From an encoded time value (created by getEncodedTime()) extract the
 * saved TimeZone offset from UTC and place it in the specified SimpleTimeZone.
 * If there is no TimeZone information then false is returned and simpleTimeZone
 * is set as the default time zone.
 * <p>
 * The supplied SimpleTimeZone will have its Daylight Savings Time Savings value
 * set to zero because the information in the encodedTime only specifies the
 * raw offset at that time but does not indicate if the TimeZone it represents
 * had daylight savings time or not. Then the raw offset is set to the offset
 * saved in the encoded time.
 * @param simpleTimeZone the SimpleTimeZone to have its offset set.
 * @return true if there was a TimeZone offset stored in the encoded time,
 * false if not.
 */
public static boolean encodedTimeToTimeZoneOffset(long encodedTime, SimpleTimeZone simpleTimeZone)
{
	int off = encodedTimeToTimeZoneOffset(encodedTime);
	simpleTimeZone.setStartYear(9999);
	if (off == NO_TIME_ZONE_IN_ENCODED_TIME){
		Time t = (Time)Cache.get(Time.class);
		try{
			t.setEncodedTime(encodedTime);
			simpleTimeZone.setRawOffset(t.getTimeZoneUTCOffset(TimeZone.getDefault()));
		}finally{
			Cache.put(t);
		}
		return false;
	}else{
		simpleTimeZone.setRawOffset(off);
		return true;
	}
}
/**
 * From an encoded time produced by getEncodedTime() set a Calendar with
 * the encoded time and TimeZone set to the TimeZone offset stored in the
 * encoded time. If no TimeZone information was stored in the getEncodedTime()
 * the method returns false and the default TimeZone is set to the Calendar.
 * @param encodedTime the encoded time.
 * @param destination a non-null destination Calendar.
 * @return true if TimeZone information was saved in the encoded time,
 * false if it was not.
 */
public static boolean setEncodedTime(long encodedTime,Calendar destination)
{
	if (destination == null) destination = Calendar.getInstance();
	Time t = (Time)Cache.get(Time.class);
	try{
		t.setEncodedTime(encodedTime);
		t.toCalendar(destination);
		int off = encodedTimeToTimeZoneOffset(encodedTime);
		if (off == NO_TIME_ZONE_IN_ENCODED_TIME) {
			destination.setTimeZone(TimeZone.getDefault());
			return false;
		}else{
			destination.setTimeZone(new SimpleTimeZone(off,"GMT "+off));
			return true;
		}
	}finally{
		Cache.put(t);
	}
}
/**
 * This is a possible return value from encodedTimeToTimeZoneOffset() indicating
 * that the encoded time did not have any TimeZone offset stored within it.
 */
public static final int NO_TIME_ZONE_IN_ENCODED_TIME = 0x7fffffff;
/**
 * 
 * @param encodedTime the encoded time produced by getEncodedTime().
 * @return
 */
public static int encodedTimeToTimeZoneOffset(long encodedTime)
{
	int off = (int)(encodedTime >> 57) & 0x7f;
	if ((off & 0x40) != 0) off |= 0xffffff80;
	if (off == -64) return 0;
	else if (off == 0) return NO_TIME_ZONE_IN_ENCODED_TIME;
	else return off*900000;
}
/**
* Compare two encoded times.
* @param one An encoded time from getEncodedTime().
* @param two An encoded time from getEncodedTime().
* @param ignoreDate if this is true then the date portion will be ignored.
* @param ignoreTime if this is true then the time portion will be ignored.
* @return less than 0 if one is less than two, greater than 0 if one is greater than two, 0 if
* they are equal.
*/
//===================================================================
public static int compareEncodedTimes(long one, long two, boolean ignoreDate, boolean ignoreTime)
//===================================================================
{
	if (!ignoreDate){
		int hiOne = (int) (one >> 32);
		int hiTwo = (int) (two >> 32);
		int o = hiOne & 0x01fffe00;
		int t = hiTwo & 0x01fffe00;
		if (o > t) return 1;
		else if (o < t) return -1;
		o = hiOne & 0x1e0;
		t = hiTwo & 0x1e0;
		if (o > t) return 1;
		else if (o < t) return -1;
		o = hiOne & 0x1f;
		t = hiTwo & 0x1f;
		if (o > t) return 1;
		else if (o < t) return -1;
	}
	if (!ignoreTime){
		int hiOne = (int)one;
		int hiTwo = (int)two;
		int o = hiOne & 0x7c00000;
		int t = hiTwo & 0x7c00000;
		if (o > t) return 1;
		else if (o < t) return -1;
		o = hiOne & 0x3f0000;
		t = hiTwo & 0x3f0000;
		if (o > t) return 1;
		else if (o < t) return -1;
		o = hiOne & 0xfc00;
		t = hiTwo & 0xfc00;
		if (o > t) return 1;
		else if (o < t) return -1;
		o = hiOne & 0x3ff;
		t = hiTwo & 0x3ff;
		if (o > t) return 1;
		else if (o < t) return -1;
	}
	return 0;
}
//===================================================================
public String getText()
//===================================================================
{
	return Convert.toString(getEncodedTime());
}
//===================================================================
public void setText(String text)
//===================================================================
{
	setEncodedTime(Convert.toLong(text));
}

//===================================================================
public int hashCode()
//===================================================================
{
	return (int)getTime();
}
/**
 * Set the Time of day fields only in this Time object to be the same as
 * the other Time object.
 * @param other the other Time to take the time values from.
 * @return the result of a call isValid() after a call to update().
 */
public boolean setTimeOfDay(Time other)
{
	this.hour = other.hour;
	this.minute = other.minute;
	this.second = other.second;
	this.millis = other.millis;
	return update().isValid();
}
/**
 * Set the date fields only in this Time object to be the same as
 * the other Time object.
 * @param other the other Time to take the date values from.
 * @return the result of a call isValid() after a call to update().
 */
public boolean setDayOfYear(Time other)
{
	this.year = other.year;
	this.month = other.month;
	this.day = other.day;
	return update().isValid();
}
//private static Calendar utc;
/*
//===================================================================
public Date getDate()
//===================================================================
{
	return toCalendar(null).getTime();
}
//===================================================================
public Time setDate(Date date)
//===================================================================
{
	Calendar c = Calendar.getInstance();
	c.setTime(date);
	return fromCalendar(c);
}
*/
/**
 * Set the time to be the current local time.
 * @return this Time.
 */
//===================================================================
public Time setToCurrentTime()
//===================================================================
{
	doGetSetTime(0,false,true);
	return this;
}

private long doGetSetTime(long time,boolean isGet,boolean setToCurrent)
{
	if (hasNative) try{
		return getSetTime(time,isGet,setToCurrent);
	}catch(UnsatisfiedLinkError e){
		hasNative = false;
	}catch(SecurityException se){
		hasNative = false;
	}
	synchronized(Time.class){
		Calendar c = _getTemp();
		if (setToCurrent){
			c.setTimeInMillis(System.currentTimeMillis());
		}else if (!isGet){
			c.setTimeInMillis(time);
		}
		if (isGet){
			toCalendar(c);
		}else{
			fromCalendar(c);
		}
		return c.getTimeInMillis();
	}
}
//===================================================================
private native void nativeSetLocalTime() throws IllegalAccessException, IllegalArgumentException;
private native long getSetTime(long time,boolean isGet,boolean setToCurrent);
//===================================================================
/**
* Find the number of days in a month on a particular year.
**/
//===================================================================
public static int numberOfDays(int month,int year)
//===================================================================
{
	if (month < 1 || month > 12) return 0;
	if (month != 2) return dim[month-1];
	if ((year % 4) != 0) return 28;
	if (((year % 100) == 0) && ((year % 400) != 0)) return 28;
	return 29;
}
/**
Returns if the specified year is a leap year.
*/
//===================================================================
public static boolean isLeapYear(int year)
//===================================================================
{
	return numberOfDays(2,year) == 29;	
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Extra methods, in Personal Version, but also must be present
// in Java version as private if necessary.
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
private static Calendar tempCalendar;
private static Calendar _getTemp()
{
	if (tempCalendar == null)
		tempCalendar = Calendar.getInstance();
	return tempCalendar;
}
//===================================================================
public Calendar toCalendar(Calendar destination)
//===================================================================
{
	if (destination == null) destination = Calendar.getInstance();
	if (true || Vm.isJavaVM()){
		destination.set(destination.YEAR,year);
		destination.set(destination.MONTH,destination.JANUARY+(month-1));
		destination.set(destination.DATE,day);
		destination.set(destination.HOUR_OF_DAY,hour);
		destination.set(destination.MINUTE,minute);
		destination.set(destination.SECOND,second);
		destination.set(destination.MILLISECOND,millis);
	}else{
		// DONT use this - will cause problems if different systems
		// have different millisecond values.
		destination.setTimeInMillis(getTime());
	}
	return destination;
}
//===================================================================
public Time fromCalendar(Calendar source)
//===================================================================
{
	year = source.get(source.YEAR);
	month = 1+source.get(source.MONTH)-source.JANUARY;
	day = source.get(source.DATE);
	hour = source.get(source.HOUR_OF_DAY);
	minute = source.get(source.MINUTE);
	second = source.get(source.SECOND);
	millis = source.get(source.MILLISECOND);
	dayOfWeek = source.get(source.DAY_OF_WEEK);
	if (dayOfWeek == source.SUNDAY) dayOfWeek = 7;
	else dayOfWeek = dayOfWeek-source.MONDAY+1;
	return this;
}
/*

//===================================================================
public static synchronized long localTimeToUTC(long localTime,TimeZone tz)
//===================================================================
{
	if (tz == null) tz = TimeZone.getDefault();
	if (utc == null) {
		utc = new Time();
		utcCalendar = Calendar.getInstance();
	}
	utc.setTime(localTime);
	utcCalendar.setTimeZone(tz);
	return utc.toCalendar(utcCalendar).getTimeInMillis();
}
//===================================================================
public static synchronized long UTCTimeToLocal(long utcTime,TimeZone tz)
//===================================================================
{
	if (tz == null) tz = TimeZone.getDefault();
	if (utc == null) {
		utc = new Time();
		utcCalendar = Calendar.getInstance();
	}
	utcCalendar.setTimeInMillis(utcTime);
	utc.fromCalendar(utcCalendar);
	return utc.getTime();
}

//===================================================================
public static long localTimeToUTC(long localTime)
//===================================================================
{
	return localTimeToUTC(localTime, null);
}
//===================================================================
public static long UTCTimeToLocal(long utcTime)
//===================================================================
{
	return UTCTimeToLocal(utcTime, null);
}
*/
private static Calendar utcCal, gmtCal;

private synchronized static void setupUTC()
{
	if (utcCal == null){
		utcCal = Calendar.getInstance();
		gmtCal = Calendar.getInstance(new SimpleTimeZone(0,"GMT"));
	}
}
/**
 * What is the UTC millisecond value given this Time's Y/M/D/h/m/s values at the
 * specified TimeZone.
 * @param tz the TimeZone.
 * @return the UTC millisecond value for this Time's Y/M/D/h/m/s values at the
 * specified TimeZone.
 */
public long getUTCMillis(TimeZone tz)
{
	if (tz == null) tz = TimeZone.getDefault();
	synchronized(Time.class){
		setupUTC();
		utcCal.setTimeZone(tz);
		toCalendar(utcCal);
		return utcCal.getTimeInMillis();
	}
}
/**
 * Set the Time Y/M/D/h/m/s to be the time that it was at the specified TimeZone
 * given the specified UTC millisecond value.
 * @param tz the TimeZone. If null the default TimeZone is used.
 * @param utcMillis the UTC millisecond value.
 * @return this Time with the Y/M/D/h/m/s values set to values it would be
 * at the specified TimeZone. 
 */
public Time setUTCMillis(TimeZone tz,long utcMillis)
{
	if (tz == null) tz = TimeZone.getDefault();
	synchronized(Time.class){
		setupUTC();
		utcCal.setTimeZone(tz);
		utcCal.setTimeInMillis(utcMillis);
		fromCalendar(utcCal);
	}
	return this;
}
/**
 * Determine what the UTC time was at a particular Time (given by the
 * Y/M/D/h/m/s values in this Time Object)
 * at a particular TimeZone.
 * @param dest an optional destination Time to hold the year,month,day,hours,minutes,seconds and millis
 * of the UTC that coincided with the time given by this Time Object. 
 * @param tz the TimeZone at which this Time object was current - or null
 * for the default TimeZone.
 * @return the destination or new Time Object whose Y/M/D/h/m/s
 * values correspond to the UTC time. Do NOT use getTime() on the returned object
 * and use that to determine the UTC time because getTime() on a Time Object is always
 * influenced by the default TimeZone.
 */
public Time localToUTC(Time dest, TimeZone tz)
{
	if (dest == null) dest = new Time();
	synchronized(Time.class){
		long got = getUTCMillis(tz);
		gmtCal.setTimeInMillis(got);
		dest.fromCalendar(gmtCal);
		return dest;
	}
}
/**
 * Determine what the local time at a current TimeZone was at a particular UTC time(given by the
 * year,month,day,hours,minutes,seconds,millis values in this Time Object)
 * at a particular TimeZone.
 * @param dest an optional destination Time to hold the year,month,day,hours,minutes,seconds and millis
 * of the UTC that co-incided with the time given by this Time Object. 
 * @param tz the TimeZone at which this Time object was current - or null
 * for the default TimeZone.
 * @return the destination or new Time Object whose year,month,day,hours,minutes,seconds and millis
 * values correspond to the UTC time. Do not use getTime() on the returned object
 * and use that to determine the UTC time. getTime() on a Time Object is always
 * influenced by the default TimeZone.
 */
public Time UTCToLocal(Time dest, TimeZone tz)
{
	if (dest == null) dest = new Time();
	if (tz == null) tz = TimeZone.getDefault();
	synchronized(Time.class){
		setupUTC();
		utcCal.setTimeZone(tz);
		toCalendar(gmtCal);
		utcCal.setTimeInMillis(gmtCal.getTimeInMillis());
		dest.fromCalendar(utcCal);
		return dest;
	}
}
/**
 * Determine the offset in milliseconds of the Time specified in this time Object from UTC
 * time at a particular TimeZone.
 * @param tz the TimeZone.
 * @return the offset in milliseconds of the Time specified in this time Object from UTC
 * time at a particular TimeZone.
 */
public int getTimeZoneUTCOffset(TimeZone tz)
{
	if (tz == null)tz = TimeZone.getDefault();
	synchronized(Time.class){
		Calendar tc = toCalendar(_getTemp());
		tc.setTimeZone(tz);
		
		if (false)
		return tc.get(Calendar.ZONE_OFFSET);
		else
		return tz.getOffset(GregorianCalendar.AD, tc.get(Calendar.YEAR), tc.get(Calendar.MONTH), tc.get(Calendar.DATE), tc.get(Calendar.DAY_OF_WEEK), 
				tc.get(Calendar.MILLISECOND)+
				tc.get(Calendar.SECOND)*1000+
				tc.get(Calendar.MINUTE)*1000*60+
				tc.get(Calendar.HOUR_OF_DAY)*1000*60*60
				);
		
	}
}
/**
 * @deprecated - use Time.localToUTC(Time dest,TimeZone tz) instead.
 */
public static long localTimeToUTC(long localTime)
//===================================================================
{
	return localTime;
}
/**
 * @deprecated - use Time.UTCToLocal(Time dest,TimeZone tz) instead.
 */
public static long UTCTimeToLocal(long utcTime)
//===================================================================
{
	return utcTime;
}

/**
 * Set the local time on the computer to the specified time.
 * @throws IllegalAccessException if the current process does not have permission to
 * do this.
 * @throws IllegalArgumentException if the time in this Time Object is not considered
 * a valid time to set the Time to.
 */
public void setLocalTime() throws IllegalAccessException, IllegalArgumentException
{
	try{
		nativeSetLocalTime();
	}catch(IllegalArgumentException e){
		throw e;
	}catch(IllegalAccessException e){
		throw e;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		throw new IllegalAccessException();
	}
}
/* (non-Javadoc)
 * @see eve.util.Stringable#toString(eve.util.CharArray)
 */
public CharArray toString(CharArray dest) {
	return toString(this,(format == null ? getDefaultFormat() : format),Locale.getDefault(),dest);
}
/* (non-Javadoc)
 * @see eve.util.Stringable#fromString(char[], int, int)
 */
public void fromString(char[] src, int offset, int length) {
	fromString(new String(src,offset,length));
}
public PlainDate getDate(PlainDate dest) {
	if (dest == null) dest = new PlainDate();
	dest.day = day;
	dest.month = month;
	dest.year = year;
	return dest;
}
public void setDate(int day, int month, int year) {
	this.day = day;
	this.month = month;
	this.year = year;
}
public PlainTime getTime(PlainTime dest) {
	if (dest == null) dest = new PlainTime();
	dest.hour = hour;
	dest.minute = minute;
	dest.second = second;
	dest.millis = millis;
	return dest;
}
public void setTime(int hour, int minute, int second, int millis) {
	this.hour = hour;
	this.minute = minute;
	this.second = second;
	this.millis = millis;
}
public boolean dateIsValid() {
	return isValid();
}
public void makeDateInvalid() {
	setTime(invalidTime);
}
public void makeTimeInvalid() {
	setTime(invalidTime);
}
public boolean timeIsValid() {
	return isValid();
}

//##################################################################
}
//##################################################################

