/*
 * Created on Mar 23, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.Vector;

import eve.util.StringList;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public final class Cache {
	
	private Cache(){}
	private static ResourceCache rc;// = new ResourceCache();
	
	public static boolean debugCache = false;//true;
	
	private static ReferenceQueue cachedQueue = new ReferenceQueue();
	private static Vector takenOut = new Vector();
	static {
		new Thread(){
			public void run(){
				while(true){
					try{
						CachedRef cr = (CachedRef)cachedQueue.remove(1000);
						if (cr != null){
							int idx = indexOf(cr);
							if (idx != -1)
								takenOut.removeElementAt(idx);
							if (debugCache) cr.stack.printStackTrace();
						}
						if (debugCache) System.gc();
						
					}catch(InterruptedException e){
						
					}catch(Throwable t){
						t.printStackTrace();
					}
				}
				
			}
		}.start();
	}
	static class CachedRef extends WeakReference{
		Exception stack;
		public CachedRef(Object obj){
			super(obj,cachedQueue);
			if (obj == null) throw new NullPointerException();
			if (debugCache) stack = new Exception(obj.getClass().getName()+" freed.\n");
		}
		//
		// Java version of Vector was not calling this for some reason.
		//
		public boolean equals(Object obj){
			return obj == this || obj == CachedRef.this.get();
		}
	}
	static int indexOf(Object obj)
	{
		synchronized(takenOut){
			int sz = takenOut.size();
			for (int i = 0; i<sz; i++){
				CachedRef cr = (CachedRef)takenOut.get(i);
				if (cr == obj || cr.get() == obj) return i;
			}
			return -1;
		}
	}
	static Object cached(Object obj, boolean out)
	{
		if (!debugCache) return obj;
		if (obj instanceof StringList){
			//if (out) Vm.debug(">>>");
			//else Vm.debug("<<<");
			//Vm.debug(Convert.toString(System.identityHashCode(obj)));
		}
		if (obj == null) return obj;
		CachedRef cr = out ? new CachedRef(obj) : null;
		//if (true) return;
		synchronized(takenOut){
			int idx = indexOf(obj);
			//if (idx != -1) System.out.println("Back->"+idx);
			if (idx != -1) {
				WeakReference wr = (WeakReference)takenOut.get(idx);
				wr.clear();
				takenOut.removeElementAt(idx);
			}
			if (out){
				takenOut.add(cr);
				idx = indexOf(obj);
				//if (idx != -1) System.out.println("")
				//System.out.println(takenOut+" Added: "+System.identityHashCode(cr.get())+" at "+idx+" in: "+takenOut.size());
				//mThread.nap(5000);
			}
		}
		return obj;
	}
	
	static Object makeNew(Class type) throws IllegalArgumentException
	{
		try{
			return type.newInstance();
		}catch(Throwable e){
			RuntimeException ret = new IllegalArgumentException("Cannot create a new: "+type);
			Vm.setCause(ret,e);
			throw ret;
		}
	}
	/**
	 * Put an Object in the cache.
	 * @param obj the object to put in the cache.
	 * @return null always.
	 */
	public static Object put(Object obj)
	{
		cached(obj,false);
		synchronized(Cache.class){
			if (rc == null) rc = new ResourceCache();
		}
		rc.cache(rc,obj);
		return null;
	}
	/**
	 * This always returns toReturn, but if toReturn is not equal to fromCache
	 * then it will place fromCache back in the cache before returning.
	 * @param toReturn an Object to return.
	 * @param fromCache an Object retrieved from the Cache.
	 * @return toReturn always.
	 */
	public static Object returnCached(Object toReturn, Object fromCache)
	{
		if (toReturn != fromCache && fromCache != null) put(fromCache);
		return toReturn;
	}
	
	public static Object tryGet(Class type)
	{
		synchronized(Cache.class){
			if (rc == null) rc = new ResourceCache();
		}
		return cached(rc.getCached(rc,type,false),false);
	}
	
	public static Object get(Class type)
	{
		synchronized(Cache.class){
			if (rc == null) rc = new ResourceCache();
		}
		return cached(rc.getCached(rc,type,true),true);
	}
	public static Object clear(Class type)
	{
		synchronized(Cache.class){
			if (rc == null) return type;
		}
		rc.clearCache(rc,type);
		return type;
	}
	/*
	public static void main(String[] args) 
	{
		Vm.debug("Start");
		Object obj1 = "Hello";
		Object obj2 = "Hello";
		Class c = Cache.class;
		Vm.debug("Again");
		Class c2 = Cache.class;
	}
	*/
}

//####################################################
