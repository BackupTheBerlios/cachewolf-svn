/*
 * Created on Aug 13, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface TimerProc {

	public void ticked(Object timer, long elapsed);
}

//####################################################
