package eve.sys;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
/**
 * A Proxy is a class created by the virtual machine that implements a 
 * set of interfaces and provides a single method that can be used to implement
 * all the methods.<p>
 * One use of Proxies is to implement remote method calls. You can use Vm.getRemoteProxyMaker()
 * to get an IRemoteProxyMaker object which will create a proxy object that
 * implements methods by making calls across a specified communication line.
 * However if there is a problem with the communication channel, the proxy 
 * returned by IRemoteProxyMaker will fail by throwing a RemoteMethodException
 * and thereafter it may not be possible to do further calls using the proxy.
 * <p>
 * This class provides a way of recovering from such an error. This class
 * is used to wrap a proxy such that a RemoteMethodException triggers a
 * call to the abstract method handleRemoteMethodException(). That method
 * should attempt to re-establish a connection and then create a new proxy
 * to be used instead of the original. The method call is then attempted
 * again on that new proxy and normal operation continues. 
 * <p>
 * Each instance of RemoteProxy can only handle a single proxy, so you should
 * create a new one for each proxy created. 
 */
public abstract class SafeRemoteProxy implements InvocationHandler{

	/**
	 * The original or current external proxy being used.
	 */
	protected Object originalProxy;
	/**
	 * The classes implemented by the proxy.
	 */
	protected Class[] interfaces;
	/**
	 * If you are using the createProxy() method, this is the ClassLoader
	 * that is used to create the proxy. If you keep it as null it will default
	 * to being the System ClassLoader or all registered class loaders.
	 */
	protected ClassLoader proxyClassLoader;
	/**
	 * Create a RemoteProxy.
	 * @param createdProxy a proxy object that has already been created.
	 * @param interfaces the list of interfaces implemented by the proxy.
	 * @param proxyClassLoader an optional ClassLoader to be used with proxy creation.
	 */
	protected SafeRemoteProxy(Object createdProxy, Class[] interfaces, ClassLoader proxyClassLoader)
	{
		this.proxyClassLoader = proxyClassLoader;
		this.interfaces = (Class[])interfaces.clone();
		originalProxy = createdProxy;
	}
	/**
	 * A simpler way to crete a RemoteProxy.
	 * @param createdProxy a proxy object that has already been created.
	 * @param implementedInterface the single interface implemented by the proxy.
	 */
	protected SafeRemoteProxy(Object createdProxy,Class implementedInterface)
	{
		this.interfaces = new Class[]{implementedInterface};
		originalProxy = createdProxy;
	}
	/**
	 * Create and return the proxy that implements the same intefaces as the original
	 * proxy.
	 */
	public Object createProxy()
	{
		return Reflection.newProxyInstance(proxyClassLoader, interfaces, this);
	}
	
	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		//
		Wrapper w = Reflection.handleProxyObjectMethod(originalProxy,method,args);
		if (w != null) return w.toJavaWrapper();
		//
		for (int attempt = 1;;attempt++)
		{
			try{
				return method.invoke(originalProxy, args);
			}catch(InvocationTargetException e){
				Throwable t = e.getTargetException();
				if (t instanceof RemoteMethodException){
					Object newProxy = handleRemoteMethodException(method,(RemoteMethodException)t, attempt);
					if (newProxy != null){
						originalProxy = newProxy;
						continue;
					}
				}
				throw t;
			}
		}
		
	}

	/**
	 * If the remote proxy that was provided should throw a RemoteMethodException
	 * when a method is called then this method is called.
	 * Here you should try to recover from the 
	 * error (possibly by attempting a reconnect to the remote entity)
	 * and if successful, return a new proxy object that implements the same interfaces
	 * as the original. Or the original proxy object if the problem was fixed
	 * and the original proxy will not throw an error if the method is invoked
	 * again.
	 * @param method the method that was being invoked when the RemoteMethodException
	 * occured.
	 * @param thrown the RemoteMethodException that was thrown when the method
	 * was called.
	 * @param numberOfFailures the number of times the method call has failed
	 * consecutively.
	 * @return return a new object that also implements the original interfaces
	 * and which will be used for future calls. Or return null if the error is
	 * unrecoverable, in which case the invokation will re-throw the RemoteMethodException.
	 */
	protected abstract Object handleRemoteMethodException(Method method,RemoteMethodException thrown, int numberOfFailures);
}
