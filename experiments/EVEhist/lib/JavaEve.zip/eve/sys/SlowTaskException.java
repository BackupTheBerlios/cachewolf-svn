package eve.sys;

import java.lang.reflect.Method;

/**
* This class can be thrown by a method if its operations, under some circumstances
* may take a long time. Instead of hanging the calling thread, it can throw this
* exception, which contains a Handle that can be used to monitor the state of the
* operation and retrieve the results.
* <p>However Handles cannot be used by system threads and so a static method
* is provided that will provide a SlowTaskException ONLY if the current thread is not a system thread.
* The method that wants to throw such an exception can then call this
* static method and check if a SlowTaskException was returned. If one was, then it can
* start up a new Thread to perform the task, and use the handle to report the progress
* of the operation. If a SlowTaskException was not returned, then it should just go ahead
* and do the task as normal.
**/
//##################################################################
public class SlowTaskException extends Exception {
//##################################################################

private Handle handle;

public SlowTaskException setHandle(Handle h)
{
	handle = h;
	return this;
}
//===================================================================
public SlowTaskException(Handle h)
//===================================================================
{
	super();
	handle = h;
}
//===================================================================
public SlowTaskException(String message,Handle h)
//===================================================================
{
	super(message);
	handle = h;
}
/**
 * Get the handle for the task being performed.
 */
//===================================================================
public Handle getHandle()
//===================================================================
{
	return handle;
}
/**
 * This returns a new SlowTaskException ONLY if the calling thread is not a system thread.
 * @param message An optional message for the exception.
 * @return a new SlowTaskException ONLY if the calling thread is not a system thread.
 */
//===================================================================
public static SlowTaskException getNew(String message)
//===================================================================
{
	return getNew(message,null);
}
/**
 * This returns a new SlowTaskException ONLY if the calling thread is not in a System Thread.
 * @param message An optional message for the exception.
 * @param h A Handle to be used for the task.
 * @return a new SlowTaskException ONLY if the calling thread can wait.
*/
//===================================================================
public static SlowTaskException getNew(String message,Handle h)
//===================================================================
{
	
	if (Vm.inSystemThread()) return null;
	if (h == null) h = new Handle();
	return message == null ? new SlowTaskException(h) : new SlowTaskException(message,h);
}
/**
 * This returns a new SlowTaskException ONLY if the calling thread is not a System Thread.
 * @return a new SlowTaskException ONLY if the calling thread can wait.
 */
//===================================================================
public static SlowTaskException getNew()
//===================================================================
{
	return getNew(null);
}
/**
 * This returns if a SlowTaskException is appropriate to be thrown here. This
 * checks to see if the current thread is a System Thread and if it is then
 * it is not possible for the Thread to wait and so the SlowTaskException should
 * not be thrown.
 */
public static boolean canThrow()
{
	return !Vm.inSystemThread();
}
//===================================================================
//public SlowTaskException(Throwable cause) {super(cause);}
//===================================================================
//public SlowTaskException(String message,Throwable cause) {super(message,cause);}
//===================================================================

/**
 * Start a Task and let it run for a certain length of time before throwing
 * a SlowTaskException. If the task ends within the specified time
 * then the returnValue field is returned. If an exception is thrown
 * within the task it is thrown by this method.<p>
 * If the current Thread is a System Thread this method runs the task
 * directly within this Thread and so a SlowTaskException is never thrown.
 * @param waitBeforeThrowing how long to wait before considering it slow
 * and throwing a SlowTaskException. If this is zero then the SlowTaskException
 * is always thrown.
 * @param taskToRun the task to run that may take too long.
 * @return if the task completed before the throw time, then the returnValue
 * field of the Handle is returned. Otherwise a SlowTaskException is thrown.
 * @throws SlowTaskException 
 */
public static Object checkSlowTask(int waitBeforeThrowing,Task taskToRun)
throws SlowTaskException
{
	if (Vm.inSystemThread()){
		taskToRun.run();
		return taskToRun.waitForReturnValue();
	}else{
		return checkSlowTask(taskToRun.start(),waitBeforeThrowing);
	}
}
/**
 * Let the runningTask run for a certain length of time before throwing
 * a SlowTaskException. If the task ends within the specified time
 * then the returnValue field is returned. If an exception is thrown
 * within the task it is thrown by this method.
 * @param runningTask the running task that may take too long.
 * @param waitBeforeThrowing how long to wait before considering it slow
 * and throwing a SlowTaskException. If this is zero then the SlowTaskException
 * is always thrown.
 * @return if the task completed before the throw time, then the returnValue
 * field of the Handle is returned. Otherwise a SlowTaskException is thrown.
 * @throws SlowTaskException 
 */
public static Object checkSlowTask(Handle runningTask, int waitBeforeThrowing)
throws SlowTaskException
{
	try{
		if ((waitBeforeThrowing == 0)
		|| (!runningTask.waitUntilStopped(new TimeOut(waitBeforeThrowing))))
			throw new SlowTaskException(runningTask);
		return runningTask.waitForReturnValue();
	}catch(InterruptedException ie){
		throw new SlowTaskException(runningTask);
	}
}
/**
 * Execute a method on a target Object in a separate Task and then call checkSlowTask
 * on the running Task. If the current Thread is a system thread then the
 * method is called directly instead.
 * @param target the target object which may be null if the method is static.
 * @param method the method to invoke.
 * @param parameters any parameters for the method.
 * @param waitBeforeThrowing the length of time in milliseconds to wait
 * before throwing the SlowTaskException.
 * @return the return value from the method invokation.
 * @throws SlowTaskException
 */
public static Object checkSlowTask(Object target, Method method, Object[] parameters, int waitBeforeThrowing)
throws SlowTaskException
{
	return checkSlowTask(waitBeforeThrowing,Reflection.invokeMethodTask(target,method,parameters));
}
/**
 * Execute a method on a target Object in a separate Task and then call checkSlowTask
 * on the running Task. If the current Thread is a system thread then the
 * method is called directly instead.
 * @param target the target object which may be null if the method is static.
 * @param method the method to invoke.
 * @param parameters any parameters for the method.
 * @param waitBeforeThrowing the length of time in milliseconds to wait
 * before throwing the SlowTaskException.
 * @return the return value from the method invokation.
 * @throws SlowTaskException
 */
public static Object checkSlowTask(Object target, Class targetClass, String method, Object[] parameters, int waitBeforeThrowing)
throws SlowTaskException
{
	final Method m = Reflection.getMethod(targetClass,method,false);
	if (m == null) throw new NoSuchMethodError(method);
	return checkSlowTask(waitBeforeThrowing,Reflection.invokeMethodTask(target,m,parameters));
}
/**
 * This waits until the Handle of the SlowTaskException has stopped and
 * then returns the returnValue. If the Handle fails with an error
 * then the error is thrown as a Runtime exception or as an Error using throwRuntimeError().
 * @return the returnValue field of the Handle.
 */
public Object waitForReturnValue()
{
	return handle.waitForReturnValue();
}
//##################################################################
}
//##################################################################

