package eve.sys;
import java.lang.reflect.Constructor;
import java.util.Vector;

import eve.data.HasProperties;
import eve.data.PropertyList;
/**
A Handle is a standard and flexible way of monitoring any asynchronous process.
**/
//##################################################################
public class Handle implements HasProperties{
//##################################################################
/**
If the process returns an integer return value or code, it should be placed here.
**/
public int returnCode; //This should not be moved! It must be first.
/**
* If the process is supposed to produce or return an object value, it should be
* put here.
**/
public Object returnValue; //This should not be moved! It must be second.
//
int nonce; //This should not be moved! It must be third.
/**
* A status flag indicating that some change has occured.
**/
public static final int Changed = 0x80000000;
/**
* A status flag indicating that the process has stopped.
**/
public static final int Stopped = 0x40000000;
/**
* A status flag indicating that the process has met with success.
**/
public static final int	Success = 0x20000000;
/**
* A status flag indicating that the process has met with failure
**/
public static final int	Failure = 0x10000000;
/**
* A status flag indicating that the process is still running.
**/
public static final int	Running = 0x08000000;
/**
* A status flag indicating that the process has been aborted, probably through
* user intervention.
**/
public static final int	Aborted = 0x04000000;

/** An option for waitOnFlags() - may also be used with or without OPTION_TIMEOUT_IF_NOT_SET */
public static final int OPTION_TIMEOUT_IF_NOT_SET = 0x02000000;
/** An option for waitOnFlags() - may also be used with or without OPTION_TIMEOUT_IF_NOT_SET */
public static final int OPTION_STOP_IF_NOT_SET = 0x01000000;
/** An option for waitOnFlags() - almost always used with OPTION_TIMEOUT_IF_NOT_SET */
//public static final int OPTION_DISCARD_IF_NOT_SET = 0x01000000;
/**
* This is the Success flag ORed with the Stopped flag.
**/
public static final int	Succeeded = Success|Stopped;
/**
* This is the Failure flag ORed with the Stopped flag.
**/
public static final int	Failed = Failure|Stopped;
/**
* This indicates the current progress of the running process. 
* A value of 0 indicates the process has just begun, a value equal to maxProgess indicates
* that the process has reached completion (although the process may still be running). 
* A value less than zero (e.g. -1) indicates that
* the process is running but its progress is unknown.<p>
* Use setProgress() to update this variable and notify waiters on the change.
**/
public float progress = 0;
/**
This is the maximum value that progress will be. By default it is 100, so that you
can call setProgress() with percentage values (0 - 100).
**/
//public int maxProgress = 100;
/**
* By default this is 1.
* If this is set to 0 then a call to changed() is done everytime setProgress() is set, otherwise
* changed is called only when the progress has increased past the last setProgress() by this value.
**/
public float progressResolution = 1;
/**
If an error occurs an Exception should be created and placed here. The message of the
Exception will be the error message that you wish to pass to the monitor.
**/
public Throwable error;
/**
* This is the time that the task started at. Calling startDoing() will set it to be the current
* time and will set the progress to 0.0
**/
public long startTime;
/**
* This gets set to true if the stop() method is called.
**/
public boolean shouldStop = false;
/**
* This is the reason given to the stop() method.
**/
public int stopReason = 0;
/**
* This is a human readable text version of what the process is currently doing.
**/
public String doing = "";
/**
* This is the state of the handle.
**/
private int state;
private int nextProgress;
//private WeakSet stops;
private PropertyList props;
//private boolean shouldDiscard;

/**
 * If this is greater than zero, then checkChangeAccepted() is called whenever
 * changed() is called. By default it is zero.
 */
public int waitChangeAcceptedTime;

protected void interrupt()
{
}
/**
 * This interface is used by an Object that knows how to discard of a particular
 * Object.
 */

public static interface ObjectDiscarder {
	
	/**
	 * Discard, in this Thread, the provided Object.
	 * @param obj the Object to be discarded.
	 * @return true if this ObjectDiscarder knows how to discard of it, 
	 * false if not.
	 */
	public boolean discard(Object obj);
}

private static Vector discarders;

/**
 * Add an ObjectDiscarder to the global set of ObjectDiscarders.
 * @param discarder the ObjectDiscarder to add.
 */
/*
public static synchronized void addDiscarder(ObjectDiscarder discarder)
{
	if (discarder == null) return;
	if (discarders == null) discarders = new Vector();
	discarders.add(discarder);
}
private static void discardOf(Object obj)
{
	if (discarders == null) return;
	for (int i = 0; i<discarders.size(); i++){
		ObjectDiscarder od = (ObjectDiscarder)discarders.get(i);
		try{
			if (od.discard(obj)) break;
		}catch(Throwable t){}
	}
}
protected void discard(Object obj)
{
	try{
		if (obj == null) return;
		Class c = obj.getClass();
		Method m = Reflection.getMethod(c,"free()V",false);
		if (m == null) m = Reflection.getMethod(c,"dispose()V",false);
		if (m == null) m = Reflection.getMethod(c,"close()V",false);
		if (m != null) Reflection.invoke(obj,m,null,null);
		discardOf(obj);
	}catch(Throwable t){}
}
*/
/**
 * Tell the Handle that current or future returnValues should be discarded.
 * This will only work correctly if setResult() or setSuccess() is used to set
 * the return value. If a returnValue has already been set, it will be immediately
 * discarded.
 * @param inThisThread if this is true and there is a returnValue to discard,
 * then the discard() method will be called in this Thread. Otherwise it will
 * be called in a separate Thread.
 */
/*
public void discardResult(boolean inThisThread)
{
	Object rv = null;
	synchronized(this){
		shouldDiscard = true;
		rv = returnValue;
		returnValue = null;
	}
	if (rv != null){
		final Object toD = rv;
		if (inThisThread) discard(toD);
		else new Thread(){
			public void run(){
				discard(toD);
			}
		}.start();
	}
}
*/
/**
 * Tell the Handle that current or future returnValues should be discarded.
 * This will only work correctly if setResult() or setSuccess() is used to set
 * the return value. If a returnValue has already been set, it will be immediately
 * discarded in a separate Thread.
 */
/*
public void discardResult()
{
	discardResult(false);
}
*/
//===================================================================
public Handle(){}
//===================================================================
/**
Create a completed Handle that has its state set to the specified value ORed with Stopped
and has its returnValue field set to the provided parameter.
**/
//===================================================================
public Handle(int status, Object returnValue)
//===================================================================
{
	state = status|Stopped;
	this.returnValue = returnValue;
}
/**
Create a failed Handle that has its state set to Failed and has its error
field set to the provided parameter.
**/
//===================================================================
public Handle(Throwable t)
//===================================================================
{
	state = Failed;
	error = t;
}
//===================================================================
public synchronized PropertyList getProperties()
//===================================================================
{
	if (props == null) props = new PropertyList();
	return props;
}
/**
* Set the Stopped and Failure bits of this Handle and set the errorObject
* to be the specified Throwable. If the state already 
* has the Stopped or Succeess bits set, then this will return false.
**/
//===================================================================
public synchronized boolean fail(Throwable t)
//===================================================================
{
	if ((state & (Stopped|Failure)) != 0) return false;
	error = t;
	setFlags(Failed,0);
	return true;
}

/**
Set the returnValue of the Handle and then set the Stopped and Success bits - this
is the same as setResult(). If
the state already has the Stopped or Failure bits set, then this will return false.
*/
//===================================================================
public boolean succeed(Object returnValue)
//===================================================================
{
	//boolean ret = true;
	synchronized(this){
		if (((state & (Stopped|Failure)) != 0) || shouldStop) return false;
		this.returnValue = returnValue;
		setFlags(Succeeded,0);
		return true;
		/*
		*/
		//dc = (shouldDiscard && returnValue != null); 
	}
	//if (dc) discard(returnValue);
	//return ret;
}
/**
Set the returnValue of the Handle and then set the Stopped and Success bits - this
is the same as succeed(). If
the state already has the Stopped or Failure bits set, then this will return false.
*/
public boolean setResult(Object returnValue)
{
	return succeed(returnValue);
}
/**
 * This calls stop() and sets the status of the handle to Failed and sets error to be a TimedOutException
 * assuming that the Handle has not already stopped.
 * @param timeoutMessage a message for the TimedOutException().
 * @return true if it timed out before it was stopped another way, false if it
 * was already stopped.
 */
public synchronized boolean timeout(String timeoutMessage)
{
	stop(0);
	return fail(timeoutMessage == null ? new TimedOutException() : new TimedOutException(timeoutMessage));
}
/**
 * This calls stop() and sets the status of the handle to Failed and sets error to be a TimedOutException
 * assuming that the Handle has not already stopped.
 * @return true if it timed out before it was stopped another way, false if it
 * was already stopped.
 */
public synchronized boolean timeout()
{
	return timeout(null);
}
/**
 * Wait for a result to be set via setResult() or succeed() or until it has timed out.
 * If the result was set within the timeout period this will return true and you should
 * access returnValue to get the return value. If
 * the handle was stopped due to failure this will throw a HandleStoppedException. If
 * the timeout period expired then this will return null if timeoutIfNotDone is false,
 * and it will cause timeout() and discardResult() to be called if timeoutIfNotDone is true.<p>
 * @param waitFor The length of time to wait. Use TimeOut.Immediate to check
 * without waiting, or TimeOut.Forever to wait indefinitely.
 * @param timeoutIfNotDone if this is true and the result is not available during
 * the TimeOut period then timeout() will be called and this will throw a HandleStopped
 * exception.
 * @return true if successful, false if the TimeOut period expired, but
 * timeoutIfNotDone is false.
 * @throws HandleStoppedException if the Handle was stopped for any reason other than
 * success.
 * @throws InterruptedException if the Thread was interrupted.
 */
/*
public boolean waitOnSuccess(TimeOut waitFor, boolean timeoutIfNotDone) throws HandleStoppedException, InterruptedException
{
	int f = Success;
	if (timeoutIfNotDone) f |= OPTION_TIMEOUT_IF_NOT_SET|OPTION_DISCARD_IF_NOT_SET;
	return waitOn(f,waitFor);
}
*/
/**
 * Wait for a specific length of time for a returnValue to be set and the handle state to
 * be set to Succeess via the setResult() or succeed() calls - but stop() the Handle if
 * the result is not available during the timeout period. This method should only be
 * called once, because if the result is not available the Handle will be stopped via
 * a call to timeout(). 
 * @param waitFor the length of time to wait for.
 * @return true if Success was set, false if not (in which case it never will be). 
 */
public boolean waitOnSuccess(TimeOut waitFor)
{
	while(true){
		try{
			return waitOn(Success|OPTION_TIMEOUT_IF_NOT_SET,waitFor);//|OPTION_DISCARD_IF_NOT_SET,waitFor);
		}catch(HandleStoppedException e2){
			return false;
		}catch(InterruptedException e){}
	}
}
/**
 * This calls waitOnSuccess(waitFor) and then returns the returnValue if it returned
 * true, or null if it returned false.
 * @param waitFor the length of time to wait for.
 * @return returnValue if successful, null if not.
 */
public Object waitOnResult(TimeOut waitFor)
{
	return waitOnSuccess(waitFor) ? returnValue : null;
}
//===================================================================
public void resetProgress(float progressResolution)
//===================================================================
{
	progress = nextProgress = 0;
	this.progressResolution = progressResolution;
}

//===================================================================
public int setProgress(float currentProgress)
//===================================================================
{
//TODO - is this correct?
	progress = currentProgress;
	return changed();
}
/**
 * This method does the following:<ol>
 <li>It sets the doing field to the specified parameter.
 <li>It sets the startTime to the current time.
 <li>It sets the progress to 0.0
 <li>It sets the maxProgress field to match the maxProgress parameter.
 <li>It calls changed() on the handle.
 </ol>
 * @param doing the new value for the doing field.
* @param maxProgress the value to set maxProgress to.
* @return this Handle.
*/
//===================================================================
public int startDoing(String doing)
//===================================================================
{
	this.doing = doing;
	startTime = System.currentTimeMillis();
	progress = nextProgress = 0;
	return changed();
}
//===================================================================
public String getErrorText(String defaultText)
//===================================================================
{
	String ret = null;
	if (error != null) ret = error.getMessage();
	if (ret == null) ret = defaultText;
	return ret;
}
/**
 * Signal that the state has changed somehow (e.g. like the progress
 * or doing field) even if the state bits have not.
 *
 * @return a value that can be used with a call to waitChangeAccepted().
 */
public final int changed()
//===================================================================
{
	int ret = 0;
	synchronized(this){
		doChangeTo(state);
		ret = nonce;
	}
	if (waitChangeAcceptedTime > 0){
		waitChangeAcceptedTime = checkChangeAccepted(ret,waitChangeAcceptedTime);
	}
	//yield();
	return ret;
}
/**
 * Signal to the Handle that a change has been accepted.
 */
public synchronized void changeAccepted()
{
	nonce++;
	notifyAll();
}
/**
 * Wait until the changeAcceptedMethod() was called.
 * @param valueFromChanged the value returned from the changed(), setProgress()
 * or startDoing() method.
 * @param timeout the length of time to wait.
 * @return true if the wait was accepted, false if not or if interrupted.
 */
public synchronized boolean waitChangeAccepted(int valueFromChanged, int timeout)
{
	long now = System.currentTimeMillis();
	while(nonce == valueFromChanged)try{
		long left = (now+timeout)-System.currentTimeMillis();
		if (left <= 0) return false;
		wait(left);
	}catch(InterruptedException e){
		return false;
	}
	return true;
}
/**
 * This is similar to the changeAcceptedMethod() except that:<p>
 * <pre>
 * If the timeout is zero no waiting is done at all and zero is returned.
 * If the changeAccepted() method was not called within the timeout zero is returned.
 * If the changeAccepted() method was called, the timeout is returned.
 * </pre>
 * This provides a simple way of initially waiting for the change to be
 * accepted, but if it was not accepted within an acceptable time, no
 * further waits will be done (in case there is nothing monitoring the 
 * handle).<p>
 * To use it do something like this:<p>
 * <pre>
 * int waitTime = 100; // 1/10th of a second.
 * Handle h = new Handle();
 * int v = h.startDoing("Beginning...");
 * waitTime = checkChangeAccepted(v,waitTime);
 * for (int i = 0; i<max; i++){
 *   --- do some work ---
 *   v = h.setProgress((float)(i+1)/max);
 *   waitTime = checkChangeAccepted(v,waitTime);
 * }
 * </pre>
 * @param valueFromChanged
 * @param timeout
 * @return
 */
public synchronized int checkChangeAccepted(int valueFromChanged, int timeout)
{
	if (timeout <= 0) return 0;
	return waitChangeAccepted(valueFromChanged,timeout) ? timeout : 0;
}
//-------------------------------------------------------------------
private final synchronized void doChangeTo(int newstate)
//-------------------------------------------------------------------
{
	state = newstate & ~Changed;
	nonce++;
	notifyAll();
}
/**
* Everytime it is called it will ensure
* that any waiting Coroutines get notified so they can check to see if the
* state they are waiting for has been achieved.
**/
//===================================================================
public synchronized final void set(int newstate)
//===================================================================
{
	if (newstate != state) doChangeTo(newstate);
}
/**
 * This sets and clears specific flags (bits) in the handle state.
 * Everytime it is called it will ensure
 * that any waiting Coroutines get notified so they can check to see if the
 * state they are waiting for has been achieved.
 * @param switchOn Flag bits to switch on.
 * @param switchOff Flag bits to swtich off.
 */
//===================================================================
public synchronized final void setFlags(int switchOn,int switchOff)
//===================================================================
{
		set((state & ~switchOff)|switchOn);
}
//-------------------------------------------------------------------
public void yield()
//-------------------------------------------------------------------
{
	Thread.yield();
}

public final boolean hasStopped()
{
	return ((state & Stopped) != 0);
}
/**
* This returns the state of the handle.
**/
//===================================================================
public final int check() {return state;}
//===================================================================
//-------------------------------------------------------------------
private int doWaitOnFlagsLocked(int flags,TimeOut t,boolean allFlags) 
throws HandleStoppedException, InterruptedException
//-------------------------------------------------------------------
{
	int state = this.state;
	boolean timeoutIfNotDone = (flags & OPTION_TIMEOUT_IF_NOT_SET) != 0;
	boolean stopIfNotDone = (flags & OPTION_STOP_IF_NOT_SET) != 0;
	//boolean discardIfNotDone = (flags & OPTION_DISCARD_IF_NOT_SET) != 0;
	flags &= ~(OPTION_TIMEOUT_IF_NOT_SET|OPTION_STOP_IF_NOT_SET);//|OPTION_DISCARD_IF_NOT_SET);
	//
	// Uncomment the line below to disable Thread.handleState usage.
	// curThread = null;
	//
	while(true){
		int st = state & flags;
		if (st == flags && allFlags) return state;
		if (st != 0 && !allFlags) return state;
		if ((state & Stopped) != 0) {
			throw new HandleStoppedException();
		}
		if (t.hasExpired()) {
			//if (discardIfNotDone) discardResult(false);
			if (timeoutIfNotDone) {
				timeout();
				throw new HandleStoppedException();
			}else if (stopIfNotDone){
				stop(0);
				return 0;
			}else
				return 0;
		}
		int last = nonce;
		t.waitOn(this);
		state = this.state;
		//if (curThread != null) state |= curThread.handleState;
		if (((flags & Changed) != 0) && nonce != last) {
			return state; //If waiting on a change.
		}
	}
}
//-------------------------------------------------------------------
private final synchronized int doWaitOnFlags(int flags,TimeOut t,boolean allFlags) 
throws HandleStoppedException, InterruptedException
//-------------------------------------------------------------------
{
	if (flags == 0) throw new IllegalArgumentException("flags must not be 0.");
	if (t == null) t = TimeOut.Forever;
	return doWaitOnFlagsLocked(flags,t,allFlags);
}
/**
 * This causes the current Thread to wait until the status of the Handle has ALL
 * the flag bits set as specified by the "flags" parameter, or until the Timout specified
 * expires, or until the Handle has the Stopped bit
 * set (in which case an Exception is thrown).
 * @param flags The flag bits to wait for. Must NOT be zero; an IllegalArgumentException is thrown if it is.
 * @param t The TimeOut to wait for.
 * @return true if the flags were all set within the timeout period, false if not.
 * @exception HandleStoppedException If the handle has the Stopped flag set before all the flags were set.
 * @exception InterruptedException If the Thread was interrupted.
 */
//===================================================================
public final boolean waitOn(int flags,TimeOut t) throws HandleStoppedException, InterruptedException
//===================================================================
{
	return (doWaitOnFlags(flags,t,true) != 0);
}
/**
 * This causes the current Thread to wait until the status of the Handle has ALL
 * the flag bits set as specified by the "flags" parameter, or until the Timout specified
 * expires, or until the Handle has the Stopped bit
 * set (in which case an Exception is thrown).
 * @param flags The flag bits to wait for. Must NOT be zero; an IllegalArgumentException is thrown if it is.
 * @param t The time in milliseconds to wait.
 * @return true if the flags were all set within the timeout period, false if not.
 * @exception HandleStoppedException If the handle has the Stopped flag set before all the flags were set.
 * @exception InterruptedException If the Thread was interrupted.
 */
//===================================================================
public final boolean waitOn(int flags,int t) throws HandleStoppedException, InterruptedException
//===================================================================
{
	return (doWaitOnFlags(flags,new TimeOut(t),true) != 0);
}
/**
 * This causes the current Thread to wait indefinitely until the status of the Handle has ALL
 * the flag bits set as specified by the "flags" parameter, or until the Handle has the Stopped bit
 * set (in which case an Exception is thrown).
 * @param flags The flag bits to wait for. Must NOT be zero; an IllegalArgumentException is thrown if it is.
 * @exception HandleStoppedException If the handle has the Stopped flag set before all the flags were set.
 * @exception InterruptedException If the Thread was interrupted.
 */
//===================================================================
public final void waitOn(int flags) throws HandleStoppedException, InterruptedException
//===================================================================
{
	doWaitOnFlags(flags,TimeOut.Forever,true);
}
/**
 * This causes the current Thread to wait until the status of the Handle has at least one of
 * the flag bits set as specified by the "flags" parameter set, or until the Timout specified
 * expires, or until the Handle has the Stopped bit
 * set (in which case an Exception is thrown).
 * @param flags The flag bits to wait for. Must NOT be zero; an IllegalArgumentException is thrown if it is.
 * @param t The TimeOut to wait for.
 * @return true if any of the flags were all set within the timeout period, false if not.
 * @exception HandleStoppedException If the handle has the Stopped flag set before all the flags were set.
 * @exception InterruptedException If the Thread was interrupted.
 */
//===================================================================
public final boolean waitOnAny(int flags,TimeOut t) throws HandleStoppedException, InterruptedException
//===================================================================
{
	return (doWaitOnFlags(flags,t,false) != 0);
}
/**
 * This causes the current Thread to wait until the status of the Handle has at least one of
 * the flag bits set as specified by the "flags" parameter set, or until the Timout specified
 * expires, or until the Handle has the Stopped bit
 * set (in which case an Exception is thrown).
 * @param flags The flag bits to wait for. Must NOT be zero; an IllegalArgumentException is thrown if it is.
 * @param t The time in milliseconds to wait.
 * @return true if any of the flags were all set within the timeout period, false if not.
 * @exception HandleStoppedException If the handle has the Stopped flag set before all the flags were set.
 * @exception InterruptedException If the Thread was interrupted.
*/
//===================================================================
public final boolean waitOnAny(int flags,int t) throws HandleStoppedException, InterruptedException
//===================================================================
{
	return (doWaitOnFlags(flags,new TimeOut(t),false) != 0);
}
/**
 * This causes the current Thread to wait indefinitely until the status of the Handle has at least
 * one of the flag bits set as specified by the "flags" parameter, or until the Handle has the Stopped bit
 * set (in which case an Exception is thrown).
 * @param flags The flag bits to wait for. Must NOT be zero; an IllegalArgumentException is thrown if it is.
 * @exception HandleStoppedException If the handle has the Stopped flag set before all the flags were set.
 * @exception InterruptedException If the Thread was interrupted.
 */
//===================================================================
public final void waitOnAny(int flags) throws HandleStoppedException, InterruptedException
//===================================================================
{
	doWaitOnFlags(flags,TimeOut.Forever,false);
}
/**
 * Wait until the Handle has stopped.
 * @param howLong How long to wait for.
 * @return true if the Handle stopped within the TimeOut period, false if not.
 * @exception InterruptedException if the Thread was interrupted.
 */
//===================================================================
public final boolean waitUntilStopped(TimeOut howLong) throws InterruptedException
//===================================================================
{
	try{
		return waitOn(Handle.Stopped,howLong);
	}catch(HandleStoppedException e){return true;}
}
/**
 * Wait until the Handle has stopped.
 * @exception InterruptedException if the Thread was interrupted.
 */
//===================================================================
public final void waitUntilStopped() throws InterruptedException
//===================================================================
{
	try{
		waitOn(Handle.Stopped,TimeOut.Forever);
	}catch(HandleStoppedException e){}
}
/**
 * Wait until the Handle has stopped, but do not allow the thread to be interrupted.
 * @param howLong How long to wait for.
 * @return true if the Handle stopped within the TimeOut period, false if not.
 */
//===================================================================
public final boolean waitUntilCompletion(TimeOut howLong)
//===================================================================
{
	while(true){
		try{
			return waitOn(Handle.Stopped,howLong);
		}catch(HandleStoppedException e){return true;}
		catch(InterruptedException e){}
	}
}
/**
 * Wait until the Handle has stopped, but do not allow the thread to be interrupted.
 */
//===================================================================
public final void waitUntilCompletion()
//===================================================================
{
	while(true){
		try{
			waitOn(Handle.Stopped,TimeOut.Forever);
			return;
		}catch(HandleStoppedException e){return;}
		catch(InterruptedException e){}
	}
}
/**
 * Checks to see if all the specified flags have been set.
 * @param flags The flag bits to check for.
 * @return true if the bits are all set, false if not.
 * @exception HandleStoppedException If the handle has the Stopped flag set AND the handle does
 * not have the specified flag bits set.
 */
//===================================================================
public final boolean check(int flags) throws HandleStoppedException
//===================================================================
{
	int s = check();
	if ((s & flags) == flags) return true;
	if ((s & Stopped) == Stopped) throw new HandleStoppedException();
	return false;
}
/**
 * Checks to see if any of the specified flags have been set.
 * @param flags The flag bits to check for.
 * @return true if any of the bits are set, false if not.
 * @exception HandleStoppedException If the handle has the Stopped flag set AND the handle does
 * not have any of the specified flag bits set.
 */
//===================================================================
public final boolean checkAny(int flags) throws HandleStoppedException
//===================================================================
{
	int s = check();
	if ((s & flags) != 0) return true;
	if ((s & Stopped) == Stopped) throw new HandleStoppedException();
	return false;
}
//===================================================================
public final boolean succeeded()
//===================================================================
{
	int s = check();
	return ((s & Success) != 0);
}
/**
* This tells the handle to ask its associated task to stop. It does not
* guarantee to immediately stop the task. The task, because it may be
* an asynchronous task, will do so on its own time.
**/
//===================================================================
public void stop(int reason)
//===================================================================
{
	synchronized(this){
		shouldStop = true;
		stopReason = reason;
		stopIfWaitingOnOther();
		interrupt();
		/*
		if (stops != null){
			Object[] others = stops.getRefs();
			for (int i = 0; i<others.length; i++){
				Handle h = (Handle)others[i];
				if (h != null) h.stop(reason);
			}
		}
		*/
	}
}
/**
* This tells the handle to ask its associated task to start. It does not
* guarantee to immediately start the task. The task, because it may be
* an asynchronous task, will do so on its own time. The default implementation
* of this is to do nothing.
**/
//===================================================================
public Handle start()
//===================================================================
{
	return this;
}

//-------------------------------------------------------------------
private final boolean waitOnOtherLocked(Handle otherHandle, TimeOut t, int flags, boolean copyProgress, boolean onAny)
//-------------------------------------------------------------------
{
	//
	// Here I am locked on otherHandle;
	//
	if (copyProgress) 
		setProgress(otherHandle.progress);
	while(!shouldStop){
		try{
			int ns = copyProgress ? 
				otherHandle.doWaitOnFlagsLocked(flags|Changed,t,false):
				otherHandle.doWaitOnFlagsLocked(flags,t,!onAny);
			if (ns == 0) return false; // Timed out.
			if (copyProgress) setProgress(otherHandle.progress);
			if ((ns & flags) == flags) return true;
			if (((ns & flags) != 0) && onAny) return true;
		}catch(InterruptedException e){
			continue;
		}catch(HandleStoppedException h){
			return false;
		}
	}
	return false;
}

//private Handle waitingOnHandle;
private Thread waitingOnThread;
//-------------------------------------------------------------------
private final boolean waitOn(Handle otherHandle, TimeOut t, int flags, boolean copyProgress, boolean onAny)
//-------------------------------------------------------------------
{
	if (otherHandle == null) return false;
	boolean ret = false;
	//
	synchronized(this){
			waitingOnThread = Thread.currentThread();
	}
	//
	synchronized(otherHandle){
			ret = waitOnOtherLocked(otherHandle,t,flags,copyProgress,onAny);
	}
	synchronized(this){
		waitingOnThread.interrupted();
		waitingOnThread = null;
	}
	return ret;
}

/**
Wait until the flags of another Handle have been set to a particular value. Calling stop()
on this Handle in this method will cause it to abort the wait immediately and return false 
with shouldStop being true.
@param otherHandle The other Handle to wait on.
@param flags The flag bits to wait for.
@param t The time to wait for.
@param copyProgress if this is true then the progress of this Handle will be made the same
as the progress of otherHandle.
@return true if the flags were set within the timeout period. False if the timeout expired
or if stop() was called on this handle or if the other handle stopped before the flags
were set.
*/
//===================================================================
public final boolean waitOn(Handle otherHandle, int flags, TimeOut t, boolean copyProgress)
//===================================================================
{
	return waitOn(otherHandle,t,flags,copyProgress,false);
}
/**
Wait until at least one bit in the flags of another Handle have been set to a particular value. Calling stop()
on this Handle in this method will cause it to abort the wait immediately and return null 
with shouldStop being true.
@param otherHandle The other Handle to wait on.
@param flags The flag bits to wait for.
@param t The time to wait for.
@param copyProgress if this is true then the progress of this Handle will be made the same
as the progress of otherHandle.
@return true if one of the flags bits were set within the timeout period. False if the timeout expired
or if stop() was called on this handle or if the other handle stopped before the flags
were set.
*/
//===================================================================
public final boolean waitOnAny(Handle otherHandle, int flags, TimeOut t, boolean copyProgress)
//===================================================================
{
	return waitOn(otherHandle,t,flags,copyProgress,true);
}
/**
 * This can be used after a call to waitOn() or waitOnAny() has failed.
 * If the shouldStop variable OR if the wasWaitingOn handle has the Aborted flag set,
 * then the handle for this task will be set to Aborted and true will be returned.
 * Otherwise this task's handle will be set to Failure, and its errorObject set to the
 * same error object as wasWaitingOn. If stopWaitingOn is true then the stop() metod
 * will be called on wasWaitingOn.
 * <p><b>Only call this from within the TaskObject's thread.</b>
 * @param wasWaitingOn The Handle that this task was waiting on.
 * @param stopWaitingOn If this is true then wasWaitingOn will have its stop() method called.
 * @return true if this task or the wasWaitingOn task was aborted, false if wasWaitingOn had
 * failed.
 */
//===================================================================
public final boolean checkAbortFail(Handle wasWaitingOn,boolean stopWaitingOn)
//===================================================================
{
		if (shouldStop || ((wasWaitingOn.check() & Aborted) != 0)){
			set(Aborted);
			if (stopWaitingOn) wasWaitingOn.stop(0);
			return true;
		}
		error = wasWaitingOn.error;
		set(Failure);
		if (stopWaitingOn) wasWaitingOn.stop(0);
		return false;
}
/**
 * Call this to check on the result of a waitOn() or waitOnAny() and automatically set the
 * Failure or Abort flag of the handle of this task, based on the failure/success of waitOn.
 * <p><b>Only call this from within the TaskObject's thread.</b>
 * @param resultOfWait The result of the waitOn() or waitOnAny() call.
 * @param wasWaitingOn The hande the task was waiting on.
 * @param stopWaitingOn If this is true then the task will be stopped on failure.
 * @return will always be resultOfWait.
 */
//===================================================================
public final boolean checkFailure(boolean resultOfWait,Handle wasWaitingOn,boolean stopWaitingOn)
//===================================================================
{
	if (resultOfWait) return true;
	checkAbortFail(wasWaitingOn,stopWaitingOn);
	return false;
}

/**
Wait until the otherHandle has the Success flag set.
@param otherHandle the otherHandle to wait on.
@param t The timeout period.
@param copyProgress if this is true then the progress of this Handle will be made the same
as the progress of otherHandle.
@return true if the Success bit was set within the timeout period. False if the timeout expired
or if stop() was called on this handle or if the other handle stopped before the flags
were set. If this method returns false then this Handle will be set to Failure or Aborted
depending on whether stop() was called or whether the timeout expired.
*/
//===================================================================
public final boolean waitOnSuccess(Handle otherHandle, TimeOut t,boolean copyProgress)
//===================================================================
{
	return checkFailure(waitOn(otherHandle,Success,t,copyProgress),otherHandle,true);
}
/**
 * If this Handle cannot be stopped (i.e. although the handle can be used to monitor
 * a task, it cannot be used to stop it) then calling this method will return a Handle
 * that monitors this Handle and that handle can be aborted via stop(). It will not stop
 * the task controlled by this Handle but the wait can be aborted.
 * @return a Handle which will return Success when this handle reports success and
 * will return Aborted if stop() is called on the returned Handle.
 */
public Handle getStoppableWaitOnSuccess()
{
	final Handle waitFor = this;
	return new Task(){
		protected void doRun(){
			if (waitOnSuccess(waitFor,TimeOut.Forever,true))
				set(Success);
		}
	}.start();
}
//-------------------------------------------------------------------
private final boolean stopIfWaitingOnOther()
//-------------------------------------------------------------------
{
	synchronized(this){
		if (waitingOnThread == null) return false;
		try{
			waitingOnThread.interrupt();
		}catch(SecurityException e){}
		return true;
	}
}
/**
 * Convert the error of this Handle to an Exception of the specified class if it is
 * not already so or even if it is null.
 * @param exceptionClass The type of the exception return.
 * @param defaultMessage If there is no current error, or no message associated with
 * the error, then this message will be used to create the new Exception.
 * @return An Exception of the specified class.
 */
//===================================================================
public Throwable convertError(Class exceptionClass,String defaultMessage)
//===================================================================
{
	Throwable toRet = error;
	String message = null;
	if (error != null && !exceptionClass.isInstance(error)){
		toRet = null;
		message = error.getMessage();
	}
	//
	if (toRet != null) return toRet;
	//
	Constructor c = null;
	try{
		c = exceptionClass.getConstructor(new Class[]{String.class});
		toRet = (Throwable)c.newInstance(new Object[]{message});
	}catch(Exception e){
		try{
			c = exceptionClass.getConstructor(new Class[]{});
			toRet = (Throwable)c.newInstance(new Object[]{});
		}catch(Exception e2){
			throw new IllegalArgumentException(exceptionClass+" can not be created.");
		}
	}
	//
	return toRet;
}

/**
 * If the error for this Handle is an Error or a RuntimeException, then this method
 * will throw it, otherwise it will throw defaultException.
 * @param defaultException the default exception to throw. 
 * If this is null a RuntimeException will created and thrown.
 */
public void throwRuntimeError(RuntimeException defaultException)
{
	if (error instanceof Error) throw (Error)error;
	else if (error instanceof RuntimeException) throw (RuntimeException)error;
	else if (defaultException == null) throw new RuntimeException("Unknown error.",error); 
	else throw defaultException;
}
/**
 * If the error for this Handle is an Error or a RuntimeException, then this method
 * will throw it, otherwise it will throw defaultException.
 * @param defaultException the default exception to throw. 
 * If this is null a RuntimeException will created and thrown.
 */
public void throwRuntimeError(Error defaultException)
{
	if (error instanceof Error) throw (Error)error;
	else if (error instanceof RuntimeException) throw (RuntimeException)error;
	else if (defaultException == null) throw new RuntimeException("Unknown error.",error); 
	else throw defaultException;
}
/**
 * If the error for this Handle is an Error or a RuntimeException, then this method
 * will throw it, otherwise it will throw a new RuntimeException with the message "Unknown error."
 */
public void throwRuntimeError()
{
	throwRuntimeError((RuntimeException)null);
}
/**
 * If the error for this Handle is an Error or a RuntimeException, then this method
 * will throw it, otherwise it will throw a new RuntimeException with the defaultMessage.
 * @param defaultMessage the default message to throw. 
 * If this is null the message "Unknown error." will be thrown.
 */
public void throwRuntimeError(String defaultMessage)
{
	if (error instanceof Error) throw (Error)error;
	else if (error instanceof RuntimeException) throw (RuntimeException)error;
	else throw new RuntimeException(defaultMessage == null ? "Unknown error." : defaultMessage,error); 
}
/**
 * This method waits until the Handle has stopped, ignoring any interrupts
 * and then returns the returnValue field. If the Handle fails with an error
 * then the error is thrown as a Runtime exception or as an Error using throwRuntimeError().
 * @return the returnValue field.
 */
public Object waitForReturnValue()
{
	waitUntilCompletion();
	if (((state & Failure) != 0) && error != null)
		throwRuntimeError();
	return returnValue;
}
/**
 * Call this in the case where the process returns an Object on success.
 * @param waitTime how long to wait. If this elapses without any return value
 * then null is returned.
 * @param stopOnTimeout if this is true then timeout() will be called on the Handle
 * if the time expires but the process has not succeeded. This will call stop() on
 * the Handle to let it know to stop and not return any value. 
 * @return the returnValue Object as set by the process, or null if it timed out.
 * @throws InterruptedException if the Thread was interrupted while waiting.
 * @throws HandleStoppedException if the process stops but did not succeed. Check
 * the error field to see if an error was thrown by the process or if.
 */
public Object getReturnValue(TimeOut waitTime, boolean stopOnTimeout) throws InterruptedException, HandleStoppedException
{
	int bit = stopOnTimeout ? OPTION_STOP_IF_NOT_SET : 0;
	if (!waitOn(Success|bit,waitTime)) return null;
	return returnValue;
}
/**
 * Call this AFTER the handle has stopped to get the final return value. It does
 * not wait, it either returns the returnValue immediately or it stops the
 * handle immediately.
 * @return the returnValue or null if it was not available.
 */
public synchronized Object getFinalReturnValue()
{
	if ((state & Succeeded) != Succeeded){
		stop(0);
		return null;
	}
	return returnValue;
}
/**
 * Wait indefinitely, ignoring InterruptedExceptions, for the process to succeed
 * and return a value. If the process fails null is returned and you should check
 * the "error" field to see why.
 * @return the returnValue Object or null on failure of the process.
 */

public Object waitReturnValue()
{
	while(true){
		try{
			return getReturnValue(TimeOut.Forever,true);
		}catch(HandleStoppedException e){
			return null;
		}catch(InterruptedException e){
			
		}
	}
}

/**
 * This is identical to succeed(Object returnValue).
 * @param ret the Object to return.
 * @return true if the return value was set successfully while the Handle
 * had not stopped.
 */
public boolean setReturnValue(Object ret)
{
	return succeed(ret);
}
//##################################################################
}
//##################################################################


