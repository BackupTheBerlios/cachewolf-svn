package eve.sys;

/**
This exception is a RuntimeException that is ignored by the native VM should it be
uncaught.
**/

//##################################################################
public class EventDirectionException extends RuntimeException{
//##################################################################

public EventDirectionException() {super();}
public EventDirectionException(String message) {super(message);}

//##################################################################
}
//##################################################################

