/*
 * Created on Apr 11, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class mThread extends Thread{

	public mThread(){}
	public mThread(Runnable r){super(r);}
	
	/**
	 * Puts the current thread to sleep while catching and discarding any
	 * InterruptedExceptions.
	 * @param millis the length of time to sleep for.
	 */
	public static void nap(long millis)
	{
		try{
			Thread.sleep(millis);
		}catch(InterruptedException e){}
	}
	/**
	 * On a native Eve VM, this will cause the current thread to yield after a certain
	 * number of milliseconds have past since the last yield. On an Java VM, this
	 * has no effect.
	 * @param intervalInMillis the number of milliseconds between yields.
	 * @deprecated
	 */
	public static void yield(long intervalInMillis)
	{
		Device.yield();
	}
	/**
	 * Returns the same value as Vm.inSystemThread().
	 * @see eve.sys.Vm#inSystemThread()
	 * 
	 */
	public static boolean inSystemThread()
	{
		return Vm.inSystemThread();
	}
	
	private static ResourceCache threadResources;
	
	public synchronized static void setupResourceStore(int initialCapacity, float loadFactor)
	{
		if (threadResources != null) threadResources = new ResourceCache(initialCapacity,loadFactor);
	}
	public synchronized static void setupResourceFor(Thread t,int initialCapacity, float loadFactor)
	{
		if (threadResources == null) threadResources = new ResourceCache();
		threadResources.setupFor(t,initialCapacity,loadFactor);
	}
	public synchronized static void putResource(Thread t, String key, Object data)
	{
		if (threadResources == null) threadResources = new ResourceCache();
		threadResources.put(t,key,data);
	}
	public synchronized static Object getResource(Thread t, String key)
	{
		if (threadResources == null) threadResources = new ResourceCache();
		return threadResources.get(t,key);
	}
	/**
	 * This calls setupResources() for the current running thread.
	 */
	public static void setupResources(int initialCapacity, float loadFactor)
	{
		setupResourceFor(Thread.currentThread(),initialCapacity,loadFactor);
	}
	/**
	 * This calls putResource() for the current running thread.
	 */
	public static void putResource(String key, Object data)
	{
		putResource(Thread.currentThread(),key,data);
	}
	/**
	 * This calls getResource() for the current running thread.
	 */
	public static Object getResource(String key)
	{
		return mThread.getResource(Thread.currentThread(),key);
	}
	
	private static ResourceCache rc;
	
	/*
	public static void main(String args[])
	{
		Vm.startEve(args);
		//WeakCache.setCleanInterval(100);
		rc = new ResourceCache();
		boolean made = false;
		while(true){
			if (!made){
				for (int i = 0; i<1; i++)
					new Thread(){
						public void run(){
							System.out.println("For: "+hashCode()+","+rc.get(this,"Resource"));
							rc.put(this,"Resource","Resource for: "+hashCode());
							mThread.nap(100);
							System.gc();
							System.out.println("For: "+hashCode()+","+rc.get(this,"Resource"));
							//rc.remove(this,"Resource");
							System.out.println("For: "+hashCode()+","+rc.get(this,"Resource"));
							rc = null;
							System.gc();
						}
					}.start();
			}
			made = true;
			nap(1000);
			System.gc();
			System.out.println("GC!");
		}
	}
	*/
}

//####################################################
