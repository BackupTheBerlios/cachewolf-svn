/*
 * Created on Nov 28, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * A Countdown is simple Object that can be used to count elapsed time after an initial start point.
 * Unlike a TimeOut, it can be set to different countdown values using the start() method.
 * <p>
 * A Countdown can be used in two ways but you should not use the same Countdown 
 * object in both ways. It can be used as a simple lookup where a calling thread calls
 * start() to mark the current time and then can call hasExpired(), timeRemaining() and
 * elapse() to check the state of the Countdown. No extra Thread is created using these
 * methods.
 * <p>
 * Or it can be used to automatically generate a "tick" after a specified interval via
 * a separate Thread that it creates for this purpose. To do that you call one of the
 * requestTick() methods. Note that unlike a Timer, a Countdown
 * can only service one "tick" at a time. Any call to requestTick() will override
 * previous calls.
 *  
 * @author Michael L Brereton
 */
//####################################################
public class Countdown implements Runnable{

	protected long interval = -1;
	protected long started;
	protected Thread myTicker;
	protected TimerProc tickProc;
	
	/**
	 * This is used with the requestTick() methods. It indicates how long the countdown Thread should remain idle after a timer
	 * tick has been done before quitting. If it is less than zero then the timer
	 * Thread will never exit and therefore this Countdown object will never be
	 * garbage collected. If the countdown Thread quits, then a new one will be
	 * created at the next requestTick().
	 */
	public long idleQuitTime = 0;
	/**
	 * Create a new Countdown that will not expire. Call one of the start() methods to begin counting
	 * down.
	 */
	public Countdown()
	{
		start(-1);
	}
	/**
	 * Start counting down from the remaining time left on the TimeOut.
	 * @param remaining a TimeOut object. The remaining() method is called on 
	 * this if it is not null and start() is called using that value. If remaining
	 * is null then an infinite interval is used. 
	 * @return this Countdown object.
	 */
	public Countdown start(TimeOut remaining)
	{
		return start(remaining == null ? -1 : remaining.remaining());
	}
	/**
	 * Start the count down for the specified time.
	 * @param howLongInMillis the interval in milliseconds.
	 * @return this Countdown object.
	 */
	public Countdown start(long howLongInMillis)
	{
		interval = howLongInMillis;
		started = System.currentTimeMillis();
		return this;
	}
	/**
	 * Returns if the time has expired. If the initial time was < 0, indicating an
	 * infinite time, this never returns true.
	 */
	public boolean hasExpired()
	{
		if (interval < 0) return false;
		if (interval == 0) return true;
		return System.currentTimeMillis()-started >= interval;
	}
	/**
	 * Returns the time remaining before the interval expires. If the interval was < 0,
	 * indicating an infinite wait, this returns -1.
	 * @return the time remaining before the interval expires. If the interval was < 0,
	 * indicating an infinite wait, this returns -1. Otherwise it returns 0 if there
	 * is no time remaining, or the actual remaining time.
	 */
	public long timeRemaining()
	{
		if (interval < 0) return -1;
		if (interval == 0) return 0;
		long ret = interval-(System.currentTimeMillis()-started);
		if (ret <= 0) return 0;
		return ret;
	}
	/**
	 * Wait on the Object for the length of time remaining. The current Thread
	 * must hold the lock on the Object.
	 * Returns false if there is no time remaining and no wait is done at all.
	 * @param obj the object to wait on.
	 * @return true if a wait was done, false if no wait was done because there
	 * was no time remaining.
	 * @throws InterruptedException if the wait was interrupted.
	 */
	public boolean waitOn(Object obj) throws InterruptedException
	{
		long left = timeRemaining();
		if (left == 0) return false;
		if (left < 0) obj.wait();
		else obj.wait(left);
		return true;
	}
	
	public void waitUntilExpired() throws IllegalStateException
	{
		while(true){
			long left = timeRemaining();
			if (left == 0) return;
			if (left < 0) throw new IllegalStateException("Countdown never expires.");
			if (!mThread.inSystemThread()) mThread.nap(left);
		}
	}
	/**
	 * Return the amount of time that has elapsed since started was called or
	 * since requestTick() was called.
	 */
	public long elapsed()
	{
		return System.currentTimeMillis()-started;
	}
	
	/**
	 * Request that the Countdown tick() method be called after the specified interval.
	 * No TimerProc is called so you must override the tick() method of this Countdown
	 * in order for this to do any useful work.
	 * @param howLong the length of time to wait before calling the tick() method.
	 */
	public synchronized void requestTick(long howLong)
	{
		requestTick(howLong,true);
	}
	/**
	 * Request that the Countdown tick() method be called after the specified interval.
	 * No TimerProc is called so you must override the tick() method of this Countdown
	 * in order for this to do any useful work.
	 * @param howLong the length of time to wait before calling the tick() method.
	 * @param cancelPrevious If the Countdown is already processing a previous
	 * tick request and this is true, then the previous tick request is cancelled
	 * and the countdown begins again for howLong. Otherwise if cancelPrevious is
	 * false, and ther is a pending tick, then this new request is ignored.
	 */
	public synchronized void requestTick(long howLong, boolean cancelPrevious)
	{
		if (interval >= 0 && !cancelPrevious){
			return;
		}
		cancelTick();
		if (howLong >= 0 && myTicker == null){
			myTicker = new Thread(this);
			myTicker.start();
		}
		start(howLong);
		notifyAll();
		tickProc = null;
	}
	/**
	 * Request a tick to be called on a TimerProc after the specified interval. The ticked()
	 * method will be called synchronized to this object. It is safe to call
	 * requestTick() within that ticked() method call.
	 * @param proc an optional TimerProc object to be called.
	 * @param howLong how long in milliseconds to wait before calling
	 * the ticked() method.
	 */
	public synchronized void requestTick(TimerProc proc, long howLong)
	{
		requestTick(howLong);
		tickProc = proc;
	}
	/**
	 * Cancel any pending tick request and set the interval to -1.
	 */
	public synchronized void cancelTick()
	{
		start(-1);
		notifyAll();
	}
	public synchronized void cancelTick(TimerProc forWho)
	{
		if (tickProc != forWho) return;
		cancelTick();
	}
	/**
	 * Override this to handle ticks. By default it will call ticked()
	 * on the TimerProc specified by requestTick() - if one was specified.
	 * When this method is called by the countdown Thread it holds the lock
	 * for this Countdown object. It IS safe to call requestTick() within this
	 * method. 
	 */
	protected void ticked()
	{
		TimerProc tc = tickProc;
		tickProc = null;
		if (tc != null) tc.ticked(this,elapsed());
	}
	//
	protected void finalize()
	{
		cancelTick();
	}
	/**
	 * Do not call this method directly. It is called by the Countdown Thread.
	 */
	public void run()
	{
		try{
			while(true){
				//boolean doTick = false;
				synchronized(this){
					if (interval < 0) {
						//
						// This means there is no tick request pending.
						// Therefore we should decide whether to quit or wait.
						//
						if (idleQuitTime == 0){
							myTicker = null;
							return;
						}else try{
							if (idleQuitTime < 0) wait();
							else wait(idleQuitTime);
							if (interval < 0 && idleQuitTime >= 0){
								myTicker = null;
								return;
							}
						}catch(InterruptedException e){}
					}else if (hasExpired()){
						cancelTick();
						ticked();
					}else
						try{waitOn(this);}catch(InterruptedException e){}
				}
				//if (doTick) ticked();
			}
		}finally{
			Thread t = Thread.currentThread();
			if (myTicker == t) myTicker = null;
		}
	}
}

//####################################################
