package eve.sys;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Modifier;
import java.util.Hashtable;
import java.util.Vector;

import eve.io.File;
import eve.io.StreamUtils;
import eve.util.ByteArray;
import eve.util.Utils;

//##################################################################
public class ClassFile {//implements Comparable{
//##################################################################

/**
* The data bytes for the class file.
**/
public ByteArray data;
/**
* The size of the class file.
**/
public int size;
/**
* The name of the class file.
**/
public String name = "";
//
public boolean hasNativeMethods;
// Constant Pool tags
public static final int CONSTANT_Utf8               =1;
public static final int CONSTANT_Integer            =3;
public static final int CONSTANT_Float              =4;
public static final int CONSTANT_Long               =5;
public static final int CONSTANT_Double             =6;
public static final int CONSTANT_Class              =7;
public static final int CONSTANT_String             =8;
public static final int CONSTANT_Fieldref           =9;
public static final int CONSTANT_Methodref          =10;
public static final int CONSTANT_InterfaceMethodref =11;
public static final int CONSTANT_NameAndType        =12;

public int accessFlags;
public String superClassName;

public ClassConstantData constantData;

//===================================================================
public ClassFile(ByteArray data)
//===================================================================
{
	this.data = data;
	size = data.length;
	getClassInfo();
}

//===================================================================
public ClassFile(File file) throws IOException
//===================================================================
{
	InputStream in = file.toReadableStream();
	this.data = StreamUtils.readAllBytes(null,in,null);
	in.close();
	size = data.length;
	getClassInfo();
}

public class ClassConstantData{
	
	private int endingOffset;
	private int[] indexes;
	//
	public int getEndingOffset()
	{
		return endingOffset;
	}
	/**
	 * The number of indexes. Indexes go from 1 to size() inclusive. 
	 * Note that some indexes are empty (getType() returns 0) because the
	 * index just before it was a Double or a Long.
	 * @return
	 */
	public int size()
	{
		return indexes.length/2;
	}
	public int getType(int idx)
	{
		return indexes[(idx-1)*2];
	}
	public int offsetOfData(int index, int expectedType,String typeName)
	{
		int i = (index-1)*2;
		if (indexes[i] != expectedType)
			throw new IllegalArgumentException("Index: "+index+" is not a "+typeName);
		return indexes[i+1]+1;
	}
	public String getString(int idx)
	{
		int offset = offsetOfData(idx,CONSTANT_Utf8,"String");
		int sz = Utils.readInt(data.data,offset,2);
		return Utils.decodeJavaUtf8String(data.data,offset+2,sz);		
	}
	//-------------------------------------------------------------------
	public UtfStringConstant getUtfString(int idx)
	//-------------------------------------------------------------------
	{
		int offset = offsetOfData(idx,CONSTANT_Utf8,"String");
		UtfStringConstant usc = new UtfStringConstant();
		usc.length = Utils.readInt(data.data,offset,2);
		usc.bytes = new byte[usc.length];
		System.arraycopy(data.data,offset+2,usc.bytes,0,usc.length);
		usc.string_value = Utils.decodeJavaUtf8String(data.data,offset+2,usc.length);
		usc.size = 1+2+usc.length;
		return usc;
	}
	
	//===================================================================
	public int getClassNameIndex(int index)
	//===================================================================
	{
		return Utils.readInt(data.data,offsetOfData(index,CONSTANT_Class,"Class"),2);
	}
	public String getClassName(int index)
	{
		return getString(getClassNameIndex(index));
	}
	ClassConstantData()
	{
		int curOffset = 8;
		int numIndexes = Utils.readInt(data.data,curOffset,2);
		indexes = new int[(numIndexes-1)*2];
		curOffset += 2;
		int curIndex = 0;
		//System.out.println(numIndexes);
		while(curIndex < numIndexes-1){
			int curIndexSize = 1;
			int curSize = 0;
			int type = (int)data.data[curOffset];
			//System.out.println(curIndex+"->"+type+"@"+curOffset);
			switch(type){
					case CONSTANT_Utf8:
						curSize = Utils.readInt(data.data,curOffset+1,2)+3;
						break;
					case CONSTANT_Integer:
					case CONSTANT_Float:
					case CONSTANT_Fieldref:
					case CONSTANT_Methodref:
					case CONSTANT_InterfaceMethodref:
					case CONSTANT_NameAndType:
						curSize = 5;
						break;
					case CONSTANT_Class:
					case CONSTANT_String:
						curSize = 3;
						break;
					case CONSTANT_Long:
					case CONSTANT_Double:
						curSize = 9;
						curIndexSize = 2;
						break;
					default:
						//new Exception().printStackTrace();
						//System.out.println("Unknown constant at: "+curIndex);
					break;
			}
			int idx = curIndex*2;
			indexes[idx] = type;
			indexes[idx+1] = curOffset;
			curOffset += curSize;
			curIndex += curIndexSize;
		}
		endingOffset = curOffset;
	}
}

/*
//===================================================================
public ClassFile(Streamable source) throws IOException
//===================================================================
{
	try{
		Handle h = source.toStream(false,"r");
		h.waitOn(h.Success);
		Stream s = (Stream)h.returnValue;
		h = IO.readAllBytes(s,-1,false);
		h.waitOn(h.Success);
		data = (ByteArray)h.returnValue;
		size = data.length;
		getClassInfo();
	}catch(Exception e){
		if (e instanceof IOException) throw (IOException)e;
		throw new IOException(e.getMessage());
	}
}
*/
private int getInt(int offset)
{
	return Utils.readInt(data.data,offset,4);
}
private short getShort(int offset)
{
	return (short)Utils.readInt(data.data,offset,2);
}

public Hashtable fields, methods;

public String getString(int index)
{
	return constantData.getString(index);
}
public class FieldMethod {

public String name;
public String type;
public String parameters = "";
public int modifiers;
public int endingOffset;
public int numberOfAttributes;
public int indexOfFirstAttribute;

public FieldMethod(int offset)
{
	int p = offset;
	modifiers = getShort(p);
	int nameIndex = getShort(p+2);
	int descIndex = getShort(p+4);
	name = constantData.getString(nameIndex);
	type = constantData.getString(descIndex);
	p += 6;
	int attrCount = getShort(p); p += 2;
	numberOfAttributes = attrCount;
	indexOfFirstAttribute = p;
	for (int a = 0; a < attrCount; a++){
		nameIndex = getShort(p); p += 2;
		//String attrName = getUtfString(wclass, nameIndex);
		int bytesCount = getInt(p); p += 4;
		p += bytesCount;
	}
	endingOffset = p;
}
public Vector getAttributes(Vector destination)
{
	return getAttributesAt(indexOfFirstAttribute-2, destination);
}
public String toString()
{
	String ret = "";
	if (Modifier.isNative(modifiers)) ret += "*";
	ret += name+parameters+":"+type;
	return ret;
}
public String toKey()
{
	return name+parameters;
}
}
public class ClassField extends FieldMethod{
	public ClassField(int offset)
	{
		super(offset);
	}
}
public class ClassMethod extends FieldMethod{
	public ClassMethod(int offset)
	{
		super(offset);
		int idx = type.indexOf(')');
		parameters = type.substring(0,idx+1);
		type = type.substring(idx+1);
	}
	
}
//===================================================================
public int getFieldsAndMethods()
//===================================================================
{
	fields = new Hashtable();
	methods = new Hashtable();
	int p = constantData.getEndingOffset();
	p += 6; // Get past accessFlags, name and super class name.
	//
	// Go over interfaces.
	//
	int n = getShort(p);
	p += 2 + (n * 2);
	//
	// Load fields.
	//
	int numFields = getShort(p); p += 2;
	for (int i = 0; i<numFields; i++){
		ClassField cf = new ClassField(p);
		fields.put(cf.toKey(),cf);
		p = cf.endingOffset;
		//System.out.println(cf.toString());
	}
	//
	// Load methods.
	//
	int numMethods = getShort(p); p+= 2;
	for (int i = 0; i<numMethods; i++){
		ClassMethod cf = new ClassMethod(p);
		methods.put(cf.toKey(),cf);
		p = cf.endingOffset;
		if (Modifier.isNative(cf.modifiers)) hasNativeMethods = true;
		//System.out.println(cf.toString());
	}
	return p;
}
public static class Attribute {
	protected Attribute(){}
	public String name;
	public byte[] data;
	public int startOfData;
	public int lengthOfData;
	public int readShort(int idx)
	{
		return Utils.readInt(data, idx, 2);
	}
	public int readInt(int idx)
	{
		return Utils.readInt(data, idx, 4);
	}
	public String toString()
	{
		return name;
	}
}

public Attribute getAttributeAt(int byteIndexInClassFile)
{
	Attribute a = new Attribute();
	a.data = data.data;
	a.name = constantData.getString(a.readShort(byteIndexInClassFile));
	if (a.name == null) return null;
	a.lengthOfData = a.readInt(byteIndexInClassFile+2);
	a.startOfData = byteIndexInClassFile+6;
	return a;
}
public Vector getAttributesAt(int byteIndexOfAttributesCount, Vector destination)
{
	if (destination == null) destination = new Vector();
	int numberOfAttributes = getShort(byteIndexOfAttributesCount);
	int p = byteIndexOfAttributesCount+2;
	for (int a = 0; a < numberOfAttributes; a++){
		Attribute at = getAttributeAt(p);
		if (at == null) break;
		destination.add(at);
		p = at.startOfData+at.lengthOfData;
	}
	return destination;
}

/*
public String reportDifference(ClassFile javaVersion)
{
	StringBuffer sb = new StringBuffer();
	for (Enumeration e = methods.elements(); e.hasMoreElements();){
		ClassMethod cm = (ClassMethod)e.nextElement();
		if (Modifier.isPublic(cm.modifiers)){
			ClassMethod other = (ClassMethod)javaVersion.methods.get(cm.toKey());
			if (other == null){
				sb.append("- Missing method in java version: "+cm+"\n");
			}
		}
	}
	for (Enumeration e = javaVersion.methods.elements(); e.hasMoreElements();){
		ClassMethod cm = (ClassMethod)e.nextElement();
		if (Modifier.isNative(cm.modifiers)){
				sb.append("- Native method in java version: "+cm+"\n");
		}
	}
	if (sb.length() == 0) return null;
	return getClassName()+":\n"+sb;
}
*/
/*
//===================================================================
public String getAClassName(int classIndex,ClassPoolIterator cpi)
//===================================================================
{
	if (cpi == null) cpi = new ClassPoolIterator();
	cpi.goTo(classIndex);
	int idx = cpi.getClassIndex();
	cpi.goTo(idx);
	return cpi.getString().toString();
}
*/
//===================================================================
public boolean getClassInfo()
//===================================================================
{
	constantData = new ClassConstantData();
	int endOffset = constantData.endingOffset;
	accessFlags = Utils.readInt(data.data,endOffset,2);
	name = constantData.getClassName(Utils.readInt(data.data,endOffset+2,2));
	int sup = Utils.readInt(data.data,endOffset+4,2);
	if (sup == 0) superClassName = null;
	else superClassName = constantData.getClassName(sup);
	return true;
}
//-------------------------------------------------------------------
protected UtfStringConstant getUtfString(int offset)
//-------------------------------------------------------------------
{
	UtfStringConstant usc = new UtfStringConstant();
	usc.length =	Utils.readInt(data.data,offset+1,2);
	usc.bytes = new byte[usc.length];
	System.arraycopy(data.data,offset+3,usc.bytes,0,usc.length);
	usc.string_value = Utils.decodeJavaUtf8String(data.data,offset+3,usc.length);
	usc.size = 1+2+usc.length;
	return usc;
}
/*
//##################################################################
public class ClassUtfStringPool{
//##################################################################

UtfStringConstant [] all;

//===================================================================
public ClassUtfStringPool()
//===================================================================
{
	all = new UtfStringConstant[Utils.readInt(data.data,8,2)];
}

//===================================================================
public void setStringAt(int index,UtfStringConstant str)
//===================================================================
{
	all[index-1] = str;
}
//===================================================================
public UtfStringConstant getStringAt(int index)
//===================================================================
{
	return all[index-1];
}

//##################################################################
}
//##################################################################
*/

/*
//##################################################################
public class ClassPoolIterator{
//##################################################################

public int curIndex;
public int numIndexes;
public int curOffset;
public int type;
public int curSize = 0;
public int curIndexSize;

public ClassPoolIterator go(int index)
{
	goTo(index);
	return this;
}
//===================================================================
public boolean goTo(int index)
//===================================================================
{
	if (index <= 0) return false;
	index--;
	reset();
	while(index != curIndex && hasMore()){
		getNext();
	}
	return true;
}
//===================================================================
public int getEndingOffset()
//===================================================================
{
	while(hasMore()) {
		getNext();
	}
	int ret = curOffset+curSize;
	reset();
	return ret;
}
//===================================================================
public void reset()
//===================================================================
{
	curIndex = 0;
	curOffset = 8;
	numIndexes = Utils.readInt(data.data,curOffset,2);
	curOffset += 2;
	//if (hasMore()) 
	set();
}
//===================================================================
public ClassPoolIterator()
//===================================================================
{
	reset();
}
//===================================================================
void set()
//===================================================================
{
	curIndexSize = 1;
	type = (int)data.data[curOffset];
	switch(type){
			case CONSTANT_Utf8:
				curSize = Utils.readInt(data.data,curOffset+1,2)+3;
				break;
			case CONSTANT_Integer:
			case CONSTANT_Float:
			case CONSTANT_Fieldref:
			case CONSTANT_Methodref:
			case CONSTANT_InterfaceMethodref:
			case CONSTANT_NameAndType:
				curSize = 5;
				break;
			case CONSTANT_Class:
			case CONSTANT_String:
				curSize = 3;
				break;
			case CONSTANT_Long:
			case CONSTANT_Double:
				curSize = 9;
				curIndexSize = 2;
				break;
	}
}
//===================================================================
public UtfStringConstant getString()
//===================================================================
{
	return getUtfString(curOffset);
}
//===================================================================
public int getClassIndex()
//===================================================================
{
	return Utils.readInt(data.data,curOffset+1,2);
}
//===================================================================
public boolean hasMore()
//===================================================================
{
	return (curIndex+curIndexSize < numIndexes-1);
}
//===================================================================
public boolean getNext()
//===================================================================
{
	curIndex += curIndexSize;
	curOffset += curSize;
	set();
	//if (hasMore()) set();
	return hasMore();
}
public String getStringAt(int index)
{
	if (goTo(index)) return getString().toString();
	return null;
}
//##################################################################
}
//##################################################################
*/
/*
//===================================================================
public ClassUtfStringPool getClassStringPool()
//===================================================================
{
	ClassUtfStringPool cu = new ClassUtfStringPool();
	for(ClassPoolIterator i = new ClassPoolIterator(); i.hasMore(); i.getNext())
		if (i.type == CONSTANT_Utf8)
			cu.setStringAt(i.curIndex+1,i.getString());
	return cu;
}

//===================================================================
public static void sort(Vector v)
//===================================================================
{
	Object [] all = new Object[v.size()];
	v.copyInto(all);
	Utils.sort(all,new StandardComparer(),false);
	v.clear();
	mVector.addAll(v,all);
}
*/
/**
 * Return all the referenced classes as a Vector of Strings.
 * @param addTo The  vector to add to. Can be null.
 * @return The referenced clasess as a Vector of Strings.
 */
/*
//===================================================================
public Vector getAllReferencedClasses(Vector addTo)
//===================================================================
{
	if (addTo == null) addTo = new Vector();
	ClassUtfStringPool cu = getClassStringPool();
	for(ClassPoolIterator i = new ClassPoolIterator(); i.hasMore(); i.getNext())
		if (i.type == CONSTANT_Class){
			int index = i.getClassIndex();
			String put = cu.getStringAt(index).toString();
			if (!addTo.contains(put) && put.charAt(0) != '['){
				addTo.add(put);
			}
		}
	sort(addTo);
	return addTo;
}
//===================================================================
public static Vector clearOutJavaAndEwe(Vector source, Vector dest)
//===================================================================
{
	if (dest == null) dest = new Vector();
	for (int i = 0; i<source.size(); i++){
		String got = source.get(i).toString();
		if (!got.startsWith("java/") && !got.startsWith("ewe/"))
			dest.add(source.get(i));
	}
	return dest;
}
*/
//===================================================================
public String toString()
//===================================================================
{
	return getClassName();
}
/**
Assuming this ClassFile was loaded from the specified source - find out what the
base directory for the class is.
**/
//===================================================================
public File getClassPathFrom(File source)
//===================================================================
{
	String fp = source.getAbsolutePath().replace('\\','/');
	if (!fp.endsWith(".class")) return null;
	fp = fp.substring(0,fp.length()-6);
	String nm = getClassName().replace('.','/');
	if (nm == null) return null;
	nm = "/"+nm;
	if (!fp.toLowerCase().endsWith(nm.toLowerCase())) return null;
	fp = fp.substring(0,fp.length()-nm.length());
	return source.getNew(fp);
}
/*
This is a hashtable of classes, made from a vector of class names with the
unwanted classes removed.
*/
/*
public Hashtable dependancies;

//===================================================================
public static Vector applyFilter(ClassFilter filter, Vector source, Vector dest)
//===================================================================
{
	if (dest == null) dest = new Vector();
	for (int i = 0; i<source.size(); i++){
		String got = source.get(i).toString();
		if (!filter.keepClass(got)) continue;
		dest.add(source.get(i));
	}
	return dest;
}
//===================================================================
public void resolveDependancies(Vector classPaths, Hashtable madeClasses, ClassFilter filter)
throws IOException
//===================================================================
{
	if (dependancies != null) return;
	Vector curList = getAllReferencedClasses(null);
	if (filter != null) curList = applyFilter(filter,curList,null);
	else curList = clearOutJavaAndEwe(curList,null);
	makeDependancies(curList,classPaths,madeClasses,true,filter);
}
*/
/**
 * Create and add to dependancies the referenced classes.
 * @param referenced referenced class names. Usually a filtered version of getAllReferencedClasses().
 * @param classPaths a set of class paths to look in - each should be a File object.
 * @param alreadyMade a hashtable of classes that have already been made.
 * @return the number of dependancies added
 */
/*
//===================================================================
public int makeDependancies(Vector referenced, Vector classPaths, Hashtable alreadyMade, boolean resolveMade,ClassFilter filter)
throws IOException
//===================================================================
{
	if (dependancies != null) return dependancies.size();
	dependancies = new Hashtable();
	for (int i = 0; i<referenced.size(); i++){
		String nm = referenced.get(i).toString();
		if (alreadyMade != null){
			Object got = alreadyMade.get(nm);
			if (got != null){
				dependancies.put(nm,got);
				continue;
			}
		}
		File src = null;
		for (int c = 0; c<classPaths.size(); c++){
			File f = (File)classPaths.get(c);
			src = f.getChild(nm+".class");
			if (src.exists()) break;
			src = null;
		}
		if (src == null){
			//ewe.sys.System.out.println("Cannot find class: "+nm);
			throw new IOException("Cannot find class: "+nm);
		}
		ClassFile made = new ClassFile(src);
		if (alreadyMade != null) alreadyMade.put(nm,made);
		dependancies.put(nm,made);
	}
	if (resolveMade){
		for (Enumeration it = dependancies.elements(); it.hasMoreElements();){
			ClassFile cf = (ClassFile)it.nextElement();
			cf.resolveDependancies(classPaths,alreadyMade,filter);
		}
	}
	return dependancies.size();
}
//===================================================================
public void addDependanciesToNeighbourhood(Hashtable neighbourhood)
//===================================================================
{
	Vector added = new Vector();
	for (Enumeration it = dependancies.elements(); it.hasMoreElements();){
		ClassFile cf = (ClassFile)it.nextElement();
		if (neighbourhood.containsKey(cf.getClassName()))
			continue;
		neighbourhood.put(cf.getClassName(),cf);
		added.add(cf);
	}
	for (int i = 0; i<added.size(); i++){
		ClassFile cf = (ClassFile)added.get(i);
		cf.addDependanciesToNeighbourhood(neighbourhood);
	}	
}

//===================================================================
public static Hashtable readPackages(File baseDirectory, Hashtable destination)
throws IOException
//===================================================================
{
	if (destination == null) destination = new Hashtable();
	String[] all = baseDirectory.list();
	File look = baseDirectory.getNew("");
	for (int i = 0; i<all.length; i++){
		look.set(baseDirectory,all[i]);
		if (all[i].endsWith(".class") && !look.isDirectory()){
			ClassFile cf = new ClassFile(look);
			destination.put(cf.name,cf);
		}else if (look.isDirectory()){
			readPackages(look,destination);
		}
	}
	return destination;
}

static void report(File src, File other,StringBuffer dest) throws IOException
{
	String[] all = src.list("*",File.LIST_DIRECTORIES_ONLY);
	//
	if (all != null) 
		for (int i = 0; i<all.length; i++)
			report(src.getChild(all[i]),other.getChild(all[i]),dest);
	//
	all = src.list("*.class",0);
	if (all != null) 
		for (int i = 0; i<all.length; i++){
			ClassFile cf = new ClassFile(src.getChild(all[i]));
			cf.getFieldsAndMethods();
			//System.out.println("Report: "+cf.getClassName());
			File o = other.getChild(all[i]);
			if (!cf.hasNativeMethods && !o.exists()) continue;
			if (!o.exists()) dest.append(cf.getClassName()+":\n"+"- No java version!\n");
			else{
				ClassFile ocf = new ClassFile(o);
				ocf.getFieldsAndMethods();
				String diff = cf.reportDifference(ocf);
				if (diff != null) dest.append(diff);
			}
		}
}
*/
//##################################################################
public static class UtfStringConstant{
//##################################################################

//public byte [] data;
//public int [] offset;
public int code;
public int length;
public String string_value;
public byte [] bytes;
public int size;

public String _fields = "length,string_value,size";

//===================================================================
public int hashCode()
//===================================================================
{
	return string_value.hashCode();
}
//===================================================================
public String toString() {return string_value;}
//===================================================================
//===================================================================
public boolean equals(Object other)
//===================================================================
{
	if (this == other) return true;
	return string_value.equals(other.toString());
}
//##################################################################
}
//##################################################################

/**
 * Return the class name in the '/' format.
 */
protected String getClassName()
{
	return name == null ? "" : name;	
}
/**
 * Return the class name in the '.' format.
 */
//===================================================================
public String className()
//===================================================================
{
	return name == null ? "" : name.replace('/','.');	
}
//===================================================================
public boolean equals(Object other)
//===================================================================
{
	if (other instanceof String) return getClassName().equals(other);
	else if (other instanceof ClassFile)
		return getClassName().equals(((ClassFile)other).getClassName());
	else return super.equals(other);
}
//===================================================================
public int hashCode()
//===================================================================
{
	return getClassName().hashCode();
}
//##################################################################
}
//##################################################################

