/*
 * Created on Feb 18, 2005
 * @header
 */
package eve.sys;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.ref.ReferenceQueue;
import java.net.Socket;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.Vector;
//import java.util.zip.ZipEntry;
//import java.util.zip.ZipFile;

import eve.io.ByteArrayRandomStream;
import eve.io.FakeFileSystem;
import eve.io.File;
import eve.io.FileRandomStream;
import eve.io.RandomStream;
import eve.io.StreamUtils;
import eve.io.filestore.FileStore;
import eve.nativeaccess.NativeAccess;
import eve.nativeaccess.NativeInputStream;
import eve.nativeaccess.NativeRandomStream;
import eve.nativeaccess.VmMethodCall;
import eve.sys.options.VMOptions;
import eve.util.ByteArray;
import eve.util.Utils;
import eve.util.mClassLoader;
import eve.util.mString;
import eve.util.mVector;
//import eve.zipfile.ZipFile;

/**
 */
/**
 * @author Mike
 *  
 */
public class Vm implements VmConstants {
	
	private static boolean hasNative = true;
	static boolean javaEveLoaded = false;

	static{
		try{
			//System.out.println("Loading?");
			loadLibrary("java_eve");
			javaEveLoaded = true;
		}catch(Throwable t2){
			//System.out.println("Could not load java_eve.dll");
		}
	}
	
/*
 * These are used by the Java VM only for GeneralThreadHandler support. 
 */
	/**
	 * Values for op: 0 = get GeneralThreadHandler pointer, 1 = run a thread, -1 delete thread
	 * native data.
	 */
	static native int threadHandlerOp(int data,int op);
	static synchronized int getThreadHandler()
	{
		return threadHandlerOp(0,0);
	}
	static Object newMonitor()
	{
		return new Object();
	}
	static Object newNativeThread(final int data)
	{
		//System.out.println("Created!");
		try{
			return new Thread(){
				public void run(){
					//System.out.println("Running!");
					threadHandlerOp(data,1);
				}
				public void finalize()
				{
					threadHandlerOp(data,-1);
				}
			};
		}catch(Throwable e){
			e.printStackTrace();
			return null;
		}
	}

private static boolean isSameFile(File f, ByteArray data)
{
	return f.getLength() == data.length;
}
private static boolean saveDLL(String dllName, String destDir, ByteArray ba, boolean canChangeName)
{
	File temp = newFileObject().getNew(destDir);
	OutputStream out = null;
	File dll = temp.getChild(dllName);
	for (int i = 0; i<=10; i++){
		if (isSameFile(dll,ba)){
			//System.out.println("Already there as: "+dll);
			try{
				System.load(dll.getAbsolutePath());
				return true;
			}catch(Throwable t){
				return false;
			}
		}
		//
		// Note that if it is in use, it won't be deleted.
		//
		try{
			out = dll.toWritableStream(false);
			break;
		}catch(IOException e){}
		//
		//Failed to open for writing, may be in use.
		//
		if (!canChangeName) break;
		int idx = dllName.indexOf('.');
		if (idx == -1) dll = temp.getChild(dllName+"-temp-"+(i+1));
		else dll = temp.getChild(dllName.substring(0,idx)+"-temp-"+(i+1)+dllName.substring(idx));
	}
	if (out == null) return false;
	try{
		out.write(ba.data,0,ba.length);
		out.close();
		System.load(dll.getAbsolutePath());
		return true;
	}catch(Throwable t){
		return false;
	}
	//System.out.println("Finally loading: "+dll);
}
/**
 * Load a library using the full name and path to the library.
 * @param libraryName the library to load.
 */
static void load(String libraryName) throws UnsatisfiedLinkError
{
	String nn = libraryName;
	InputStream in = null;
	try{
		if (!isJavaVM() && nn.startsWith("java_eve")) return;
		try{
			
			//System.out.println("Try load: "+libraryName);
			/*
			if (nn.startsWith("libjava_eve"))
				System.load("/home/mike/projects/eve/vm/libjava_eve.so");
			else
			*/
			System.load(libraryName);
			//System.out.println("Loaded: "+libraryName);
			return;
		}catch(Throwable t){
			//t.printStackTrace();
		}
		try{
			File af = findFileResource(libraryName);
			if (af != null){
				//System.out.println("Try: "+af);
				System.load(af.getAbsolutePath());
				return;
			}
		}catch(Throwable t){
			//t.printStackTrace();
		}
		try{
			in = openResource(null,nn);
		}catch(FileNotFoundException f){
			//Device.messageBox("Not found as resource!", nn, Device.MB_TYPE_OK);
			in = null;
		}
		if (in != null){
			//Device.messageBox("Found as resource!", nn, Device.MB_TYPE_OK);
			ByteArray ba = StreamUtils.readAllBytes(null,in,null);
			String dllName = File.getFileExt(nn);
			if (saveDLL(dllName, File.getProgramDirectory(), ba, false))
				return;
			File root = newFileObject();
			String tempDir = (String)root.getInfo(File.INFO_TEMPORARY_DIRECTORY).getObject(String.class);
			//Device.messageBox("Temp:", tempDir, Device.MB_TYPE_OK);
			if (tempDir == null) throw new Exception();
			if (saveDLL(dllName, tempDir, ba, true))
				return;
		}
		throw new UnsatisfiedLinkError(libraryName);
	}catch(Throwable t){
		System.load(libraryName);
	}finally{
		try{
			if (in != null) in.close();
		}catch(Exception e){}
	}
}
/**
 * Load a DLL library to support native methods in a system dependant way.
 * With this method you should not use a path or extension with the library name.
 * This method differs from System.loadLibrary() because it can load
 * libraries from the program resources which may be in a zip or eve file. 
 * @param libraryName the library name.
 */
public static void loadLibrary(String libraryName)
{
	String s = System.mapLibraryName(libraryName);
	load(s);
}
/**
 * This is NEVER to be executed. It simply embedds in this class
 * all the essential classes needed by the VM.
 *
 */
static void linkEssensialClasses()
{
	new VmMethodCall();
	new VMOptions();
	new EventDirectionException();
	new NullPointerException();
	new ArrayIndexOutOfBoundsException();
	new StringIndexOutOfBoundsException();
	new NumberFormatException();
	new IllegalArgumentException();
	new ArithmeticException();
	new RuntimeException();
	new OutOfMemoryError();
	new InterruptedException();
	new UnsatisfiedLinkError();
	new SecurityException();
	new InvalidThreadException();
	new VirtualMachineError();
	new UnsupportedOperationException();
	new ReferenceQueue();
	new FinalizerThread();
	new RunMainThread(null,null);
	eve.sys.registry.Registry.isInitialized(false);
	new ArrayStoreException();
	VMOptions.getNewVMOptions();
	/*
	"java/lang/Object\n"+
	"java/lang/ref/WeakReference\n"+
	"java/lang/ref/SoftReference\n"+
	"java/lang/ref/PhantomReference\n"+
	"java/lang/ref/ReferenceQueue\n"+
	"java/lang/OutOfMemoryError\n"+
	"eve/eni/NativeThread\n"+
	"eve/sys/Vm\n"+
	"eve/sys/FinalizerThread\n"+
	"eve/sys/RunMainThread\n"+
	"eve/sys/registry/Registry"
	*/
}
/**
 * If a true Java VM is running the Eve library then this returns true
 * only if the java_eve library has been successfully loaded. If a native Eve
 * VM is running the library this always returns true.
 */
	public static boolean javaEveLibraryLoaded()
	{
		if (isJavaVM())
			return javaEveLoaded;
		return true;
	}

	native private static boolean checkSystemThread(Thread t);

	native private static Object stringChars(char[] chars, String string);

	native private static void doCallBack(CallBack cb, Object data);
	native private static void nativeSetClipboardText(char[] data,int offset,int length);
	native private static String nativeGetClipboardText();
	native private static String trackObject(int obj,int options,Thread t);
	
	native private static void nativeAppStarted();
	
	/**
	 * This should be called in the eveMain() method of the starting
	 * application. It tells the Vm to initially create no visible main window.
	 */
	public static void eveMainSetNoVisibleWindow()
	{
		setParameter(TURN_ON_VM_FLAG_BITS,VM_FLAG_NO_VISIBLE_WINDOW);
	}
	/**
	 * Get the VM Flag bits - this is equivalent to getParameter(VM_FLAGS);
	 */
	public static int getVmFlags()
	{
		return getParameter(VM_FLAGS);
	}
	/**
	 * Modify the VM Flag bits - this is equivalent to getParameter(VM_FLAGS);
	 * @param flagsToTurnOn - the bits to set, if any.
	 * @param flagsToTurnOff - the bits to clear, if any.
	 * @return a value that can be used with restoreVmFlags() to restore
	 * the flags to their original state.
	 */
	public static long modifyVmFlags(int flagsToTurnOn,int flagsToTurnOff)
	{
		long mask = flagsToTurnOn|flagsToTurnOff;
		long cf = getParameter(VM_FLAGS) & mask;
		setParameter(TURN_ON_VM_FLAG_BITS, flagsToTurnOn);
		setParameter(TURN_OFF_VM_FLAG_BITS, flagsToTurnOff);
		return (mask << 32) | (cf & 0xffffffffL);
	}
	/**
	 * Restore the VM Flag bits to what they were before modifyVmFlags() was
	 * called.
	 * @param fromModifyVmFlags the value returned by modifyVmFlags().
	 */
	public static void restoreVmFlags(long fromModifyVmFlags)
	{
		long mask = (fromModifyVmFlags >> 32) & 0xffffffffL;
		long cf = fromModifyVmFlags & 0xffffffffL;
		long got = getParameter(VM_FLAGS);
		got &= ~mask;
		got |= cf;
		setParameter(VM_FLAGS, (int)got);
	}
	/**
	 * On some systems the VM displays a "Wait" cursor while the
	 * application is starting. This is hidden automatically when
	 * the first window is painted. However if your system does not
	 * display a Window then the Wait cursor may stay on the screen
	 * indefinitely. This method will clear it explicitly.
	 */
	public static void applicationStarted()
	{
		try{
			nativeAppStarted();
		}catch(Throwable t){
			
		}
	}
	public static int getVersion()
	{
		return 126;
	}
	public static String getVersionPostFix()
	{
		return "";
	}
	public static int getTrackKey(Object obj)
	{
		return System.identityHashCode(obj) ^ 0xffffffff;
	}
	public static String trackObject(int obj, int options)
	{
		if (hasNative) try{
			return trackObject(obj,options,Thread.currentThread());
		}catch(Throwable t){
		}
		return null;
	}
	/**
	 * On a native VM this tells the VM that the next call to Throwable.fillInStackTrace()
	 * should ignore the specified number of lines.
	 * @param toIgnore the number of lines to ignore.
	 */
	public static void fixFillInStackTrace(int toIgnore)
	{
		if (hasNative) try{
			NativeAccess.ignoreNextFillStackTrace = toIgnore;
		}catch(Throwable t){
		}
	}
	private static Type appletType;
	/**
	 * Return the Applet to use when running under Java. Under Java this
	 * applet is used when running within a browser OR when running from
	 * a command line as a local application.
	 * @return
	 */
	private static Type getAppletType()
	{
		if (appletType == null) appletType = new Type("eve.applet.EveApplet");
		return appletType;
	}
	
	public static void setClipboardText(String text)
	{
		if (text == null) text = "";
		if (hasNative)try{
			nativeSetClipboardText(getStringChars(text),0,text.length());
			return;
		}catch(Throwable t){
			checkNativeAccess(t);
		}
		getAppletType().invoke(null,"setClipboardText(Ljava/lang/String;)V",new Object[]{text});
	}
	public static String getClipboardText()
	{
		if (hasNative)try{
			return nativeGetClipboardText();
		}catch(Throwable t){
			checkNativeAccess(t);
		}
		return (String)getAppletType().invoke(null,"getClipboardText()Ljava/lang/String;",new Object[]{});
	}
	/**
	 * Get a local or remote registry key if supported. This can be used even if the
	 * eve.sys.registry package is not supported.
	 * @param localKey true for a local key, false for a remote key.
	 * @param path the full path, starting with "HKEY_XXXX\". Note that you must
	 * use '\' and not '/' characters as separators.
	 * @param fullAccess true for full read/write access, false for read-only.
	 * @param createIfDoesntExist true to create the key if it does not yet exist.
	 * @return an IRegistryKey object or null if none could be created.
	 */
	public static synchronized IRegistryKey getRegistryKey(boolean localKey, String path, boolean fullAccess, boolean createIfDoesntExist)
	{
		try{
			IRegistryKey ir = //(IRegistryKey)Registry.registries.get(localKey ? Registry.REGISTRY_LOCAL : Registry.REGISTRY_REMOTE);
				localKey ? Registry.getLocalRegistry() : Registry.getRemoteRegistry();
			if (ir == null) return null;
			ir = ir.getSubKey(path);
			if (createIfDoesntExist && !ir.keyExists())
				ir.createKey(true);
			return ir;
		}catch(Throwable t){
			return null;
		}
	}
	/**
	 * Get the "cause" of a target Throwable if one has been set and
	 * if it is supported by the underlying VM.   
	 * @param target the target Throwable.
	 * @return the Throwable set as the cause of the target if any
	 * and if supported, otherwise null is returned.
	 */
	public static Throwable getCause(Throwable target)
	{
		try{
			return target.getCause();
		}catch(Throwable t){
			return null;
		}
	}
	/**
	 * This provides a fully portable method of setting the "cause" of a Throwable for 
	 * exception chaining. Under Java this will only have an effect on Java 1.4 or higher. Under
	 * earlier versions of Java this call will not do anything.
	 * @param target The target Throwable.
	 * @param cause The cause for the target.
	 * @return The target Throwable.
	 * @exception IllegalArgumentException If the cause is the same as the target.
	 * @exception IllegalStateException If the cause for the target has already been set.
	 */
//	===================================================================
	public static Throwable setCause(Throwable target,Throwable cause) throws IllegalArgumentException, IllegalStateException
//	===================================================================
	{
		try{
			return target.initCause(cause);
		}catch(Throwable t){
			return target;
		}
	}

	/**
	 * This method returns true if the specified thread is considered to be a
	 * System Thread - but this only applies to a native Eve VM, it will not
	 * apply to a true Java VM.
	 * <p>
	 * A System Thread is one that is called by specific internal VM functions
	 * or one that has been invoked from a native method.
	 * <p>
	 * A System Thread cannot sleep, or wait without freezing the entire VM.
	 * Therefore if it should attempt to hold a monitor that is already held, or
	 * if it should attempt to call sleep(), or wait() or join another thread,
	 * an InvalidThreadException will be thrown. Also, a call to join() on a
	 * System Thread will also fail because the System Thread will never die.
	 * <p>
	 * You will hardly ever need to deal with a System Thread - usually only if
	 * you are writing a native code interface or if you are trying to maximally
	 * optimize certain operations.
	 * 
	 * @param t
	 *            The Thread to check.
	 * @return true the Thread to check is a System Thread, false if not.
	 */
	public static boolean isSystemThread(Thread t) {
		if (hasNative)
			try {
				return checkSystemThread(t);
			} catch (Throwable tr) {
				checkNativeAccess(tr);
				hasNative = false;
			}
		return false;
	}
	/**
	 * This method returns true if the current thread is considered to be a
	 * System Thread - but this only applies to a native Eve VM, it will not
	 * apply to a true Java VM.
	 * <p>
	 * A System Thread is one that is called by specific internal VM functions
	 * or one that has been invoked from a native method.
	 * <p>
	 * A System Thread cannot sleep, or wait without freezing the entire VM.
	 * Therefore if it should attempt to hold a monitor that is already held, or
	 * if it should attempt to call sleep(), or wait() or join another thread,
	 * an InvalidThreadException will be thrown. Also, a call to join() on a
	 * System Thread will also fail because the System Thread will never die.
	 * <p>
	 * You will hardly ever need to deal with a System Thread - usually only if
	 * you are writing a native code interface or if you are trying to maximally
	 * optimize certain operations.
	 * 
	 * @return true if the current thread is a System Thread, false if not.
	 */
	public static boolean inSystemThread() {
		return isSystemThread(Thread.currentThread());
	}

	private static File fileSystem;

	/**
	 * Set a new File system. This can only be done once.
	 * @param f
	 * @return
	 */
	public synchronized static boolean setFileSystem(File f)
	{
		if (fileSystem != null) return false;
		fileSystem = f;
		return true;
	}
	public static File newFileObject() {
		if (fileSystem == null)
			return new File("");
		return fileSystem.getNew("");
	}

	static native int getSetVMValue(int which, int value, boolean isGet);

	static native void debug(int value, Object what);

	/**
	 * An operation for debug(Object,int) - indicates that the names of the classes of 
	 * created objects should be output on the console. For each use of this operation
	 * there must be an opposite call using DEBUG_END_OBJECT_CREATION before the 
	 * object creation debugging is fully disabled.
	 */
	public static final int DEBUG_START_OBJECT_CREATION = 16;
	/**
	 * An operation for debug(Object,int) - indicates that the names of the classes of 
	 * created objects should no longer be output on the console. For each use of DEBUG_START_OBJECT_CREATION
	 * operation
	 * there must be an opposite call using DEBUG_END_OBJECT_CREATION before the 
	 * object creation debugging is fully disabled.
	 */
	public static final int DEBUG_END_OBJECT_CREATION = 17;
	
	/**
	 * An operation for debug(Object,int) - indicates that the current stack trace
	 * should be output to the console.
	 */
	public static final int DEBUG_STACK_TRACE = 18;
	
	/**
	 * An operation for debug(Object,int) - indicates that the name of a class
	 * and the stack trace should be displayed when a new instance of the class is created.
	 * The Object parameter should be a Class object.
	 * For each use of this operation
	 * there must be an opposite call using DEBUG_END_STACK_TRACE_FOR_CLASS before the 
	 * object creation stack tracing is fully disabled for the Class.
	 */
	public static final int DEBUG_START_STACK_TRACE_FOR_CLASS = 19;
	/**
	 * An operation for debug(Object,int) - indicates that the name of a class
	 * and the stack trace should not be displayed when a new instance of the class is created.
	 * The Object parameter should be a Class object.
	 * For each use of the DEBUG_START_STACK_TRACE_FOR_CLASS operation
	 * there must be an opposite call with this operator before the 
	 * object creation stack tracing is fully disabled for the Class.
	 */
	public static final int DEBUG_END_STACK_TRACE_FOR_CLASS = 20;
	
	/**
	 * Perform a special debuggin operation.
	 * @param parameters dependent on the operation.
	 * @param operation one of the DEBUG_XXX values.
	 */
	public static void debug(Object parameters, int operation)
	{
		if (operation == 0) {
			debug(mString.toString(parameters));
			return;
		}else if (hasNative) try{
			debug(operation,parameters);
			return;
		}catch(Throwable t){
			checkNativeAccess(t);
			hasNative = false;
		}
		switch(operation){
		case DEBUG_STACK_TRACE:
			String s = getStackTrace(new Exception());
			int ignore = 3;
			String[] all = mString.split(s,'\n');
			StringBuffer ret = new StringBuffer();
			for (int i = ignore; i<all.length; i++){
				int idx = all[i].indexOf("at ");
				ret.append(all[i].substring(idx+3));
				ret.append('\n');
			}
			debug(ret.toString());
		}
	}
	private static int javaVmFlags = 0;
	private static int simulateSIP = 0;
	private static int softKeyBarHeight = -1;
	
	public static void setParameter(int whichParameter, int value)
	{
		if (hasNative) try{
			getSetVMValue(whichParameter, value, false);
			return;
		}catch(Throwable t){
			checkNativeAccess(t);
		}
		//
		// Java version
		//
		switch (whichParameter){
		case TURN_ON_VM_FLAG_BITS:
			javaVmFlags |= value;
			break;
		case TURN_OFF_VM_FLAG_BITS:
			javaVmFlags &= ~value;
			break;
		case SIMULATE_SIP:
			simulateSIP = value;
			break;
		case GET_PARAMATER_SOFTKEY_BAR_HEIGHT:
		case GET_PARAMATER_SIP_BUTTON_HEIGHT:
			softKeyBarHeight = value;
			break;
		}
	}
	public static int getParameter(int whichParameter) {
		if (hasNative) try{
			return getSetVMValue(whichParameter, 0, true);
		}catch(Throwable t){
			checkNativeAccess(t);
		}
		//
		// Java version
		//
		switch (whichParameter){
		case VM_FLAGS:
			return javaVmFlags;
		case SIMULATE_SIP:
			return simulateSIP;
		case GET_PARAMATER_SOFTKEY_BAR_HEIGHT:
		case GET_PARAMATER_SIP_BUTTON_HEIGHT:
			return softKeyBarHeight;
		}
		return 0;
	}

	private static void checkNativeAccess(Throwable t) {
		Device.checkNoNativeMethod(t);
	}

	private static int count(int countWhat, boolean gcFirst, Object data)
	{
		if (gcFirst) System.gc();
		if (hasNative)
			try {
				return getSetVMValue(countWhat, 0, true);
			} catch (Throwable t) {
				checkNativeAccess(t);
				hasNative = false;
			}
		return -1;
	}
	/**
	 * Count how many Objects have been allocated and not garbage collected.
	 * This method is only available on a native Eve VM vm, a Java VM will
	 * return -1.
	 * 
	 * @param gcFirst
	 *            true to do a System.gc() call first.
	 * @return the number of Objects allocated but not garbage collected.
	 */
	public static int countObjects(boolean gcFirst) 
	{
		return count(VM_NUM_OBJECTS,gcFirst,null);
	}
	public static int countThreads()
	{
		return count(VM_NUM_THREADS,false,null);
	}
	public static int getUsedObjectMemory(boolean gcFirst)
	{
		return count(VM_OBJECT_MEMORY,gcFirst,null);
	}
	public static int getUsedClassMemory()
	{
		return count(VM_CLASS_MEMORY,false,null);
	}
	/**
	 * Using the native VM this will expose the char array which represents the
	 * String.
	 * <p>
	 * Use this with care! If you write into it using the native VM you will
	 * change the String which is SUPPOSED to be immutable. Under a JavaVM this
	 * will return a COPY of the string arrays.
	 */
	//	===================================================================
	public static char[] getStringChars(String str)
	//	===================================================================
	{
		if (str == null)
			throw new NullPointerException();
		if (hasNative)
			try {
				return (char[]) stringChars(null, str);
			} catch (Throwable t) {
				checkNativeAccess(t);
				hasNative = false;
			}
		char[] dst = new char[str.length()];
		if (dst.length != 0)
			str.getChars(0, dst.length, dst, 0);
		return dst;
	}

	/**
	 * Create a new String that uses the specified character array <b>without
	 * </b> creating a new character array for the String.
	 * <p>
	 * Use this with care. After creating the String you may be able to change
	 * it since you may have direct access to the String's characters. However
	 * under some systems (e.g. Java) this method may allocate a new copy of the
	 * array so do not assume that the provided character array <b>will </b> be
	 * used directly.
	 */
	//	===================================================================
	public static String createStringWithChars(char[] chars)
	//	===================================================================
	{
		if (chars == null)
			throw new NullPointerException();
		if (hasNative)
			try {
				return (String) stringChars(chars, null);
			} catch (Throwable t) {
				checkNativeAccess(t);
				hasNative = false;
			}
		return new String(chars);
	}

	public static long getTimeStampLong() {
		return System.currentTimeMillis();
	}

	//	===================================================================
	/**
	 * This method should not be used unless you are writing operating system
	 * specific native code.
	 * <p>
	 * This method will cause the callBack() method of the specified CallBack
	 * object to be called in a separate System Thread. Under a true Java VM,
	 * this will be called under a separate normal Thread since there is no
	 * System Thread in a Java VM. Under the Eve VM it will be called back at
	 * the soonest opertunity within the System Thread.
	 * 
	 * @param callBack
	 *            The CallBack to be called.
	 * @param data
	 *            Optional data to send to the CallBack object.
	 */
	public static void callBackInSystemThread(final CallBack callBack,
			final Object data)
	//	===================================================================
	{
		if (callBack == null)
			throw new NullPointerException();
		if (hasNative)
			try {
				doCallBack(callBack, data);
				return;
			} catch (Throwable t) {
				checkNativeAccess(t);
				hasNative = false;
			}
		new Thread() {
			public void run() {
				callBack.callBack(data);
			}
		}.start();
	}

	static Locale locale;

	/**
	 * @return The default locale.
	 */
	public synchronized static Locale getLocale() {
		if (locale == null) locale = new Locale();
		return locale;
	}

	public static void debug(String what) {
		if (hasNative)
			try {
				debug(0, what);
				return;
			} catch (Throwable t) {
				checkNativeAccess(t);
				hasNative = false;
			}
		System.out.println(what);
	}

	
	private static Vector resourceDirectories, zipFiles;
	private static Type zipFileType;
	
	private synchronized static void setupResources()
	{
		if (resourceDirectories == null){
			File f = newFileObject();
			Vector v = resourceDirectories = new Vector();
			zipFiles = new Vector();
			File s = f.getNew(File.getProgramDirectory()); 
			v.add(s);
			String cp = getProperty("java.class.path",null);
			if (cp != null){
				char sc = java.io.File.pathSeparatorChar;
				String[] all = mString.split(cp,sc);
				for (int i = 0; i<all.length; i++){
					File ff = f.getNew(all[i]);
					if (ff.isDirectory())
						v.add(ff);
					else if (ff.canRead() && isJavaVM()){
						if (zipFileType == null)
							zipFileType = new Type("java.util.zip.ZipFile");
						if (zipFileType.exists()){
							Object got = zipFileType.newInstance("Ljava/lang/String;",new Object[]{ff.getAbsolutePath()});
							if (got != null){
								//System.out.println(got.getClass());
								zipFiles.add(got);
							}
						}
					}
				}
			}
		}
	}
	private static File findFileResource(String name)
	{
		setupResources();
		for (int i = 0; i<resourceDirectories.size(); i++){
			File f = (File)resourceDirectories.get(i);
			f = f.getChild(name);
			if (f.canRead()) return f;
		}
		return null;
	}
	
	private static native int getStreamedResource(Class clazz, String name, boolean asRandom);
	private static InputStream openLocalResource(Class clazz, String name, boolean asRandom)
	{
		InputStream found = null;
		if (hasNative) try{
			int got = getStreamedResource(clazz,name,asRandom);
			if (got != 0)
				return asRandom ? NativeRandomStream.toRandomStream(got,"r") : NativeInputStream.toInputStream(got);
			if (asRandom){
				got = getStreamedResource(clazz,name,false);
				if (got != 0)
					found = NativeInputStream.toInputStream(got);					
			}
		}catch(Throwable t){
			checkNativeAccess(t);
			hasNative = false;
		}
		if (found == null){
			if (zipFileType != null && zipFileType.exists()){
				for (int i = 0; i<zipFiles.size(); i++){
					Object zf = zipFiles.get(i);
					Object ze = zipFileType.invoke(zf,"getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;",new Object[]{name});
					/*
					ZipFile zf = (ZipFile)zipFiles.get(i);
					ZipEntry ze = zf.getEntry(name);
					*/
					if (ze != null) try{
						found = (InputStream)zipFileType.invoke(zf,"getInputStream(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;",new Object[]{ze});
						//found = zf.getInputStream(ze);
						break;
					}catch(Throwable e){
						found = null;
					}
				}
			}
		}
		if (found == null && !hasNative){
			if (clazz == null) clazz = Object.class;
			found = clazz.getResourceAsStream(name);
		}
		if (found == null)
			found = mClassLoader.loadResourceFromAll(name);
		if (found == null){
			Type ty = getAppletType();
			if (ty.exists())
				found = (InputStream)ty.invoke(null,"openLocalResource(Ljava/lang/String;)Ljava/io/InputStream;",new Object[]{name});
		}
		if (found == null || !asRandom) return found;
		try{
			ByteArray ba = StreamUtils.readAllBytes(null,found,null);
			found.close();
			return new ByteArrayRandomStream(ba,"r");
		}catch(IOException e){
			return null;
		}
	}
	
	/**
	 * Read a resource that <b>may</b> be associated with a specific Class into a
	 * ByteArray in the most efficient way. 
	 * @param clazz an optional Class if the resource is associated with a particular
	 * Class.
	 * @param name a path name for the resource (which may include '/' characters).
	 * @param dest an optional destination ByteArray to append the data to. If this
	 * is null a new one will be created and returned.
	 * @return a ByteArray containing the read in data or null if the resource could
	 * not be found or if there was an error reading the resource.
	 */
	public static ByteArray readResource(Class clazz, String name, ByteArray dest)
	{
		try{
			InputStream in = openResource(clazz,name);
			if (dest == null) dest = new ByteArray();
			StreamUtils.readAllBytes(null,in,dest);
			return dest;
		}catch(IOException e){
			return null;
		}
	}
	
	private static InputStream openResource(Class clazz,String name,boolean asRandom) throws FileNotFoundException
	{
		for (int i = 0; i<2; i++){
			try{
				File f = findFileResource(name);
				if (f != null) return new FileRandomStream(f,"r");
				InputStream got = openLocalResource(clazz,name,asRandom);
				if (got != null) return got;
				return new FileRandomStream(name,"r");
			}catch(FileNotFoundException e){
				if (i != 0) throw e;
				if (name == null || !name.startsWith("eve/")) throw e;
				name = name.toLowerCase();
			}
		}
		throw new FileNotFoundException(name);
	}
	/**
	 * Open a resource that <b>may</b> be associated with a specific Class as an
	 * InputStream.
	 * @param clazz an optional Class if the resource is associated with a particular
	 * Class.
	 * @param name a path name for the resource (which may include '/' characters).
	 * @return an InputStream from which the resource data may be read.
	 * @throws FileNotFoundException if the resource could not be found.
	 */
	public static InputStream openResource(Class clazz,String name) throws FileNotFoundException
	{
		return openResource(clazz,name,false);
	}
	/**
	 * Avoid using this - it is used by the system for specific purposes.
	 * @param clazz
	 * @param name
	 * @return
	 */
	static byte[] loadResource(String name)
	{
		try{
			InputStream in = openResource(null,name);
			ByteArray ba = StreamUtils.readAllBytes(null, in, null);
			in.close();
			return ba.toBytes();
		}catch(Exception e){
			return null;
		}
	}
	/**
	 * Open a resource that <b>may</b> be associated with a specific Class as a
	 * RandomStream.
	 * @param clazz an optional Class if the resource is associated with a particular
	 * Class.
	 * @param name a path name for the resource (which may include '/' characters).
	 * @return an InputStream from which the resource data may be read.
	 * @throws FileNotFoundException if the resource could not be found.
	 */
	public static RandomStream openResourceAsRandomStream(Class clazz,String name) throws FileNotFoundException
	{
		return (RandomStream)openResource(clazz,name,true);
	}
	public static boolean isJavaVM()
	{
		return "java".equals(getProperty("vm.type","java"));
	}
	
	static Properties properties;
	/**
	 * This method attempts to get a System property, but since
	 * that is not allowed for an Applet it will instead fetch it
	 * from a local property list.
	 * @param propertyName the name of the property.
	 * @param defaultValue the default value if it is not found.
	 * @return the found property or the default value.
	 */
	public synchronized static String getProperty(String propertyName, String defaultValue)
	{
		try{
			return System.getProperty(propertyName,defaultValue);
		}catch(Throwable t){
			if (properties == null) return defaultValue;
			return properties.getProperty(propertyName,defaultValue);
		}
	}
	/**
	 * This method attempts to get a system environment value, but since
	 * that is not allowed for an Applet and in some versions of Java
	 * it will instead fetch it
	 * from a local property list.
	 * @param envName the name of the environment value.
	 * @return the found property or the default value.
	 */
	public static String getenv(String envName)
	{
		try{
			return System.getenv(envName);
		}catch(Throwable t){
			//return getProperty(envName,null);
			return null;
		}
	}
	/**
	 * This first searches for an environment value using getenv(), and if
	 * that returns null it will call getProperty().
	 * @param envName the environment value name.
	 * @param defaultValue the default value to return if not found.
	 * @return the found environment, property or the default value if not found.
	 */
	public static String getEnvOrProperty(String envName, String defaultValue)
	{
		String s = getenv(envName);
		if (s != null) return s;
		return getProperty(envName, defaultValue);
	}
	
	public synchronized static void setProperty(String propertyName,String value)
	{
		try{
			System.setProperty(propertyName,value);
		}catch(Throwable t){
			
		}
		if (properties == null) properties = new Properties();
		properties.setProperty(propertyName,value);
	}
	private static boolean eveStarted = false;
	
	/**
	 * You would not normally call this. 
	 * This is called to let the class library know that startup procedures  
	 * and standard Eve arguments have been processed.
	 */
	public static void eveStarted()
	{
		eveStarted = true;
	}
	/**
	 * Get a String representation of the stack trace for a Throwable object. This trace will
	 * display partial traces of all chained exception as well. To get the full trace for any
	 * particular Throwable you should call getAStackTrace().
	 * @param t The throwable object.
	 * @return A String representation of the stack trace.
	 */
//	===================================================================
	public static String getStackTrace(Throwable t)
//	===================================================================
	{
		return getStackTrace(t,-1);
	}
	/**
	 * This gets the fully expanded stack trace for the Throwable and all chained throwables.

	 * @param th The throwable.
	 * @return the fully expanded stack trace for the Throwable and all chained throwables.
	 */
//	===================================================================
	public static String getFullStackTrace(Throwable th)
//	===================================================================
	{
		String got = "";
		for (Throwable t = th;t != null; t = getCause(t)){
			if (t != th) got += "\nCaused by: ";
			got += getAStackTrace(t);
		}
		return got;
	}
	/**
	 * This gets a String representation of the full stack trace for a Throwable, but not for any
	 * of its possible chained exceptions.
	 * @param t The Throwable
	 * @return a String representation of the full stack trace for the Throwable.
	 */
//	===================================================================
	public static String getAStackTrace(Throwable t)
//	===================================================================
	{
		if (t == null) return null;
		java.io.StringWriter sw = new java.io.StringWriter();
		t.printStackTrace(new java.io.PrintWriter(sw));
		java.io.BufferedReader br = new java.io.BufferedReader(new java.io.StringReader(sw.toString()));
		String got = "";
		for (int i = 0;;i++){
			try{
				String line = br.readLine();
				if (line == null) break;
				if (line.startsWith("Caused by:")) break;
				if (i != 0) got += "\n";
				got += line;
			}catch(Exception e){break;}
		}
		return got;
	}
	/**
	 * Get a String representation of the stack trace for a Throwable object.
	 * @param t The throwable object.
	 * @param lines The number of lines to retrieve. If lines <= 0 then all lines will be retrieved
	 * @return A String representation of the stack trace.
	 */
//	===================================================================
	public static String getStackTrace(Throwable t,int lines)
//	===================================================================
	{
		if (t == null) return null;
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		t.printStackTrace(pw);
		BufferedReader br = new BufferedReader(new StringReader(sw.toString()));
		String got = "";
		for (int i = 0;lines < 0 || i<lines; i++){
			try{
				String line = br.readLine();
				if (line == null) break;
				if (i != 0) got += "\n";
				got += line;
			}catch(Exception e){break;}
		}
		return got;
	}
	/**
	 * Display on the console the current stack trace - leaving out this method call.
	 */
	public static void debugStackTrace()
	{
		debug(null,DEBUG_STACK_TRACE);
	}
	
	private static boolean inShutdown = false;
	private static Vector shutdowns;
	
	public static void exit(int exitValue)
	{
		synchronized(Vm.class){
			if (inShutdown) return;
			inShutdown = true;
		}
		if (shutdowns != null){
			for (int i = 0; i<shutdowns.size(); i++){
				try{
					Runnable r = (Runnable)shutdowns.get(i);
					r.run();
				}catch(Throwable t){}
			}
			shutdowns.clear();
		}
		try{
			System.exit(exitValue);
		}catch(Exception e){}
		eveStarted = false;
		inShutdown = false;
	}
	/**
	 * These are executed only when Vm.exit() is called and before
	 * System.exit() is called. They are executed sequentially in the
	 * Thread that called Vm.exit().
	 * @param shutdown the Runnable to run at shutdown.
	 */
	public static synchronized void addShutdown(Runnable shutdown)
	{
		if (inShutdown) return;
		if (shutdowns == null) shutdowns = new Vector();
		shutdowns.add(shutdown);
	}
	
	/**
	 * Have this as the first line of your main() method to ensure that the eveMain()
	 * method is called should the application be run on a Java VM.
	 * @param args the same arguments passed to your main() method.
	 */
	public static void startEve(String[] args,String startClassName)
	{
		if (eveStarted) return;
		eveStarted = true;
		if ((getParameter(VM_FLAGS) & VM_FLAG_LOAD_FAKE_FILE) != 0) try{
			FakeFileSystem fileSystem = new FakeFileSystem();
			boolean added = false;
			try{
				RandomStream s = Vm.openResourceAsRandomStream(null,"_filesystem.zip");
				if (s != null){
					//ZipFile zf = new ZipFile(s);
					Type ty = new Type("eve.zipfile.ZipFile");
					if (ty.exists()){
						FileStore zf = (FileStore)
							ty.newInstance("Leve/io/RandomStream;",new Object[]{s});
					//System.out.println("Loading virtual file system.");
						eve.io.File zef = zf.getFileSystem(null);
						fileSystem.addVolume("Disk1",zef.getNew("/"));
						zf.close();
					}
				}
			}catch(FileNotFoundException e){
				System.out.println("Warning: No _filesystem.zip found.");
			}
			setFileSystem(fileSystem.getFile());
		}catch(Throwable tt){
			tt.printStackTrace();
		}
		if (!isJavaVM()) return;
		Type t = new Type(startClassName);
		if (!t.exists()){
			if (startClassName.equals("StartEve")){
				t = new Type("eve.sys.Vm");
				startClassName = "eve.sys.Vm";
			}else
				throw new RuntimeException("The class: "+startClassName+" cannot be found!");
		}
		Type ty = getAppletType();
		if (ty.exists()){
			mVector v = new mVector(args);
			javaVmFlags = ((Integer)ty.invoke(null,"startEve(Ljava/lang/String;[Ljava/lang/String;)I",new Object[]{startClassName,args})).intValue();
			VMOptions.vmOptions.runMain(args,startClassName);
			//Thread.currentThread().setDaemon(true);
			//System.out.println("Running eveMain() and main()");
			synchronized(Thread.currentThread()){
				try{
					Thread.currentThread().wait();
				}catch(InterruptedException e){}
			}
		}
	}
	
	public static String getCallingClassName(String myClassName)
	{
		try{
			String startClassName = null;
			String st = getStackTrace(new Exception()).replace('/','.');
			int idx = st.indexOf("eve.sys.Vm.getCallingClassName");
			while(true){
				startClassName = null;
				idx = st.indexOf('\n',idx);
				if (idx == -1) break;
				idx = st.indexOf("at ",idx);
				if (idx == -1) break;
				int s = idx+3;
				while (!Character.isJavaIdentifierStart(st.charAt(s))) s++;
				int e = s+1;
				while (Character.isJavaIdentifierPart(st.charAt(e)) || (st.charAt(e) == '.')) e++;
				startClassName = st.substring(s,e);
				startClassName = startClassName.substring(0,startClassName.lastIndexOf('.'));
				if (startClassName.equals("eve.sys.Vm")) continue;
				if (myClassName != null && startClassName.equals(myClassName)) continue;
				break;
			}
			return startClassName;
		}catch(RuntimeException e){
			return null;
		}
	}
	/**
	 * Have this as the first line of your main() method to ensure that the eveMain()
	 * method is called should the application be run on a Java VM.
	 * @param args the same arguments passed to your main() method.
	 */
	public static void startEve(String[] args)
	{
		if (eveStarted || !isJavaVM()) return;
		eveStarted = true;
		String startClassName = getCallingClassName(null);
		if (startClassName == null) return;
		startEve(args,startClassName);
		/*
			String [] args = new String[programArguments.length+1];
			args[0] = startClassName;
			copyArray(programArguments,0,args,1,programArguments.length);
			try{
				ewe.applet.Applet.main(args);
				try{
					synchronized(Thread.currentThread()){
						Thread.currentThread().wait();
					}
				}catch(InterruptedException e){
					
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			//Under a native Ewe VM, this will do nothing.
			 * 
			 
		*/
	}
	/**
	 * Prepare a command line for running. 
	 * It is always safest to place the executable in quotes (") in case it has
	 * spaces in it. This will remove those quotes and place it as a single String
	 * as the first command. If there are quotes in any other arguments, those
	 * other quotes are preserved. The path of the executable is also corrected
	 * to use the correct system directory separators. 
	 * @param commandLine the command line to use, the executable may
	 * be placed in quotes.
	 * @return an array of Strings that you can pass to Runtime.exec().
	 */
	public static String[] processCommandLine(String commandLine)
	{
		String [] got = splitCommand(commandLine,null);
		// Remove quotes from executable.
		
		String[] paths = null;
		if (got.length != 0){
			if (!got[0].startsWith("\"")){
				String s = null;
				for (int i = 0; i<got.length; i++){
					if (i == 0) s = got[i];
					else s += " "+got[i];
					boolean ex = false;
					//System.out.println("Test: "+s);
					for (int pp = -1;;pp++){
						File f = null;
						if (pp == -1) {
							f = File.getNewFile(s);
							ex = f.exists();
							if (!ex && paths == null){
								String p = getenv("PATH");
								paths = p == null ? new String[0] : mString.split(p,File.pathSeparatorChar);
							}
						}
						else if (pp >= paths.length) break;
						else{
							f = File.getNewFile(paths[pp]).getChild(s);
							ex = f.exists();
						}
						//if (!ex) System.out.println(f+" not exists.");
						if (ex){
							//System.out.println("Exists: "+f);
							String[] gg = new String[got.length-i];
							gg[0] = f.getAbsolutePath();
							if (gg.length != 1)
								System.arraycopy(got, i+1, gg, 1, gg.length-1);
							got = gg;
							break;
						}
					}
					if (ex) break;
				}
			}
			for (int q = 0; q<1 /*got.length*/; q++){
				if (got[q].startsWith("\""))
					got[q] = got[q].substring(1,got[q].length()-1);
			}
			got[0] = File.toSystemDependantPath(got[0]);
		}
		return got;
	}
	private static Process tryRun(String fullPath)
	{
		try{
			return Vm.execCommandLine(fullPath);
		}catch(Throwable t){
			return null;
		}
	}
	/**
	 * Try to execute a command which may be in a number of different paths.
	 * @param command the command line to execute. This may have the
	 * executable file in quotations if it contains spaces.
	 * @param paths a list of paths to check in or null to not check in
	 * any paths. Do not place quotations around these. If the command itself
	 * starts with a quotation mark, which indicates that the executable
	 * is in quotations, then the quotations will be extended around
	 * the paths as they are added to the front of the path.
	 * @param onlyInPaths if this is true then the command on its own
	 * will not be executed - it will only be executed in one of the
	 * provided paths.
	 * @param executed if this is not null and execution is successful
	 * then the executed path is appended to this StringBuffer.
	 * @return a Process representing the running process or null if it
	 * could not be executed in any path.
	 */
	public static Process tryExecCommandLine(String command,String[] paths,boolean onlyInPaths,StringBuffer executed)
	{
		Process p = null;
		String nm = "";
		if (!onlyInPaths) p = tryRun(nm = command);
		for (int i = 0; p == null && paths != null && i<paths.length; i++){
			String s = paths[i];
			if (!s.endsWith("/") && !s.endsWith("\\"))
				s += "/";
			if (command.charAt(0) == '"')
				nm = "\""+s+command.substring(1);
			else
				nm = s+command;
			p = tryRun(nm);
		}
		if (p != null && executed != null) executed.append(nm);
		return p;
	}
	
	/**
	 * Runs a command line with quoted executable. 
	 * It is always safest to place the executable in quotes (") in case it has
	 * spaces in it. This will remove those quotes and place it as a single String
	 * as the first command. If there are quotes in any other arguments, those
	 * other quotes are preserved. The path of the executable is also corrected
	 * to use the correct system directory separators. 
	 * @param commandLine the command line to use, the executable may
	 * be placed in quotes.
	 * @return the Process executed.
	 * @throws IOException if the command line could not be executed.
	 */
	public static Process execCommandLine(String commandLine) throws IOException
	{
		return Runtime.getRuntime().exec(processCommandLine(commandLine)); 
	}
	/**
	 * Split a command line preserving any quoted items as single Strings.
	 * @param args a command list. This will be split using spaces as the
	 * separator. Any text within quotes are preserved, including contained
	 * spaces. The quotes themselves are also preserved.
	 * @param prepend an optional single String to place as the first
	 * element in the array (this will NOT be split). 
	 * @return
	 * @deprecated
	 */
//	===================================================================
	public static String [] splitCommand(String args,String prepend)
//	===================================================================
	{
		Vector v = new Vector();
		if (prepend != null) v.add(prepend);
		if (args != null){
			char [] chars = getStringChars(args);
			int st = 0;
			char quote = 0;
			for (int i = 0; i<chars.length; i++){
				char c = chars[i];
				if (c == '"' || c == '\''){
					if (quote == 0) quote = c;
					else if (quote == c) quote = 0;
					continue;
				}
				if ((c == ' ' || c == '\t') && (quote == 0)) {
					if (st == i) {
						st = i+1;
						continue;
					}else{
						v.add(args.substring(st,i));
						st = i+1;
					}
				}
			}
			if (st != chars.length) v.add(args.substring(st,chars.length));
		}
		String [] ret = new String[v.size()];
		v.copyInto(ret);
		return ret;
	}
	/**
	 * If this Application is running as an Applet in a Web Browser,
	 * then this will return an Object that implements the eve.sys.Applet interface,
	 * otherwise it returns null.
	 */
	public static Applet getApplet()
	{
		return (Applet)getAppletType().invoke(null,"getSysApplet()Leve/sys/Applet;",null);
	}
	private static String toHex(double value)
	{
		return Long.toHexString(Double.doubleToLongBits(value));
	}
	/*
	public static long aLong = 1234;
	public static double aDouble = 567.8901;
	public static final long finalLong = 1234;
	public static final double finalDouble = 567.8901;
	*/
	//private static Type launcher
	public static void eveMain(String[] args)
	{
		boolean testing = args.length != 0 && args[0].equals("-test");
		if (!testing) VMOptions.vmOptions.getLaunchType().invoke(null,"eveMain([Ljava/lang/String;)V",new Object[]{args});
	}
	/**
	 * Get an IRemoteProxyMaker if available. This attempts to create and
	 * return an eve.io.block.RemoteProxy Object if it is included in the library.
	 * @param forInterface the interface the IRemoteProxyMaker will be implementing.
	 * @param iRemoteProxyMakerOptions any of the IRemoteProxyMaker.OPTION_XXX values
	 * ORed together.
	 * @param proxyClassLoader an optional ClassLoader to be used when making the proxy.
	 * @return an IRemoteProxyMaker supporting the specified interface or null
	 * if none is available in the library.
	 */
	public static IRemoteProxyMaker getRemoteProxyMaker(Class forInterface,int iRemoteProxyMakerOptions,ClassLoader proxyClassLoader)
	{
		Type t = new Type("eve.io.block.RemoteProxy");
		if (!t.exists()) return null;
		return (IRemoteProxyMaker)t.newInstance("(Ljava/lang/Class;ILjava/lang/ClassLoader;)", new Object[]{forInterface,new Integer(iRemoteProxyMakerOptions),proxyClassLoader});
	}
	/**
	 * This is used on mobile devices to initiate services on the running
	 * VM.
	 * @param command the command of the service request.
	 * @throws IOException on any error.
	 */
	public static void runServiceCommand(String command) throws IOException
	{
		String got = Registry.readRegistryString(VmServer.location,"ServerName");
		if (got != null){
			Object v = Registry.readRegistryValue(VmServer.location,"ServerPort");
			if (v instanceof Integer){
				int port = ((Integer)v).intValue();
				try{
					Socket s = new Socket(got,port);
					PrintWriter pw = new PrintWriter(s.getOutputStream());
					pw.println(command);
					pw.flush();
					pw.close();
					return;
				}catch(Exception e){
				}
			}
		}
		//
		// Start the server.
		//
		if (!Registry.writeRegistryString(VmServer.location,"ServerCommand",command))
			throw new IOException("No registry access is possible.");
		//
		String comms = Registry.getVmCommandLine("StartEve -servercommand",null);
		Registry.execCommandLine(comms);
	}
	private static String testFile()
	{
		String ret = "";
		try{
			File f = File.getNewFile(File.getProgramDirectory()).getChild("test.txt");
			if (f.exists()) ret += "test.txt existed with size: "+f.getLength()+"\n";
			else ret += "test.txt does not exist.\n";
			FileOutputStream fos = new FileOutputStream(f.toJavaFile(),false);
			fos.write(Utils.encodeJavaUtf8String("writing now: "+new Time().format("HH:mm:ss")));
			fos.close();
			if (f.exists()) ret += "test.txt now exists with size: "+f.getLength()+"\n";
			else ret += "test.txt does not exist.\n";
		}catch(Exception e){
			ret += e.getMessage();
		}
		return ret;
	}
	public static void main(String[] args) 
	{
		boolean serverCommand = args.length != 0 && args[0].equals("-servercommand");
		boolean testing = args.length != 0 && args[0].equals("-test");
		boolean runServer = serverCommand || Device.isMobile();// || true;
		if (runServer) new VmServer().start();
		if (serverCommand){
			String comm = Registry.readRegistryString(VmServer.location,"ServerCommand");
			Registry.setRegistryValue(VmServer.location,"ServerCommand","");
			if (comm != null && comm.length() != 0){
				try{
					runServiceCommand(comm);
				}catch(Throwable t){}
			}
		}
		Type t = testing ? null : VMOptions.vmOptions.getLaunchType();
		//if (t != null) debug("Exists: "+t.exists());
		if (!testing && t.exists()){
			t.invoke(null,"main([Ljava/lang/String;)V",new Object[]{args});
			exit(0);
		}else{
			try{
				int v = getVersion();
				String version = ""+(v%100);
				while (version.length() < 2) version = "0"+version;
				version = (v/100)+"."+version;
				String message = "Eve Virtual Machine - Version "+version+"\nMichael L Brereton, Ewesoft.com\nhttp://www.ewesoft.com/eve";
				if (testing)try{
					message += "\nDefault locale: "+Locale.getDefault()+"\n";
					Time tt = new Time();
					Calendar c = tt.toCalendar(null);
					SimpleDateFormat sdf = new SimpleDateFormat("EEE dd/MMM/yyyy HH:mm:ss Z");
					message += tt.format("EEE dd/MMM/yyyy HH:mm:ss Z\n");
					message += "The time is: "+sdf.format(c)+"\n";
					message += "The time at GMT: "+tt.localToUTC(null, TimeZone.getDefault()).format("EEE dd/MMM/yyyy HH:mm:ss")+"\n";
					//message += "Program dir: "+File.getProgramDirectory()+"\n";
					//message += testFile();
				}catch(Exception e){
					e.printStackTrace();
					mThread.nap(3000);
				}
				boolean doMessageBox = true;
				if (false){
					System.out.println(message);
					System.err.println("This goes to stderr!");
					System.out.println("This goes to stdout!");
					System.out.println("Enter something:");
					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
					String got = br.readLine();
					System.out.println("You entered: "+got);
					doMessageBox = !isJavaVM();
				}
				//
				// There is some kind of bug in Java. When
				// you read from standard input and then try to
				// bring up a message box it fails to appear.
				//
				if (doMessageBox)
					if (Device.tryMessageBox("Eve Virtual Machine",message,false))
						exit(0);
				if (testing) exit(0);
				//else exit(0);
				//System.out.println("Eve Virtual Machine - Version 0.1Beta\nMichael L Brereton, Ewesoft.com\nhttp://www.ewesoft.com");
				/*
				if (args.length > 0 && args[0].equalsIgnoreCase("-test")){
					if ((Device.getGUICapabilities() & Device.GUI_CAN_MESSAGEBOX) != 0){
						int c = Device.messageBox("This is a test message.\nContinue running?","A message",Device.MB_TYPE_YESNO);
						if (c != Device.IDYES) System.exit(0);
					}
					if ((Device.getGUICapabilities() & Device.GUI_CAN_FLASHMESSAGE) != 0){
						Device.flashMessage("Just a quick  test message!",1000);
					}
					Vm.debug("Test values: "+finalLong+" & "+finalDouble+", Should be 1234 & 567.8901");
					try{
						long fl = Vm.class.getField("finalLong").getLong(null);
						double fd = Vm.class.getField("finalDouble").getDouble(null);
						Vm.debug("Test values: "+fl+" & "+fd+", Should be 1234 & 567.8901");
					}catch(Exception e){e.printStackTrace();}
					Vm.debug("Test values: "+aLong+" & "+aDouble+", Should be 1234 & 567.8901");
					int al = (int)aLong;
					float af = (float)aDouble;
					Vm.debug("Test values: "+al+" & "+af+", Should be 1234 & 567.8901 (aprox.)");
					long bits = 0x1234567812345678L;
					double db = Double.longBitsToDouble(bits);
					bits = Double.doubleToRawLongBits(db);
					Vm.debug("Test values: "+Long.toHexString(bits)+" & "+db);
					Vm.debug(toHex(Double.NaN)+", "+toHex(Double.POSITIVE_INFINITY)+", "+toHex(Double.NEGATIVE_INFINITY));
				}
				*/
			}catch(Throwable e){
				e.printStackTrace();
			}
			
			//mThread.nap(3000);
			if (!runServer)
				exit(0);
		}
	}
	/**
	 * Returns if you can install signal handlers on this platform.
	 */
	public static boolean canInstallSignalHandlers()
	{
		return installSignalHandler(null,0);
	}
	private static Thread sigHandlerThread;
	private static Map handlers;
	
	private static void unhandledSignal(int which)
	{
		try{
			System.exit(0);
		}catch(Exception e){}
	}
	/*
	 * This is called from RunMainThread().
	 */
	static void setupSignalHandlers()
	{
		if (isJavaVM()) return;
		if (sigHandlerThread == null){
			//System.out.println("Starting!");
			handlers = new Hashtable();
			signalOperation(SIGNAL_OP_STARTUP, 0);
			sigHandlerThread  = new Thread("Signal Handler"){
				{
					setDaemon(true);
				}
				public void run(){
					while(true){
						int got = signalOperation(SIGNAL_OP_GET,0);
						if (got == 0) break;
						try{
							Object key = toSignalKey(got);
							SignalHandler sh = (SignalHandler)handlers.get(key);
							if (sh == null) unhandledSignal(got);
							else sh.handleSignal(got);
						}catch(IllegalArgumentException e){}
					}
				}
			};
			sigHandlerThread.start();
		}
	}
	private static Object toSignalKey(int which) throws IllegalArgumentException
	{
		switch(which){
		case SignalHandler.SIGINT: 
		case SignalHandler.SIGTERM: 
			break;
		default:
			throw new IllegalArgumentException("Unknown signal: "+which);
		}
		return new Integer(which);
	}
	private static final int SIGNAL_OP_SUPPORTED = 0;
	private static final int SIGNAL_OP_HANDLED = 1;
	private static final int SIGNAL_OP_NOT_HANDLED = 2;
	private static final int SIGNAL_OP_GET = 3;
	private static final int SIGNAL_OP_STARTUP = 4;
	private static native int signalOperation(int op, int signal);
	/**
	 * This is used to install a Signal handler if supported.
	 * @param handler the handler to install.
	 * @param signal the signal to install a handler for. 
	 * @return false if signal handling is not supported. 
	 */
	public static synchronized boolean installSignalHandler(SignalHandler handler,int signal)
	{
		Type ty = getAppletType();
		if (ty.exists()){
			Object got = ty.invoke(null, "installSignalHandler(Leve/sys/SignalHandler;I)Z", new Object[]{handler,new Integer(signal)});
			if (!(got instanceof Boolean)) return false;
			return ((Boolean)got).booleanValue();
		}
		if (signal == 0){
			return signalOperation(SIGNAL_OP_SUPPORTED,0) != 0;
		}
		Object key = toSignalKey(signal);
		setupSignalHandlers();
		//
		if (handler == null) {
			handlers.remove(key);
			signalOperation(SIGNAL_OP_NOT_HANDLED, signal);
		}
		else{
			SignalHandler old = (SignalHandler)handlers.get(key);
			handler.installed(signal, old);
			handlers.put(key, handler);
			signalOperation(SIGNAL_OP_HANDLED, signal);
		}
		return true;
	}
}

