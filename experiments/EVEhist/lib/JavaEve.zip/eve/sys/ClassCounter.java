/*
 * Created on May 1, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.util.Hashtable;

import eve.nativeaccess.NativeAccess;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class ClassCounter {
	private int nativeCounter;
	private native Object nativeOp(int op,Object par1,Object par2);
	private Object nativeOp(int op)
	{
		return nativeOp(op,null,null);
	}
	private static Hashtable counters;
	
	public static synchronized String mark(String name)
	{
		if (counters == null) counters = new Hashtable();
		ClassCounter cc = (ClassCounter)counters.get(name);
		System.gc();
		if (cc == null){
			cc = new ClassCounter();
			counters.put(name,cc);
			return null;
		}
		String ret = cc.getDifferencesToNow();
		cc.countNow();
		return ret;
	}
	public ClassCounter()
	{
		try{
			nativeOp(0);
		}catch(Throwable t){
			
		}
	}
	public void countNow()
	{
		try{
			nativeOp(1);
		}catch(Throwable t){
			
		}
		
	}
	public String getDifferencesToNow()
	{
		try{
			return (String)nativeOp(2);
		}catch(Throwable t){
			return "";
		}
	}
	protected void finalize()
	{
		try{
			NativeAccess.unref(nativeCounter);
			nativeCounter = 0;
		}catch(Throwable t){}
	}
}

//####################################################
