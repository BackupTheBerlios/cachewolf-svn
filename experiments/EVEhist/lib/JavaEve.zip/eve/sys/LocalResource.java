package eve.sys;
/**
* This allows the retrieval of locale specific data if it is installed.
**/
//##################################################################
public interface LocalResource{
//##################################################################

/**
* This should convert the resourceID to a String and then call get(resourceName,defaultValue);
**/
public Object get(int resourceID,Object defaultValue);
/**
* This finds the local resource as given by the resourceName. If it cannot be found the defaultValue will
* be returned.
**/
public Object get(String resourceName,Object defaultValue);

//##################################################################
}
//##################################################################

