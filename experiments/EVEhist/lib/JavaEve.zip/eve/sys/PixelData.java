package eve.sys;
/**
 * This class represents exposed PixelData within some kind of image.
 * It is really just an aggregrate of data indicating the array the
 * pixels are contained in (the pixels member), the offset of the first
 * pixel (the firstPixel member) and the number of int values between
 * scan lines (the rowStride member).<p>
 * This class does not hold information regarding how many pixels or
 * scan lines are actually stored. Thus this class is only meaningful
 * in some larger context.
 */
public class PixelData {
/**
 * The pixels values in ARGB format.
 */
	public int [] pixels;
	/**
	 * The index of the first pixel in the pixels array.
	 */
	public int firstPixel;
	/**
	 * The row stride (ie number of int values between corresponding
	 * pixels in consecutive scan lines. 
	 */
	public int rowStride;
}
