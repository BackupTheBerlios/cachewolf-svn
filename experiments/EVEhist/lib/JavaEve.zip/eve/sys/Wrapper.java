package eve.sys;
import eve.data.DataUnit;
import eve.data.Value;
import eve.util.ByteArray;
import eve.util.CharArray;
import eve.util.LocaleFormatted;
import eve.util.Utils;
import eve.util.mString;

import java.lang.reflect.Field;
import java.text.ParseException;
/*
A Wrapper is a substitute for standard java wrappers in situations where you wish to
avoid excessive creation of Integer, Character or other such wrappers. For example
when reading/writing to a large number of java.lang.reflect.Field objects.
*/
//##################################################################
public class Wrapper extends Number implements DataUnit, DataConverter{ // implements DataConverter,ewe.util.Stringable{
//##################################################################
//	These four are used by the native VM - do not move.
protected int type = NONE;
protected Object objValue;
protected long longValue;
protected double doubleValue;
//{new Exception().printStackTrace();}
public static final int NONE = 0;
public static final int VOID = 'V';
public static final int BYTE = 'B';
public static final int CHAR = 'C';
public static final int SHORT = 'S';
public static final int INT = 'I';
public static final int BOOLEAN = 'Z';
public static final int FLOAT = 'F';
public static final int LONG = 'J'; 
public static final int DOUBLE = 'D'; 
public static final int OBJECT = 'L';
//
// ARRAY value is never set in the Java code
// but it is in some parts of the native code, so better keep it
// just in case.
//
private static final int ARRAY = '[';
//
//public static final int VMREFERENCE = '?';

private static WeakSet cached;

/**
 * Get a re-used Wrapper from a global SoftSet of wrappers.
 * @return a re-used Wrapper or a new Wrapper if there are no cached ones available. 
 * It will have had zero() called on it before
 * being returned.
 */
public static Wrapper getCached()
{
	if (true) return (Wrapper)Cache.get(Wrapper.class);
	Wrapper w = cached == null ? null : (Wrapper)cached.takeRef();
	if (w == null) w = new Wrapper();
	else w.zero();
	return w;
}
/**
 * Cache a Wrapper for re-use.
 * @param used the Wrapper that is no longer in use.
 */
public static synchronized void cache(Wrapper used)
{
	if (true){
		Cache.put(used);
		return;
	}
	if (used == null) return;
	if (cached == null) cached = new WeakSet(true);
	cached.add(used);
}
/**
 * Cache this Wrapper for re-use.
 *
 */
public void cache()
{
	cache(this);
}
//=====================================================
/**
Create a Wrapper with the type set to NONE.
*/
//===================================================================
public Wrapper()
//===================================================================
{
	//Vm.debugStackTrace();
}

/**
 * Clear any stored value in the Wrapper and set the type to NONE.
 * @return this Wrapper
 */
//===================================================================
public Wrapper clear()
//===================================================================
{
	return zero(NONE);
}
/**
Determine the Wrapper type given the type represented by the class.
@param aType the type.
@return the Wrapper type corresponding to the specified type.
*/
//===================================================================
public static int toWrapperType(Class aType)
//===================================================================
{
	return Reflection.getEncodedType(aType);
}
/** This is the String value "Ljava/lang/String;" */
//public static final String stringClass = "Ljava/lang/String;"; 
/** This is the String value "Ljava/lang/Object;" */
//public static final String objectClass = "Ljava/lang/Object;"; 
/** This is the String value "Leve/data/Value;" */
//public static final String valueClass = "Leve/data/Value;";

/** This is a zero length Wrapper array. **/
public static final Wrapper [] noParameter = new Wrapper[0];

//-------------------------------------------------------------------
private Wrapper setType(String typeName)
//-------------------------------------------------------------------
{
	if (typeName == null) return this;
	if (typeName.length() == 0) return this;
	return setType(typeName.charAt(0));
}
//-------------------------------------------------------------------
public Wrapper setType(int type)
//-------------------------------------------------------------------
{
	if (type == '[') type = OBJECT;
	this.type = type;
	if (type != OBJECT && type != ARRAY) objValue = null;
	return this;
}
//-------------------------------------------------------------------
private Wrapper setInteger(int v,int type)
//-------------------------------------------------------------------
{
	longValue = v;
	return setType(type);
}
//-------------------------------------------------------------------
private Wrapper setFloat(float v,int type)
//-------------------------------------------------------------------
{
	doubleValue = v;
	return setType(type);
}
//-------------------------------------------------------------------
private Wrapper setObject(Object obj,int type)
//-------------------------------------------------------------------
{
	objValue = obj;
	return setType(type);
}
//===================================================================
public Wrapper setLong(long v)
//===================================================================
{
	longValue = v;
	return setType(LONG);
}
//===================================================================
public Wrapper setDouble(double d)
//===================================================================
{
	doubleValue = d;
	return setType(DOUBLE);
}

public Wrapper setByte(byte v){return setInteger(v,BYTE);}
public Wrapper setChar(char v) {return setInteger(v,CHAR);}
public Wrapper setShort(short v) {return setInteger(v,SHORT);}
public Wrapper setInt(int v){return setInteger(v,INT);}
public Wrapper setBoolean(boolean v) {return setInteger(v ? 1 : 0,BOOLEAN);}
public Wrapper setFloat(float v) {return setFloat(v,FLOAT);}
public Wrapper setObject(Object v) {return setObject(v,OBJECT);}

//public Wrapper setArray(Object v) {return setObject(v,ARRAY);}
//public native Wrapper setLong();
//public native Wrapper setDouble();
/*
//===================================================================
public Object getCopy()
//===================================================================
{
	Wrapper wr = new Wrapper();
	wr.type = type;
	//wr.value = value;
	wr.objValue = objValue;
	//wr.doubleValue = doubleValue;
	//wr.refValue = refValue;
	wr.longValue = longValue;
	wr.doubleValue = doubleValue;
	return wr;
}
*/
//===================================================================

/**
 * Return the type of the stored data, or NONE if no data has been stored.
 * @return the type of the stored data - one of Wrapper.INT, Wrapper.BYTE, etc.
 */
public int getType() 
{
	return type;
}
/**
 * Returns true if the type is not an Object OR if the Object it is set to is null.
 */
public boolean isNull()
{
	return type != OBJECT || objValue == null;
}
/**
 * Returns true if the type IS an Object AND the Object is of the specified type.
 */
public boolean isInstance(Class c)
{
	if (type != OBJECT) return false;
	return c.isInstance(objValue);
}
//===================================================================
private final static String badError = "Bad data type";
private final static String typeError = badError+" - should be: ";
//===================================================================

/**
Return the int value stored in the Wrapper.
If the type is NONE then 0 will be returned. 
If the type is not INT then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
*/
public int getInt() throws IllegalStateException
{
	if (type == NONE) return 0;
	if (type != INT) throw new IllegalStateException("("+System.identityHashCode(this)+") "+typeError+"int"+" but is: "+(char)type); 
	return (int)longValue;
}
/**
Return the short value stored in the Wrapper.
If the type is NONE then 0 will be returned. 
If the type is not SHORT then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
*/
public short getShort() throws IllegalStateException 
{
	if (type == NONE) return 0;
	if (type != SHORT) throw new IllegalStateException(typeError+"short"); 
	return (short)longValue;
}
/**
Return the char value stored in the Wrapper.
If the type is NONE then 0 will be returned. 
If the type is not CHAR then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
*/
public char getChar() throws IllegalStateException 
{
	if (type == NONE) return 0;
	if (type != CHAR) throw new IllegalStateException(typeError+"char"); 
	return (char)longValue;
}
/**
Return the byte value stored in the Wrapper.
If the type is NONE then 0 will be returned. 
If the type is not BYTE then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
*/
public byte getByte()  throws IllegalStateException
{
	if (type == NONE) return 0;
	if (type != BYTE) throw new IllegalStateException(typeError+"byte"); 
	return (byte)longValue;
}
/**
Return the boolean value stored in the Wrapper.
If the type is NONE then false will be returned. 
If the type is not BOOLEAN then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
*/
public boolean getBoolean()  throws IllegalStateException
{
	if (type == NONE) return false;
	if (type != BOOLEAN) throw new IllegalStateException(typeError+"boolean"); 
	return longValue == 0 ? false:true;
}
/**
Return the float value stored in the Wrapper.
If the type is NONE then 0 will be returned. 
If the type is not FLOAT then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
*/
public float getFloat() 
{
	if (type == NONE) return 0;
	if (type != FLOAT) throw new IllegalStateException(typeError+"float"); 
	return (float)doubleValue;
}
/**
Return the Object/Array stored in the Wrapper. 
If the type is NONE then null will be returned. 
If the type is not OBJECT then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
*/
//===================================================================
public Object getObject() throws IllegalStateException
//===================================================================
{
	if (type == NONE) return null;
	if (type != OBJECT) throw new IllegalStateException(typeError+"Object"); 
	return objValue;
}

//===================================================================
/**
 * Return the object value of the Wrapper only if it is of the specified type.
 * Otherwise return null.
 * @param ofType the type of the Object expected.
 * @return the object value of the Wrapper only if it is of the specified type, otherwise
 * returns null.
 */
public Object getObject(Class ofType)
//===================================================================
{
	if (type != OBJECT || objValue == null) return null;
	if (!ofType.isInstance(objValue)) return null;
	return objValue;
}

/**
 * Return the object value of the Wrapper only if it is of the specified type
 * and if the Wrapper is not null.
 * Otherwise return null.
 * @param source a Wrapper possibly containing an object of the specified type, or
 * possibly null.
 * @param ofType the type of the Object expected.
 * @return the object value of the Wrapper only if it is of the specified type, otherwise
 * returns null.
 */
public static Object getObject(Wrapper source, Class ofType)
{
	if (source == null) return null;
	return source.getObject(ofType);
}
/**
Return the Object stored in the Wrapper only if it is an array.
If the type is NONE then null will be returned. 
If the type is not OBJECT or the actual value is not an array then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
*/
//===================================================================
public Object getArray() throws IllegalStateException
//===================================================================
{
	if (type == NONE) return null;
	if (type != OBJECT) 
		throw new IllegalStateException(typeError+"Array"); 
	if (objValue == null) return objValue;
	if (!objValue.getClass().isArray()) 
		throw new IllegalStateException(typeError+"Array"); 
	return objValue;
}
/**
Return the long value stored in the Wrapper.
If the type is NONE then 0 will be returned. 
If the type is not LONG then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
*/
//===================================================================
public long getLong() throws IllegalStateException
//===================================================================
{	
	if (type == NONE) return 0;
	if (type != LONG) throw new IllegalStateException(typeError+"long"); 
	return longValue;
}
/**
Return the double value stored in the Wrapper.
If the type is NONE then 0 will be returned. 
If the type is not DOUBLE then an IllegalStateException is thrown.
@throws IllegalStateException if the type is incorrect and not NONE.
 */
public double getDouble() throws IllegalStateException
//===================================================================
{
	if (type == NONE) return 0;
	if (type != DOUBLE) throw new IllegalStateException(typeError+"double"); 
	return doubleValue;
}
/**
 * Convert the value stored in the Wrapper to a short as long as it is of type SHORT or BYTE.
 * If the type is NONE then zero is returned.
 * @return the converted value or 0 if the type is NONE.
 * @throws IllegalStateException if the type is not SHORT or BYTE or NONE.
 */
//===================================================================
public short toShort() throws IllegalStateException
//===================================================================
{
	if (type == NONE) return 0;
	if (type == SHORT || type == BYTE) return (short)longValue;
	throw new IllegalStateException(badError);
}
/**
 * Convert the value stored in the Wrapper to an int as long as it is of type 
 * BYTE, CHAR, SHORT or INT.
 * If the type is NONE then zero is returned.
 * @return the converted value or 0 if the type is NONE.
 * @throws IllegalStateException if the type is not BYTE, CHAR, SHORT or INT.
 */
//===================================================================
public int toInt()  throws IllegalStateException
//===================================================================
{
	if (type == NONE) return 0;
	if (type == INT || type == SHORT || type == BYTE || type == CHAR) return (int)longValue;
	throw new IllegalStateException(badError);
}
/**
 * Convert the value stored in the Wrapper to an int as long as it is of type 
 * BYTE, CHAR, SHORT, INT or LONG.
 * If the type is NONE then zero is returned.
 * @return the converted value or 0 if the type is NONE.
 * @throws IllegalStateException if the type is not BYTE, CHAR, SHORT, INT or LONG.
 */
//===================================================================
public long toLong()  throws IllegalStateException
//===================================================================
{
	if (type == NONE) return 0;
	if (type == LONG || type == INT || type == SHORT || type == BYTE || type == CHAR) return longValue;
	throw new IllegalStateException(badError);
}
/**
 * Convert the value stored in the Wrapper to a double as long as it is of type 
 * FLOAT or DOUBLE.
 * If the type is NONE then zero is returned.
 * @return the converted value or 0 if the type is NONE.
 * @throws IllegalStateException if the type is not FLOAT or DOUBLE.
 */
//===================================================================
public double toDouble()  throws IllegalStateException
//===================================================================
{
	if (type == NONE) return 0;
	if (type == DOUBLE || type == FLOAT) return doubleValue;
	throw new IllegalStateException(badError);
}
/**
* Copy all appropriate data from another object.
**/
//===================================================================
public void copyFrom(Object other) 
//===================================================================
{
	if (!(other instanceof Wrapper)) return;
	Wrapper from = (Wrapper)other;
	type = from.type;
	objValue = from.objValue;
	doubleValue = from.doubleValue;
	longValue = from.longValue;
}
/**
Set the type to the specified type and then set the values to zero and return this Wrapper.
@param type The type to set to (e.g. 'C', 'I').
@return this Wrapper.
*/
//===================================================================
public Wrapper zero(int type)
//===================================================================
{
	setType(type);
	objValue = null;
	doubleValue = 0;
	longValue = 0;
	return this;
}
public Wrapper zero(Class type)
{
	return zero(Reflection.getEncodedType(type));
}
/**
Set the values to zero and return this Wrapper without changing the type.
@return this Wrapper.
*/
//===================================================================
public Wrapper zero()
//===================================================================
{
	return zero(type);
}

//===================================================================
public static Object doConvertData(Object sourceData,Class sourceType,Class destType)
//===================================================================
{
	if (sourceType.equals(destType)) return sourceData;
	Wrapper dest = new Wrapper(), source = new Wrapper().fromJavaWrapper(sourceData,sourceType);
	if (!doConvertData(source,sourceType,dest,destType))
		return null;
	return dest.toJavaWrapper();
}

/**
 * The Locale implementation of DataConvert.convertData() calls this method. 
 * @param forLocale
 * @param source
 * @param sourceType
 * @param dest
 * @param destType
 * @return
 */
public static boolean doConvertData(Locale forLocale,Wrapper source,Class sourceType,Wrapper dest,Class destType)
//===================================================================
{
	//if (true) return doConvertData(source,sourceType,dest,destType);
	if (forLocale == null) forLocale = Locale.getDefault();
	Class dc = Double.TYPE, fc = Float.TYPE;
	if (destType == String.class){
		if (sourceType == dc || sourceType == fc){
			dest.setObject(forLocale.format(source.toDouble(),null,0));
			return true;
		}else{
			//new Exception().printStackTrace();
			LocaleFormatted lf = (LocaleFormatted)source.getObject(LocaleFormatted.class);
			if (lf != null){
				dest.setObject(mString.localeFormat(lf, forLocale));
				return true;
			}
		}
	}else if (sourceType == String.class && source.objValue instanceof String){
		String s = (String)source.objValue;
		if (destType == dc || destType == fc){
			double got = 0;
			try{
				got = forLocale.parseDouble(s, null);
			}catch(Exception e){
				got = 0;
			}
			if (destType == dc) dest.setDouble(got);
			else dest.setFloat((float)got);
			return true;
		} else {
			LocaleFormatted lf = (LocaleFormatted)dest.getObject(LocaleFormatted.class);
			if (lf != null)try{
				mString.localeParse(lf, forLocale, s);
				return true;
			}catch(ParseException pe){
				throw new IllegalArgumentException(s);
			}
		}
	}
	return doConvertData(source,sourceType,dest,destType);
}
//===================================================================
public static boolean doConvertData(Wrapper source,Class sourceType,Wrapper dest,Class destType)
//===================================================================
{
	if (!dest.isInstance(destType))
		dest.zero(destType);
	if (sourceType.equals(destType)){
		dest.copyFrom(source);
		return true;
	}
	//......................................................
	// Converting from a string into...
	//......................................................
	if (sourceType.equals(String.class)){
		String str = (String)source.objValue;
		if (destType.isPrimitive())
			dest.fromString(str);
		else if (Value.class.isAssignableFrom(destType)){
			dest.fromString(str);
		}else
			return false;
	//......................................................
	// Converting to a string from
	//......................................................
	}else if (destType.equals(String.class)){
		if (sourceType.isPrimitive())
			dest.setObject(source.toString());
		else if (Value.class.isAssignableFrom(sourceType)){
			dest.setObject(source.toString());
		}else
			return false;
	}else if (destType.isArray() && destType.getComponentType() == Byte.TYPE){
		//ewe.sys.Vm.debug("Source: "+sourceType);
		if (ByteArray.class.isAssignableFrom(sourceType)){
			//FIXME Wrapper.convert byte array!
			//ewe.sys.Vm.debug("Convert byte array to byte!");
		}		
	}
	return true;
}
//===================================================================
public boolean convertData(Wrapper source,Class sourceType,Wrapper dest,Class destType)
//===================================================================
{
	return doConvertData(source,sourceType,dest,destType);
}
public CharArray toString(CharArray dest,Locale locale)
{
	if (locale == null) locale = Locale.getDefault();
	if (dest == null) dest = new CharArray();
	switch(type){
		case INT: case BYTE: case SHORT: 
		case LONG: dest.append(longValue); break;
		case FLOAT:
		case DOUBLE:{
				locale.format(doubleValue,null,dest,0); break;
				//dest.append(doubleValue); break;
		}
		case BOOLEAN: dest.append(longValue == 0 ? "false" : "true"); break;
		case CHAR: dest.append((char)longValue); break;
		default: mString.toString(objValue,dest,locale);
	}
	return dest;
}

public CharArray toString(CharArray dest)
{
	if (dest == null) dest = new CharArray();
	switch(type){
		case INT: case BYTE: case SHORT: 
		case LONG: dest.append(longValue); break;
		case FLOAT:
		case DOUBLE: dest.append(doubleValue); break;
		case BOOLEAN: dest.append(longValue == 0 ? "false" : "true"); break;
		case CHAR: dest.append((char)longValue); break;
		default: mString.toString(objValue,dest);
	}
	return dest;
}
//===================================================================
public String toString()
//===================================================================
{
	switch(type){
		case LONG: return ""+longValue;
		case DOUBLE: return ""+doubleValue;
		case INT: case BYTE: case SHORT: return ""+longValue;
		case BOOLEAN: return longValue == 0 ? "false" : "true";
		case CHAR: return ""+(char)longValue;
		case FLOAT: return ""+doubleValue;
		case ARRAY:
		case OBJECT: return mString.toString(objValue);
		default: return "";
	}
}
//===================================================================
public void fromString(String what)
//===================================================================
{
	if (what == null) return;
	if (what.length() == 0) return;
	switch(type){
		case DOUBLE: doubleValue = Convert.toDouble(what); break;
		case LONG: longValue = Convert.toLong(what); break;
		case INT: case BYTE: case SHORT:  longValue = Convert.toInt(what); break;
		case BOOLEAN: longValue = Convert.toBoolean(what) ? 1 : 0; break;
		case CHAR: longValue = Convert.toChar(what); break;
		case FLOAT: doubleValue = Convert.toFloat(what); break;
		case OBJECT:
			if (objValue instanceof Value){
				((Value)objValue).fromString(what);
			}
	}
}
//===================================================================
public boolean isCompatibleWith(int aType)
//===================================================================
{
	if (aType == type) return true;
	if ((aType == OBJECT || aType == ARRAY) && (type == OBJECT || type == ARRAY))
		return true;
	return aType == type;
}
//===================================================================
public int compareTo(Object other) 
//===================================================================
{
	if (!(other instanceof Wrapper)) return 1;
	Wrapper from = (Wrapper)other;
	int ty = type-from.type;
	if (ty != 0) return ty;
	if (type == NONE) return 0;
	if (type == OBJECT || type == ARRAY)
		return Utils.compare(objValue,from.objValue);
	if (type == FLOAT || type == DOUBLE){
		if (doubleValue < from.doubleValue) return -1;
		else if (doubleValue > from.doubleValue) return 1;
		else return 0;
	}else{
		if (longValue < from.longValue) return -1;
		else if (longValue > from.longValue) return 1;
		else return 0;
	}
}
/**
Convert this Wrapper to a standard java Wrapper such as Integer, Double, etc. Objects and
Arrays are returned as themselves.
@return a standard java Wrapper such as Integer, Double, etc.
@exception IllegalStateException if the Wrapper is not of a valid type.
*/
//===================================================================
public Object toJavaWrapper() throws IllegalStateException
//===================================================================
{
	switch(type){
		case BOOLEAN: return longValue != 0 ? Boolean.TRUE : Boolean.FALSE; 
		case BYTE: return new Byte((byte)longValue); 
		case CHAR: return new Character((char)longValue); 
		case SHORT: return new Short((short)longValue); 
		case INT: return new Integer((int)longValue); 
		case LONG: return new Long(longValue); 
		case FLOAT: return new Float((float)doubleValue); 
		case DOUBLE: return new Double(doubleValue); 
		case ARRAY:
		case OBJECT: return objValue; 
		case VOID: return null;
	}
	throw new IllegalStateException("Invalid Wrapper value.");
}
/**
 * Return a Java wrapper for an Object which may be an Eve Wrapper.
 * @param possibleEveWrapper the object that may be an Eve Wrapper.
 * @return a Java wrapper for the Object.
 * @throws IllegalStateException if it is an Eve wrapper but its state is unknown.
 */
public static Object toJavaWrapper(Object possibleEveWrapper) throws IllegalStateException
{
	if (possibleEveWrapper instanceof Wrapper) return ((Wrapper)possibleEveWrapper).toJavaWrapper();
	else return possibleEveWrapper;
}
private static Class[] javaWrapperClasses;
private static int[] myTypes;

/**
 * Given a Java Wrapper object (like Integer, Short, etc.) return the Wrapper type (e.g 
 * INTEGER, SHORT, etc.) of the wrapper. If the parameter is not a Java Wrapper, but any
 * other Object, then the value OBJECT is returned. If the parameter is null, NONE is
 * returned.
 */
public static int getWrapperType(Object javaWrapper)
{
	if (javaWrapper == null) return NONE;
	if (javaWrapperClasses == null) synchronized(Wrapper.class){
		if (javaWrapperClasses == null){
			javaWrapperClasses 
				= new Class[]{Boolean.class, Byte.class,Character.class,Short.class,Integer.class,Long.class,Float.class,Double.class};
			myTypes 
				= new int[]{BOOLEAN,BYTE,CHAR,SHORT,INT,LONG,FLOAT,DOUBLE};
		}
	}
	Class c = javaWrapper.getClass();
	for (int i = 0; i<javaWrapperClasses.length; i++)
		if (c == javaWrapperClasses[i]) return myTypes[i];
	return OBJECT;
}

public Wrapper fromJavaWrapper(Object javaWrapper)
{
	return fromJavaWrapper(javaWrapper,null);
}
/**
Set this Wrapper value from the specified standard Java Wrapper. If the parameter
is not a Java Wrapper then it will be treated like an ordinary object.
@return itself
*/
//===================================================================
public Wrapper fromJavaWrapper(Object javaWrapper,Class destinationType)
//===================================================================
{
	if (destinationType != null){
		if (destinationType.equals(Void.TYPE)) return zero(VOID);
		if (!destinationType.isPrimitive())
			return setObject(javaWrapper);
	}
	switch(getWrapperType(javaWrapper)){
	case BOOLEAN: return setBoolean(((Boolean)javaWrapper).booleanValue());
	case BYTE: return setByte(((Byte)javaWrapper).byteValue());
	case CHAR: return setChar(((Character)javaWrapper).charValue());
	case SHORT: return setShort(((Short)javaWrapper).shortValue());
	case INT: return setInt(((Integer)javaWrapper).intValue());
	case LONG: return setLong(((Long)javaWrapper).longValue());
	case FLOAT: return setFloat(((Float)javaWrapper).floatValue());
	case DOUBLE: return  setDouble(((Double)javaWrapper).doubleValue());
	default: return setObject(javaWrapper);
	}
}
/**
Put the value stored in this Wrapper in the specified field in the specified object.
@param f The field to store the data in.
@param dest The destination object.
@return true if successful, false if not successful for any reason.
*/
//===================================================================
public boolean putInField(Field f,Object dest)
//===================================================================
{
	try{
		switch(type){
			case BOOLEAN: f.setBoolean(dest,longValue != 0); return true;
			case BYTE: f.setByte(dest,(byte)longValue); return true;
			case CHAR: f.setChar(dest,(char)longValue); return true;
			case SHORT: f.setShort(dest,(short)longValue); return true;
			case INT: f.setInt(dest,(int)longValue); return true;
			case LONG: f.setLong(dest,longValue); return true;
			case FLOAT: f.setFloat(dest,(float)doubleValue); return true;
			case DOUBLE: f.setDouble(dest,doubleValue); return true;
			case ARRAY:
			case OBJECT: f.set(dest,objValue); return true;
			default: 
				return false;
		}
	}catch(Exception e){
		return false;
	}
}
/**
Get the value stored in the field f in the object source into this Wrapper.
@param f The field to get the data from.
@param source The source object.
@return true if successful, false if not successful for any reason.
*/
//===================================================================
public boolean getFromField(Field f,Object source)
//===================================================================
{
	zero(NONE);
	try{
		switch(toWrapperType(f.getType())){
			case BOOLEAN: setBoolean(f.getBoolean(source)); return true;
			case BYTE: setByte(f.getByte(source)); return true;
			case CHAR: setChar(f.getChar(source)); return true;
			case SHORT: setShort(f.getShort(source)); return true;
			case INT: setInt(f.getInt(source)); return true;
			case LONG: setLong(f.getLong(source)); return true;
			case FLOAT: setFloat(f.getFloat(source)); return true;
			case DOUBLE: setDouble(f.getDouble(source)); return true;
			case ARRAY:
			case OBJECT: setObject(f.get(source)); return true;
			default:
				return false;
		}
	}catch(Exception e){
		return false;
	}
}

//private static boolean hasNative = true;
//private static native boolean nativeIsJavaWrapper(Object obj);

/**
Returns if the specified object is a standard Java primitive data wrapper (e.g. Boolean, Integer, etc.)
*/
//===================================================================
public static boolean isJavaWrapper(Object obj)
//===================================================================
{
	int type = getWrapperType(obj);
	return (type != NONE && type != OBJECT);
}
/**
 * Widen a Java wrapper object to a specified primitive type. For example a Short wrapper
 * will be widened to an Integer if the type class represents the primitive int type.
 * @param value The Java wrapper object to widen.
 * @param type the target primitive Java type.
 * @return possibly a new Java wrapper object with the same value.
 * @exception IllegalArgumentException if the value is incompatible with the type.
 */
//===================================================================
public static Object widenJavaWrapper(Object value,Class type) throws IllegalArgumentException
//===================================================================
{
	boolean t = false;
	if (!type.isPrimitive()) return value;
	else if (value == null) t = true;
	else if (type == Boolean.TYPE){
		if (!(value instanceof Boolean)) t = true;
	}else if (type == Character.TYPE){
		if (!(value instanceof Character)) t = true;
	}else if (type == Byte.TYPE){
		if (!(value instanceof Byte)) t = true;
	}else if (type == Short.TYPE){
		if (value instanceof Byte) value = new Short(((Byte)value).shortValue());
		else if (!(value instanceof Short)) t = true;
	}else if (type == Integer.TYPE){
		if (value instanceof Byte) value = new Integer(((Byte)value).intValue());
		else if (value instanceof Short) value = new Integer(((Short)value).intValue());
		else if (value instanceof Character) value = new Integer(((Character)value).charValue());
		else if (!(value instanceof Integer)) t = true;
	}else if (type == Long.TYPE){
		if (value instanceof Byte) value = new Long(((Byte)value).longValue());
		else if (value instanceof Short) value = new Long(((Short)value).longValue());
		else if (value instanceof Character) value = new Long(((Character)value).charValue());
		else if (value instanceof Integer) value = new Long(((Integer)value).longValue());
		else if (!(value instanceof Long)) t = true;
	}else if (type == Float.TYPE){
		if (value instanceof Byte) value = new Float(((Byte)value).floatValue());
		else if (value instanceof Short) value = new Float(((Short)value).floatValue());
		else if (value instanceof Character) value = new Float(((Character)value).charValue());
		else if (value instanceof Integer) value = new Float(((Integer)value).floatValue());
		else if (value instanceof Long) value = new Float(((Long)value).floatValue());
		else if (!(value instanceof Float)) t = true;
	}else if (type == Double.TYPE){
		if (value instanceof Byte) value = new Double(((Byte)value).doubleValue());
		else if (value instanceof Short) value = new Double(((Short)value).doubleValue());
		else if (value instanceof Character) value = new Double(((Character)value).charValue());
		else if (value instanceof Integer) value = new Double(((Integer)value).doubleValue());
		else if (value instanceof Long) value = new Double(((Long)value).doubleValue());
		else if (value instanceof Float) value = new Double(((Float)value).doubleValue());
		else if (!(value instanceof Double)) t = true;
	}
	if (t) throw new IllegalArgumentException();
	return value;
}
/**
 * Convert an array of Eve Wrappers to an array of standard Java wrapper Objects.
 * @param wrappers the array of Eve Wrappers.
 * @return an array of Java wrapper objects.
 */
//===================================================================
public static Object [] toJavaWrappers(Wrapper [] wrappers)
//===================================================================
{
	Object [] j = new Object[wrappers.length];
	for (int i = 0; i<j.length; i++)
		j[i] = wrappers[i].toJavaWrapper();
	return j;
}
/**
 * @deprecated - use toEveWrapper(Object possibleJavaWrapper,Class javaType)
 * Convert an Object to an Eve Wrapper.
 * @param possibleJavaWrapper if this is already an Eve Wrapper it will be
 * returned. If it is a Java Wrapper it will be converted to an Eve Wrapper and
 * returned. If it is neither a new Eve Wrapper will be created and have setObject(null)
 * called on it and then returned.
 * @return a Wrapper representing the data.
 */
public static Wrapper toEveWrapper(Object possibleJavaWrapper)
{
	return toEveWrapper(possibleJavaWrapper,null);
}
/**
 * Convert an Object to an Eve Wrapper.
 * @param possibleJavaWrapper if this is already an Eve Wrapper it will be
 * returned. If it is a Java Wrapper it will be converted to an Eve Wrapper and
 * returned. If it is neither a new Eve Wrapper will be created and have setObject(null)
 * called on it and then returned.
 * @param javaType the Java type represented by the possible wrapper - this can
 * be null indicating that the Java type is not known.
 * @return a Wrapper representing the data.
 */
public static Wrapper toEveWrapper(Object possibleJavaWrapper,Class javaType)
{
	if (possibleJavaWrapper instanceof Wrapper) return (Wrapper)possibleJavaWrapper;
	else if (possibleJavaWrapper == null) return new Wrapper().setObject(null);
	else return new Wrapper().fromJavaWrapper(possibleJavaWrapper,javaType);
}
/**
 * @deprecated - use toEveWrappers(Object[] javaWrappers,Class[] types) instead.
 * @param javaWrappers
 * @return
 */
public static Wrapper [] toEveWrappers(Object [] javaWrappers)
//===================================================================
{
	return toEveWrappers(javaWrappers,null);
}
/**
 * Convert an array of standard Java wrapper objects to an array of Eve Wrappers.
 * @param javaWrappers the array of Java wrapper objects.
 * @param types an array of types for each Java Wrapper.
 * @return an array of Eve Wrappers.
 */
//===================================================================
public static Wrapper [] toEveWrappers(Object [] javaWrappers,Class [] types)
//===================================================================
{
	if (javaWrappers instanceof Wrapper[]) return (Wrapper[])javaWrappers;
	Wrapper [] w = new Wrapper[javaWrappers.length];
	for (int i = 0; i<w.length; i++){
		w[i] = new Wrapper();
		w[i].fromJavaWrapper(javaWrappers[i],types == null ? null : types[i]);
	}
	return w;
}
/**
 * Return a Class representing the type of the currently stored data. If the
 * stored data is an Object it will call getClass() on the stored object.
 */
public Class getDataClass()
{
	switch(type){
		case BOOLEAN: return Boolean.TYPE;
		case BYTE: return Byte.TYPE;
		case CHAR: return Character.TYPE;
		case SHORT: return Short.TYPE;
		case INT: return Integer.TYPE;
		case LONG: return Long.TYPE;
		case FLOAT: return Float.TYPE;
		case DOUBLE: return Double.TYPE;
		case ARRAY:
		case OBJECT: return objValue == null ? null : objValue.getClass();
		default:
			return null;
	}
}
//===================================================================
public Object getCopy()
//===================================================================
{
	Wrapper wr = new Wrapper();
	wr.copyFrom(this);
	return wr;
}
/*
public static void main(String args[]) throws Exception
{
	final Tag t = new Tag(), t2 = new Tag();
	final Field f = t.getClass().getField("tag");
	for (int i = 0; i<10; i++){
		synchronized(t){
			int now = Vm.countObjects(false);
			Reflection.copy(t,t2);
			f.setInt(t,123);
			now = Vm.countObjects(false)-now;
			if (now != 0) System.out.println("Change: "+now);
			else System.out.println("0");
		}
		mThread.nap(1000);
	}
}
*/
//##################################################################
/* (non-Javadoc)
 * @see java.lang.Number#intValue()
 */
public int intValue() {
	return (int)longValue();
}
/* (non-Javadoc)
 * @see java.lang.Number#longValue()
 */
public long longValue() {
	switch(type){
	case INT:
	case SHORT:
	case BYTE:
	case LONG:
	case CHAR:
		return longValue;
	case DOUBLE:
	case FLOAT:
		return (long)doubleValue;
	default:
		return 0;
}
}
/* (non-Javadoc)
 * @see java.lang.Number#floatValue()
 */
public float floatValue() {
	return (float)doubleValue();
}
/* (non-Javadoc)
 * @see java.lang.Number#doubleValue()
 */
public double doubleValue() {
	switch(type){
	case INT:
	case SHORT:
	case BYTE:
	case LONG:
	case CHAR:
		return (double)longValue;
	case DOUBLE:
	case FLOAT:
		return doubleValue;
	default:
		return 0;
	}
}
public boolean booleanValue() {
	if (type == BOOLEAN) return longValue != 0;
	return false;
}
/* (non-Javadoc)
 * @see eve.data.DataUnit#getNew()
 */
public Object getNew() {
	// TODO Auto-generated method stub
	return new Wrapper();
}
public void cached()
{
	zero(NONE);
}
}
//##################################################################


