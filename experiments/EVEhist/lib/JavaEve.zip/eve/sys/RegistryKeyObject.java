/*
 * Created on Mar 1, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.util.Vector;
import java.util.WeakHashMap;

import eve.util.Comparer;
import eve.util.Utils;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class RegistryKeyObject implements IRegistryKey {

	protected String name = "";
	protected String path = "";
	protected RegistryKeyObject root;
	private WeakHashMap keys = null;
	private Object[] subKeys = null;
	/**
	 * This is used to create a root key only.
	 * @param name the display name for the Root key. Its path
	 * will always be an empty String.
	 */
	public RegistryKeyObject(String name)
	{
		this(name,"",null);
	}
	
	protected RegistryKeyObject(String name, String fullPath, RegistryKeyObject root)
	{
		if (fullPath == null) fullPath = "";
		if (name == null){
			int idx = fullPath.lastIndexOf('\\');
			if (idx != -1) name = fullPath.substring(idx+1);
			else name = fullPath;
		}
		this.name = name;
		this.path = fullPath;
		this.root = root;
		if (root == null) keys = new WeakHashMap();
	}
	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getRootKey()
	 */
	public IRegistryKey getRootKey() {
		if (root == null) return this;
		else return root;
	}
	
	protected final IRegistryKey getOrCreate(String fullPath)
	{
		WeakHashMap wm = root == null ? keys : root.keys; 
		synchronized(wm){
			Object got = wm.get(fullPath);
			if (got != null) return (IRegistryKey)got;
			IRegistryKey r = getNew(null,fullPath,root == null ? this : root);
			wm.put(fullPath,r);
			return r;
		}
	}
	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getSubKey(java.lang.String)
	 */
	public IRegistryKey getSubKey(String subkeyPath) {
		if (root != null) subkeyPath = path+"\\"+subkeyPath;
		return getOrCreate(subkeyPath);
	}
	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#createKey(boolean)
	 */
	public boolean createKey(boolean createFullPath) {
		if (keyExists()) return true;
		Vector v = new Vector();
		for (IRegistryKey rk = this; rk != null; rk = rk.getParentKey()){
			if (rk.keyExists()) break;
			v.add(rk);
		}
		int num = v.size();
		if (!createFullPath && num > 1) return false;
		for (int i = v.size()-1; i >= 0; i--){
			RegistryKeyObject rk = (RegistryKeyObject)v.get(i);
			if (!createKey(rk.getFullKeyPath())) return false;
			rk.clearKeyNames();
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getFullKeyPath()
	 */
	public String getFullKeyPath() {
		return path;
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getKeyName()
	 */
	public String getKeyName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getParentKey()
	 */
	public IRegistryKey getParentKey() {
		if (root == null) return null;
		int idx = path.lastIndexOf('\\');
		if (idx == -1) return root;
		else return getOrCreate(path.substring(0,idx));
	}


	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#deleteKey()
	 */
	public final boolean deleteKey() {
		if (root == null) return false;
		synchronized(keys){
			if (!doDelete()) return false;
			RegistryKeyObject got = (RegistryKeyObject)getParentKey();
			got.clearKeyNames();
			return true;
		}
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getSubKey(int)
	 */
	public String getSubKey(int index) throws IndexOutOfBoundsException {
		synchronized(this){
			Object[] got = getSubkeys();
			return ((String[])got[0])[index];
		}
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getSubKeyCount()
	 */
	public int getSubKeyCount() {
		synchronized(this){
			Object[] got = getSubkeys();
			return ((String[])got[0]).length;
		}
	}


	protected final boolean amRoot()
	{
		return root == null;
	}
	
protected final String [] emptyValuesList = {};
private static Comparer sensitive, insensitive;

	private synchronized Object[] getSubkeys()
	{
		synchronized(RegistryKeyObject.class){
			if (sensitive == null){
				Locale loc = Locale.getDefault(); 
				insensitive = loc.getStringComparer(Locale.IGNORE_CASE);
				sensitive = loc.getStringComparer(0);
			}
		}
		synchronized(this){
			if (subKeys == null) {
				String[] got = getUnsortedKeyNames();
				if (got == null) got = new String[0];
				subKeys = new Object[2];
				Utils.sort(got,insensitive,false);
				subKeys[0] = got;
				subKeys[1] = Utils.sortIndexes(null,got,sensitive,false);
			}
			return subKeys;
		}
	}
	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getSubKeys(int)
	 */
	public Object getSubKeys(int options) {
		synchronized(this){
			Object[] both = getSubkeys();
			String[] all = (String[])both[0];
			if ((options & SORT_CASE_SENSITIVE) != 0){
				System.out.println("Sensitive!");
				String[] ss = new String[all.length];
				int[] si = (int[])both[1];
				for (int i = 0; i<si.length; i++)
					ss[i] = all[si[i]];
				all = ss;
			}
			if ((options & (GET_INDEXES_AS_LONGS|GET_INDEXES)) != 0){
				int [] ret = new int[all.length];
				if ((options & SORT_DESCENDING) == 0)
					Utils.getIntSequence(ret,0);
				else
					Utils.getIntSequence(ret,0,ret.length-1,-1,ret.length);
				if ((options & GET_INDEXES_AS_LONGS) != 0){
					long[] r2 = new long[ret.length];
					for (int i = 0; i<r2.length; i++)
						r2[i] = ret[i];
					return r2;
				}
				return ret;
			}else
				return all.clone();
		}
	}
	
	
/*
 * ----------------------------------------- 
 * Override from here.
 * ----------------------------------------- 
 */
	
	
	/**
	 * Override this to create the data that represents a key.
	 * @param fullPath the full path of the key.
	 * @return true if it could be created, false if not.
	 */
	protected boolean createKey(String fullPath)
	{
		return false;
	}
	
	protected String[] getUnsortedKeyNames()
	{
		return emptyValuesList;
	}
	/**
	 * Used to clear key names if keys have been changed.
	 */
	protected final synchronized void clearKeyNames()
	{
		subKeys = null;
	}
	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#setExpandingString(java.lang.String, java.lang.String)
	 */
	public boolean setExpandingString(String name, String value) {
		return false;
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#setValue(java.lang.String, java.lang.String)
	 */
	public boolean setValue(String name, String value) {
		return false;
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#setValue(java.lang.String, byte[])
	 */
	public boolean setValue(String name, byte[] value) {
		return false;
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#setValue(java.lang.String, int)
	 */
	public boolean setValue(String name, int value) {
		return false;
	}
	/**
	 * You must override this method.
	 * @param name the name to display. If this is null the displayed name
	 * defaults to the last section of the path.
	 * @param fullPath the full path but not starting with a leading '\'
	 * @param root the root for the key.
	 * @return a new RegistryKeyObject.
	 */
	protected RegistryKeyObject getNew(String name, String fullPath, RegistryKeyObject root)
	{
		return new RegistryKeyObject(name,fullPath,root);
	}
	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getValue(java.lang.String)
	 */
	public Object getValue(String valueName) {
		return null;
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getValue(int, java.lang.StringBuffer)
	 */
	public Object getValue(int index, StringBuffer valueName)
			throws IndexOutOfBoundsException {
		throw new IndexOutOfBoundsException();
	}

	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#deleteValue(java.lang.String)
	 */
	public boolean deleteValue(String name) {
		return false;
	}
	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#getValueCount()
	 */
	public int getValueCount() {
		return 0;
	}
	/* (non-Javadoc)
	 * @see eve.sys.IRegistryKey#keyExists()
	 */
	public boolean keyExists() {
		if (root == null) return true;
		return false;
	}
	protected boolean doDelete()
	{
		return false;
	};

}

//####################################################
