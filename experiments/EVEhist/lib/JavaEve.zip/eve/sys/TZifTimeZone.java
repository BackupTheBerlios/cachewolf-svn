package eve.sys;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import eve.data.Property;
import eve.io.File;
import eve.io.StreamUtils;
import eve.util.ByteArray;
import eve.util.Utils;
/**
 * This class implements a TimeZone from a Linux TZif formatted timezone
 * file.
 */
public class TZifTimeZone extends TimeZone{
	
	private Property defaultLocalTime;
	private long [] switches;
	private Property [] switchTo;
	private long rawOffset = 0;
	private long dstChange = 0;
	private boolean usesDaylight = false;
	private String myName;
	
	  public String getDisplayName(boolean dst, int style, Locale locale)
	  {
		 String gmt = super.getDisplayName(dst,style,locale);
		 if (style != LONG || myName == null) return gmt;
		 return myName+", "+gmt;
	  }	
	/**
	 * A convenience method to create a TZifTimeZone from a File source.
	 * @param fullName the full name for the TZifTimeZone (e.g. "America/Port_Of_Spain") this may be null
	 * if it is not known.
	 * @param src the source file.
	 * @return a TZifTimeZone if the file is of the proper format.
	 * @throws IOException if there was an error reading from the file.
	 * @throws IllegalArgumentException if the file was not of the proper format.
	 */
	public static TZifTimeZone fromFile(String fullName, File src) throws IOException, IllegalArgumentException
	{
	  InputStream in = src.toReadableStream();
	  ByteArray ba = StreamUtils.readAllBytes(null,in, null);
	  in.close();
	  return new TZifTimeZone(fullName,ba.data, 0, ba.length);
	}
	/**
	 * Create a TZifTimeZone from the bytes of a TZif file.
	 * @param src the data bytes.
	 * @param offset the start of the data bytes.
	 * @param length the number of data bytes.
	 * @throws IllegalArgumentException if the data bytes are not a TZif
	 * formatted file.
	 */
	  public TZifTimeZone(String fullName,byte[] src, int offset, int length) throws IllegalArgumentException 
	  {
		  this.myName = fullName;
		try{
			if ((src[offset] != (byte)'T')||(src[offset+1] != (byte)'Z')||(src[offset+2] != (byte)'i')||(src[offset+3] != (byte)'f'))
				throw new IllegalArgumentException();
			int off = 20+offset;
			int ttisgmtcnt = Utils.readInt(src, off, 4); off+=4;
			int ttisstdcnt = Utils.readInt(src, off, 4); off+=4;
			int leapcnt = Utils.readInt(src, off, 4); off+=4;
			int timecnt = Utils.readInt(src, off, 4); off+=4;
			int typecnt = Utils.readInt(src, off, 4); off+=4;
			int charcnt = Utils.readInt(src, off, 4); off+=4;
			switches = new long[timecnt];
			for (int i = 0; i<timecnt; i++){
				switches[i] = (long)Utils.readInt(src,off,4);// & 0x00000000ffffffffL;
				off += 4;
				switches[i] *= 1000; //Convert from seconds to milliseconds.
				Time t = new Time();
				t.setTime(switches[i]);
				//System.out.println("Switch: "+t.format("dd/MMM/yyyy HH:mm:ss"));
			}
			int [] switchIndexes = new int[timecnt];
			for (int i = 0; i<timecnt; i++){
				switchIndexes[i] = (int)src[off++] & 0xff;
			}
			//
			Property [] locals = new Property[typecnt];
			// Each of these is six bytes.
			int stringsOffset = off + 6*typecnt;
			for (int i = 0; i<typecnt; i++){
				int [] val = new int[2];
				val[0] = Utils.readInt(src, off, 4); off += 4;
				val[1] = (int)src[off++] & 0xff;
				int nidx = (int)src[off++] & 0xff;
				int strlen = 0;
				for (int ii = stringsOffset+nidx; src[ii] != 0; ii++)
					strlen++;
				Property p = new Property();
				p.name = Utils.decodeJavaUtf8String(src, stringsOffset+nidx, strlen);
				p.value = val;
				locals[i] = p;
				if (i == 0) defaultLocalTime = p;
				if (val[1] != 0) usesDaylight = true;
			}
			//
			long fullDstOffset = 0;
			boolean rawOffsetSet = false, dstOffsetSet = false;
			switchTo = new Property[switchIndexes.length];
			for (int i = 0; i<switchIndexes.length; i++){
				Property p = switchTo[i] = locals[switchIndexes[i]];
				int[] v = (int[])p.value;
				boolean isDST = v[1] != 0;
				long millis = (long)v[0]*1000;
				if (isDST){
					fullDstOffset = millis;
					dstOffsetSet = true;
				}else{
					rawOffset = millis;
					rawOffsetSet = true;
				}
				if (rawOffsetSet && dstOffsetSet)
					dstChange = fullDstOffset-rawOffset;
			}
			//if (dstChange != 0)
			
			//
			//System.out.println("Raw offset: "+rawOffset+", "+dstChange);
		}catch(Exception e){
			throw new IllegalArgumentException();
		}
	  }

	private static Time getOffsetTime;
	
	private Property getForTime(long when)
	{
		Property p = defaultLocalTime;
		for (int i = 0; i<switches.length; i++){
			if (when >= switches[i])
				p = switchTo[i];
			else
				break;
		}
		return p;
	}
	
	public int getOffset(int era, int year, int month, int day, int dayOfWeek,
			int milliseconds) {
		long when = 0;
		synchronized(TZifTimeZone.class){
			if (getOffsetTime == null)
				getOffsetTime = new Time();
			getOffsetTime.year = year;
			getOffsetTime.month = month+1;
			getOffsetTime.day = day;
			getOffsetTime.hour = getOffsetTime.minute = getOffsetTime.second = getOffsetTime.millis = 0;
			getOffsetTime.isValid();
			when = getOffsetTime.getTime()+milliseconds;
		}
		Property p = getForTime(when);
		int[] v = (int[])p.value;
		return v[0]*1000;
	}

	public int getRawOffset() {
		return (int)rawOffset;
	}

	public boolean inDaylightTime(Date date) {
		long when = date.getTime();
		Property p = getForTime(when);
		int[] v = (int[])p.value;
		return v[1] != 0;
	}
	/**
	 * This does nothing - the raw offset is decoded from the file.
	 */
	public void setRawOffset(int offsetMillis) {
	}
	/**
	 * Return the most up-to-date Daylight Savings Time change in 
	 * milliseconds.
	 */
  public int getDSTSavings ()
  {
    return (int)dstChange;
  }
/**
 * Returns if this TimeZone uses daylight savings.
 */
	public boolean useDaylightTime() {
		return dstChange != 0;
	}
	
	/*
	static class offset {
		long value;
		String name;
		public int hashCode(){
			return ((int)value >> 1)*name.hashCode();
		}
		public boolean equals(Object other)
		{
			return 
			((offset)other).value == value &&
			((offset)other).name.equals(name);
		}
		public offset(int off, boolean isDST, String name)
		{
			value = off;
			if (isDST) value |= 0x0000000100000000L;
			this.name = name;
		}
	}
	static class countData {
		int txRes = 60;
		int lowest = 12*60*60;
		int highest = -12*60*60;
		int numTransitions;
		int numOffsets;
		int nameTableSize;
		int nameTableCount;
		int bigDiff = 0;
		Hashtable names = new Hashtable(); 
		Vector abb = new Vector();
		Vector offsets = new Vector();
	}
	public static void countTransitions(countData data,byte[] src, int offset, int length,String fullName)
	{
		if ((src[offset] != (byte)'T')||(src[offset+1] != (byte)'Z')||(src[offset+2] != (byte)'i')||(src[offset+3] != (byte)'f'))
			return;
		int off = 20+offset;
		int ttisgmtcnt = Utils.readInt(src, off, 4); off+=4;
		int ttisstdcnt = Utils.readInt(src, off, 4); off+=4;
		int leapcnt = Utils.readInt(src, off, 4); off+=4;
		int timecnt = Utils.readInt(src, off, 4); off+=4;
		int typecnt = Utils.readInt(src, off, 4); off+=4;
		int charcnt = Utils.readInt(src, off, 4); off+=4;
		data.numTransitions += timecnt;
		data.nameTableSize += fullName.length()+1+4;
		data.nameTableCount++;
		//
		// Check transitions
		//
		for (int i = 0; i<timecnt; i++){
			int tx = Utils.readInt(src,off,4);// & 0x00000000ffffffffL;
			off += 4;
		}
		// Jump over indexes to offsets.
		off += timecnt;
		//
		int stringsOffset = off + 6*typecnt;
		int rawOffset = 0;
		boolean rawOffsetSet = false;
		int here = off;
		for (int i = 0; i<typecnt; i++){
			int toff = Utils.readInt(src, off, 4); off += 4;
			boolean isDst = src[off++] != 0; 
			int nidx = (int)src[off++] & 0xff;
			int strlen = 0;
			for (int ii = stringsOffset+nidx; src[ii] != 0; ii++)
				strlen++;
			String name = Utils.decodeJavaUtf8String(src, stringsOffset+nidx, strlen);
			offset got = new offset(toff,isDst,name);
			if (!data.abb.contains(name))data.abb.add(name);
			if (toff > data.highest) data.highest = toff;
			if (toff < data.lowest) data.lowest = toff;
			if (!isDst) {
				rawOffset = toff;
				rawOffsetSet = true;
			}
			if (!data.offsets.contains(got))
				data.offsets.add(got);
		}
		if (!rawOffsetSet) {
			System.out.println("Raw offset not set: "+fullName);
		}
		off = here;
		for (int i = 0; i<typecnt; i++){
			int toff = Utils.readInt(src, off, 4); off += 4;
			boolean isDst = src[off++] != 0; 
			int nidx = (int)src[off++] & 0xff;
			int fromRaw = rawOffset-toff;
			if (fromRaw < -131072 || fromRaw > 131071){
				System.out.println(fullName+": "+fromRaw);
			}
		}
		data.numOffsets += typecnt;
		
	}
	public static void countTransitions(countData data,File src,ByteArray ba,String fullName)
	{
		try{
		  InputStream in = src.toReadableStream();
		  ba.clear();
		  StreamUtils.readAllBytes(null,in, ba);
		  in.close();
		  countTransitions(data, ba.data,0,ba.length,fullName);
		}catch(Exception e){
			
		}
	}
	
	private static String[] ignoreDirs = mString.split("posix,right,SystemV",',');
	
	public static void countTransitions(countData data,ByteArray ba,File dir,String src)
	{
		if (ba == null) ba = new ByteArray();
		if (src == null) src = "";
		if (src.length() != 0 && !src.endsWith("/"))
			src = src+"/";
		File f = dir.getCopy();
		String[] all = dir.list();
		for (int i = 0; i<all.length; i++){
			String nm = src+all[i];
			boolean ignore = false;
			for (int ig = 0; !ignore && ig<ignoreDirs.length; ig++)
				ignore = ignoreDirs[ig].equalsIgnoreCase(nm);
			if (ignore) continue;
			f.set(dir, all[i]);
			if (f.isDirectory()){
				countTransitions(data, ba, f, nm);
			}else{
				//System.out.println(nm);
				countTransitions(data,f,ba,nm);
			}
		}
	}
	public static countData countTransitions(File dir)
	{
		countData cd = new countData();
		countTransitions(cd,null,dir,null);
		return cd;
	}
	

	private static String testTZ(TimeZone tz)
	{
		return tz.useDaylightTime()+", "+tz.getRawOffset()+", "+tz.getDSTSavings();
	}
	public static void main(String[] args)
	{
		Vm.startEve(args);
		if (true){
			countData cd = countTransitions(new File("e:\\zoneinfo"));
			System.out.println("Transitions: "+cd.numTransitions);
			System.out.println("Name table: "+cd.nameTableCount+" = "+cd.nameTableSize+", "+cd.abb.size());
			System.out.println("Offset table: "+cd.offsets.size()+" from "+cd.numOffsets);
			System.out.println("Lowest: "+cd.lowest+", Highest: "+cd.highest);
			System.out.println("BigDiff: "+cd.bigDiff);
			Vm.exit(0);
		}
		TimeZone gmt = TimeZone.getTimeZone("GMT");
		TimeZone tz = TimeZone.getTimeZone(args[0]);
		if (tz == gmt)
			System.out.println("None exists in Java.");
		else try{
			TimeZone tzif = fromFile(new File("e:\\zoneinfo").getChild(args[0]));
			System.out.println(testTZ(tz));
			System.out.println(testTZ(tzif));
			long lg = new Time(1,1,2008).getTime();
			long end = lg + 366*24*60*60*1000; 
			long inc = 60*1000;
			Date dt = new Date();
			System.out.println("Checking...");
			int ii = 0;
			for (; lg < end; ii++){
				dt.setTime(lg);
				if (tz.inDaylightTime(dt) != tzif.inDaylightTime(dt)){
					System.out.println("Mismatch: "+dt);
				}else{
					//System.out.println("Match: "+dt);
				}
				lg += inc;
			}
			System.out.println("Check done("+ii+") times.");
			System.out.println("Checking again...");
			Calendar cc = Calendar.getInstance();
			Time t2 = new Time();
			long lastDiff = 0;
			for (int year = 1990; year <= 2020; year ++)
				for (int month = 1; month <= 12; month++)
					for (int day = 1; day <= 28; day++)
					{
						cc.set(Calendar.YEAR, year);
						cc.set(Calendar.MONTH, month-1);
						cc.set(Calendar.DAY_OF_MONTH, day);
						try{
							long tzo = tz.getOffset(GregorianCalendar.AD, year, month-1, day, cc.get(Calendar.DAY_OF_WEEK), 0);
							long tzfo = tzif.getOffset(GregorianCalendar.AD, year, month-1, day, cc.get(Calendar.DAY_OF_WEEK), 0);
							if (tzo != tzfo){
								System.out.println("Mismatch at: "+day+"/"+month+"/"+year+": "+tzo+" != "+tzfo);
							}
							t2.day = day;
							t2.month = month;
							t2.year = year;
							t2.hour = 12;
							t2.minute = t2.second = t2.millis = 0;
							long zm = t2.getUTCMillis(tz);
							long zmf = t2.getUTCMillis(tzif);
							if (zm != zmf){
								System.out.println("Mismatch2 at: "+day+"/"+month+"/"+year+": "+tzo+" != "+tzfo);
							}else{
								long diff = zm-t2.getTime();
								if (diff != lastDiff){
									System.out.println("Change at: "+day+"/"+month+"/"+year+": "+lastDiff+"->"+diff);
									lastDiff = diff;
								}
							}
						}catch(IllegalArgumentException e){
							System.out.println(cc.get(Calendar.DAY_OF_WEEK));
						}
					}
			System.out.println("Check done.");
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("No TZIF file exists.");
		}
	}
	*/
}
