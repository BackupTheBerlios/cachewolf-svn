/*
 * Created on May 1, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface PNGImageTypes {

	public static final int PNG_TYPE_GRAY_SCALE = 0;
	public static final int PNG_TYPE_PALETTE = 3;
	public static final int PNG_TYPE_GRAY_SCALE_ALPHA = 4;
	public static final int PNG_TYPE_TRUE_COLOR = 2;
	public static final int PNG_TYPE_TRUE_COLOR_ALPHA = 6;

}
//####################################################
