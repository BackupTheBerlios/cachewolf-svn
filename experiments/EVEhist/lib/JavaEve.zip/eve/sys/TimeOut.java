package eve.sys;
/**
 * A TimeOut is an immutable 
 * @author Michael L Brereton
 *
 */
//##################################################################
public class TimeOut{
//##################################################################
/**
* This is the value for an infinite timeout in milliseconds, equal to -1.
**/
public static final long Infinite = -1;
/**
* This is the value for a zero timeout in milliseconds, equal to 0.
**/
public static final long Zero = 0;
	
protected long started, interval, nanos;

private boolean expired = false;
//==================================================================
public static TimeOut Forever, Immediate;
static {
	Forever = new TimeOut(Infinite);
	Immediate = new TimeOut(Zero);
}
//==================================================================

//===================================================================
public static final long now() {return System.currentTimeMillis();}
//===================================================================
//===================================================================
private static final long now(long startedFrom) {return System.currentTimeMillis();}
//===================================================================

/**
 * Gets the interval in milliseconds of this TimeOut. If the value is less than zero
 * this indicates an infinite interval.
 */
public long getInterval()
{
	return interval;
}
//===================================================================
/**
 * Reset the TimeOut so that it will time out again after its interval.
 * @return this TimeOut object.
 */
public TimeOut reset() 
//===================================================================
{
	started = now(); 
	expired = false; 
	return this;
}
/**
* Has this TimeOut expired yet?
**/
//===================================================================
public boolean hasExpired()
//===================================================================
{
	if (interval == 0) return true;
	if (interval < 0) return false;
	if (expired) return true;
	return (expired = now(started)-started >= interval);
}
/**
* How many milliseconds remaining? If it returns -1 it means that it
* will never timeout.
**/
//===================================================================
public long remaining()
//===================================================================
{
	if (interval == 0) return 0;
	if (interval < 0) return Infinite;
	if (expired) return 0;
	long r = interval+started-now(started);
	if (r < 0) r = 0;
	return r;
}
/**
* How many milliseconds has elapsed since the TimeOut was started/reset.
**/
//===================================================================
public long elapsed()
//===================================================================
{
	return now(started)-started;
}
/**
* Force it to expire. This has no effect on the Forever timeout.
**/
//===================================================================
public void expire() {if (interval >= 0) expired = true;}
//===================================================================
/**
* Create a timeout with the specified number of milliseconds.
**/
//===================================================================
public TimeOut(long time)
//===================================================================
{
	interval = time;
	if (interval < 0) interval = Infinite;
	reset();
}
/**
* Get a copy of this TimeOut, i.e. one which has the same interval.
**/
//===================================================================
public TimeOut getNew()
//===================================================================
{
	return new TimeOut(interval);
}


/**
 * Call the wait() method on the specified object with the amount of time
 * that is left. The calling thread must own the lock on the object. If the
 * TimeOut has already expired it will not wait at all.
 * @param obj the object to call wait() on.
 * @exception InterruptedException if it was interrupted.
 */
//===================================================================
public final void waitOn(Object obj) throws InterruptedException
//===================================================================
{
	long time = (int)remaining();
	if (time == 0) return;
	if (time == Infinite) obj.wait();
	else obj.wait(time);
}

//##################################################################
}
//##################################################################

