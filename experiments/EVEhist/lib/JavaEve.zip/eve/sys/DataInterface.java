/*
 * Created on Aug 16, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface DataInterface {

	public void setFieldTransfer(FieldTransfer ft);
	public FieldTransfer getFieldTransfer();
	public void updateFrom(FieldTransfer ft);
	public void updateTo(FieldTransfer ft);
}
//####################################################
