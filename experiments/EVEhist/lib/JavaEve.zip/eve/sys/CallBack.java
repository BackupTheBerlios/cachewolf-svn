/*
 * Created on Mar 5, 2005
 *
 */
package eve.sys;

/**
 * @author Mike
 */
public interface CallBack {
	public void callBack(Object data);
}
