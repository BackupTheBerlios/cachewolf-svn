/*
 * Created on Feb 23, 2005
 *
 */
package eve.sys;

import eve.io.File;
import eve.sys.options.VMOptions;


class RunMainThread extends Thread {

	String className;
	String[] args;
	boolean runHybrid = false;
	
	boolean tryHybrid()
	{
		try{
			String outf = System.getProperty("this.hybrid.jar");
			if (outf == null) return false;
			String inf = System.getProperty("this.hybrid.me");
			if (inf == null) return false;
			if (System.getProperty("this.hybrid.java") == null) return false;
			return true;
		}catch(Throwable e){
			//System.out.println("Could not build JAR!");
			e.printStackTrace();
			return false;
		}
	}
	public RunMainThread(String className, String[] args)
	{
		this.className = className;
		this.args = args;
		runHybrid = tryHybrid();
		if (runHybrid){
			start();
			return;
		}
		//
		// This is run in a non-Thread and so we cannot sleep here.
		//
		//try{sleep(1000);}catch(InterruptedException e){}
		Vm.setupSignalHandlers();
		try{
			Reflection.invokeMethod(Class.forName(className),"eveMain([Ljava/lang/String;)V",new Object[]{args});
		}catch(Throwable t){
			t.printStackTrace();
		}
		Type t = new Type("eve.fx.gui.WindowSurface");
		if (t.exists())try{
			t.invoke(null,"createDefaultWindow()Leve/fx/gui/WindowSurface;",null);
		}catch(Throwable th){
		}
		start();
	}
	public void run()
	{
		if (runHybrid){
			try{
				String hn = System.getProperty("this.hybrid.jar");
				String jv = System.getProperty("this.hybrid.java");
				String exe = System.getProperty("this.hybrid.me","/");
				if ("true".equals(System.getProperty("this.hybrid.build",""))){
					String cl = "\""+jv+"\" -cp \""+hn+".tmp\" Eve -hybrid- \""+hn+"\" \""+exe+"\"";
					//System.out.println("CL: "+cl);
					Process p = Vm.execCommandLine(cl);
					p.waitFor();
					File f = new File(hn+".tmp");
					f.delete();
					if (p.exitValue() != 0) throw new Exception();
				}
				File f = new File(exe);
				String pd = f.getParent();
				if (pd == null) pd = "/";
				String cl = "\""+jv+"\" -cp \""+hn+"\" Eve /d \""+pd+"\"";
				String ecl = System.getProperty("vm.commands","").trim();
				if (ecl.length() != 0)
					cl = cl+" "+ecl;
				Process p = Vm.execCommandLine(cl);
				p.waitFor();
				System.exit(p.exitValue());
				return;
			}catch(Throwable e){
				e.printStackTrace();
				mThread.nap(5000);
				System.exit(-1);
				return;
			}
		}
		VMOptions.vmOptions.runMain(args,className);
		/*
		try{
			Type t = new Type(className);
			if (t.exists()){
				Class c = t.getReflectedClass();
				Method m = c.getMethod("main",new Class[]{args.getClass()});
				m.invoke(null,new Object[]{args});
			}
			//Reflection.invokeMethod(Class.forName(className),"main([Ljava/lang/String;)V",new Object[]{args});
		}catch(Throwable e){
			if (e instanceof InvocationTargetException){
				((InvocationTargetException)e).getCause().printStackTrace();
			}else
				e.printStackTrace();
			//System.err.println("An error occured in main().");
			Device.tryMessageBox("Application Error","An error occured in main().\nThe application will now exit.",true);
			System.exit(-1);
		}
		*/
	}
}
