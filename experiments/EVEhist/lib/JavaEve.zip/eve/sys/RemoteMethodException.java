package eve.sys;

/**
 * This Exception is thrown if an error occurs (usually a communication error)
 * when executing a method "remotely" - that is where the target object may
 * not exist on the running virtual machine, in which case the method call
 * is done over some kind of communication medium. This Exception is thrown
 * if some error occurs over that medium or because some operation is not
 * allowed when run remotely.
 * <p>
 * The RemoteCallException inherits from this method and that exception is
 * specific to the remote call implementation used in eve.io.block.RemoteCall.
 */
public class RemoteMethodException extends RuntimeException
{
	Throwable exception;
	/**
	 * Returns the same as getCause() - i.e. the exception that caused this
	 * RemoteCallException to be thrown.
	 * @return
	 */
	public Throwable getException()
	//===================================================================
	{
		Throwable t = getCause();
		if (t == null) return exception;
		return t;
	}
	//===================================================================
	public RemoteMethodException(Throwable cause) {Vm.setCause(this,cause);}
	//===================================================================
	public RemoteMethodException(String message,Throwable cause) {super(message); Vm.setCause(this,cause);}
	//===================================================================
	public RemoteMethodException(String message) {super(message);}
}
