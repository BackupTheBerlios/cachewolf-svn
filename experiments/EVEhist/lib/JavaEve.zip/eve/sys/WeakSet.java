package eve.sys;

import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Vector;

import eve.util.ObjectFinder;
/**
* A weak set is an unordered collection of weak references to objects. Any
* object within this set is elligable for garbage collection if it is not
* pointed to by at least one non-weak reference.
* <p>
* A WeakSet can also be used as a SoftSet by using the constructor WeakSet(boolean useSoftReferences).
* <p>
* A WeakSet can also be used as a re-usable weak/soft reference - but one that
* does not allow for the use of queues. To use it in this way use only the get() and set()
* methods.
* <p>
* A WeakSet/SoftSet is a very good way of re-using resources in a memory efficient way,
* especially on a native Eve VM because it is backed by a native implementation that
* does not use Java Objects.
**/
//##################################################################
public class WeakSet{ 
//##################################################################
// Don't move these two.
private int nativeObject;
private boolean isSoft;
//
private Wrapper counter; 
private Vector refs;
private Vector tempV;
private static boolean useRefs = true; //Used for debugging. Set to false for strong references.
private static boolean hasNative = true;
private native Object setOperation(int operation, Object obj);
private static Vector toGo = new Vector();

private static final int OP_SETUP = 1;
private static final int OP_COUNT = 2;
private static final int OP_ADD = 3;
private static final int OP_REMOVE = 4;
private static final int OP_TAKE = 5;
private static final int OP_CLEANUP = 6;
private static final int OP_CLEAR = 7;
private static final int OP_GET_REFS = 8;
private static final int OP_CONTAINS = 9;
private static final int OP_SET = 10;
private static final int OP_GET = 11;

//===================================================================
public WeakSet(boolean useSoftReferences)
//===================================================================
{
	isSoft = useSoftReferences;
	if (hasNative && useRefs) try{
		setOperation(OP_SETUP,null);
		counter = new Wrapper();
		return;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	refs = new Vector();
}
//===================================================================
public WeakSet()
//===================================================================
{
	this(false);
}


//===================================================================
private void cleanup()
//===================================================================
{
	if (hasNative && useRefs){
		setOperation(OP_CLEANUP,null);
		return;
	}
	if (!useRefs) return;
	synchronized(toGo){
		for (int i = 0; i<refs.size(); i++){
			Reference wr = (Reference)refs.get(i);
			if (wr.get() == null) toGo.add(wr);
		}
		for (int i = 0; i<toGo.size(); i++)
			refs.remove(toGo.get(i));
		toGo.removeAllElements();
	}
}

//-------------------------------------------------------------------
private Object toObject(Object what)
//-------------------------------------------------------------------
{
	if (!useRefs) return what;
	else return ((Reference)what).get();
}
//-------------------------------------------------------------------
private Object toRef(Object what)
//-------------------------------------------------------------------
{
	if (!useRefs) return what;
	return isSoft ? (Object)new SoftReference(what) : (Object)new WeakReference(what);
}
/**
* This adds a reference to the set. Adding null will be ignored and adding an object
* which is already in the set will be ignored.
**/
//===================================================================
public synchronized void add(Object what)
//===================================================================
{
	if (what == null) return;
	if (hasNative && useRefs){
		setOperation(OP_ADD,what);
		return;
	}
	cleanup();
	for (int i = 0; i<refs.size(); i++)
		if (toObject(refs.get(i)) == what) return;
	refs.add(toRef(what));
}
/**
* This removes a reference from the set if it is in it. 
**/
//===================================================================
public synchronized void remove(Object what)
//===================================================================
{
	if (what == null) return;
	if (hasNative && useRefs){
		setOperation(OP_REMOVE,what);
		return;
	}
	cleanup();
	for (int i = 0; i<refs.size(); i++)
		if (toObject(refs.get(i)) == what){
			refs.removeElementAt(i);
			return;
		}
}
/**
* This removes all references in the set.
**/
public synchronized void clear() 
{
	if (hasNative && useRefs){
		setOperation(OP_CLEAR,null);
		return;
	}
	refs.removeAllElements();
}
/**
 * Add all live references into the destination Vector, without clearing the vector.
 * @param destination a non-null destination Vector.
 * @return the number of references found.
 */
public synchronized int getRefs(Vector destination)
{
	if (destination == null) throw new NullPointerException();
	if (hasNative && useRefs){
		synchronized(destination){
			int need = count();
			if (need == 0) return 0;
			int sz = destination.size();
			destination.ensureCapacity(need+sz);
			setOperation(OP_GET_REFS,destination);
			return destination.size()-sz;
		}
	}
	cleanup();
	Vector got = destination;
	int did = 0;
	for (int i = 0; i<refs.size(); i++){
		Object f = toObject(refs.get(i));
		if (f == null) continue; 
		got.addElement(f);
		did++;
	}
	return did;
}
/**
* This finds an object int the reference list using the ObjectFinder. This has the advantage of not
* creating an array everytime you are looking for an object.
**/

public synchronized Object find(ObjectFinder f)
{
	if (tempV == null) tempV = new Vector();
	tempV.removeAllElements();
	int got = getRefs(tempV);
	try{
		for (int i = 0; i<got; i++)
			if (f.lookingFor(tempV.get(i))) 
				return tempV.get(i);
	}finally{
		tempV.removeAllElements();
	}
	return null;
}

public synchronized boolean contains(Object who)
{
	if (who == null) return false;
	if (hasNative && useRefs){
		return setOperation(OP_CONTAINS,who) != null;
	}
	for (int i = 0; i<refs.size(); i++)
		if (toObject(refs.get(i)) == who) return true;
	return false;
}
/**
* This counts the number of live references. However this number may be
* reduced unpredictably.
**/
//===================================================================
public synchronized int count()
//===================================================================
{
	if (hasNative && useRefs){
		counter.setInt(0);
		return ((Wrapper)setOperation(OP_COUNT,counter)).getInt();
	}
	int did = 0;
	for (int i = 0; i<refs.size(); i++){
		Object f = toObject(refs.get(i));
		if (f == null) continue; 
		did++;
	}
	return did;
}
/**
 * True to indicate that there are definitely no entries. If it returns false
 * then there may be some entries.
 * @return
 */
//===================================================================
public synchronized boolean isEmpty()
//===================================================================
{
	if (hasNative && useRefs){
		return count() == 0;
	}
	return refs.size() == 0;
}
/**
* Get an Iterator to go through all the entries. The iterator will not return
* a null reference when next() is called (unless hasNext() returns false).
* <p>
* Note that this is a memory inefficient way of doing things.
**/
//===================================================================
public Iterator entries()
//===================================================================
{
	Vector v = new Vector();
	getRefs(v);
	return v.iterator();
}
/**
 * Place and return all live references into a new Object array. 
 */
public synchronized Object[] getRefs()
{
	if (tempV == null) tempV = new Vector();
	Vector v = tempV;
	v.removeAllElements();
	try{
		int got = getRefs(v);
		Object[] ret = new Object[v.size()];
		v.copyInto(ret);
		return ret;
	}finally{
		v.removeAllElements();
	}
}
/**
 * Remove and return a single live reference from the set, 
 * or return null if no live references could be found.
 */
public synchronized Object takeRef()
{
	if (hasNative && useRefs){
		return setOperation(OP_TAKE,null);
	}
	for (int i = 0; i<refs.size(); i++){
		Object f = toObject(refs.get(i));
		if (f != null) {
			refs.removeElementAt(i);
			return f;
		}
	}
	return null;	
}
/**
 * This is used to set the WeakSet to contain a single value. All other values
 * are removed.
 * @param obj the Object to add to the WeakSet.
 * @return the parameter obj.
 */
public synchronized Object set(Object obj)
{
	if (hasNative){
		setOperation(OP_SET,obj);
		return obj;
	}
	clear();
	add(obj);
	return obj;
}
/**
 * Return the first live value but leave it in the set.
 * @return the first live value or null if there are no live values.
 */
public synchronized Object get()
{
	if (hasNative){
		return setOperation(OP_GET,null);
	}
	if (tempV == null) tempV = new Vector();
	Vector v = tempV;
	v.removeAllElements();
	try{
		int got = getRefs(v);
		if (v.size() == 0) return null;
		return v.get(0);
	}finally{
		v.removeAllElements();
	}
}
/*
public static void main(String[] args)
{
	Vector alloced = new Vector();
	Object look = new byte[1000000];
	Reference wf = new WeakReference(look);
	WeakSet ws = new WeakSet(true);
	ws.add(new byte[1000000]);
	look = null;
	System.out.println(wf.get()+", "+ws.count());
	int cur = 2;
	while(wf.get() != null || ws.count() != 0){
		int i = 0;
		if (wf.get() != null) i++;
		if (ws.count() != 0) i++;
		if (i != cur) System.out.println(wf.get()+", "+ws.count());
		cur = i;
		alloced.add(new byte[100000]);
		System.gc();
	}
	System.out.println("Cleared!");
}
*/
//##################################################################
}
//##################################################################

