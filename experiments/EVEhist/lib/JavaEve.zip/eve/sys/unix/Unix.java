package eve.sys.unix;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.UndeclaredThrowableException;

import eve.io.File;
import eve.nativeaccess.NativeAccess;
import eve.sys.Registry;
import eve.sys.Vm;

public class Unix {
	
	private Unix(){}
	private static native int getID(String name, boolean isGroup);
	private static native String getName(int id, boolean isGroup);
	private static native int doGetuid(boolean isEffective,boolean isGroup);
	
static final int EFFECTIVE_ONLY = 1;	
static final int REAL_ONLY = 2;	
static final int REAL_EFFECTIVE = 3;
static final int ALL = 4;

	private static native void doSetuid(int rid,int eid,int sid,int which,boolean isGroup) throws UserNotFoundException, IllegalAccessException;

	/**
	 * This command only works on Unix/Linux platforms and only on a native Eve
	 * VM. It first causes the process
	 * to execute a fork(). If preExec is not null then the method preExec() will
	 * be called on it, with the preExecData object as a parameter. If preExec()
	 * returns a non-zero value, then the new process terminates immediately with
	 * that return value as the exit code. If preExec() throws an exception the process
	 * terminates with an exit code of -1. If preExec() returns zero then the 
	 * specified commands are executed via an exec() call. If commands is null
	 * then the process terminates after the preExec() call with an exit value
	 * of whatever value preExec() returned.<p>
	 * If both commands and preExec are null then a NullPointerException() is
	 * thrown.
	 * @param command the commands to execute. The first element must contain the
	 * path to the executable without quotes.
	 * @param env optional environment variables.
	 * @param preExec an optional object that will have its preExec() method invoked
	 * before the exec of the specified commands.
	 * @param preExecData optional data sent to the preExec() method.
	 * @return the Process representing the newly created process or null
	 * if the application is not running on a unix platform.
	 * @throws IOException if there was an error executing the command.
	 */
	public static Process forkExec(String[] commands, String[] env, PreExec preExec) throws IOException
	{
		if (!isUnixProcess() || Vm.isJavaVM()) return null;
		if (commands == null && preExec == null) throw new NullPointerException();
		else if (commands != null && commands.length == 0 && preExec == null) throw new IllegalArgumentException();
		Method m = NativeAccess.getNativeMethod(Runtime.class, "forkExec([Ljava/lang/String;[Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Process;");
		try{
			return (Process)m.invoke(Runtime.getRuntime(), new Object[]{commands,env,preExec});
		}catch(InvocationTargetException e){
			Throwable t = e.getCause();
			if (t instanceof IOException)
				throw (IOException)t;
			else if (t instanceof Error)
				throw (Error)t;
			else if (t instanceof RuntimeException)
				throw (RuntimeException)t;
			else
				throw new UndeclaredThrowableException(t);
		}catch(IllegalAccessException e){
			return null; 
		}catch(IllegalArgumentException e){
			return null;
		}
	}
	public static boolean isUnixProcess()
	{
		return getuid() != -1;
	}
	/**
	 * Determine the current real user if this is a Unix/Linux process.
	 * @return the current user id or -1 if this is not a Unix process.
	 */
	public static int getuid()
	{
		return doGetuid(false, false);
	}
	/**
	 * Determine the current effective user if this is a Unix/Linux process.
	 * @return the current effective user id  or -1 if this is not a Unix process.
	 */
	public static int geteuid()
	{
		return doGetuid(true, false);
	}
	/**
	 * Determine the current real group id if this is a Unix/Linux process.
	 * @return the current group id  or -1 if this is not a Unix process.
	 */
	public static int getgid() 
	{
		return doGetuid(false, true);
	}
	/**
	 * Determine the current effective group id if this is a Unix/Linux process.
	 * @return the current effective group id  or -1 if this is not a Unix process.
	 */
	public static int getegid() 
	{
		return doGetuid(true, true);
	}
	
	/**
	 * Get the user ID number for the specified user name.
	 * @param name the user name.
	 * @return the user ID number for the specified user name 
	 * or -1 if it was not found.
	 */
	public static int getUserID(String name)
	{
		return getID(name,false);
	}
	/**
	 * Get the group ID number for the specified group name.
	 * @param name the group name.
	 * @return the user ID number for the specified group name 
	 * or -1 if it was not found.
	 */
	public static int getGroupID(String name)
	{
		return getID(name,true);
	}
	/**
	 * Get the user name for the specified user id.
	 * @param userID the user id.
	 * @return the user name for the specified user id
	 * or null if it was not found.
	 */
	public static String getUserName(int userID)
	{
		return getName(userID,false);
	}
	/**
	 * Get the group name for the specified group id.
	 * @param groupID the group id.
	 * @return the group name for the specified group id
	 * or null if it was not found.
	 */
	public static String getGroupName(int groupID)
	{
		return getName(groupID,true);
	}
	public static void seteuid(int euid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(-1, euid, -1, EFFECTIVE_ONLY, false);
	}
	public static void setuid(int ruid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(ruid, -1, -1, REAL_ONLY, false);
	}
	public static void setreuid(int ruid,int euid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(ruid, euid, -1, REAL_EFFECTIVE, false);
	}
	public static void setresuid(int ruid,int euid,int suid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(ruid, euid, suid, ALL, false);
	}
	public static void setegid(int egid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(-1, egid, -1, EFFECTIVE_ONLY, true);
	}
	public static void setgid(int rgid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(rgid, -1, -1, REAL_ONLY, true);
	}
	public static void setregid(int rgid,int egid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(rgid, egid, -1, REAL_EFFECTIVE, true);
	}
	public static void setresgid(int rgid,int egid,int sgid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(rgid, egid, sgid, ALL, true);
	}
	private static void testMe()
	{
		int myId = geteuid();
		String myName = getUserName(myId);
		System.out.println("Me: "+myId+" am: "+myName);
		System.out.println("My name goes to: "+getUserID(myName));
		System.out.println("Group is: "+getegid()+" = "+getGroupName(getegid()));
	}
	public static void main(String[] args) throws Exception
	{
		Vm.startEve(args);
		//
		try{
			testMe();
		}catch(Throwable t){
			t.printStackTrace();
		}
		if (args.length != 0){
			if (args[0].equals("fork")){
				File exec = Registry.getRunningVM();
				String cmd = File.toSystemDependantPath(exec.getAbsolutePath());
				System.out.println("Running: "+cmd);
				String[] commands = new String[]{cmd,"eve.ui.data.Notepad"};
				final int anna = getUserID("mike");
				//
				PreExec pe = new PreExec();
				pe.setreuid(anna, anna);
				//
				Process p = forkExec(commands, null, pe);
				if (p != null){
					System.out.println("Waiting!");
					BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
					while(true){
						String line = br.readLine();
						if (line == null) break;
						System.out.println(">"+line);
					}
				}
				int got = p.waitFor();
				System.out.println("Returned: "+got);
				//Runtime.getRuntime().exec(commands);
				Vm.exit(0);
			}else if (args[0].equals("test")){
				String [] c = new String[args.length-1];
				for (int i = 0; i<c.length; i++)
					c[i] = args[i+1];
				Process p = Runtime.getRuntime().exec(c);
				if (p != null){
					System.out.println("Waiting!");
					BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
					while(true){
						String line = br.readLine();
						if (line == null) break;
						System.out.println(">"+line);
					}
				}
				int got = p.waitFor();
				System.out.println("Returned: "+got);
				//Runtime.getRuntime().exec(commands);
				Vm.exit(0);
			}
			int aid = getUserID(args[0]);
			if (aid == -1){
				System.out.println("No such user: "+args[0]);
			}else{
				seteuid(aid);
				testMe();
				seteuid(aid*10);
			}
		}
		Vm.exit(0);
	}
}
