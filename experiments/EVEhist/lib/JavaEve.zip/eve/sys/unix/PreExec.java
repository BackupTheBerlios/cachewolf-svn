package eve.sys.unix;
/**
 * This can be used with Unix.forkExec(). It specifies what changes
 * to the process is to be made before the exec() call.
 * To use this you can call ONE of the setuid() methods and ONE of
 * the setgid() methods. These method calls will not have an effect
 * until after the fork() is done. 
 */
public class PreExec {
	//This must be first.
	int [] ids = new int[8];
	
	public PreExec()
	{
		for (int i = 0; i<ids.length; i++)
			ids[i] = -1;
	}
	
	private void doSetuid(int r, int e, int s, int which, boolean isGroup)
	{
		int offset = isGroup ? 4 : 0;
		ids[offset++] = which;
		ids[offset++] = r;
		ids[offset++] = e;
		ids[offset++] = s;
	}
	
	public  void seteuid(int euid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(-1, euid, -1, Unix.EFFECTIVE_ONLY, false);
	}
	public  void setuid(int ruid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(ruid, -1, -1, Unix.REAL_ONLY, false);
	}
	public  void setreuid(int ruid,int euid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(ruid, euid, -1, Unix.REAL_EFFECTIVE, false);
	}
	public  void setresuid(int ruid,int euid,int suid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(ruid, euid, suid, Unix.ALL, false);
	}
	public  void setegid(int egid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(-1, egid, -1, Unix.EFFECTIVE_ONLY, true);
	}
	public  void setgid(int rgid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(rgid, -1, -1, Unix.REAL_ONLY, true);
	}
	public  void setregid(int rgid,int egid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(rgid, egid, -1, Unix.REAL_EFFECTIVE, true);
	}
	public  void setresgid(int rgid,int egid,int sgid) throws IllegalAccessException, UserNotFoundException
	{
		doSetuid(rgid, egid, sgid, Unix.ALL, true);
	}
	
}
