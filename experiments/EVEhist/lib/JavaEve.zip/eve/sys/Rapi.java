package eve.sys;

import eve.io.File;

/**
 * This class provides a simplified interface to the eve.net.rapi 
 * functions, but this Rapi class will always be present
 * even if eve.net.rapi is not. All functions in this class can be
 * called at any time without initializing the Rapi library - this
 * will be done the methods in this class.
 */

public final class Rapi {

	private Rapi(){}
	/**
	 * Whenever it is necessary for Rapi to initiate a connection,
	 * this timeout value will be used. By default it is 1000 but
	 * this can be changed to any other value.
	 */
	public static int connectionTimeoutInMillis = 1000;
	
	private static Type rapiType, rapiFileType;
	private static Object[] tryConnectP;
	/**
	 * Try to make a connection via ActiveSync. This is not usually
	 * necessary since this will be done by the other methods automatically
	 * but there may be reasons that you want to initialize the connection
	 * before hand.
	 * @param timeoutInMillis the timeout for the connection.
	 * @return true on success, false on failure.
	 */
	public static synchronized boolean tryConnect(int timeoutInMillis)
	{
		if (rapiType == null) {
			rapiType = new Type("eve.net.rapi.Rapi");
			rapiFileType = new Type("eve.net.rapi.RapiFile");
			tryConnectP = new Object[1];
		}
		tryConnectP[0] = new Integer(timeoutInMillis);
		if (!rapiType.exists()) return false;
		Object got = rapiType.invoke(null, "tryConnect(I)Z", tryConnectP);
		if (!(got instanceof Boolean)) return false;
		return ((Boolean)got).booleanValue();
	}
	public static IRegistryKey getRemoteRegistry()
	{
		if (!tryConnect(connectionTimeoutInMillis)) return null;
		return Registry.getRemoteRegistry();
	}
	/**
	 * Get a File that represents the root directory of the remote system. Use
	 * getChild() on this File to navigate the remote file system.
	 * @return a File that represents the root directory of the remote system.
	 */
	public static File getRapiRootFile()
	{
		return getRapiFile("\\");
	}
	/**
	 * Get a File that represents a particular file on the remote system. Use
	 * getChild()/getParentFile() on this File to navigate the remote file system.
	 * @return a File that represents the root directory of the remote system.
	 */
	public static File getRapiFile(String location)
	{
		if (!tryConnect(connectionTimeoutInMillis)) return null;
		return (File)rapiFileType.newInstance("Ljava/lang/String;", new Object[]{location});
	}
}
