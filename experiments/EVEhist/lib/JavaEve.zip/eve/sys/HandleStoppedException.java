package eve.sys;

//##################################################################
public class HandleStoppedException extends Exception{
//##################################################################

public HandleStoppedException() {}
public HandleStoppedException(String msg) {super(msg);}

//##################################################################
}
//##################################################################

