package eve.sys;

import java.text.ParseException;

import eve.util.CharArray;
import eve.util.LocaleFormatted;

/**
 * This is object is used by LocaleFormatted objects when 
 * formatting their data for display in a Locale specific way.
 * The base version of LocaleFormat provides a field to hold
 * the Locale that should be used (which defaults to the default
 * Locale), field to hold a format Object (usually a string specifying format)
 * and options specific to the target object.
 * <p>   
 * There are also some static methods to make it easy to format
 * LocaleFormatted objects using default values without having
 * to create LocaleFormat objects.
 */
public class LocaleFormat {
	
	/**
	 * The locale that should be used.
	 */
	public Locale locale = Locale.getDefault();
	/**
	 * This indicates that a number should format itself as it would
	 * for being displayed as currency.
	 */
	//public boolean isCurrency;
	/**
	 * This indicates that a number should show the currency symbol
	 * in the appropriate place.
	 */
	//public boolean showCurrencySymbol;
	/**
	 * This is an optional format Object to use.
	 * The type of this value depends on the Object being formatted.
	 * An eve.math.DecimalFormat Object may be used to format a number.   
	 * If it is null the LocaleFormatted
	 * object should use the default format as provided by the Locale.
	 */
	public Object format;
	
	public static final int OPTION_IS_CURRENCY = 0x8000000; 
	public static final int OPTION_SHOW_CURRENCY_SYMBOL = 0x4000000; 
	public static final int OPTION_SHOW_GROUPINGS = 0x2000000; 
	/**
	 * Further formatting options. Custom options should start at 0x1 and go
	 * up to 0x800000
	 */
	public int options;
	
	public static final LocaleFormat getCached(Locale loc)
	{
		LocaleFormat lc = (LocaleFormat)Cache.get(LocaleFormat.class);
		lc.format = null; 
		lc.options = 0;
		lc.locale = loc == null ? Locale.getDefault() : loc;
		return lc;
	}
	public LocaleFormat getCachedCopy()
	{
		LocaleFormat lc = (LocaleFormat)Cache.get(LocaleFormat.class);
		lc.format = format; 
		lc.options = options;
		lc.locale = locale;
		return lc;
	}
	public final void cache()
	{
		Cache.put(this);
	}
	/**
	 * Convert a LocaleFormatted data to a String, formatted for the current locale.
	 * If the Object implements LocaleFormatted, the format() method
	 * will be called, otherwise a simple toString() is called.
	 * @param dest the destination CharArray. If it is null a new one is 
	 * created and returned.
	 * @param data the LocaleFormatted Object to convert to a String.
	 * @param format a format specifier - usually a String.
	 * @param loc the locale to use for formatting. If it is null, the default
	 * Locale is used.
	 * @return the dest CharArray or a new one if it was null.
	 */
	public static CharArray format(CharArray dest,LocaleFormatted data,Object format,Locale loc)
	{
		if (dest == null) dest = new CharArray();
		LocaleFormat lcf = LocaleFormat.getCached(loc);
		lcf.format = format;
		try{
			((LocaleFormatted)data).format(lcf, dest);
		}finally{
			lcf.cache();
		}
		return dest;
	}
	/**
	 * Format a LocaleFormatted to a String.
	 * @param lf the LocaleFormatted object to format.
	 * @param format an optional format specifier - usually a String.
	 * @param loc the Locale to use for formatting.
	 * @return the LocaleFormatted object formatted as a String.
	 */
	public static String format(LocaleFormatted lf, Object format, Locale loc)
	{
		CharArray ca = (CharArray)Cache.get(CharArray.class);
		try{
			ca.clear();
			format(ca,lf,format,loc);
			return ca.toString();
		}finally{
			Cache.put(ca);
		}
	}	
	/**
	 * Parse a String to a LocaleFormatted Object.
	 * @param formatted the formatted String.
	 * @param lf the LocaleFormatted object that will be parsing.
	 * @param an optional format specifier - usually a String.
	 * @param loc the Locale that was used for formatting.
	 * @throws java.text.ParseException on a parse error.
	 */
	public static void parse(String formatted,LocaleFormatted lf, Object format, Locale loc)
	throws ParseException
	{
		char[] all = Vm.getStringChars(formatted);
		LocaleFormat lcf = LocaleFormat.getCached(loc);
		lcf.format = format;
		try{
			lf.parse(lcf, all, 0, all.length); 
		}finally{
			lcf.cache();
		}
	}	
}
