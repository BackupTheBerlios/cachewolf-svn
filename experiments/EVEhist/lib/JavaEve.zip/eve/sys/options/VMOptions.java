/*
 * Created on Jul 1, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys.options;

import eve.io.File;
import java.io.IOException;

import eve.data.EncodableObject;
import eve.io.Io;
import eve.sys.Device;
import eve.sys.IRegistryKey;
import eve.sys.Rapi;
import eve.sys.Registry;
import eve.sys.Type;
import eve.sys.Vm;

/**
 * This class holds options for the VM if the class eve.ui.VMOptions does not exist.
 * The eve.ui.options.VMOptions is loaded when the VM starts but if it is not present, then
 * this one is loaded.<p>
 * Use the static <b>vmOptions</b> field to access the VM options selected and
 * saved on the running system.
 * @author Michael L Brereton
 */
//####################################################
public class VMOptions extends EncodableObject{

	public boolean singleWindowed = false; 
	public boolean keepVmResident = false;//Vm.isMobile();
	public boolean fixedSIPButton = false;
	public boolean useSIP = true;
	public String pathToEve = Vm.getProperty("this.exe.path", "/Program Files/eve");
	public String _fields = "fixedSIPButton,singleWindowed,keepVmResident,pathToEve,useSIP,showEveSyncConsole";
	public boolean showEveSyncConsole = false;
	
	/**
	 * This holds an instance of VMOptions that has been initialized to the
	 * correct saved values.
	 */
	public static VMOptions vmOptions;
	static {
		vmOptions = getNewVMOptions();
		try{
			vmOptions.initialize();
			vmOptions.read();
		}catch(Throwable t){}
	}
	public static boolean shouldUsePathToEve()
	{
		return File.pathSeparatorChar == ':'; //FIXME
		//true ||
		//(!Vm.isJavaVM() && (Vm.getProperty("windows.version",null) == null));
	}
	/**
	 * Use this to get a new instance of a VMOptions - don't use the constructor
	 * VMOptions(). This method will return an eve.ui.options.VMOptions object
	 * if it exists.
	 * @return a new instance of a VMOptions object. 
	 */
	public static VMOptions getNewVMOptions()
	{
		Type ty = new Type(VMOptionsConfig.VMOptionsClassName);
		if (ty.exists()) return (VMOptions)ty.newInstance();
		else return new VMOptions();
	}
//	===================================================================
	public boolean read()
//	===================================================================
	{
		try{
			String found = Io.getConfigInfo("Ewesoft\\EveVM"); 
			textDecode(found);
			//Device.messageBox("Read",found,Device.MB_TYPE_OK);
			return true;
		}catch(Exception e){
			//new ReportException(e).execute();
			return false;
		}
	}
//	===================================================================
	public boolean save()
//	===================================================================
	{
		try{
			Io.saveConfigInfo(textEncode(),"Ewesoft\\EveVM",Io.SAVE_IN_FILE_OR_REGISTRY);
			//if (ed != null) Gui.flashMessage("Saved. Restart to take effect...",1000,ed,Gui.FLASH_BEEP);
			//new MessageBox("Saving!","Saving data!",MessageBox.MBOK).execute();
			return true;
		}catch(Exception e){
			//new ReportException(e).execute();
			return false;
		}
	}
	public boolean applySystemOptions()
	{
		return true;
	}
	/**
	 * Used with removeInstallation, will remove all file association
	 * for .eve files.
	 */
	public static final int REMOVE_FILE_ASSOCIATIONS = 0x1;
	/**
	 * Used with removeInstallation, will remove the Ewesoft\EveVM
	 * configuration.
	 */
	public static final int REMOVE_VM_OPTIONS = 0x2;
	/**
	 * Used with removeInstallation, will remove all Ewesoft
	 * configurations including the EveVM configuration.
	 */
	public static final int REMOVE_ALL_EWESOFT_OPTIONS = 0x4;

	private static final void delKey(IRegistryKey r,String name)
	{
		IRegistryKey k = r.getSubKey(name);
		if (k != null) {
			k.deleteKey();
		}
	}
	/**
	 * Remove installation information on the local or remote machine.
	 * @param onLocalMachine true for the local machine, false for the
	 * remote device.
	 * @param whatToRemove any of the REMOVE_XXX values OR'ed together.
	 * @throws IOException on error.
	 */
	public static void removeInstallation(boolean onLocalMachine,int whatToRemove) throws IOException
	{
		IRegistryKey rk = onLocalMachine ? Registry.getLocalRegistry() : Registry.getRemoteRegistry();
		File f = onLocalMachine ? new File("") : Rapi.getRapiRootFile();
		if (rk == null) throw new IOException("Could not access registry.");
		if (f == null) throw new IOException("Could not access file system.");
		if ((whatToRemove & REMOVE_FILE_ASSOCIATIONS) != 0){
			delKey(rk,"HKEY_CLASSES_ROOT\\.eve");
			delKey(rk,"HKEY_CLASSES_ROOT\\EveFile10");
		}
		if ((whatToRemove & (REMOVE_VM_OPTIONS|REMOVE_ALL_EWESOFT_OPTIONS)) != 0){
			IRegistryKey k = rk.getSubKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\EweSoft\\EveVM");
			if (k != null){
				Object ff = k.getValue("File");
				if (ff instanceof String){
					File td = f.getNew((String)ff);
					td.delete();
				}
			}
			delKey(rk,"HKEY_LOCAL_MACHINE\\SOFTWARE\\EweSoft\\EveVM");
		}
		if ((whatToRemove & (REMOVE_ALL_EWESOFT_OPTIONS)) != 0){
			delKey(rk,"HKEY_LOCAL_MACHINE\\SOFTWARE\\EweSoft");
		}
	}
	/**
	 * @deprecated use setupInstallFileAssociations(boolean onLocalMachine).
	 */
	public void setupInstallFileAssociations()
	{
		setupInstallFileAssociations(true);
	}
	/**
	 * Setup standard File Associations on the local machine or on the
	 * remote device (connected via ActiveSync). Make sure the pathToEve has been setup correctly
	 * first.
	 * @param onLocalMachine true to setup the local machine, false
	 * for a connected remote device.
	 * @return true on success, false on failure. If onLocalMachine is
	 * false and the device is not connected, this will return false.
	 */
	public boolean setupInstallFileAssociations(boolean onLocalMachine)
	{
		try{
			IRegistryKey k = Vm.getRegistryKey(onLocalMachine,"HKEY_CLASSES_ROOT\\.eve",true,true);
			k.setValue(null, "EveFile10");
			String pe = pathToEve.replace('/','\\');
			k = Vm.getRegistryKey(onLocalMachine,"HKEY_CLASSES_ROOT\\EveFile10\\DefaultIcon",true,true);
			k.setValue(null,pe+",-50");
			k = Vm.getRegistryKey(onLocalMachine,"HKEY_CLASSES_ROOT\\EveFile10\\Shell\\Open\\Command",true,true);
			String cmd = "\""+pe+"\" \"%1\"";
			k.setValue(null, cmd);
			k = Vm.getRegistryKey(onLocalMachine,"HKEY_CLASSES_ROOT\\EveFile10\\DLL",true,true);
			if (pe.toLowerCase().endsWith(".exe"))
				pe = pe.substring(0,pe.length()-3)+"DLL";
			k.setValue(null, pe);
			return true;
		}catch(Throwable t){
			t.printStackTrace();
			return false;
		}
	}
	/**
	 * This method is used to setup the computer after the installation
	 * of the Eve VM or an Eve application if installation of the VM is part
	 * of the application installation. It sets up the Registry (on Windows machines)
	 * and then saves the VMOptions configuration. 
	 * To use this, do getNewVMOptions() to get a new VM options
	 * and then setup the option fields, including, most importantly,
	 * the pathToEve (on all platforms) to be the correct path to the VM executable.
	 * @deprecated use setupInstall(boolean onLocalMachine) instead. 
	 */
	public void setupInstall() throws IOException
	{
		setupLocal();
	}
	private void setupLocal() throws IOException
	{
		initialize();
		setupInstallFileAssociations();
		Io.saveConfigInfo(textEncode(),"Ewesoft\\EveVM",Io.SAVE_IN_FILE_OR_REGISTRY);
		applySystemOptions();
	}
	/**
	 * This method is used to setup the computer or mobile device after the installation
	 * of the Eve VM or an Eve application if installation of the VM is part
	 * of the application installation. It sets up the Registry (on Windows machines)
	 * and then saves the VMOptions configuration. 
	 * To use this, do getNewVMOptions() to get a new VM options
	 * and then setup the option fields, including, most importantly,
	 * the pathToEve (on all platforms) to be the correct path to the VM executable.
	 * @param onLocalMachine true for the local machine, false for the remote. 
	 */
	public void setupInstall(boolean onLocalMachine) throws IOException
	{
		if (onLocalMachine) setupLocal();
		else{
			if (!setupInstallFileAssociations(false))
				throw new IOException("Could not setup registry on remote device.");
			String pe = pathToEve.replace('\\','/');
			int idx = pe.lastIndexOf('/');
			if (idx != -1 && idx != 0) pe = pe.substring(0,idx);
			Io.saveRemoteConfigInfo(textEncode(),"Ewesoft\\EveVM",pe);
		}
	}
	/*
//	===================================================================
	public static boolean createShortcutToVM()
//	===================================================================
	{
		return false;
	}
	*/
	public void apply()
	{
		/**
		 * Note that this method is not called automatically,
		 * the GUI is responsible for applying it when necessary.
		 */
		Device.preloadVm(keepVmResident);
		Vm.setParameter(Vm.SET_USE_SIP,useSIP ? 1 : 0);
		if (singleWindowed) Vm.setParameter(Vm.TURN_ON_VM_FLAG_BITS, Vm.VM_FLAG_NO_WINDOWS);
		if (fixedSIPButton) Vm.setParameter(Vm.TURN_ON_VM_FLAG_BITS, Vm.VM_FLAG_SIP_BUTTON_ALWAYS_SHOWN);
	}
	private static Type launcher;
	
	/**
	 * Get the default launcher Class. If the Type returned exists
	 * then eveMain() and main() are called on that Type at startup.
	 * @return a default Type for launching.
	 */
	public Type getLaunchType()
	{
		if (launcher == null)
			launcher = new Type((String)null);
		return launcher;
	}

	public void runMain(String[] args, String startClassName)
	{
		Type t = new Type(startClassName);
		if (!t.exists()) return;
		if (Vm.isJavaVM())
			t.invoke(null,"eveMain([Ljava/lang/String;)V",new Object[]{args});
		t.invoke(null,"main([Ljava/lang/String;)V",new Object[]{args});
	}
	protected void initialize()
	{
	}
}
//####################################################
