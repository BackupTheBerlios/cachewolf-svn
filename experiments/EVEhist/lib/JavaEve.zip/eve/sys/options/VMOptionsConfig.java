/*
 * Created on Mar 19, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys.options;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
class VMOptionsConfig {

static final String VMOptionsClassName = "eve.ui.VMOptions";
	
}
//####################################################
