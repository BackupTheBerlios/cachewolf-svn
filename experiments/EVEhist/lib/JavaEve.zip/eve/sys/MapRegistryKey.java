/*
 * Created on Mar 13, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import eve.util.mString;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class MapRegistryKey extends RegistryKeyObject {

	protected Map list;
	protected Vector values;
	/**
	 * @param name
	 */
	public MapRegistryKey(String name, Map list) {
		this(name,null,null);
		if (list == null) list = new Hashtable();
		this.list = list;
	}

	/**
	 * @param name
	 * @param fullPath
	 * @param root
	 */
	protected MapRegistryKey(String name, String fullPath,
			RegistryKeyObject root) {
		super(name, fullPath, root);
		//System.out.println("Creating: "+name+", "+fullPath+", "+root);
		this.list = root == null ? null : ((MapRegistryKey)root).list;
	}
	/*
	 * ----------------------------------------- 
	 * Override from here.
	 * ----------------------------------------- 
	 */
		
		Map locateMap(String path, boolean parent)
		{
			String[] all = mString.split(path,'\\');
			Map look = list;
			int max = all.length;
			if (parent) max--;
			for (int i = 0; i<max; i++){
				Object got = look.get(all[i]);
				if (!(got instanceof Map)) return null;
				look = (Map)got;
			}
			return look;
		}
		Map locateMe()
		{
			if (root == null) return list;
			return locateMap(path,false);
		}
		/**
		 * Override this to create the data that represents a key.
		 * @param fullPath the full path of the key.
		 * @return true if it could be created, false if not.
		 */
		protected boolean createKey(String fullPath)
		{
			Map m = locateMap(fullPath,true);
			if (m == null) return false;
			int idx = fullPath.lastIndexOf('\\');
			if (idx != -1) fullPath = fullPath.substring(idx+1);
			m.put(fullPath,new Hashtable());
			return true;
		}
		
		synchronized Vector getMyValues()
		{
			if (values == null){
				values = new Vector();
				if (root != null){
					Map m = locateMe();
					if (m != null){
						for (Iterator e = m.keySet().iterator(); e.hasNext();){
							Object key = e.next();
							if (m.get(key) instanceof Map) continue;
							values.add(key);
						}
					}
				}
			}
			return values;
			
		}
		/* (non-Javadoc)
		 * @see eve.sys.IRegistryKey#getValueCount()
		 */
		public int getValueCount() {
			return getMyValues().size();
		}
		
		private synchronized boolean doSet(String name, Object value)
		{
			Map m = locateMe();
			if (m == null) return false;
			if (name == null) name = "";
			m.put(name,value);
			return true;
		}
		/* (non-Javadoc)
		 * @see eve.sys.IRegistryKey#setExpandingString(java.lang.String, java.lang.String)
		 */
		public boolean setExpandingString(String name, String value) {
			if (value == null) value = "";
			return doSet(name,new StringBuffer(value));
		}

		/* (non-Javadoc)
		 * @see eve.sys.IRegistryKey#setValue(java.lang.String, java.lang.String)
		 */
		public boolean setValue(String name, String value) {
			if (value == null) value = "";
			return doSet(name,value);
		}

		/* (non-Javadoc)
		 * @see eve.sys.IRegistryKey#setValue(java.lang.String, byte[])
		 */
		public boolean setValue(String name, byte[] value) {
			if (value == null) value = new byte[0];
			return doSet(name,value);
		}

		/* (non-Javadoc)
		 * @see eve.sys.IRegistryKey#setValue(java.lang.String, int)
		 */
		public boolean setValue(String name, int value) {
			return doSet(name,new Integer(value));
		}
		/**
		 * You must override this method.
		 * @param name the name to display. If this is null the displayed name
		 * defaults to the last section of the path.
		 * @param fullPath the full path but not starting with a leading '\'
		 * @param root the root for the key.
		 * @return a new RegistryKeyObject.
		 */
		protected RegistryKeyObject getNew(String name, String fullPath, RegistryKeyObject root)
		{
			return new MapRegistryKey(name,fullPath,root);
		}
		/* (non-Javadoc)
		 * @see eve.sys.IRegistryKey#getValue(java.lang.String)
		 */
		public Object getValue(String valueName) 
		{
			if (valueName == null) valueName = "";
			Map m = locateMe();
			if (m == null) return null;
			Object got = m.get(valueName);
			if (got instanceof String) return got;
			if (got instanceof StringBuffer) return got;
			if (got instanceof byte[]) return got;
			if (got instanceof Integer) return got;
			return null;
		}

		/* (non-Javadoc)
		 * @see eve.sys.IRegistryKey#getValue(int, java.lang.StringBuffer)
		 */
		public synchronized Object getValue(int index, StringBuffer valueName)
				throws IndexOutOfBoundsException {
			String nm = getMyValues().get(index).toString();
			if (valueName != null) valueName.append(nm);
			return getValue(nm);
		}

		/* (non-Javadoc)
		 * @see eve.sys.IRegistryKey#deleteValue(java.lang.String)
		 */
		public synchronized boolean deleteValue(String name) {
			Map m = locateMe();
			if (m == null) return false;
			m.remove(name);
			if (values != null) values.remove(name);
			return true;
		}
		public boolean keyExists() {
			if (root == null) return true;
			return locateMe() != null;
		}
		protected boolean doDelete()
		{
			MapRegistryKey rk = (MapRegistryKey)getParentKey();
			if (rk == null) return false;
			Map m = rk.locateMe();
			if (m == null) return false;
			m.remove(name);
			return false;
		}
		protected String[] getUnsortedKeyNames()
		{
			Map m = locateMe();
			if (m == null){
				return emptyValuesList;
			}
			Vector v = new Vector();
			for (Iterator e = m.keySet().iterator(); e.hasNext();){
				Object key = e.next();
				if (!(m.get(key) instanceof Map)) continue;
				v.add(key);
			}
			String[] ret = new String[v.size()];
			v.copyInto(ret);
			return ret;
		}

}

//####################################################
