/*
 * Created on Apr 15, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.sys;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface EventListener extends java.util.EventListener{

	public void onEvent(Event ev);

}
//####################################################
