/*
 * 
 * 
 */
package eve.sys;

import java.util.Vector;

/**
 * This class is used to provide a single-writer/multiple-reader Lock
 * for any resource. If at least one reader holds the lock no writer
 * can hold the lock. If the lock is held by a writer no readers can
 * hold the lock. Multiple readers can hold the lock at the same time.
 * <p>
 * Requests are first-in-first-out but Write request have priority over
 * read requests - so it <b>is</b> possible for continuous write requests
 * to completely deny read requests, but not for read requests to deny
 * write requests. 
 * @author Michael L Brereton
 *
 */
//####################################################
public class ReadWriteLock {
	
	private Vector waitingToWrite, waitingToRead;
	private Vector multipleReading;
	private Object reading;
	private Thread writing;
	private int writeCount;
	private int readCount; //Only used when there is one reader.
	private boolean writingPaused = false;
	private boolean closed = false;
	private Vector readingVector;
	
	/**
	 * Returns if the lock is closed.
	 */
	public synchronized boolean isClosed()
	{
		return closed;
	}
	/**
	 * Closes the lock. You can override this to ensure
	 * that the lock never closes.
	 */
	public synchronized void close()
	{
		closed = true;
		notifyAll();
	}
	private boolean doWait(long started,long timeout) throws InterruptedException
	{
		long left = started+timeout-System.currentTimeMillis();
		if (timeout == 0) return false;
		else if (timeout > 0 && left <= 0)return false;
		else if (timeout < 0) wait();
		else wait(left);
		return true;
	}
	private boolean grabWrite(Thread who, boolean inQueue)
	{
		if (writing == who){
			if (inQueue) throw new Error("grabWrite() error.");
			if (writingPaused) throw new IllegalThreadStateException("Writer cannot acquire another Write lock while writing is paused.");
			writeCount++;
			return true;
		}
		//
		// Should never try to lock writing when you have the read lock.
		//
		if (readCount != 0){
			if (reading == who || (readingVector != null && readingVector.contains(who)))
				throw new IllegalThreadStateException("Already hold a Read lock.");
		}
		//
		// At this point I do not hold any lock.
		//
		// As long as someone is already reading or writing I have to wait.
		//
		if (readCount != 0 || writeCount != 0) return false;
		//
		// At this point it IS possible to hold the write lock.
		// See if anyone else is waiting.
		//
		if (!inQueue && waitingToWrite != null && waitingToWrite.size() != 0) return false;
		//
		// I can become the writer. Which means there are no readers.
		//
		reading = null;
		writing = who;
		writeCount++;
		return true;
	}
	private boolean grabRead(Thread who, boolean inQueue)
	{
		//
		// If I am the writer then I can also be the only reader.
		//
		if (writing == who || reading == who){
			reading = who;
			readCount++;
			return true;
		}
		if (readCount != 0 && readingVector != null && readingVector.contains(who)){
			if (inQueue) throw new Error("grabRead() error.");
			readingVector.add(who);
			readCount++;
			return true;
		}
		//
		// At this point I do not have any read lock at all.
		//
		// Is it possible to acquire the read lock now?
		//
		if (writeCount != 0 && !writingPaused) return false;
		//
		// At this point it IS possible to acquire the read lock. 
		// First see if anyone is waiting.
		//
		if (!inQueue){
			if (waitingToWrite != null && waitingToWrite.size() != 0) return false;
			if (waitingToRead != null && waitingToRead.size() != 0) return false;
		}
		//
		// Nobody is ahead of me.
		//
		//
		if (readCount == 0){
			reading = who;
			readCount++;
			return true;
		}
		//
		// If there is only one thread holding the read lock, that
		// thread MAY be the value of reading. (It could not be me,
		// or that would have been caught above). In that case
		// transfer that value to the Vector and then add me.
		//
		if (readingVector == null) readingVector = new Vector();
		//
		if (reading != null){
			for (int i = 0; i<readCount; i++)
				readingVector.add(reading);
			reading = null;
		}
		readingVector.add(who);
		readCount++;
		return true;
	}
	public final synchronized boolean lock(boolean forWriting, int timeout, boolean allowInterrupt) throws InterruptedException
	{
		if (closed) return false;
		long now = System.currentTimeMillis();
		Thread t = Thread.currentThread();
		//
		if (forWriting ? grabWrite(t,false) : grabRead(t,false)) return true;
		if (timeout == 0) return false;
		if (waitingToWrite == null) {
			waitingToWrite = new Vector();
			waitingToRead = new Vector();
		}
		//
		Vector v = forWriting ? waitingToWrite : waitingToRead;
		v.add(t);
		//
		while(true){
			if (closed) return false;
			if (v.elementAt(0) == t)
				if (forWriting ? grabWrite(t,true) : grabRead(t,true)) {
					v.removeElementAt(0);
					return true;
				}
			try{
				if (!doWait(now,timeout)){
					v.remove(t);
					notifyAll();
					return false;
				}
			}catch(InterruptedException e){
				if (allowInterrupt) throw e;
			}
		}
	}
	/**
	 * This method requests a Read lock and returns if the request
	 * was granted or if the timeout expired or the lock was closed.
	 * A timeout less than zero indicates an infinite timeout. A timeout
	 * of zero means to attempt a "grab" at the lock and not to wait if
	 * it is not immediately available.
	 * @param timeout the time to wait.
	 * @return true if the lock was acquired, false if it timed out
	 * or if the lock was closed.
	 */
	public final synchronized boolean read(int timeout)
	{
		try{
			return lock(false,timeout,false);
		}catch(InterruptedException e){
			return false; //Should never happen.
		}
	}
	/**
	 * This method requests a Read lock and does not return
	 * until it has been satisfied or until the lock is closed.
	 * If you know that the lock will never close then you can
	 * assume that once it returns, the request has been satisfied.
	 */
	public final synchronized boolean read()
	{
		try{
			return lock(false,-1,false);
		}catch(InterruptedException e){
			return false; //Should never happen.
		}
	}
	
	/**
	 * This method requests a Write lock and returns if the request
	 * was granted or if the timeout expired or the lock was closed.
	 * A timeout less than zero indicates an infinite timeout. A timeout
	 * of zero means to attempt a "grab" at the lock and not to wait if
	 * it is not immediately available.
	 * @param timeout the time to wait.
	 * @return true if the lock was acquired, false if it timed out
	 * or if the lock was closed.
	 */
	public final synchronized boolean write(int timeout)
	{
		try{
			return lock(true,timeout,false);
		}catch(InterruptedException e){
			return false; //Should never happen.
		}
	}
	/**
	 * This method requests a Write lock and does not return
	 * until it has been satisfied or until the lock is closed.
	 * If you know that the lock will never close then you can
	 * assume that once it returns, the request has been satisfied.
	 */
	public final synchronized boolean write()
	{
		try{
			return lock(true,-1,false);
		}catch(InterruptedException e){
			return false; //Should never happen.
		}
	}
	/**
	 * Release a read or write lock. If this Thread is the writer
	 * and pauseWriting() was called but resumeWriting was not then
	 * this throws an IllegalThreadStateException.
	 * @throws IllegalThreadStateException
	 */
	public final synchronized void unlock() throws IllegalThreadStateException
	{
		Thread t = Thread.currentThread();
		try{
			if (reading == t) {
				readCount--;
				if (readCount == 0) reading = null;
				return;
			}
			if (readingVector != null){
				int idx = readingVector.indexOf(t);
				if (idx != -1){
					readingVector.removeElementAt(idx);
					readCount--;
					return;
				}
			}
			if (writing == t) {
				if (writingPaused) throw new IllegalThreadStateException("Writer cannot unlock while Writing is paused.");
				writeCount--;
				if (writeCount == 0) writing = null;
				return;
			}
			throw new IllegalThreadStateException("This thread does not hold a lock.");
		}finally{
			notifyAll();
		}
	}
	/**
	 * Only the writer holding the lock can call this. It allows other
	 * Threads to acquire a read lock while writing is paused. Use this
	 * with care - the resource should be in a consistent state and you
	 * should not alter it until resumeWriting() is called.<p>
	 * There <b>cannot</b> be nested calls of pauseWriting().
	 */
	public final synchronized void pauseWriting()
	{
		Thread t = Thread.currentThread();
		if (writing != t) throw new IllegalThreadStateException("Thread does not hold the write lock.");
		if (writingPaused) throw new IllegalThreadStateException("Writing is already paused.");
		if (readCount != 0) throw new IllegalThreadStateException("Cannot pause writing when read lock is held.");
		writingPaused = true;
		notifyAll();
	}
	/**
	 * Only the writer holding the lock can call this after a single
	 * call to pauseWriting().<p>
	 * If Readers did acquire the lock while writing was paused, this
	 * method will not return until they have all released the lock.
	 */
	public final synchronized void resumeWriting()
	{
		Thread t = Thread.currentThread();
		if (writing != t) throw new IllegalThreadStateException("Thread does not hold the write lock.");
		if (!writingPaused) throw new IllegalThreadStateException("Writing is not paused.");
		if (readCount != 0)
			if (reading == t || (readingVector != null && readingVector.contains(t)))
				throw new IllegalThreadStateException("Cannot resume writing Thread has the read lock.");
		writingPaused = false;
		while(readCount != 0){
			try{
				wait();
			}catch(InterruptedException e){}
		}
	}
}
//####################################################
