package eve.database;
import eve.data.DataObject;
import eve.data.PlainDate;
import eve.data.PlainTime;
import eve.math.Decimal;
import eve.sys.Time;
//##################################################################
public class TestData extends DataObject{
//##################################################################

public String lastName = "Brereton";
public String firstNames = "Michael Louis";
public String gender = "M";
public Time dob = new Time(1,1,1980);
public Decimal salary = new Decimal("10000.00");
public int retirementAge = 65;
public boolean smoker = false;
public PlainDate anniversary = new PlainDate(5,8,1994);
public PlainTime birthTime = new PlainTime(10,9,0);

private static int number = 0;

public TestData()
{
	lastName += (++number);
}
//===================================================================
public String getName()
//===================================================================
{
	return lastName+", "+firstNames;
}
/*
public long testCall(int i, double d, String s) throws InterruptedException
{
	System.out.println("I was called: "+i+", "+d+", "+s);
	Thread.sleep(7000);
	System.out.println("I'm returning!");
	return -1234;
}
*/
//##################################################################
}
//##################################################################

