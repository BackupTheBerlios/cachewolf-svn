package eve.database.implement;
import java.io.IOException;

import eve.database.DataValidator;
import eve.database.Database;
import eve.database.DatabaseEntry;
import eve.database.DatabaseTypes;
import eve.sys.Convert;
import eve.util.Encodable;
/**
* Do not use this class directly - it is used and stored internally by the Database.
**/
//##################################################################
public class FieldModifier implements Encodable, DatabaseTypes, DataValidator{
//##################################################################
public int fieldID;
public int fieldType;
public int modifier;
public String modifiedData = "";

private Object metaLocation;
private int nextValue = 0;
private Database db;

//===================================================================
public boolean decodeAfterReading(Database db) throws IOException
//===================================================================
{
	this.db = db;
	if (fieldType == INTEGER && fieldType == db.getFieldType(fieldID)){
		if (modifier == db.FIELD_MODIFIER_INTEGER_AUTO_INCREMENT){
			if (!db.isOpenForReadWrite()) return false;
			int initial = Convert.toInt(modifiedData);
			String name = "AUTO_INCREMENT-"+db.getFieldName(fieldID);
			int size = db.metaDataLength(name);
			metaLocation = db.getMetaData(name,4,false);
			if (size != -1) nextValue = db.readMetaDataInt(metaLocation,0);
			if (nextValue < initial) nextValue = initial;
			//ewe.sys.Vm.debug("Read Next value = "+nextValue);
			return true;
		}
	}
	return false;
}
//-------------------------------------------------------------------
protected int getNextInteger() throws IOException
//-------------------------------------------------------------------
{
	int toReturn = nextValue++;
	//ewe.sys.Vm.debug("Write Next value = "+nextValue);
	db.writeMetaDataInt(metaLocation,0,nextValue);
	return toReturn;
}
//===================================================================
public void modify(DatabaseEntry newData,DatabaseEntry oldData) throws IOException
//===================================================================
{
	if (oldData == null){ 
		//
		// Saving a new one, however if we are synchronizing we may be saving one
		// created on another database. Therefore we should preserve the number if one is
		// set.
		//
		if (modifier == db.FIELD_MODIFIER_INTEGER_AUTO_INCREMENT){
			if (newData.getField(fieldID,0) == 0)
				newData.setField(fieldID,getNextInteger());
		}
	}else if (newData != null && newData != oldData){//Modifying an old one.
		int old = oldData.getField(fieldID,0);
		if (old == 0) old = getNextInteger();
		newData.setField(fieldID,old);
	}
}
//===================================================================
public void validateEntry(Database db,DatabaseEntry newData,DatabaseEntry oldData) throws IOException
//===================================================================
{
	modify(newData,oldData);
}
//===================================================================
public FieldModifier()
//===================================================================
{
	
}
//===================================================================
public void set(Database db,int fieldID,int modifier,Object data)
//===================================================================
{
	this.db = db;
	this.fieldID = fieldID;
	this.modifier = modifier;
	fieldType = db.getFieldType(fieldID);
	if (fieldType == 0) throw new IllegalArgumentException();
	if (fieldType == INTEGER && modifier == db.FIELD_MODIFIER_INTEGER_AUTO_INCREMENT){
		if (!(data instanceof Integer)) throw new IllegalArgumentException();
		modifiedData = Convert.toString((int)((Integer)data).intValue());
	}
}
//##################################################################
}
//##################################################################

