package eve.database.implement;
import java.io.IOException;
import java.util.Hashtable;

import eve.data.PlainDate;
import eve.data.PlainTime;
import eve.database.Database;
import eve.database.DatabaseEntry;
import eve.database.FoundEntries;
import eve.database.TimeStamp;
import eve.math.BigDecimal;
import eve.math.Decimal;
import eve.sys.Cache;
import eve.sys.DayOfYear;
import eve.sys.Locale;
import eve.sys.Time;
import eve.sys.TimeOfDay;
import eve.sys.Vm;
import eve.sys.Wrapper;
import eve.util.ByteArray;
import eve.util.ByteEncodable;
import eve.util.CharArray;
import eve.util.SubString;

//##################################################################
public 
abstract 
class DatabaseEntryObject implements DatabaseEntry{
//##################################################################
//
// Do not move this, it must be first.
//
protected ByteArray myData;
protected DatabaseObject database;
protected boolean isDeleted = false;
protected FoundEntries modifyingInside;
protected Locale locale;
//ByteArray myEncryptedData;
private Hashtable fields;
private Time aTime;
/*
static final ewe.sys.Long longValue = new ewe.sys.Long();
static final ewe.sys.Double doubleValue = new ewe.sys.Double();
static final ewe.sys.Time timeValue = new ewe.sys.Time();
static final ewe.sys.Decimal decimalValue = new ewe.sys.Decimal();
*/
static final Wrapper wrapper = new Wrapper();
//static final SubString substring = new SubString();
//static final ByteArray byteArray = new ByteArray();

public abstract Wrapper getFieldValue(int fieldID, int type, Object data);
protected abstract int discoverType(int field);

/**
 * If the value is a String, convert it to an Object suitable for the specified type.
 * @param value the provided Object value, which may be a String.
 * @param type the type of the field being set.
 * @return a static (possibly shared) object value holding the appropriate data.
 */
/*
//-------------------------------------------------------------------
protected static Object convertStringToStaticObjectValue(Object value, int type)
//-------------------------------------------------------------------
{
	if (!(value instanceof String) || (type == STRING)) return value;
	String s = (String)value;
	switch(type){
		case BOOLEAN:
			return longValue.set(Convert.toBoolean(s) ? 1 : 0);
		case INTEGER: 
			return longValue.set(Convert.toInt(s));
		case LONG:
			return longValue.set(Convert.toLong(s));
		case DOUBLE:
			return doubleValue.set(Convert.toDouble(s));
		case DECIMAL:
			try{
				return new Decimal(s);
			}catch(Exception e){
				return new Decimal(0);
			}
		case TIME: case DATE_TIME: case DATE: case TIMESTAMP:
			timeValue.fromString(s);
			return timeValue;
		default:
			throw new IllegalArgumentException();
	}
}
*/
//-------------------------------------------------------------------
protected DatabaseEntryObject(DatabaseObject database)
//-------------------------------------------------------------------
{
	this.database = database;
	locale = database == null ? Vm.getLocale() : database.getLocale();
}


/**
 * Get the database associated with the FoundEntries.
 */
//===================================================================
public Database getDatabase() {return database;}
//===================================================================
//===================================================================
public boolean isADeletedEntry()
//===================================================================
{
	return isDeleted;
}
//===================================================================
public void reset()
//===================================================================
{
	isDeleted = false;
}

//===================================================================
public void save() throws IllegalStateException, IOException
//===================================================================
{
	if (isADeletedEntry()) throw new IllegalStateException();
	boolean isNew = !isSaved();
	if (aTime == null) aTime = new Time();
	else aTime.setToCurrentTime();
	if (database.hasField(FLAGS_FIELD)){
		int value = getField(FLAGS_FIELD,0);
		value &= ~FLAG_SYNCHRONIZED;
		setField(FLAGS_FIELD,value);
	}
	if (database.hasField(MODIFIED_FIELD)){
		setField(MODIFIED_FIELD,aTime);
	}
	if (database.hasField(MODIFIED_BY_FIELD)){
		setField(MODIFIED_BY_FIELD,database.getIdentifier());
	}
	if (isNew){
		if (database.hasField(OID_FIELD))
			setField(OID_FIELD,database.getNewOID());
		if (database.hasField(CREATED_FIELD))
			setField(CREATED_FIELD,aTime);
	}
	store();
}
//===================================================================
public void delete() throws IOException
//===================================================================
{
	if (isADeletedEntry()) erase();
	else {
		if (!isSaved()) return;
		long oid = hasField(OID_FIELD) ? getField(OID_FIELD,(long)0) : -1;
		if (oid != -1) markAsDeleted();
		else erase();
	}
}

//-------------------------------------------------------------------
protected void markAsDeleted() throws IOException
//-------------------------------------------------------------------
{
	database.markAsDeleted(this);
}
//===================================================================
public void store() throws IllegalStateException, IOException
//===================================================================
{
	if (isADeletedEntry()) throw new IllegalStateException();
	database.store(this);
}
//===================================================================
public void erase() throws IOException
//===================================================================
{
	database.erase(this);
}
//===================================================================
public void revert() throws IllegalStateException, IOException
//===================================================================
{
	if (isADeletedEntry() || !isSaved()) throw new IllegalStateException();
	load();
}
//-------------------------------------------------------------------
protected void load() throws IOException
//-------------------------------------------------------------------
{
	clearDataAndSpecialFields();
	database.load(this);
	isDeleted = false;
}
/**
 * Get the data from the entry into a data object. 
 * @param destination a destination object. If this is null a new one will be created if
 * possible.
 * @return the destination or new object.
 * @exception IllegalArgumentException if the destination object is not the right type.
 * @exception IllegalStateException if a new object was requested but could not be created.
 */
//===================================================================
public Object getData(Object destination) throws IllegalArgumentException, IllegalStateException
//===================================================================
{
	return database.getData(this,destination);
}
/**
 * Get the data from the entry, creating a new data object.
 * @return the new data object.
 * @exception IllegalStateException if a new object could not be created.
 */
//===================================================================
public Object getData() throws IllegalStateException
//===================================================================
{
	return database.getData(this,null);
}
/**
* Set the data in the entry from the data object.
* @param data the data to set.
* @exception IllegalArgumentException if the data object is the wrong type.
*/
//===================================================================
public void setData(Object data) throws IllegalArgumentException
//===================================================================
{
	clearFields();
	database.setData(this,data);
}
//===================================================================
public DatabaseEntry getNew()
//===================================================================
{
	return database.getNewData();
}
//===================================================================
public int compareTo(DatabaseEntry other,int sortID) throws IllegalArgumentException
//===================================================================
{
	return compareTo(other,database.toCriteria(sortID),false);
}
/**
* This is used as a mechanism for automatic data transfer between a DatabaseEntry and 
* a user interface object.
**/
//===================================================================
public boolean _getSetField(String fieldName,Wrapper value,boolean isGet)
//===================================================================
{
	if (isGet) value.zero();
	return _getSetValue(fieldName,value,isGet);
}
/**
* This is used as a mechanism for automatic data transfer between a DatabaseEntry and an
* object that has the same field names.
**/
//===================================================================
public boolean _getSetValue(String fieldName,Wrapper value,boolean isGet)
//===================================================================
{
	try{
	//if (!isGet) System.out.println("Setting: "+fieldName);//+" to: "+value);
	int got = getFieldInfo(fieldName);
	//
	int id = (got >> 16) & 0xffff;
	int type = got & 0xffff;
	//
	if (type == 0) {
		if (isGet) return false;
		switch(value.getType()){
			case Wrapper.CHAR:
			case Wrapper.INT:
			case Wrapper.SHORT:
			case Wrapper.BYTE: type = INTEGER; break;
			case Wrapper.FLOAT:
			case Wrapper.DOUBLE: type = DOUBLE; break;
			case Wrapper.BOOLEAN: type = BOOLEAN; break;
			case Wrapper.LONG: type = LONG; break;
			default:
				Object obj = value.getObject();
				if (obj instanceof String) type = STRING;
				else if (obj instanceof SubString) type = STRING;
				else if (obj instanceof CharArray) type = STRING;
				else if (obj instanceof DayOfYear) type = DATE;
				else if (obj instanceof TimeOfDay) type = TIME;
				else if (obj instanceof TimeStamp) type = TIMESTAMP;
				else if (obj instanceof Time) type = DATE_TIME;
				else if (obj instanceof PlainTime) type = PLAIN_TIME;
				else if (obj instanceof PlainDate) type = PLAIN_DATE;
				else if (obj instanceof byte[]) type = BYTE_ARRAY;
				else if (obj instanceof ByteArray) type = BYTE_ARRAY;
				else if (obj instanceof BigDecimal) type = DECIMAL;
				else if (obj instanceof Decimal) type = DECIMAL;
				else return false;
		}
	}
	//
	if (isGet){
		switch(type){
			case INTEGER: value.setInt(getField(id,0)); break;
			case DOUBLE: value.setDouble(getField(id,(double)0.0)); break;
			case LONG: value.setLong(getField(id,(long)0)); break;
			case BOOLEAN: value.setBoolean(getField(id,false)); break;
			case STRING:
				Object obj = value.getObject();
				if (obj instanceof CharArray) value.setObject(getField(id,(CharArray)obj));
				else {
					String s = getField(id,(String)null);
					value.setObject(s);
				}
				break;//allowNullStrings ? null : "")); break;
			case PLAIN_DATE: case PLAIN_TIME:
			case DATE_TIME: case TIME: case DATE: case TIMESTAMP:
			case DECIMAL:
			case BYTE_ARRAY:
			case JAVA_OBJECT:
			{
				Object read = getFieldValue(id,type,value.getObject());
				//System.out.println("Read: "+fieldName+" = "+read);
				value.setObject(read); 
				break;
			}
			default:
				return false;
		}
	}else{
		switch(type){
			case INTEGER: setField(id,value.getInt()); break;
			case DOUBLE: setField(id,value.getDouble()); break;
			case LONG: setField(id,value.getLong()); break;
			case BOOLEAN: setField(id,value.getBoolean()); break;
			case STRING: 
			case PLAIN_DATE: case PLAIN_TIME:
			case DATE_TIME: case DATE: case TIME: case TIMESTAMP:
			case DECIMAL:
			case BYTE_ARRAY:
			case JAVA_OBJECT:
					setFieldValue(id,type,value.getObject()); break;
			default:
				return false;
		}
	}
	return true;	
	}catch(IllegalStateException e){
		//System.out.println("Error caused by: "+fieldName+" - "+isGet);
		throw e;
	}
}
//===================================================================
public void setFieldValue(int fieldID, Object data)
//===================================================================
{
	setFieldValue(fieldID,fieldToType(fieldID),data);
}
//===================================================================
public Wrapper getFieldValue(int fieldID, Object data)
//===================================================================
{
	return getFieldValue(fieldID,fieldToType(fieldID),data);
}

//===================================================================
public void setField(int fieldID,int value) 
//===================================================================
{
	synchronized(wrapper){
		setFieldValue(fieldID,INTEGER,wrapper.setInt(value));
	}
}
//===================================================================
public void setField(int fieldID,long value) 
//===================================================================
{
	synchronized(wrapper){
		setFieldValue(fieldID,LONG,wrapper.setLong(value));
	}
}
//===================================================================
public void setField(int fieldID,boolean value) 

//===================================================================
{
	setFieldValue(fieldID,BOOLEAN,value ? Boolean.TRUE : Boolean.FALSE);
}
//===================================================================
public void setField(int fieldID,double value) 
//===================================================================
{
	synchronized(wrapper){
		setFieldValue(fieldID,DOUBLE,wrapper.setDouble(value));
	}
}
//===================================================================
public void setField(int fieldID,PlainTime time) 
//===================================================================
{
	setFieldValue(fieldID,PLAIN_TIME,time);
}
//===================================================================
public void setField(int fieldID,PlainDate time) 
//===================================================================
{
	setFieldValue(fieldID,PLAIN_DATE,time);
}
//===================================================================
public void setField(int fieldID,Time time) 
//===================================================================
{
	setFieldValue(fieldID,DATE_TIME,time);
}
//===================================================================
public void setField(int fieldID,TimeOfDay time) 
//===================================================================
{
	setFieldValue(fieldID,TIME,time);
}
//===================================================================
public void setField(int fieldID,DayOfYear date) 
//===================================================================
{
	setFieldValue(fieldID,DATE,date);
}
//===================================================================
public void setField(int fieldID,TimeStamp timestamp) 
//===================================================================
{
	setFieldValue(fieldID,TIMESTAMP,timestamp);
}
//===================================================================
public void setField(int fieldID,BigDecimal value) 
//===================================================================
{
	setFieldValue(fieldID,DECIMAL,value);
}
//===================================================================
public void setField(int fieldID,Decimal value) 
//===================================================================
{
	setFieldValue(fieldID,DECIMAL,value);
}
//===================================================================
public void setField(int fieldID,ByteArray bytes) 
//===================================================================
{
	setFieldValue(fieldID,BYTE_ARRAY,bytes);
}
//===================================================================
public void setField(int fieldID,byte[] bytes) 
//===================================================================
{
	/*
	ByteArray ba = bytes == null ? null : byteArray;
	if (ba != null){
		ba.data = bytes;
		ba.length = bytes.length;
	}
	*/
	setFieldValue(fieldID,BYTE_ARRAY,bytes);
}
//===================================================================
public void setField(int fieldID,SubString chars) 
//===================================================================
{
	setFieldValue(fieldID,STRING,chars);
}
//===================================================================
public void setField(int fieldID,CharArray chars)
//===================================================================
{
	/*
	if (chars == null) setFieldValue(fieldID,STRING,null);
	else{
		substring.data = chars.data;
		substring.start = 0;
		substring.length = chars.length;
		setFieldValue(fieldID,STRING,substring);
	}
	*/
	setFieldValue(fieldID,STRING,chars);
}
//===================================================================
public void setField(int fieldID,String chars) 
//===================================================================
{
	/*
	SubString ss = chars == null ? null : substring;
	if (ss != null){
		ss.data = Vm.getStringChars(chars);
		ss.start = 0;
		ss.length = ss.data.length;
	}
	*/
	setFieldValue(fieldID,STRING,chars);//ss);
}

//===================================================================
public void setField(int fieldID,ByteEncodable value)
//===================================================================
{
	/*
	if (value == null) setFieldValue(fieldID,BYTE_ARRAY,null);
	byteArray.clear();
	value.encodeBytes(byteArray);
	*/
	setFieldValue(fieldID,BYTE_ARRAY,value);//byteArray);
}

/* (non-Javadoc)
 * @see eve.database.DatabaseEntry#setField(int, java.math.BigDecimal)
 */
public void setField(int fieldID, java.math.BigDecimal value) 
{
	setField(fieldID,BigDecimal.toEveBigDecimal(value));
}

//===================================================================
public void setObjectField(int fieldID,Object value)
//===================================================================
{
	setFieldValue(fieldID,JAVA_OBJECT,value);
}
//===================================================================
public Object getObjectField(int fieldID,Object dest)
//===================================================================
{
	return getFieldValue(fieldID,JAVA_OBJECT,dest);
}
//===================================================================
public int getField(int fieldID,int defaultValue)
//===================================================================
{
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,INTEGER,wrapper.setInt(defaultValue));
		return w == null ? defaultValue : w.getInt();
	}
}
//===================================================================
public long getField(int fieldID,long defaultValue)
//===================================================================
{
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,LONG,wrapper.setLong(defaultValue));
		return w == null ? defaultValue : w.getLong();
	}
}
//===================================================================
public boolean getField(int fieldID, boolean defaultValue)
//===================================================================
{
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,BOOLEAN,wrapper.setBoolean(defaultValue));
		return w == null ? defaultValue : w.getBoolean();
	}
}
//===================================================================
public double getField(int fieldID, double defaultValue)
//===================================================================
{
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,DOUBLE,wrapper.setDouble(defaultValue));
		return w == null ? defaultValue : w.getDouble();
	}
}
//===================================================================
public Time getField(int fieldID, Time dest)
//===================================================================
{
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,DATE_TIME,wrapper.setObject(dest));
		return w == null ? null : (Time)w.getObject();
	}
}
//===================================================================
public PlainTime getField(int fieldID, PlainTime dest)
//===================================================================
{
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,PLAIN_TIME,wrapper.setObject(dest));
		return w == null ? null : (PlainTime)w.getObject();
	}
}
//===================================================================
public PlainDate getField(int fieldID, PlainDate dest)
//===================================================================
{
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,PLAIN_DATE,wrapper.setObject(dest));
		return w == null ? null : (PlainDate)w.getObject();
	}
}

//===================================================================
public String getField(int fieldID, String defaultValue)
//===================================================================
{
	CharArray t = (CharArray)Cache.get(CharArray.class);
	try{
		CharArray got = getField(fieldID, t);
		if (got == null) return null;
		return got.toString();
	}finally{
		Cache.put(t);
	}
}
//===================================================================
public CharArray getField(int fieldID, CharArray dest)
//===================================================================
{
	synchronized(wrapper){
		if (dest == null) dest = new CharArray();
		Wrapper w = getFieldValue(fieldID,STRING,wrapper.setObject(dest));
		return w == null ? null : (CharArray)w.getObject();
	}
}
//===================================================================
public byte[] getFieldBytes(int fieldID)
//===================================================================
{
	ByteArray ret = getField(fieldID,new ByteArray());
	if (ret == null) return null;
	return ret.toBytes();
}
//===================================================================
public ByteArray getField(int fieldID,ByteArray dest)
//===================================================================
{
	synchronized(wrapper){
		if (dest == null) dest = new ByteArray();
		Wrapper w = getFieldValue(fieldID,BYTE_ARRAY,wrapper.setObject(dest));
		return w == null ? null : (ByteArray)w.getObject();
	}
}
//===================================================================
public DayOfYear getField(int fieldID, DayOfYear dest)
//===================================================================
{
	if (dest == null) dest = new DayOfYear();
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,DATE,wrapper.setObject(dest));
		return w == null ? null : (DayOfYear)w.getObject();
	}
}
//===================================================================
public TimeOfDay getField(int fieldID, TimeOfDay dest)
//===================================================================
{
	if (dest == null) dest = new TimeOfDay();
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,TIME,wrapper.setObject(dest));
		return w == null ? null : (TimeOfDay)w.getObject();
	}
}
//===================================================================
public TimeStamp getField(int fieldID, TimeStamp dest)
//===================================================================
{
	if (dest == null) dest = new TimeStamp();
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,TIMESTAMP,wrapper.setObject(dest));
		return w == null ? null : (TimeStamp)w.getObject();
	}
}
//===================================================================
public java.math.BigDecimal getField(int fieldID, java.math.BigDecimal defaultValue)
//===================================================================
{
	Decimal d = getField(fieldID,(Decimal)null);
	if (d == null) return defaultValue;
	return d.getJavaBigDecimal();
}
//===================================================================
public BigDecimal getField(int fieldID, BigDecimal defaultValue)
//===================================================================
{
	Decimal d = getField(fieldID,(Decimal)null);
	if (d == null) return defaultValue;
	return d.getBigDecimal();
}
//===================================================================
public Decimal getField(int fieldID,Decimal dest)
//===================================================================
{
	if (dest == null) dest = new Decimal();
	synchronized(wrapper){
		Wrapper w = getFieldValue(fieldID,DECIMAL,wrapper.setObject(dest));
		return w == null ? null : (Decimal)w.getObject();
	}
}
//===================================================================
public int[] getAssignedFields()
//===================================================================
{
	int num = countAssignedFields();
	int [] ret = new int[num];
	getAssignedFields(ret,0);
	return ret;
}
//-------------------------------------------------------------------

/**
Return the field info as the id|type.
**/
protected synchronized int getFieldInfo(String fieldName)
//-------------------------------------------------------------------
{
	if (fields != null) {
		Integer found = (Integer)fields.get(fieldName);
		if (found != null) return ((Integer)found).intValue();
	}
	int id = database.findField(fieldName);
	int type = id == 0 ? 0 : database.getFieldType(id);
	int got = ((id & 0xffff)<<16)|(type & 0xffff);
	if (false){
		if (fields == null) fields = new Hashtable();
		fields.put(fieldName,new Integer(got));
	}
	return got;
}

//-------------------------------------------------------------------
protected int fieldToID(String fieldName)
//-------------------------------------------------------------------
{
	int got = getFieldInfo(fieldName);
	return (got >> 16) & 0xffff;
}
//-------------------------------------------------------------------
protected String getFieldName(int id)
//-------------------------------------------------------------------
{
	return database.getFieldName(id);
}
//-------------------------------------------------------------------
protected int fieldToType(int field)
//-------------------------------------------------------------------
{
	int type = database.getFieldType(field);
	if (type != 0) return type;
	return discoverType(field);

}
//-------------------------------------------------------------------
protected String dump()
//-------------------------------------------------------------------
{
	int [] all = getAssignedFields();
	StringBuffer sb = new StringBuffer();
	if (all.length != 0)
		for (int i = 0; i<all.length; i++){
			sb.append(getFieldName(all[i])+" = ");
			Object fv = getFieldValue(all[i],fieldToType(all[i]),null);
			sb.append(""+fv);
			if (i != all.length-1) sb.append(", ");
		}
	else
		sb.append("<empty>");
	return sb.toString();
}
//===================================================================
public String toString() 
//===================================================================
{
	return dump();
}
//===================================================================
public void duplicateFrom(DatabaseEntry other)
//===================================================================
{
	byte[] all = other.encode();
	decode(all,0,all.length);
}
//===================================================================
public byte[] encode()
//===================================================================
{
	try{
		ByteArray got = encode(null,null);
		return got.toBytes();
	}catch(Exception e){
		return null;
	}
}
//===================================================================
public boolean decode(byte[] source,int offset,int length)
//===================================================================
{
	try{
		decode(source,offset,length,null);
		return true;
	}catch(Exception e){
		return false;
	}
}
/**
 * Get a set of fields from the DatabaseEntry.
 * @param fieldIDs the field IDs.
 * @param destinationObjectsAndWrappers the destination Object and/or Wrappers
 * to hold the data. See getFieldValue() to see the destination types to use.
 */
public void getFieldValues(int[] fieldIDs, Object[] destinationObjectsAndWrappers)
{
	for (int i = 0; i<fieldIDs.length; i++)
		getFieldValue(fieldIDs[i], destinationObjectsAndWrappers[i]);
}
/**
 * set a set of fields from the DatabaseEntry.
 * @param fieldIDs the field IDs.
 * @param sourceObjectsAndWrappers the source Object and/or Wrappers
 * to hold the data. See getFieldValue() to see the destination types to use.
 */
public void setFieldValues(int[] fieldIDs, Object[] sourceObjectsAndWrappers)
{
	for (int i = 0; i<fieldIDs.length; i++)
		setFieldValue(fieldIDs[i], sourceObjectsAndWrappers[i]);
}

//##################################################################
}
//##################################################################

