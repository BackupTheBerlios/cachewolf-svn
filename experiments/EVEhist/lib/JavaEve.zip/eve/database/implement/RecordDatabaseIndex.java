package eve.database.implement;
import java.io.IOException;

import eve.data.PropertyList;
import eve.database.Database;
import eve.database.FoundEntries;
import eve.sys.Handle;

//##################################################################
public class RecordDatabaseIndex extends RecordFoundEntries implements DatabaseIndex{
//##################################################################
public String name;

//===================================================================
public String getName() 
//===================================================================
{
	return name;
}

protected PropertyList pl = new PropertyList();
{
	isAllInclusive = true;
}
//===================================================================
public boolean needsCompacting() throws IOException
//===================================================================
{
	return needCompact;
}
//===================================================================
public boolean compact(Handle h) throws IOException
//===================================================================
{
	if (!((DatabaseObject)database).saveIndex(h,(DatabaseIndex)this))
		return false;
	needCompact = false;
	return true;
}

//===================================================================
public PropertyList getProperties()
//===================================================================
{
	return pl;
}
//-------------------------------------------------------------------
protected RecordDatabaseIndex(Database database,String name)
//-------------------------------------------------------------------
{
	super(database);	
	this.name = name;
}
//===================================================================
public FoundEntries getEntries()
//===================================================================
{
	RecordFoundEntries fe = (RecordFoundEntries)getNewFoundEntries();
	fe.ids.length = ids.length;
	fe.ids.data = new int[ids.length];
	System.arraycopy(ids.data,0,fe.ids.data,0,ids.length);
	return fe;
}
//##################################################################
}
//##################################################################

