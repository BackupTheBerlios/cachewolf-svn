package eve.database.implement;
import eve.database.DatabaseUtils;
import eve.util.Encodable;
//##################################################################
public class FieldSortEntry implements Encodable{
//##################################################################
//Don't move these!
public int id; //Should be first.
public int type; //Should be second. 
public int field1,field2,field3,field4; //Should be 3rd, 4th, 5th, 6th
int type1,type2,type3,type4; //Should be 7th,8th,9th,10th
//......................................................
public String name = "", header = "";

//===================================================================
public FieldSortEntry()
//===================================================================
{
	
}
//===================================================================
public String toString()
//===================================================================
{
	String s = id+", "+type;
	if (field1 == 0) return s;
	s += " = "+field1+", "+type1+"; ";
	if (field2 == 0) return s;
	s += field2+", "+type2+"; ";
	if (field3 == 0) return s;
	s += field3+", "+type3+"; ";
	if (field4 == 0) return s;
	s += field4+", "+type4+"; ";
	return s;
}
//-------------------------------------------------------------------
static int toCriteria(int field, int type, int options)
//-------------------------------------------------------------------
{
	return DatabaseUtils.toCriteria(field,type,options);
}

//-------------------------------------------------------------------
int[] toCriteria()
//-------------------------------------------------------------------
{
	int count = 4;
	if (field1 == 0) count = 0;
	else if (field2 == 0) count = 1;
	else if (field3 == 0) count = 2;
	else if (field4 == 0) count = 3;
	else count = 4;
	int[] all = new int[count];
	if (count == 0) return all;
	all[0] = toCriteria(field1,type1,type);
	if (count == 1) return all;
	all[1] = toCriteria(field2,type2,type);
	if (count == 2) return all;
	all[2] = toCriteria(field3,type3,type);
	if (count == 3) return all;
	all[3] = toCriteria(field4,type4,type);
	return all;
}
/*
//-------------------------------------------------------------------
boolean isDescending()
//-------------------------------------------------------------------
{
	return ((type & DatabaseTypes.SORT_DESCENDING) != 0);
}
*/
//##################################################################
}
//##################################################################

