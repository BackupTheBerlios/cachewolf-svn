package eve.database;

import eve.sys.Event;

//##################################################################
public class DatabaseEvent extends Event{
//##################################################################
public static final int ENTRY_DELETED = 1;
public static final int ENTRY_CHANGED = 2;
public static final int ENTRY_ADDED = 3;
public static final int DELETED_ENTRY_ERASED = 4;

//===================================================================
public DatabaseEvent(int type,Object target)
//===================================================================
{
	this.type = type;
	this.target = target;
}
//##################################################################
}
//##################################################################

