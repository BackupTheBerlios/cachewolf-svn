package eve.database;

import java.io.IOException;

/**
This error indicates that data within the Database is Encrypted but no suitable
decryptor is available to decrypt the data.
**/
//##################################################################
public class EncryptedDataException extends IOException{
//##################################################################

//===================================================================
public EncryptedDataException(){super("Data is Encrypted");}
//===================================================================

//##################################################################
}
//##################################################################

