package eve.database;
import java.io.IOException;

import eve.io.DataProcessor;
import eve.math.BigDecimal;
import eve.math.Decimal;
import eve.sys.DayOfYear;
import eve.sys.Time;
import eve.sys.TimeOfDay;
import eve.sys.Wrapper;
import eve.util.ByteArray;
import eve.util.CharArray;
import eve.util.SubString;
//##################################################################
public interface DatabaseEntry extends DatabaseTypes{
//##################################################################
/**
 * Get the database associated with the FoundEntries.
 */
//===================================================================
public Database getDatabase();
//===================================================================

//===================================================================
public boolean isSaved();
public boolean isADeletedEntry();
public boolean hasField(int ID);
public int countAssignedFields();
public int getAssignedFields(int[] dest,int offset);
public int[] getAssignedFields();
//===================================================================

//===================================================================
public void setField(int fieldID,int value);
//===================================================================
//===================================================================
public void setField(int fieldID,long value);
//===================================================================
//===================================================================
public void setField(int fieldID,boolean value);
//===================================================================
//===================================================================
public void setField(int fieldID,double value);
//===================================================================
//===================================================================
public void setField(int fieldID,TimeOfDay value);
//===================================================================
//===================================================================
public void setField(int fieldID,DayOfYear value);
//===================================================================
//===================================================================
public void setField(int fieldID,TimeStamp value);
//===================================================================
//===================================================================
public void setField(int fieldID,Time time);
//===================================================================
//===================================================================
public void setField(int fieldID,ByteArray bytes);
//===================================================================
//===================================================================
public void setField(int fieldID,byte[] bytes);
//===================================================================
//===================================================================
public void setField(int fieldID,SubString chars);
//===================================================================
//===================================================================
public void setField(int fieldID,CharArray chars);
//===================================================================
//===================================================================
public void setField(int fieldID,String chars);
//===================================================================
public void setField(int fieldID,BigDecimal value);
public void setField(int fieldID,java.math.BigDecimal value);
//===================================================================
public void setField(int fieldID,Decimal value);
//===================================================================
public void setObjectField(int fieldID,Object value);
//===================================================================

//===================================================================
public void setFieldValue(int fieldID, int type, Object data);
public void setFieldValue(int fieldID, Object data);
//===================================================================


/**
 * Get the data stored in a Wrapper.
 * @param fieldID the field ID.
 * @param type the expected type of the field.
 * @param destDataOrDestWrapper this can be a destination Wrapper, which itself
 * may have a destination object already set, or it can be a destination Object
 * itself. The destination Object is NOT used for primitive types such as INTEGER, LONG,
 * DOUBLE or BOOLEAN, but a destination Wrapper can be used. The acceptable destination objects for other types are:
 * <pre>
 * BYTE_ARRAY - eve.util.ByteArray
 * STRING     - eve.util.CharArray
 * PLAIN_DATE - eve.data.PlainDate
 * PLAIN_TIME - eve.data.PlainTime
 * DATE_TIME  - eve.sys.Time
 * DATE       - eve.sys.DayOfYear
 * TIME       - eve.sys.TimeOfDay
 * DECIMAL    - eve.sys.Decimal
 * TIMESTAMP  - eve.database.TimeStamp
 * </pre>
 * @return a new Wrapper or provided destination Wrapper holding the found data, or
 * null if no data was found for that field. If the field data IS present, but is null, then a Wrapper is returned
 * with its object value set at null.
 */
public Wrapper getFieldValue(int fieldID, int type, Object destDataOrDestWrapper);

/**
 * Get the data stored in a Wrapper, assuming that the type of the field will be known
 * to the DatabaseEntry.
 * @param fieldID the field ID.
 * @param destDataOrDestWrapper this can be a destination Wrapper, which itself
 * may have a destination object already set, or it can be a destination Object
 * itself. The destination Object is NOT used for primitive types such as INTEGER, LONG,
 * DOUBLE or BOOLEAN, but a destination Wrapper can be used. The acceptable destination objects for other types are:
 * <pre>
 * BYTE_ARRAY - eve.util.ByteArray
 * STRING     - eve.util.CharArray
 * PLAIN_DATE - eve.data.PlainDate
 * PLAIN_TIME - eve.data.PlainTime
 * DATE_TIME  - eve.sys.Time
 * DATE       - eve.sys.DayOfYear
 * TIME       - eve.sys.TimeOfDay
 * DECIMAL    - eve.sys.Decimal
 * TIMESTAMP  - eve.database.TimeStamp
 * </pre>
 * @return a new Wrapper or provided destination Wrapper holding the found data, or
 * null if no data was found for that field.
 */
public Wrapper getFieldValue(int fieldID, Object destDataOrDestWrapper);
//===================================================================
//===================================================================
public int getField(int fieldID,int defaultValue);
//===================================================================
//===================================================================
public long getField(int fieldID,long defaultValue);
//===================================================================
//===================================================================
public boolean getField(int fieldID, boolean defaultValue);
//===================================================================
//===================================================================
public double getField(int fieldID, double defaultValue);
//===================================================================
//===================================================================
public Time getField(int fieldID, Time dest);
//===================================================================
//===================================================================
public DayOfYear getField(int fieldID, DayOfYear dest);
//===================================================================
//===================================================================
public TimeOfDay getField(int fieldID, TimeOfDay dest);
//===================================================================
//===================================================================
public TimeStamp getField(int fieldID, TimeStamp dest);
//===================================================================
//===================================================================
public BigDecimal getField(int fieldID, BigDecimal defaultValue);
//===================================================================
//===================================================================
public java.math.BigDecimal getField(int fieldID, java.math.BigDecimal defaultValue);
//===================================================================
//===================================================================
public Decimal getField(int fieldID, Decimal dest);
//===================================================================
//===================================================================
public String getField(int fieldID, String defaultValue);
//===================================================================
//===================================================================
public CharArray getField(int fieldID, CharArray dest);
//===================================================================
//===================================================================
public ByteArray getField(int fieldID,ByteArray dest);
//===================================================================
public Object getObjectField(int fieldID,Object dest);
//===================================================================
public byte[] getFieldBytes(int fieldID);
//===================================================================
/**
* Get the ByteArray that holds the record's encoded data. This is used
* for saving the data. This is the records actual data, not a copy of it, so do not write
* to the returned ByteArray.
**/
//===================================================================
//public ByteArray getDataForSaving();
//===================================================================
/**
* This will place the encoded record data in the destination ByteArray, <b>clearing it first</b>
* and possibly encrypting it first (if encryptor is not null). The returned value is always
* a copy of the record's data.
* @param destination The destination for the data. If it is null a new one will be created.
* @param encryptor An optional encryptor for the data.
* @return The destination byte array with the data for the record starting at index 0.
* @exception IOException if there is an error encrypting the data.
*/
//===================================================================
//public ByteArray getDataForSaving(ByteArray destination,DataProcessor encryptor) throws IOException
//===================================================================
/**
* Get the ByteArray that holds the record's encoded data. This is used
* for reading in data to the Entry and will clear the current data.
* After placing the data in the ByteArray, call decode() to decode and validate the data.
**/
//===================================================================
//public ByteArray getDataForLoading()
//===================================================================
/**
 * This will save or add the entry into the database. The database may decide to add or alter
 * fields within the entry (e.g. the modified time field).
 * @exception IllegalStateException if the entry is a deleted entry or otherwise cannot be saved.
 * @exception IOException on error.
 */
//===================================================================
public void save() throws IllegalStateException, IOException;
//===================================================================
/**
 * This will store and add (if necessary) the entry into the database with <b>no</b> modifications.
 * @exception IllegalStateException if the entry is a deleted entry or otherwise cannot be saved.
 * @exception IOException on error.
 */
//===================================================================
public void store() throws IllegalStateException, IOException;
//===================================================================
/**
 * This will delete the entry from the database. The database may decide
 * to mark the entry as deleted, saving the object ID and delete time.
 * @exception IOException on error.
 */
//===================================================================
public void delete() throws IOException;
//===================================================================
/**
 * This will erase the entry from the database. The database will not
 * mark it as deleted.
 */
//===================================================================
public void erase() throws IOException;
//===================================================================
/**
 * Reload the entries data.
 * @exception IllegalStateException if the entry's data could not be reloaded, because
 * it was deleted, erased or reset.
 * @exception IOException 
 */
//===================================================================
public void revert() throws IllegalStateException, IOException;
//===================================================================
/**
* Reset the entry to be an empty entry, as if it had just been returned by Database.getNewData()
**/
//===================================================================
public void reset();
//===================================================================
/**
* Set the specified field to be unassigned.
**/
//===================================================================
public void clearField(int fieldID);
//===================================================================
/**
* Clears the data fields but not the special fields.
**/
//===================================================================
public void clearFields();
//===================================================================
/**
* Clears the data fields and the special fields. Use this with care.
**/
//===================================================================
public void clearDataAndSpecialFields();
//===================================================================

/**
* Compare this entry with another based on the sortID stored in the database (ignoring
* the SORT_DESCENDING option).
**/
//===================================================================
public int compareTo(DatabaseEntry other, int sortID) throws IllegalArgumentException;
//===================================================================
/**
* Compare this entry with another based on an arbitrary sort criteria.
**/
//===================================================================
public int compareTo(DatabaseEntry other,int[] sortCriteria,boolean hasWildCards) throws IllegalArgumentException;
//===================================================================
/**
 * Get the data from the entry into a data object. 
 * @param destination a destination object. If this is null a new one will be created if
 * possible.
 * @return the destination or new object.
 * @exception IllegalArgumentException if the destination object is not the right type.
 * @exception IllegalStateException if a new object was requested but could not be created.
 */
//===================================================================
public Object getData(Object destination) throws IllegalArgumentException, IllegalStateException;
//===================================================================
/**
 * Get the data from the entry, creating a new data object.
 * @return the new data object.
 * @exception IllegalStateException if a new object could not be created.
 */
//===================================================================
public Object getData() throws IllegalStateException;
//===================================================================
/**
* Set the data in the entry from the data object.
* @param data the data to set.
* @exception IllegalArgumentException if the data object is the wrong type.
*/
//===================================================================
public void setData(Object data) throws IllegalArgumentException;
//===================================================================

//===================================================================
public void pointTo(DatabaseEntry other) throws IllegalArgumentException;
//===================================================================

//===================================================================
public boolean isPointingTo(DatabaseEntry other) throws IllegalArgumentException;
//===================================================================
/**
 * Decode an encoded DatabaseEntry.
 * @param data the encoded data bytes.
 * @param offset the start of the data.
 * @param length the number of data bytes.
 * @param decryptor an optional decryptor for decoding.
 * @exception IOException if the data is invalid or if the decryptor failed during decryption.
 */
//===================================================================
public void decode(byte[] data, int offset, int length, DataProcessor decryptor)
throws IOException;
//===================================================================
/**
 * Encode and append the data to the supplied ByteArray object.
 * @param dest the destination ByteArray object.
 * @param encryptor an optional encryptor for encrypting the data.
 * @return the destination ByteArray object or a new one if dest is null.
 * @exception IOException if the encryptor failed during decryption.
 */
//===================================================================
public ByteArray encode(ByteArray dest,DataProcessor encryptor)
throws IOException;
//===================================================================

//===================================================================
public boolean decode(byte[] data,int offset,int length);
//===================================================================
//===================================================================
public byte[] encode();
//===================================================================
/**
 * Duplicate all set fields in this DatabaseEntry with those from the other.
 */
//===================================================================
public void duplicateFrom(DatabaseEntry other);
/**
 * Get a set of fields from the DatabaseEntry.
 * @param fieldIDs the field IDs.
 * @param destinationObjectsAndWrappers the destination Object and/or Wrappers
 * to hold the data. See getFieldValue() to see the destination types to use.
 */
public void getFieldValues(int[] fieldIDs, Object[] destinationObjectsAndWrappers);
/**
 * set a set of fields from the DatabaseEntry.
 * @param fieldIDs the field IDs.
 * @param sourceObjectsAndWrappers the source Object and/or Wrappers
 * to hold the data. See getFieldValue() to see the destination types to use.
 */
public void setFieldValues(int[] fieldIDs, Object[] sourceObjectsAndWrappers);

//##################################################################
}
//##################################################################


