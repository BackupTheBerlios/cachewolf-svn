package eve.database;

import java.io.IOException;
import java.util.Vector;

public interface IRemoteSynchronizer {

	/** 
	 * An option for getSetOptions() - it specifies that all entries
	 * should be considered unsynchronized. Useful when synchronizing
	 * a database with a new database.
	 */
	public static final int OPTION_SYNCHRONIZE_ALL_ENTRIES = 0x1;
	/**
	 * This will set the optionsToSet bits and clear the optionsToClear bits
	 * and return the state of the options after the operation is done.
	 * @param optionsToSet any or none of the OPTION_XXX bits OR'ed together.
	 * @param optionsToClear any or none of the OPTION_XXX bits OR'ed together.
	 * @return the state of the options after the operation is done.
	 */
	public int getSetOptions(int optionsToSet, int optionsToClear);
	
	public int countUnsynchronizedEntries() throws IOException;
	/**
	 * Return a Vector containing byte[] values for each database entry
	 * requested. The indexes here are based on the value returned by
	 * countUnsynchronizedEntries();
	 * @param startIndex the first index in the unsynchronized list to get.
	 * @param count the number of database entries to get.
	 * @return a Vector containing a byte[] for each database entry. The
	 * DatabaseEntry.decode() method should be used to decode the entry.
	 * @throws IOException
	 */
	public Vector getUnsynchronizedEntries(int startIndex, int count) throws IOException;
	/**
	 * Mark the entries in the unsynchronized list as being synchronized.
	 * @param indexes the indexes to mark as synchronized.
	 * @param offset the start of the indexes in the array.
	 * @param length the number of indexes to delete.
	 * @throws IOException
	 */
	public void markAsSynchronized(int [] indexes,int offset,int length) throws IOException;
	/**
	 * Add entries to the database.
	 * @param entries the list of entries, each one of which is a byte[].
	 * Each of these is convereted to a DatabaseEntry using the decode()
	 * method.
	 * @throws IOException
	 */
	public void addEntries(Vector entries) throws IOException;
	/**
	 * Erases the entries as specified by the OID values. If an entry does
	 * not exist on the database it is ignored.
	 * @param oids the list entries to erase.
	 * @param offset the start of the OIDs in the array.
	 * @param length the number of OIDs to delete.
	 * @throws IOException
	 */
	public void eraseEntries(long[] oids,int offset, int length) throws IOException;	
	
	/**
	 * Returns the number of deleted entries.
	 * @throws IOException
	 */
	public int countDeletedEntries() throws IOException;
	/**
	 * Returns an array of OID values for the specified deleted entries. The
	 * index is relative to the value returned by countDeletedEntries().
	 * @param startIndex the index of the first deleted entry.
	 * @param count the number of deleted entries to get.
	 * @return an array of OID values for each deleted entry.
	 * @throws IOException
	 */
	public long [] getDeletedEntries(int startIndex, int count) throws IOException;
	/**
	 * Erase the entries at the specified indexes. Note that this should not
	 * change the indexes.
	 * @param indexesToDelete the list of deleted intries to delete.
	 * @param offset the start of the indexes in the array.
	 * @param length the number of indexes to delete.
	 * @throws IOException
	 */
	public void eraseDeleted(int[] indexesToDelete,int offset,int length) throws IOException;
}
