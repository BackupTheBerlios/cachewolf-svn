package eve.database;

/**
* This is thrown by Database.getEntries() if the specified criteria returns
* too many entries than can be represented by a FoundEntries() object. 
**/
//##################################################################
public class DataTooBigException extends RuntimeException{
//##################################################################


//##################################################################
}
//##################################################################

