package eve.database;
import eve.io.File;
import java.io.IOException;

//##################################################################
public interface DatabaseMaker{
//##################################################################
/**
 * This should open the specified database. If mode is "rw" and the Database
 * does not exist, it should create it and initialize it as being empty.
 * @param name The name for the database (either with our without a file extension).
 * @param mode The mode for opening, either "r" or "rw" or "a".
 * @return The open Database.
 * @exception IOException if the database was not found or could not be opened or initialized.
 */
//===================================================================
public Database openDatabase(String name, String mode) throws IOException;
//===================================================================
/**
 * This should open the specified database. If mode is "rw" and the Database
 * does not exist, it should create it and initialize it as being empty.
 * @param name A File object referring to the Database (either with our without a file extension).
 * @param mode The mode for opening, either "r" or "rw".
 * @return The open Database.
 * @exception IOException if the database was not found or could not be opened or initialized.
 */
//===================================================================
public Database openDatabase(File name, String mode) throws IOException;
//===================================================================
/**
 * This should open the specified database. If mode is "rw" and the Database
 * does not exist, it should create it and initialize it as being empty.
 * @param name The name for the database (either with our without a file extension).
 * @param mode The mode for opening, either "r" or "rw" or "a".
 * @return The open Database.
 * @exception IOException if the database was not found or could not be opened or initialized.
 */
//===================================================================
public Database openDatabase(String name, String mode, boolean ignoreInconsistentState) throws IOException;
//===================================================================
/**
 * This should open the specified database. If mode is "rw" and the Database
 * does not exist, it should create it and initialize it as being empty.
 * @param name A File object referring to the Database (either with our without a file extension).
 * @param mode The mode for opening, either "r" or "rw".
 * @return The open Database.
 * @exception IOException if the database was not found or could not be opened or initialized.
 */
//===================================================================
public Database openDatabase(File name, String mode, boolean ignoreInconsistentState) throws IOException;
//===================================================================

//===================================================================
public boolean databaseExists(String name);
//===================================================================
//===================================================================
public boolean databaseExists(File name);
//===================================================================
//===================================================================
public boolean databaseIsValid(String name);
//===================================================================
public boolean databaseIsValid(File name);
//===================================================================
public boolean canOpenForWriting(String name);
//===================================================================
public boolean canOpenForWriting(File name);
//===================================================================

//##################################################################
}
//##################################################################

