package eve.database;

//##################################################################
public class StandardEntryComparer extends EntryComparer{
//##################################################################
private int [] criteria;
{
	compareAsDatabaseEntries = true;
}
//===================================================================
public int[] getCriteria()
//===================================================================
{
	return DatabaseUtils.copyCriteria(criteria);
}
//===================================================================
public StandardEntryComparer(Database db, int sortID) throws IllegalArgumentException
//===================================================================
{
	this(db,db.toCriteria(sortID));
}
//===================================================================
public StandardEntryComparer(Database db, int[] criteria) throws IllegalArgumentException
//===================================================================
{
	super(db);
	if (criteria == null) throw new NullPointerException();
	this.criteria = DatabaseUtils.copyCriteria(criteria);
}
//===================================================================
public EntrySelector toEntrySelector(Object searchData, boolean hasWildCards)
//===================================================================
{/*
	if (searchData instanceof Object[]){
		int num = ((Object[])searchData).length;
		if (num > criteria.length) num = criteria.length;
		return new EntrySelector(db,searchData,DatabaseUtils.getCriteriaSubset(criteria,num),hasWildCards);
	}
	*/
	return new EntrySelector(db,searchData,criteria,hasWildCards);
}
//-------------------------------------------------------------------
protected int compareEntries(Object one, Object two)
//-------------------------------------------------------------------
{
	if (one == two) return 0;
	if (one == null) return -1;
	else if (two == null) return 1;
	else return ((DatabaseEntry)one).compareTo((DatabaseEntry)two,criteria,false);
}

//##################################################################
}
//##################################################################

