package eve.database;
import eve.sys.Reflection;
import eve.util.Encodable;

//##################################################################
public class IndexEntry implements Encodable{
//##################################################################

public String comparerClassName;
public int sortID;
public String name;

private Class comparerClass;

//===================================================================
public boolean hasCustomComparer()
//===================================================================
{
	return (comparerClassName != null && comparerClassName.length() != 0);
}
//===================================================================
public Class getCustomComparerClass()
//===================================================================
{
	if (comparerClassName == null || comparerClassName.length() == 0)
		return null;
	if (comparerClass == null) comparerClass = Reflection.forName(comparerClassName);
	return comparerClass;
}
//===================================================================
public DatabaseEntryComparer getCustomComparerInstance(Database forDatabase)
//===================================================================
{
	Class c = getCustomComparerClass();
	if (c == null) return null;
	try{
		DatabaseEntryComparer dc = (DatabaseEntryComparer)c.newInstance();
		dc.setDatabase(forDatabase);
		return dc;
	}catch(Exception e){
		return null;
	}
}
//-------------------------------------------------------------------
public IndexEntry getCopy()
//-------------------------------------------------------------------
{
	IndexEntry ie = new IndexEntry();
	ie.comparerClassName = comparerClassName;
	ie.sortID = sortID;
	ie.name = name;
	ie.comparerClass = comparerClass;
	return ie;
}
//===================================================================
public String toString()
//===================================================================
{
	return name;
}
//##################################################################
}
//##################################################################

