package eve.database;
import java.io.IOException;

import eve.sys.Vm;

//##################################################################
public class DatabaseIOException extends RuntimeException{
//##################################################################

//===================================================================
public DatabaseIOException(IOException e)
//===================================================================
{
	super(e.getMessage());
	Vm.setCause(this,e);
}
//===================================================================
public IOException toIOException()
//===================================================================
{
	Throwable t = Vm.getCause(this);
	if (t instanceof IOException) return (IOException)t;
	IOException e = new IOException(getMessage());
	Vm.setCause(e,this);
	return e;
}
//##################################################################
}
//##################################################################


