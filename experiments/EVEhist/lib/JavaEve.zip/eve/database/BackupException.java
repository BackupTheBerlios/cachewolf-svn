/*
 * Created on May 3, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.database;

import java.io.IOException;

import eve.sys.Vm;

/**
 * @author Michael L Brereton
 * This Exception is thrown by SafeDBAccess if an error occurs during the backup process.
 */
//####################################################
public class BackupException extends IOException {

	/**
	 * @param msg
	 */
	public BackupException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	public BackupException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public BackupException(Throwable cause) {
		super();
		Vm.setCause(this,cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public BackupException(String message, Throwable cause) {
		super(message);
		Vm.setCause(this,cause);
	}

}

//####################################################
