/*
 * Created on May 3, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.database;

import java.io.IOException;

import eve.sys.Vm;

/**
 * @author Michael L Brereton
 * This exception is thrown by SafeDBAccess to indicate that a Restore operation
 * failed.
 */
//####################################################
public class RestoreException extends IOException {

	public RestoreException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	public RestoreException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RestoreException(Throwable cause) {
		super();
		Vm.setCause(this,cause);
		// TODO Auto-generated constructor stub
	}

	public RestoreException(String message, Throwable cause) {
		super(message);
		Vm.setCause(this,cause);
	}

}

//####################################################
