package eve.database;
import java.io.IOException;
/**
This is an IOException that indicates that the operation requested is illegal based
on the current state of the Database. The most common cause of this is unsynchronized
access to the Database by two threads.
**/
//##################################################################
public class DatabaseOperationException extends IOException{
//##################################################################

public DatabaseOperationException(String message) {super(message);}

//##################################################################
}
//##################################################################

