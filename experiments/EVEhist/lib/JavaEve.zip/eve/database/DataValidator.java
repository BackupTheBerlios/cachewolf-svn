package eve.database;

import java.io.IOException;

//##################################################################
public interface DataValidator{
//##################################################################
/**
This method can be used to either alter data before it is saved into the database or
to abort a particular operation by throwing an InvalidDataException.
<p>This method is called under four circumstances.
<nl>
<li>When a new DatabaseEntry is being saved - in which case the newData parameter
holds the new data while the oldData parameter will be null.
<li>When a DatabaseEntry is being modified - in which case the newData parameter
holds the new data while the oldData parameter will hold the old data.
<li>When a DatabaseEntry is being deleted - in which case the newData parameter
will be null while the oldData parameter will hold the old data.
<li>When a DatabaseEntry is being read - in which case the newData parameter refers
to the same object as the oldData parameter (i.e. newData == oldData).
</nl>
<p>
 * @param database The Database that holds the data.
 * @param newData The data being saved or changed or read. If you need to modify the data,
 * then modify this parameter.
 * @param oldData The original data before the change or deletion.
 * @exception InvalidDataException If the operation should be disallowed due to bad data.
 */
//===================================================================
public void validateEntry(Database database,DatabaseEntry newData,DatabaseEntry oldData) throws InvalidDataException, IOException;
//===================================================================

//##################################################################
}
//##################################################################


