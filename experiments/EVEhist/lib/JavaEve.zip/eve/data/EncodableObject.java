/*
 * Created on Jul 1, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.data;

import java.lang.reflect.Field;

import eve.sys.Reflection;
import eve.sys.Wrapper;
import eve.util.TextDecoder;
import eve.util.TextEncodable;
import eve.util.TextEncoder;
import eve.util.mString;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class EncodableObject extends DataObject implements TextEncodable{

	/**
	* You can override this to encode the object as a String, but it is easier to override
	* encode(TextEncoder te).
	**/
//	===================================================================
	public String textEncode() 
//	===================================================================
	{
		TextEncoder te = new TextEncoder();
		encode(te);
		return encoded(te.toString());
	}
	/**
	* You can override this to decode a String representation of the Object as
	* encoded by textEncode, but it is easier to override decode(TextDecoder te).
	**/
//	===================================================================
	public void textDecode(String txt)
//	===================================================================
	{
		TextDecoder td = new TextDecoder(txt);
		decode(td);
		decoded(txt);
	}
	/**
	* You can call this within your encode(TextEncoder te) method to encode specific
	* fields.
	* @param fields An array of fields.
	* @param te A TextEncoder object.
	* @param baseName Either the fully qualified class and package name or the class name (without package) of the object.
	* @return The te parameter is returned after the fields are added.
	*/

//	===================================================================
	public TextEncoder encodeFields(Field[] fields,TextEncoder te,String baseName)
//	===================================================================
	{
		Class r = Reflection.getBaseClass(getClass(),baseName);
		if (te == null) te = new TextEncoder();
		if (r != null){
			Field[] all = fields;
			Wrapper w = (all.length != 0) ? Wrapper.getCached() : null;
			try{
				for (int i = 0; i<all.length; i++){
					String fn = all[i].getName();
					te.addValue(fn,te.toString(all[i],this,w));
				}
			}finally{
				if (w != null) w.cache();
			}
		}
		return te;
	}

	/**
	* You can call this within your encode(TextEncoder te) method to encode specific
	* fields.
	* @param fieldNames A comma separated list of field names.
	* @param te A TextEncoder object.
	* @param baseName Either the fully qualified class and package name or the class name (without package) of the object.
	* @return The te parameter is returned after the fields are added.
	*/

//	===================================================================
	public TextEncoder encodeFields(String fieldNames,TextEncoder te,String baseName)
//	===================================================================
	{
		Class r = Reflection.getBaseClass(getClass(),baseName);
		if (te == null) te = new TextEncoder();
		if (r != null){
			String [] all = mString.split(fieldNames,',');
			Wrapper w = (all.length != 0) ? Wrapper.getCached() : null;
			try{
				for (int i = 0; i<all.length; i++){
					Field f = Reflection.getField(r,all[i],false);
					if (f == null) continue;
					te.addValue(all[i],te.toString(f,this,w));
				}
			}finally{
				if (w != null) w.cache();
			}
		}
		return te;
	}
	/**
	* You can call this within your decode(TextDecoder te) method to encode specific
	* fields.
	* @param fieldNames A comma separated list of field names.
	* @param td A TextDecoder object.
	* @param baseName Either the fully qualified class and package name or the class name (without package) of the object.
	* @return The td parameter is returned after the fields are extracted.
	*/
//	===================================================================
	public TextDecoder decodeFields(String fieldNames,TextDecoder td,String baseName)
//	===================================================================
	{
		Class r = Reflection.getBaseClass(getClass(),baseName);
		if (td == null) return td;
		if (r != null){
			String [] all = mString.split(fieldNames,',');
			Wrapper w = (all.length != 0) ? Wrapper.getCached() : null;
			try{
				for (int i = 0; i<all.length; i++){
					String s = td.getValue(all[i]);
					if (s == null) continue;
					Field f = Reflection.getField(r,all[i],false);
					if (f == null) continue;
					TextEncoder.fromString(f,this,s,w);
				}
			}finally{
				if (w != null) w.cache();
			}
		}
		return td;
	}
	/**
	* You can call this within your decode(TextDecoder te) method to encode specific
	* fields.
	* @param fields A list of fields.
	* @param td A TextDecoder object.
	* @param baseName Either the fully qualified class and package name or the class name (without package) of the object.
	* @return The td parameter is returned after the fields are extracted.
	*/
//	===================================================================
	public TextDecoder decodeFields(Field[] fields,TextDecoder td,String baseName)
//	===================================================================
	{
		Class r = Reflection.getBaseClass(getClass(),baseName);
		if (td == null) return td;
		if (r != null){
			Field[] all = fields;
			Wrapper w = (all.length != 0) ? Wrapper.getCached() : null;
			try{
				for (int i = 0; i<all.length; i++){
					String fn = all[i].getName();
					String s = td.getValue(fn);
					if (s != null)
						TextEncoder.fromString(all[i],this,s,w);
				}
			}finally{
				if (w != null) w.cache();
			}
		}
		return td;
	}
	/**
	* Override this to encode the fields that you want to encode. The LiveObject implementation of
	* this automatically encodes all the fields for each class in the hierarchy that does not
	* override encode(TextEncoder te);
	**/

//	-------------------------------------------------------------------
	protected TextEncoder encode(TextEncoder te)
//	-------------------------------------------------------------------
	{
		//Vector v = DataUtils.getClassList(getClass(),"encode(Leve/util/TextEncoder;)Leve/util/TextEncoder;");
		Class[] v = DataUtils.getCachedClassList(getClass(),"encode(Leve/util/TextEncoder;)Leve/util/TextEncoder;");
		for (int i = 0; i<v.length; i++){
			Class r = (Class)v[i];
			//ewe.sys.Vm.debug("Encoding: "+r.getClassName());
			encodeFields(DataUtils.getCachedFieldList(r,this,true),te,r.getName());
		}
		return te;
	}
	/**
	* Override this to decode the fields that you want to decode.  The LiveObject implementation of
	* this automatically decodes all the fields for each class in the hierarchy that does not
	* override decode(TextDecoder td);
	**/

//	-------------------------------------------------------------------
	protected TextDecoder decode(TextDecoder td)
//	-------------------------------------------------------------------
	{
		Class[] v = DataUtils.getCachedClassList(getClass(),"decode(Leve/util/TextDecoder;)Leve/util/TextDecoder;");
		//Vector v = DataUtils.getClassList(getClass(),"decode(Leve/util/TextDecoder;)Leve/util/TextDecoder;");
		for (int i = 0; i<v.length; i++){
			//ewe.sys.Vm.debug("Decoding: "+r.getClassName());
			decodeFields(DataUtils.getCachedFieldList(v[i],this,true),td,v[i].getName());
		}
		return td;
	}
	/**
	* This method is called after the base implementation of textDecode() is executed. It gives
	* you a chance to do extra work after the fields are decoded.
	* @param from The String this object was decoded from.
	*/
//	-------------------------------------------------------------------
	protected void decoded(String from){}
//	-------------------------------------------------------------------
	/**
	* This method is called after the base implementation of textEncode() is executed. It gives
	* you a chance to do extra work and maybe modify the data after the fields are encoded.
	* @param to the String the object has been encoded to.
	* @return the String that should be used as the encoded text for the object. By default this
	* method simply returns the to parameter.
	*/
//	-------------------------------------------------------------------
	protected String encoded(String to){return to;}
//	-------------------------------------------------------------------

}
//####################################################
