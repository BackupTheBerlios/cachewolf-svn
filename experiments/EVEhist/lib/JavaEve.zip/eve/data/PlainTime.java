package eve.data;

import java.text.ParseException;

import eve.sys.Cache;
import eve.sys.Convert;
import eve.sys.Locale;
import eve.sys.LocaleFormat;
import eve.sys.SimpleDateFormat;
import eve.sys.Vm;
import eve.util.CharArray;
import eve.util.Intable;
import eve.util.LocaleFormatted;

/**
 * A PlainDate holds a day in year value with guaranteed no regard for
 * timezone information. The Date, DayInYear and DayOfYear classes
 * all take timezones into account which raises the possibility of
 * values changing when data is moved from one timezone into another.
 * @author Mike
 *
 */
public class PlainTime extends DataObject implements LocaleFormatted,ITime,Intable,Value{

	/** The full 24 hour value, from 0 to 23 **/
	public int hour;
	/** The full minute in the hour value, from 0 to 59 **/
	public int minute;
	/** The full second in the minute value, from 0 to 59 **/
	public int second;
	/** The full millisecond in the second value, from 0 to 999 **/
	public int millis;
	
	public PlainTime(){}
	
	public PlainTime(int hour, int minute, int second)
	{
		this(hour,minute,second,0);
	}
	
	public PlainTime(int hour, int minute, int second,int millisecond)
	{
		this.hour = hour;
		this.minute = minute;
		this.second = second;
		this.millis = millisecond;
	}
	
	/**
	 * Checks if any value is less than zero.
	 */
	public boolean timeIsValid()
	{
		return hour >= 0 && minute >= 0 && second >= 0 && millis >= 0; 
	}
	/**
	 * Set both the month and day to zero.
	 * @return
	 */
	public void makeTimeInvalid()
	{
		hour = minute = second = millis = -1;
	}
		/**
	 * Convert this PlainDate into a platform independent int value.
	 */
	public int getInt()
	{
		//return (hour*10000000)+(minute*100000)+(second*1000)+millisecond;
		return DateTimeUtils.timeToInt(hour, minute, second, millis);
	}
	/**
	 * Retrieve this PlainTime from a platform independent int value.
	 */
	public void setInt(int value)
	{
		if (value <= 0) makeTimeInvalid();
		else{
			hour = value/10000000;
			minute = (value/100000)%100;
			second = (value/1000)%100;
			millis = value%1000;
		}
	}
	/*
	public int compareEncoded(char[] one, int offset1, char [] two, int offset2)
	{
		for (int i = 0; i<9; i++){
			int v = one[offset1++]-two[offset1++];
			if (v != 0) return v;
		}
		return 0;
	}
	*/
	public int compareTo(Object other)
	{
		if (!(other instanceof PlainTime)) return super.compareTo(other);
		return getInt()-((PlainTime)other).getInt();
	}
	public PlainTime getTime(PlainTime dest) {
		if (dest == null) dest = new PlainTime();
		dest.copyFrom(this);
		return dest;
	}
	public void setTime(int hour, int minute, int second, int millis) {
		this.hour = hour;
		this.minute = minute;
		this.second = second;
		this.millis = millis;
	}

	public void fromString(char[] src, int offset, int length) {
		if (length != 9){
			makeTimeInvalid();
		}else{
			hour = Convert.toInt(src,offset+0,2);
			minute = Convert.toInt(src,offset+2,2);
			second = Convert.toInt(src,offset+4,2);
			millis = Convert.toInt(src,offset+6,3);
			if (hour > 23) makeTimeInvalid();
		}
	}

	public CharArray toString(CharArray dest) {
		return DateTimeUtils.timeTextEncode(dest,hour, minute, second, millis);
	}
	public String toString(){
		CharArray ca = (CharArray)Cache.get(CharArray.class);
		try{
			ca.clear();
			toString(ca);
			return ca.toString();
		}finally{
			Cache.put(ca);
		}
	}
	//===================================================================
	public CharArray format(String format,Locale locale,CharArray dest)
	//===================================================================
	{
		dest = CharArray.unNull(dest);
		if (locale == null) locale = Vm.getLocale();
		if (format == null) format = "HH:mm:ss";
		char spec = 0;
		int count = 0;
		int l = format.length();
		for(int i = 0; i<l+1; i++){
			char ch = i == l ? 0 : format.charAt(i);
			if (ch == spec) count++;
			else {
				//System.out.println(count+":"+spec);
				if (spec != 0){
					//String add = "????";
					CharArray add = dest;
					int h = hour;
					if (count < 2) count = 0;
					if (count >= 3 && spec == 'd') spec = 'E';
					switch(spec){
					case 'h':
						h = h%12;
						if (h == 0) h = 12;
					case 'H':
						//if (count < 2) count = 0;
						add = PlainDate.toString(h,count,true,dest);
						break;
					case 'm':
						//if (count < 2) count = 0;
						add = PlainDate.toString(minute,count,true,dest);
						break;
					case 's':
						add = PlainDate.toString(second,count,true,dest);
						break;
					case 'S':
						add = PlainDate.toString(millis,count,true,dest);
						break;
					case 't':
					case 'a':
						//add = locale.getString(locale.AM_PM,t.hour >= 12 ? 1 : 0,0);
						add = dest.append(locale.getString(locale.AM_PM,hour >= 12 ? 1 : 0,0));
						break;
					default:
							add = dest.append("????");
					}
					//sb.append(add);
					spec = 0;
					count = 0;
				}
				if (ch == 0) break;
				if ((ch | 0x20) >= 'a' && (ch | 0x20) <= 'z') {
					spec = ch;
					count = 1;
					continue;
				}else if (ch == '\''){
					int did = 0;
					for (i++;i<l;i++){
						char c2 = format.charAt(i);
						if (c2 == '\'') {
							if (did == 0) dest.append('\'');
							break;
						}else{
							dest.append(c2);
							did++;
						}
					}
					continue;
				}
				dest.append(ch);
			}
		}
		return dest;
	}
	
	public void fromString(String s) {
		char[] src = Vm.getStringChars(s);
		fromString(src,0,src.length);
	}
	public void format(LocaleFormat locale, CharArray dest) {
		LocaleFormat lf = SimpleDateFormat.fixLocaleFormat(locale, (LocaleFormat)Cache.get(LocaleFormat.class));
		try{
			format((String)lf.format,lf.locale,dest);
		}finally{
			Cache.put(lf);
		}
	}

	public void parse(LocaleFormat localeFormat, char[] chars, int offset, int length)
	throws ParseException {
LocaleFormat lf = SimpleDateFormat.fixLocaleFormat(localeFormat, (LocaleFormat)Cache.get(LocaleFormat.class));
try{
Locale locale = lf.locale;
String format = (String)lf.format;
if (format == null) format = locale.getString(Locale.SHORT_DATE_FORMAT,0,0);
if (format == null) format = "dd/MM/yyyy";
StringBuffer sb = new StringBuffer();
char spec = 0;
int count = 0;
int l = format.length();
int src = 0;
String source = new String(chars,offset,length);
String str = source;
for(int i = 0; i<l+1; i++){
	char ch = i == l ? 0 : format.charAt(i);
	if (ch == spec) count++;
	else {
		if (spec != 0){
			boolean digit = false;
			int sl = source.length();
			for(;src<sl;src++) if (source.charAt(src) != ' ') break;
			int st;
			for (st = src; src<sl; src++){
				char sc = source.charAt(src);
				if (st == src) digit = (sc >= '0' && sc <= '9');
				else if (digit) {
					if (sc < '0'|| sc > '9') break;
				}else{
					if (sc == '.') continue;
					if ((sc | 0x20) < 'a' || (sc | 0x20) > 'z') break;
				}
			}
			String data = st < sl ? source.substring(st,src) : "";
			int val = Convert.toInt(data);
			if (count >= 3 && spec == 'd') spec = 'E';
			//System.out.println(spec+" = "+data);
			switch(spec){
			/*
				case 'y':
					if (!digit) throw new ParseException(source,i);
					year = val;
					if (year < 1000)
						if (count < 4) 
							if (year <= 49) year += 2000;
							else year += 1900;
					break;
				case 'M':
					if (count > 2){
						if (digit) throw new ParseException(str,i);
						val = locale.fromString(count == 3 ? locale.SHORT_MONTH:locale.MONTH,data,0);
					}else{
						if (!digit) throw new ParseException(str,i);
					}
					if (val < 1 || val > 12) throw new ParseException(str,i);
					month = val;
					break;
				case 'd':
					if (!digit) throw new ParseException(str,i);
					day = val;
					break;
					*/
				case 'H':
				case 'h':
					if (val < 0 || val > 23) throw new ParseException(str,i);
					hour = val;
					break;
				case 'm':
					if (val < 0 || val > 59) throw new ParseException(str,i);
					minute = val;
					break;
				case 's':
					if (val < 0 || val > 59) throw new ParseException(str,i);
					second = val;
					break;
				case 'S':
					if (val < 0 || val > 999) throw new ParseException(str,i);
					millis = val;
					break;
				case 't':
				case 'a':
					val = locale.fromString(locale.AM_PM,data,0);
					if (val == -1) throw new ParseException(str,i);
					if (val == 0) {
						if (hour == 12) hour = 0;
						else if (hour > 12) throw new ParseException(str,i);
					}else{
						if (hour < 12) hour += 12;
					}
					break;
			}
		}
		spec = 0;
		count = 0;
// Starting a new sequence			
		if (ch == 0) break;
		if ((ch | 0x20) >= 'a' && (ch | 0x20) <= 'z') {
			spec = ch;
			count = 1;
			continue;
		}else if (ch == '\''){
			int did = 0;
			for (i++;i<l;i++){
				char c2 = format.charAt(i);
				if (c2 == '\'') {
					if (did == 0) src++;
					break;
				}else{
					src++;
					did++;
				}
			}
			continue;
		}
		src++;
	}
}
}finally{
	Cache.put(lf);
}
}
	
}
