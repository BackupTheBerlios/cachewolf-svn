package eve.data;

public interface IDate{

	public void setDate(int day, int month, int year);
	public PlainDate getDate(PlainDate dest); 
	public boolean dateIsValid();
	public void makeDateInvalid();
}

