/*
 * Created on Nov 8, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.data;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface Named {

	
	/**
	 * Get the name of the Object.
	 * @return the name of the Object.
	 */
	public String getName();
	
	/**
	 * Returns true if this Object is named as the specified parameter.
	 * @param aName a possible name.
	 * @return true if this Object is considered to have that name, false if not.
	 */
	public boolean isNamed(String aName);
}

//####################################################
