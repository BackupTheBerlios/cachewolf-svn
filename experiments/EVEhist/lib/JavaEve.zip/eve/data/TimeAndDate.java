/*
 * Created on Apr 30, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.data;

import eve.sys.Convert;
import eve.sys.Time;
import eve.util.TextEncodable;

/**
 * This is the same as eve.sys.Time, but it encodes/decodes itself as a platform, era
 * independant long value.
 * @author Michael L Brereton
 *
 */
//####################################################
public class TimeAndDate extends Time implements TextEncodable {

	/**
	 * 
	 */
	public TimeAndDate() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param day
	 * @param month
	 * @param year
	 */
	public TimeAndDate(int day, int month, int year) {
		super(day, month, year);
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see eve.util.TextEncodable#textEncode()
	 */
	public String textEncode() {
		return Convert.toString(getEncodedTime());
	}

	/* (non-Javadoc)
	 * @see eve.util.TextEncodable#textDecode(java.lang.String)
	 */
	public void textDecode(String encoded) {
		if (encoded == null) return;
		setEncodedTime(Convert.toLong(encoded));
	}

}

//####################################################
