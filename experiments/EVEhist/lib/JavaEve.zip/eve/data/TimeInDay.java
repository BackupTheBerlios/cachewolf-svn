/*
 * Created on Apr 30, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.data;

import eve.sys.Convert;
import eve.sys.TimeOfDay;
import eve.util.TextEncodable;

/**
 * This class is the same as TimeOfDay, but it encodes/decodes itself as a platform, era
 * independant long value.
 * <p>
 * @author Michael L Brereton
 *
 */
//####################################################
public class TimeInDay extends TimeOfDay implements TextEncodable {

	/**
	 * 
	 */
	public TimeInDay() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param hour
	 * @param minute
	 * @param second
	 */
	public TimeInDay(int hour, int minute, int second) {
		super(hour, minute, second);
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see eve.util.TextEncodable#textEncode()
	 */
	public String textEncode() {
		return Convert.toString(getEncodedTime());
	}

	/* (non-Javadoc)
	 * @see eve.util.TextEncodable#textDecode(java.lang.String)
	 */
	public void textDecode(String encoded) {
		if (encoded == null) return;
		setEncodedTime(Convert.toLong(encoded));
	}
}

//####################################################
