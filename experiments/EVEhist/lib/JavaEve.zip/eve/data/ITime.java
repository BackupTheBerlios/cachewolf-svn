package eve.data;

public interface ITime{
	public void setTime(int hour, int minute, int second, int millis);
	public PlainTime getTime(PlainTime dest); 
	public boolean timeIsValid();
	public void makeTimeInvalid();
}
