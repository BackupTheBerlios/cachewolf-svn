package eve.data;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Hashtable;

import eve.sys.Cache;
import eve.sys.Reflection;
import eve.sys.Wrapper;
/**
* This is an object which completely implements the DataUnit interface.
* The following is the default behavior.
* <p>
* getNew() will use the Reflection API to attempt to create a new instance
* of the object via a public default constructor. If successful, the object created will be returned.
* <p>
* getCopy() will call first call getNew() and then invoke copyFrom() on the
* created object passing it this object as a parameter.
* <p>
* copyFrom(Object other) envokes the eve.util.Utils.copy(Object source,Object dest) with this as the
* destination and the "other"
* <p>
* compareTo() returns 0 if the two Objects are the same object, or 1 otherwise.
* <p>
* equals() returns true if compareTo() returns 0.
**/
//##################################################################
public class DataObject implements DataUnit{
//##################################################################
//
// Do not add variables to this class.
//

//===================================================================
public Object getCopy()
//===================================================================
{
	DataUnit du = (DataUnit)getNew();
	du.copyFrom(this);
	return du;
}
//==================================================================
public void copyFrom(Object other)
//==================================================================
{
	Reflection.copy(other,this);
	copied(other);
}
//===================================================================
public int compareTo(Object other) 
//===================================================================
{
	if (other == this) return 0;
	return 1;
}
//===================================================================
public boolean equals(Object other) {return compareTo(other) == 0;}
//===================================================================
public Object getNew()
//===================================================================
{
	return Reflection.newInstance(getClass());
}
private static Hashtable cachedFields;

private static final int FIELD_TYPE = 0; 
private static final int FIELD_FIELD = 1; 
private static final int FIELD_GET = 2; 
private static final int FIELD_SET = 3; 
private synchronized static Object[] getCachedFieldSpecs(Class theClass, String fieldName)
{
	if (cachedFields == null) cachedFields = new Hashtable();
	Hashtable ht = (Hashtable)cachedFields.get(theClass);
	if (ht == null) cachedFields.put(theClass,ht = new Hashtable());
	Object[] got = (Object[])ht.get(fieldName);
	if (got != null) return got;
	ht.put(fieldName,got = new Object[4]);
	try{
		Field f = theClass.getField(fieldName);
		got[FIELD_TYPE] = f.getType();
		got[FIELD_FIELD] = f;
	}catch(Exception e){}
	try{
		Method m = theClass.getMethod("get_"+fieldName,Reflection.emptyClasses);
		if (got[FIELD_TYPE] == null) got[FIELD_TYPE] = m.getReturnType();
		got[FIELD_GET] = m;
	}catch(Exception e){
		return got;
	}
	if (got[FIELD_TYPE] != null)
		try{
			got[FIELD_SET] = theClass.getMethod("set_"+fieldName,new Class[]{(Class)got[FIELD_TYPE]});
		}catch(Exception e){}
	return got;
}
/**
* This is used for data transfer using a eve.data.FieldTransfer object. It is used
* if the programmer requests a field transfer but there is no such field in the object. In
* that case the _getSetField() method will be called and the programmer can programatically
* get/set the field data.<p>
* By default this method calls PropertyList.getSetProperties() on this Object.
 @param name the field name.
 @param data a non-null Wrapper that receives or provides the field data.
 @param isGet if this is true then it is a <b>get</b> operation (in which case you should set
* the value of data to be the field value) if it is false it is a <b>set</b> operation and
* the value of data should be assigned to the field.
* @return the Object should return true if the field data was successfully transfered, false if not.
*/
//===================================================================
public boolean _getSetField(String name, Wrapper data, boolean isGet)
//===================================================================
{
	Object[] all = getCachedFieldSpecs(getClass(),name);
	if (isGet){
		Method m = (Method)all[FIELD_GET];
		if (m != null){
			try{
				Reflection.invoke(this,m,Wrapper.noParameter,data);
				return true;
			}catch(Exception e){
				return false;
			}
		}
	}else{
		Method m = (Method)all[FIELD_SET];
		if (m != null){
			try{
				Reflection.invoke(this,m,new Wrapper[]{data},null);
				return true;
			}catch(Exception e){
				return false;
			}
		}
	}
	boolean b = PropertyList.getSetProperties(this,name,data,isGet);
	return b;
}
public Class _getFieldType(String name)
{
	Object[] all = getCachedFieldSpecs(getClass(),name);
	return (Class)all[FIELD_TYPE];
}
/**
* Gets the declared field list for a particular class in the class hierarchy of this LiveObject.
* @param baseClassName This should be the last part of the class name or the fully qualified class name.
For example if the object is of type samples.data.PersonInfo, the baseClassName can be "PersonInfo".
* @return A comma separated list of field names.
* @exception IllegalArgumentException If the baseClassName does not appear in the class hierarchy.
*/
//===================================================================
public String getMyFieldList(String baseClassName) throws IllegalArgumentException
//===================================================================
{
	return DataUtils.getFieldList(DataUtils.getClass(this,baseClassName),this,true);
}
/**
 * Get a declared field for this object for the specified baseClassName.
 * @param fieldName The fieldName
* @param baseClassName This should be the last part of the class name or the fully qualified class name.
For example if the object is of type samples.data.PersonInfo, the baseClassName can be "PersonInfo".
 * @return the Field or null if no declared field of that name was found.
* @exception IllegalArgumentException If the baseClassName does not appear in the class hierarchy.
 */
//===================================================================
public Field getDeclaredField(String fieldName,String baseClassName) throws IllegalArgumentException
//===================================================================
{
	Class r = DataUtils.getClass(this,baseClassName);
	try{
		return r.getDeclaredField(fieldName);
	}catch(Exception e){
		return null;
	}
}
/**
 * Get the value of a declared field in a Wrapper object.
 * @param fieldName The fieldName
* @param baseClassName This should be the last part of the class name or the fully qualified class name.
For example if the object is of type samples.data.PersonInfo, the baseClassName can be "PersonInfo".
 * @return the field value or null if the field does not exist, or if the field value could not be retrieved.
* @exception IllegalArgumentException If the baseClassName does not appear in the class hierarchy.
 */
//===================================================================
public Object getDeclaredFieldValue(String fieldName,String baseClassName) throws IllegalArgumentException
//===================================================================
{
	try{
		Field f = getDeclaredField(fieldName,baseClassName);
		if (f == null) return null;
		return f.get(this);
	}catch(IllegalAccessException e){
		return null;
	}
}
/**
 * Put this object into a cache of re-usable objects.
 * By default this uses the Reflection.cache() call.
 */
public void cache()
{
	Cache.put(this);
}
//
// FIXME - get everything from _getSetField()
//
/**
This method is called after the base implementation of copyFrom() is executed. It gives
you a chance to do extra work after the standard field by field copy is done. 
* @param from The object that data was copied from.
*/
//-------------------------------------------------------------------
protected void copied(Object from){}
//-------------------------------------------------------------------

//##################################################################
}
//##################################################################

