package eve.data;
/**
* A DataUnit encompasses a set of standard methods which are useful
* for small units of data. It extends Copyable and Comparable and in
* total provides the following methods:
* <pre>
* Object getNew();
* Object getCopy();
* void copyFrom(Object other);
* int compareTo(Object other);
* </pre>
**/
//##################################################################
public interface DataUnit extends eve.util.Copyable,Comparable{
//##################################################################
/**
* Return a new Object which is of the same class as the original.
**/
public Object getNew();
/**
* Copy all appropriate data from another object.
**/
public void copyFrom(Object other);

//##################################################################
}
//##################################################################

