package eve.data;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Hashtable;
import java.util.Vector;

import eve.sys.Reflection;
import eve.sys.Vm;
import eve.util.mString;

//##################################################################
public class DataUtils{
//##################################################################
/**
 * Get the child at the specified address.
 * The address of a child is an array of integers, each element being
 * the index in a successive descendant from the parent.
 * If the child IS the parent the address is an empty array.
 * If the child is at index 3 in the parent the address will be [3].
 * If the child is at index 2 of a child at index 5 of the parent the
 * address will be [5,2].
 * @param parent the parent node.
 * @param address the address of the child.
 * @return the address of the child in the parent or null if
 * the child is not a descendant of the parent.
 */
//===================================================================
public static TreeNode getChildAt(TreeNode parent,int [] address)
//===================================================================
{
	if (address == null) return null;
	TreeNode n = parent;
	for (int i = 0; i<address.length && n != null; i++)
		n = n.getChild(address[i]);
	return n;
}
/**
 * Get the address of a child in the specified parent.
 * @param parent the parent node.
 * @param child the child node.
 * @return the address of the child in the parent or null if
 * the child is not a descendant of the parent.
 */
public static int [] addressOfChild(TreeNode parent,TreeNode child)
//===================================================================
{
	TreeNode ch = child;
	int i;
	for (i = 0;child != parent && child != null;i++) child = child.getParent();
	if (child == null) return null; //Child not in parent.
	int [] ret = new int[i];
	child = ch;
	for (int j = 0;child != parent;j++){
		TreeNode p = child.getParent();
		ret[i-j-1] = p.indexOfChild(child);
		child = p;
	}
	return ret;
}
//===================================================================
public static TreeNode getSibling(TreeNode child,int change)
//===================================================================
{
	TreeNode p = child.getParent();
	if (p == null) return null;
	return p.getChild(p.indexOfChild(child)+change);
}
//===================================================================
public static TreeNode getParent(TreeNode child,int levels)
//===================================================================
{
	for (int i = 0; i<levels && child != null; i++) child = child.getParent();
	return child;
}
//===================================================================
public static boolean isNamed(Object data,String name)
//===================================================================
{
	if (data == null) return false;
	if (data instanceof Named)
		return ((Named)data).isNamed(name);
	String nm = mString.removeTrailingSlash(data.toString());
	if (nm == null) return false;
	return nm.equalsIgnoreCase(name);
}
//===================================================================
public static TreeNode findNamedChild(TreeNode parent,String name)
//===================================================================
{
	if (parent == null) return null;
	int n = parent.getChildCount();
	for (int i = 0; i<n; i++){
		TreeNode c = parent.getChild(i);
		if (isNamed(c,name)) return c;
	}
	return null;
}
/**
* This tries to find the address of a child given its path from the parent.
**/
//===================================================================
public static int [] addressOfChild(TreeNode parent,String childPath)
//===================================================================
{
	if (childPath == null || parent == null) return null;
	childPath = mString.removeTrailingSlash(childPath.replace('\\','/'));
	String [] all = mString.split(childPath,'/');
	if (all != null) if (all.length == 0) all = null;
	if (all == null) all = new String[]{""};
	
	TreeNode cur = parent;
	for (int i = 0; i<all.length; i++){
		cur.expand();
		cur = findNamedChild(cur,all[i]);
		if (cur == null) return null;
	}
	return addressOfChild(parent,cur);
}
/**
Look through the dataObject class and possibly its superclasses to locate in each
the String field named "fieldName" and then append them all together. This method
is used when comma separated values are used to specify some information about
the class.

 * @param fieldName the name of the field (e.g. "_fields").
 * @param dataObject the data object.
 * @param declaredOnly if this is true then only the declared field will be searched.
 * @return all found values concatenated together.
 */
//===================================================================
public static String appendAllFields(String fieldName,Object dataObject,boolean declaredOnly)
//===================================================================
{
	String ret = "";
	for (Class r = dataObject.getClass(); r != null; r = r.getSuperclass()){
		try{
			Field f = r.getDeclaredField(fieldName);
			if (f != null && Modifier.isPublic(f.getModifiers()) && dataObject != null && f.getType().getName().equals("java.lang.String")){
				String add = mString.toString(f.get(dataObject));
				if (add.length() == 0) continue;
				if (ret.length() != 0) add += ",";
				ret = add+ret;
			}
		}catch(Exception e){}
		if (declaredOnly) break;
	}
	return ret;
}
//-------------------------------------------------------------------
static Class getClass(Object obj,String baseClassName) throws IllegalArgumentException
//-------------------------------------------------------------------
{
	Class r = Reflection.getBaseClass(obj.getClass(),baseClassName);
	if (r == null) throw new IllegalArgumentException("\""+baseClassName+"\" is not in the class hierarchy.");
	return r;
}

static Hashtable cachedClassList = new Hashtable();
static class classListEntry{
	public String method;
	public Class theClass;
	public int hashCode(){return theClass.hashCode()^method.hashCode();}
	public boolean equals(Object other)
	{
		if (other == this) return true;
		else if (!(other instanceof classListEntry)) return false;
		classListEntry cle = (classListEntry)other;
		return cle.theClass.equals(theClass) && cle.method.equals(method);
	}
};

static classListEntry e;

public static Class[] getCachedClassList(Class c, String methodNameAndSpecs)
{
	synchronized(cachedClassList){
		if (e == null) e = new classListEntry();
		e.method = methodNameAndSpecs;
		e.theClass = c;
		Class[] got = (Class[])cachedClassList.get(e);
		if (got != null) return got;
		Vector v = old_getClassList(c,methodNameAndSpecs);
		got = new Class[v.size()];
		v.copyInto(got);
		cachedClassList.put(e,got);
		e = null;
		return got;
	}
}
//-------------------------------------------------------------------
private static Vector old_getClassList(Class c,String methodNameAndSpecs)
//-------------------------------------------------------------------
{
	Vector v = new Vector();
	Class[] methodParameters = Reflection.getParameterTypes(methodNameAndSpecs);
	Class methodReturn = Reflection.getReturnOrFieldType(methodNameAndSpecs);
	int idx = methodNameAndSpecs.indexOf('(');
	if (idx == -1) return v;
	String name = methodNameAndSpecs.substring(0,idx);
	for (Class r = c; r != null; r = r.getSuperclass()){
		if (r.getName().startsWith("eve.data")) break;
		else {
			if (Reflection.getMethod(r,name,methodParameters,methodReturn,true) == null)
				v.insertElementAt(r,0);
			/*
			try {
				boolean found = false;
				
				Method[] all = r.getDeclaredMethods();
				for (int i = 0; i<all.length; i++)
					if (all[i].getName().equals(methodExclusion)){
						found = true;
						break;
					}
				if (!found) v.insertElementAt(r,0);
			}catch(Exception e){// Method was not found so add this to the list.
				v.insertElementAt(r,0);	
			}
			*/
		}
	}		
	return v;
}

private static Hashtable declaredFieldLists = new Hashtable(), allFieldLists = new Hashtable();

public static Field[] getCachedFieldList(Class theClass,Object dataObject,boolean declaredOnly)
{
	Hashtable ht = declaredOnly ? declaredFieldLists : allFieldLists;
	if (theClass == null) theClass = dataObject.getClass();
	Field[] got =  (Field[])ht.get(theClass);
	if (got != null) return got;
	String[] fl = mString.split(getFieldList(theClass,dataObject,declaredOnly),',');
	Vector v = new Vector();
	for (int i = 0; i<fl.length; i++){
		try{
			Field f = declaredOnly ? theClass.getDeclaredField(fl[i]) : theClass.getField(fl[i]);
			v.add(f);
		}catch(Exception e){}
	}
	got = new Field[v.size()];
	v.copyInto(got);
	ht.put(theClass,got);
	return got;
}
/**
 * Get a comma separated list of fields for the specified object.
 * @param theClass the Class for the object.
 * @param dataObject an instance of the object, which is necessary if the "_fields" field is used to
 * specifiy fields.
 * @param declaredOnly if this is true only the field declared by the class (not those inherited)
 * are used.
 * @return a comma separatedlist of fields (e.g. "name,age,dob").
 */
//===================================================================
public static String getFieldList(Class theClass,Object dataObject,boolean declaredOnly)
//===================================================================
{
	String ret = "";
	for (Class r = theClass; r != null; r = r.getSuperclass()){
		String add = "";
		try{
			Field f = r.getDeclaredField("_fields");
			if (f != null && Modifier.isPublic(f.getModifiers()) && dataObject != null && f.getType().getName().equals("java.lang.String"))
				add = mString.toString(f.get(dataObject));
		}catch(Exception e){
			try{
				Field [] all = r.getDeclaredFields();
				for (int i = 0; i<all.length; i++){
					int mod = all[i].getModifiers();
					if (!Modifier.isStatic(mod) && Modifier.isPublic(mod) && (all[i].getName().charAt(0) != '_')){
						if (add.length() != 0) add += ",";
						add += all[i].getName();
					}
				}
			}catch(Exception e2){}
		}
		if (add.length() != 0){
			if (ret.length() != 0) add += ",";
			ret = add+ret;
		}
		if (declaredOnly) break;
	}
	return ret;
}
/**
 * Get a comma separated list of fields for the specified object.
 * @param objectOrClass the object, or Class of the object.
 * @param declaredOnly if this is true only the field declared by the class (not those inherited)
 * are used.
 * @return a comma separatedlist of fields (e.g. "name,age,dob").
 */
//===================================================================
public static String getFieldList(Object objectOrClass,boolean declaredOnly)
//===================================================================
{
	Class c = objectOrClass instanceof Class ? (Class)objectOrClass : null;
	if (c == null && objectOrClass != null) c = objectOrClass.getClass();
	if (objectOrClass instanceof Class) objectOrClass = null;
	return getFieldList(c,objectOrClass,declaredOnly);
}
/**
 * This converts a name with underscores to a prompt with capital letters and spaces where
 * the underscores were.
 * @param name 
 * @return The converted name.
 */
//===================================================================
public static String nameToPrompt(String name)
//===================================================================
{
	if (name == null) return null;
	char [] all = Vm.getStringChars(name);
	char [] another = new char[all.length*2];
	boolean cap = true;
	boolean hasUnder = false;
	int j = 0;
	for (int i = 0; i<all.length; i++){
		if (all[i] == '$') return new String(another,0,j);
		if (all[i] == '_') {
			hasUnder = true;
			another[j++] = ' ';
			cap = true;
		}else{
			if (cap) another[j++] = Character.toUpperCase(all[i]);
			else if (i != 0 && !hasUnder && Character.isUpperCase(all[i])){
				if (Character.isUpperCase(all[i-1])) another[j++] = all[i];
				else {
					another[j++] = ' ';
					another[j++] = all[i];
				}
			}else another[j++] = all[i];
			cap = false;
		}
	}
	return new String(another,0,j);
}

//##################################################################
}
//##################################################################

