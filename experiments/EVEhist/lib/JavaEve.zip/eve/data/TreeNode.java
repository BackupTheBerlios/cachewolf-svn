package eve.data;

import java.util.Iterator;

//##################################################################
public interface TreeNode{
//##################################################################
/**
* Get the parent of this object.
**/
public TreeNode getParent();
/**
* Get the child at the specified index.
**/
public TreeNode getChild(int index);
/**
* Get the number of children that this object has.
**/
public int getChildCount();
/**
* Get an Iterator for the children.
**/
public Iterator getChildren();
/**
* Return the index of the specified child. This will return -1 if the
* parameter is not a child of this TreeNode.
**/
public int indexOfChild(TreeNode child);
/**
* Returns whether this node is expandable.
**/
public boolean canExpand();
/**
* Tell it to expand (ie gather its children).
**/
public boolean expand();
/**
* Tell it that it can release its children.
**/
public boolean collapse();
/**
* Returns whether this is a node or leaf.
**/
public boolean isLeaf();
//##################################################################
}
//##################################################################


