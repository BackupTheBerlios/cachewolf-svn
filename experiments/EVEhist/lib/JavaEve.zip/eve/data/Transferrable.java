package eve.data;

import eve.sys.Wrapper;

//##################################################################
public interface Transferrable{
//##################################################################

public boolean getSetTransferData(Object transferObject,Wrapper wrapper,boolean isGet);

//##################################################################
}
//##################################################################

