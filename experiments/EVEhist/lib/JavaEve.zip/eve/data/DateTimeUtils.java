package eve.data;

import eve.sys.Cache;
import eve.util.CharArray;

public class DateTimeUtils {

	private static char [] buff = new char[9];
	
	private static void encode(int value, int digits, char[] dest, int offset)
	{
		int d = offset+digits;
		for (int i = 0; i<digits; i++){
			dest[--d] = (char)('0'+value%10);
			value /= 10;
		}
	}
	public static CharArray timeTextEncode(CharArray dest,int hour, int minute, int second, int millis) {
		if (dest == null) dest = new CharArray();
		if (hour > 23 || hour < 0 || minute < 0 || second < 0 || millis < 0) dest.append("999999999");
		else synchronized(buff){
			encode(hour,2,buff,0);
			encode(minute,2,buff,2);
			encode(second,2,buff,4);
			encode(second,3,buff,6);
			dest.append(buff,0,9);
			//System.out.println("Now: "+dest);
		}
		return dest;
	}
	
	public static CharArray dateTextEncode(CharArray dest,int day, int month, int year) {
		if (dest == null) dest = new CharArray();
		if (month <= 0 || day <= 0) dest.append("00000000");
		else synchronized(buff){
			encode(year,4,buff,0);
			encode(month,2,buff,4);
			encode(day,2,buff,6);
			dest.append(buff,0,8);
		}
		return dest;
	}
	/**
	 * Convert a plain date into a platform independent int value.
	 */
	public static int dateToInt(int day, int month, int year)
	{
		return (year*10000)+(month*100)+day;
	}
	/**
	 * Convert a plain date into a platform independent int value.
	 */
	public static int timeToInt(int hour, int minute, int second, int millis)
	{
		return (hour*10000000)+(minute*100000)+(second*1000)+millis;
	}
	
	public static void transferDate(IDate src, IDate dest)
	{
		PlainDate pd = null;
		//
		if (src instanceof PlainDate) pd = (PlainDate)src;
		else if (dest instanceof PlainDate) pd = (PlainDate)dest;
		else pd = (PlainDate)Cache.get(PlainDate.class);
		//
		if (pd != src) src.getDate(pd);
		if (pd != dest) dest.setDate(pd.day, pd.month, pd.year);
		if (pd != src && pd != dest) Cache.put(pd);
	}
	public static void transferTime(ITime src, ITime dest)
	{
		PlainTime pd = null;
		//
		if (src instanceof PlainTime) pd = (PlainTime)src;
		else if (dest instanceof PlainTime) pd = (PlainTime)dest;
		else pd = (PlainTime)Cache.get(PlainTime.class);
		//
		if (pd != src) src.getTime(pd);
		if (pd != dest) dest.setTime(pd.hour,pd.minute,pd.second,pd.millis);
		if (pd != src && pd != dest) Cache.put(pd);
	}
	/**
	 * Checks if any value is less than zero.
	 */
	public static boolean timeIsValid(int hour, int minute, int second, int millis)
	{
		return hour >= 0 && minute >= 0 && second >= 0 && millis >= 0; 
	}
	public static boolean timeIsValid(ITime src)
	{
		PlainTime pt = null;
		if (src instanceof PlainTime) pt = (PlainTime)src;
		else {
			pt = (PlainTime) Cache.get(PlainTime.class);
			src.getTime(pt);
		}
		try{
			return timeIsValid(pt.hour,pt.minute,pt.second,pt.millis);
		}finally{
			if (pt != src) Cache.put(pt);
		}
	}
	public static boolean dateIsValid(IDate src)
	{
		PlainDate pt = null;
		if (src instanceof PlainDate) pt = (PlainDate)src;
		else {
			pt = (PlainDate) Cache.get(PlainDate.class);
			src.getDate(pt);
		}
		try{
			return dateIsValid(pt.day,pt.month,pt.year);
		}finally{
			if (pt != src) Cache.put(pt);
		}
	}
	/**
	 * Checks if any value is less than zero.
	 */
	public static boolean dateIsValid(int day, int month, int year)
	{
		return day > 0 && month > 0; 
	}
	/*
	public static boolean dateFromInt(int value, PlainDate dest)
	{
		if (value <= 0) dest.makeInvalid();
		else{
			dest.year = value/10000;
			dest.month = (value/100)%100;
			dest.day = value%100;
		}
		return dest.isValid();
	}
	public static boolean timeFromInt(int value, PlainTime dest)
	{
		dest.hour = value/10000000;
		dest.minute = (value/100000)%100;
		dest.second = (value/1000)%100;
		dest.millisecond = value%1000;
		if (!dest.isValid()) dest.makeInvalid();
		return dest.isValid();
	}
	*/
}
