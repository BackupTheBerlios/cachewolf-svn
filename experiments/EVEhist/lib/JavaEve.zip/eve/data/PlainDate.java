package eve.data;

import java.text.ParseException;

import eve.sys.Cache;
import eve.sys.Convert;
import eve.sys.Locale;
import eve.sys.LocaleFormat;
import eve.sys.SimpleDateFormat;
import eve.sys.Vm;
import eve.util.CharArray;
import eve.util.Intable;
import eve.util.LocaleFormatted;

/**
 * A PlainDate holds a day in year value with guaranteed no regard for
 * timezone information. The Date, DayInYear and DayOfYear classes
 * all take timezones into account which raises the possibility of
 * values changing when data is moved from one timezone into another.
 * @author Mike
 *
 */
public class PlainDate extends DataObject implements IDate, Intable, Value, LocaleFormatted{

	public PlainDate(){}
	public PlainDate(int day, int month, int year)
	{
		this.day = day;
		this.month = month;
		this.year = year;
	}
	/** The full four-digit year, e.g. 2008 **/
	public int year;
	/** The month in the year value, starting from 1. **/
	public int month;
	/** The day in the month value, starting from 1. **/
	public int day;
	/**
	 * Checks if month and day are both greater than 0.
	 */
	public boolean dateIsValid()
	{
		return month > 0 && day > 0;
	}
	/**
	 * Set both the month and day to zero.
	 * @return
	 */
	public void makeDateInvalid()
	{
		month = day = year = 0;
	}
	//
	//
	/**
	 * Convert this PlainDate into a platform independent int value.
	 */
	public int getInt()
	{
		return DateTimeUtils.dateToInt(day, month, year);
	}
	/**
	 * Retrieve this PlainDate from a platform independent int value.
	 */
	public void setInt(int value)
	{
		if (value <= 0) makeDateInvalid();
		else{
			year = value/10000;
			month = (value/100)%100;
			day = value%100;
		}
	}
	/*
	public int compareEncoded(char[] one, int offset1, char [] two, int offset2)
	{
		for (int i = 0; i<8; i++){
			int v = one[offset1++]-two[offset1++];
			if (v != 0) return v;
		}
		return 0;
	}
	*/
	public int compareTo(Object other)
	{
		if (!(other instanceof PlainDate)) return super.compareTo(other);
		return getInt()-((PlainDate)other).getInt();
	}
	public int hashCode()
	{
		return getInt();
	}
	public PlainDate getDate(PlainDate dest) {
		if (dest == null) dest = new PlainDate();
		dest.copyFrom(this);
		return dest;
	}
	public void setDate(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}
	public String toString(){
		CharArray ca = (CharArray)Cache.get(CharArray.class);
		try{
			ca.clear();
			toString(ca);
			return ca.toString();
		}finally{
			Cache.put(ca);
		}
	}
	public void fromString(String s) {
		char[] src = Vm.getStringChars(s);
		fromString(src,0,src.length);
	}
	
	public void fromString(char[] src, int offset, int length) {
		if (length != 8){
			makeDateInvalid();
		}else{
			year = Convert.toInt(src,offset,4);
			month = Convert.toInt(src,offset+4,2);
			day = Convert.toInt(src,offset+6,2);
		}
	}
	public CharArray toString(CharArray dest) {
		return DateTimeUtils.dateTextEncode(dest, day, month, year);
	}
	//===================================================================
	static CharArray toString(int value,int digits,boolean zeroFill,CharArray dest)
	//===================================================================
	{
		int need = Convert.formatInt(value,null,0);
		int where = dest.length;
		int toFill = digits-need;
		if (toFill < 0) toFill = 0;
		if (need < digits) need = digits;
		dest.makeSpace(where,need);
		Convert.formatInt(value,dest.data,where+toFill);
		for (int i = 0; i<toFill; i++)
			dest.data[where+i] = zeroFill ? '0':' ';
		return dest;
	}
	
	//===================================================================
	public CharArray format(String format,Locale locale,CharArray dest)
	//===================================================================
	{
		dest = CharArray.unNull(dest);
		if (locale == null) locale = Vm.getLocale();
		if (format == null) format = locale.getString(Locale.SHORT_DATE_FORMAT,0,0);
		if (format == null)
			return dest.append(day).append('/').append(month).append('/')
			.append(year);
		char spec = 0;
		int count = 0;
		int l = format.length();
		for(int i = 0; i<l+1; i++){
			char ch = i == l ? 0 : format.charAt(i);
			if (ch == spec) count++;
			else {
				//System.out.println(count+":"+spec);
				if (spec != 0){
					//String add = "????";
					CharArray add = dest;
					if (count < 2) count = 0;
					if (count >= 3 && spec == 'd') spec = 'E';
					switch(spec){
					case 'y':
						int y = year;
						if (count < 4) y = y%100;
						add = toString(y,count,true,dest);
						break;
					case 'M':
						int m = month;
						//if (count < 2) count = 0;
						if (count >= 3) add = dest.append(locale.getString(count == 3 ? locale.SHORT_MONTH:locale.MONTH,m,0));
						else add = toString(m,count,true,dest);
						break;
					case 'd':
						//if (count < 2) count = 0;
						add = toString(day,count,true,dest);
						break;
					default:
							add = dest.append("????");
					}
					spec = 0;
					count = 0;
				}
				if (ch == 0) break;
				if ((ch | 0x20) >= 'a' && (ch | 0x20) <= 'z') {
					spec = ch;
					count = 1;
					continue;
				}else if (ch == '\''){
					int did = 0;
					for (i++;i<l;i++){
						char c2 = format.charAt(i);
						if (c2 == '\'') {
							if (did == 0) dest.append('\'');
							break;
						}else{
							dest.append(c2);
							did++;
						}
					}
					continue;
				}
				dest.append(ch);
			}
		}
		return dest;
	}
	
	public void format(LocaleFormat locale, CharArray dest) {
		LocaleFormat lf = SimpleDateFormat.fixLocaleFormat(locale, (LocaleFormat)Cache.get(LocaleFormat.class));
		try{
			format((String)lf.format,lf.locale,dest);
		}finally{
			Cache.put(lf);
		}
	}
	
	public void parse(LocaleFormat localeFormat, char[] chars, int offset, int length)
			throws ParseException {
		LocaleFormat lf = SimpleDateFormat.fixLocaleFormat(localeFormat, (LocaleFormat)Cache.get(LocaleFormat.class));
	try{
		Locale locale = lf.locale;
		String format = (String)lf.format;
		if (format == null) format = locale.getString(Locale.SHORT_DATE_FORMAT,0,0);
		if (format == null) format = "dd/MM/yyyy";
		StringBuffer sb = new StringBuffer();
		char spec = 0;
		int count = 0;
		int l = format.length();
		int src = 0;
		String source = new String(chars,offset,length);
		String str = source;
		for(int i = 0; i<l+1; i++){
			char ch = i == l ? 0 : format.charAt(i);
			if (ch == spec) count++;
			else {
				if (spec != 0){
					boolean digit = false;
					int sl = source.length();
					for(;src<sl;src++) if (source.charAt(src) != ' ') break;
					int st;
					for (st = src; src<sl; src++){
						char sc = source.charAt(src);
						if (st == src) digit = (sc >= '0' && sc <= '9');
						else if (digit) {
							if (sc < '0'|| sc > '9') break;
						}else{
							if (sc == '.') continue;
							if ((sc | 0x20) < 'a' || (sc | 0x20) > 'z') break;
						}
					}
					String data = st < sl ? source.substring(st,src) : "";
					int val = Convert.toInt(data);
					if (count >= 3 && spec == 'd') spec = 'E';
					//System.out.println(spec+" = "+data);
					switch(spec){
						case 'y':
							if (!digit) throw new ParseException(source,i);
							year = val;
							if (year < 1000)
								if (count < 4) 
									if (year <= 49) year += 2000;
									else year += 1900;
							break;
						case 'M':
							if (count > 2){
								if (digit) throw new ParseException(str,i);
								val = locale.fromString(count == 3 ? locale.SHORT_MONTH:locale.MONTH,data,0);
							}else{
								if (!digit) throw new ParseException(str,i);
							}
							if (val < 1 || val > 12) throw new ParseException(str,i);
							month = val;
							break;
						case 'd':
							if (!digit) throw new ParseException(str,i);
							day = val;
							break;
							/*
						case 'H':
						case 'h':
							if (val < 0 || val > 23) throw new ParseException(str,i);
							hour = val;
							break;
						case 'm':
							if (val < 0 || val > 59) throw new ParseException(str,i);
							minute = val;
							break;
						case 's':
							if (val < 0 || val > 59) throw new ParseException(str,i);
							second = val;
							break;
						case 'S':
							if (val < 0 || val > 999) throw new ParseException(str,i);
							millis = val;
							break;
						case 't':
						case 'a':
							val = locale.fromString(locale.AM_PM,data,0);
							if (val == -1) throw new ParseException(str,i);
							if (val == 0) {
								if (hour == 12) hour = 0;
								else if (hour > 12) throw new ParseException(str,i);
							}else{
								if (hour < 12) hour += 12;
							}
							break;
							*/
					}
				}
				spec = 0;
				count = 0;
	// Starting a new sequence			
				if (ch == 0) break;
				if ((ch | 0x20) >= 'a' && (ch | 0x20) <= 'z') {
					spec = ch;
					count = 1;
					continue;
				}else if (ch == '\''){
					int did = 0;
					for (i++;i<l;i++){
						char c2 = format.charAt(i);
						if (c2 == '\'') {
							if (did == 0) src++;
							break;
						}else{
							src++;
							did++;
						}
					}
					continue;
				}
				src++;
			}
		}
		}finally{
			Cache.put(lf);
		}
	}

}
