/*
 * Created on Jun 28, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package eve.server;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author Mike
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface IRemoteFile 
{
	/** 
	 * This returns a set of Strings in the same format as returned by
	 * getInfo() - separated by '|' characters.
	 * @param path
	 * @return
	 */
	public String getDirectory(String path);
	
	public String getInfo(String path);
	public InputStream getInputStreamFor(String path);
	public OutputStream getOutputStreamFor(String path, boolean append);
	public boolean move(String srcPath, String destPath);
	public boolean delete(String srcPath);
	public boolean createDir(String dirPath);
}
