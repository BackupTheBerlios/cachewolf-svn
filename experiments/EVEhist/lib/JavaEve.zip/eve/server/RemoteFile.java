/*
 * Created on Jun 28, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package eve.server;

import java.io.IOException;
import java.util.Hashtable;

import eve.io.File;
import eve.io.FileAdapter;
import eve.sys.Convert;
import eve.sys.Vm;

/**
 * @author Mike
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RemoteFile extends FileAdapter{

	IRemoteFile myFile;
	Hashtable fileInfo = new Hashtable();
	/** Which starts at 1. */
	private int indexOf(char[] src, int which)
	{
		int got = 0;
		for (int i = 0; i<src.length; i++){
			if (src[i] == ';'){
				got++;
				if (got == which) return i;
			}
		}
		return -1;
	}
	/* (non-Javadoc)
	 * @see eve.io.FileBase#getNewInstance()
	 */
	protected File getNewInstance()
	{
		return new RemoteFile();
	}
	
	private long lengthOf(String info,char[] infoChars)
	{
		if (infoChars == null) infoChars = Vm.getStringChars(info); 
		int idx = indexOf(infoChars,1);
		if (idx == -1) return 0;
		return Convert.toLong(infoChars,idx+1,infoChars.length-(idx+1));
	}
	private String infoFor(String fileName)
	{
		String got = (String)fileInfo.get(fileName);
		if (got != null) return got; 
		return myFile.getInfo(fileName);
	}
	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#createDir()
	 */
	public boolean createDir() {
		return myFile.createDir(getFullPath());
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#delete()
	 */
	public boolean delete() {
		return myFile.delete(getFullPath());
	}
	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#exists()
	 */
	public boolean exists() {
		return infoFor(getFullPath()) != null;
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#isDirectory()
	 */
	public boolean isDirectory() {
		String inf = infoFor(getFullPath());
		if (inf == null) return false;
		return lengthOf(inf,null) == -1;
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#getFullPath()
	 */
	public String getFullPath() {
		return new String(name.data,0,name.length);
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#deleteOnExit()
	 */
	public void deleteOnExit() {
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#list(java.lang.String, int)
	 */
	public String[] list(String mask, int listAndSortOptions) {
		String all = myFile.getDirectory(getFullPath());
		//String[] infos = new  
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#getSetModified(long, boolean)
	 */
	protected long getSetModified(long time, boolean doGet) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#move(eve.io.File)
	 */
	public boolean move(File newFile) {
		if (!(newFile instanceof RemoteFile)){
			return false;
		}
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#getLength()
	 */
	public long getLength() {
		// TODO Auto-generated method stub
		return 0;
	}

}
