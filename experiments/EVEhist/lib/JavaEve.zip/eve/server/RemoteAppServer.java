/*
 * Created on May 29, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import eve.data.Property;
import eve.data.PropertyList;
import eve.io.Io;
import eve.io.TextCodec;
import eve.io.block.RemoteCallHandlerObject;
import eve.server.RemoteAppEntry;
import eve.sys.Task;
import eve.sys.Vm;
import eve.util.ByteArray;
import eve.util.TextDecoder;
import eve.util.mString;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class RemoteAppServer {//extends EncodableObject {

	public Hashtable entries = new Hashtable();
	/**
	 * If this is true then it acts as a server for WebBrowsers.
	 */
	public boolean isAppletServer;
	//
	public void addApplication(RemoteAppEntry entry)
	{
		synchronized(entries){
			entries.put(entry.applicationName,entry);
		}
	}
	
	public void copyToOther(RemoteAppServer dest)
	{
		dest.entries.putAll(entries);
	}
	public String hostName = "Any";
	public int hostPort = 2000;
	//private static int curNumber = 0;
	static synchronized long nextNumber()
	{
		return System.currentTimeMillis();
	}
	private String[] getEntryNames(boolean shortNames){
		synchronized(entries){
			String[] all = new String[entries.size()];
			int i = 0;
			for (Enumeration e = entries.keys(); e.hasMoreElements();){
				all[i++] = (String)e.nextElement();
				if (shortNames){
					RemoteAppEntry en = (RemoteAppEntry)entries.get(all[i-1]);
					all[i-1] = en.getLinkName();
				}
			}
			return all;
		}
	}
	public String optionIt(String display,String value)
	{
		return optionIt(display,value,false);
	}
	public String optionIt(String display,String value,boolean selected)
	{
		if (value == null) value = display;
		String sel = selected ? "selected " : "";
		return "<option "+sel+"value=\""+value+"\">"+display+"<options>";
	}
	/**
	 * Run the server. This method does not return.
	 * @param ss the ServerSocket to run the server on.
	 */
	public void runServer(ServerSocket ss)
	{
		/*
		if (!isAppletServer)
		new Task(){
			public void doRun(){
				while(true){
					sleep(1000);
					Vm.debug("Objects: "+Vm.countObjects(true)+", "+" Threads: "+Vm.countThreads());
				}
			}
		}.start();
		*/
		//System.out.println("Server running on: "+ss.getInetAddress());
		while(true){
			try{
				final Socket s = ss.accept();
				//s.setTcpNoDelay(true);
				//System.out.println("Connected to: "+s.getInetAddress());
				final String[] appNames = getEntryNames(false);
				final String[] smallNames = getEntryNames(true);
				new Task(){
					OutputStream out;
					PrintWriter pw;
					BufferedReader br;
					protected void doRun()
					{
						try{
							if (isAppletServer) doRunHttpServer();
							else doRunAppServer();
						}catch(Exception e){
							fail(e);
						}
					}
					ByteArray toBytes(String data, ByteArray dest) throws IOException
					{
						TextCodec dc = Io.getDefaultCodec();
						return ((TextCodec)dc.getCopy()).encodeText(Vm.getStringChars(data),0,data.length(),true,dest);
					}
//					-------------------------------------------------------------------
					protected String getResponseCode(String code,String message)
//					-------------------------------------------------------------------
					{
						return "HTTP/1.0 "+code+" "+message+"\r\n"; 
					}
					protected void sendToClient(ByteArray data,PropertyList props) throws IOException
					{
						sendToClient(getResponseCode("200","Found"),data,props);
					}
//					===================================================================
					protected void sendToClient(String response,ByteArray data,PropertyList props) throws IOException
//					===================================================================
					{
						ByteArray header = new ByteArray();
						toBytes(response,header);
						if (props != null){
							for (int i = 0; i<props.size(); i++){
								Property p = (Property)props.get(i);
								String s = p.name+": "+p.value+"\r\n";
								toBytes(s,header);
							}
						}
						
						toBytes("Content-length: "+data.length+"\r\n\r\n",header);
						out.write(header.data,0,header.length);
						out.write(data.data,0,data.length);
					}
					void addProperty(Properties dest,String name, TextDecoder decoder, String def)
					{
						String v = decoder.getValue(name);
						if (v == null) v = def;
						if (v == null) return;
						dest.put(name,v);
					}
					String addProperty(String dest,String name, TextDecoder decoder, String def)
					{
						String v = decoder.getValue(name);
						if (v == null) v = def;
						if (v == null) return dest;
						dest = dest+" "+v;
						return dest;
					}
					public String makeTwo(String left, String right)
					{
						return "<tr><td>"+left+"</td><td>"+right+"</td></tr>\r\n";
					}
					protected void doRunHttpServer() throws IOException
					{
						out = s.getOutputStream();
						br = new BufferedReader(new InputStreamReader(s.getInputStream()));
						String rq = br.readLine();
						//System.out.println(rq);
						String[] req = mString.split(rq,' ');
						while(true){
							String line = br.readLine();
							if (line == null || line.trim().length() == 0) break;
						}
						boolean sent = false;
						if (req.length >= 3 && req[0].toUpperCase().equals("GET")){
							String location = req[1];
							if (location.length() == 0 || location.equals("/")){
								String ret = RemoteAppEntry.getHtml(true);
								ret += "<h1>Available Applets</h1><hr>\r\n";
								ret += "<table>";
								for (int i = 0; i < appNames.length; i++){
									ret += "<tr><td><a href=\""+smallNames[i]+"\"><b>"+appNames[i]+"</b></a></td>";
									ret += "<td><a href=\""+smallNames[i]+"?\"><i>[Click here to configure runtime options]</i></a></td></tr>\r\n";
								}
								ret += "</table><hr>\r\n";
								sendToClient(toBytes(ret,null),null);
								sent = true;
							}
							if (!sent){
								if (location.startsWith("/"))
									location = location.substring(1);
								int qt = location.indexOf('?');
								String pars = null;
								int idx = location.indexOf('/');
								String appName = idx == -1 ? location : location.substring(0,idx);
								if (qt != -1) appName = location.substring(0,qt);
								if (qt != -1) pars = location.substring(qt+1);
								int tw = appName.indexOf('~');
								if (tw != -1) appName = appName.substring(0,tw);
								RemoteAppEntry re = (RemoteAppEntry)entries.get(appName);
								for (int i = 0; re == null && i<appNames.length; i++){
									if (appNames[i].equalsIgnoreCase(appName))
										re = (RemoteAppEntry)entries.get(appNames[i]);
									if (re == null && smallNames[i].equalsIgnoreCase(appName))
										re = (RemoteAppEntry)entries.get(appNames[i]);
								}
								if (re != null){
									if (qt != -1){
										if (pars.length() == 0){
											String ret = re.getHtml(true);
											ret += "<center><h1>"+appName+"</h1><h2>Configure Applet</h2></center><br>";
											/*
											ret += "<b>Note:</b> You will have to clear the Java Classloader Cache before starting a new Applet or before restarting an Applet with a different configuration.<br>";
											ret += "To do that click on the Java icon in the task bar and open the Java Console and then press 'x' in the console.<br>You may have to open the console from the Browser Tools menu.<br>";
											*/
											/*
											ret += "Or you can click <a href=\"/"+appName+"?\" target=_new>here</a> to open a new browser window.<br>\r\n";
											ret += "But if the link above opens a new Tab then right-click on the link and select \"Open Link in New Window\".<br>\r\n";
											*/
											ret += "<hr><form method=get>\r\n";
											ret += "<table>";
											ret += makeTwo("Device Type:","<SELECT name=formFactor>"+
													optionIt("Desktop","",true)
													+optionIt("PocketPC","/p /r")
													+optionIt("PocketPC Windows Mobile 5","/p5 /r")
													+optionIt("PocketPC Windows Mobile 6","/p6 /r")
													+optionIt("SmartPhone","/s /r")
													+optionIt("SmartPhone Windows Mobile 5","/s5 /r")
													+optionIt("SmartPhone Windows Mobile 6","/s6 /r")
													+"</SELECT>\r\n");
											ret += makeTwo("Screen Rotation:","<SELECT name=rotation>"+
													optionIt("None","",true)
													+optionIt("Right","/R90")
													+optionIt("Left","/R270")
													+optionIt("Inverted","/R180")
													+"</SELECT>\r\n");
											
											ret += makeTwo("Use Screen/Applet Size:","<input type=checkbox name=overrideScreen value=true>"+
													" Width: <input type=text name=frameWidth size=10 value=\"400\">"+
													" Height: <input type=text name=frameHeight size=10 value=\"400\">");
											ret += makeTwo("Automatic SIP:","<input type=checkbox name=autoSIP value=true>");
											ret += makeTwo("Run Applet In Window:","<input type=checkbox name=useFrame value=true checked>");
											ret += makeTwo("Allow Multiple Windows:","<input type=checkbox name=multipleFrames value=true checked>");
											ret += makeTwo("VM Options:","<input type=text name=vmOptions size=40>");
											ret += makeTwo("Runtime Arguments:","<input type=text name=arguments size=40>");
											ret += "</table>";
											ret += "<br><button type=submit>Run Applet</button><br>\r\n";
											ret += "</form><hr>\r\n";
											ret += re.getHtml(false);
											sendToClient(toBytes(ret,null),null);
											sent = true;
										}else{
											TextDecoder td = new TextDecoder(pars);
											//System.out.println(td);
											String vmOptions = td.getValue("vmOptions");
											if (vmOptions != null && vmOptions.trim().length() == 0)
												vmOptions = null;
											String arguments = td.getValue("arguments");
											if (arguments != null && arguments.trim().length() == 0)
												arguments = null;
											Properties params = new Properties();
											addProperty(params,"useFrame",td,"false");
											addProperty(params,"frameWidth",td,"400");
											addProperty(params,"frameHeight",td,"400");
											if (vmOptions == null) vmOptions = "";
											vmOptions = addProperty(vmOptions,"formFactor",td,null);
											vmOptions = addProperty(vmOptions,"rotation",td,null);
											if (td.getValue("multipleFrames") == null){
												vmOptions = "/n "+vmOptions;
											}
											if (td.getValue("autoSIP") == null){
												vmOptions = "/i "+vmOptions;
											}
											boolean overrideSize = td.getValue("overrideScreen") != null;
											if (overrideSize)
												vmOptions = "/w "+params.getProperty("frameWidth")+" /h "+params.getProperty("frameHeight")+" "+vmOptions;
											sendToClient(toBytes(re.getFullHtmlPage("/"+appName+"~"+nextNumber(),vmOptions,arguments,params),null),null);
											sent = true;
										}
									}else{
										String resource = idx == -1 ? "" : location.substring(idx+1);
										if (resource.length() == 0){
											sendToClient(toBytes(re.getFullHtmlPage("/"+appName+"~"+nextNumber(),null,null,null),null),null);
											sent = true;
										}else{
											byte[] get = re.getResource(resource);
											if (get != null){
												sendToClient(new ByteArray(get),null);
												sent = true;
											}
										}
									}
								}
							}
						}
						if (!sent){
							sendToClient(getResponseCode("404","Not Found"),
								toBytes(RemoteAppEntry.getHtml(true)+"<h1>Document Not Found<h1><p>The URL:  was not found on this server.</p>"+RemoteAppEntry.getHtml(false),null),
								null);
							sent = true;
						}
						s.close();
					}
					protected void doRunAppServer(){
						AppServer obj = new AppServer(){

							public byte[] authenticate(byte[] loginCertficate) throws SecurityException {
								// TODO Auto-generated method stub
								return null;
							}

							public String[] getApplications() {
								return appNames;
							}

							public Property getApplicationProperties() {
								// TODO Auto-generated method stub
								return null;
							}

							public byte[] getApplicationZip() throws IOException {
								// TODO Auto-generated method stub
								return null;
							}
							public byte[] getApplicationEve() throws IOException {
								// TODO Auto-generated method stub
								return null;
							}

							public byte[] getDeflatedResource(String resourceName) throws IOException {
								// TODO Auto-generated method stub
								return null;
							}

							public byte[] getResource(String resourceName) throws IOException {
								// TODO Auto-generated method stub
								return null;
							}
							
						};
						try{
							//System.out.println("Got connection!");
							final RemoteCallHandlerObject ro = new RemoteCallHandlerObject(s.getInputStream(),s.getOutputStream());
							ro.addTarget(null,obj,AppServer.class);
							for (int i = 0; i<appNames.length; i++)
								ro.addTarget(appNames[i],entries.get(appNames[i]),AppServer.class);
							ro.runInSingleThread = true;
							//ro.start();
							ro.run();
							//System.out.println("Leaving.");
						}catch(IOException e){
							
						}finally{
							try{s.close();}catch(Exception e){}
						}
					}
				}.start();
			}catch(Exception e){
				break;
			}
		}
	}
}
//####################################################

