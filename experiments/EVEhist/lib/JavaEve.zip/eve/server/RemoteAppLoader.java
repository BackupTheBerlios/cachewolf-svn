/*
 * Created on May 29, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.server;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.Socket;

import eve.data.EncodableObject;
import eve.data.Property;
import eve.io.ByteArrayRandomStream;
import eve.io.InflaterInputStream;
import eve.io.Io;
import eve.io.block.RemoteCallTask;
import eve.io.filestore.EveFile;
import eve.io.filestore.FileStore;
import eve.net.Net;
import eve.sys.Convert;
import eve.sys.Handle;
import eve.sys.Reflection;
import eve.sys.Task;
import eve.sys.TimeOut;
import eve.sys.Type;
import eve.sys.Vm;
import eve.util.TextDecoder;
import eve.util.mClassLoader;
import eve.zipfile.ZipFile;

//####################################################
public class RemoteAppLoader extends EncodableObject{

public String hostName = "";
public int hostPort = 2000;
public String applicationName = "";

public static void runIt(Class cl) throws Exception
{
	Method m = Reflection.getMethod(cl,"main([Ljava/lang/String;)V",true);
	if (m != null && Modifier.isStatic(m.getModifiers())){
		m.invoke(null,new Object[]{new String[0]});
		return;
	}
	Object obj = cl.newInstance();
	if (obj instanceof Runnable){
		((Runnable)obj).run();
		Vm.exit(0);
		return;
	}
	Type ty = new Type("eve.ui.Form");
	if (ty.exists() && ty.isInstance(obj)){
		m = ty.getMethod("execute()I");
		if (m != null){
			m.invoke(obj,new Object[0]);
		}
		Vm.exit(0);
		return;
	}
}

public boolean runIt(String className, ClassLoader loader) throws ClassNotFoundException
{
	loaderProgress(PROGRESS_LOADING_STARTING_CLASS,null);
	Class runClass = null;
	try{
		runClass = Class.forName(className,true,loader);
	}finally{
		loaderProgress(PROGRESS_LOADED_STARTING_CLASS,null);
	}
	try{
		runIt(runClass);
	}catch(Throwable e){
		e.printStackTrace();
	}
	return true;
}
private ClassLoader getLoader(AppServer app, boolean isZip)
{
	try{
		byte[] zip = isZip ? app.getApplicationZip() : app.getApplicationEve();
		if (zip == null) return null;
		ByteArrayRandomStream rs = new ByteArrayRandomStream(zip,0,zip.length,"r"); 
		FileStore zf = isZip ? (FileStore)new ZipFile(rs) : (FileStore)new EveFile(rs,"EveFile");
		mClassLoader cl = new mClassLoader();
		cl.fileStore = zf;
		return cl;
	}catch(Exception e){
		return null;
	}
}

public ClassLoader getClassLoader(final AppServer app)
{
	Handle h = new Task(){
		protected void doRun(){
			ClassLoader cl = getLoader(app,true);
			if (cl == null) cl = getLoader(app,false);
			succeed(cl);
		}
	}.start();
	if (!h.waitUntilCompletion(new TimeOut(1000))){
		loaderProgress(PROGRESS_LOADING_EVE_OR_ZIP,h);
		try{
			h.waitUntilCompletion();
		}finally{
			loaderProgress(PROGRESS_LOADED_EVE_OR_ZIP,h);
		}
	}
	if (!(h.returnValue instanceof ClassLoader))
		h.returnValue = new mClassLoader(){
			public InputStream openResource(String name)
			{
				try{
					//System.out.println("Want: "+name);
					byte[] got = app.getDeflatedResource(name);
					//System.out.println("Got: "+name);
					if (got == null) return null;
					return new InflaterInputStream(new ByteArrayInputStream(got));
				}catch(Exception e){
					e.printStackTrace();
					return null;
				}
			}
		};
	return (ClassLoader)h.returnValue;
}

protected static final int PROGRESS_LOADING_EVE_OR_ZIP = 1;
protected static final int PROGRESS_LOADED_EVE_OR_ZIP = 2;
protected static final int PROGRESS_LOADING_STARTING_CLASS = 3;
protected static final int PROGRESS_LOADED_STARTING_CLASS = 4;

protected void loaderProgress(int progress,Handle handle)
{
	
}
protected String selectApplication(String[] availableApps)
{
	if (availableApps == null || availableApps.length == 0) return null;
	return availableApps[0];
}

public boolean runClient(Socket sock, String saveConfigName) throws Exception
{
	Vm.setProperty("RemoteAppServerHost",Net.getRemoteAddress(sock).getHostAddress());
	Vm.setProperty("RemoteAppServerPort",Convert.toString(sock.getPort()));
	if (applicationName == null) applicationName = "";
	else applicationName = applicationName.trim();
	try{
		RemoteCallTask rt = RemoteCallTask.createProxyClient(sock);
		AppServer s = (AppServer)rt.createProxy(AppServer.class);
		String[] all = s.getApplications();
		if (applicationName == null) applicationName = "";
		if (applicationName.length() != 0){
			String was = applicationName;
			applicationName = "";
			for (int i = 0; i<all.length; i++)
				if (all[i].equalsIgnoreCase(was)){
					applicationName = all[i];
					break;
				}
		}
		if (applicationName.length() == 0){
			applicationName = selectApplication(all);
			if (applicationName == null) {
				applicationName = "";
				return false;
			}
		}
		if (saveConfigName != null)
			try{
				Io.saveConfigInfo(textEncode(),"EweSoft\\Eve\\AppLoader",Io.SAVE_IN_FILE_OR_REGISTRY);
			}catch(Exception e){}
		//
		final AppServer app = (AppServer)rt.createProxy(AppServer.class,applicationName);
		Property p = app.getApplicationProperties();
		if (p == null || p.name == null || !(p.value instanceof String)) throw new Exception("Bad response to getApplicationProperties() from server.");
		String props = p.value.toString();
		TextDecoder td = new TextDecoder(props);
		for (int i = 0; i<td.size(); i++){
			Vm.setProperty(td.getName(i),td.getValue(i));
		}
		runIt(p.name,getClassLoader(app));
		return true;
	}catch(Exception e){
		throw e;
	}
}
/*
public static void main(String args[])
{
	Application.startApplication(args);
	RemoteAppLoader rl = new RemoteAppLoader();
	try{
		String got = Io.getConfigInfo("EweSoft\\Eve\\AppLoader");
		if (got != null) rl.textDecode(got);
	}catch(Exception e){}
	//Handle h = 
	Application.exit(0);
}
*/
}
//####################################################
