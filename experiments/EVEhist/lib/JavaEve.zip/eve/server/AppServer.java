/*
 * Created on May 29, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.server;

import java.io.IOException;

import eve.data.Property;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface AppServer {

	public byte[] authenticate(byte[] loginCertficate) throws SecurityException;
	public String[] getApplications();
	/*
	 * The returned property will have the name be equal to the start class
	 * of the application. The data for the application will be an array of
	 * properties in the form "name=property". You should call Vm.setProperty()
	 * for each one. The starting class will use these properties.
	 * 
	 */
	public Property getApplicationProperties();
	public byte[] getApplicationZip() throws IOException;
	public byte[] getApplicationEve() throws IOException;
	public byte[] getDeflatedResource(String resourceName) throws IOException;
	public byte[] getResource(String resourceName) throws IOException;
	
}

//####################################################
