/*
 * Created on May 29, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.server;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

import eve.data.Property;
import eve.io.ByteArrayRandomStream;
import eve.io.File;
import eve.io.Io;
import eve.io.StreamUtils;
import eve.io.filestore.EveFile;
import eve.io.filestore.FileStore;
import eve.io.filestore.FileStoreEntry;
import eve.sys.Device;
import eve.sys.Time;
import eve.sys.Vm;
import eve.util.ByteArray;
import eve.util.TextEncoder;
import eve.zipfile.ZipFile;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class RemoteAppEntry implements AppServer{
	
	class ResourceEntry{
		Object myFileOrStore;
		long modTime;
		byte[] data;
		IOException error;
		Time aTime = new Time();
		long getModified() throws IOException
		{
			return myFileOrStore instanceof File ? ((File)myFileOrStore).getModified(aTime).getTime() : 0;
		}
	}
	static final String FileStoreHashtableEntry = "*FileStore*";
	public String applicationName;
	public String arguments;
	public String vmOptions;
	public String startClass;
	/** This can be null if no zip file is used. **/
	public File zipFile;
	/** This can be null if no eve file is used. **/
	public File eveFile;
	/**
	 * To this you can add Files, or FileStores or Objects returned by
	 * makeSharedFileStoreEntry().
	 * This can remain empty if a zip file or an eve file is used. **/ 
	public Vector directories = new Vector();
	/** Use addProperty() to add properties to this Vector. **/
	public Properties properties = new Properties();
	/*{
		properties.setProperty("One","is uno");
		properties.setProperty("Two","=is dos");
	}*/
	public int appletWidth = 400;
	public int appletHeight = 400;
	public boolean appletUsesFrames = true;
	
	/**
	 * Set this value to display a custom HTML page. Place the text &lt;APPLET&gt;
	 * within the HTML where you would like the applet to appear. If you leave
	 * it out the applet will be placed at the end and an ending BODY and HTML
	 * tag will be added.
	 */
	public String fullPageHtml;
	
	public String makeHtmlLinkToResource(String resourceName,boolean putQuotes)
	{
		String ret = getLinkName()+"/"+resourceName;
		if (putQuotes) ret = "\""+ret+"\"";
		return ret;
	}
	private static Object javaEveStore;
	private static File javaEveStoreDir;
	
	private static void setTheJavaEveStore(FileStore fs)
	{
		javaEveStore = makeSharedFileStoreEntry(fs);
	}
	/**
	 * 
	 *
	 */
	public static void setJavaEveStore(Object knownStore) throws FileNotFoundException
	{
		if (knownStore instanceof String)
			knownStore = File.getNewFile((String)knownStore);
		
		if (knownStore instanceof File){
			File je = (File)knownStore;
			if (je.isDirectory()) {
				javaEveStoreDir = je;
				return;
			}
			if (je.canRead()) try{
				knownStore = new ZipFile(je);
			}catch(Exception e){
				throw new FileNotFoundException(je.toString()+" is not a valid Zip/Jar file.");
			}else throw new FileNotFoundException(je.toString());
		}
		
		if (knownStore instanceof FileStore){
			setTheJavaEveStore((FileStore)knownStore);
			return;
		}
		throw new FileNotFoundException(knownStore+" does not provide the Eve Java classes.");
	}
	/**
	 */
	public void enableForApplet() throws IOException, FileNotFoundException
	{
		if (zipFile != null)
			directories.add(new ZipFile(zipFile));
		if (eveFile != null)
			directories.add(new EveFile(eveFile.toRandomStream("r"),eveFile.getFileExt()));
		if (javaEveStoreDir != null){
			directories.add(javaEveStoreDir);
			return;
		}
		if (javaEveStore == null){
			File found = null;
			String got = Device.getPathToVm();
			if (got != null) found = File.getNewFile(got).getParentFile().getChild("eve.jar");
			if (found == null || !found.exists())
				throw new FileNotFoundException("Cannot locate eve.jar for Applet.");
			if (false){// Low memory version.
				setJavaEveStore(found);
			}else{
				//
				InputStream in = found.toReadableStream();
				ByteArray ba = StreamUtils.readAllBytes(null,in, null);
				in.close();
				ByteArrayRandomStream bar = new ByteArrayRandomStream(ba,"r");
				FileStore fs = new ZipFile(bar);
				setJavaEveStore(fs);
			}
		}
		directories.add(javaEveStore);
	}
	/**
	 * Use this to have a single FileStore be shared among any number of
	 * RemoteAppEntries.
	 * After using this you can then add the returned Object to the
	 * directories vector of any entry.
	 * @param store the FileStore to make shared.
	 * @return an Oject that should be added to the directories vector. 
	 */
	public static Object makeSharedFileStoreEntry(FileStore store)
	{
		Hashtable ht = new Hashtable();
		ht.put(FileStoreHashtableEntry,store);
		return ht;
	}
	public RemoteAppEntry(String applicationName,String className)
	{
		this.applicationName = applicationName;
		startClass = className;
	}
	
	public void addProperty(String name, String value)
	{
		properties.put(name,value);
	}
	
	/* (non-Javadoc)
	 * @see eve.server.AppServer#authenticate(byte[])
	 */
	public byte[] authenticate(byte[] loginCertficate) throws SecurityException {
		// TODO Auto-generated method stub
		return null;
	}
	/* (non-Javadoc)
	 * @see eve.server.AppServer#getApplications()
	 */
	public String[] getApplications() {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * Get all the Properties for this entry as an encoded String.
	 */
	public String getEncodedProperties()
	{
		TextEncoder te = new TextEncoder();
		te.addValues(properties);
		return te.toString();
	}
	/* (non-Javadoc)
	 * @see eve.server.AppServer#getApplicationProperties(java.lang.String)
	 */
	public Property getApplicationProperties() {
		Property p = new Property();
		p.name = startClass;
		p.value = getEncodedProperties();
		return p;
	}
	/**
	 * Get a name for the application suitable for use in a link (no spaces).
	 */
	public String getLinkName()
	{
		char[] c = Vm.getStringChars(applicationName);
		StringBuffer sb = new StringBuffer();
		for (int ch = 0; ch < c.length; ch++)
			if (c[ch] != ' ') sb.append(c[ch]);
		return sb.toString();
	}	
	private static byte[] getFileData(File f) throws IOException
	{
		if (f == null || !f.exists() || !f.canRead()) return null;
		InputStream in = f.toReadableStream();
		ByteArray ba = StreamUtils.readAllBytes(null,in,null);
		in.close();
		return ba.toBytes();
	}
	/* (non-Javadoc)
	 * @see eve.server.AppServer#getApplicationZip()
	 */
	public byte[] getApplicationZip() throws IOException {
		return getFileData(zipFile);
	}
	private Hashtable resources = new Hashtable();

	private Object findResource(String name)
	{
		for (int i = 0; i<directories.size(); i++){
			Object dr = directories.get(i);
			if (dr instanceof File){
				File f = (File)dr;
				f = f.getChild(name);
				if (f.exists() && !f.isDirectory()) {
					//System.out.println("Load: "+name);
					return f;
				}
			}else if (dr instanceof FileStore){
				FileStore fs = (FileStore)dr;
				synchronized(fs){
					try{
						FileStoreEntry fe = fs.findEntry(name);
						if (fe != null) return fs;
					}catch(Exception e){
					}
				}
			}else if (dr instanceof Hashtable){
				Hashtable ht = (Hashtable)dr;
				Object got = ht.get(name);
				if (got instanceof byte[]) return ht;
				got = ht.get(FileStoreHashtableEntry);
				if (got instanceof FileStore){
					FileStore fs = (FileStore)got;
					synchronized(fs){
						try{
							FileStoreEntry fe = fs.findEntry(name);
							if (fe != null) return ht;
						}catch(Exception e){
						}
					}					
				}
			}
		}
		if (name.equals("_properties.txt"))try{
			String got = getEncodedProperties();
			return Io.getDefaultCodec().encodeText(Vm.getStringChars(got),0,got.length(),true,null);
		}catch(Exception e){}
		return null;
	}
	private static File lf;
	private static ByteArray lfs, lfc;
	private static Object[] locals;
	
	
	static{
		if (true){
			locals = new Object[2];
			locals[0] = "C:/projects/eve/java_eve_classes";
			locals[1] = "C:/projects/eve/classes";
		}
	};

	private static byte[] tryLocal(File dir,String name) throws IOException
	{
		if (lf == null) lf = dir.getChild(name);
		else lf.set(dir, name);
		if (!lf.canRead()) return null;
		InputStream in = lf.toReadableStream();
		if (lfs != null) lfs.clear();
		lfs = StreamUtils.readAllBytes(null,in, lfs);
		in.close();
		if (lfc != null) lfc.clear();
		else lfc = new ByteArray();
		Io.deflate(lfs.data, 0, lfs.length, lfc);
		return lfc.toBytes();
	}
	private byte[] getCompressed(String name) throws IOException
	{
		if (locals != null) 
		{
			for (int i = 0; i<locals.length; i++){
				Object obj = locals[i];
				if (!(obj instanceof File))
					obj = (locals[i] = File.getNewFile(obj.toString()));
				byte[] ret = tryLocal((File)obj,name);
				if (ret != null) return ret;
			}
		}
		ResourceEntry w = null;
		synchronized(resources){
			w = (ResourceEntry)resources.get(name);
			if (w == null){
				Object found = findResource(name);
				if (found == null) return null;
				w = new ResourceEntry();
				if (found instanceof byte[]){
					byte[] r = (byte[])found;
					found = new ByteArray(r);
				}
				if (found instanceof ByteArray){
					ByteArray ff = (ByteArray)found;
					ByteArray r = new ByteArray();
					Io.deflate(ff.data,0,ff.length,r);
					w.myFileOrStore = null;
					w.data = r.toBytes();
				}else{
					w.myFileOrStore = found;
				}
				w.modTime = w.getModified();
				resources.put(name,w);
			}
		}
		synchronized(w){
			if (w.modTime != w.getModified()){
				w.data = null;
			}
			if (w.data == null) try{
				//System.out.println("Loading: "+w.myFile);
				ByteArray src = null;
				if (w.myFileOrStore instanceof File){
					File mf = (File)w.myFileOrStore;
					InputStream in = mf.toReadableStream();
					src = StreamUtils.readAllBytes(null,in,null);
					in.close();
				}else if (w.myFileOrStore instanceof FileStore){
					synchronized(w.myFileOrStore){
						FileStoreEntry fe = ((FileStore)w.myFileOrStore).findEntry(name);
						if (fe != null) {
							InputStream in = ((FileStore)w.myFileOrStore).openInputStream(fe);
							src = StreamUtils.readAllBytes(null,in,null);
							in.close();
						}
					}
				}else if (w.myFileOrStore instanceof Hashtable){
					Hashtable ht = (Hashtable)w.myFileOrStore;
					Object got = ht.get(name);
					if (got instanceof byte[]) {
						w.data = (byte[])got;
						w.notifyAll();
						return w.data;
					}
					got = ht.get(FileStoreHashtableEntry);
					if (got instanceof FileStore){
						FileStore fs = (FileStore)got;
						synchronized(fs){
							FileStoreEntry fe = fs.findEntry(name);
							if (fe != null){
								InputStream in = fs.openInputStream(fe);
								src = StreamUtils.readAllBytes(null,in,null);
								in.close();
							}
						}
					}
				}
				if (src == null) throw new IOException("Could not access the bytes.");
				ByteArray ba = new ByteArray();
				int did = Io.deflate(src.data,0,src.length,ba);
				w.modTime = w.getModified();
				w.data = ba.toBytes();
				if (w.myFileOrStore instanceof Hashtable){
					((Hashtable)w.myFileOrStore).put(name,w.data);
				}
				w.notifyAll();
				return w.data;
			}catch(IOException e){
				w.error = e;
				w.notifyAll();
				throw e;
			}
			while (w.data == null && w.error == null) try{
				w.wait();
			}catch(InterruptedException e){}
			if (w.data != null) return w.data;
			throw w.error;
		}
	}
	
	/* (non-Javadoc)
	 * @see eve.server.AppServer#getDeflatedResource(java.lang.String)
	 */
	public byte[] getDeflatedResource(String resourceName) throws IOException {
		try{
			//System.out.println("Looking for: "+resourceName);
			return getCompressed(resourceName);
		}catch(IOException e){
			//e.printStackTrace();
			throw e;
		}finally{
			//System.out.println("Done with: "+resourceName);
		}
	}
	/* (non-Javadoc)
	 * @see eve.server.AppServer#getResource(java.lang.String)
	 */
	public byte[] getResource(String resourceName) throws IOException {
		ByteArray got = new ByteArray();
		byte[] src = getCompressed(resourceName);
		if (src == null) return null;
		Io.inflate(src,0,src.length,got);
		return got.toBytes();
	}

	/* (non-Javadoc)
	 * @see eve.server.AppServer#getApplicationEve()
	 */
	public byte[] getApplicationEve() throws IOException {
		return getFileData(eveFile);
	}
	
	String addIfPresent(String current,String toAdd)
	{
		if (toAdd != null && toAdd.trim().length() != 0)
			current = current+toAdd.trim()+" ";
		return current;
	}
	public static String toParam(String name, String value)
	{
		return "<PARAM name=\""+name+"\" value=\""+value+"\">\r\n";
	}
	public String getAppletCommandLine(String vmOptions,String arguments)
	{
		String ret = "";
		if (vmOptions == null) vmOptions = this.vmOptions;
		if (arguments == null) arguments = this.arguments;
		ret = addIfPresent(ret,vmOptions);
		ret = addIfPresent(ret,startClass);
		ret = addIfPresent(ret,arguments);
		if (ret.length() != 0)
			return toParam("commandLine",ret);
		else return "";
	}
	public String getAppletTag(String codeBase,String vmOptions,String arguments,Properties params)
	{
		String ret = "";
		String aWidth = ""+appletWidth;
		String aHeight = ""+appletHeight;
		if (params == null){
			if (appletUsesFrames) {
				ret += toParam("useFrame","true");
				ret += toParam("frameWidth",aWidth);
				ret += toParam("frameHeight",aHeight);
				aWidth = aHeight = "2";
			}
		}else{
			String v = params.getProperty("useFrame","false");
			if (!v.toUpperCase().startsWith("T")){
				aWidth = params.getProperty("frameWidth",aWidth);
				aHeight = params.getProperty("frameHeight",aHeight);
			}else{
				aWidth = aHeight = "2";
				ret += toParam("useFrame","true");
				ret += toParam("frameWidth",params.getProperty("frameWidth","400"));
				ret += toParam("frameHeight",params.getProperty("frameHeight","400"));
			}
		}
		ret = "<center><APPLET codebase=\""+codeBase+"\" code=\"eve.applet.EveApplet\" \n"+
	    "width=\""+aWidth+"\" height=\""+aHeight+"\" align=\"baseline\">\r\n"
			+ret;
		ret += getAppletCommandLine(vmOptions,arguments);
		ret += "</APPLET></center>";
		return ret;
	}
	static String getHtml(boolean start)
	{
		if (start) return "<html><body>\r\n";
		else return "</body></html>\r\n";
	}
	
	public String getFullHtmlPage(String codeBase,String vmOptions,String arguments,Properties params)
	{
		String ret = "";
		String appTag = getAppletTag(codeBase,vmOptions,arguments,params);
		if (fullPageHtml != null){
			int idx = fullPageHtml.indexOf("<APPLET>");
			if (idx == -1) idx = fullPageHtml.indexOf("<applet>");
			if (idx == -1) ret = fullPageHtml;
			else ret = fullPageHtml.substring(0,idx);
			ret += appTag;
			if (idx == -1) ret += getHtml(false);
			else ret += fullPageHtml.substring(idx+8);
			return ret;
		}
		boolean uf = appletUsesFrames;
		if (params != null)
			uf = params.getProperty("useFrame","false").toUpperCase().startsWith("T");
		ret += getHtml(true)+"<center><h1><img align=center src="+makeHtmlLinkToResource("eve/eve64.png",true)+">";
		ret += applicationName+"</h1>"+
		(uf ? "The Applet will appear in a new frame when loaded." : "The Applet will appear below when loaded.")+"</center><br><hr>"+
		appTag+
		getHtml(false);
		return ret;
	}
	
}
//####################################################
