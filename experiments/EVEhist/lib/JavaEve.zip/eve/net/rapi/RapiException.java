package eve.net.rapi;

import java.io.IOException;

import eve.sys.Vm;

public class RapiException extends IOException {

	public RapiException() {
		// TODO Auto-generated constructor stub
	}

	public RapiException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RapiException(String message, Throwable cause)
	{
		super(message);
		Vm.setCause(this, cause);
	}
	public RapiException(Throwable cause)
	{
		super();
		Vm.setCause(this, cause);
	}
	
}
