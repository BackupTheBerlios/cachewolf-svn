package eve.net.rapi;

import java.util.Vector;

import eve.io.FileSpecs;
import eve.sys.Cache;
import eve.sys.Time;

//##################################################################
public class Rapi{
//##################################################################

	private static native String initLibrary(); 
	/**
	 * Attempt to connect to a device.
	 * @param timeoutMillis the maximum time to wait for a successful connection.
	 * @throws RapiException if the connection failed.
	 */
	public static native void connect(int timeoutMillis) throws RapiException;
	/**
	 * Close the connection.
	 * @throws RapiException
	 */
	public static native void close() throws RapiException;
	private static native void nativeGetSystemInfo(SystemInfo si) throws RapiException;
	private static native String nativeGetSpecialFolder(int folder) throws RapiException;
	native static int getRapiFileFlags(String name) throws RapiException;	
	/**
	 * Get the FileSpecs for a list of file names.
	 * @param fileNames a Vector holding a list of file names.
	 * @param specs a destination Vector that will be made to hold one FileSpecs for
	 * each item in fileNames. If specs
	 * already contains FileSpecs objects they are reused starting from the first one.
	 * The size of the vector is never made less, only bigger so that it is always at
	 * least as big as the fileNames Vector. If any item within this size is not a FileSpecs
	 * Object it is discarded and a new FileSpecs object is created and used instead.
	 * @throws RapiException
	 */
	public static native void getFileSpecs(Vector fileNames,Vector specs) throws RapiException;
	/**
	 * List all files in a directory that match the mask.
	 * @param directoryPath the full path of the directory to list.
	 * @param mask the mask for the function to use. If this is null then *.* will be used.
	 * @param specs a destination Vector that will be made to hold one FileSpecs for
	 * each entry found. 
	 * If specs already contains FileSpecs objects they are reused starting from the first one.
	 * The size of the vector is never made less, only bigger so that it is always at
	 * least as big as the number of files found. If any item within this size is not a FileSpecs
	 * Object it is discarded and a new FileSpecs object is created and used instead.
	 * <p>
	 * The name field of each FileSpecs holds ONLY the name within the directory, not
	 * the full path.
	 * @param includeFiles true to include regular (non-directory) files.
	 * @param includeDirectories true to include directories.
	 * @param dontIncludeHidden true to exclude hidden files.
	 * @return the number of files found and therefore the minimum number of FileSpecs
	 * objects that will be present in the specs Vector.
	 * @throws RapiException on a RAPI error.
	 */
	public static native int listAllFiles(String directoryPath, String mask, Vector specs, boolean includeFiles, boolean includeDirectories, boolean dontIncludeHidden) throws RapiException;
	//public static String error = null;
	/**
	 * Send an execute command to the remote device.
	 * @param path the path of the executable on the remote device.
	 * @param parameters parameters for executing the command.
	 * @throws RapiException on error.
	 */
	public  static native void execute(String path,String parameters) throws RapiException;
	private static native void nativeCreateShortcut(String target,String arguments,String shortcutPath) throws RapiException;
	
	public static synchronized void initializeLibrary() throws RapiException
	{
		String got = initLibrary();
		if (got == null) return;
		throw new RapiException(got);
	}

/**
 * A simplified method that initializes the library and makes a connection
 * if possible. This may be called multiple times during an application.
 * @param timeoutInMillis a timeout for the connection attempt in milliseconds.
 * @return true on success, false on error.
 */
	public static boolean tryConnect(int timeoutInMillis)
	{
		try{
			initializeLibrary();
			connect(timeoutInMillis);
			return true;
		}catch(Throwable t){
			return false;
		}
	}
/**
 * Return the SystemInfo for the connected system.
 * @throws RapiException
 */
public static SystemInfo getSystemInfo() throws RapiException
//===================================================================
{
	SystemInfo si = new SystemInfo();
	nativeGetSystemInfo(si);
	return si;
}

public static final int FOLDER_WINDOWS            = -1;
public static final int FOLDER_DESKTOP            = 0x0000;
public static final int FOLDER_PROGRAMS           = 0x0002;
public static final int FOLDER_CONTROLS           = 0x0003;
public static final int FOLDER_PRINTERS           = 0x0004;
public static final int FOLDER_PERSONAL           = 0x0005;
public static final int FOLDER_FAVORITES          = 0x0006;
public static final int FOLDER_STARTUP            = 0x0007;
public static final int FOLDER_RECENT             = 0x0008;
public static final int FOLDER_SENDTO             = 0x0009;
public static final int FOLDER_BITBUCKET          = 0x000a;
public static final int FOLDER_STARTMENU          = 0x000b;
public static final int FOLDER_DESKTOPDIRECTORY   = 0x0010;
public static final int FOLDER_DRIVES             = 0x0011;
public static final int FOLDER_NETWORK            = 0x0012;
public static final int FOLDER_NETHOOD            = 0x0013;
public static final int FOLDER_FONTS		 					 = 0x0014;
public static final int FOLDER_TEMPLATES          = 0x0015;

//-------------------------------------------------------------------

/**
 * Get the FileSpecs for an individual file.
 * @param fileName the full path for the file on the device.
 * @param destination a destination FileSpecs or null to create and return a new one.
 * @return the destination or new FileSpecs if the file exists.
 * @throws RapiException on a RAPI error.
 */
public static FileSpecs getFileSpecs(String fileName,FileSpecs destination) throws RapiException
{
	if (fileName == null) throw new NullPointerException();
	if (destination == null) destination = new FileSpecs();
	Vector fn = (Vector)Cache.get(Vector.class), sp = (Vector)Cache.get(Vector.class);
	try{
		fn.clear(); sp.clear();
		fn.add(fileName);
		sp.add(destination);
		getFileSpecs(fn, sp);
		return (FileSpecs)sp.elementAt(0);
	}finally{
		Cache.put(fn); Cache.put(sp);
	}
}

static final int FILE_EXISTS = 0x1;
static final int FILE_IS_DIRECTORY = 0x2;
static final int FILE_IS_READ_ONLY = 0x4;
static final int FILE_IS_HIDDEN = 0x8;

//-------------------------------------------------------------------
private static String checkFolder(String name,String alternate)
//-------------------------------------------------------------------
{
	try{
		int get = getRapiFileFlags(name);
		if ((get & FILE_IS_DIRECTORY) == 0) return alternate;
		return name;
	}catch(RapiException e){
		return alternate;
	}
}
//===================================================================
public static String getSpecialFolder(int folder) throws RapiException
//===================================================================
{
	if (folder == -1) return "\\Windows";
	String got = nativeGetSpecialFolder(folder);
	if (got != null) got = checkFolder(got,null);
	if (got != null) return got;
	switch(folder){
		case FOLDER_PROGRAMS: return checkFolder("\\Program Files","\\Windows\\Programs");
		case FOLDER_STARTMENU: return checkFolder("\\Windows\\Start Menu","\\Windows\\Programs");
		default: return "\\Windows";
	}
}
/**
 * Create a shortcut to a target.
 * @param target the target executable.
 * @param arguments the arguments for the executable.
 * @param shortcutPath the full path for the shortcut. WindowsCE uses
 * a .lnk extension for a shortcut. If you do not provide an extension
 * for the shortcutPath then .lnk is added to it. If a '.' exists in
 * the path, then .lnk is NOT added.
 * @throws RapiException if there was a RAPI error.
 */
public static void createShortcut(String target,String arguments,String shortcutPath) throws RapiException
//===================================================================
{
	if (target == null || shortcutPath == null) throw new NullPointerException();
	if (target.charAt(0) == '"') target = target.substring(1,target.length()-1);
	if (shortcutPath.indexOf('.') == -1)
		shortcutPath += ".lnk";
	nativeCreateShortcut(target,arguments,shortcutPath);
}
private static void testFile(String file) throws RapiException
{
	FileSpecs fs = getFileSpecs(file, null);
	Time t = (new Time().setTime(fs.modifiedTime)); 
	if (fs != null) System.out.println(fs+" = "+fs.length+", "+t.format("HH:mm:ss dd/MMM/yyyy"));
	else System.out.println(file+" does not exist!");
}
/*
public static void main(String[] args) throws Exception
{
	Application.startApplication(args);
	initializeLibrary();
	connect(1000);
	SystemInfo si = getSystemInfo();
	System.out.println(si);
	String fd = getSpecialFolder(FOLDER_STARTMENU);
	System.out.println(fd+" - "+Integer.toHexString(getRapiFileFlags(fd)));
	fd = "\\Windows\\Start Menu\\Programs\\Eve";
	System.out.println(fd+" - "+Integer.toHexString(getRapiFileFlags(fd)));
	fd = "\\Windows\\Start Menu\\Programs\\Eve\\Eve.exe";
	System.out.println(fd+" - "+Integer.toHexString(getRapiFileFlags(fd)));
	fd = "\\Windows\\Start Menu\\Programs\\Eve-not.exe";
	System.out.println(fd+" - "+Integer.toHexString(getRapiFileFlags(fd)));
	if (false){
		execute("\\Windows\\Start Menu\\Programs\\Eve\\Eve.exe","eve.ui.data.Notepad");
		createShortcut("\\Windows\\Start Menu\\Programs\\Eve\\Eve.exe", "eve.ui.data.Notepad", "\\Windows\\Start Menu\\Programs\\Eve\\MyNotepad.lnk");
	}
	Vector v = new Vector();
	v.add(new FileSpecs());
	v.add(new FileSpecs());
	int got = listAllFiles("\\Windows\\Start Menu\\Programs\\Eve","*.*",v, true, true, false);
	System.out.println("Listed: "+v);
	String[] all = new RapiFile("/").list();
	v.clear();
	mVector.addAll(v,all);
	System.out.println("Listed: "+v);
	
	if (true){
		RegistryView rv = new RegistryView(true);
		rv.execute();
	}
	if (true){
		FileChooser fc = new FileChooser(
				//FileChooser.DIRECTORY_TREE|
				FileChooser.BROWSE,"/windows/start menu/programs/eve",new RapiFile("\\"));
		fc.execute();
	}
	close();
	Vm.exit(0);
}
*/
//##################################################################
}
//##################################################################


