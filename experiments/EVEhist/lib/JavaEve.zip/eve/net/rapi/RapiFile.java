package eve.net.rapi;

import java.io.IOException;
import java.util.Vector;

import eve.io.File;
import eve.io.FileAdapter;
import eve.io.FileSpecs;
import eve.io.RandomStream;
import eve.nativeaccess.NativeRandomStream;
import eve.sys.Cache;
import eve.sys.Wrapper;
import eve.util.CharArray;

//##################################################################
public class RapiFile extends FileAdapter{
//##################################################################

private CharArray rapiFileNativeCreate(CharArray fullPath) {return fullPath;}

private static native long fileLongOp(CharArray name,int which, long value, String data);
private static native int fileStream(CharArray name,String mode) throws IOException;

private long longOp(int whichOp, long value, String stringData)
{
	return fileLongOp(name,whichOp,value,stringData);
}

/**
This is used to implement getPermissionsAndFlags() and changePermissionsAndFlags(). It should
work like this: 
<p>
If isGet is true, then the valuesToSetOrGet parameter will hold the flags that the user is
interested in. 
<p>
If isGet is false, then the valuesToSetOrGet parameter will hold the flags to set and the valuesToClear parameter
will hold the flags to clear. 
<p>
The method should return the final flags for the file.
**/
//-------------------------------------------------------------------
protected int getSetPermissionsAndFlags(boolean isGet, int valuesToSetOrGet, int valuesToClear) throws IOException
//-------------------------------------------------------------------
{
	if (isGet){
		FileSpecs fs = (FileSpecs)Cache.get(FileSpecs.class);
		try{
			Rapi.getFileSpecs(getFullPath(), fs);
			return fs.flagsAndPermissions & valuesToSetOrGet;
		}catch(RapiException e){
			return 0;
		}finally{
			Cache.put(fs);
		}
	}else{
		valuesToSetOrGet &= ALL_DOS_FLAGS;
		valuesToClear &= ALL_DOS_FLAGS;
		return (int)longOp(SETFLAGSPERMISSION_OP,(long)valuesToSetOrGet<<32|(long)valuesToClear,null);
	}
}
/**
 * Returns a value indicating which of the flags
 * specified in the interestedFlags parameter is supported by the
 * underlying system.
 * @param interestedFlags the flags you wish to check OR'ed together.
 * @return the supported flags OR'ed together.
 */
public int getSupportedPermissionsAndFlags(int interestedFlags)
{
	return ALL_DOS_FLAGS & interestedFlags;
}
/**
* Creates a directory. Returns true if the operation is successful and false
* otherwise.
*/
public boolean createDir()
{
	return longOp(CREATEDIR_OP,0,null) != 0;
}
/**
 * Create a symbolic link to a specified target file.
 * @param target the file to link to.
 * @return true if created, false if not (if not supported on the platform).
 */
public boolean createSymbolicLink(String target)
{
	return false;
}
/**
* Deletes the file or directory. Returns true if the operation is
* successful and false otherwise.
*/
public boolean delete()
{
	return longOp(DELETE_OP,0,null) != 0;
}
public boolean canWrite()
{
	FileSpecs fs = (FileSpecs)Cache.get(FileSpecs.class);
	try{
		Rapi.getFileSpecs(getFullPath(), fs);
		return (fs.exists && ((fs.flagsAndPermissions & FLAG_READONLY) == 0));
	}catch(RapiException e){
		return false;
	}finally{
		Cache.put(fs);
	}
	//return longOp(CANWRITE_OP,0,null) != 0;
}
/**
 * This returns true if the file should be considered hidden. On Linux/Unix systems
 * files that start with '.' are considered hidden, while on DOS/Windows
 * systems they are hidden if the HIDDEN attribute is set for the file.
 * @return whether the file should be considered hidden on the running
 * platform.
 */
public boolean isHidden()
{
	FileSpecs fs = (FileSpecs)Cache.get(FileSpecs.class);
	try{
		Rapi.getFileSpecs(getFullPath(), fs);
		return (fs.exists && ((fs.flagsAndPermissions & FLAG_HIDDEN) == 0));
	}catch(RapiException e){
		return false;
	}finally{
		Cache.put(fs);
	}
}
private int getBitFlags()
{
	try{
		return Rapi.getRapiFileFlags(getFullPath());
	}catch(RapiException e){
		return 0;
	}
}

/** Returns true if the file exists and false otherwise. */
public boolean exists()
{
	return ((getBitFlags() & 0x1) != 0);
}

/** Returns true if the file is a directory and false otherwise. */
public boolean isDirectory()
{
	return ((getBitFlags() & 0x2) != 0);
}
/** Returns true if the file is a symbolic link. */
public boolean isSymbolicLink()
{
	//return ((getBitFlags() & 0x20) != 0);
	return false;
}
/**
* This moves/renames the file to the destination new File. The new File
* should not exist.
**/
public boolean move(File newFile)
{
	return longOp(MOVE_OP,0,newFile.getFullPath()) != 0;
}

/* (non-Javadoc)
 * @see eve.io.FileBase#getLength()
 */
public long getLength()
{
	FileSpecs fs = (FileSpecs)Cache.get(FileSpecs.class);
	try{
		Rapi.getFileSpecs(getFullPath(), fs);
		return fs.length;
	}catch(RapiException e){
		return 0;
	}finally{
		Cache.put(fs);
	}
}
private static final int MOVE_OP = 4;
private static final int CREATEDIR_OP = 5;
private static final int DELETE_OP = 6;
private static final int SETMODIFIED_OP = 9;
private static final int GETINFO_OP = 10;
private static final int SETINFO_OP = 11;
private static final int SETFLAGSPERMISSION_OP = 16;

//===================================================================
public void set(File parent,String file)
//===================================================================
{
	setFullPathName(parent,file);
	name = rapiFileNativeCreate(name);
}
//===================================================================
public RapiFile(String file) {this(null,file);}
//===================================================================

//===================================================================
public RapiFile(File parent,String file)
//===================================================================
{
	set(parent,file);
}
//===================================================================
public File getNew(File parent,String file)
//===================================================================
{
	return new RapiFile(parent,file);
}

public Wrapper getInfo(int infoCode, Wrapper sourceParameters, int options)
{
	if (sourceParameters == null) sourceParameters = new Wrapper();
	sourceParameters.clear();
	switch(infoCode){
		case INFO_DEVICE_NAME:
			sourceParameters.setObject("Mobile Device");
			break;
		case INFO_FLAGS:
			sourceParameters.setInt(FLAG_SLOW_ACCESS);
			break;
	}
	return sourceParameters;
}

//-------------------------------------------------------------------
protected long getSetModified(long value,boolean doGet) throws IOException
{
	if (doGet){
		FileSpecs fs = (FileSpecs)Cache.get(FileSpecs.class);
		try{
			Rapi.getFileSpecs(getFullPath(), fs);
			if (!fs.exists) throw new IOException("Can't get modified time.");
			return fs.modifiedTime;
		}catch(RapiException e){
			return 0;
		}finally{
			Cache.put(fs);
		}
	}else{
		if (longOp(SETMODIFIED_OP, value, null) == 0) throw new IOException("Can't set modified time.");
		else return value;
	}
}
//===================================================================
public String getFullPath() {return name.toString();}
//===================================================================
/**
* Create and return a RandomAccessStream for reading/writing to the data associated with this File object.
* @param mode must be "r" or "rw".
* @return An open RandomAccessStream
* @exception IOException if an open stream could not be created.
* @exception IllegalArgument exception if mode is not "r" or "rw"
*/
//===================================================================
public RandomStream toRandomStream(String mode) throws IOException
//===================================================================
{
	RandomStream.validateMode(mode);
	return NativeRandomStream.toRandomStream(fileStream(name, mode),mode);
}

/**
 * This does nothing on a RapiFile.
 */
public void deleteOnExit() 
{
}
/* (non-Javadoc)
 * @see eve.io.FileBase#list(java.lang.String, int)
 */
public String[] list(String mask, int listAndSortOptions)
{
	boolean includeFiles = (listAndSortOptions & LIST_DIRECTORIES_ONLY) == 0; 
	boolean includeDirectories = (listAndSortOptions & LIST_FILES_ONLY) == 0; 
	boolean dontIncludeHidden = (listAndSortOptions & LIST_DONT_LIST_HIDDEN_FILES) != 0; 
	Vector v = new Vector();
	try{
		int got = Rapi.listAllFiles(getFullPath(), mask, v, includeFiles, includeDirectories, dontIncludeHidden);
		if (got == 0) return new String[0];
		v = FileSpecs.filterAndSort(v, mask, listAndSortOptions, null);
		got = v.size();
		String[] all = new String[got];
		for (int i = 0; i<got; i++)
			all[i] = ((FileSpecs)v.get(i)).name;
		return all;
	}catch(RapiException e){
		return new String[0];
	}
}


//##################################################################
}
//##################################################################
