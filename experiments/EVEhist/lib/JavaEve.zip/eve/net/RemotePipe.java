/*
 * Created on Oct 5, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import eve.sys.Convert;
import eve.sys.Handle;
import eve.sys.HandleStoppedException;
import eve.sys.TimeOut;
import eve.sys.Wrapper;
import eve.sys.mThread;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
class RemotePipe {

	private BufferedReader input;
	private PrintWriter output;
	private Socket sock;
	private boolean closed;
	private boolean started;
	
	void debugln(String data)
	{
		if (RemoteServer.db != null)
			RemoteServer.db.println(data);
	}
	public Handle openHandle = new Handle();
	//public RemotePipe(){}
	/*
	 * Create a new RemotePipe for a Socket and start the pipe running. 
	 */
	public RemotePipe(Socket s) throws IOException
	{
		sock = s;
		input = new BufferedReader(new InputStreamReader(s.getInputStream()));
		output = new PrintWriter(s.getOutputStream());
		openHandle.set(Handle.Running);
		start();
	}
	
	synchronized void close() throws IOException
	{
		if (closed) return;
		closed = true;
		//debugln("close input!");
		//input.close();
		//debugln("close output!");
		//output.close();
		//debugln("close pending!");
		for (Enumeration e = pending.elements(); e.hasMoreElements();){
			Handle h = (Handle)e.nextElement();
			h.fail(new IOException("Connection closed."));
		}
		sock.close();
		notifyAll();
		//debugln("Pipe Closed.");
	}
	
	private Vector out = new Vector();
	private Vector in = new Vector();
	private int curCode;
	private Hashtable pending = new Hashtable();
	
	synchronized void sendReply(String toSend,String replyTo)
	{
		if (closed) return;
		out.addElement("reply,"+replyTo+":"+toSend);
		notifyAll();
	}
	//
	TimeOut living = new TimeOut(10000);
	//
	public synchronized void keepAlive()
	{
		if (!RemoteServer.dontKeepAlive) out.addElement("-KeepAlive-");
		notifyAll();
	}
	public synchronized Handle sendCommand(String toSend)
	{
		if (closed) return new Handle(new IOException("Connection closed."));
		Handle h = new Handle();
		String code = Convert.toString(++curCode);
		pending.put(code,h);
		out.addElement("command,"+code+":"+toSend);
		notifyAll();
		return h;
	}
	synchronized void received(String line)
	{
		living.reset();
		//debugln(line);
		if (line.startsWith("command,")){
			Command c = new Command();
			int idx = line.indexOf(':');
			if (idx == -1) return;
			c.command = line.substring(idx+1);
			c.code = line.substring(line.indexOf(',')+1,idx);
			in.add(c);
			notifyAll();
		}else if (line.startsWith("reply,")){
			int idx = line.indexOf(':');
			if (idx == -1) return;
			String code = line.substring(line.indexOf(',')+1,idx);
			Handle h = (Handle)pending.get(code);
			if (h != null) {
				pending.remove(code);
				h.succeed(line.substring(idx+1));
			}
		}else if (line.startsWith("-KeepAlive-")){
			//debugln(line);
		}
	}
	
	public class Command {
		public String command;
		private String code;
		public void reply(String reply)
		{
			sendReply(reply,code);
		}
	}
	
	public boolean isClosed()
	{
		return closed;
	}
	/**
	 * Get the next incomming command.
	 * @param howLong how long to wait. Use TimeOut.Immediate to not wait at all and
	 * TimeOut.Forever to wait indefinitely.
	 * @return the next incoming command or null if no command was available during the
	 * timeout period or if no commands are pending and the pipe is closed. Use isClosed()
	 * to determine if the pipe is closed.
	 * @throws InterruptedException if interrupt() is called on this Thread.
	 */
	public synchronized Command getNextCommand(TimeOut howLong) throws InterruptedException
	{
		if (howLong == null) howLong = TimeOut.Forever;
		while(true){
			if (in.size() != 0){
				Command c = (Command)in.get(0);
				in.removeElementAt(0);
				notifyAll();
				return c;
			}
			if (closed || howLong.hasExpired()) return null;
			howLong.waitOn(this);
		}
	}
	
	public synchronized void start()
	{
		if (started) return;
		started = true;
		new Thread(){
			public void run(){
				synchronized(RemotePipe.this){
					living.reset();
				}
				while(true){
					mThread.nap(1000);
					synchronized(RemotePipe.this){
						if (closed) return;
						if (living.hasExpired()){
							debugln("Keep Alive Expired!");
							try{close();}catch(IOException e){
								}
							return;
						}
						keepAlive();
					}
				}
			}
		}.start();
		new Thread(){
			public void run(){ // The read thread.
				try{
					while(true){
						String got = input.readLine();
						if (got == null) {
							//debugln("Got null line.");
							break;
						}
						received(got);
					}
				}catch(IOException e){
					//debugln("Got read exception.");
				}finally{
					try{
					close();
					}catch(IOException e){}
					openHandle.set(Handle.Stopped);
					//debugln("Read - Leaving!");
				}
			}
		}.start();
		new Thread(){
			public void run(){ // The write thread.
				try{
					while(true){
						String toGo = null;
						synchronized(RemotePipe.this){
							if (out.size() != 0) {
								toGo = (String)out.get(0);
								out.removeElementAt(0);
							}else try{
								if (closed) return;
								RemotePipe.this.wait();
							}catch(Exception e){}
						}
						if (toGo == null) continue;
						//debugln("Sending: "+toGo);
						output.println(toGo);
						output.flush();
					}
				}finally{
					//debugln("Write - leaving.");
				}
			}
		}.start();
	}
	public boolean runCommand(String toSend,Wrapper returnValue)
	{
		try{
			return executeCommand(toSend,returnValue);
		}catch(InterruptedException e){
			if (returnValue != null)
				returnValue.setObject("Interrupted.");
			return false;
		}
	}
	/**
	 * In the case of an error this returns false and an error message is put in
	 * the returnValue as a String. 
	 * @param toSend
	 * @param returnValue
	 * @return
	 * @throws InterruptedException
	 */
	public boolean executeCommand(String toSend, Wrapper returnValue) throws InterruptedException
	{
		Handle h = sendCommand(toSend);
		try{
			h.waitOn(Handle.Success);
			String read = h.returnValue.toString();
			//debugln("<"+read);
			
			int where = read.indexOf(':');
			if (returnValue != null)
				returnValue.setObject(read.substring(where+1).trim());
			return (read.startsWith("OK"));
		}catch(HandleStoppedException e){
			if (returnValue != null)
				returnValue.setObject(h.error == null ? "Unknown error!" : h.error.getMessage());
			return false;
		}
	}
}

//####################################################
