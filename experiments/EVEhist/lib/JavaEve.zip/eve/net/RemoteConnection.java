/*
 * Created on Oct 5, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import eve.data.PropertyList;
import eve.io.Io;
import eve.sys.Convert;
import eve.sys.Device;
import eve.sys.Handle;
import eve.sys.IRegistryKey;
import eve.sys.TimeOut;
import eve.sys.TimedOutException;
import eve.sys.Vm;
import eve.sys.Wrapper;
import eve.sys.mThread;
import eve.util.ObjectBuffer;
import eve.util.TextEncoder;
import eve.util.mString;

/**
 * This class is used by each client application to communicate
 * with the local running RemoteServer.
 *
 */
//####################################################
public class RemoteConnection{
	
	private int rcport = 270;
	
	protected RemoteConnection() throws IOException
	{
		//PrintWriter pw = Vm.out();
		int gp = RemoteServer.getServicePort();
		//debugln("Port: "+gp);
		if (gp != 0) rcport = gp;
		boolean m = Device.isMobile();
		if (tryConnect(rcport,m)) return;
		if (!m)
			if (tryConnect(271,false)) return;
		throw new IOException("Could not communicate with RemoteConnection agent.");
	}
	
	private RemotePipe server;
	
	void connectToServer(String host, int port) throws IOException
	{
		server = new RemotePipe(new Socket(host,port));
	}
	boolean tryConnect(int port, boolean asMobile)
	{
		try{
			server = new RemotePipe(new Socket(Net.getLocalHost(),port));
			if (getServerStatus() <= 0){
				server.close();
				return false; 
			}
			if (asMobile && ((status & STATUS_IS_MOBILE) != 0)) return true;
			if (!asMobile && ((status & STATUS_IS_DESKTOP) != 0)) return true;
			server.close();
			return false;
		}catch(Exception e){
			//e.printStackTrace();
			try{
				server.close();
			}catch(Exception e2){
			}
		}
		return false;
	}
	/**
	* This is returned by getStatus().
	**/
	public static final int STATUS_IS_DESKTOP = 1;
	/**
	* This is returned by getStatus().
	**/
	public static final int STATUS_IS_MOBILE = 2;
	/**
	* This is returned by getStatus().
	**/
	public static final int STATUS_IS_EMULATOR = 4;
	
	private String initError = null;
	private int status = 0;
	private static RemoteConnection curConnection;
	
	public boolean isEmulated()
	{
		return ((status & STATUS_IS_EMULATOR) != 0); 
	}
	public boolean isMobile()
	{
		return ((status & STATUS_IS_MOBILE) != 0);
	}
	/**
	* This is used to check the RemoteConnection status. 
	*@return
	* -1 = Remote Connection server is not running.<br>
	* 0 = Remote Connection is running but there is an internal error.<br>
	* STATUS_IS_DESKTOP = Remote Connection is running and OK and this process is running on the Desktop.<br>
	* STATUS_IS_MOBILE = Remote Connection is running and OK and this process is running on a Mobile PC.<br>
	**/
	public int getStatus()
	{
		int v = getServerStatus();
		if (v == -1) return -1;
		return v & (STATUS_IS_DESKTOP|STATUS_IS_MOBILE);
	}
	/**
	* This is used to check the RemoteConnection status and it returns a value that
	* is the combination of a number of bit flags. 
	*@return
	* 0 = A working Remote Connection is not running.<br>
	* IS_DESKTOP = Remote Connection is running and OK and this process is running on the Desktop.<br>
	* IS_MOBILE = Remote Connection is running and OK and this process is running on a Mobile PC.<br>
	* IS_EMULATED = Remote Connection is running and is the Emulator - i.e. the mobile
	* peer is actually running on the desktop.<br>
	**/
//	===================================================================
	int getServerStatus()
//	===================================================================
	{
		try{
			Wrapper w = new Wrapper();
			if (!server.runCommand("getStatus:",w)){
				return status = 0;
			}
			return status = Convert.toInt((String)w.getObject());
		}catch(Exception e){
			status = 0;
			return -1;
		}
	}
	/**
	* Use this to get an instance of a RemoteConnection. This will re-use the
	* previous one.
	* @return A RemoteConnection instance.
	* @exception IOException if there is an error getting the connection.
	*/
//	===================================================================
	public static synchronized RemoteConnection getConnection() throws IOException
//	===================================================================
	{
		if (curConnection != null) {
			int st = curConnection.getServerStatus();
			if (st > 0 && ((st & (STATUS_IS_MOBILE|STATUS_IS_DESKTOP)) != 0))
				return curConnection;
			curConnection = null;
		}
		RemoteConnection rc = new RemoteConnection();
		return curConnection = rc;
	}
	/**
	 * Return a Handle that can be used to monitor the connection to the Remote Server.
	 * If the Remote Server exits the connection to this Object is lost and this Handle
	 * will be flagged as Stopped.
	 * @return a Handle that can be used to monitor the connection to the Remote Server.
	 */
	public Handle getConnectionHandle()
	{
		RemotePipe s = server;
		if (s == null) return new Handle(Handle.Stopped,null);
		return s.openHandle;
	}
	public void exitSystemOnClosedConnection()
	{
		new Thread(){
			public void run(){
				getConnectionHandle().waitUntilCompletion();
				System.exit(0);
			}
		}.start();
	}
	/**
	* Use this to get a new instance of a RemoteConnection.
	* @return A new RemoteConnection instance.
	* @exception IOException if there is an error getting the connection.
	*/
//	===================================================================
	public static synchronized RemoteConnection getNewConnection() throws IOException
//	===================================================================
	{
		curConnection = null;
		return getConnection();
	}
	
	/**
	 * Return a Socket connected to the specified host and port.
	 * @param host
	 * @param port
	 * @param howLong
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public Socket connectToHost(String host, int port, TimeOut howLong) throws IOException, InterruptedException
	{
		//debugln("Connect: "+host+", "+port);
		//System.out.println("Connect: "+host+", "+port);
		if (howLong == null) howLong = TimeOut.Forever;
		Wrapper w = new Wrapper();
		if (!server.runCommand("canConnectTo:"+host+";"+port,w))
			throw new IOException("RemoteServer error.");
		if (((String)w.getObject()).equalsIgnoreCase("true")){
			// FIXME - do a timeout.
			return new Socket(host,port);
		}
		//System.out.println("Cannot connect to: "+host+", "+port+", must do a bridge!");
		InetAddress ii = Net.getLocalHost();
		final ServerSocket ss = createServiceServerSocket();
		int myPort = ss.getLocalPort();
		String myHost = Net.getLocalAddress(ss).getHostAddress();
		//System.out.println("Bridge to: "+myHost+", "+myPort);
		ObjectBuffer ob = RemoteServer.acceptConnection(ss,true);
		if (!server.runCommand("makeBridge:"+myHost+";"+myPort+";"+host+";"+port,w)){
			ob.close();
			throw new IOException((String)w.getObject());
		}
		Object got = ob.get(howLong,true);
		if (got == null) throw new IOException("Socket connection not made in time.");
		if (got instanceof IOException) throw (IOException) got;
		return (Socket)got;
	}
	public String getService(String name) throws IOException
	{
		Wrapper w = new Wrapper();
		if (!server.runCommand("getService:"+name,w)){
			throw new IOException((String)w.getObject());
		}
		return (String)w.getObject();
	}
	/**
	* This is used by an application to connect to a service on the remote machine. If the service
	* has not been posted or is not running, the underlying service on the remote machine will look
	* up in the registry (or equivalent) under the AutoStart, EmulatorAutoStart and Services keys to
	* see if the service has been registered (the EveConfig app is used to register services) and if it has it
	* will attempt to start the service.
	* @return A socket which can be used to communicate with the specified port.
	**/
//	===================================================================
	public Socket connectToService(String service,TimeOut howLong) throws IOException, InterruptedException
//	===================================================================
	{
		String sv = getService(service);
		return connectToHost(mString.leftOf(sv,':'),Convert.toInt(mString.rightOf(sv,':')),howLong);
	}
	public static final int MOBILE_IS_VM_APPLICATION = 1;
	public static final int MANUAL_MOBILE_START_ON_EMULATOR = 2;
	public static final int MOBILE_GET_COMMAND_FROM_REGISTRY = 4;
	
	/**
	 * Run a command on the remote entitiy.
	 * @param commandOrRegistryEntry
	 * @param options
	 * @throws IOException if the remote entity reports that it cannot run the command
	 */
	private void runRemoteCommand(String commandOrRegistryEntry, int options) throws IOException 
	{
		Wrapper w = new Wrapper();
		if (!server.runCommand("runCommand:"+commandOrRegistryEntry+";"+options,w)){
			throw new IOException((String)w.getObject());
		}
	}
	/**
	 * Run command lines on the remote.
	 * @param commandLines The line to run or remote Registry value that stores the command to be run.
	 * @param execOptions This can be any of MOBILE_GET_COMMAND_FROM_REGISTRY,  MOBILE_IS_VM_APPLICATION, OR'ed together.
	 * @exception IOException If the command could not be executed.
	 */
//	===================================================================
	public void execRemote(String [] commandLines,int execOptions) throws IOException
//	===================================================================
	{
		for (int i = 0; i<commandLines.length; i++){
			String toRun = commandLines[i];
			String error = "Could not run mobile application: "+toRun;
			if ((execOptions & MOBILE_GET_COMMAND_FROM_REGISTRY) != 0){
				toRun = getRegistryValue(toRun);
				if (toRun == null) throw new IOException(error);
			}
			runRemoteCommand(toRun,execOptions);
		}
	}
	/**
	 * Run a command line on the remote.
	 * @param commandLine The line to run or remote Registry value that stores the command to be run.
	 * @param execOptions This can be any of MOBILE_GET_COMMAND_FROM_REGISTRY,  MOBILE_IS_VM_APPLICATION, OR'ed together.
	 * @exception IOException If the command could not be executed.
	 */
//	===================================================================
	public void execRemote(String commandLine,int execOptions) throws IOException
//	===================================================================
	{
		execRemote(new String[]{commandLine},execOptions);
	}
	
	/**
	 * Return a registry key value from the remote entity.
	 * @param keyName the name of the key.
	 * @return the key value or an empty String if no key name exists.
	 */
	public String getRegistryValue(String keyName)
	{
		Wrapper w = new Wrapper();
		if (!server.runCommand("getRegistryKeyValue:"+keyName,w)){
			return null;
		}
		return (String)w.getObject();
	}
	/* (non-Javadoc)
	 * @see eve.net.IRemoteServer#getRemoteHostAndPort(java.lang.String)
	 */
	/*
	public String getRemoteHostAndPort(String serviceName) {
		// TODO Auto-generated method stub
		return null;
	}
*/
	/* (non-Javadoc)
	 * @see eve.net.IRemoteServer#getLocalHostAndPort(java.lang.String)
	 */
	/*
	public String getLocalHostAndPort(String serviceName) {
		// TODO Auto-generated method stub
		return null;
	}
*/
	public static final int AUTO_START_IS_VM_APPLICATION = 0x1;
	public static final int AUTO_START_EMULATOR = 0x2;
	public static final int AUTO_START_SERVICE = 0x4;
	public static final int AUTO_START_UNREGISTER_FROM_ALL = 0x8;
	
	
	private static String autoStartKey(int which)
	{
		String keyName = "AutoStart";
		if ((which & AUTO_START_EMULATOR) != 0)
			keyName = "EmulatorAutoStart";
		else if ((which & AUTO_START_SERVICE) != 0)
			keyName = "Services";
		return keyName;
	}
	static void getAutoStarts(int which,PropertyList dest)
	{
		String config = "EweSoft\\EveSync\\File"+autoStartKey(which);
		try{
			String got = Io.getConfigInfo(config);
			if (got != null) TextEncoder.fromString(dest, got);
		}catch(Exception e){}
	}
	static void saveAutoStarts(int which,PropertyList list)
	{
		String config = "EweSoft\\EveSync\\File"+autoStartKey(which);
		try{
			Io.saveConfigInfo(TextEncoder.toString(list),config,Io.SAVE_IN_FILE);
		}catch(Exception e){}
	}
	public static void unregisterFromAllAutoStarts(String entryName)
	{
		unregisterAutoStart(entryName, AUTO_START_UNREGISTER_FROM_ALL);
	}
/**
 * Use this to unregister an AutoStart entry. 
 * @param entryName the name of the entry.
 * @param options this should be only one of AUTO_START_EMULATOR
 * (to unregister from the auto-start emulator services), AUTO_START_SERVICE
 * (to unregister from the service list) or AUTO_START_UNREGISTER_FROM_ALL to
 * remove it from all.
 * If it is zero then it is unregistered from the normal auto-start entries only.
 */
	public static void unregisterAutoStart(String entryName, int type)
	{
		for (int i = 0; i<3; i++){
			if ((type & AUTO_START_UNREGISTER_FROM_ALL) == 0){
				if (i == 0 && (type & (AUTO_START_EMULATOR|AUTO_START_SERVICE)) != 0)
					continue;
				if (i == 1 && (type & AUTO_START_EMULATOR) == 0)
					continue;
				if (i == 2 && (type & AUTO_START_SERVICE) == 0)
					continue;
			}
			int w = 0;
			if (i == 1) w = AUTO_START_EMULATOR;
			else if (i == 2) w = AUTO_START_SERVICE;
			String keyName = autoStartKey(w);
			String regKeyName = "HKEY_LOCAL_MACHINE\\Software\\EweSoft\\EveSync\\"+keyName;
			IRegistryKey rk = Vm.getRegistryKey(true,"HKEY_LOCAL_MACHINE\\Software\\EweSoft\\EveSync\\"+keyName,true,true);
			if (rk != null) rk.deleteValue(entryName);
			PropertyList pl = new PropertyList();
			getAutoStarts(w, pl);
			int size = pl.size();
			pl.remove(entryName);
			if (pl.size() != size)
				saveAutoStarts(w, pl);
		}
	}
	/**
	 * Use this to register an AutoStart entry. When an successful EveSync connection from the
		desktop to the mobile device is made, then this will cause registered AutoStart entries
		to run.
	 * @param entryName A unique name for the entry. You can use spaces or special characters,
		but not the backslash (\) character.
	 * @param commandLine The command line to run. This should be a full command line, or it can
		be a command line to the EveVM if the AUTO_START_IS_VM_APPLICATION option is chosen.
	 * @param typeAndOptions This can be a combination of AUTO_START_IS_VM_APPLICATION with
		AUTO_START_EMULATOR or AUTO_START_SERVICE. If neither AUTO_START_EMULATOR nor AUTO_START_SERVICE
		is selected, then it is assumed that the entry is in the normal (default) auto start section.
	 * @exception IOException If the information could not be registerd.
	 */
//	===================================================================
	public static void registerAutoStart(String entryName,String commandLine,int typeAndOptions)
	throws IOException
//	===================================================================
	{
		String keyName = autoStartKey(typeAndOptions);
		if ((typeAndOptions & AUTO_START_IS_VM_APPLICATION) != 0){
			String vm = Device.getPathToVm();
			if (vm == null) {
				throw new IOException("Could not determine path of local VM");
			}
			if (vm.charAt(0) != '"') vm = '"'+vm+'"';
			commandLine = vm+" "+commandLine;
		}
		//
		IRegistryKey rk = Vm.getRegistryKey(true,"HKEY_LOCAL_MACHINE\\Software\\EweSoft\\EveSync\\"+keyName,true,true);
		if (rk != null)  rk.setValue(entryName,commandLine);
		//
		PropertyList pl = new PropertyList();
		getAutoStarts(typeAndOptions, pl);
		pl.set(entryName,commandLine);
		saveAutoStarts(typeAndOptions, pl);
	}
	/**
	 * This registers a normal autostart entry specifying the entry name and a command line that is
		 taken to be a VM application.
	 * @param entryName A unique name for the entry. You can use spaces or special characters,
		but not the backslash (\) character.
	 * @param commandLine The command line to run with the VM.
	 * @exception IOException If the information could not be registerd.
	 */
//	===================================================================
	public static void registerAutoStartVMApp(String entryName,String vmCommandLine)
	throws IOException
//	===================================================================
	{
		registerAutoStart(entryName,vmCommandLine,AUTO_START_IS_VM_APPLICATION);
	}
	/**
	* This is used by an application to notify the connection that it has created
	* and is listening to a TCP/IP server port on the specified hostName and port number.
	* The server port is then associated with the provided service name. A remote ewe application
	* could then connect to the named service by using connectToService().
	* @param service The service name to post. Note that this IS case sensitive.
	* @param hostName The name of the host used for the connection.
	* @param port The port number of the connection.
	**/
//	===================================================================
	public void postService(String service,String hostName,int port) throws IOException
//	===================================================================
	{
		Wrapper w = new Wrapper();
		if (!server.runCommand("postService:"+service+";"+hostName+":"+port,w))
			throw new IOException("RemoteServer error.");
	}
	/**
	* This is used by an application to notify the connection that it has created
	* and is listening to a TCP/IP server port on the specified hostName and port number.
	* The server port is then associated with the provided service name. A remote ewe application
	* could then connect to the named service by using connectToService().
	* @param service The service name to post. Note that this IS case sensitive.
	* @param serverSocket The socket being listened to.
	 */
//	===================================================================
	public void postService(String service,ServerSocket serverSocket) throws IOException
//	===================================================================
	{
		postService(service,Net.toOneHostAddress(Net.getLocalAddress(serverSocket)),serverSocket.getLocalPort());
	}
	/**
	 * This is the most reliable way to create a ServerSocket for providing
	 * a service over the RemoteConnection. Creating it this way overcomes
	 * some problems that might arise on Linux Systems where determining the
	 * IP address is not reliable.
	 * Call postService() with the created ServerSocket to make the service
	 * public.
	 * @return a ServerSocket that you can use to listen to in order to provide
	 * some kind of service.
	 * @throws IOException if there was an error creating the Socket.
	 */
	public static ServerSocket createServiceServerSocket() throws IOException
	{
		return RemoteServer.getServiceSocket(0,0);
	}
	/**
	 * This is the most reliable way to create a ServerSocket for providing
	 * a service over the RemoteConnection. Creating it this way overcomes
	 * some problems that might arise on Linux Systems where determining the
	 * IP address is not reliable.
	 * Call postService() with the created ServerSocket to make the service
	 * public.
	 * @param port a specific port to listen to - which can be 0 to select
	 * any available port.
	 * @param backlog the backlog of incoming connections to allow. 0 will select
	 * the default backlog.
	 * @return a ServerSocket that you can use to listen to in order to provide
	 * some kind of service.
	 * @throws IOException if there was an error creating the Socket.
	 */
	public static ServerSocket createServiceServerSocket(int port, int backlog) throws IOException
	{
		return RemoteServer.getServiceSocket(port, backlog);
	}
	/**
	 * This creates a ServerSocket on a new port and then posts the service to the RemoteConnecion.
	 * @param serviceName The name of the service to be posted.
	 * @return The ServerSocket created.
	 * @exception IOException If the ServerSocket could not be created or if the service
	 * could not be posted.
	 */
//	===================================================================
	public static ServerSocket createService(String serviceName) throws IOException
//	===================================================================
	{
		ServerSocket ss = createServiceServerSocket(0,0);
		try{
			RemoteConnection rc = getConnection();
			rc.postService(serviceName,ss);
			return ss;
		}catch(Exception e){
			try{
				ss.close();
			}catch(Exception e2){}
			if (e instanceof IOException) throw (IOException)e;
			else if (e instanceof RuntimeException) throw (RuntimeException)e;
			else throw new IOException(e.getMessage());
		}
	}

	/**
	This is a convenience method for doing standard application synchronization that can be
	be run on both the desktop and mobile device.<p>
	If it is running on the desktop it will do the following:
	<pre>
	1. Create a server socket on an arbitrary port.
	2. Post the service name and the socket port.
	3. Execute the remote command line, unless the MANUAL_MOBILE_START_ON_EMULATOR 
			option is selected in which case a MessageBox is shown if the connection
			is running on the Evesync Emulator and you must start the mobile app yourself.
			
			If the MOBILE_GET_COMMAND_FROM_REGISTRY option is used, then the command line supplied should
			be the name of a value in the registry key - this value will be retrieved and then run.
			If MOBILE_IS_VM_APPLICATION option is used then the value retrieved from the registry
			should be the location of a .eve file.
			
	4. Wait for a connection.
	</pre><p>
	If it is running on the mobile this method will:
	<pre>
	1.  Attempt to connect to the serviceName on the remote host.
	</pre>

	 * @param serviceName The unique service name to be used.
	 * @param commandLine A command line to pass to the Ewe VM on the remote device.
	 * @param howLong The length of time to wait for a connection.
	 * @param makeOptions This can be any of MANUAL_MOBILE_START_ON_EMULATOR, MOBILE_IS_VM_APPLICATION OR'ed together.
	 * @return The connected Socket.
	 * @exception TimedOutException If no connection was made during the Timeout period.
	 * @exception IOException If there was an error making the connection.
	 * @exception InterruptedException If the Thread was interrupted while waiting for the connection.
	 */
//	===================================================================
	public Socket makeSyncConnection(String serviceName,String commandLine,TimeOut howLong,int makeOptions)
	throws TimedOutException, IOException, InterruptedException
//	===================================================================
	{
		return makeSyncConnection(serviceName,commandLine == null ? null : new String[]{commandLine},howLong,makeOptions);
	}

	/**
	This is a convenience method for doing standard application synchronization that can be
	be run on both the desktop and mobile device.<p>
	If it is running on the desktop it will do the following:
	<pre>
	1. Create a server socket on an arbitrary port.
	2. Post the service name and the socket port.
	3. Execute the remote command lines, unless the MANUAL_MOBILE_START_ON_EMULATOR 
			option is selected in which case a MessageBox is shown if the connection
			is running on the Evesync Emulator and you must start the mobile app yourself.
			
			If the MOBILE_GET_COMMAND_FROM_REGISTRY option is used, then the command lines supplied should
			be the name of a value in the registry key - this value will be retrieved and then run.
			
			If MOBILE_IS_VM_APPLICATION option is used then the value retrieved from the registry
			should be the location of a .eve file.
			
	4. Wait for a connection.
	</pre><p>
	If it is running on the mobile this method will:
	<pre>
	1.  Attempt to connect to the serviceName on the remote host.
	</pre>

	 * @param serviceName The unique service name to be used.
	 * @param commandLines An array of command lines to pass to the Eve VM on the remote device.
	 * @param howLong The length of time to wait for a connection.
	 * @param makeOptions This can be any of MANUAL_MOBILE_START_ON_EMULATOR, MOBILE_IS_VM_APPLICATION, MOBILE_GET_COMMAND_FROM_REGISTRY OR'ed together.
	 * @return The connected Socket.
	 * @exception TimedOutException If no connection was made during the Timeout period.
	 * @exception IOException If there was an error making the connection.
	 */
//	===================================================================
	public Socket makeSyncConnection(String serviceName,String [] commandLines,TimeOut howLong,int makeOptions)
	throws TimedOutException, IOException, InterruptedException
//	===================================================================
	{
		int st = getStatus();	

		if (st == STATUS_IS_MOBILE){
			Socket desktop = connectToService(serviceName,howLong);
			if (desktop == null) throw new IOException("Could not connect to desktop.");
			else return desktop;
		}else if (st == STATUS_IS_DESKTOP){
				ServerSocket ss = createService(serviceName);
				try{
					Handle accepted = Net.acceptConnection(ss);
					if (commandLines == null || (isEmulated() && ((makeOptions & MANUAL_MOBILE_START_ON_EMULATOR) != 0))){
						Device.tryMessageBox("Start Mobile App.","Please start the mobile application.",false);
					}else{
						execRemote(commandLines,makeOptions);
					}
					try{
						Socket sock = (Socket)accepted.waitOnResult(howLong);
						if (sock != null) return sock;
						if (accepted.error instanceof TimedOutException)
							throw new TimedOutException("Mobile application did not connect.");
						else 
							throw newIOException("Could not connect to mobile.",accepted.error);
					}finally{
						//if (start != null) start.exit(0);
					}
				}finally{
					ss.close();
				}
		}else{
			throw new IOException("There is a problem with the remote connection.");
		}
		
	}
	private static IOException newIOException(String name, Throwable cause)
	{
		return (IOException)Vm.setCause(new IOException(name),cause);
	}

/*
	public RemoteConnection(Socket s,boolean isMobile) throws IOException
	{
		connection = new RemotePipe(s);
		amMobile = isMobile;
		new Thread(){
			public void run(){
				try{
					RemoteServer.handleCodedCommands(connection,RemoteConnection.this);
				}catch(Exception e){
					try{
						connection.close();
					}catch(IOException e2){}
				}finally{
					debugln("RS - leaving");
				}
			}
		}.start();
	}
*/
	static void debugln(String what)
	{
		RemoteServer.debugln(what);
	}
	static void exitSystem(int value)
	{
		RemoteServer.exitSystem(value);
	}
	static void exitSystem(int value,int wait)
	{
		RemoteServer.exitSystem(value,wait);
	}
	static void noRemoteService(Throwable e)
	{
		debugln("An error occured. Make sure EveSync or the EveSync Emulator is running.");
		debugln("Use \"eve eve.net.RemoteServer -emulator\" to run the emulator.");
		debugln("\nThe error was:\n"+e);
		exitSystem(-1,10);
	}
	public static void main(String args[]) throws Exception
	{
		//RemoteServer.startEmulator(false);
		try{
			if (args.length == 0 || args[0].equalsIgnoreCase("-capitalize") || args[0].equalsIgnoreCase("-commonize")){
				final boolean isCommon = args.length != 0 && args[0].equalsIgnoreCase("-commonize");
				RemoteServer.setup(args,isCommon ? "Commonize Server":"Capitalize Server");
				debugln("Registering...");
				RemoteConnection.registerAutoStart(
						isCommon ? "Commonize" : "Capitalize",
								"\"c:/program files/eve/eve_debug.exe\" "+
						(Device.isMobile()? "-r " : "")
						+"-cp \"f:\\projects\\eve\\classes\" eve.net.RemoteConnection "+
						(isCommon ? "-commonize":"-capitalize"),RemoteConnection.AUTO_START_SERVICE);
				debugln("Starting...");
				RemoteConnection rs = null;
				try{
					rs = RemoteConnection.getConnection();
				}catch(Exception e){
					noRemoteService(e);
				}
				rs.exitSystemOnClosedConnection();
				ServerSocket s = RemoteConnection.createService(isCommon ? "Commonize" : "Capitalize");
				debugln("Server started on: "+s);
				while(true){
					final Socket client = s.accept();
					new Thread(){
						public void run(){
							try{
								BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()));
								PrintWriter pw = new PrintWriter(client.getOutputStream());
								while(true){
									String line = br.readLine();
									if (line == null) break;
									if (line.equals("quit")) {
										exitSystem(0);
									}
									line = isCommon ? line.toLowerCase() : line.toUpperCase();
									pw.println(line);
									pw.flush();
								}
								br.close();
								pw.close();
								debugln("Client closed.");
							}catch(Exception e){
								//e.printStackTrace();
								debugln("Client cut off.");
							}
						}
					}.start();
				}
			}else if (args[0].equals("-autostart")){
				RemoteConnection.registerAutoStart("Notepad", "eve.ui.data.Notepad", AUTO_START_IS_VM_APPLICATION);
				RemoteConnection.registerAutoStart("Notepad", "eve.ui.data.Notepad", AUTO_START_EMULATOR|AUTO_START_IS_VM_APPLICATION);
				System.out.println("Notepad will start on evesync.");
				mThread.nap(5000);
				Vm.exit(0);
			}else if (args[0].equals("-unregister")){
				RemoteConnection.unregisterFromAllAutoStarts("Capitalize");
				RemoteConnection.unregisterFromAllAutoStarts("Commonize");
				RemoteConnection.unregisterFromAllAutoStarts("Notepad");
				System.out.println("Unregistered.");
				mThread.nap(5000);
				Vm.exit(0);
			}else if (args[0].equals("-test")){
				RemoteServer.setup(args,"Capitalize Tester");
				if (!Device.isMobile()){
 					debugln("You must use the VM -r option to cause this process\nto emulate a mobile device. Or run it on an actual mobile device.");
				}else{
					RemoteConnection rsi = null;
					try{
						rsi = RemoteConnection.getConnection();
					}catch(Exception e){
						noRemoteService(e);
					}
					debugln("Status: IsMobile="+rsi.isMobile()+", IsEmulated="+rsi.isEmulated());
					Socket s = rsi.connectToService("Capitalize",new TimeOut(5*1000));
					PrintWriter pw = new PrintWriter(s.getOutputStream());
					pw.println("please capitalize this!");
					pw.flush();
					BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
					String got = br.readLine();
					debugln("Received from Capitalize: "+got);
					s.close();
				}
				exitSystem(0,5);
			}else{
				RemoteServer.setup(args,"Remote Server");
				debugln("Unknown command: use -capitalize to run the capitalize server\n and on another process use -test to test the server.");
				exitSystem(0,10);
			}
		}catch(Exception e){
			RemoteServer.endException(e);
		}
		/*
		debugln("Starting...");
		Socket[] s = Net.pipe();
		InetAddress ii = InetAddress.getLocalHost();
		ServerSocket pcSS = new ServerSocket(0,0,ii);
		ServerSocket mobileSS = new ServerSocket(0,0,ii);
		//debugln(pcSS.getInetAddress().getHostAddress()+", "+pcSS.getLocalPort());
		RemoteServer pc = new RemoteServer(s[0],pcSS,false);
		RemoteServer mobile = new RemoteServer(s[1],mobileSS,true);
		//
		ServerSocket ss = pcSS;
		RemoteConnection client = new RemoteConnection();
		client.registerAutoStartVMApp("Test","something.eve -ok");
		client.connectToServer(ss.getInetAddress().getHostAddress(),ss.getLocalPort());
		//
		String got = client.getRegistryValue("HKEY_LOCAL_MACHINE\\software\\ewesoft\\evevm");
		debugln("Got value: "+got);
		try{
			//client.runRemoteCommand("c:\\windows\\notepad.exe",0);
			Socket test = client.connectToHost("192.168.1.2",2000,TimeOut.Forever);
			PrintWriter pw = new PrintWriter(test.getOutputStream());
			BufferedReader br = new BufferedReader(new InputStreamReader(test.getInputStream()));
			pw.println("Hello from me!");
			pw.println("Please say something...");
			try{
				while(true){
					String gg = br.readLine();
					if (gg == null) break;
					debugln(">"+gg);
				}
			}catch(IOException e){
			}finally{
				debugln("Closed!");
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		mThread.nap(5000);
		debugln("Done!");
		s[0].close();
		debugln("Closed!");
		mThread.nap(2000);
		//exitSystem(0);
		 */
	}
	/* (non-Javadoc)
	 * @see eve.net.IRemoteServer#getLocalRegistryKey(java.lang.String)
	 */
	/*
	public String getLocalRegistryKeyValue(String name) 
	{
		try{
			IRegistryKey key = Vm.getRegistryKey(true,name,false,false);
			String vname = null;
			if (key == null){
				int idx = name.lastIndexOf('\\');
				if (idx == -1) return null;
				vname = name.substring(idx+1);
			 	name = name.substring(0,idx);
				key = Vm.getRegistryKey(true,name,false,false);
			}
			if (key == null) return null;
			return key.getValue(vname).toString();
		}catch(Exception e){
			return null;
		}
	}
*/
	/* (non-Javadoc)
	 * @see eve.net.IRemoteServer#getRemoteRegistryKey(java.lang.String)
	 */
	/*
	public String getRemoteRegistryKeyValue(String name) throws IOException {
		return RemoteServer.getLocalRegistryKeyValue(name,connection);
	}
	*/

}

//####################################################
