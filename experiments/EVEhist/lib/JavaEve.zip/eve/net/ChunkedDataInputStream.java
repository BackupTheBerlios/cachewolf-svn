/*
 * Created on Nov 4, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.StreamCorruptedException;

import eve.io.AsciiCodec;
import eve.io.MemoryStream;
import eve.sys.Handle;
import eve.util.ByteArray;
import eve.util.CharArray;
import eve.util.mString;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class ChunkedDataInputStream extends MemoryStream {

	private InputStream source;
	private AsciiCodec ac = new AsciiCodec();
	//private byte[] buffer;
	private ByteArray buff;
	private CharArray chBuff;
	/**
	 * 
	 */
	public ChunkedDataInputStream(InputStream source,int bufferSize) {
		super(bufferSize);
		this.source = source;
		startGeneratingData();
	}
//	===================================================================
	private int readInChunkedHeader() throws IOException
//	===================================================================
	{
	 	if (buff == null) buff = new ByteArray();
		buff.clear();
		while(true){
			int got = source.read();
			if (got == -1) throw new IOException();
			if (got == '\n') break;
			buff.append((byte)got);
		}
		ac.reset();
		if (chBuff != null) chBuff.clear();
		chBuff = ac.decodeText(buff.data,0,buff.length,true,chBuff);
		//
		// There may or may not be a ';' after the data length.
		//
		String s = mString.leftOf(chBuff.toString(),';').trim();
		try{
			int ret = Integer.parseInt(s,16);
			return ret;
		}catch(NumberFormatException e){
			throw new StreamCorruptedException("Bad chunk size: "+s);
		}
	}

	protected void doGenerateData(Handle h)
	{
		while(true && !h.shouldStop){
			if (!waitForDataRequest()) return;
			byte[] buff = new byte[1024*8];
			try{
				int len = readInChunkedHeader();
				if (len == 0) return; // No more data.
				while(len > 0){
					int toRead = len;
					if (toRead > buff.length) toRead = buff.length;
					int got = source.read(buff,0,toRead);
					if (got == -1) throw new StreamCorruptedException();
					write(buff,0,got);
					len -= got;
				}
				// Should always have a '\n' at the end of a data chunk.
				while(true){
					int got = source.read();
					if (got == -1) throw new IOException();
					if (got == '\n') break;
				}
			}catch(IOException e){
				generateInputError(e);
			}
		}
	}
	
}

//####################################################
