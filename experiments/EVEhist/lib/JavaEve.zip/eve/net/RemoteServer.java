/*
 * Created on Jul 12, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.net;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;
import java.util.Iterator;

import eve.data.Property;
import eve.data.PropertyList;
import eve.io.Io;
import eve.io.StreamUtils;
import eve.sys.Convert;
import eve.sys.Device;
import eve.sys.DeviceIcon;
import eve.sys.Event;
import eve.sys.EventListener;
import eve.sys.Handle;
import eve.sys.IConsole;
import eve.sys.IRegistryKey;
import eve.sys.ITaskbarEntry;
import eve.sys.Registry;
import eve.sys.Task;
import eve.sys.TimeOut;
import eve.sys.Vm;
import eve.sys.Wrapper;
import eve.sys.mThread;
import eve.sys.options.VMOptions;
import eve.util.ObjectBuffer;
import eve.util.TextEncoder;
import eve.util.mString;

/**
 * This is the class that implements the EveSync connection.
 * It maintains a connection to a peer RemoteServer and the
 * two of them together provide the EveSync services to the desktop PC
 * and mobile device.
 * <p>
 * You would not normally use this class unless you need to explicitly
 * start the EveSync connection in your application and you would not normally
 * need to do that since EveSync would normally be setup to run automatically
 * when ActiveSync connects.
 * <p>
 * For your application to access the services provided by EveSync you would
 * use the RemoteConnection class. 
 */
//####################################################
public class RemoteServer {
	
	static native void startMobileRemoteServer(String myAddressAndPort, String differentCommand) throws IOException;

	boolean stopClientComms;
	ServerSocket clientComms;
	ServerSocket mobileEmulatorServerSocket;
	synchronized void stopClient()
	{
		stopClientComms = true;
		if (clientComms != null)
			try{
				clientComms.close();
			}catch(Exception e){}
	}
	synchronized boolean startingClient(ServerSocket ss)
	{
		if (stopClientComms){
			try{
				ss.close();
			}catch(Exception e){}
			return false;
		}
		clientComms = ss;
		return true;
	}
	static final String configName = "EweSoft\\EveSync\\CurrentConfig";
	static final String portKey =  "HKEY_LOCAL_MACHINE\\Software\\EweSoft\\EveSync\\ServerPort";
	static int getServicePort()
	{
		try{
			IRegistryKey key = Vm.getRegistryKey(true,portKey,false,false);
			if (key == null) throw new Exception();
			String v = key.getValue(Device.isMobile() ? "Mobile" : "Desktop").toString();
			if (v == null) throw new Exception();
			int value = Convert.toInt(v);
			if (value <= 0) throw new Exception();
			return value;
		}catch(Throwable e){
			try{
				String cf = Io.getConfigInfo(configName);
				if (cf != null){
					PropertyList pl = new PropertyList();
					TextEncoder.fromString(pl, cf);
					int port = 0;
					if (Device.isMobile()) port = pl.getInt("MobilePort", 0);
					else port = pl.getInt("DesktopPort",0);
					if(port != 0) return port;
				}
			}catch(Exception ex){}
		}
		return Device.isMobile() ? 272 : 270;
	}
	/**
	 * Don't call this for the Zaurus server on the desktop.
	 * @param port
	 */
	void setServicePort(int port)
	{
		IRegistryKey key = Vm.getRegistryKey(true,portKey,true,true);
		if (key != null){
			key.setValue(amMobile ? "Mobile" : "Desktop", Convert.toString(port));
		}
		if (!amMobile || !amEmulator){
			PropertyList pl = new PropertyList();
			if (amMobile) pl.set("MobilePort",Convert.toString(port));
			else pl.set("DesktopPort",Convert.toString(port));
			if (amEmulator && !amMobile)
				pl.set("MobilePort",Convert.toString(mobileEmulatorServerSocket.getLocalPort()));
			String toSave = TextEncoder.toString(pl);
			try{
				Io.saveConfigInfo(toSave, "EweSoft\\EveSync\\CurrentConfig" , Io.SAVE_IN_FILE);
			}catch(IOException e){}
		}
	}
	
	//
	RemotePipe peer;
	Hashtable services = new Hashtable();
	boolean amMobile;
	boolean amEmulator;
	private static int tried102 = 0;
	private static final String linuxDesktopAddress = "192.168.131.102";
	private static final String linuxMobileAddress = "192.168.131.201";
	
	//
	// Called from client.
	//
	boolean canConnectTo(String host, int port)
	{
		if (amMobile) return true;
		if (host.equals(linuxMobileAddress)) return true;
		return false;
	}
	//
	// Called from peer.
	// 
	String getLocalRegistryKeyValue(String name) 
	{
		try{
			IRegistryKey key = Vm.getRegistryKey(true,name,false,false);
			String vname = null;
			if (key == null){
				int idx = name.lastIndexOf('\\');
				if (idx == -1) return null;
				vname = name.substring(idx+1);
			 	name = name.substring(0,idx);
				key = Vm.getRegistryKey(true,name,false,false);
			}
			if (key == null) return null;
			return key.getValue(vname).toString();
		}catch(Exception e){
			return null;
		}
	}
	//
	// Called locally or from peer RemoteServer.
	//
	void doMakeBridge(String hostOne, int portOne, String hostTwo, int portTwo) throws IOException
	{
		Socket one = new Socket(hostOne,portOne);
		Socket two = null;
		try{
			two = new Socket(hostTwo,portTwo);
		}catch(IOException e){
			one.close();
			throw e;
		}
		StreamUtils.transfer(one.getInputStream(),two.getOutputStream(),true);
		StreamUtils.transfer(two.getInputStream(),one.getOutputStream(),true);
	}
	//
	// Called from client.
	//
	void makeBridge(String hostOne, int portOne, String hostTwo, int portTwo) throws IOException
	{
		if (canConnectTo(hostOne,portOne) && canConnectTo(hostTwo,portTwo))
			doMakeBridge(hostOne,portOne,hostTwo,portTwo);
		else{
			Wrapper w = new Wrapper();
			if (!peer.runCommand("makeBridge:"+hostOne+";"+portOne+";"+hostTwo+";"+portTwo,w))
				throw new IOException((String)w.getObject());
		}
	}
	//
	// This should be called to accept incoming client connections.
	//
	Handle startClientComms(final ServerSocket sock)
	{
		return new Task(){
			protected void doRun(){
				try{
					if (!startingClient(sock)) return;
					while(true){
						newClientConnection(sock.accept());
					}
				}catch(Exception e){
					
				}finally{
					succeed(null);
				}
			}
		}.start();
	}
	Handle startClientComms(ServerSocket ss, boolean registerIt)
	{
		if (registerIt) setServicePort(ss.getLocalPort());
		return startClientComms(ss);
	}
	
	Handle startClientComms(int onPort, boolean allowDifferent, boolean registerIt)
	{
		try{
			ServerSocket ss = new ServerSocket(onPort,0,Net.getLocalHost());
			if (registerIt) setServicePort(ss.getLocalPort());
			//System.out.println("Started: "+ss);
			return startClientComms(ss);
		}catch(IOException e){
			if (!allowDifferent) return new Handle(new IOException("Requested server port in use."));
			return startClientComms(0,false,registerIt);
		}
	}
	void postService(String name, String hostAndPort, RemotePipe connection)
	{
		Service ret = null;
		debugln("Service: "+name+"@"+hostAndPort+" has been posted.");
		synchronized(services){
			ret = (Service)services.get(name);
			if (ret == null) {
				ret = new Service();
				ret.name = name;
				services.put(name,ret);
			}
			synchronized(ret){
				ret.connection = connection;
				ret.location = hostAndPort;
				ret.notifyAll();
			}
		}
	}
	
	class Service {
		public String name;
		public String location;
		public boolean starting;
		public RemotePipe connection;
		
		synchronized String getService() throws IOException
		{
			RemotePipe rp = connection;
			if (rp != null && location != null)
				if ((rp.openHandle.check() & Handle.Stopped) == 0)
					return location;
			location = null;
			boolean iStarted = false;
			String errMsg = "Service \""+name+"\" not available.";
			if (!starting){
				try{
					IRegistryKey rk = Vm.getRegistryKey(true,"HKEY_LOCAL_MACHINE\\Software\\EweSoft\\EveSync\\Services",true,true);
					if (rk == null) throw new Exception();
					String command = rk.getValue(name).toString();
					debugln("Running service: "+name+" with:\n"+command);
					Vm.execCommandLine(command);
				}catch(Exception e){
					debugln("Cannot run!");
					//e.printStackTrace();
					throw new IOException(errMsg);
				}
				iStarted = starting = true;
			}
			TimeOut t = new TimeOut(10*1000);// Wait 10 seconds.
			while(true){
				if (location != null){
					if (iStarted) starting = false;
					return location;
				}
				try{
					if (t.hasExpired()) throw new Exception();
					t.waitOn(this);
				}catch(Exception e){
					throw new IOException(errMsg);
				}
			}
		}
	}
	
	String getService(String name) throws IOException
	{
		Service ret = null;
		synchronized(services){
			ret = (Service)services.get(name);
			if (ret == null) {
				ret = new Service();
				ret.name = name;
				services.put(name,ret);
			}
		}
		//debugln(amMobile+" - service at: "+ret.location);
		return ret.getService();
	}
	Handle startPeerComms(Socket sock) throws IOException
	{
		peer = new RemotePipe(sock);
		return startPeerComms();
	}
	//
	// This gets called once the RemotePipe to the peer is active. It handles
	// incomming commands from the peer.
	//
	Handle startPeerComms()
	{
		return new Task(){
			public void doRun(){
				try{
					while(true){
						RemotePipe.Command cc = peer.getNextCommand(TimeOut.Forever);
						if (cc == null) return;
						if (cc == null) return;
						String command = cc.command;
						if (command == null) continue;
						//debugln(amMobile+" - From peer: "+command);
						String retValue = "";
						String error = null;
						String [] all = null;
						Wrapper w = new Wrapper();
						try{
							try{
								if ((all = splitCommand(command,"runCommand")) != null){
									/*
									 * Find out the correct command and run it.
									 */
									String cmd = all[0];
									int options = Convert.toInt(all[1]);
									if ((options & RemoteConnection.MOBILE_IS_VM_APPLICATION) != 0){
										cmd = Registry.getVmCommandLine(cmd);
										if (cmd == null) throw new IOException("Could not execute VM command: "+all[0]);
									}
									debugln("Run: "+cmd);
									Vm.execCommandLine(cmd);
								}else if ((all = splitCommand(command,"getRegistryKeyValue")) != null){
									retValue = getLocalRegistryKeyValue(all[0]);
								}else if ((all = splitCommand(command,"makeBridge")) != null){
									doMakeBridge(all[0],Convert.toInt(all[1]),all[2],Convert.toInt(all[3]));
								}else if ((all = splitCommand(command,"getService")) != null){
									retValue = getService(all[0]);
								}else{
									error = "Unknown command: "+command;
								}
							}catch(IndexOutOfBoundsException e){
								throw e;
							}catch(Throwable t){
								error = t.getMessage();
							}
						}catch(IndexOutOfBoundsException e){
							error = "Badly formatted command.";
						}
						if (retValue == null) retValue = "";
						String rp = null;
						if (error == null) {
							rp = "OK:"+retValue;
						}else {
							rp = "Error:"+error;
						}
						cc.reply(rp);
					}					
				}catch(Exception e){
					
				}finally{
					stopClient();
				}
			}
		}.start();
	}
	void newClientConnection(final Socket sock)
	{
		debugln("Client connected: "+Net.getRemoteAddress(sock,defaultLocalAddress)+":"+sock.getPort());
		new Thread(){
			public void run(){
				try{
					RemotePipe client = new RemotePipe(sock);
					while(true){
						RemotePipe.Command cc = client.getNextCommand(TimeOut.Forever);
						if (cc == null) return;
						String command = cc.command;
						if (command == null) continue;
						String retValue = "";
						String error = null;
						String [] all = null;
						Wrapper w = new Wrapper();
						//debugln(">"+command);
						try{
							try{
								//
								// These commands are passed to the peer.
								//
								if ((all = splitCommand(command,"runCommand")) != null){
									if (!peer.runCommand(command,w))
										throw new IOException((String)w.getObject());
								}else if ((all = splitCommand(command,"getService")) != null){
									if (!peer.runCommand(command,w))
										error = (String)w.getObject();
									else
										retValue = (String)w.getObject();
								}else if ((all = splitCommand(command,"getRegistryKeyValue")) != null){
									if (!peer.runCommand(command,w))
										retValue = "";
									else
										retValue = (String)w.getObject();
								}else if ((all = splitCommand(command,"postService")) != null){
									postService(all[0],all[1],client);
								}else if ((all = splitCommand(command,"getStatus")) != null){
									int s = amMobile ? RemoteConnection.STATUS_IS_MOBILE : RemoteConnection.STATUS_IS_DESKTOP;
									if (amEmulator) s |= RemoteConnection.STATUS_IS_EMULATOR;
									retValue = Convert.toString(s);
								}
								//
								// These commands are handled by this entity.
								//
								else if ((all = splitCommand(command,"makeBridge")) != null){
									makeBridge(all[0],Convert.toInt(all[1]),all[2],Convert.toInt(all[3]));
								}else if ((all = splitCommand(command,"canConnectTo")) != null){
									retValue = canConnectTo(all[0],Convert.toInt(all[1])) ? "true" : "false";
								}else{
									error = "Unknown command: "+command;
								}
							}catch(IndexOutOfBoundsException e){
								throw e;
							}catch(Throwable t){
								error = t.getMessage();
							}
						}catch(IndexOutOfBoundsException e){
							error = "Badly formatted command.";
						}
						if (retValue == null) retValue = "";
						String rp = null;
						if (error == null) {
							rp = "OK:"+retValue;
						}else {
							rp = "Error:"+error;
						}
						cc.reply(rp);
						//debugln("Replied: "+rp);
					}
				}catch(Exception e){
				}finally{
					debugln("Client connection closed: "+Net.getRemoteAddress(sock,defaultLocalAddress)+":"+sock.getPort());
				}
			}
		}.start();
	}
	
	static String[] splitCommand(String command,String name)
	{
		int idx = command.indexOf(':');
		if (idx != name.length()) return null;
		if (!command.startsWith(name)) return null;
		return mString.split(command.substring(idx+1).trim(),';');
	}

	/*
	RemoteServer(Socket peerConnection, ServerSocket clientConnection, int status) throws IOException
	{
		this.amMobile = amMobile;
		peer = new RemotePipe(peerConnection);
		startPeerComms();
		startClientComms(clientConnection);
	}
	*/
	
	static int servicePort(boolean mobile)
	{
		return mobile? 272 : 270;
	}
	Handle runAsEmulator(Socket peerConnection, boolean amMobile,ServerSocket use) throws IOException
	{
		amEmulator = true;
		this.amMobile = amMobile;
		peer = new RemotePipe(peerConnection);
		Handle h = startPeerComms();
		int port = servicePort(amMobile);
		//port = 0; For testing. 
		if (!amMobile){
			int ms = servicePort(true);
			try{
				mobileEmulatorServerSocket = new ServerSocket(ms);
			}catch(Exception e){
				mobileEmulatorServerSocket = new ServerSocket(0);
			}
		}
		if (use == null)
			startClientComms(port,true,true);
		else
			startClientComms(use,true);
		return h;
	}
	
	
	/*
	static String runLocalCommand(String commandOrRegistryEntry, int options, RemotePipe pipe)
	{
		Wrapper w = new Wrapper();
		if (!pipe.runCommand("runLocalCommand:"+commandOrRegistryEntry+";"+options,w))
			return (String)w.getObject();
		return null;
	}

	static String getLocalRegistryKeyValue(String name,RemotePipe pipe)
	{
		Wrapper w = new Wrapper();
		if (!pipe.runCommand("getLocalRegistryKeyValue:"+name,w))
			return null;
		return (String)w.getObject();
	}
	
	
	
	static void handleCodedCommands(RemotePipe pipe, IRemoteServer server) throws IOException, InterruptedException
	{
		while(true){
			RemotePipe.Command cc = pipe.getNextCommand(TimeOut.Forever);
			if (cc == null) return;
			String command = cc.command;
			if (command == null) continue;
			//debugln("RX Command: "+command);
			String retValue = "";
			String error = null;
			String [] all = null;
			try{
				try{
					if ((all = splitCommand(command,"runLocalCommand")) != null){
						server.runLocalCommand(all[0],Convert.toInt(all[1]));
					}else if ((all = splitCommand(command,"getLocalRegistryKeyValue")) != null){
						retValue = server.getLocalRegistryKeyValue(all[0]);
					}else{
						error = "Unknown command: "+command;
					}
				}catch(IndexOutOfBoundsException e){
					throw e;
				}catch(Throwable t){
					error = t.getMessage();
				}
			}catch(IndexOutOfBoundsException e){
				error = "Badly formatted command.";
			}
			if (retValue == null) retValue = "";
			String rp = null;
			if (error == null) {
				rp = "OK:"+retValue;
			}else {
				rp = "Error:"+error;
			}
			cc.reply(rp);
			debugln("Replied: "+rp);
		}
	}
	*/
	/**
	 * Run the EveSync emulator. If standAlone is true then it will not
	 * return until the connection has closed.
	 */
	public static boolean startEmulator(boolean standAlone) throws IOException
	{
		Socket[] s = Net.pipe();
		RemoteServer rs = new RemoteServer();
		Handle h1 = rs.runAsEmulator(s[0],false,null);
		RemoteServer rs2 = new RemoteServer();
		Handle h2 = rs2.runAsEmulator(s[1],true,rs.mobileEmulatorServerSocket);
		debugln("Emulator running...");
		showTaskbarStatus("EveSync Emulator Running.");
		//
		runAutoStart(true);
		//
		if (standAlone){
			while(true){
				mThread.nap(1000);
				if ((h1.check() & Handle.Stopped) != 0) break;
				if ((h2.check() & Handle.Stopped) != 0) break;
			}
			debugln("Exiting!");
			exitSystem(0);
		}
		return true;
	}
	/**
	 * Setup a Thread to accept a single Socket connection on the ServerSocket.
	 * If the   
	 * @param sock
	 * @return
	 */
	static ObjectBuffer acceptConnection(final ServerSocket sock,final boolean closeAfterConnection)
	{
		final ObjectBuffer ob = new ObjectBuffer(1){
			protected void closed(){
				super.closed();
				try{
					sock.close();
				}catch(Exception e){}
			}
		};
		new Thread(){
			public void run()
			{
				try{
					Socket s = sock.accept();
					if (closeAfterConnection) sock.close();
					if (!ob.put(s)) s.close();
				}catch(IOException e){
					ob.put(e);
				}
			}
		}.start();
		return ob;
	}

	private static ServerSocket getDesktopSocket(StringBuffer addr, String tryUse)
	{
		try{
			InetAddress ia = null;
			String toUse = tryUse;
			if (toUse != null)
				ia = InetAddress.getByName(toUse);
			ServerSocket ss =
				ia == null ? new ServerSocket(0) : 
				new ServerSocket(0,0,ia);
			if (toUse != null) addr.append(toUse);
			else addr.append(Net.toOneHostAddress(Net.getLocalAddress(ss,null)));
			return ss;
		}catch(IOException e){
			return null;
		}
	}
	private static InetAddress defaultLocalAddress;
		
	static synchronized String getServiceSocketName()
	{
		if (Device.isMobile()) return null;
		if (tried102 == 0){
			try{
				InetAddress ia = InetAddress.getByName(linuxDesktopAddress);
				ServerSocket ss = new ServerSocket(0,0,ia);
				ss.close();
				tried102 = 1;
			}catch(IOException e){
				tried102 = -1;
			}
		}
		return tried102 == 1 ? linuxDesktopAddress : null; 
	}
	
	static synchronized ServerSocket getServiceSocket(int port, int backlog) throws IOException
	{
		String got = getServiceSocketName();
		if (got == null) return new ServerSocket(port,backlog);
		else return new ServerSocket(port,backlog,InetAddress.getByName(got));
	}
	private static ServerSocket getDesktopSocket(StringBuffer addr)
	{
		ServerSocket ss = getDesktopSocket(addr,linuxDesktopAddress);
		if (ss == null) ss = getDesktopSocket(addr,null);
		if (ss != null) defaultLocalAddress = Net.getLocalAddress(ss,null);
		return ss;
	}
	private static void runAutoStart(final boolean isEmulator)
	{
		new Thread(){
			public void run(){
				String keyName = !isEmulator ? "AutoStart" : "EmulatorAutoStart";
				IRegistryKey rk = Vm.getRegistryKey(true,"HKEY_LOCAL_MACHINE\\Software\\EweSoft\\EveSync\\"+keyName,false,false);
				int vc = rk == null ? 0 : rk.getValueCount();
				if (vc != 0){
					StringBuffer vn = new StringBuffer();
					for (int i = 0; i<vc; i++){
						try{
							vn.setLength(0);
							Object got = rk.getValue(i, vn);
							debugln("AutoStarting: "+vn);
							if (got instanceof String){
								try{
									Vm.execCommandLine(got.toString());
								}catch(Exception e){
									debugln("AutoStart entry: "+vn+" could not be started.");
									debugln(vn+" command line: "+got.toString());
									debugln(vn+" error: "+e.toString());
								}
							}
						}catch(Exception e){}
					}
				}else{
					PropertyList pl = new PropertyList();
					RemoteConnection.getAutoStarts(isEmulator ? RemoteConnection.AUTO_START_EMULATOR : 0, pl);
					for (Iterator it = pl.iterator(); it.hasNext();){
						Property p = (Property)it.next();
						if (p.value instanceof String){
							try{
								debugln("AutoStarting: "+p.name);
								Vm.execCommandLine((String)p.value);
							}catch(Exception e){
								debugln("AutoStart entry: "+p.name+" could not be started.");
								debugln(p.name+" command line: "+p.value);
								debugln(p.name+" error: "+e.toString());
							}
						}
					}
				}
			}
		}.start();
	}
	
	public static Handle startActiveSyncDesktop(boolean runRemote) throws IOException, InterruptedException
	{
		StringBuffer address = new StringBuffer();
		ServerSocket ss = getDesktopSocket(address);
		if (ss == null) throw new IOException("Could not create Server Socket.");
		ObjectBuffer ob = acceptConnection(ss,true);
		address.append(":"+ss.getLocalPort());
		debugln("Desktop EveSync connection starting on:\n"+address);
		debugln("Connecting...");
		try{
			if (!Vm.javaEveLibraryLoaded()) throw new IOException("java_eve library not found.");
			if (runRemote) try{
				startMobileRemoteServer(address.toString(),null);
			}catch(Throwable t){
				//t.printStackTrace();
				if (t instanceof IOException)
					throw (IOException)t;
				IOException e = new IOException("Error starting remote server.");
				Vm.setCause(e,t);
				throw e;
			}
		}catch(IOException e){
			ob.close();
			throw e;
		}
		TimeOut t = runRemote ? new TimeOut(30*1000) : TimeOut.Forever;
		Object got = ob.get(t,true);
		if (got instanceof IOException) throw (IOException)got;
		if (got == null) throw new IOException("Mobile Remote Server did not connect.");
		
		RemoteServer rs = new RemoteServer();
		Handle h = rs.startPeerComms((Socket)got);
		rs.startClientComms(servicePort(false),true,true);
		debugln("Connection successful!");
		debugln("Desktop EveSync running.");
		showTaskbarStatus("EveSync Connected.");
		//
		runAutoStart(false);
		//
		return h;
	}
	static boolean dontKeepAlive;
	
	public static Handle startActiveSyncMobile(String address) throws IOException
	{
		debugln("Starting on:\n"+address);
		debugln("Connecting...");
		Socket s = new Socket(mString.leftOf(address,':'),Convert.toInt(mString.rightOf(address,':')));
		RemoteServer rs = new RemoteServer();
		//dontKeepAlive = true;
		rs.amMobile = true;
		Handle h = rs.startPeerComms(s);
		rs.startClientComms(servicePort(true),true,true);
		debugln("Success!");
		debugln("Running.");
		showTaskbarStatus("EveSync Connected.");
		return h;
	}
	static PrintWriter db;
	
	public static void setupConsole(PrintWriter console)
	{
		db = console;
	}
	static void debugln(String data)
	{
		if (db != null) db.println(data);
	}

	static IConsole debugForm;
	static ITaskbarEntry taskbar;
	
	static void showTaskbarStatus(String status)
	{
		if (taskbar != null)
			taskbar.setIconAndTip(null,status,taskbar.SET_TIP_IS_VALID);
	}
	static void exitSystem(int val)
	{
		exitSystem(val,3);
	}
	static void exitSystem(int val,int pause)
	{
		if (debugForm != null){
			if (pause > 0/*!Device.isMobile()*/){
				debugln("Exiting in "+pause+" seconds...");
				mThread.nap(pause*1000);
			}
			debugForm.close();
		}
		if (taskbar != null) taskbar.close();
		System.exit(val);
	}
	static boolean setupConsole(String args[],String doingWhat)
	{
		Vm.startEve(args);
		VMOptions vo = VMOptions.vmOptions;
		debugForm = Device.createConsole(doingWhat,IConsole.BUTTON_CLEAR|IConsole.BUTTON_STOP|IConsole.BUTTON_HIDE,100);
		if (debugForm != null){
			db = new PrintWriter(debugForm.getWriter());
			debugForm.getEventDispatcher().addListener(new EventListener(){

				public void onEvent(Event ev) {
					if (ev.type == IConsole.BUTTON_STOP)
						exitSystem(-1,0);
					else if (ev.type == IConsole.BUTTON_CLOSE){
						return;
					}else
						debugForm.doDefaultAction(ev);
				}
				
			});
			if (vo.showEveSyncConsole)
				debugForm.setVisible(true);
		}
		DeviceIcon di = Device.toDeviceIcon(new String[]{"eve/evesync32.png","eve/evesync16.png"});
		if (di != null){
			ITaskbarEntry ti = taskbar = Device.createTaskbarEntry();
			if (ti != null){
				ti.getEventDispatcher().addListener(new EventListener(){
	
					public void onEvent(Event ev) {
						if (debugForm != null) debugForm.setVisible(true);
					}
					});
				ti.setIconAndTip(di,"EveSync starting...",ti.SET_ICON_IS_VALID|ti.SET_TIP_IS_VALID);
			}else
				if (debugForm != null) debugForm.setVisible(true);
		}
		Vm.applicationStarted();
		return true;
	}
	static void endException(Exception e) throws Exception
	{
		showTaskbarStatus("EveSync connection failed.");
		if (db != null){
			e.printStackTrace(db);
			exitSystem(-1,10);
		}
		if (Device.isMobile()){
			exitSystem(0);
		}else{
			throw e;
		}
	}
	static void setup(String[] args,String doingWhat)
	{
		if (!setupConsole(args,doingWhat)) Vm.startEve(args);
	}
	public static void eveMain(String args[])
	{
		Vm.eveMainSetNoVisibleWindow();
	}
	public static void main(String args[]) throws Exception
	{
		try{
			if (args[0].equals("-activesyncdesktop") || args[0].equals("-activesyncdesktoptest")){
				setup(args,"EveSync Destkop Agent");
				Handle h = startActiveSyncDesktop(args[0].equals("-activesyncdesktop"));
				h.waitUntilCompletion();
				debugln("EveSync ended.");
				exitSystem(0);
			}else if (args[0].equals("-activesyncmobile")){
				setup(args,"EveSync Mobile Agent");
				Handle h = startActiveSyncMobile(args[1]);
				h.waitUntilCompletion();
				debugln("EveSync ended.");
				exitSystem(0);
			}else if (args[0].equals("-emulator")){
				setup(args,"EveSync Emulator");
				startEmulator(true);
			}else{
				debugln("Unknown command!");
				exitSystem(0);
			}
		}catch(Exception e){
			endException(e);
		}
	}
}
//####################################################
