/*
 * Created on Oct 3, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.net;

import java.io.IOException;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface IRemoteServer {
	
	public static final int MOBILE_IS_VM_APPLICATION = 1;
	public static final int MANUAL_MOBILE_START_ON_EMULATOR = 2;
	public static final int MOBILE_GET_COMMAND_FROM_REGISTRY = 4;

	/**
	 * Called by a local entity to determine if the local computer can connect directly
	 * to the host/port number (which will usually be the remote computer).<p>
	 * If it returns true then the local entity will attempt a direct connection.
	 * @param hostName
	 * @param portNumber
	 * @return
	 */
	public boolean canConnectTo(String hostName, int portNumber);
	
	
	/**
	 * Called by the remote peer requesting that this entity provide a bridge betwen
	 * the specified host/port (usually the remote peer computer) and the otherHost/otherPort
	 * (usually the local computer).
	 * @param hostName
	 * @param portNumber
	 * @param otherHost
	 * @param otherPort
	 * @throws IOException on error.
	 */
	public void makeBridge(String hostName, int portNumber, String otherHost, int otherPort) throws IOException;
	
	/**
	 * Called by the remote peer requesting the host and port number for a running service.
	 * If the service is not running this entity should attempt to start the service and
	 * then try again to determin the host/port number.
	 * @param serviceName the name of the service.
	 * @return the host name followed by a ';' and the port number.
	 */
	/*
	public String getRemoteHostAndPort(String serviceName);
	
	public String getLocalHostAndPort(String serviceName);
	*/
	/**
	 * Called by the remote peer requesting this entity start running a command on the local
	 * computer.
	 * @param command the command to execute.
	 * @param options any of MOBILE_IS_VM_APPLICATION and MOBILE_GET_COMMAND_FROM_REGISTRY OR'ed together.
	 * If MOBILE_GET_COMMAND_FROM_REGISTRY is selected then the actual command line should
	 * come from the local registry.  
	 */
	public void runLocalCommand(String commandOrRegistryEntry, int options) throws IOException;
	
	public void runRemoteCommand(String commandOrRegistryEntry, int options) throws IOException;
	
	public String getLocalRegistryKeyValue(String keyName) throws IOException;
	
	public String getRemoteRegistryKeyValue(String keyName) throws IOException;
}
//####################################################
