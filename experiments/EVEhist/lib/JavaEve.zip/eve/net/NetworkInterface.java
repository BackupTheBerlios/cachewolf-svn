package eve.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Hashtable;
import java.util.Properties;

import eve.io.File;
import eve.io.Io;
import eve.sys.AsyncTask;
import eve.sys.Device;
import eve.sys.Handle;
import eve.sys.TimeOut;
import eve.sys.Vm;
import eve.util.mString;

/**
 * This class represents a Network interface, usually for the local machine.
 * You can try to find out the NetworkInterfaces on a local machine using
 * getLocalInterfaces(), although this may fail for some machines.
 */
public class NetworkInterface 
{

/**
 * This standard IPv4 address associated with the interface if known.
 */
public InetAddress inet4Address;
/**
 * This standard IPv6 address associated with the interface if known.
 */
public InetAddress inet6Address;
/**
 * The MAC address associated with the interface if known.
 */
public String macAddress;
/**
 * The name of the interface if known (e.g. eth0).
 */
public String deviceId;
/**
 * The name of the hardware if known.
 */
public String deviceName;

/**
 * This may be null but if not may include items like "addr", "Bcast" and "Mask".
 */
public Properties inet4Properties;
/**
 * This may be null but if not may include items like "addr" and "Scope".
 */
public Properties inet6Properties;
/**
 * This may be null but if not may include items that are interface specific.
 */
public Properties properties;

private String allProperties;

private static NetworkInterface[] locals;
private static IOException localError;
private static Hashtable ip6;

private static native NetworkInterface[] getLocalInterfaces(int options) throws IOException;
private static boolean haveNative = true;

private static Properties getProperties(String [] items, int start, Properties p)
{
	if (p == null) p = new Properties();
	for (int i = start; i < items.length; i++){
		String s = items[i];
		int c = s.indexOf(':');
		if (c == -1) break;
		String pname = s.substring(0,c);
		String value = s.substring(c+1);
		if (value.trim().length() == 0){
			++i;
			if (i == items.length) break;
			value = items[i].trim();
		}
		p.setProperty(pname, value);
	}
	return p;
}
private static Properties add(String name,String value,String prefix,Properties old)
{
	if (old == null) old = new Properties();
	if (prefix != null) name = name.substring(prefix.length());
	old.setProperty(name,value);
	return old;
}
private static void listProperties(Properties p,String name)
{
	if (p == null) return;
	System.out.print(name+":");
	p.list(System.out);
}
/**
 * Note that the local loopbacks 127.0.0.1 IS included in this list.
 * @param rescanHardware
 * @return
 * @throws IOException
 */
public synchronized static NetworkInterface[] getLocalInterfaces(Handle h, boolean rescanHardware) throws IOException
{
	/* This was a waste of time. It works in principle but would frequently
	 * hang on Ubuntu.
	 */
	//if (true) throw localError = new IOException("Cannot determine network interfaces at this time.");
	if (rescanHardware) {
		locals = null;
		localError = null;
	}
	if (locals != null) return locals;
	if (localError != null) throw localError;
	if (haveNative)try{
		locals = getLocalInterfaces(0);
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		haveNative = false;
	}
	if (rescanHardware || ip6 == null){
		if (ip6 != null) ip6.clear();
		try{
			BufferedReader br = Io.getBufferedReader(new File("/proc/net/if_inet6"));
			while(true){
				String line = br.readLine();
				if (line == null) break;
				try{
					if (line.length() == 0) continue;
					String[] all = mString.split(line,' ');
					String nm = all[all.length-1].trim();
					char[] ch = Vm.getStringChars(all[0]);
					byte[] by = new byte[16];
					int s = 0;
					int n = 0;
					for (int i = 0; i<16; i++){
						if (ch[s] == ':') s++;
						n = ch[s++];
						if (n >= '0' && n <= '9') n -= '0';
						else if (n >= 'a' && n <= 'f') n = 10+n-'a';
						else if (n >= 'A' && n <= 'F') n = 10+n-'A';
						int x = n << 4;
						n = ch[s++];
						if (n >= '0' && n <= '9') n -= '0';
						else if (n >= 'a' && n <= 'f') n = 10+n-'a';
						else if (n >= 'A' && n <= 'F') n = 10+n-'A';
						x |= n;
						by[i] = (byte)x;
					}
					if (ip6 == null) ip6 = new Hashtable();
					ip6.put(nm,InetAddress.getByAddress(by));
				}catch(Exception e){}
			}
			br.close();
		}catch(IOException e){}
	}
	for (int i = 0; locals != null && i < locals.length; i++){
		NetworkInterface ni = locals[i];
		if (ni.deviceName != null && ni.inet6Address == null && ip6 != null)
			ni.inet6Address = (InetAddress)ip6.get(ni.deviceName); 
		String s = ni.allProperties;
		if (s != null && s.length() != 0){
			String[] p = mString.split(s,'|');
			for (int pp = 0; pp < p.length; pp++){
				String left = mString.leftOf(p[pp], '=');
				String right = mString.rightOf(p[pp], '=');
				if (left.startsWith("ip4-"))
					ni.inet4Properties = add(left,right,"ip4-",ni.inet4Properties);
				else if (left.startsWith("ip6-"))
					ni.inet6Properties = add(left,right,"ip6-",ni.inet6Properties);
				else
					ni.properties = add(left,right,null,ni.properties);
			}
		}
		/*
		System.out.println(ni.deviceName+", "+ni.macAddress);
		System.out.println(ni.inet4Address+", "+ni.inet6Address);
		listProperties(ni.inet4Properties, "IPv4");
		listProperties(ni.inet6Properties, "IPv6");
		listProperties(ni.properties, "Other");
		*/
	}
	return locals;
	/*
	try{
		Process p = Vm.tryExecCommandLine("ifconfig",new String[]{"/sbin","/usr/bin","/usr/sbin"},false,null);
		if (p == null) throw new IOException("Could not run ifconfig");
		BufferedReader br = new BufferedReader(
				new InputStreamReader(p.getInputStream()));
		Vector v = new Vector();
		NetworkInterface n = null;
		while(true){
			String s = br.readLine();
			if (s == null) break;
			if (s.trim().length() == 0 || !Character.isWhitespace(s.charAt(0))){
				if (n != null) v.add(n);
				n = null;
			}
			String[] all = mString.split(s,' ');
			if (all.length == 0) continue;
			int i = 0;
			if (n == null) {
				n = new NetworkInterface();
				n.deviceId = all[i++];
			}
			try{
				while(i < all.length){
					if (all[i].equalsIgnoreCase("inet")){
						n.inet4Properties = getProperties(all, i+1, n.inet4Properties);
						try{
							String addr = n.inet4Properties.getProperty("addr");
							n.inet4Address = InetAddress.getByName(addr); 
						}catch(Throwable t){}
						break;
					}else if (all[i].equalsIgnoreCase("inet6")){
						n.inet6Properties = getProperties(all, i+1, n.inet6Properties);
						try{
							String addr = n.inet6Properties.getProperty("addr");
							n.inet6Address = InetAddress.getByName(addr); 
						}catch(Throwable t){}
						break;
					}else if (all[i].equalsIgnoreCase("hwaddr")){
						i++;
						n.macAddress = all[i++];
					}else
						i++;
				}
			}catch(Exception c){
				//c.printStackTrace();
			}
		}
		if (n != null) v.add(n);
		br.close();
		NetworkInterface[] all = new NetworkInterface[v.size()];
		v.copyInto(all);
		locals = all;
		return all;
	}catch(IOException e){
		//e.printStackTrace();
		throw localError = new IOException("Cannot determine network interfaces at this time.");
	}
	*/
}
public static NetworkInterface[] getLocalInterfaces(boolean rescanHardware,TimeOut timeout) throws IOException
{
	//if (true) throw localError = new IOException("Cannot determine network interfaces at this time.");
	Handle h = AsyncTask.invokeOn(NetworkInterface.class,"getLocalInterfaces(Leve/sys/Handle;Z)[Leve/net/NetworkInterface;",new Object[]{null,Boolean.valueOf(rescanHardware)});
	if (!h.waitUntilCompletion(timeout) || !(h.returnValue instanceof NetworkInterface[])){
		throw new IOException("Cannot determine network interfaces at this time.");
	}
	return (NetworkInterface[])h.returnValue;
}

public static void main(String[] args)
{
	Vm.startEve(args);
	try{
		InetAddress [] all = eve.net.Net.getLocalAddresses(true, false);
		System.out.println("There are "+all.length+" active IP addresses.");
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i<all.length; i++){
			if (sb.length() != 0) sb.append(", ");
			sb.append(all[i]);
		}
		if (sb.length() != 0) System.out.println(sb);
		/*
		NetworkInterface[] all = getLocalInterfaces(true,new TimeOut(10000));
		for (int i = 0; i<all.length; i++){
			System.out.println(all[i].deviceId+", "+all[i].macAddress+", "+all[i].inet4Address+", "+all[i].inet6Address);
			if (all[i].inet4Properties != null)
				all[i].inet4Properties.list(System.out);
			else
				System.out.println("No IP4 properties.");
			if (all[i].inet6Properties != null)
				all[i].inet6Properties.list(System.out);
			else
				System.out.println("No IP6 properties.");
		}
		*/
	}catch(Exception e){
		e.printStackTrace();
	}
	//mVector v = new mVector(getLocalAddresses(false,false));
	//System.out.println("Addresses: "+v);
	Vm.exit(0);
}

}
