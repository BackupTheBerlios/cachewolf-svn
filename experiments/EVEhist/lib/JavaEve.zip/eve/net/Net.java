/*
 * Created on Mar 31, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.net;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Vector;

import eve.io.Io;
import eve.sys.Handle;
import eve.sys.IRemoteProxyMaker;
import eve.sys.Reflection;
import eve.sys.Task;
import eve.sys.TimeOut;
import eve.sys.Vm;


/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Net {
//####################################################

/**
 * This is the host name associated with the infra-red port.
 */
public static final String infraRedHostName = Io.infraRedHostName;

/**
 * If this is set true then this indicates that the application is not
 * interested in using Socket ti
 */
//public static boolean dontUseSocketTimeouts = false;
/**
 * @return the InetAddress associated with the infra-red port on the local/remote device.
 * @throws UnknownHostException if no infra-red port is available.
 */
public static InetAddress getInfraRedAddress() throws UnknownHostException 
{
	return InetAddress.getByName(infraRedHostName);
}
/**
 * Return if an infra-red port is available on the local host.
 */
public static boolean hasInfraRedPort()
{
	try{
		getInfraRedAddress();
		return true;
	}catch(UnknownHostException e){
		return false;
	}
}
private static Socket returnSocket(Handle handle, Socket s)
{
	if (handle == null) return s;
	else if (handle.shouldStop){
		if (s != null)try{
			s.close();
		}catch(Exception e){
		}
		return null;
	}else
		return s;
}
public static Socket newSocket(Handle handle,Object host,int port) throws UnknownHostException, IOException
{
	if (handle != null) {
		handle.startDoing("Connecting");
		if (handle.shouldStop) return null;
	}
	return returnSocket(handle, host instanceof String ? 
							new Socket((String)host,port) :
								new Socket((InetAddress)host,port));
}

public static Socket acceptConnection(Handle handle, ServerSocket ss) throws IOException
{
	if (handle != null) {
		handle.startDoing("Accepting");
		if (handle.shouldStop) return null;
	}
	return returnSocket(handle,ss.accept());
}
/**
 * Create a new connected Socket in a separate thread.
 * @param host the host to connect to.
 * @param port the port to connect to.
 * @return a Handle that can be used to monitor the connection process. If it reports
 * success then the returnValue will be the connected socket. If it fails then the error
 * in the handle will indicate the thrown exception. Note that calling stop() on the Handle
 * will not necessarily stop the connection.
 */
public static Handle newSocket(String host,int port)
{
	return Reflection.invokeAsync(Net.class,"newSocket(Leve/sys/Handle;Ljava/lang/Object;I)Ljava/net/Socket;",new Object[]{null,host,new Integer(port)});
}
/**
 * Create a new connected Socket in a separate thread.
 * @param host the host to connect to.
 * @param port the port to connect to.
 * @return a Handle that can be used to monitor the connection process. If it reports
 * success then the returnValue will be the connected socket. If it fails then the error
 * in the handle will indicate the thrown exception.
 */
public static Handle newSocket(InetAddress host,int port)
{
	return Reflection.invokeAsync(Net.class,"newSocket(Leve/sys/Handle;Ljava/lang/Object;I)Ljava/net/Socket;",new Object[]{null,host,new Integer(port)});
}

public static Handle acceptConnection(ServerSocket ss)
{
	return Reflection.invokeAsync(Net.class,"acceptConnection(Leve/sys/Handle;Ljava/net/ServerSocket;)Ljava/net/Socket;",new Object[]{null,ss});
}
/**
 * Create two sockets connected to each other on the local machine.
 */
public static Socket[] pipe() throws IOException
{
	final Socket[] ret = new Socket[2];
	final ServerSocket ss = new ServerSocket(0);
	Handle h = 
	new Task(){
		protected void doRun(){
			try{
				ret[1] = ss.accept();
				ss.close();
				succeed(null);
			}catch(Exception e){
				fail(e);
			}
		}
	}.start();
	try{
		ret[0] = new Socket(getLocalHost(),ss.getLocalPort());
		h.waitOn(Handle.Success);
		return ret;
	}catch(Exception hs){
		try{
			ss.close();
		}catch(Exception e){}
		if (h.error instanceof IOException) throw (IOException)h.error;
		throw new IOException("Could not connect.");
	}
}
public static String toOneHostAddress(InetAddress addr)
{
	if (!addr.isAnyLocalAddress()){
		return addr.getHostAddress();
	}
	try{
		InetAddress[] all = getLocalAddresses(false,true);
		if (all == null || all.length == 0) return addr.getHostAddress();
		return all[0].getHostAddress();
	}catch(Exception e){
	}
	return addr.getHostAddress();
}
public static boolean isLoopbackAddress(InetAddress addr)
{
	if (addr == null) return false;
	if (addr instanceof Inet4Address)
		return ((Inet4Address)addr).isLoopbackAddress();
	if (addr instanceof Inet6Address)
		return ((Inet6Address)addr).isLoopbackAddress();
	return false;
}
public static String toHostAddresses(InetAddress addr)
{
	if (!addr.isAnyLocalAddress()) return addr.getHostAddress();
	try{
		InetAddress[] all = getLocalAddresses(false,true);
		//InetAddress.getAllByName(InetAddress.getLocalHost().getHostName());
		if (all == null || all.length == 0) return addr.getHostName();
		StringBuffer r = new StringBuffer();
		for (int i = 0; i<all.length; i++){
			if (i != 0) r.append(';');
			r.append(all[i].getHostAddress());
		}
		return r.toString();
	}catch(Exception e){
		return addr.getHostAddress();
	}
}
/**
 * Try to find the list of all IP addresses held by the local host, but 
 * not including the local loop backs
 */
public static InetAddress[] getLocalAddresses(boolean rescanHardware, boolean ip4Only)
{
	Vector v = new Vector();
	try{
		InetAddress[] all = InetAddress.getAllByName(InetAddress.getLocalHost().getHostName());
		for (int i = 0; i<all.length; i++){
			if (Net.isLoopbackAddress(all[i])) continue;
			if (ip4Only && !(all[i] instanceof Inet4Address)) continue;
			if (v.indexOf(all[i]) == -1) 
				v.add(all[i]);
		}
	}catch(IOException e){
		
	}
	try{
		NetworkInterface[] all = NetworkInterface.getLocalInterfaces(rescanHardware,new TimeOut(3000));
		for (int i = 0; i<all.length; i++){
			if (all[i].inet4Address != null && !v.contains(all[i].inet4Address))
				if (!Net.isLoopbackAddress(all[i].inet4Address))
					v.add(all[i].inet4Address);
			if (ip4Only) continue;
			if (all[i].inet6Address != null && !v.contains(all[i].inet6Address))
				if (!Net.isLoopbackAddress(all[i].inet6Address))
					v.add(all[i].inet6Address);
		}
	}catch(IOException e){
		
	}
	InetAddress[] ret = new InetAddress[v.size()];
	v.copyInto(ret);
	return ret;
}
/**
 * A "safer" version of InetAddress getLocalHost(). If no local host was found
 * it will return attempt to return the 127.0.0.1 address.
 */
public static InetAddress getLocalHost() throws UnknownHostException
{
	try{
		return InetAddress.getLocalHost();
	}catch(IOException e){
		return InetAddress.getByName("127.0.0.1");
	}
}
public static InetAddress fixLocalAddress(InetAddress address,InetAddress defaultAddress)
{
	byte[] all = address.getAddress();
	for (int i = 0; i<all.length; i++) 
		if (all[i] != 0) return address;
	try{
		return defaultAddress == null ? getLocalHost() : defaultAddress;
	}catch(IOException e){
		return address;
	}
	
}
public static InetAddress getLocalAddress(ServerSocket ss,InetAddress defaultTo)
{
	return fixLocalAddress(ss.getInetAddress(),defaultTo);
}
public static InetAddress getLocalAddress(ServerSocket ss)
{
	return fixLocalAddress(ss.getInetAddress(),null);
}
public static InetAddress getLocalAddress(Socket s,InetAddress defaultTo)
{
	return fixLocalAddress(s.getLocalAddress(),defaultTo);
}
public static InetAddress getLocalAddress(Socket s)
{
	return fixLocalAddress(s.getLocalAddress(),null);
}
public static InetAddress getRemoteAddress(Socket s,InetAddress defaultTo)
{
	return fixLocalAddress(s.getInetAddress(),defaultTo);
}
public static InetAddress getRemoteAddress(Socket s)
{
	return fixLocalAddress(s.getInetAddress(),null);
}
/**
 * Start up a server that accepts Remote Method Invocation calls on the 
 * provided connected socket.
 * @param serverObject the Object acting as the server.
 * @param serverInterface the Interface the serverObject will implement.
 * @param connectedSocket the connected socket.
 * @param callTimeOutInMillis the length of time in milliseconds before
 * remote calls time out. A zero or negative value indicates that the
 * default should be used.
 * @return a Handle that can be used to monitor the connection. Once the
 * Stopped bit is set this indicates the connection has closed. Calling stop()
 * on the Handle will also close the connection.
 * @throws IOException on any IO error.
 */
public static Handle startRemoteServer(Object serverObject, Class serverInterface, Socket connectedSocket,int callTimeOutInMillis)
throws IOException
{
	IRemoteProxyMaker pm = Vm.getRemoteProxyMaker(serverInterface, 0, null);
	if (callTimeOutInMillis > 0) pm.setTimeOut(callTimeOutInMillis);
	return pm.makeServerObject(serverObject, connectedSocket, connectedSocket);
}
/**
 * Create a proxy object that implements serverInterface by making remote
 * calls to a server object at the other end of the connectedSocket.
 * @param serverInterface the Interface the serverObject will implement.
 * @param connectedSocket the connected socket.
 * @param callTimeOutInMillis the length of time in milliseconds before
 * remote calls time out. A zero or negative value indicates that the
 * default should be used.
 * @return an Object that implements serverInterface by making remote
 * calls to a server object at the other end of the connectedSocket.
 * @throws IOException on any IO error.
 */
public static Object startClientProxy(Class serverInterface, Socket connectedSocket, int callTimeOutInMillis)
throws IOException
{
	IRemoteProxyMaker pm = Vm.getRemoteProxyMaker(serverInterface, 0, null);
	if (callTimeOutInMillis > 0) pm.setTimeOut(callTimeOutInMillis);
	pm.setConnection(connectedSocket,connectedSocket);
	return pm.createProxy();
}
//####################################################
}
//####################################################
