
package eve.net;
import eve.sys.Vm;


public final class URL //implements Serializable
{
final static String hex = "0123456789ABCDEF";
/**
 * Encode the URL using %## notation.
 * @param url The unencoded URL.
 * @param spaceToPlus true if you wish a space to be encoded as a '+', false to encode it as %20
 * @return The encoded URL.
 */
//===================================================================
public static String encodeURL(String url, boolean spaceToPlus)
//===================================================================
{
	char [] what = Vm.getStringChars(url);
	int max = what.length;
	char [] dest = new char[max+max/2];
	char d = 0;
	for (int i = 0; i<max; i++){
		if (d >= dest.length-2) {
			char [] n = new char[dest.length+dest.length/2+3];
			System.arraycopy(dest,0,n,0,d);
			dest = n;
		}
		char c = what[i];
		if (spaceToPlus && c == ' ') c = '+';
		else if (c <= ' ' || c == '+' || c == '&' || c == '%' || c == '=' || c == '|' || c == '{' || c == '}'){
			dest[d++] = '%';
			dest[d++] = hex.charAt((c >> 4) & 0xf);
			dest[d++] = hex.charAt(c & 0xf);
			continue;
		}
		dest[d++] = c;
	}
	return new String(dest,0,d);
}

/**
 * Decode a URL encoded with '%##' notation.
 * @param url The possibly encoded URL.
 * @return The decoded URL.
 */
//===================================================================
public static String decodeURL(String url)
//===================================================================
{
	char [] src = Vm.getStringChars(url);
	char [] dest = new char[src.length];
	int max = src.length;
	int d = 0;
	for (int i = 0; i<max; i++){
		char c = src[i];
		if (c == '+') c = ' ';
		else if (c == '%'){
			int v = hex.indexOf(Character.toUpperCase(src[++i]));
			v = v << 4;
			v |= hex.indexOf(Character.toUpperCase(src[++i]));
			dest[d++] = (char)(v & 0xff);
			continue;	
		}
		dest[d++] = c;
	}
	return new String(dest,0,d);
}
/*
//===================================================================
public URLConnection openConnection() throws IOException
//===================================================================
{
	throw new IOException("Cannot open a connection!");
}
*/
//===================================================================
//public String toString() {return url;}
//===================================================================

/*
  private void readObject(ObjectInputStream ois)
    throws IOException, ClassNotFoundException
  {
    ois.defaultReadObject();
    this.ph = getURLStreamHandler(protocol);
    if (this.ph == null)
      throw new IOException("Handler for protocol " + protocol + " not found");
  }

  private void writeObject(ObjectOutputStream oos) throws IOException
  {
    oos.defaultWriteObject();
  }
	*/
}


