package eve.applet;

import sun.misc.Signal;
import eve.sys.SignalHandler;

class shBridge implements sun.misc.SignalHandler{

	SignalHandler mine;
	int mySig;
	public shBridge(SignalHandler me,int which)
	{
		mine = me;
		mySig = which;
		if (mySig == 0) return;//Just testing handling.
		sun.misc.SignalHandler old = Signal.handle(Signals.toSignal(which), this);
		if (old instanceof shBridge)
			me.installed(which, ((shBridge)old).mine);
		else
			me.installed(which, null);
	}
	public void handle(Signal arg0) {
		mine.handleSignal(mySig);
		
	}
	
}
class Signals {

	public static Signal toSignal(int which)
	{
		switch(which){
			case SignalHandler.SIGINT: return new Signal("INT");
			case SignalHandler.SIGTERM: return new Signal("TERM");
		}
		throw new IllegalArgumentException("Unknown signal.");
	}
	public static boolean setSignalHandler(SignalHandler sh,int which)
	{
		new shBridge(sh,which);
		return true;
	}
}
