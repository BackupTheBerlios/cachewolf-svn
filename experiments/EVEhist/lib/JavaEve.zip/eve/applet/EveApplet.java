/*
 * Created on Jan 7, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.applet;

import java.applet.Applet;
import java.applet.AppletContext;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import eve.data.PropertyList;
import eve.io.FakeFileSystem;
import eve.io.FileRandomStream;
import eve.io.RandomStream;
import eve.io.StreamUtils;
import eve.sys.Convert;
import eve.sys.Device;
import eve.sys.IRegistryKey;
import eve.sys.MapRegistryKey;
import eve.sys.Registry;
import eve.sys.SignalHandler;
import eve.sys.Vm;
import eve.ui.SIPButton;
import eve.util.ByteArray;
import eve.util.ObjectIterator;
import eve.util.TextDecoder;
import eve.util.Utils;
import eve.util.mString;
import eve.zipfile.ZipEntry;
import eve.zipfile.ZipFile;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class EveApplet extends Applet{
static {
//	System.out.println("Initializing Applet class.");
}
public static int messageBox(String title, String message, int type)
{
	JOptionPane jp = new JOptionPane(message);
	int jtype = JOptionPane.OK_OPTION;
	switch((type & Device.MB_MASK_FOR_TYPE)){
		case Device.MB_TYPE_OK : jtype = JOptionPane.OK_OPTION; break;
		case Device.MB_TYPE_OKCANCEL : jtype = JOptionPane.OK_CANCEL_OPTION; break;
		case Device.MB_TYPE_YESNO : jtype = JOptionPane.YES_NO_OPTION; break;
		case Device.MB_TYPE_YESNOCANCEL : jtype = JOptionPane.YES_NO_CANCEL_OPTION; break;
		default:
			jtype = JOptionPane.OK_OPTION; break;
	}
	if (jtype != JOptionPane.OK_OPTION) jp.setOptionType(jtype);
	JDialog d = jp.createDialog(null,title);
	//d.show();
	d.setVisible(true);
	Object ret = jp.getValue();
	if (!(ret instanceof Integer)) return Device.IDCANCEL;
	switch(((Integer)ret).intValue()){
	case JOptionPane.NO_OPTION: return Device.IDNO;
	case JOptionPane.CANCEL_OPTION: return Device.IDCANCEL;
	default:
		if ((type & Device.MB_MASK_FOR_TYPE) == Device.MB_TYPE_OK)
			return Device.IDOK;
		else
			return Device.IDYES;
	}
}

public static int vmFlags = 0;
private static boolean isTrueApplet = true;
private static EveApplet applet;
private static EveApplet currentApplet;
private static boolean loadFakeFile = false;
private static Object uiLock = new Object();

public synchronized static EveApplet getApplet()
{
	//if (applet == null) applet = new EveApplet();
	return applet;
}
private static ZipFile resources;
public ZipFile getResources()
{
	return resources;
}
void loadResources()
{
	try{
		RandomStream s = Vm.openResourceAsRandomStream(getClass(),"_resources.zip");
		if (s != null) resources = new ZipFile(s);
	}catch(Exception e){
	}
}
public synchronized static eve.sys.Applet getSysApplet()
{
	if (!isTrueApplet) return null;
	final EveApplet app = applet; 
	if (app == null) return null;
	return new eve.sys.Applet(){

		public boolean isActive() {
			try{
				return app.isActive();
			}catch(Throwable t){
				return false;
			}
		}

		public URL getDocumentBase() {
			try{
				return app.getDocumentBase();
			}catch(Throwable t){
				return null;
			}
		}

		public URL getCodeBase() {
			try{
				return app.getCodeBase();
			}catch(Throwable t){
				return null;
			}
		}

		public String getParameter(String name) {
			try{
				return app.getParameter(name);
			}catch(Throwable t){
				return null;
			}
		}

		public boolean appletResize(int width, int height) {
			try{
				 app.resize(width,height);
				 return true;
			}catch(Throwable t){
				return false;
			}
		}

		public boolean showDocument(URL url) {
			try{
				app.showDocument(url);
				return true;
			}catch(Throwable t){
				return false;
			}
		}

		public boolean showDocument(URL url, String target) {
			try{
				app.showDocument(url,target);
				return true;
			}catch(Throwable t){
				return false;
			}
		}

		public boolean showStatus(String message) {
			try{
				app.showStatus(message);
				return true;
			}catch(Throwable t){
				return false;
			}
		}

		public void setStream(String key, InputStream stream) throws IOException {
			try{
				app.setStream(key,stream);
			}catch(IOException e){
				throw e;
			}catch(Throwable t){
				throw new IOException();
			}
		}

		public InputStream getStream(String key) {
			try{
				return app.getStream(key);
			}catch(Throwable t){
				return null;
			}
		}

		public Iterator getStreamKeys() {
			try{
				return app.getStreamKeys();
			}catch(Throwable t){
				return new ObjectIterator(null);
			}
		}
		
	};
}
/*
public static AppletStub getAppletStub()
{
	final Applet app = getApplet();
	if (app == null) return null;
	return new AppletStub(){

		public boolean isActive() {
			return app.isActive();
		}

		public void appletResize(int arg0, int arg1) {
			app.resize(arg0,arg1);
		}

		public AppletContext getAppletContext() {
			return app.getAppletContext();
		}

		public URL getCodeBase() {
			return app.getCodeBase();
		}

		public URL getDocumentBase() {
			return app.getDocumentBase();
		}

		public String getParameter(String arg0) {
			return app.getParameter(arg0);
		}
		
	};
}
*/
static FakeFileSystem fileSystem;
public String className;
public String eveFile;
public static String programDirectory;
public String title;
public static String localLanguage, localCountry;
public static String [] commandLine = null;
public static String [] programArguments = new String[0];
public boolean isColor = true;
public boolean isApplication = false;
public int width,height;
public static int mainWidth;
public static int mainHeight;
	/**
	 * 
	 */
	public EveApplet() {
		//
		// If created via an Applet remember to call Vm.startedEve().
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static void setClipboardText(String text)
	{
		if (text == null) text = "";
		java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new java.awt.datatransfer.StringSelection(text),null);
	}
	public static String getClipboardText()
	{
		try{
			return (String)java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().getContents(new Object()).getTransferData(java.awt.datatransfer.DataFlavor.stringFlavor);
		}catch(Exception e){
			return null;
		}
	}
	//
//	===================================================================
	String [] splitArgs(String line)
//	===================================================================
	{
		Vector v = new Vector();
		int i = 0, max = line.length();
		while(i<max){
			StringBuffer sb = new StringBuffer();
			while(i<max && Character.isWhitespace(line.charAt(i))) i++;
			if (i>=max) break;
			if (line.charAt(i) == '"'){
				i++;
				while(i<max && line.charAt(i) != '"') sb.append(line.charAt(i++));
				i++;
				v.addElement(sb.toString());
				continue;
			}else{
				while(i<max && !Character.isWhitespace(line.charAt(i))) sb.append(line.charAt(i++));
				v.addElement(sb.toString());
			}
		}
		String [] got = new String[v.size()];
		v.copyInto(got);
		return got;
	}
	
	private static Vector eveFiles = new Vector();
	//
//	===================================================================
	private static boolean loaded(String fileName)
//	===================================================================
	{
		for (int i = 0; i<eveFiles.size(); i++){
			EveFile ef = (EveFile)eveFiles.elementAt(i);
			if (ef.myFileName.equals(fileName)) return true;
		}
		return false;
	}
	public static InputStream openLocalResource(String resourceName)
	{
		InputStream got = openStreamInEves(resourceName,false);
		if (got != null || !isTrueApplet) return got;
		try{
			if (resources != null)try{
				ZipEntry ze = resources.getEntry(resourceName);
				if (ze != null) return resources.getInputStream(ze);
			}catch(Exception e){}
			URL codeBase = currentApplet.getCodeBase();
			String cb = codeBase.toString();
			char lastc = cb.charAt(cb.length() - 1);
			char firstc = resourceName.charAt(0);
			if (lastc != '/' && firstc != '/')
				cb += "/";
			URL url = new java.net.URL(cb + resourceName);
			return url.openStream();
		}catch(Exception e){
			return null;
		}
	}
//	===================================================================
	public static InputStream openStreamInEves(String fileName)
//	===================================================================
	{
		return openStreamInEves(fileName,false);
	}

//	===================================================================
	public static java.io.InputStream openStreamInEves(String fileName,boolean runFile)
//	===================================================================
	{
		if (fileName != null) fileName = fileName.replace('\\','/');
		if (!runFile && fileName != null){
			try{/*
				String fn = fileName;
				if (!fn.startsWith("/")) fn = '/'+fn;
				InputStream is = appletClass.getResourceAsStream(fn);
				if (is != null){
					return is;
				}*/
			}catch(Exception e){
			}
		}
		byte [] got = findFileInEves(fileName,runFile);
		if (got == null) return null;
		return new java.io.ByteArrayInputStream(got);
	}
//	===================================================================
	public static byte [] findFileInEves(String fileName)
//	===================================================================
	{
		return findFileInEves(fileName,false);
	}
//	===================================================================
	public static byte [] findFileInEves(String fileName,boolean runFile)
//	===================================================================
	{
		for (int i = 0; i<eveFiles.size(); i++){
			EveFile ef = (EveFile)eveFiles.elementAt(i);
			try{
				byte [] ret = 
					runFile ? ef.getRunFile() :  ef.getFile(fileName);
				if (ret != null) {
					if (runFile) {
						if (programDirectory == null)
							programDirectory = new File(ef.myFileName).getParent();
					}
					return ret;
				}
			}catch(IOException e){
				e.printStackTrace();
				continue;
			}
		}
		return null;
	}
	private void findMainAppClass() throws Exception
	{
		String line = null;
		if (eveFiles.size() == 0){
			//No eweFiles - look for CommandLine.txt in resourceFile
			InputStream in = openStreamInEves("/META-INF/CommandLine.txt");
			if (in != null){
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				line = br.readLine();
				br.close();
			}
		}
		if (line == null){
			InputStream in = openStreamInEves(null,true);
			if (in == null) throw new Exception("Main class not specified");
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			line = br.readLine();
			br.close();
		}
		if (line != null){
			String [] args = splitArgs(line);
			processArgs(args,1);
		}
		if (className == null) 
			throw new Exception("Main class not specified");
	}
	
	static StringBuffer userCommands = new StringBuffer();
	static void toUserCommands(String[] args, int start)
	{
		if (userCommands.length() != 0) return;
		for (int i = start; i<args.length; i++){
			if (i != start) userCommands.append(' ');
			boolean q = (args[i].indexOf(' ') != -1);
			if (q) userCommands.append('\"');
			userCommands.append(args[i]);
			if (q) userCommands.append('\"');
		}
	}
	
	boolean setupClassPathAndProgramDir(String fileName, String className)
	{
		char[] file = fileName.toCharArray();
		char[] clazz = className.toCharArray();
		int cl = clazz.length-1, fn = file.length-1;
		if (cl > fn) return false;
		while(cl >= 0 && clazz[cl] != '/') cl--;
		while(fn >= 0 && file[fn] != '/' && file[fn] != '\\') fn--;
		if (fn > 0) fileName = fileName.substring(0,fn);
		else fileName = "";
		if (cl > 0) className = className.substring(0,cl);
		else className = "";
		if (fn > 0){
			// There is still some file data.
			if (cl > 0 && fn > cl){
				cl--;
				fn--;
				// There is still some package name.
				boolean matches = true;
				while (cl >= 0 && matches){
					char c = clazz[cl];
					char f = file[fn];
					if (c == '/')
						matches = f == '/' || f == '\\';
					else
						matches = c == Character.toUpperCase(f) || c == Character.toLowerCase(f);
					cl--;
					fn--;
				}
				if (!matches) return false;
				if (file[fn] != '/' && file[fn] != '\\') return false;
				fileName = fileName.substring(0,fn);
			}
			if (fn > 0){
				//
				if (classLoader != null){
					PathClassInfoLoader pil = new FileClassInfoLoader();
					pil.paths.addElement(fileName);
					classLoader.classInfoLoaders.addElement(pil);
				}				
				if (fn > 8){ // See if it ends with "/classes"
					boolean matches = true;
					char[] cc = "classes".toCharArray();
					matches = file[fn-8] == '/' || file[fn-8] == '\\';
					for (int i = 0; i<7 && matches; i++){
						char c = cc[i];
						char fc = file[fn-7+i];
						if (fc != c && fc != Character.toUpperCase(c))
							matches = false;
					}
					if (matches){
						fn -= 8;
						fileName = fileName.substring(0,fn);
					}
				}
				if (programDirectory == null)
					programDirectory = fileName;
			}
			return true;
		}
		return false;
	}
	
//	===================================================================
	void processArgs(String [] args,int level) 
//	===================================================================
	{
		try{
			int count = args.length, i = 0;
			for (i = 0; i < count; i++)
			{
				String arg = args[i];
				if (arg.toLowerCase().endsWith(".eve")){
					toUserCommands(args,i);
					if (eveFile == null) 
						eveFile = arg;
					if (programDirectory == null)
						programDirectory = new File(arg).getParent();
					try{
						if (!loaded(arg)){
							RandomStream raf = new EveFile(arg);
							eveFiles.addElement(raf);
							if (className == null) try{
								findMainAppClass();
							}catch(Exception e){}
						}
					}catch(Exception e){
						System.out.println("Error: "+e.getMessage());
					}
				}else if (arg.endsWith(".class")){
					toUserCommands(args,i);
					try{
						arg = arg.replace('\\','/'); 
						File f = new File(arg);
						int len = (int)f.length();
						byte[] data = new byte[len];
						InputStream in = new FileInputStream(f);
						int read = 0;
						while(read < len){
							int r = in.read(data,read,len-read);
							if (r < 0) throw new IOException("File not completely read.");
							read += r;
						}
						in.close();
						//
						eve.sys.ClassFile cf = new eve.sys.ClassFile(new ByteArray(data));
						setupClassPathAndProgramDir(arg, cf.name);
						className = cf.name.replace('/', '.');
					}catch(Exception e){
						System.out.println("Error: "+e.getMessage());
					}
				}else if (arg.charAt(0) != '/' && arg.charAt(0) != '-') {
					toUserCommands(args,i);
					if (className != null) break;
					className = arg;
				}else{
					if (arg.charAt(0) == '-')
						arg = '/'+arg.substring(1);
					if (className != null){
						if (arg.equals("/-")) i++;
						break;
					}
					if (arg.equals("/-") || arg.equals("--")){
						i++;
						break;
					}else if (arg.equals("/a")){
						vmFlags |= Vm.VM_FLAG_LOW_MEMORY|Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD;
						vmFlags |= Vm.VM_FLAG_NO_PEN|Vm.VM_FLAG_HAS_SOFT_KEYS|Vm.VM_FLAG_NO_WINDOWS|Vm.VM_FLAG_HIDDEN_SOFTKEYS|Vm.VM_FLAG_HAS_SOFTKEY_MENU_BUTTON;
						//vmFlags |= Vm.VM_FLAG_HAS_BACK_BUTTON;
						Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,20);
						if (mainWidth == 0 && mainHeight == 0){
							mainWidth = 240;
							mainHeight = 240;
						}
					}else if (arg.equals("/s")){
						vmFlags |= Vm.VM_FLAG_LOW_MEMORY|Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD;
						vmFlags |= Vm.VM_FLAG_NO_PEN|Vm.VM_FLAG_HAS_SOFT_KEYS|Vm.VM_FLAG_NO_WINDOWS|Vm.VM_FLAG_USE_NATIVE_TEXT_INPUT;
						vmFlags |= Vm.VM_FLAG_HAS_BACK_BUTTON;
						Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,20);
						//vmFlags |= Vm.VM_FLAG_IS_MOBILE;
						if (mainWidth == 0 && mainHeight == 0){
							mainWidth = 176;
							mainHeight = 220;
						}
					}else if (arg.equals("/n770")||arg.equals("/n800")){
						vmFlags |= Vm.VM_FLAG_USE_SOFT_KEYPAD|Vm.VM_FLAG_NO_WINDOWS|Vm.VM_FLAG_MAXIMIZE_APPS|Vm.VM_FLAG_NO_MOUSE_POINTER;
						
						//vmFlags |= Vm.VM_FLAG_LOW_MEMORY|Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD;
						//vmFlags |= Vm.VM_FLAG_NO_WINDOWS;
						//vmFlags |= Vm.VM_FLAG_USE_SOFT_KEYPAD;
						//vmFlags |= Vm.VM_FLAG_HAS_BACK_BUTTON;
						//vmFlags |= Vm.VM_FLAG_IS_MOBILE;
						if (mainWidth == 0 && mainHeight == 0){
							mainWidth = 800;
							mainHeight = 480;
						}
						/*
						if (mainWidth > 300 && mainWidth < 480)
							Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,35);
						else if (mainWidth >= 480)
							Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,52);
							*/
					}else if (arg.equals("/s5") || arg.equals("/s6")){
						Vm.setProperty("windows.version",arg.equals("/s6")? "mobile 6": "mobile 5");
						Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,26);
						vmFlags |= Vm.VM_FLAG_LOW_MEMORY|Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD;
						vmFlags |= Vm.VM_FLAG_NO_PEN|Vm.VM_FLAG_HAS_SOFT_KEYS|Vm.VM_FLAG_NO_WINDOWS|Vm.VM_FLAG_USE_NATIVE_TEXT_INPUT;
						vmFlags |= Vm.VM_FLAG_HAS_BACK_BUTTON;
						//vmFlags |= Vm.VM_FLAG_IS_MOBILE;
						if (mainWidth == 0 && mainHeight == 0){
							mainWidth = 240;
							mainHeight = 320-26;
						}
						if (mainWidth > 300 && mainWidth < 480)
							Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,35);
						else if (mainWidth >= 480)
							Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,52);
					}else if (arg.equals("/m")){
						vmFlags |= Vm.VM_FLAG_LOW_MEMORY;
					}else if (arg.equals("/b")){
						if (++i < count) title = args[i];
					}else if (arg.equals("/n")){
						vmFlags |= Vm.VM_FLAG_NO_WINDOWS;
					}else if (arg.equals("/r")){
						vmFlags |= Vm.VM_FLAG_IS_MOBILE;
					}else if (arg.equals("/k")){
						vmFlags |= Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD;
					}else if (arg.equals("/p5")||arg.equals("/p6")){
						Vm.setProperty("windows.version",arg.equals("/p6")? "mobile 6": "mobile 5");
						Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,26);
						vmFlags |= Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD;
						vmFlags |= Vm.VM_FLAG_HAS_SOFT_KEYS|Vm.VM_FLAG_NO_WINDOWS|Vm.VM_FLAG_SIP_BUTTON_ON_SCREEN;
						Vm.setParameter(Vm.SIMULATE_SIP,1);
						if (mainWidth == 0 && mainHeight == 0){
							mainWidth = 240;
							mainHeight = 320;
						}
						if (mainWidth > 300 && mainWidth < 480)
							Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,35);
						else if (mainWidth >= 480)
							Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,52);
					}else if (arg.equals("/p")){ 
						Vm.setParameter(Vm.GET_PARAMATER_SOFTKEY_BAR_HEIGHT,26);
						vmFlags |= Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD|Vm.VM_FLAG_SIP_BUTTON_ON_SCREEN;
						Vm.setParameter(Vm.SIMULATE_SIP,1);
						if (mainWidth == 0 && mainHeight == 0){
							mainWidth = 240;
							mainHeight = 320;
						}
					}else if (arg.equals("/f")){
						vmFlags |= Vm.VM_FLAG_LOAD_FAKE_FILE;
					}else if (arg.equals("/z")){
						vmFlags |= Vm.VM_FLAG_IS_MONOCHROME;
					}else if (args[i].equals("/d")){
						programDirectory = args[++i];
						if (programDirectory.endsWith("/") || programDirectory.endsWith("\\"))
							programDirectory = programDirectory.substring(0,programDirectory.length()-1);
						if (classLoader != null){
							PathClassInfoLoader pil = new FileClassInfoLoader();
							pil.paths.addElement(programDirectory+"/classes");
							pil.paths.addElement(programDirectory);
							classLoader.classInfoLoaders.addElement(pil);
						}
					}else if (args[i].equals("/w"))
						{
						if (++i < count)
							try { mainWidth = Integer.parseInt(args[i]); }
							catch (Exception e)
								{
								e.printStackTrace();
								System.out.println("ERROR: bad width");
								}
						}
					else if (args[i].equals("/h"))
						{
						if (++i < count)
							try { mainHeight = Integer.parseInt(args[i]); }
							catch (Exception e)
								{
								System.out.println("ERROR: bad height");
								}
						}
					else if (args[i].equals("/color"))
						isColor = true;
					
					else if (args[i].equals("/l")){
						if (++i < count){
							String [] ll = mString.split(args[i],'-');
							if (ll.length >= 1) localLanguage = ll[0];
							if (ll.length >= 2) localCountry = ll[1];
						}
					}else if (args[i].equals("/R90")){
						Device.setScreenRotation(Device.ROTATION_90);
					}else if (args[i].equals("/R180")){
						Device.setScreenRotation(Device.ROTATION_180);
					}else if (args[i].equals("/R270")){
						Device.setScreenRotation(Device.ROTATION_270);
					}else if (args[i].equals("/i")){
						vmFlags |= Vm.VM_FLAG_SIP_DISABLED;
					}
				}			
			}
			//if (level > 0) return;
			programArguments = new String[count-i];
			for (int j = 0; j<programArguments.length; j++){
				programArguments[j] = args[i+j];
			}
		}finally{
			//Gui.resetFlags();
		}
	}
	public static boolean shouldUseFrame = true;
	int prW, prH;

	public java.awt.Dimension getPreferredSize()
	{
		return new java.awt.Dimension(prW,prH);
	}
	
	public void init()
	{
		
	}	
	boolean getBooleanParameter(String name)
	{
		String v = getParameter(name);
		if (v == null) return false;
		return v.toUpperCase().startsWith("T");
	}
	protected void myInit()
	{
		Hashtable h = new Hashtable();
		Hashtable sub = new Hashtable();
		h.put("HKEY_CLASSES_ROOT",sub);
		sub.put("One","Test!");
		Hashtable sub2 = new Hashtable();
		sub.put(".eve",sub2);
		sub2 = new Hashtable();
		sub.put("EveFile10",sub2);
		sub2 = new Hashtable();
		sub.put("abba",sub2);
		sub2 = new Hashtable();
		sub.put("zebra",sub2);
		IRegistryKey rk = new MapRegistryKey("Fake Registry",h);
		Registry.registries.put(Registry.REGISTRY_LOCAL,rk);
		shouldUseFrame = false;
		isTrueApplet = true;
		vmFlags |= Vm.VM_FLAG_IS_APPLET;
		setLayout(new java.awt.GridLayout(1,1));
		// NOTE: getParameter() and size() don't function in a
		// java applet constructor, so we need to call them here
		if (!isApplication){
			//boolean doLoad = applet == null;
			//if (doLoad) 
			loadResources();
			width = height = mainWidth = mainHeight = 0;
			shouldUseFrame = getBooleanParameter("useFrame");		
			title = getParameter("title");
			//mainWidth = getSize().width;
			//mainHeight = getSize().height;
			int nw = Convert.toInt(getParameter("frameWidth"));
			if (nw != 0) width = nw;
			int nh = Convert.toInt(getParameter("frameHeight"));
			if (nh != 0) height = nh;
			String pars = getParameter("commandLine");
			if (pars != null){
				processArgs(splitArgs(pars),0);
			}
			String cn = getParameter("appClass");
			if (cn != null) className = cn;
			if (className != null)
				className = className.replace('/','.');
			if (!shouldUseFrame) vmFlags |= Vm.VM_FLAG_NO_WINDOWS;
			//setSize(width,height);
			prW = width;
			prH = height;
			synchronized(uiLock){
				try{
					if (fileSystem == null){
						fileSystem = new FakeFileSystem();
						boolean added = false;
						try{
							if (!isApplication) currentApplet.showStatus("Applet loading virtual file system.");
							RandomStream s = Vm.openResourceAsRandomStream(getClass(),"_filesystem.zip");
							if (s != null){
								ZipFile zf = new ZipFile(s);
								System.out.println("Loading virtual file system.");
								eve.io.File zef = zf.getFileSystem(null);
								fileSystem.addVolume("Disk1",zef.getNew("/"));
								zf.close();
							}
						}catch(Throwable t){
							//t.printStackTrace();
						}
						try{
							if ((vmFlags & Vm.VM_FLAG_LOAD_FAKE_FILE) != 0)
								Vm.setFileSystem(fileSystem.getFile());
							else{
								java.io.File jf = new java.io.File("/");
								jf.canRead();
								jf = new java.io.File("C:\\");
								jf.canRead();
							}
							//System.out.println("Local file access allowed!");
						}catch(SecurityException e){
							//System.out.println("Local file access not allowed!");
							Vm.setFileSystem(fileSystem.getFile());
						}
					}
					// Load properties.
					try{
						BufferedReader br = new BufferedReader(new InputStreamReader(
								Vm.openResource(getClass(),"_properties.txt")
								));
						String full = "";
						while(true){
							String got = br.readLine();
							if (got == null) break;
							full += got.trim();
						}
						br.close();
						TextDecoder td = new TextDecoder(full);
						for (int i = 0; i<td.size(); i++){
							Vm.setProperty(td.getName(i),td.getValue(i));
						}
					}catch(Exception e){
						//System.out.println("No properties found!");
					}
				}catch(Throwable t){
					t.printStackTrace();
				}
			}
			if (!isApplication) currentApplet.showStatus("Continuing to load application...");
		}
		if (applet.className == null) {
			applet.className = "StartEve";
		}
		try{
			Vm.setProperty("vm.commands","Eve "+userCommands.toString());
		}catch(Throwable t){}
	}
	//
	private static boolean started = false;
	//
	ThreadGroup myThreads;
	
	
	public void start()
	{
		applet = currentApplet = this;
		myThreads = new ThreadGroup("Applet Threads");
		removeAll();
		//System.out.println("New arguments: "+mString.toString(applet.programArguments)+" == "+applet.className);
		new Thread(myThreads,"Main Thread"){
			public void run(){
				System.out.println("Starting...");
				if (!started) {
					myInit();
				}
				Vm.startEve(applet.programArguments,applet.className);
			}
		}.start();
	}
	public void stop()
	{
		try{
			myThreads.stop();
		}catch(Throwable t){
			t.printStackTrace();
		}
	}
	public void destroy()
	{
		Vm.exit(-1);
	}
	/**
	 * @param className
	 * @param args
	 * @return
	 */
	public static int startEve(String className,String[] args)
	{
		//
		return vmFlags;
	}
	public static PropertyList getAppletProperties()
	{
		if (!isTrueApplet) return null;
		//
		// FIXME - get applet properties.
		//
		if (applet == null) 
			throw new IllegalStateException("To run a Ewe application you must use the command line:\n\tjava -cp ewe.jar Ewe YourClassName\n");
		if (applet.isApplication) return null;
		PropertyList pl = new PropertyList();
		java.net.URL url = applet.getCodeBase();
		pl.set("applet",applet);
		pl.set("hostName",url.getHost());
		pl.set("hostPort",Convert.toString(url.getPort()));
		pl.set("codeBase",url.toString());
		pl.set("documentBase",mString.toString(applet.getDocumentBase()));
		return  pl;
	}
	public static boolean installSignalHandler(SignalHandler handler,int signal)
	{
		try{
			return Signals.setSignalHandler(handler, signal);
		}catch(Error e){
			e.printStackTrace();
			return false;
		}
	}
	
	//##################################################################
	class eveClassLoader extends mClassLoader{
	//##################################################################
	
	eveClassLoader()
	{
		mClassLoader mc = 
		new mClassLoader(){
			//-------------------------------------------------------------------
			public boolean getClassBytes(ClassInfo info)
			//-------------------------------------------------------------------
			{
				String look = info.fullPath.replace('.','/')+".class";
				byte [] got = null;
				for (int i = 0; i<eveFiles.size(); i++){
					EveFile ef = (EveFile)eveFiles.elementAt(i);
					try{
						got = ef.getFile(look);
						if (got == null) continue;
						if (ef.pool != null){
							ClassFile cf = new ClassFile(new ByteArray(got));
							got = cf.convertBack(ef.pool);
						}
						break;
					}catch(IOException e){
						e.printStackTrace();
						continue;
					}
				}				
				if (got == null) {
					if (info.fullPath.equals(className))
						vmFlags |= Vm.VM_FLAG_USING_CLASSES;
					return super.getClassBytes(info);
				}
				info.bytes = got;
				return true;
			}	
		};
		classInfoLoaders.addElement(mc);

	}
	//##################################################################
	}
	//##################################################################

eveClassLoader classLoader;
{
	try{
		classLoader = new eveClassLoader();
	}catch(Throwable t){}
}

//-------------------------------------------------------------------
void makeLoader()
//-------------------------------------------------------------------
{
	classLoader = new eveClassLoader();
}

//===================================================================
public static Class loadClass(String className)
//===================================================================
{
	try{
		Class c = Class.forName(className);
		if (c != null) return c;
		
	}catch(Throwable e){}
	if (applet.classLoader != null)
		return applet.classLoader.getClass(className);
	return null;
}

static void reInitialize()
{
	vmFlags = 0;
	Vm.setParameter(Vm.SIMULATE_SIP,0);
	SIPButton.initialize();
}
	public static void main(String[] args)
	{
		reInitialize();
		try{
			isTrueApplet = false;
			if (commandLine != null) args = commandLine;
			int count = args.length;
			boolean isColor = false;
			int width = 240;
			int height = 320;
			if (applet == null){
				applet = new EveApplet();
				applet.makeLoader();
			}
			applet.width = width;
			applet.height = height;
			applet.isApplication = true;
			if (args.length == 0) {
				try{
					InputStream in = Vm.openResource(null,"META-INF/CommandLine.txt");
					BufferedReader br = new BufferedReader(new InputStreamReader(in));
					String line = br.readLine();
					br.close();
					args = mString.splitCommand(line,false);
				}catch(IOException e){}
			}
			if (args.length == 0) args = new String[]{"StartEve"};//"eve.sys.Vm"};
			applet.processArgs(args,0);
			//
			// Here we would process and modify the arguments and
			// then return the new arguments in args.
			//
			
			/*
			String className = args[0];
			int copyFrom = 1;
			Vector v = new Vector();
			for (int i = copyFrom; i<args.length; i++)
				v.add(args[i]);
			int num = v.size();
			String[] na = new String[num];
			v.copyInto(na);
			*/
			//System.out.println("New arguments: "+mString.toString(applet.programArguments)+" == "+applet.className);
			if (applet.className == null) applet.className = "eve.sys.Vm";
			try{
				Vm.setProperty("vm.commands","Eve "+userCommands.toString());
			}catch(Throwable t){}
			loadFakeFile = (vmFlags & Vm.VM_FLAG_LOAD_FAKE_FILE) != 0;
			if (loadFakeFile){
				if (fileSystem == null){
					fileSystem = new FakeFileSystem();
					boolean added = false;
					try{
						RandomStream s = Vm.openResourceAsRandomStream(null,"_filesystem.zip");
						if (s != null){
							ZipFile zf = new ZipFile(s);
							eve.io.File zef = zf.getFileSystem(null);
							fileSystem.addVolume("Disk1",zef.getNew("/"));
							zf.close();
						}
					}catch(FileNotFoundException e){
						System.out.println("Warning: No _filesystem.zip found.");
					}
					Vm.setFileSystem(fileSystem.getFile());
				}
			}			
			Vm.startEve(applet.programArguments,applet.className);
		}catch(Throwable t){
			t.printStackTrace();
			//Application.startApplication(args);
			if (!isTrueApplet)
				messageBox("Error!",t.getClass().getName()+":\n"+t.getMessage(),Device.MB_TYPE_OK);
		}
		if (!isTrueApplet)
			System.exit(0);
	}
	private boolean wasShown = true;
	public boolean wasShown()
	{
		return wasShown;
	}

	public AppletContext getAppletContext()
	{
		try{
			return super.getAppletContext();
		}catch(Throwable t){
			return null;
		}
	}
	/* (non-Javadoc)
	 * @see eve.sys.Applet#appletResize(int, int)
	 */
	public void appletResize(int width, int height) {
		resize(width,height);
	}

	public void showDocument(URL url) {
		AppletContext c = getAppletContext();
		if (c != null) c.showDocument(url);
	}

	/* (non-Javadoc)
	 * @see eve.sys.Applet#showDocument(java.net.URL, java.lang.String)
	 */
	public void showDocument(URL url, String target) {
		AppletContext c = getAppletContext();
		if (c != null) c.showDocument(url,target);
	}

	/* (non-Javadoc)
	 * @see eve.sys.Applet#setStream(java.lang.String, java.io.InputStream)
	 */
	public void setStream(String key, InputStream stream) throws IOException {
		AppletContext c = getAppletContext();
		if (c != null) c.setStream(key,stream);
	}

	/* (non-Javadoc)
	 * @see eve.sys.Applet#getStream(java.lang.String)
	 */
	public InputStream getStream(String key) {
		AppletContext c = getAppletContext();
		if (c != null) return c.getStream(key);
		return null;
	}

	/* (non-Javadoc)
	 * @see eve.sys.Applet#getStreamKeys()
	 */
	public Iterator getStreamKeys() {
		AppletContext c = getAppletContext();
		if (c != null) return c.getStreamKeys();
		return new ObjectIterator(null);
	}
}
//####################################################
//##################################################################
class EveFile extends FileRandomStream{
//##################################################################

String myFileName;
String myEveName;
ClassFile.UtfPool pool;

//===================================================================
public EveFile(String name) throws java.io.IOException
//===================================================================
{
	super(name,"r");
	myFileName = name;
	myEveName = new java.io.File(name).getName();
	int idx = myEveName.lastIndexOf('/'); //Fix bug in MS Java
	if (idx != -1) myEveName = myEveName.substring(idx+1);
	idx = myEveName.lastIndexOf('\\'); //Fix bug in MS Java
	if (idx != -1) myEveName = myEveName.substring(idx+1);
	idx = myEveName.lastIndexOf('.');
	if (idx != -1) myEveName = myEveName.substring(0,idx);
	byte [] got = getFile("_UtfPool_");
	if (got != null) pool = new ClassFile.UtfPool(got);
}

//===================================================================
public byte [] getRunFile() throws IOException
//===================================================================
{
	return getFile(myEveName+".run");
}

byte [] buff = new byte[256];
public void readFully(byte[] dest, int offset, int length) throws IOException
{
	StreamUtils.readFully(this,dest,offset,length);
}
//-------------------------------------------------------------------
int readInt() throws IOException 
//-------------------------------------------------------------------
{
	readFully(buff,0,4);
	return Utils.readInt(buff,0,4);
}
//-------------------------------------------------------------------
int readShort() throws IOException
//-------------------------------------------------------------------
{
	readFully(buff,0,2);
	return Utils.readInt(buff,0,2);
}
//-------------------------------------------------------------------
int readInt(int where) throws IOException
//-------------------------------------------------------------------
{
	setPosition(where);
	return readInt();
}
//-------------------------------------------------------------------
int readShort(int where) throws IOException
//-------------------------------------------------------------------
{
	setPosition(where);
	return readShort();
}
char [] nameBuff = new char[256];
//===================================================================
public byte [] getFile(String name) throws IOException
//===================================================================
{
	int baseP = 0;
	int numRecs = readInt(baseP+4);
	if (numRecs == 0) return null;
	// NOTE: We do a binary search to find the class. So, a search
	// for N classes occurs in O(nlogn) time.
	int top = 0;
	int bot = numRecs;
	while(true){
		int mid = (bot + top) / 2;
		int offP = baseP + 8 + (mid * 4);
		int off = readInt(offP);
		int nextOff = readInt();
		int p = baseP + off;
		int nameLen = readShort(p); //This is the number of bytes representing the string.
		if (nameLen > buff.length) buff = new byte[nameLen];
		readFully(buff,0,nameLen);
		int checkLen = nameLen;
		while(checkLen > 0 && buff[checkLen-1] == 0) checkLen--;
		String inFile = Utils.decodeJavaUtf8String(buff,0,checkLen);
		int cmp = name.compareTo(inFile);
		if (cmp == 0){
			int size = nextOff - off - nameLen - 2;
			byte [] ret = new byte[size];
			readFully(ret,0,size);
			return ret;
		}
		if (mid == top)
			break; // not found
		if (cmp < 0)
			bot = mid;
		else
			top = mid;
		}
	return null;
}
//##################################################################
}
//##################################################################
