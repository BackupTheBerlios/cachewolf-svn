package eve.applet;
//#####################################################################
public class ClassInfo{
//#####################################################################
public String fullName;
public String fullPath;
public String directory;
public int size;
public ClassLoader loader;
public Class theClass;
public byte [] bytes;
public boolean isSystemClass;
public Throwable error;
//==================================================================
//public ClassInfo(){}
//==================================================================
//==================================================================
public ClassInfo(String n,ClassLoader l)
//==================================================================
{
	loader = l;
	fullPath = fullName = n;
}
//==================================================================
//#####################################################################
}
//#####################################################################

