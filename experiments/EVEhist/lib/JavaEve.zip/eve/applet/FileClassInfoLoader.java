package eve.applet;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;

//#####################################################################
public class FileClassInfoLoader extends PathClassInfoLoader{
//#####################################################################
/**
* 
*/
protected boolean 
//============================================================
  classExists(String fullPathName)
//============================================================
{
	File f = new File(fullPathName);
	return f.exists();
}
/**
* 
*/
protected boolean 
//============================================================
  getBytesFromPath(ClassInfo ci,String fullPathName)
//============================================================
{
	//System.out.println("getBytesFromPath(ci,"+fullPathName+");");
	try {
		File f = new File(fullPathName);
		//System.out.println(f+", "+f.exists());
		if (!f.exists()) return false;
		int len = (int)f.length();
		DataInputStream is = new DataInputStream(new FileInputStream(fullPathName));
		ci.bytes = new byte[len];
		is.readFully(ci.bytes);
		is.close();
	}catch(Exception e){
		if (ci.bytes == null) ci.error = e;
	}
	return (ci.bytes != null);
}

/**
*
*/
public static void main(String args[])
{
	mClassLoader cl = new mClassLoader();
	FileClassInfoLoader fci = new FileClassInfoLoader();
	fci.paths.addElement("c:/html/otherclasses");
	cl.classInfoLoaders.addElement(fci);
	Object obj = cl.getObject(args[0]);
	System.out.println("Got->"+obj);
}

//############################################################
}
//############################################################

