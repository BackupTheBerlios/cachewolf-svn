package eve.applet;
/**
* This interface is only to be used by a ClassLoader. The ClassInfo 
* returned by getClassInfo() need only contain the name of the class
* and the bytes for the class. Therefore the bytes may need to be
* defined into a Class. Only ClassLoaders can do this.
**/
//#####################################################################
public interface ClassInfoLoader{
//#####################################################################

//public ClassInfo getClassInfo(String fullClassName);
public boolean getClassBytes(ClassInfo ci);
//#####################################################################
}
//#####################################################################

