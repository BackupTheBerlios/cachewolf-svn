/*
 * Created on Mar 12, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import eve.fx.gui.WindowConstants;
import eve.sys.Handle;

/**
 * This class is used to display ProgressBars indicating the status
 * of a copy/delete operation as run by eve.io.FileClipboard.
 * <p>
 * After creating it call execute() to start the operation and to wait
 * until it has completed.
 * <p>
 * If the return value is Form.IDCANCEL, then the operation was aborted
 * by the user.
 * 
 * @author Michael L Brereton
 *
 */
//####################################################
public class FileClipboardProgress extends Form {
	
protected Handle[] h;

	public FileClipboardProgress(Handle deleteHandle, String title)
	{
		this(new Handle[]{deleteHandle},title);
	}

	public FileClipboardProgress(Handle[] copyMoveHandles, String title)
	{
		h = copyMoveHandles;
		this.title = title;
		Form f = this;
		f.windowFlagsToClear |= WindowConstants.FLAG_HAS_CLOSE_BUTTON;
		f.addLast(new Label("Operation Progress"));
		ProgressBar pb = new ProgressBar();
		f.addLast(pb);
		pb.monitor(h[0]);
		if (h.length > 1){
			f.addLast(new Label("File Progress"));
			pb = new ProgressBar();
			f.addLast(pb);
			pb.monitor(h[1]);
		}
		f.setPreferredSize(300,-1);
		f.doButtons(f.CANCELB);
	}
	
	public boolean canExit(int ex){
		h[0].stop(0);
		return true;
	}
	private boolean started = false;
	/**
	 * Use this instead of Execute.
	 * @return
	 */
	public void shown()
	{
		super.shown();
		synchronized(this){
			if (started) return;
			started = true;
		}
		new Thread(){
			public void run(){
				h[0].start();
				h[0].waitUntilCompletion();
				exit(IDOK);
			}
		}.start();
	}

}

//####################################################
