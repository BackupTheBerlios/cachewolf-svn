/*
 * Created on Mar 28, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import java.util.Iterator;

import eve.util.IteratorEnumerator;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class ControlIterator extends IteratorEnumerator {

	private Control current;
	private final static int MODE_FORWARDS = 0;
	private final static int MODE_BACKWARDS = 1;
	private final static int MODE_SINGLE = 2;
	private int mode;
	private Iterator myIt;
	/*
	public ControlIterator(Control first,boolean backwards)
	{
		current = first;	
		back = backwards;
	}
	*/
	//{new Exception().printStackTrace();}	
	public boolean hasNext() 
	{
		if (current != null) return true;
		if (myIt != null && myIt.hasNext()) return true;
		myIt = null;
		return false;
	}
	public Object next() 
	{
		Control c = current;
		current = null;
		if (c != null){
			if (mode != MODE_SINGLE) {
				current = mode == MODE_BACKWARDS ? c.prev : c.next; 
			}
			return c;
		}
		if (myIt != null){
			Object ret = myIt.next();
			if (!myIt.hasNext()) myIt = null;
			return ret;
		}
		return null;
	}

	public ControlIterator setFor(Iterator it)
	{
		setForNone();
		if (it != null && it.hasNext())
			myIt = it;
		return this;
	}
	public ControlIterator setForNone()
	{
		myIt = null;
		current = null;
		mode = MODE_SINGLE;
		return this;
	}
	public ControlIterator setForSingleControl(Control who)
	{
		setForNone();
		current = who;
		return this;
	}
	public ControlIterator setFor(Control parent, boolean backwards)
	{
		setForNone();
		if (parent != null) current = backwards ? parent.tail : parent.children;
		mode = backwards ? MODE_BACKWARDS : MODE_FORWARDS;
		return this;
	}
	public static ControlIterator unNull(ControlIterator provided)
	{
		if (provided != null) return provided;
		return new ControlIterator();
	}
	public void cached()
	{
		current = null;
	}
	/**
	 * 
	 */
	public ControlIterator() {
		super();
	}

}

//####################################################
