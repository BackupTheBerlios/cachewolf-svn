package eve.ui;
import eve.fx.Color;
import eve.fx.Dimension;
import eve.fx.FontMetrics;
import eve.fx.Graphics;
import eve.fx.IImage;
import eve.fx.ImageCache;
import eve.fx.Metrics;
import eve.fx.Pen;
import eve.fx.Point;
import eve.fx.Rect;
import eve.util.Booleanable;
import eve.util.CharArray;
import eve.util.mString;

//##################################################################
public class CheckBox extends ButtonControl implements Booleanable{
//##################################################################

{
	modify(PreferredSizeOnly|HasData,0);
	//defaultAddMeCellConstraints = mPanel.DontStretch;
	//defaultAddMeControlConstraints = mPanel.DontFill;
	//defaultAddMeAnchor = mPanel.NorthWest;
	borderStyle = BDR_NOBORDER;
}
/**
 * Set this true to disable blinking of the Checkbox when it gets the keyboard focus.
 */
public boolean dontBlink = false;

//==================================================================
public CheckBoxGroup group;
//==================================================================
public CheckBox(){this("");}
//===================================================================
public CheckBox(String txt) 
//===================================================================
{
	if (txt == null) txt = "";
	text = Gui.getTextFrom(txt);
	setHotKey(0,Gui.getHotKeyFrom(txt));
}
//==================================================================
/**
 * This is the default width of the box. By default it is 16.
 */
public static int defaultBoxWidth = isDoubleSized() ? 20 : 16;
/**
 * If this is true a checkbox will draw an 'x' instead of a tick.
 */
public static boolean defaultUseCross = false;
/**
 * This width of the box - this is initialized to defaultBoxWidth.
 */
public int boxWidth = defaultBoxWidth;
/**
 * If this is true the checkbox will draw an 'x' instead of a tick. It is
 * initialized to defaultUseCross;
 */
public boolean useCross = defaultUseCross;

private Object blinkId = null;

boolean cursorOn = false;
//===================================================================
public void gotFocus(int how)
//===================================================================
{
	cursorOn = false;
	if (Gui.useNativeTextInput){
		cursorOn = !dontBlink;
	}else if (how == ByKeyboard){
		if (!dontBlink){
			cursorOn = true;
			repaintDataNow();
			blinkId = Window.requestCursorBlink(this,500);
		}
	}
	super.gotFocus(how);
}
//===================================================================
public void lostFocus(int how)
//===================================================================
{
	blinkId = null;
	if (cursorOn) {
		cursorOn = false;
		repaintDataNow();
	}
	super.lostFocus(how);
}
//===================================================================
public void penPressed(Point p) 
//===================================================================
{
	blinkId = null;
	if (cursorOn) cursorOn = false;
	super.penPressed(p);
}
//===================================================================
public void ticked(Object id,long elapsed)
//===================================================================
{
	//System.out.println(elapsed);
	if (blinkId == id){
		cursorOn = !cursorOn;
		if (!tipIsDisplayed()) repaintDataNow();
		blinkId = Window.requestCursorBlink(this,500);
	}else 
		super.ticked(id,elapsed);
}

//==================================================================
protected void calculateSizes()
//==================================================================
{
	//if (isExclusive()) boxWidth = 15;
	Dimension r = Dimension.getCached(0,0); 
	Metrics.getSize(getFontMetrics(),text,4,2,r);
	boolean noText = mString.toString(text).length() == 0;
	if (noText) r.set(0,0);
	preferredWidth = r.width+boxWidth+(noText ? 0 : 2);
	preferredHeight = r.height;
	if (preferredHeight < boxWidth) preferredHeight = boxWidth;
	r.cache();
}
//==================================================================
public boolean isExclusive()
//==================================================================
{
	//group = new CheckBoxGroup();
	if (group == null) return false;
	return group.exclusive;
}
//==================================================================
public void doPaint(Graphics g,Rect area)
//==================================================================
{
	int flags = getModifiers(true);
	if (!((flags & Invisible) == 0)) return;
	int w = width, h = height;
	doBackground(g);
	g.setColor(Color.Black);
	if (!(((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0))) g.setColor(Color.DarkGray);
	FontMetrics fm = getFontMetrics();
	g.setFont(fm.getFont());
	CharArray ca = makeHot(text,(CharArray)getCached(CharArray.class)); 
	g.drawText(ca.data,0,ca.length,boxWidth+4,(h-fm.getHeight())/2);
	cache(ca);
	if (text.length() == 0) borderStyle &= ~BDR_DOTTED;
	synchronized(Rect.gBuffer1){
		g.draw3DRect(getDim(Rect.gBuffer1),borderStyle,true,null,null);
	}
	if (!isExclusive()) doPaintSquare(g);
	else doPaintCircle(g);//doPaintDiamond(g);
}
//==================================================================
protected void doPaintData(Graphics g)
//==================================================================
{
	synchronized(this){
		int got = modify(PaintDataOnly,0);
		if (!isExclusive()) doPaintSquare(g);
		else doPaintCircle(g);//doPaintDiamond(g);
		restore(got,PaintDataOnly);
	}
}
private static IImage smallCheck, bigCheck, smallRoundCheck, bigRoundCheck, smallRoundBox, bigRoundBox;
private static void checkImages()
{
	if (smallCheck == null) {
		// Don't call load image - don't want double sized.
		smallCheck = ImageCache.cache.tryImage("eve/check12.png",null);
		bigCheck = ImageCache.cache.tryImage("eve/check16.png",null);
		smallRoundCheck = ImageCache.cache.tryImage("eve/roundcheck9.png",null);
		bigRoundCheck = ImageCache.cache.tryImage("eve/roundcheck16.png",null);
		smallRoundBox = ImageCache.cache.tryImage("eve/roundbox15.png",null);
		bigRoundBox = ImageCache.cache.tryImage("eve/roundbox20.png",null);
	}
}
//==================================================================
public void doPaintSquare(Graphics g)
//==================================================================
{
	int flags = getModifiers(true);
	int myFlag = getModifiers(false);
	int w = width, h = height;
	g.setColor(Color.White);
	boolean en = (((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0));
	boolean ed = (((flags & (NotEditable|DisplayOnly)) == 0) || ((flags & NotAnEditor) != 0));
	if (!en || !ed) g.setColor(Color.LightGray);
	else if (cursorOn) g.setColor(Gui.useNativeTextInput ? Color.LightGreen : Color.LightGray);
	int sp = 2*boxWidth/15; 
	int bx = text.length() == 0 ? 0 : sp;
	int by = text.length() == 0 ? 0 : (h-boxWidth)/sp+1;
	g.fillRect(bx+2,by+2,boxWidth-2*2,boxWidth-2*2);
	if (state || pressState){
		Color c = Color.LightGray;
		if (!pressState){
			if (!state) 
				if (en && ed) c = Color.White;
				else c = Color.LightGray;
			else 
				if (en) c = Color.Black;
				else c = Color.DarkGray;
		}
		Pen oldPen = g.getPen(Pen.getCached()); 
		g.changePen(c,Pen.SOLID,sp);
		//g.drawLine(bx+4,by+4,bx+bw-5,by+bw-5);
		int io = 0;
		if (c != Color.Black) io = IImage.DISABLED;
		if (c == Color.White) io = -1;
		if (useCross){
			g.drawLine(bx+sp+1,by+sp+1,bx+boxWidth-sp*2-1,by+boxWidth-sp*2-1);
			g.drawLine(bx+sp+1,by+boxWidth-sp*2-1,bx+boxWidth-sp*2-1,by+sp+1);
			
		}else{
			if (smallCheck == null) checkImages();
			IImage use = boxWidth < 19 ? smallCheck : bigCheck; 
			if (use != null){
				if (io != -1) use.draw(g,bx+2,by+2,io);
			}else{
				g.drawLine(bx+sp+2,by+boxWidth-sp-3,bx+boxWidth-(sp+3),by+sp+2);
				g.drawLine(bx+sp+2,by+boxWidth-sp-3,bx+sp+2,by+boxWidth-(sp+3)*2);
			}
		}
		g.set(oldPen);
		oldPen.cache();
	}
	if ((myFlag & PaintDataOnly) == 0)
		synchronized(Rect.gBuffer1){
			g.draw3DRect(
				Rect.gBuffer1.set(bx,by,boxWidth,boxWidth),
				GuiStyle.checkboxEdge,
				(flags & DrawFlat) != 0,
				null,
				Color.DarkGray);
			}

}
//==================================================================
public void doPaintCircle(Graphics g)
//==================================================================
{
	int flags = getModifiers(true);
	int myFlag = getModifiers(false);
	int w = width, h = height;
	Color back = Color.White;
	Color forgnd = Color.Black;
	if (!(((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0)) || !(((flags & (NotEditable|DisplayOnly)) == 0) || ((flags & NotAnEditor) != 0))) back = Color.LightGray;
	if (cursorOn) back = Color.LightGray;
	if (!((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0)) forgnd = Color.DarkGray;
	int bx = 1;
	int by = (h-boxWidth)/2+1;
	if (smallCheck == null) checkImages();
	if (true){
		IImage use = boxWidth < 19 ? smallRoundBox : bigRoundBox; 
		if (use != null)
			use.draw(g,bx,by,0);
		else{
			g.setColor(back);
			g.fillEllipse(bx+1,by+1,boxWidth-3,boxWidth-3);
			if ((flags & DrawFlat) != 0 || true){
				g.setColor((GuiStyle.standardEdge & EDGE_ETCHED) == EDGE_ETCHED ? Color.DarkGray : forgnd);
				g.drawEllipse(bx,by,boxWidth-1,boxWidth-1);
			}else if ((GuiStyle.standardEdge & EDGE_ETCHED) == EDGE_ETCHED){
				g.setColor(Color.DarkGray);
				g.drawArc(bx,by,boxWidth-1,boxWidth-1,30,180);
				g.setColor(Color.White);
				g.drawArc(bx+1,by+1,boxWidth-3,boxWidth-3,30,180);
				g.setColor(Color.White);
				g.drawArc(bx,by,boxWidth-1,boxWidth-1,211,180);
				g.setColor(Color.DarkGray);
				g.drawArc(bx+1,by+1,boxWidth-3,boxWidth-3,211,180);
			}else{
				g.setColor(forgnd);
				g.drawArc(bx,by,boxWidth-1,boxWidth-1,30,180);
				g.setColor(Color.DarkGray);
				g.drawArc(bx+1,by+1,boxWidth-3,boxWidth-3,30,180);
				g.setColor(Color.White);
				g.drawArc(bx,by,boxWidth-1,boxWidth-1,210,180);
				g.setColor(Color.LightGray);
				g.drawArc(bx+1,by+1,boxWidth-3,boxWidth-3,210,180);
			}
		}
	}else{
	}
	if (pressState || state || ((myFlag & PaintDataOnly) != 0)){
		Color c = Color.LightGray;
		if (!pressState){
			g.setColor(back);
			if (!state) 
				if ((((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0))) c = back;
				else c = Color.LightGray;
			else 
				if ((((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0))) c = Color.Black;
				else c = Color.DarkGray;
		}
		g.setColor(c);
		//g.drawLine(bx+4,by+4,bx+bw-5,by+bw-5);
		int io = 0;
		if (c != Color.Black) io = IImage.DISABLED;
		if (c == Color.White) io = -1;
		int sp = 0;
		if (boxWidth >= 20) sp = -1;
		IImage use = boxWidth < 19 ? smallRoundCheck : bigRoundCheck; 
		if (use != null){
			if (io != -1) use.draw(g,bx+3+sp,by+3+sp,io);
		}else{
			g.fillEllipse(bx+3+sp,by+3+sp,boxWidth-7-(2*sp),boxWidth-7-(2*sp));
		}
	}
}

//==================================================================
public void doPaintDiamond(Graphics g)
//==================================================================
{
	int flags = getModifiers(true);
	int w = width, h = height;
	Color back = Color.White;
	if (!(((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0)) || !(((flags & (NotEditable|DisplayOnly)) == 0) || ((flags & NotAnEditor) != 0))) back = Color.LightGray;
	int bx = 0;
	int by = (h-boxWidth)/2;
	Rect _rect;
	g.draw3DDiamond(_rect = new Rect(bx,by,boxWidth,boxWidth),true,back,((flags & DrawFlat) != 0));
	g.setColor(Color.LightGray);
	if (!pressState){
		if (!state) 
			if ((((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0))) g.setColor(Color.White);
			else g.setColor(Color.LightGray);
		else 
			if ((((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0))) g.setColor(Color.Black);
			else g.setColor(Color.DarkGray);
	}
	x += 3; y += 3; width-=6; height-=6;
	g.drawDiamond(_rect,All);
}
//==================================================================
public boolean getState() {return state;}
public void setState(boolean to)
//==================================================================
{
	if (to == state) return;
	if (to == true)
 		if (isExclusive()){
			CheckBox cb = group.getSelected();
			if (cb != null) {
				cb.setState(false);
				cb.notifyDataChange();
			}
		}
	state = to;
	repaintDataNow();
}
//==================================================================
public void doAction(int how)
//==================================================================
{
	if (isExclusive() && state == true) return;
	setState(!state);
	//super.doAction(how);
}
/**
 * Add this CheckBox to the CheckBoxGroup and return this CheckBox.
 * @param cbg the Group to add to.
 * @return this CheckBox.
 */
//==================================================================
public CheckBox setGroup(CheckBoxGroup cbg)
//==================================================================
{
	cbg.add(this);
	group = cbg;
	addListener(group);
	return this;
}

//==================================================================
public void setText(String text) {super.setText(text); repaintNow();}
//==================================================================
//===================================================================
public void notifyAction()
//===================================================================
{
	super.notifyAction();
	super.notifyDataChange();
}


//##################################################################
}
//##################################################################

