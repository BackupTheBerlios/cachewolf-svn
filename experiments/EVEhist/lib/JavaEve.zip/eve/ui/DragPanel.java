/*
 * Created on Aug 13, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import eve.fx.Graphics;
import eve.fx.IImage;
import eve.fx.Image;
import eve.fx.Point;
import eve.fx.Rect;
import eve.fx.Sound;
import eve.fx.gui.WindowSurface;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class DragPanel extends CellPanel {

	{
		modify(WantDrag,0);
		//backGround = Color.Black;
	}


	public boolean canDrag = true;
	public boolean isTopBar = true;
	
	Image dragImage;
	Point last;
	Point start;
//	==================================================================
	public void calculateSizes()
//	==================================================================
	{
		super.calculateSizes();
		if (preferredWidth < 4) preferredWidth = 6;
		if (preferredHeight < 4) preferredHeight = 6;
	}
//	==================================================================
	public void penPressed(Point where)
//	==================================================================
	{
		super.penPressed(where);
	}
//	==================================================================
	public void startDragging(DragContext dc)
//	==================================================================
	{
		if (!canDrag) return;
		if (Gui.isWindowFrame(getFrame())){
			WindowSurface ws = (WindowSurface) getWindow().getSurface();
			if (ws != null)
				if (ws.specialOperation(isTopBar ? Window.SPECIAL_MOUSE_MOVE:Window.SPECIAL_MOUSE_RESIZE,null)){
					firstPress = true;
					return;
				}
		}
		if (isTopBar) {
			Rect r = getDim(null);
			dragImage = new Image(r.width,r.height);
			Graphics g = new Graphics(dragImage);
			repaintNow(g,r);
			g.draw3DRect(r,EDGE_BUMP,false,null,null);
			g.free();
			dc.startImageDrag(dragImage,new Point().set(dc.curPoint),this);
		}else {
			IImage mi = loadImage("eve/ResizeFrame.png");
			dc.startImageDrag(mi,new Point(5,5),this);
		}
	}
//	==================================================================
	public void dragged(DragContext dc)
//	==================================================================
	{
		if (!canDrag||Gui.isWindowFrame(getFrame())) return;
		dc.imageDrag();
	}
//	==================================================================
	public void stopDragging(DragContext dc)
//	==================================================================
	{
		if (!canDrag||Gui.isWindowFrame(getFrame())) return;
		dc.stopImageDrag(false);
		Frame f = getFrame();
		if (f == null) return;
		Rect r = f.getRect();
		if (isTopBar) {
			int dx = dc.getImageDrag().relativeImagePos.x;
			int dy = dc.getImageDrag().relativeImagePos.y;
			Gui.moveFrameTo(f,new Rect(r.x+dx,r.y+dy,r.width,r.height));
		}else{
			Rect ar = Gui.getAppRect(this);
			int tx = ar.x+dc.curPoint.x+5;
			int ty = ar.y+dc.curPoint.y+5;
			ar = Gui.getAppRect(f);
			if (tx <= ar.x || ty <= ar.y) {
				Sound.beep();
				return;
			}
			//f.setRect(r.x,r.y,tx-ar.x,ty-ar.y);
			Gui.moveFrameTo(f,new Rect(r.x,r.y,tx-ar.x,ty-ar.y));
		}
	}
	
}

//####################################################
