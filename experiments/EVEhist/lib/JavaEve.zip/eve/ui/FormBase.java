/*
 * Created on Aug 13, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import eve.fx.IImage;
import eve.fx.ImageTool;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class FormBase extends CellPanel {


	/**
	* This is set to Gui.CENTER_FRAME by default.
	**/
	//public static int defaultShowOptions = Gui.CENTER_FRAME;//Gui.NEW_WINDOW;
	private static int dis = Control.isDoubleSized() ? 20 : 10;
	/**
	* The tick icon.
	**/
	public static IImage tick;
	/**
	* The cross (X) icon - colored Red.
	**/
	public static IImage cross;
	/**
	* The close (X) icon - colored Black.
	**/
	public static IImage close = //new DrawnIcon(DrawnIcon.CROSS,dis,dis,new Color(0,0,0));
	loadImage("eve/cross16.png");
	
	static {
		try{
			tick = loadImage("eve/accept.png");
		}catch(Exception e){
			tick = ImageTool.changeColor(loadImage("eve/tick16.png"),0xff000000,0xff008000);
			//new DrawnIcon(DrawnIcon.TICK,dis,dis,new Color(0,128,0));
		}
		try{
			cross = loadImage("eve/cancel.png");
		}catch(Exception e){
			cross = ImageTool.changeColor(loadImage("eve/cross16.png"),0xff000000,0xff800000);
			//new DrawnIcon(DrawnIcon.CROSS,dis,dis,new Color(128,0,0));
		}
		
	}
	/**
	* The tool icon - supposed to look like a spanner.
	**/
	public static IImage tools = loadImage("eve/SmallConfig.png");
	/**
	* The stop icon.
	**/
	public static IImage stop = loadImage("eve/Stop.png");
	/**
	* A predefined return value from the Form - it is the same as IDOK.
	**/
	public static final int IDYES = 1;
	/**
	* A predefined return value from the Form - it is the same as IDYES.
	**/
	public static final int IDOK = 1;
	/**
	* A predefined return value from the Form.
	**/
	public static final int IDNO = 2;
	/**
	* A predefined return value from the Form.
	**/
	public static final int IDBACK = 3;
	/**
	* A predefined return value from the Form.
	**/
	public static final int IDCANCEL = -1;
//	public static final int IDTIMEDOUT = -2;
	/**
	* An option for doButtons()
	**/
	public static final int YESB = 0x1;
	/**
	* An option for doButtons()
	**/
	public static final int NOB = 0x2;
	/**
	* An option for doButtons()
	**/
	public static final int CANCELB = 0x4;
	/**
	* An option for doButtons()
	**/
	public static final int OKB = 0x8;
	/**
	* An option for doButtons()
	**/
	public static final int BACKB = 0x10;
	/**
	* This is an OK button that has ENTER assigned as the hotkey.
	**/
	public static final int DEFOKB = 0x20;
	/**
	* This is an OK button that has ESC/CANCEL assigned as the hotkey.
	**/
	public static final int DEFCANCELB = 0x40;
	/*
	public static final int BADOKB = 0x10;
	public static final int APPLYB = 0x20;
	public static final int RESETB = 0x40;
	public static final int DEFAULTB = 0x80;
	public static final int CLOSEB = 0x100;
	*/
	/**
	* A MessageBox type.
	**/
	public static final int MBB = 0x1000;
	/**
	* A MessageBox type.
	**/
	public static final int MBYESNO = MBB|YESB|NOB;
	/**
	* A MessageBox type.
	**/
	public static final int MBYESNOCANCEL = MBB|YESB|NOB|DEFCANCELB;
	/**
	* A MessageBox type.
	**/
	public static final int MBOK = MBB|DEFOKB;
//	public static final int MBBADOK = MBB|BADOKB;
	/**
	* A MessageBox type.
	**/
	public static final int MBOKCANCEL = MBB|DEFOKB|DEFCANCELB;
	/**
	* A MessageBox type.
	**/
	public static final int MBNONE = MBB;
	/**
	A standard Form action string.
	**/
	public static final String EXIT_IDCANCEL = "EXIT_IDCANCEL";
	/**
	A standard Form action string.
	**/
	public static final String EXIT_IDOK = "EXIT_IDOK";
	/**
	A standard Form action string.
	**/
	public static final String EXIT_IDYES = "EXIT_IDYES";
	/**
	A standard Form action string.
	**/
	public static final String EXIT_IDNO = "EXIT_IDNO";
	/**
	A standard Form action string.
	**/
	public static final String EXIT_IDBACK = "EXIT_IDBACK";


}

//####################################################
