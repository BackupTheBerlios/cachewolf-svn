package eve.ui;
import eve.fx.Color;
import eve.fx.Dimension;
import eve.fx.Graphics;
import eve.fx.IImage;
import eve.fx.IconAndText;
import eve.fx.Rect;


//##################################################################
public class Button extends ButtonControl implements Actionable{
//##################################################################
/**
* The position of the text relative to any image. Should be
* Graphics.Up or Graphics.Down
**/
public int textPosition = Graphics.Up;
/**
* If this is set, then the inside will be filled with this color.
**/
public Color insideColor = null;
private Color oldBackground;
private boolean switched = false;

/**
An optional action label for the button. When the button generates a ControlEvent.PRESSED event
this value will be placed in the action value of the event. If this is null, then the text of the
button is put instead.
**/
public String action;
public void setAction(String action)
{
	this.action = action;
}
public String getAction()
{
	return action;
}
/*
* The direction of any arrow. If it is zero there is no arrow.
**/
//===================================================================
public void gotFocus(int how)
//===================================================================
{
	if (Gui.useNativeTextInput && !switched){
			switched = true;
			oldBackground = insideColor;
			insideColor = Color.LightGreen;
	}
	super.gotFocus(how);
}
//===================================================================
public void lostFocus(int how)
//===================================================================
{
	if (switched){
		insideColor = oldBackground;
		switched = false;
	}
	super.lostFocus(how);
}

{
	borderWidth = 1;
	startDragResolution = 10;
}
//==================================================================
public Button(){this("");}
public Button(IImage image) {text = ""; this.image = image;}
public Button(String txt) 
{
	if (txt == null) txt = "";
	text = Gui.getTextFrom(txt);
	setHotKey(0,Gui.getHotKeyFrom(txt));
}

/**
* This creates an Button using the ImageCache to load an icon for the button.
* Note that this produces an IconAndText image for the button where the text is always
* to the right of the button.
**/
//===================================================================
public Button(String text,String imageName)
//===================================================================
{
	image = loadImage(imageName);
	if (text != null) {
		setHotKey(0,Gui.getHotKeyFrom(text));
		image = new IconAndText(image,makeHot(Gui.getTextFrom(text),null).toString(),null);
		((IconAndText)image).textColor = null;
	}
}
//-------------------------------------------------------------------
protected void calculateSizes()
//-------------------------------------------------------------------
{
	ButtonObject buttonObject = ButtonObject.getCached(this);
	Dimension d = buttonObject.calculateSize(getCachedDim());
	preferredWidth = d.width;
	preferredHeight = d.height;
	buttonObject.cache();
	cache(d);
}
//==================================================================
public static Color getImageColor(Color fore,Color back,boolean isEnabled,boolean flat,boolean pressState)
//==================================================================
{
	if (!isEnabled) return Color.DarkGray;
	if (!pressState || !flat) return fore;
	return back;
}
//==================================================================
public Color getImageColor()
//==================================================================
{
	int flags = getModifiers(true);
	return getImageColor(getForeground(),getBackground(),((((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0)) && (((flags & (NotEditable|DisplayOnly)) == 0) || ((flags & NotAnEditor) != 0))),((flags & DrawFlat) != 0),pressState);
}
//==================================================================
public void doPaint(Graphics g,Rect area)
//==================================================================
{
	int flags = getModifiers(true);
	if (!((flags & Invisible) == 0)) return;
	
	ButtonObject buttonObject = ButtonObject.getCached(this);
	buttonObject.paint(g);
	buttonObject.cache();
}
protected boolean showHoldDownIndicator(int x, int y)
{
	return false;
}
//##################################################################
}
//##################################################################



