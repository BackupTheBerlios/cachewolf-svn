package eve.ui;
import eve.data.DateTimeUtils;
import eve.data.IDate;
import eve.data.ITime;
import eve.data.PlainDate;
import eve.data.PlainTime;
import eve.data.Value;
import eve.sys.DayOfYear;
import eve.sys.Locale;
import eve.sys.Time;
import eve.sys.TimeOfDay;
import eve.util.Timeable;

//##################################################################
public class DateTimeInput extends TextDisplayButton implements Timeable, IDate, ITime{
//##################################################################
{
	setMenu(getClipboardMenu(null));
	setTextSize(30,1);
}
/**
 * The Locale associated with this input.
 */
public Locale locale = new Locale();
/**
 * The Popup Form attached to this input. You do not need to use this.
 */
//public ControlPopupForm attachedTo;
/**
* Set this false if you only want simple single line input for the date/time.
**/
public boolean useFullPopup = true;

private boolean is24hours = false;
private boolean showSeconds = false;
private boolean isTime = false;
private boolean showCalendar = true;//false;
private ControlPopupForm popup = null;
private String format = null;

//-------------------------------------------------------------------
protected static String getTimeFormatFor(boolean showSeconds, boolean is24hours)
//-------------------------------------------------------------------
{
	String format = is24hours ? "HH:mm" : "h:mm";
	if (showSeconds) format += ":ss";
	if (!is24hours) format += " tt";
	return format;
}

//===================================================================
public String getFormat()
//===================================================================
{
	if (format != null) return format;
	if (isTime) return getTimeFormatFor(showSeconds, is24hours);
	else return "d-MMM-yyyy";
}

//===================================================================
public DateTimeInput()
//===================================================================
{
	this(false);
}
//===================================================================
public DateTimeInput(boolean isTime)
//===================================================================
{
	this.isTime = isTime;
	if (isTime) setTimeFormat(false,false);
	else setDateFormat("d-MMM-yyyy");
	setTime(this.time);
}
//===================================================================
public void setShowCalendar(boolean showCalendar)
//===================================================================
{
	this.showCalendar = showCalendar;
	ControlPopupForm p2 = DateUpDownInput.getPopup(showCalendar);
	if (p2 != popup){
		if (popup != null) popup.detachFrom(this);
		popup = p2;
		popup.attachTo(this);
	}
}
/**
 * Set the date format string. This marks the input as being a date input rather than a
 * time input.
 * @param dateFormat the new date format.
 */
//===================================================================
public void setDateFormat(String dateFormat)
//===================================================================
{
	isTime = false;
	format = dateFormat;
	setShowCalendar(showCalendar);
	setTime(time);
}
/**
 * Set the format for display/input of a Time of day value.
 * @param is24hours show 24 hour time.
 * @param showSeconds show the seconds value.
 */
//===================================================================
public void setTimeFormat(boolean showSeconds,boolean is24hours)
//===================================================================
{
	isTime = true;
	this.is24hours = is24hours;
	this.showSeconds = showSeconds;
	format = getTimeFormatFor(showSeconds,is24hours);
	ControlPopupForm p2 = TimeUpDownInput.getPopup(showSeconds,is24hours);
	if (p2 != popup){
		if (popup != null) popup.detachFrom(this);
		popup = p2;
		popup.attachTo(this);
	}
	setTime(time);
}
/**
* This variable holds the time value being displayed/edited. You can change
* the format of it and the format of the display will also change.
**/
//===================================================================
public Time time = new Time();
//===================================================================

//-------------------------------------------------------------------
protected void calculateSizes()
//-------------------------------------------------------------------
{
	text = time.toString(locale)+"      ";
	super.calculateSizes();
	text = time.toString(locale);
}
/**
 * Set the date. Value must be a Time object value.
 */
//===================================================================
public void setValue(Value value)
//===================================================================
{
	if (value instanceof Time) setTime((Time)value);
	else{
		if (value instanceof IDate) DateTimeUtils.transferDate((IDate)value,this);
		if (value instanceof ITime) DateTimeUtils.transferTime((ITime)value,this);
	}
}
/**
 * Get the date. Value must be a Time object value.
 */
//===================================================================
public void getValue(Value value)
//===================================================================
{
	if (value instanceof Time) getTime((Time)value);
	else{
		if (value instanceof IDate) DateTimeUtils.transferDate(this,(IDate)value);
		if (value instanceof ITime) DateTimeUtils.transferTime(this,(ITime)value);
	}
}
private void updateMe()
{
	if (time instanceof TimeOfDay && !isTime)
		setTimeFormat(showSeconds,is24hours);
	else if (time instanceof DayOfYear && isTime)
		setDateFormat("d-MMM-yyyy");
	this.time.format = getFormat();
	//this.time.setTime(time.getTime());
	text = this.time.toString(locale);
	repaintNow();
}
/**
 * Set the time.
 */
//===================================================================
public void setTime(Time time)
//===================================================================
{
	if (time == null) return;
	//ewe.sys.Vm.debug("Time value: "+time.getClass());
	this.time = (Time)time.getCopy();
	updateMe();
}
public void setTime(int hour, int minute, int second, int millis)
{
	//if (!isTime) return;
	//isTime = true;
	this.time = new TimeOfDay(hour,minute,second);
	updateMe();
}
public void setDate(int day, int month, int year)
{
	//if (isTime) return;
	this.time = new DayOfYear(day,month,year);
	updateMe();
}
/**
 * Get the time.
 * @param dest an optional destination Time object.
 * @return the destination Time object, or a new one if dest is null.
 */
//===================================================================
public Time getTime(Time dest)
//===================================================================
{
	if (dest == null) return (Time)time.getCopy();//dest = new Time();
	//dest.setTime(this.time.getTime());
	if (isTime)
		dest.setTimeOfDay(this.time);
	else
		dest.setDayOfYear(this.time);
	return dest;
}
/*
//===================================================================
public void doPaint(Graphics g,Rect area)
//===================================================================
{
	text = time.toString(locale);
	super.doPaint(g,area);
}
*/
//===================================================================
public boolean acceptsData(Object data,DragContext how)
//===================================================================
{
	if (!canEdit()) return false;
	if (data instanceof Time) return true;
	Object s = toTextData(data);
	return s instanceof String;
}
//===================================================================
public boolean takeData(Object data,DragContext how)
//===================================================================
{
	if (data instanceof Time){
		if (((Time)data).isValid()) {
			setTime((Time)data);
			//time.copyFrom((Time)data);
			//return true;
		}
	}else if ((data = toTextData(data)) instanceof String){
		Time t2 = new Time();
		t2.format = getFormat();
		t2.fromString(data.toString());
		if (t2.isValid()) {
			setTime(t2);
			//time.copyFrom(t2);
			//return true;
		}
	}
	return false;
}
//-------------------------------------------------------------------
protected Object getDataToCopy()
//-------------------------------------------------------------------
{
	return time.getCopy();
}

public PlainDate getDate(PlainDate dest) {
	if (dest == null) dest = new PlainDate();
	dest.day = time.day;
	dest.month = time.month;
	dest.year = time.year;
	return dest;
}

public PlainTime getTime(PlainTime dest) {
	if (dest == null) dest = new PlainTime();
	dest.hour = time.hour;
	dest.minute = time.minute;
	dest.second = time.second;
	dest.millis = time.millis;
	return dest;
}

public boolean dateIsValid() {
	return DateTimeUtils.dateIsValid(this);
}

public void makeDateInvalid() {
	if (time != null) time.makeDateInvalid();
}

public void makeTimeInvalid() {
	if (time != null) time.makeTimeInvalid();
}

public boolean timeIsValid() {
	return DateTimeUtils.timeIsValid(this);
}

/*
//===================================================================
public Object clipboardTransfer(Object clip,boolean toClipboard,boolean cut)
//===================================================================
{
	Object ret = clip;
	if (toClipboard || cut){
		Time t = (Time)time.getCopy();
		t.format = time.format;
		ret = t;
	}
	if (!toClipboard && clip != null){
		if (clip instanceof Time){
			if (((Time)clip).isValid()) time.copyFrom((Time)clip);
		}else if ((clip = toTextData(clip)) instanceof String){
			Time t2 = new Time();
			t2.format = time.format;
			t2.fromString(clip.toString());
			if (t2.isValid()) time.copyFrom(t2);
		}
		repaintNow();
	}
	return ret;
}
*/
/*
//=================================================================
public static void main(String[] args)
//=================================================================
{
	ewe.sys.Vm.startEwe(args);
	Form f = new Form();
	InputStack is = new InputStack();
	DateTimeInput dti = new DateTimeInput();
	//dti.setTimeFormat(true,true);
	is.add(dti,"Appointment:");
	dti.setTime(new TimeOfDay(11,32,0));
	f.addLast(is).setCell(HSTRETCH);
	f.setPreferredSize(240,320);
	f.execute();
	ewe.sys.Vm.exit(0);
}
*/
//##################################################################
}
//##################################################################

