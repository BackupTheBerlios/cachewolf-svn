/*
 * Created on Apr 9, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import java.util.Vector;

import eve.fx.Rect;

/**
 * A ControlGroup is a collection of Controls. Its primary use is for
 * grouping together Controls that should be exposed all at the same time.
 * <p>
 * @author Michael L Brereton
 *
 */
//####################################################
public class ControlGroup {

	private Vector controls = new Vector();
	
	/**
	 * Add the specified Control to this ControlGroup and then
	 * set this ControlGroup as a TAG_EXPOSE_GROUP Tag on the Control using the
	 * specified asTag ID.  
	 * @param c the Control to add to this ControlGroup and be tagged.
	 * @return the c parameter.
	 */
	public synchronized Control addExposeGroup(Control c)
	{
		return add(c,Control.TAG_EXPOSE_GROUP);
	}
	/**
	 * Add the specified Control to this ControlGroup and then
	 * set this ControlGroup as a Tag on the Control using the
	 * specified asTag ID.  
	 * @param c the Control to add to this ControlGroup and be tagged.
	 * @param asTag the tag ID.
	 * @return the c parameter.
	 */
	public synchronized Control add(Control c,int asTag)
	{
		if(c == null) return c;
		controls.add(c);
		c.setTag(asTag,this);
		return c;
	}
	
	public ControlIterator iterator(ControlIterator dest)
	{
		if (dest == null) dest = new ControlIterator();
		dest.setFor(controls.iterator());
		return dest;
	}
	
	public int size() 
	{
		return controls.size();
	}
	public Control get(int index)
	{
		return (Control)controls.get(index);
	}
	public Rect getRectInParent(Control parent, Rect dest)
	{
		dest = Rect.unNull(dest).set(0,0,0,0);
		Rect r = Rect.getCached(0,0,0,0);
		int sz = controls.size();
		for (int i = 0; i<sz; i++){
			int x = 0, y = 0;
			Control c = (Control)controls.get(i);
			int width = c.width, height = c.height;
			while(c != parent && c != null){
				x += c.x;
				y += c.y;
				c = c.parent;
			}
			r.set(x,y,width,height);
			if (i == 0) dest.set(r);
			else dest.unionWith(r);
		}
		r.cache();
		return dest;
	}
	/**
	 * Get the ControlGroup for the Control which is tagged as TAG_EXPOSE_GROUP.
	 * If it is not found in this Control it
	 * is searched for in the parent of the control.
	 * @param c the Control to search for the tag in.
	 * @param asTag the Tag ID.
	 * @return the found ControlGroup or null if not found.
	 */
	public static ControlGroup getExposeGroupFor(Control c)
	{
		return getGroupFor(c,Control.TAG_EXPOSE_GROUP);
	}	
	/**
	 * Get the ControlGroup for the Control which is tagged with 
	 * the specified Tag ID. If it is not found in this Control it
	 * is searched for in the parent of the control.
	 * @param c the Control to search for the tag in.
	 * @param asTag the Tag ID.
	 * @return the found ControlGroup or null if not found.
	 */
	public static ControlGroup getGroupFor(Control c,int asTag)
	{
		while(c != null){
			Object obj = c.getTag(asTag,null);
			if (obj instanceof ControlGroup) return (ControlGroup)obj;
			c = c.parent;
		}
		return null;
	}
}
//####################################################
