package eve.ui;
import eve.fx.Font;

//##################################################################
public class FontInput extends TextDisplayButton{
//##################################################################
{
	setMenu(getClipboardMenu(null));
}

public static final int OPTION_NO_NAME = FontUpDownChooser.OPTION_NO_NAME;
public static final int OPTION_NO_SIZE = FontUpDownChooser.OPTION_NO_SIZE;
public static final int OPTION_NO_STYLE = FontUpDownChooser.OPTION_NO_STYLE;
public static final int OPTION_NO_SAMPLE =FontUpDownChooser.OPTION_NO_SAMPLE;

private int options = 0;
private ControlPopupForm popup = null;
private Font f = Application.mainApp.getFont();

//===================================================================
public void fromFont(Font font)
//===================================================================
{
	f = font;
	setText(fontToString());
}
//===================================================================
public Font toFont()
//===================================================================
{
	return f;
}
//===================================================================
public String fontToString()
//===================================================================
{
	String ret = "";
	if ((options & OPTION_NO_NAME) == 0) ret += f.getName();
	if ((options & OPTION_NO_SIZE) == 0) {
		if (ret.length() != 0) ret += ",";
		ret += f.getSize();
	}
	if ((options & OPTION_NO_STYLE) == 0) {
		if (ret.length() != 0) ret += ",";
		ret += FontUpDownChooser.getStyleName(f.getStyle());
	}
	return ret;
}
//===================================================================
public FontInput()
//===================================================================
{
	this(0);
}
//===================================================================
public FontInput(int options)
//===================================================================
{
	setOptions(options);
	setText(fontToString());
}
//===================================================================
public void setOptions(int options)
//===================================================================
{
	this.options = options;
	ControlPopupForm p2 = FontUpDownChooser.getPopup(options);
	if (p2 != popup){
		if (popup != null) popup.detachFrom(this);
		popup = p2;
		popup.attachTo(this);
	}
}

//===================================================================
public void setData(Object data)
//===================================================================
{
	//ewe.sys.Vm.debug("setData(): "+data);
	if (data instanceof Font) fromFont((Font)data);
}
//===================================================================
public Object getData()
//===================================================================
{
	return toFont();
}
//##################################################################
}
//##################################################################

