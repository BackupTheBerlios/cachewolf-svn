package eve.ui;

import eve.sys.Convert;

//##################################################################
public class DecimalKeyPad extends InputKeyPad{
//##################################################################
private static DecimalKeyPad keypad;
public static synchronized DecimalKeyPad getSharedKeypad()
{
	if (keypad == null) keypad = new DecimalKeyPad();
	return keypad;
}

//==================================================================
public static void attach(Control who) {keypad.attachTo(who);}
//==================================================================

Button one, ten, hundred, thousand;

//==================================================================
public DecimalKeyPad()
//==================================================================
{
	keys.addNext(one = new Button("+1"));
	keys.addNext(ten = new Button("+10"));
	keys.addNext(hundred = new Button("+100"));
	keys.addNext(thousand = new Button("+1000"));
	curText.alignment = Gui.Right;
	curText.anchor = Gui.NORTHEAST;
	modify(DrawFlat,0);
}
//==================================================================
protected void doClear() {curText.setText("0");}
//==================================================================
protected void pressed(Control who)
//==================================================================
{
	int val = Convert.toInt(curText.getText());
	if (who == one) val += 1;
	if (who == ten) val += 10;
	if (who == hundred) val += 100;
	if (who == thousand) val += 1000;
	curText.setText(""+val);
	super.pressed(who);
}

//##################################################################
}
//##################################################################

