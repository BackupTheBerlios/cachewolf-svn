package eve.ui;

import eve.sys.Event;

/**
* Normally, when you press the mouse or pen on a label, the event is passed to its
* associated control. A DumbLabel, however, will only pass events to its registered
* listeners.
**/
//##################################################################
public class DumbLabel extends Label{
//##################################################################

public DumbLabel(String text) {super(text);}
public DumbLabel(String text,boolean hasHotKey) {super(text,hasHotKey);}
public DumbLabel(int rows,int cols) {super(rows,cols);}

public void postEvent(Event ev)
{
	sendToListeners(ev);
}

//##################################################################
}
//##################################################################


