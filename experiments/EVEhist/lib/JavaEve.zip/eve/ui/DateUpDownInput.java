package eve.ui;
import java.util.Vector;

import eve.data.DateTimeUtils;
import eve.data.IDate;
import eve.data.PlainDate;
import eve.data.Value;
import eve.fx.BufferedGraphics;
import eve.fx.Color;
import eve.fx.FontMetrics;
import eve.fx.Graphics;
import eve.fx.Point;
import eve.fx.Rect;
import eve.sys.Convert;
import eve.sys.Event;
import eve.sys.Locale;
import eve.sys.Time;
import eve.ui.event.ControlEvent;
import eve.ui.event.DataChangeEvent;
import eve.util.Range;
import eve.util.Timeable;
/**
This inputs a time of day value using a set of UpDownInputs.
**/
//##################################################################
public class DateUpDownInput extends Holder implements Timeable, IDate {
//##################################################################

	/**
	 * Set this true for the day to be shown before the month for all future
	 * DateUpDownInput created.
	 */
public static boolean dayBeforeMonth = false;

UpDownInput day, month, century, year;
private static Range dayRange = new Range(1,31);
private static Range yearRange = new Range(0,99);
private static Vector monthRange = new Vector();
private static int monthWidth = 0;

static {
	Locale l = Locale.getDefault();
	for (int i = 0; i<12; i++){
		String r = l.getString(l.SHORT_MONTH,i+1,0);
		monthRange.add(r);
		monthWidth = Math.max(r.length(),monthWidth);
	}
}

//-------------------------------------------------------------------
Label getLabel(String what)
//-------------------------------------------------------------------
{
	Label l = new Label(what);
	l.spacing = 1;
	setControl(DONTFILL|CENTER);
	return l;
}

CalendarCanvas calendar;

//===================================================================
public void setLocale(Locale locale)
//===================================================================
{
	calendar.setLocale(locale);
}
//===================================================================
public DateUpDownInput(boolean showCalendar)
//===================================================================
{
	if (showCalendar) {
		calendar = new CalendarCanvas();
		calendar.setFont(Application.findFont("small",true));
	}
	if (dayBeforeMonth){
		addNext(day = new UpDownInput(2));
		addNext(getLabel("/"));
		addNext(month = new UpDownInput(monthWidth));
	}else{
		addNext(month = new UpDownInput(monthWidth));
		addNext(getLabel("/"));
		addNext(day = new UpDownInput(2));
	}
	addNext(getLabel("/"));
	addNext(century = new UpDownInput(2));
	addNext(year = new UpDownInput(2));
	day.integerDigits = month.integerDigits = century.integerDigits = year.integerDigits = 2;
	day.dataChangeOnEachPress = month.dataChangeOnEachPress = century.dataChangeOnEachPress = year.dataChangeOnEachPress = true;
	day.integerValues = dayRange;
	month.textValues = monthRange;
	month.allowTextInput = true;
	century.integerValues = year.integerValues = yearRange;
	century.borderStyle = BDR_OUTLINE|BF_LEFT|BF_TOP|BF_BOTTOM;
	year.borderStyle = BDR_OUTLINE|BF_RIGHT|BF_TOP|BF_BOTTOM;
	year.zeroFillInteger = true;
	century.anchor = EAST;
	year.anchor = WEST;
	setTime(new Time());
}
public void setValue(Value data)
{
	if (data instanceof Time) setTime((Time)data);
	else if (data instanceof IDate) DateTimeUtils.transferDate((IDate)data,this);
}
public void getValue(Value data)
{
	if (data instanceof Time) getTime((Time)data);
	else if (data instanceof IDate) DateTimeUtils.transferDate(this,(IDate)data);
}
/**
Set the Time the input displays.
@param t The Time to display.
*/
//===================================================================
public void setTime(Time t)
//===================================================================
{
	setDate(t.day,t.month,t.year);
}
public void setDate(int day, int month, int year)
{
	this.day.setInt(day);
	this.month.setInt(month);
	century.setInt(year/100);
	this.year.setInt(year%100);
	this.day.integerValues.last = Time.numberOfDays(month,year);
	updateCalendar();
}

/**
Get the time displayed/entered.
@param dest an optional destination Time which may be null.
@return the destination Time or a new Time if dest is  null.
*/
//===================================================================
public Time getTime(Time dest)
//===================================================================
{
	if (dest == null) dest = new Time();
	dest.day = day.getInt();
	dest.month = month.getInt();
	dest.year = century.getInt()*100+year.getInt();
	int nd = Time.numberOfDays(dest.month,dest.year);
	if (dest.day > nd){
		dest.day = 1;
		day.setInt(1);
	}
	dest.update();
	return dest;
}
public PlainDate getDate(PlainDate dest)
{
	if (dest == null) dest = new PlainDate();
	dest.day = day.getInt();
	dest.month = month.getInt();
	dest.year = century.getInt()*100+year.getInt();
	int nd = Time.numberOfDays(dest.month,dest.year);
	if (dest.day > nd){
		dest.day = 1;
		day.setInt(1);
	}
	return dest;
}
/*
//Locale locale;

//-------------------------------------------------------------------
private String pad(String what)
//-------------------------------------------------------------------
{
	while (what.length() < 4) what = " "+what;
	return what;
}
*/
private static Time cal;

//-------------------------------------------------------------------
private void updateCalendar()
//-------------------------------------------------------------------
{
	if (calendar == null) return;
	if (cal == null) cal = new Time();
	getTime(cal);
	calendar.update(cal);
}
//===================================================================
public void onEvent(Event ev)
//===================================================================
{
	if (ev instanceof DataChangeEvent){
		if (ev.target == month || ev.target == year)
			day.integerValues.last = Time.numberOfDays(month.getInt(),year.getInt());
		updateCalendar();
		super.onEvent(ev);
	}else
		super.onEvent(ev);
}

private static ControlPopupForm pop, popC;

//===================================================================
public static ControlPopupForm getPopup(boolean showCalendar)
//===================================================================
{
	if (showCalendar)
			return popC == null ? (popC = new DateUpDownInputPopup(showCalendar)) : popC;
	else
			return pop == null ? (pop = new DateUpDownInputPopup(showCalendar)) : pop;
}
/**
 * Use this to popup a Date Up/Down Input in a Frame.
 * @param parent the parent Frame - must be non-null. Use getFrame() on any Control to
 * determine its Frame.
 * @param initial an optional initial Time. If this is non-null the new Date entered
 * will be placed in here too.
 * @param location an optional point to display the popup in the Frame. If it is null
 * the popup will be centered.
 * @param showCalendar true to show the 31 day of week calendar along with the input.
 * @return a Time value containing the new date or null if the user cancelled.
 */
public static Time popupDateInput(Frame parent, Time initial, Point location, boolean showCalendar)
{
	if (initial == null) initial = new Time();
	DateTimeInput dti = new DateTimeInput();
	dti.setTime(initial);
	ControlPopupForm cp = getPopup(showCalendar);
	if (location == null)
		cp.putByClient = false;
	else{
		dti.setRect(location.x,location.y,1,1);		
	}
	dti.modify(Control.Invisible,0);
	parent.addDirectly(dti);
	cp.setFor(dti);
	int got = cp.waitUntilClosed();
	parent.remove(dti);
	if (got == Form.IDCANCEL) return null;
	return dti.getTime(initial);
}

//##################################################################
public static class DateUpDownInputPopup extends ControlPopupForm{
//##################################################################
DateUpDownInput input;
//===================================================================
public DateUpDownInputPopup(boolean showCalendar)
//===================================================================
{
	//putByClient = false;
	setBorder(BDR_OUTLINE|BF_RECT,1);
	backGround = Color.White;
	CellPanel cp = new CellPanel();
	cp.addNext(input = new DateUpDownInput(showCalendar));
	addCloseControls(cp);
	addLast(cp);
	if (showCalendar) {
		endRow();
		addLast(input.calendar);
	}
}
//===================================================================
public void onControlEvent(ControlEvent ev)
//===================================================================
{
	if (ev.target == input){
		if (ev.type == ev.PRESSED)
			exit(IDOK);
		else if (ev.type == ev.CANCELLED)
			exit(IDCANCEL);
	}
	else super.onControlEvent(ev);
}
//-------------------------------------------------------------------
protected void transferToClient(Control client)
//-------------------------------------------------------------------
{
	if (client instanceof Timeable)
		((Timeable)client).setTime(input.getTime(null));
}
/**
* This is called by setFor(Control who) and gives you an opportunity to
* modify the Form based on the client control.
* @param who The new client control.
*/
//------------------------------------------------------------------
protected void startingInput(Control who)
//-------------------------------------------------------------------
{
	if (who instanceof Timeable)
		input.setTime(((Timeable)client).getTime(null));
}
//##################################################################
}
//##################################################################

public boolean dateIsValid() {
	return DateTimeUtils.dateIsValid(this);
}

public void makeDateInvalid() {
	this.day.setInt(0);
}

/*
//##################################################################
public static class DateUpDownInputPopup extends InputPopup{
//##################################################################

DateUpDownInput input;

//===================================================================
public DateUpDownInputPopup(boolean showCalendar)
//===================================================================
{
	CellPanel cp = new CellPanel();
	addMainControls(cp).setControl(DONTFILL|CENTER);
	cp.addNext(input = new DateUpDownInput(showCalendar));
	addCloseControls(cp);
	endRow();
	if (input.calendar != null){
		addLast(input.calendar).setControl(DONTFILL|CENTER);
		firstFocus = input.day;
	}
}

//===================================================================
public boolean canExit(int exitCode)
//===================================================================
{
	if (exitCode != IDOK) return true;
	Time got = getTime(null);
	if (!got.isValid()){
		beep();
		Gui.flashMessage("Invalid Date",getFrame());
		Gui.takeFocus(input,ByRequest);
		return false;
	}
	return true;
}
//===================================================================
public Time getTime(Time dest)
//===================================================================
{
	return input.getTime(dest);	
}
//===================================================================
public void setTime(Time time)
//===================================================================
{
	input.setTime(time);	
}

//##################################################################
}
//##################################################################
*/
/*
//=================================================================
public static void main(String[] args)
//=================================================================
{
	ewe.sys.Vm.startEwe(args);
	Form f = new Form();
	DateDisplayInput ddi = new DateDisplayInput();
	
	InputStack is = new InputStack();
	is.add(ddi,"Date:");
	f.execute();
	ewe.sys.Vm.exit(0);
}*/
//##################################################################
}
//##################################################################

//##################################################################
class CalendarCanvas extends Canvas{
//##################################################################

static FontMetrics fontMetrics;
static int[] widths;// = new int[31];
static int[] dwidths;
static String[] dates;// = new String[]{
static String[] days;
static int maxWidth = 0, cellWidth = 0, cellHeight = 0;
Locale locale;

/*
This is meant only to be used in a popup - where only one is on-screen at a time.
So can use static values here.
*/
private static int dw[], dm[];
private int lastMonth = 0, lastYear = 0;

//===================================================================
CalendarCanvas()
//===================================================================
{
	modify(NoFocus,0);
	locale = Locale.getDefault();
	borderWidth = 1;
	borderStyle = BF_TOP;
}
//-------------------------------------------------------------------
void setLocale(Locale locale)
//-------------------------------------------------------------------
{
	if (locale == null) locale = new Locale("es",null,false);
	if (locale == null) locale = Locale.getDefault();
	this.locale = locale;
}
//-------------------------------------------------------------------
protected void calculateSizes()
//-------------------------------------------------------------------
{
	FontMetrics fm = getFontMetrics();
	if (fm != fontMetrics || widths == null){
		fontMetrics = fm;
		widths = new int[31];
		dates = new String[widths.length];
		for (int i = 0; i<widths.length; i++){
			dates[i] = Convert.toString(i+1);
			widths[i] = fm.getTextWidth(dates[i]);
			if (widths[i] > maxWidth) maxWidth = widths[i];
		}
		dwidths = new int[7];
		days = new String[7];
		for (int i = 0; i<7; i++){
			days[i] = Convert.toString(locale.getString(locale.SHORT_DAY,i+1,0).charAt(0));
			dwidths[i] = fm.getTextWidth(days[i]);
			if (dwidths[i] > maxWidth) maxWidth = dwidths[i];
		}
	}
	cellWidth = maxWidth+4;
	cellHeight = fm.getHeight();
	preferredWidth = cellWidth*7;
	preferredHeight = cellHeight*6+4;
}
int selectedDay = 0, firstDayIndex = 0;
int top = 2;
//-------------------------------------------------------------------
void update(Time cal)
//-------------------------------------------------------------------
{
	if (dw == null){	
		dw = new int[7];
		dm = new int[35];
	}
	if (cal.month != lastMonth || cal.year != lastYear){
		locale.getCalendarForMonth(cal,dw,dm,true);
		for (int i = 0; i<7; i++)
			if (dm[i] == 1) firstDayIndex = i;
		/*
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i<7; i++)
			sb.append(pad(locale.getString(locale.SHORT_DAY,i,0)));
		sb.append("\n");
		for (int i = 0; i<35; i++){
			if (dm[i] == 0) sb.append("    ");
			else sb.append(pad(""+dm[i]));
			if (((i+1)%7) == 0) sb.append("\n");
		}
		System.out.println(sb);
		*/
		selectedDay = cal.day;
		repaintNow();
	}else{
		if (cal.day != selectedDay){
			int sd = selectedDay;
			selectedDay = cal.day;
			paintDay(sd);
			paintDay(selectedDay);
		}
	}
	lastMonth = cal.month;
	lastYear = cal.year;
}
//-------------------------------------------------------------------
void paintDay(int day)
//-------------------------------------------------------------------
{
	if (requestPaint()){
		int idx = (firstDayIndex+(day-1)) % 35;
		int x = (idx%7)*cellWidth, y = top+((idx/7)+1)*cellHeight;
		BufferedGraphics bg = getGraphics(x,y,cellWidth,cellHeight);
		if (bg == null) return;
		try{
			Graphics g = bg.getGraphics();
			g.setColor(getBackground());
			g.fillRect(x,y,cellWidth,cellHeight);
			g.setFont(getFont());
			g.setColor(getForeground());
			g.drawText(dates[day-1],x+((cellWidth-widths[day-1])/2),y);			
			if (day == selectedDay && selectedDay != 0)
				g.drawRect(x,y,cellWidth,cellHeight);
		}finally{
			bg.release();
		}
	}
}
//===================================================================
public void doPaint(Graphics g, Rect Area)
//===================================================================
{
	super.doBackground(g);
	super.doBorder(g);
	g.setFont(getFont());
	g.setColor(getForeground());
	if (dw == null) return;
	int x = 0;
	for (int i = 0; i<7; i++){
		int idx = dw[i]-1;
		g.drawText(days[idx],x+((cellWidth-dwidths[idx])/2),top);
		x += cellWidth;
	}
	int v = 0;
	for (int r = 1; r<=5; r++){
		int y = top+r*cellHeight;
		x = 0;
		for (int i = 0; i<7; i++){
			int idx = dm[v++]-1;
			if (idx != -1)
				g.drawText(dates[idx],x+((cellWidth-widths[idx])/2),y);
			if (idx+1 == selectedDay && selectedDay != 0)
				g.drawRect(x,y,cellWidth,cellHeight);
			x += cellWidth;
		}
	}
}
//##################################################################
}
//##################################################################

