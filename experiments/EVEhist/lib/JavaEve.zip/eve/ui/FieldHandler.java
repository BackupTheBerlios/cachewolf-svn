/*
 * Created on Jul 1, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import java.util.Enumeration;
import java.util.Hashtable;

import eve.sys.Event;
import eve.sys.FieldTransfer;
import eve.ui.event.ControlEvent;
import eve.ui.event.DataChangeEvent;
import eve.ui.event.ListEvent;
import eve.ui.event.MenuEvent;
import eve.util.mString;

/**
 * A FieldHandler is a simple way of doing automatic data transfer between
 * on-screen Controls and fields in an Object. It is not as powerful as the
 * eve.ui.data.Editor Form and associated eve.ui.data.FieldListener interface
 * but it does not require the eve.ui.data library to be present.
 * <p>
 * You use this by creating the FieldHandler and setting the Class of the
 * Object to be edited. Then associate fields with Controls using the add() method.
 * Then call addFieldHandler() on a Form to activate the FieldHandler. The
 * Controls that you add to the FieldHandler must be child Controls of the 
 * Form.
 */
//####################################################
public class FieldHandler extends Hashtable{

	/**
	 * This is the type of the Object being edited.
	 */
	public Class objectClass;
	/**
	 * This holds the Object itself that is being edited.
	 */
	public Object data;
	/**
	 * Find the Control that was assigned to the specified field.
	 * @param fieldName the field name.
	 * @return the Control, if any associated with the field.
	 */
	public Control getControlFor(String fieldName)
	{
		FieldTransfer ft = getFieldTransferFor(fieldName);
		if (ft == null || !(ft.dataInterface instanceof Control)) return null;
		return (Control)ft.dataInterface;
	}
	/**
	 * Get the FieldTransfer Object responsible for data transfer between
	 * the Control and the Object field.
	 * @param fieldName the Field name.
	 * @return the FieldTransfer Object responsible for data transfer between
	 * the Control and the Object field.
	 */
	public FieldTransfer getFieldTransferFor(String fieldName)
	{
		for (Enumeration e = elements(); e.hasMoreElements(); ){
			Object obj = e.nextElement();
			if (obj instanceof FieldTransfer){
				FieldTransfer ft = (FieldTransfer)obj;
				if (fieldName.equals(ft.fieldName))
					return ft;
			}
		}
		return null;
	}
	/**
	 * Get the FieldTransfer associated with a Control.
	 * @param c the Control.
	 * @return the FieldTransfer associated with the Control.
	 */
	public FieldTransfer getFieldTransferFor(Control c)
	{
		return (FieldTransfer)get(c);
	}
	/**
	 * Transfer data from the specified Object fields to the Control elements
	 * on screen.
	 * @param fieldNames a comma separated list of field names.
	 */
	public void toControls(String fieldNames)
	{
		String[] all = mString.split(fieldNames,',');
		for (int i = 0; i<all.length; i++){
			Control c = getControlFor(all[i]);
			if (c != null) c.fromField();
		}
	}
	/**
	 * Transfer data from the he Control elements to the specified Object fields.
	 * @param fieldNames a comma separated list of field names.
	 */
	public void fromControls(String fieldNames)
	{
		String[] all = mString.split(fieldNames,',');
		for (int i = 0; i<all.length; i++){
			Control c = getControlFor(all[i]);
			if (c != null) c.toField();
		}
	}
	/**
	 * Transfer data from all the fields to the Controls.
	 */
	public void toControls()
	{
		for (Enumeration e = keys(); e.hasMoreElements();){
			((Control)e.nextElement()).fromField();
		}
	}
	/**
	 * Transfer data to all the fields from the Controls.
	 */
	public void fromControls()
	{
		for (Enumeration e = keys(); e.hasMoreElements();){
			((Control)e.nextElement()).toField();
		}
	}
	/**
	 * Set the data Object and transfer all the fields to Controls.
	 * @param obj the new Data object. This can be null but must be compatible
	 * with the objectClass type.
	 */
	public void setObject(Object obj)
	{
		if (obj != null && !objectClass.isInstance(obj))
			throw new ClassCastException(obj.getClass()+" is not of type: "+objectClass);
		data = obj;
		toControls();
	}
	/**
	 * Create a FieldHandler to handle a particular data Object. The objectClass
	 * is set using dataObject.getClass()
	 * @param dataObject this becomes the data Object
	 */
	public FieldHandler(Object dataObject)
	{
		objectClass = dataObject.getClass();
		data = dataObject;
	}
	/**
	 * Create an empty FieldHandler. You must set objectClass to the type
	 * of the Object being edited before adding fields.
	 */
	public FieldHandler()
	{
		
	}
	/**
	 * Add a field specifying transferOptions to set and/or clear.
	 * @param fieldName the name of the field.
	 * @param fieldControl the Control being used to display/edit the field.
	 * @param FieldTransfer options to set.
	 * @param FieldTransfer options to clear.
	 * @return the Control added.
	 */
	public Control add(String fieldName, Control fieldControl,int transferOptionsToSet, int transferOptionsToClear)
	{
		if (fieldControl != null && fieldName != null){
			FieldTransfer ft = new FieldTransfer(objectClass,data,fieldName,fieldControl,null);
			//if (!ft.isValid()) throw new IllegalArgumentException("Bad field: "+fieldName+" for: "+objectClass.getName());
			ft.transferOptions |= transferOptionsToSet;
			ft.transferOptions &= ~transferOptionsToClear;
			fieldControl.fieldTransfer = ft;
			put(fieldControl,ft);
			fieldControl.fromField();
		}
		return fieldControl;
	}
	/**
	 * Add a field.
	 * @param fieldName the name of the field.
	 * @param fieldControl the Control being used to display/edit the field.
	 * @return the Control added.
	 */
	public Control add(String fieldName, Control fieldControl)
	{
		return add(fieldName,fieldControl,0,0);
	}
	/**
	 * Override this to handle field action events (e.g. when a Button is pressed). 
	 * @param fieldControl the Control generated the action. To determine
	 * the name of the field call getFieldTransferFor(fieldControl) and
	 * then use the fieldName field of the returned FieldTransfer.
	 * @param f the Form the FieldHandler was associated with.
	 */
	protected void fieldAction(Control fieldControl, Form f)
	{
		
	}
	/**
	 * Override this to handle when a  field value changes. Note that when
	 * this method gets called, the value of the field has already been changed
	 * to reflect the value entered/selected by the user.
	 * @param fieldControl the Control generated the action. To determine
	 * the name of the field call getFieldTransferFor(fieldControl) and
	 * then use the fieldName field of the returned FieldTransfer.
	 * @param f the Form the FieldHandler was associated with.
	 */
	protected void fieldChanged(Control fieldControl, Form f)
	{
		
	}
	/**
	 * This is called for any ControlEvent generated by the Control other
	 * than ControlEvent.PRESSED  (handled by fieldAction()) or a DataChangeEvent
	 * (handled by fieldChanged()).
	 * @param fieldControl the Control generated the action. To determine
	 * the name of the field call getFieldTransferFor(fieldControl) and
	 * then use the fieldName field of the returned FieldTransfer.
	 * @param f the Form the FieldHandler was associated with.
	 * @param ev the ControlEvent generated by the Control.
	 */
	protected void fieldEvent(Control fieldControl, Form f, Event ev)
	{
		
	}
	/**
	 * The Form with this FieldHandler passes events to the handler through this method.
	 * If you override it be sure to call super.gotEvent() so that normal field
	 * handling can continue.
	 */
	public void gotEvent(Event ev,Form f)
	{
		if (!(ev.target instanceof Control)) return;
		Control c = (Control)ev.target;
		FieldTransfer ft = (FieldTransfer)get(ev.target);
		if (ft == null) return;
		if (ev instanceof DataChangeEvent){
			c.toField();
			fieldChanged(c,f);
		}else if (ev instanceof ControlEvent){
			if (ev.type == ControlEvent.PRESSED){
				fieldAction(c,f);
			}else if (ev.type == MenuEvent.SELECTED && !(ev instanceof ListEvent)){
				fieldChanged(c,f);
			}else{
				fieldEvent(c,f,ev);
			}
		}
	}
}
//####################################################
