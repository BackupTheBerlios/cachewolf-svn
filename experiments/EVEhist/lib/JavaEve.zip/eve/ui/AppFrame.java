package eve.ui;
import java.util.Iterator;

import eve.sys.Cache;
/**
An AppFrame is a specialized Frame only used for the main Frame for all other
application Frames under special circumstances (e.g. under Smartphones). You would
almost never have to create or use one yourself.<p>
When an AppFrame is resized it will adjust all of its children such that they now
fit into the Frame, in case they do not any more.
**/
//##################################################################
public class AppFrame extends Frame{
//##################################################################

//===================================================================
public void resizeTo(int width, int height)
//===================================================================
{
	Iterator it = getCachedChildren(false);
	for (; it.hasNext();){
		Control c = (Control)it.next();
		if (c.width == this.width && c.height == this.height){
			//
			// If the child is exactly the size of the parent, then make it
			// also continue to be so.
			//
			c.setRect(0,0,width,height);
		}else{
			//if (
		}
	}
	Cache.put(it);
	changeDimension(width, height);
	//super.resizeTo(width,height);
}
//##################################################################
}
//##################################################################

