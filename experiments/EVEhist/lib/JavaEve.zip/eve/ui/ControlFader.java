/*
 * Created on Sep 27, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package eve.ui;

import eve.sys.Task;

/**
 * @author Mike
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ControlFader extends Task 
{

	private Frame c;
	private float from;
	private float to;
	private int delay;
	private int steps;
	private int was;
	
	public synchronized void cancel(boolean repaint)
	{
		stop(0);
		c.alpha = to;//1.0f;
		c.restore(was,c.Transparent);
		if (repaint) c.repaintNow();
	}
	
	public ControlFader(Frame c, double from, int delay, int steps)
	{
		this.c = c;
		this.to = c.alpha;
		c.alpha = (float)from;
		was = c.modify(Control.Transparent,0);
		this.from = (float)from;
		this.delay = delay;
		this.steps = steps;
	}
	public ControlFader(Frame c)
	{
		this(c,0.1,50,5);
	}
	
	protected void doRun()
	{
		int nt = delay/steps;
		float alpha = from;
		float max = to;
		for (int i = 0; i<steps && !shouldStop; i++)
		{
			c.alpha = i == steps-1 ? max : alpha;
			if (c.alpha == max)
				c.restore(was,Control.Transparent);
			alpha += (max-from)/steps;
			c.repaintNow();
			sleep(nt);
		}
	}
}
