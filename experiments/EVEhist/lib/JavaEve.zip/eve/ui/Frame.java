package eve.ui;

import java.util.Iterator;
import java.util.Vector;

import eve.fx.Color;
import eve.fx.Dimension;
import eve.fx.Point;
import eve.fx.Rect;
import eve.fx.gui.SurfaceSIPEvent;
import eve.sys.Event;
import eve.sys.Handle;
import eve.ui.event.FrameEvent;
import eve.util.mVector;

//##################################################################
public class Frame extends CellPanel {
//##################################################################

public static final int PressedOutside = 1;
static final int SizedFlag = 0x10000;
Handle openState = new Handle();
WindowEventThread createdWindowThread;
boolean isModal = false;

public float alpha = 1.0f;
/**
 * This sets the alpha value and also the Transparent modifier.
 * @param alpha the new alpha value. If it is 1 (fully opaque) then
 * the Transparent modifier is switched off, otherwise the Transparent
 * modifier is switched on. 
 * @return this Frame.
 */
public Frame setAlpha(float alpha)
{
	this.alpha = alpha;
	if (alpha >= 1.0f)
		modify(0,Transparent);
	else
		modify(Transparent,0);
	return this;
}
public Handle getOpenState()
{
	return openState;
}
/**
 * Get the Control that represents the "contents" of the Frame, exclusive of
 * Frame decorations, titles, extra buttons etc.
 * If this Frame was created by a Form, the contents will be the Form.
 */
/*
public Control getMainContents()
{
	if (windowCanvas != null) return windowCanvas;
	return contents;
}
*/

public boolean wantPressedOutside = false;
public boolean contentsOnly = false;
public boolean capturePressedOutside = false;
public boolean doSaveScreen = false;
public boolean resizeOnSIP = false;

public boolean isControlPanel = false;
//public boolean isPopup = false;

public PopupController popupController;

public boolean closeWindow = false;
public CellPanel top = new CellPanel(), bottom = new CellPanel(), contents = new CellPanel();
SavedScreen savedScreen;
/**
* This is a collection of components that should be refreshed when the frame is removed. It is initially null
* until something is added.
**/
public Vector controlsToRefresh;
private Vector childFrames;
Frame parentFrame;

/**
* This resizes a Frame and its contents. It works if a Frame is in its own Window OR if it
* the child of another Frame.
* @param width The new width for the Frame.
* @param height The new height for the Frame.
* @param overrideMaximize If this is true then a resize is forced regardless of the possible maximized state of the window.
* If it is false, then if the window containing the Frame is maximized, no resize will be done.
*/
//===================================================================
public void resize(int width, int height, boolean overrideMaximize)
//===================================================================
{
	Frame f = this;
	try{
		if (Gui.isWindowFrame(f)){
			Window w = f.getWindow();
			int fl = w.getWindowFlags();
			if (overrideMaximize || (fl & (w.FLAG_MAXIMIZE|w.FLAG_MINIMIZE)) == 0){
				fl &= ~(w.FLAG_MAXIMIZE|w.FLAG_MINIMIZE|w.FLAG_MAXIMIZE_ON_PDA|w.FLAG_IS_DEFAULT_SIZE);
				Rect r = w.getWindowRect(new Rect(),true);
				int ox = r.x;
				Rect full = w.getWindowRect(new Rect(),false);
				Dimension d = f.getPreferredSize(null);
				r.x = fl;
				int ffs = w.getFlagsForSize(fl,0,d.width,d.height);
				//Integer ffs = (Integer)w.getInfo(w.INFO_FLAGS_FOR_SIZE,r,new Integer(0),0);
				if ((ffs & w.FLAG_IS_DEFAULT_SIZE) != 0){
					w.setState(w.STATE_MAXIMIZED);
				}else{
					if (r.width == d.width && r.height == d.height)
						repaintNow();
					else{
						w.setState(w.STATE_NORMAL);
						r.width = d.width; r.height = d.height;
						r.x = full.x+ox;
						r.y = full.y+r.y;
						w.setWindowRect(r,true);
						w.getWindowRect(r,true);
						w.wasResizedTo(r.width,r.height);
						//System.out.println(d+"=>"+);
					}
				}
			}else{
				f.repaintNow(); //Maximized.
			}
		}else{
			Rect r = f.getRect(null);
			Dimension d = f.getPreferredSize(null);
			r.width = d.width; r.height = d.height;
			Gui.moveFrameTo(f,r);
		}
	}catch(Exception e){
		f.repaintNow();
	}
}
/**
* This resizes a Frame and its contents to be its preferred size. It works if a Frame is in its own Window OR if it
* the child of another Frame.
* @param overrideMaximize If this is true then a resize is forced regardless of the possible maximized state of the window.
* If it is false, then if the window containing the Frame is maximized, no resize will be done.
*/
//===================================================================
public void resize(boolean overrideMaximize)
//===================================================================
{
	Dimension d = getPreferredSize(null);
	resize(d.width,d.height,overrideMaximize);
}
/**
 * This does a relayout of the Frame and its children and then resizes the Frame
 * to fit the new layout.
* @param overrideMaximize If this is true then a resize is forced regardless of the possible maximized state of the window.
* If it is false, then if the window containing the Frame is maximized, no resize will be done.
 */
//===================================================================
public void relayoutAndResize(boolean overrideMaximize)
//===================================================================
{
	super.relayout(false);
	resize(overrideMaximize);
}
public void relayout(boolean repaint)
{
	//super.relayout(repaint);
	relayoutAndResize(true);
}
//===================================================================
public boolean isPopup() {return popupController != null;}
//===================================================================

//===================================================================
void addChildFrame(Frame cf)
//===================================================================
{
	childFrames = mVector.add(childFrames,cf);
	cf.parentFrame = this;
}
//===================================================================
void removeChildFrame(Frame cf)
//===================================================================
{
	if (childFrames != null) childFrames.remove(cf);
	cf.parentFrame = null;
}

/**
* This is set to either Gui.FILL_FRAME or Gui.CENTER_FRAME depending on the option chosen
* when it was shown/exec'ed
**/
public int displayOptions = 0;

protected CellPanel trueBottom = new CellPanel();
//==================================================================
{
	borderColor = Color.Black;
}
//==================================================================
public void make(boolean reMake)
//==================================================================
{
	if (made) {
		//getPreferredSize();
		return;
	}
	trueBottom.borderStyle = EDGE_SUNKEN;
	if (contentsOnly) top = trueBottom = bottom = null;
	if (!contentsOnly && top != null && !top.isEmpty()) addLast(top).setCell(HSTRETCH);
	if (contents != null)
		addLast(contents).setCell(STRETCH).setControl(FILL|CENTER);
	if (!contentsOnly) {
		if (bottom != null && !bottom.isEmpty())
			trueBottom.addNext(bottom).setCell(HSTRETCH);
		if (trueBottom != null && !trueBottom.isEmpty())
			addLast(trueBottom).setCell(HSTRETCH);
	}
	//calculatePreferredSize(null);
	super.make(reMake);
	if (top != null && top.isEmpty()) top = null;
	if (bottom != null && bottom.isEmpty()) bottom = null;
	if (trueBottom != null && trueBottom.isEmpty()) trueBottom = null;
	//top = trueBottom = bottom = null;
}
//==================================================================
public void pressedOutside(Point whereOnScreen)
//==================================================================
{
	postEvent(new FrameEvent(FrameEvent.PRESSED_OUTSIDE,this,whereOnScreen));
}
//==================================================================
public void setRect(int x,int y,int w,int h,Control relativeTo)
//==================================================================
{
	if (relativeTo != null) {
		Point p = Gui.getPosInParent(relativeTo,getParent(),Point.getCached(0,0));
		x+=p.x; y+=p.y;
		p.cache();
	}
	setRect(x,y,w,h);
}
/*
//==================================================================
public void doPaint(Graphics g,Rect r)
//==================================================================
{
	int flags = getModifiers(true);
	if (!((flags & Invisible) == 0)) return;
	doBackground(g);
	super.doPaint(g,r);
}
*/

//==================================================================
public void setRect(int x,int y,int w,int h)
//public void resizeTo(int w,int h)
//==================================================================
{
	int lastHeight = this.height, lastWidth = this.width;
	super.setRect(x,y,w,h);
	//super.resizeTo(w,h);
	for (Iterator it = mVector.iterator(childFrames); it.hasNext();){
		Frame f = (Frame)it.next();
		if (f == this) continue;
		if (savedScreen == null) f.eraseSavedScreen();
		if ((f.width == lastWidth && f.height == lastHeight)
			||(f.displayOptions & Gui.FILL_FRAME) != 0){
			f.setRect(0,0,width,height);
		}else if ((f.displayOptions & Gui.CENTER_FRAME) != 0){
			f.setRect((width-f.width)/2,(height-f.height)/2,f.width,f.height);
		}else
			f.resetRect();
	}
	/*
	for (ewe.util.Iterator kids = getChildren(); kids.hasNext();){
		Control c = (Control)kids.next();
		if (c instanceof Frame) c.resetRect();
	}
	*/
	if (savedScreen != null) savedScreen.restore();
	if (doSaveScreen){//!(parent instanceof Window)){
		savedScreen = Gui.saveScreen(getWindow(),Gui.getAppRect(this),doSaveScreen);
	}
}
//==================================================================
public void eraseSavedScreen()
//==================================================================
{
	if (savedScreen != null) savedScreen.free();
	savedScreen = null;
}
//==================================================================
/**
* This will add the frame to the container and call a make() on it.
* This also sets the frame to be modal.
* If you specify an option of Gui.FILL_FRAME or Gui.CENTER_FRAME then the
* frame will be positioned and displayed on screen. If not 
* you will have to call setRect()/repaintNow() on the frame to cause it
* to be positioned and painted.
*/
public void exec(Container parent,int options) {Gui.execFrame(this,parent,options);}
/**
* This will add the frame to the container and call a make() on it.
* This also sets the frame to be non-modal.
* If you specify an option of Gui.FILL_FRAME or Gui.CENTER_FRAME then the
* frame will be positioned and displayed on screen. If not 
* you will have to call setRect()/repaintNow() on the frame to cause it
* to be positioned and painted.
*/
public void show(Container parent,int options) {Gui.showFrame(this,parent,options);}
/**
* This closes the frame.
*/
public void hide(){Gui.hideFrame(this);}

/*
static WeakSet sipResized = new WeakSet();

Rect beforeSip;
*/
//-------------------------------------------------------------------
void hidden()
//-------------------------------------------------------------------
{
	if (lastClickedControl != null && lastClickedControl.isChildOf(this)) lastClickedControl = null;
	if (clipOwner != null && clipOwner.isChildOf(this)) clipOwner = null;
	//sipResized.remove(this);	
}
/*
//-------------------------------------------------------------------
static void checkCurrentSip()
//-------------------------------------------------------------------
{
	if ((Gui.getSIP(null) & SIPConstants.SIP_IS_ON) == SIPConstants.SIP_IS_ON) return;
	Window.visibleWidth = Window.visibleHeight = 0;
	if (sipResized.isEmpty()) return;
	SurfaceSIPEvent ev = new SurfaceSIPEvent();
	ev.type = ev.SIP_HIDDEN;
	checkSip(ev);
}
//-------------------------------------------------------------------
static void checkSip(SurfaceSIPEvent ev)
//-------------------------------------------------------------------
{
	if (sipResized.isEmpty()) return;
	if (ev.type == SurfaceSIPEvent.SIP_HIDDEN){
		Object [] all = sipResized.getRefs();
		for (int i = 0; i<all.length; i++){
			Frame f = (Frame)all[i];
			if (f != null) f.onEvent(ev);
		}
	}
}
//-------------------------------------------------------------------
static boolean hasSipResized(Window win)
//-------------------------------------------------------------------
{
	if (sipResized.isEmpty()) return false;
	Object [] all = sipResized.getRefs();
	for (int i = 0; i<all.length; i++){
		Frame f = (Frame)all[i];
		if (f != null){
			if (win == null) return true;
			else if (f.getWindow() == win) return true;
		}
	}
	return false;
}
*/
// TODO override fillSip in FormFrame and return true.

protected boolean fillSip(int height, boolean unfill)
{
	return false;
}
/*
//===================================================================
void sipOn(final int vw,final int vh)
//===================================================================
{
	if (width == 0 && height == 0){
		Vm.callBackInSystemThread(new CallBack(){
			public void callBack(Object data){
				sipOn(vw,vh);
			}
		},null);
		return;
	}
	if (fillSip(vh,false)) return;
	Rect r = getRect();
	if (r.x+r.width > vw || r.y+r.height > vh){
		if (r.height <= vh) {
			//beforeSip = null;
			Gui.moveFrameTo(this,r.set(r.x,((vh-r.height)/2),r.width,r.height));
			//sipResized.remove(this);
			//ewe.sys.Vm.messageBox("Setting!","beforeSip is set to NULL!",0);
		}else{
			sipResized.add(this);
			beforeSip = r;
			Gui.moveFrameTo(this,new Rect().set(0,0,vw,vh));
			//ewe.sys.Vm.messageBox("Setting!","beforeSip is set to not NULL!",0);
		}
	}else{
		//ewe.sys.Vm.messageBox("Setting!","beforeSip is set to NULL!",0);
		//beforeSip = null;
		//sipResized.remove(this);
	}
}

private class sipChange {
	int newYPos;
	boolean sipShouldFill;
	Control resizedControl;
	int oldControlYPos;
	int oldControlHeight;
	
	boolean sameAs(sipChange old)
	{
		return 
			newYPos == old.newYPos &&
			sipShouldFill == old.sipShouldFill &&
			resizedControl == old.resizedControl &&
			oldControlYPos == old.oldControlYPos &&
			oldControlHeight == old.oldControlHeight;
	}
}
*/

//==================================================================
public void onEvent(Event ev)
{
	if (ev instanceof SurfaceSIPEvent){
		if (fillSip(((SurfaceSIPEvent)ev).visibleHeight,ev.type == SurfaceSIPEvent.SIP_HIDDEN))
			return;
		if (true) return;
		
		
		/*
		
		if (resizeOnSIP){
			//System.out.println("RS: "+(ev.type == SurfaceSIPEvent.SIP_SHOWN));
			int vw = ((SurfaceSIPEvent)ev).visibleWidth, vh =((SurfaceSIPEvent)ev).desktopHeight;//visibleHeight;
			if (ev.type == SurfaceSIPEvent.SIP_SHOWN){
				sipOn(vw,((SurfaceSIPEvent)ev).visibleHeight);
			}else if (ev.type == SurfaceSIPEvent.SIP_HIDDEN){
				if (fillSip(0,true)) return;
				if (beforeSip != null){
					Gui.moveFrameTo(this,beforeSip);
					beforeSip = null;
					sipResized.remove(this);
				}else{
					//ewe.sys.Vm.messageBox("Null!","beforeSip is NULL",0);
				}
			}
		}
		*/
	}else if (ev instanceof FrameEvent){
		super.onEvent(ev);
	}else
		super.onEvent(ev);
}
//##################################################################
}
//##################################################################

