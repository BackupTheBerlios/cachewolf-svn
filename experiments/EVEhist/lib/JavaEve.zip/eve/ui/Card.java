package eve.ui;

import eve.fx.Color;
import eve.fx.IImage;
import eve.fx.IconAndText;

/**
* A Card represents a Control that has been added to a Control that implements MultiPanel - 
* a CardPanel, for example.
**/
//##################################################################
public class Card{
//##################################################################
/**
* This is the longName given to the item when it was added to the MultiPanel.
**/
public String longName;
/**
* This is the short (tab) name given to the item when it was added to the MultiPanel.
**/
public String tabName;
/**
* This is the CellPanel which contains the item which was added to the MultiPanel. If
* the item added already was a CellPanel, then this MAY be the added item.
**/
public CellPanel panel;
/**
* This is the item that was added to the MultiPanel.
**/
public Control item;
/**
* If this is not null then this will be displayed instead of the tab text. Use an IconAndText
* if you want to display both an Icon and text.
**/
public IImage image;
/**
* If this is not null then it will be displayed when the card is <b>not</b> selected.
**/
public IImage closedImage;
/**
* If this is not null then this will be the tool tip for the tab. Otherwise the tool tip will be the image
* (if there is one) or tab name.
**/
public Object tip;
/**
 * An optional hot-key to for the Card. Use KeyEvent.toKey() to create the hotKey value.
 */
public int hotKey;
/*
* These are flags that apply to the Card. Currently defined flags are DISABLED and HIDDEN.
*/
public int flags;
/**
* A flag.
**/
public static final int DISABLED = 0x1;
/**
* A flag.
**/
public static final int HIDDEN = 0x2;
/**
* A flag.
**/
public static final int CLOSEABLE = 0x4;
/**
* A flag.
**/
public static final int ALREADY_MADE = 0x8;

/**
 * Call this after you have specified the tab name. This will create an IconAndText image for the
 * tab and, tells the Card to
 * display an icon only when it is deslected ONLY if it is running on a PDA sized screen.
 * @param icon The icon to use with this tab.
* @return itself.
*/
//===================================================================
public Card iconize(IImage icon)
//===================================================================
{
	return iconize(icon,Gui.screenIs(Gui.PDA_SCREEN));
}
/**
 * Call this after you have specified the tab name. This will create an IconAndText image for the
 * tab AND set the closedImage to be the icon.
 * @param icon The icon to use with this tab.
 * @param iconOnlyWhenClosed Indicates that only the icon should be displayed when the tab
	is not selected.
* @return itself.
*/
//===================================================================
public Card iconize(IImage icon,boolean iconOnlyWhenClosed)
//===================================================================
{
	image = new IconAndText(icon,tabName,null);
	((IconAndText)image).textColor = Color.Black;
	if (iconOnlyWhenClosed) closedImage = icon;
	else closedImage = null;
	return this;
}
/**
 * Call this after you have specified the tab name. This will create an IconAndText image for the
 * tab AND set the closedImage to be the icon. The image is retrieved from the ImageCache.
 * @param imageName The name of the icon.
 * @param iconOnlyWhenClosed Indicates that only the icon should be displayed when the tab
	is not selected.
* @return itself.
 */
//===================================================================
public Card iconize(String imageName,boolean iconOnlyWhenClosed)
//===================================================================
{
	return iconize(Control.loadImage(imageName),iconOnlyWhenClosed);
}
/**
 * This iconizes the tab with the icon of the specified name and, tells the Card to
 * display an icon only when it is deslected ONLY if it is running on a PDA sized screen.
 * @param imageName The name of the icon.
 * @return this Card.
 */
//===================================================================
public Card iconize(String imageName)
//===================================================================
{
	return iconize(imageName,Gui.screenIs(Gui.PDA_SCREEN));
}
public Card()
{
	
}
//===================================================================
public Card(Control c,String tn,String ln,boolean autoScroll)
//===================================================================
{
	setup(c,tn,ln,autoScroll);
}

public void setup(Control c,String tn,String ln,boolean autoScroll)
{
	item = c;
	longName = ln;
	tabName = tn;
	if (longName == null) longName = tabName;
	panel = new CellPanel();

	if (autoScroll) {
		ScrollableHolder sh = new ScrollableHolder(c);
		ScrollablePanel sp = new ScrollBarPanel(sh);
		sh.modify(0,sh.TakeControlEvents);
		//sp.modifyScrollers(sp.SmallControl,0);
		panel.addLast(sp);
		//who = panel.addLast(sp);
		//sh.stretchComponent = true;
		sh.scrollPercent = 50;
	}else {
		panel.addLast(c);
	}
}


//##################################################################
}
//##################################################################

