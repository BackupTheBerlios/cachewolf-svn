package eve.ui;
import java.util.Iterator;
import java.util.Vector;

import eve.fx.Dimension;
import eve.fx.IImage;
import eve.sys.Vm;
import eve.ui.event.MultiPanelEvent;
/**
* A CardPanel is a simple implementation of a MultiPanel and it provides
* no user controls for selecting an item to be displayed. It can be used
* as the main container for more complex MultiPanel implementations, such
* as a Tabbed Panel (see mTabbedPanel).
* <p>
* There are no methods to remove items from the CardPanel, but you can do
* this manually by removing the card from the cards Vector. If the item
* you are removing happens to be selected, then call select(-1) to deselect it
* (or select a different item) before removing it. You will then need to repaint
* the control using the CardPanel again.
**/
//##################################################################
public class CardPanel extends Container implements MultiCardPanel{
//##################################################################
/**
* The cards.
**/
public Vector cards = new Vector();
/**
* The selected card, or -1 if none is selected.
**/
public int selectedItem = -1;
/**
* If this is true, then the items are placed in ScrollBarPanels before
* being added to the MultiPanel.
@deprecated use modifyCardOptions(OPTION_AUTO_SCROLL,0) instead;
**/
public boolean autoScroll = false;
/**
If this is set to a control, then that control will gain the focus if a control
within the card panel has the focus, and then the CardPanel is set such that no
item is selected (using select(-1)), then the focusOnHide control will be given
the focus.
**/
public Control focusOnHide;
/**
* If this is set true, then when the displayed control is changed, the SIP will be turned off.
**/
public boolean clearSipOnChange = false;
/**
* Set this true if you dont want the focus to move to the Card on the next select(). It is set
* back to false after each select() call.
* @deprecated use modifyCardOptions(OPTION_DONT_FOCUS_ON_NEXT_SELECT,0) instead;
**/
public boolean dontFocusOnNextSelect = false;
/**
* @deprecated use modifyCardOptions(OPTION_FOCUS_ON_CONTROLS_AFTER_SELECTION_HOT_KEY,0) instead;
**/
public boolean focusOnControlsAfterSelectHotKey = false;

private int myOptions;

public int modifyCardOptions(int toSet, int toClear)
{
	if (dontFocusOnNextSelect) myOptions |= OPTION_DONT_FOCUS_ON_NEXT_SELECT;
	if (focusOnControlsAfterSelectHotKey) myOptions |= OPTION_FOCUS_ON_CONTROLS_AFTER_SELECTION_HOT_KEY;
	if (autoScroll) myOptions |= OPTION_AUTO_SCROLL;
	int no = myOptions;
	no |= toSet;
	no &= ~toClear;
	if (no != myOptions){
		myOptions = no;
		dontFocusOnNextSelect = (myOptions & OPTION_DONT_FOCUS_ON_NEXT_SELECT) != 0;
		focusOnControlsAfterSelectHotKey = (myOptions & OPTION_FOCUS_ON_CONTROLS_AFTER_SELECTION_HOT_KEY) != 0;
		autoScroll = (myOptions & OPTION_AUTO_SCROLL) != 0;
	}
	return no;
}
/*
public int modifyCardOptions(int toSet, int toClear)
{
	int op = 0;
	if (dontFocusOnNextSelect) op |= OPTION_DONT_FOCUS_ON_NEXT_SELECT;
	if (focusOnControlsAfterSelectHotKey) op |= OPTION_FOCUS_ON_CONTROLS_AFTER_SELECTION_HOT_KEY;
	int no = op;
	no |= toSet;
	no &= ~toClear;
	if (no != op){
		dontFocusOnNextSelect = (op & OPTION_DONT_FOCUS_ON_NEXT_SELECT) != 0;
		focusOnControlsAfterSelectHotKey = (op & OPTION_FOCUS_ON_CONTROLS_AFTER_SELECTION_HOT_KEY) != 0;
	}
	return no;
}
*/
//===================================================================
public int getSelectedItem() {return selectedItem;}
//===================================================================
public ControlIterator getSubControls(ControlIterator it)
{
	return ControlIterator.unNull(it).setFor(getMySubControls());
}
private Iterator getMySubControls()
//==================================================================
{
	Vector v = new Vector();
	for (Iterator it = cards.iterator(); it.hasNext();){
		Card c = (Card)it.next();
		v.add(c.panel);
	}
	return v.iterator();
}
//==================================================================
public Control addItem(Control item,String tabName,String longName)
//==================================================================
{
	addCard(item,tabName,longName);
	return item;
}
public Card createNewCard()
{
	return new Card();
}
public Card newCard(Control toAdd, String cardName, String longCardName,boolean autoScroll)
{
	Card c = createNewCard();
	c.setup(toAdd,cardName,longCardName,autoScroll);
	return c;
}
public Card addCard(Control toAdd, String cardName, String longCardName) {
	Card c = newCard(toAdd,cardName,longCardName,autoScroll);
	c.panel.closedFocus = (Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_NO_PEN) == 0;
	cards.add(c);
	return c;
}

//-------------------------------------------------------------------
protected Card findCard(Control item,String tabName)
//-------------------------------------------------------------------
{
	for (int i = 0; i<cards.size(); i++){
 		Card c = (Card)cards.get(i);
		if (item != null) {
			if (c.item == item) return c;
		}else if (tabName != null){
			if (tabName.equals(c.tabName)) return c;
		}
	}
	return null;
}
/**
Focus on the first control on the active panel.
**/
/*
//===================================================================
public void focusFirst()
//===================================================================
{
	if (curCard == null) return;
	if (curCard.panel == null) return;
	curCard.panel.focusFirst();
}
*/
//-------------------------------------------------------------------
protected Card curCard;
//-------------------------------------------------------------------
protected Control getFirstFocus()
//-------------------------------------------------------------------
{
	if (curCard == null) return null;
	if (curCard.panel == null) return null;
	return curCard.panel.getFirstFocus();
}
public void select(Card card)
{
	selectAndPaint(card);
}
/**
 * This is the bottom level method that selects a new card.
 * @param who the Card to be selected.
 */
protected void selectACard(Card who)
//-------------------------------------------------------------------
{
	try{
		if ((myOptions & OPTION_DONT_FOCUS_ON_ANY_SELECT) != 0)
			dontFocusOnNextSelect = true;
		selectedItem = cards.indexOf(who);
		boolean hadFocus = false;
		if (made)
			if (curCard != null && curCard != who){
				Control lf = Gui.focusedControl();
				hadFocus = lf != null ? lf.isChildOf(this) : false;
				if (hadFocus) Gui.takeFocus(null,ByRequest);
				remove(curCard.panel);
			}
		curCard = who;
		if (made && clearSipOnChange) Gui.setSIP(getWindow(),0);//Gui.freezeSIP(true,0,getWindow());
		if (made)
		 	if (who != null) {
				add(who.panel);
				if ((who.flags & Card.ALREADY_MADE) == 0) {
					who.panel.make(false);
					who.flags |= Card.ALREADY_MADE;
				}
				who.panel.setRect(0,0,width,height);
				if (hadFocus && !dontFocusOnNextSelect) who.panel.focusFirst();
				else if (!dontFocusOnNextSelect){
					Gui.takeFocus(getParent(),ByRequest);
				}
				if (hasModifier(SendUpUIEvents,false)) who.panel.modifyAll(SendUpUIEvents,0,true);
			}
	}finally{
		dontFocusOnNextSelect = false;
	}
}
//-------------------------------------------------------------------
protected void selectAndPaint(Card c)
//-------------------------------------------------------------------
{
	//synchronized(guiLock){
		if (c != null && c != curCard) {
			int got = c.panel.modify(Invisible,0);
			selectACard(c);
			c.panel.restore(got,Invisible);
			c.panel.repaintNow();
			postEvent(new MultiPanelEvent(MultiPanelEvent.SELECTED,this,cards.indexOf(c)));
		}
	//}
}
//===================================================================
public void select(Control item){ selectAndPaint(findCard(item,null));}
//===================================================================
public void select(String tabName){ selectAndPaint(findCard(null,tabName));}
//===================================================================
public void select(int index)
//===================================================================
{
	//synchronized(guiLock){
		if (index < cards.size() && index >= 0)
			selectAndPaint((Card)cards.get(index));
		else {
			Control focusTo = null;
			Control c = Gui.focusedControl();
			if (c != null)
				if (c.isChildOf(this))
					focusTo = focusOnHide;
			selectACard((Card)null);
			postEvent(new MultiPanelEvent(MultiPanelEvent.SELECTED,this,-1));
			if (focusTo != null && !dontFocusOnNextSelect)
				Gui.takeFocus(focusTo,ByRequest);
		}
	//}
}
//===================================================================
public Card getItem(int index) {if (index < cards.size() && index >= 0) return (Card)cards.get(index); return null;}
//===================================================================
public Card getItem(Control item){return findCard(item,null);}
//===================================================================
public int getItemCount() {return cards.size();}
//===================================================================

protected boolean made = false;
//==================================================================
public void make(boolean remake)
//==================================================================
{
	made = true;
	//System.out.println("Making cards");
	for (int i = 0; i<cards.size(); i++){
 		Card c = (Card)cards.get(i);
		c.panel.borderWidth = borderWidth;
		c.panel.borderStyle = borderStyle;
		add(c.panel);
		c.panel.make(remake);
		c.flags |= Card.ALREADY_MADE;
	}
	getPreferredSize(null);
	for (int i = 0; i<cards.size(); i++){
 		Card c = (Card)cards.get(i);
		remove(c.panel);
		//c.panel.make(remake);
	}
	boolean df = dontFocusOnNextSelect;
	dontFocusOnNextSelect = true;
	if (cards.size() != 0)
		if (curCard == null)
			selectACard((Card)cards.get(0));
		else
			selectACard(curCard);
	dontFocusOnNextSelect = df;
	super.make(remake);
}

//===================================================================
public void shown()
//===================================================================
{
	for (int i = 0; i<cards.size(); i++)
		((Card)cards.get(i)).panel.shown();
	super.shown();
}
protected boolean gotSize;

//==================================================================
protected void calculateSizes()
//==================================================================
{
	int w = 0, h = 0;
	for (int i = 0; i<cards.size(); i++){
 		Card c = (Card)cards.get(i);

		Dimension r = c.panel.getPreferredSize(null);
		if (r.width > w) w = r.width;
		if (r.height > h) h = r.height;
		//System.out.println("Card preferredSize: "+Geometry.toString(r));
	}
	preferredWidth = w;
	preferredHeight = h;
}

//==================================================================
public void setRect(int x,int y,int width,int height)
//==================================================================
{
	super.setRect(x,y,width,height);
	if (curCard != null)
	curCard.panel.setRect(0,0,width,height);
}
public CardPanel getCardPanel() {
	return this;
}


public Card addCard(Control toAdd, IImage icon, String cardName,
		String longCardName, int options) {
	Card c = addCard(toAdd,cardName,longCardName);
	if (icon != null){
		c.iconize(icon);
		if ((options & ADD_OPTION_DONT_SHOW_TEXT_WITH_ICON) != 0)
			c.image = icon;
	}
	return c;
}
public CellPanel getExtraControlArea(int whichArea)
{
	return null;
}

//##################################################################
}
//##################################################################
