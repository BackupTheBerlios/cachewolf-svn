/*
 * Created on Aug 8, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import eve.fx.Color;
import eve.fx.Sound;
import eve.sys.Vm;

/**
 * This class is used to hold constants that determine the look and feel of
 * the application.
 * 
 * @author Michael L Brereton
 *
 */
//####################################################
public class GuiStyle implements UIConstants{

	private GuiStyle(){}
	
	public static boolean globalDrawFlat;
	public static boolean globalPalmStyle;
	public static boolean globalSmallControls;
	public static int standardEdge = EDGE_RAISED | (((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_NO_MOUSE_POINTER) != 0) ? BDR_OUTLINE : 0);
	public static int standardBorder = EDGE_ETCHED;
	public static int inputEdge = EDGE_ETCHED;
	public static int buttonEdge = EDGE_RAISED |(((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_NO_MOUSE_POINTER) != 0) ? BDR_OUTLINE : 0);
	public static int checkboxEdge = EDGE_SUNKEN|BDR_OUTLINE;
	/**
	* Used with setStyle.
	**/
	public static final int STYLE_ETCHED = 1;
	/**
	* Used with setStyle.
	**/
	public static final int STYLE_3D = 0;
	/**
	* Used with setStyle.
	**/
	public static final int STYLE_SOFT = 2;
	/**
	* Used with setStyle.
	**/
	public static final int STYLE_PALM = 3;
	/**
	 * Set the style of Controls within an application.
	 * This sets the look of the Controls within an application to be either a Windows style 3D look
		or a Java style etched look. To make all of your controls look flat set the "Control.globalDrawFlat"
		variable true. You should also call Color.setMonochrome(true) if you want high-contrast flat controls.
	 * @param style STYLE_ETCHED or STYLE_3D
	 */
//	===================================================================
	public static final void setStyle(int style)
//	===================================================================
	{
		globalDrawFlat = globalPalmStyle = false;
		if (style == STYLE_ETCHED || style == STYLE_SOFT){
			standardBorder =  buttonEdge = checkboxEdge = inputEdge = EDGE_ETCHED|((style == STYLE_SOFT) ? BF_SOFT : 0);
			standardEdge = EDGE_ETCHED;
		}else if (style == STYLE_PALM){
			inputEdge = BDR_OUTLINE|BF_BOTTOM;
		  buttonEdge = BF_SOFT|BF_RECT;
			globalDrawFlat = globalPalmStyle = true;
		}else{
			standardBorder = EDGE_ETCHED;
			buttonEdge = standardEdge = EDGE_RAISED|
			(((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_NO_MOUSE_POINTER) != 0) ? BDR_OUTLINE : 0);
			checkboxEdge = inputEdge = EDGE_SUNKEN;
		}
		buttonEdge |= BF_BUTTON;
		if (style == STYLE_PALM) Color.setMonochrome(true);
		else Color.setMonochrome(false);
	}
/**
 * Set this to BEEP_NONE to silince the popup beep on mobile devices.
 */
	public static int popupBeep = Sound.BEEP_POPUP;
	
	public static boolean fadeInMenus = false;
}

//####################################################
