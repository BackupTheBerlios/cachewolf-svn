package eve.ui;

import eve.fx.Dimension;
import eve.fx.Font;
import eve.fx.FontMetrics;
import eve.fx.Fx;
import eve.fx.IImage;
import eve.fx.ImageCache;
import eve.fx.PixelBuffer;
import eve.fx.Point;
import eve.fx.Rect;
import eve.sys.ImageData;


/**
* The only purpose of this class is to provide space for Control's static variables and
* to keep the number of Fields in control below 64.
**/
//##################################################################
public abstract class ControlBase{
//##################################################################

static final int
	GotPenDown = 0x1, DidHoldDown = 0x2, PenIsOn = 0x4, IgnorePen = 0x8;

public static final int PEN_STATUS_GOT_PEN_DOWN = GotPenDown;
public static final int PEN_STATUS_DID_HOLD_DOWN = DidHoldDown;
public static final int PEN_STATUS_PEN_IS_ON = PenIsOn;

public static boolean doubleBuffer = true;

public static final int TAG_BOOLEAN_KEEP_BELOW_SIP = 999;
public static final int TAKE_FIRST_PRESS = 1000;
/**
* You can use tags from TAG_USER_DATA up to and including  TAG_LAST_USER_DATA, which
* spans 1000 tags.
**/
public static final int TAG_USER_DATA = 1001;
/**
* You can use tags from TAG_USER_DATA up to and including  TAG_LAST_USER_DATA, which
* spans 1000 tags.
**/
public static final int TAG_LAST_USER_DATA = 2000;
public static boolean globalEnabled = true, globalEditable = true;
public static int doubleClickTime = 500;
public static Point pressPoint = new Point(0,0);
static boolean wantAnotherPenHeld = false;
public static boolean firstPress = true;
static long lastClick;
static Control lastClickedControl = null;
public static Control clipOwner;
static String emptyString = "";
static Point zeroPoint = new Point(0,0);
static DragContext reusedDrag = new DragContext();
/**
* This is set to be the current PenEvent in the onPenEvent() handler.
**/
//public// static 
//PenEvent Gui.currentPenPress();
public static String unnamed = "unnamed";
public static Control debugControl = null;
public static boolean debugFlag = false;
public static Object clipObject;
public static MenuItem [] clipItems;
/*
static Countdown holdTicker = new Countdown();
{
	holdTicker.idleQuitTime = 1000;
}
*/
/**
 * A convenience method for loading a picture via the cache - throwing an Exception
 * if it could not be found and could not be loaded. It calls ImageCache.cache.getImage().
 * @param imageName the name of the image. If it is null then null will be returned.
 * @return the image found or it throws an Exception if the image could not be found
 * or is of the wrong format.
 */
public static IImage loadImage(String imageName)
{
	IImage got = tryLoadImage(imageName,null);
	if (got == null) throw new IllegalArgumentException(imageName+" not found.");
	return got;
}
private static ImageCache controlCache;
private static boolean doubleIt;

public synchronized static boolean isDoubleSized()
{
	if (controlCache == null){
		controlCache = new ImageCache();
		VMOptions vo = VMOptions.getVMOptions();
		Font f = VMOptions.getApplicationDefaultFont();
		if (f != null){
			FontMetrics fm = Fx.getFontMetrics(f);
			doubleIt = (fm.getHeight() >= 24);
		}
	}
	return doubleIt;
}
/**
 * Double size the image only if it has a dimension less than 18 
 * and if the font is double sized.
 * @param im the image.
 * @return the new image or the old one if it does not need double sizing.
 */
public static ImageData doubleSizeIt(ImageData im)
{
	ImageData got = im;
	if (!isDoubleSized()) return im;
	int w = got.getImageWidth(), h = got.getImageHeight();
	if (doubleIt && h <= 17 && w <= 17){
		PixelBuffer pb = new PixelBuffer(got,new Rect(0,0,w,h),new Dimension(w*2,h*2),null);
		got = pb.toPicture();
		pb.free();
	}
	return got;
}
/**
 * A convenience method for loading a picture via the cache. It calls ImageCache.cache.tryImage().
 * @param imageName the name of the image. If it is null then the defaultImage will be
 * returned.
 * @param defaultImage a default image to return if the image could not be found and could not be loaded.
 * @return the image found or the defaultImage if not found.
 */
public static IImage tryLoadImage(String imageName, IImage defaultImage)
{
	isDoubleSized(); //Must call this to initialize controlCache.
	//
	if (imageName == null) return defaultImage;
	if (isDoubleSized()){
		String tryName = imageName;
		String ext = null;
		int idx = imageName.lastIndexOf('.');
		if (idx != -1) tryName = imageName.substring(0,idx);
		tryName += "-x2";
		if (idx != -1) tryName += imageName.substring(idx);
		IImage got = controlCache.tryImage(tryName,null);
		if (got != null) return got;
	}
	IImage got = controlCache.tryImage(imageName,defaultImage);
	IImage ret = (IImage)doubleSizeIt(got);
	if (ret != got) controlCache.putIntoCache(imageName,ret);
	return ret;
}
/**
 * This is the same object as Gui.guiLock;
 */
//public static Object guiLock = Gui.guiLock;

static{
	try{
		VMOptions.doApply();
	}catch(Throwable t){}
}

//##################################################################
}
//##################################################################

