package eve.ui;
import eve.fx.Dimension;
import eve.fx.Graphics;
import eve.fx.IImage;
import eve.fx.Rect;
/**
* This is a CheckBox which is displayed as a standard push button.
**/
//##################################################################
public class ButtonCheckBox extends CheckBox {
//##################################################################
{
	borderWidth = 1;
	modify(0,PreferredSizeOnly);
	borderStyle &= ~BDR_NOBORDER;
	//defaultAddMeCellConstraints = defaultAddMeControlConstraints = 0;
}
//==================================================================
protected void calculateSizes()
//==================================================================
{
	ButtonObject buttonObject = ButtonObject.getCached(this);
	Dimension d = buttonObject.calculateSize(new Dimension());
	preferredWidth = d.width; preferredHeight = d.height;
	buttonObject.cache();
}
//==================================================================
public void doPaint(Graphics g,Rect area)
//==================================================================
{
	int flags = getModifiers(true);
	if (!((flags & Invisible) == 0)) return;
	ButtonObject buttonObject = ButtonObject.getCached(this);
	buttonObject.pressed = buttonObject.pressed || getState();
	buttonObject.paint(g);
	buttonObject.cache();
}
//==================================================================
protected void doPaintData(Graphics g)
//==================================================================
{
	doPaint(g,getDim(null));
}
//==================================================================
public ButtonCheckBox(){super();}
public ButtonCheckBox(String txt) {super(txt);}
public ButtonCheckBox(IImage img) {this(""); image = img;}
//==================================================================


//##################################################################
}
//##################################################################

