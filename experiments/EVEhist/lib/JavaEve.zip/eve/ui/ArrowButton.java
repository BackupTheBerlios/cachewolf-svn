package eve.ui;
import eve.fx.Color;
import eve.fx.Graphics;
import eve.fx.Rect;
/**
* This is a button which displays an arrow in its center.
**/
//##################################################################
public class ArrowButton extends Button {
//##################################################################
/**
* This specifies the arrow direction. It can be Up, Down, Left or Right.
**/
public int style = Up;
//==================================================================
public ArrowButton(int st){style = st;}
//==================================================================
//==================================================================
protected void calculateSizes()
//==================================================================
{
	super.calculateSizes();
	preferredWidth = preferredHeight = 15;
	if (hasModifier(SmallControl,true)) preferredWidth = preferredHeight = 7;
	else if (isDoubleSized()) preferredWidth = preferredHeight = 30;
}

//==================================================================
public void doPaint(Graphics g,Rect area)
//==================================================================
{
	if (GuiStyle.globalPalmStyle) borderStyle = BDR_NOBORDER;
	int flags = getModifiers(true);
	if (!((flags & Invisible) == 0)) return;
	int spacing = 4;
	Rect d = getDim(null);
	boolean af = (flags & DrawFlat) != 0, as = (flags & SmallControl) != 0;
	if (af) spacing = 2;
	if (as) {
		spacing = 0;
	}
	ButtonObject buttonObject = ButtonObject.getCached(this);
	try{
		buttonObject.paint(g);
		boolean soft = buttonObject.soft;
		d.width -= spacing*2; d.height -= spacing*2;
		d.x += spacing; d.y += spacing;
		if (pressState && !as && !af && !soft) { d.x++;d.y++;}
		Color c = getImageColor();
		if (!(((flags & (NotEditable|DisplayOnly)) == 0) || ((flags & NotAnEditor) != 0)) || !(((flags & Disabled) == 0)  || ((flags & AlwaysEnabled) != 0))) c = Color.DarkGray;
		g.setColor(c);
		if (style == Left || style == Right) {
			g.drawHorizontalTriangle(d,style == Left);
			return;
		}else{
			g.drawVerticalTriangle(d,style == Up);
			return;
		}
	}finally{
		buttonObject.cache();
	}
}

//##################################################################
}
//##################################################################

