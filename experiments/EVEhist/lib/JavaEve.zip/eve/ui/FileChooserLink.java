package eve.ui;

import eve.fx.IImage;
import eve.fx.FontMetrics;
import eve.fx.IconAndText;
import eve.io.File;

//##################################################################
public class FileChooserLink{
//##################################################################
public IImage icon;
public String name;
public String path;
//===================================================================
public FileChooserLink(String name,String path,IImage icon)
//===================================================================
{
	this.name = name;
	this.path = path;
	this.icon = icon == null ? (IImage)File.getIcon(File.ClosedFolderIcon) : (IImage)icon;
}
//===================================================================
public FileChooserLink(String aPath,File fileModel)
//===================================================================
{
	if (fileModel == null) fileModel = File.getNewFile();
	File f = fileModel.getNew(aPath);
	File par = f.getParentFile();
	this.path = aPath;
	this.name = f.getName();
	this.icon = (IImage)File.getIcon(File.ClosedFolderIcon);
	if (par == null && aPath.indexOf(':') != -1) this.icon = (IImage)File.getIcon(File.DriveIcon);
	if (this.icon != null) this.icon = (IImage)Control.doubleSizeIt(this.icon);
}
//===================================================================
public MenuItem addToMenu(ChoiceControl m,FontMetrics fm)
//===================================================================
{
	MenuItem mi = new MenuItem(name);//m.addItem(name);
	mi.image = new IconAndText(icon,name,fm).setColor(null,null);
	mi.data = this;
	m.addItem(mi);
	return mi;
}
//===================================================================
public String toString()
//===================================================================
{
	return path;
}
/**
* This checks for equality of Paths. The object can be another link, or a file or a path string.
**/
//===================================================================
public boolean equals(Object other)
//===================================================================
{
	if (other == null) return false;
	other = other.toString();
	if (other == null) return false;
	return path.equals(other);
}
//===================================================================
public File toFile(File fileSystem)
//===================================================================
{
	if (fileSystem == null) return File.getNewFile(path);
	return fileSystem.getNew(path);
}
//##################################################################
}
//##################################################################

