/*
 * Created on Mar 16, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import java.util.Vector;

import eve.fx.Point;
import eve.ui.event.PenEvent;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class EventThreadData {

	public PenEvent currentPenPress;
	public Point penPoint = new Point();
	Vector movedRefs;
}
//####################################################
