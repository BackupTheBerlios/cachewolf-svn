/*
 * Created on Jul 31, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import eve.fx.Color;
import eve.fx.Dimension;
import eve.fx.FontMetrics;
import eve.fx.IImage;
import eve.fx.IconAndText;
import eve.fx.Point;
import eve.fx.Rect;
import eve.fx.Sound;
import eve.fx.gui.IKeys;
import eve.fx.gui.SIPConstants;
import eve.fx.gui.WindowConstants;
import eve.fx.gui.WindowCreationData;
import eve.fx.gui.WindowSurface;
import eve.io.File;
import eve.io.FileChooserParameters;
import eve.sys.Cache;
import eve.sys.DataConverter;
import eve.sys.Device;
import eve.sys.Handle;
import eve.sys.IRegistryKey;
import eve.sys.Locale;
import eve.sys.Task;
import eve.sys.Type;
import eve.sys.Vm;
import eve.sys.VmConstants;
import eve.ui.event.ControlEvent;
import eve.ui.event.FrameEvent;
import eve.ui.event.PenEvent;
import eve.util.CharArray;

/**
 * This class contains only static methods that used by the eve.ui
 * GUI package.
 * 
 * @author Michael L Brereton
 *
 */
//####################################################
public class Gui implements UIConstants {
	/**
	 * Many GUI classes which display data as String need to be formatted for
	 * display. This class is used to convert data values from one form to 
	 * another in a FieldTransfer object. With the classes in the Eve ui library
	 * if a FieldTransfer is defined but no DataConverter is assigned to it,
	 * then this value will be used. And if this value is null then the 
	 * default Locale is used.
	 */
	public static DataConverter guiDataConverter;
	/**
	* If you show/exec a Frame with a null parent frame then if NullParentFrameToMainApp
	* is true, it will use the main frame of the mApp of the program. Otherwise it will
	* show the Frame in a new window. By default it is true.
	**/
	public static boolean NullParentFrameToMainApp = true;

	/**
	 * If a Form is displayed non-modally (using show()), but another Form has already
	 * been displayed modally (using execute()), then the new Form will
	 * not be displayed properly and this can cause event problems, especially
	 * on systems that do not allow multiple Windows. By default a show() will
	 * be changed into an execute() if a modal Form is already displayed. To
	 * disable this behaviour set this value to true.
	 */
	public static boolean disableModalProtection = false;
	
	private static boolean simulateSoftKeys = false;
	
	public static boolean hasMousePointer = !((Vm.getParameter(Vm.VM_FLAGS) & (Vm.VM_FLAG_NO_MOUSE_POINTER)) == (Vm.VM_FLAG_NO_MOUSE_POINTER));
	public static boolean hasPen = (Vm.getParameter(Vm.VM_FLAGS) & (Vm.VM_FLAG_NO_PEN)) == 0;
	public static boolean hasKeyboard = (Vm.getParameter(Vm.VM_FLAGS) & (Vm.VM_FLAG_NO_KEYBOARD)) == 0;
	public static boolean isSmartPhone = (Vm.getParameter(Vm.VM_FLAGS) & (Vm.VM_FLAG_NO_PEN|Vm.VM_FLAG_HAS_SOFT_KEYS)) == (Vm.VM_FLAG_NO_PEN|Vm.VM_FLAG_HAS_SOFT_KEYS);
	public static boolean isPDA = (Vm.getParameter(Vm.VM_FLAGS) & (Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD)) == (Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD);
	public static boolean useNativeTextInput = (Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_USE_NATIVE_TEXT_INPUT) != 0;
	public static boolean hasSoftKeys = simulateSoftKeys || (Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_HAS_SOFT_KEYS) == Vm.VM_FLAG_HAS_SOFT_KEYS;
	public static boolean hasSoftKeyboard = (Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_USE_SOFT_KEYPAD) == Vm.VM_FLAG_USE_SOFT_KEYPAD;
	/**
	By default, this is set to: !hasKeyboard || isSmartPhone || isPDA<p>
	but you can change it as you wish.
	**/
	public static boolean noHotLabels = !hasKeyboard || isSmartPhone || isPDA;
	/**
	 * Hashtable of known GUI values.
	 * <pre>
	 * "ActiveTitleBarColor" = Color of active title bar.
	 * </pre>
	 */
	public static Hashtable guiValues = new Hashtable();
	
	/**
	 * Return the default DataConverter for displaying formatted data.
	 * If guiDataConverter is not null, then that value is returned.
	 * If guiDataConverter is null, then Locale.getDefault() is returned.
	 * @return
	 */
	public static DataConverter getDefaultConverter()
	{
		DataConverter d = guiDataConverter;
		return d == null ? Locale.getDefault() : d;
	}
	public static Color getColorFrom(byte[] data, int whichColor)
	{
		if (data == null) return null;
		int offset = whichColor*4;
		if (data.length < offset+4) return null;
		Color c = new Color(data[offset] & 0xff,data[offset+1] & 0xff,data[offset+2] & 0xff);
		return c;
	}
	static Color putColorFrom(byte[] data, int whichColor, String key)
	{
		Color c = getColorFrom(data,whichColor);
		if (c != null) guiValues.put(key,c);
		else guiValues.remove(key);
		return c;
	}
	/**
	 * This resets the values of: hasMousePointer, hasPen, hasKeyboard, isSmartPhone, isPDA and noHotLabels
	 * depending on the new values of the VM parameters that may have changed.
	 */
	public static void resetFlags()
	{
		int p = Vm.getParameter(Vm.VM_FLAGS);
		hasMousePointer = (p & (Vm.VM_FLAG_NO_MOUSE_POINTER)) == 0;
		hasPen = (p & (Vm.VM_FLAG_NO_PEN)) == 0;
		hasKeyboard = (p & (Vm.VM_FLAG_NO_KEYBOARD)) == 0;
		isSmartPhone = (p & (Vm.VM_FLAG_NO_PEN|Vm.VM_FLAG_HAS_SOFT_KEYS)) == (Vm.VM_FLAG_NO_PEN|Vm.VM_FLAG_HAS_SOFT_KEYS);
		isPDA = (p & (Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD)) == (Vm.VM_FLAG_NO_MOUSE_POINTER|Vm.VM_FLAG_NO_KEYBOARD);
		useNativeTextInput = (p & Vm.VM_FLAG_USE_NATIVE_TEXT_INPUT) != 0;
		noHotLabels = !hasKeyboard || isSmartPhone || isPDA;
		hasSoftKeys = simulateSoftKeys || (p & Vm.VM_FLAG_HAS_SOFT_KEYS) == Vm.VM_FLAG_HAS_SOFT_KEYS;
		hasSoftKeyboard = (Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_USE_SOFT_KEYPAD) == Vm.VM_FLAG_USE_SOFT_KEYPAD;
		String wv = Vm.getProperty("windows.version","win32");
		boolean isMobile6 = wv.equalsIgnoreCase("mobile 6");
		boolean isMobile5 = isMobile6||wv.equalsIgnoreCase("mobile 5");
		screenSize = null;
		try{
			VMOptions vo = VMOptions.getVMOptions();
			if (vo.useDefaultColors){
				guiValues.remove(GuiValueKeys.ActiveTitleBarColor);
				guiValues.remove(GuiValueKeys.TitleBarTextColor);
			}else{
				IRegistryKey rk = Vm.getRegistryKey(true,"HKEY_LOCAL_MACHINE\\System\\GWE",false,false);
				if (rk != null){
					Object got = rk.getValue("SysColor");
					if (got instanceof byte[]){
						byte[] data = (byte[])got;
						putColorFrom(data,isMobile6 ? 7 : 2,GuiValueKeys.ActiveTitleBarColor);
						putColorFrom(data,9,GuiValueKeys.TitleBarTextColor);
					}
				}
			}
		}catch(Throwable t){
			
		}
	}
	static 
	{
		resetFlags();
	}
	/**
	 * Call showWait() on the active window.
	 * @param showOrHide true to show the wait cursor, false to hide it.
	 * For every call with showOrHide true, the must be a corresponding
	 * call with showOrHide false in order to restore the cursor
	 * to its correct state.
	 */
	public static synchronized void showWait(boolean showOrHide)
	{
		showWait(null,showOrHide);
	}
	/**
	 * Call showWait() on the window containing the control.
	 * @param forWho the Control in the window to show wait for. If this
	 * is null then the active window is used.
	 * @param showOrHide true to show the wait cursor, false to hide it.
	 * For every call with showOrHide true, the must be a corresponding
	 * call with showOrHide false in order to restore the cursor
	 * to its correct state.
	 */
	public static synchronized void showWait(Control forWho, boolean showOrHide)
	{
		Window w = forWho == null ? null : forWho.getWindow();
		if (w == null) w = Window.getActiveWindow();
		if (w == null) return;
		w.showWait(showOrHide);
	}
/* Used by Window.*/
	/*
	public static void setSIP(Window window, int state)
	{
		if (window == null) window = Window.getActiveWindow();
		if (window == null) window = Application.mainApp;
		WindowSurface ws = (WindowSurface)window.getSurface();
		ws.setSIP(state,ws);
	}
	public static int getSIP(Window window)
	{
		if (window == null) window = Window.getActiveWindow();
		if (window == null) window = Application.mainApp;
		WindowSurface ws = (WindowSurface)window.getSurface();
		return ws.getSIP(ws);
	}
	public static int getSIP()
	{
		return getSIP(null);
	}
	public static void setSIP(int state)
	{
		setSIP(null,state);
	}
	*/
	/**
	 * This temporarily holds the SIP in a particular mode (open or closed) until the current event thread
	 * has completed.
	 * @param freezeOrUnfreeze true to freeze the SIP either on (if sipOnOrOff is SIP_ON) or off (if sipOnOrOff is 0).
		Set to false to unfreeze the SIP. This is done automatically at the end of the current event thread.
	 * @param sipOnOrOff This is only valid if freezeOrUnfreeze is true, in which case it tells if the SIP should be open
		(SIP_ON) or closed (0).
	 * @param window The window of the control that is changing the SIP.
	 */
/*
//	===================================================================
	public static void freezeSIP(boolean freezeOrUnfreeze,int sipOnOrOff,Window window)
//	===================================================================
	{
		if (freezeOrUnfreeze && !Window.inEventThread()) return;
		if (window == null) window = Window.getActiveWindow();
		if (!freezeOrUnfreeze) sipOnOrOff = 0;
		else if (sipOnOrOff == SIPConstants.SIP_CURRENT) {
			sipOnOrOff = getSIP();
			//Vm.debug("Is: "+sipOnOrOff);
		}
		setSIP((sipOnOrOff & SIPConstants.SIP_ON) | (freezeOrUnfreeze ? SIPConstants.SIP_FREEZE : SIPConstants.SIP_UNFREEZE));
	}
	*/
	/**
	* This will freeze the SIP in it's current state until the end of the processing of the current Event.
	**/
/*
//	===================================================================
	public static void freezeSIP(Control forWho)
//	===================================================================
	{
		freezeSIP(true,SIPConstants.SIP_CURRENT,forWho == null ? null : forWho.getWindow());
	}
//	===================================================================
	public static void freezeSIP()
//	===================================================================
	{
		freezeSIP(null);
	}
	public static void unfreezeSIP(){}
*/
	/*
	* This turns the SIP on PalmPC/PocketPC devices. The mode is a combination of the following
	* bit flags.<br>
	* SIP_ON = If this bit is set the SIP will be switched on and the SIP button will be made visible.
	* If this bit is clear the SIP will be switched off (except in cases where SIP_LOCK is used).<br>
	* SIP_LEAVE_BUTTON = If this bit is set when the SIP_ON bit is clear, the SIP will be switched off,
	* but the SIP button will be left on. This only works for PocketPC.<br>
	* SIP_LOCK = If this bit is set when SIP_ON is also set, the SIP will be switched on and will not
	* be switched off unless this method is called with SIP_ON clear AND with SIP_LOCK on. This is
	* used to keep the SIP visible even under circumstances where it is normally hidden (e.g. when
	* switching from a text control to a non-text control). This can be used to avoid excessive
	* SIP showing and hiding.
	*/
/*
	public static int setCursor(Control forWho, int cursor)
	{
		Window w = forWho.getWindow();
		if (w != null) w.setCursor(cursor);
		return 0;
	}
*/
	/**
	 * This sets the cursor of the currently active window.
	 */
	public static int setCursor(int cursor)
	{
		Window w = Window.getActiveWindow();
		if (w != null) w.setCursor(cursor);
		//return setCursor(Application.mainApp,0);
		return 0;
	}
	public static int getAsyncKeyState(int key)
	{
		return Application.mainApp.surface.getAsyncKeyState(key);
	}
	private static int newSip = -1;
	private static int focusCount = 0;
	static Window sipWindow = null;

	static int sipRequest = -1;
	static int prevSip = -1;
	
	static //synchronized causes deadlock 
	void resetSip()
	{
		sipRequest = -1;
	}
	static //synchronized caused deadlock 
	void applySip()
	{
			if (sipRequest != -1)
				doSetSIP(null,sipRequest);
			sipRequest = -1;
			prevSip = getSIP(null);
	}
//	-------------------------------------------------------------------
	static //synchronized caused deadlock 
	void changeSip(int newSip)
//	-------------------------------------------------------------------
	{
		if (newSip == -1) return;
		//if ((newSip & SIPConstants.SIP_IS_ON) == 0)  Vm.debugStackTrace();
		if (Window.inEventThread()){
			if (newSip != getSIP(null)){
				Control.cancelHoldDown();
				//System.out.println("CHD: "+newSip+" != " +getSIP(null));
			}
			if (((newSip & 1) != 0) || ((sipRequest & 1) != 0))
				sipRequest = newSip;
		}else 
			doSetSIP(null,newSip);
	}
	public static void setSIP(Window win,int sip)
	{
		changeSip(sip);
	}
	public static int getSIP(Window window)
	{
		if (SoftKeyBar.hasKeypad()){
			return SoftKeyBar.keypadGetState();
		}
		//if (!VMOptions.vmOptions.useSIP || true) return 0;
		if (window == null) window = Window.getActiveWindow();
		if (window == null) window = Application.mainApp;
		if (window == null) return 0;
		WindowSurface ws = (WindowSurface)window.getSurface();
		if (ws != null) return ws.getSIP(ws);
		return 0;
	}
	public static void doSetSIP(Window window, int newSip)
	{
		if (SoftKeyBar.hasKeypad()){
			if ((newSip & SIPConstants.SIP_ON) != 0)
				SoftKeyBar.keypadSetVisible(true);
			else
				SoftKeyBar.keypadSetVisible(false);
			return;
		}
		if ((newSip & SIPConstants.SIP_OVERRIDE_USE_SIP) == 0)
			if (!VMOptions.vmOptions.useSIP || ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_SIP_DISABLED) != 0)) return;
		if (window == null) window = Window.getActiveWindow();
		if (window == null) window = Application.mainApp;
		if (window == null) return;
		WindowSurface ws = (WindowSurface)window.getSurface();
		if (ws != null) ws.setSIP(newSip,ws);
	}

	/**
	 * Given text in the format "Text$hotkey" this returns the hotkey character.
	 * @param text The text for the control with the included hotkey.
	 * @return The hotkey character.
	 */
//	===================================================================
	public final static char getHotKeyFrom(String text)
//	===================================================================
	{
		if (text == null) return 0;
		int idx = text.lastIndexOf('$');
		if (idx < 0 || idx != text.length()-2) return 0;
		return text.charAt(idx+1);
	}

	/**
	 * Given text in the format "Text$hotkey" this returns the text string without the hotkey character.
	 * @param text The text for the control with the included hotkey.
	 * @return The text without the hotkey character.
	 */
//	===================================================================
	public final static String getTextFrom(String text)
//	===================================================================
	{
		if (text == null) return null;
		int idx = text.lastIndexOf('$');
		if (idx < 0 || idx != text.length()-2) return text;
		return text.substring(0,idx);	
	}
	/**
	 * Given a label and a hotKey make a text string that will display the hot key
	 * underlined when drawn on a Graphics.
	 * @param label the label.
	 * @param hotKey the hotkey.
	 * @param dest a destination CharArray which will be set to zero length before
	 * this text is appended.
	 * @return the destination CharArray or a new one if it is null.
	 */
	public static final CharArray makeHot(String label, int hotKey,CharArray dest)
	{
		if (dest == null) dest = new CharArray();
		dest.setLength(0);
		if ((noHotLabels || label == null) || ((hotKey & (IKeys.INVISIBLE<<24)) != 0)
		|| ((hotKey & 0xffff) == 0 || label.length() == 0)){
			dest.append(label);
			return dest;
		}
		dest.append(label);
		dest.append((char)(hotKey & 0xffff));
		dest.append((char)0);
		return dest;
	}
	/**
	 * Convert a string with a hotkey to be a "true" hotkey encoded String which, when displayed by
		* a Graphics object, will have its hotkey underlined. Note that this is very different to the
		* human readable hotkey encoding where a $ is placed as the second to last character and the 
		* hotkey is the last character. A hotkey encoded String is one
		* where the last character is a null character. The character immediately before the null is then taken
		to be the hot key.
	 * @param label The pure String.
	 * @param hotKey The hotkey (if any) to apply to the String.
	 * @return The displayable String which will be displayed with it's hotkey underlined by a Graphics object.
	 * @deprecated - use makeHot(String,int,CharArray) instead.
	 */
//	===================================================================
	public static final String makeHot(String label,int hotKey)
//	===================================================================
	{
		if ((noHotLabels || label == null) || ((hotKey & (IKeys.INVISIBLE<<24)) != 0)
				|| ((hotKey & 0xffff) == 0 || label.length() == 0)){
					return label;
				}
		CharArray sb = (CharArray)Cache.get(CharArray.class);
		makeHot(label,hotKey,sb);
		String ret = sb.toString();
		Cache.put(sb);
		return ret;
	}


	/**
	 * Convert a '$' formatted hotkey into a "true" hotkey encoded String. A hotkey encoded String is one
		* where the last character is a null character. The character immediately before the null is then taken
		to be the hot key.
	 * @param label The '$' formatted hotkey.
	 * @return The displayable String which will be displayed with it's hotkey underlined by a Graphics object.
	 */
//	===================================================================
	public static final String makeHot(String label)
//	===================================================================
	{
		if (label.indexOf('$') == -1) return label;
		return makeHot(getTextFrom(label),getHotKeyFrom(label));
	}
	/**
	* This returns true if the Frame is the main frame of a window.
	**/
//	===================================================================
	public static boolean isWindowFrame(Frame f)
//	===================================================================
	{
		if (f == null) return false;
		return f.closeWindow;
	}
	public static int getReturnedInteger(Object value)
	{
		if (!(value instanceof Integer)) return 0;
		return ((Integer)value).intValue();
	}
	/**
	* This gets a Graphics object for a window. If the Window is rotated it will return a RotatedGraphics
	* object.
	**/
	/*
//	===================================================================
	public static Graphics getGraphics(Window window)
//	===================================================================
	{
		if (window == null) return null;
		return window.getGraphics();//new Graphics(window.getSurface());
	}
*/	
	/**
	* This gets the rect of the control relative to the top left of the controls
	* containing window. If it is not displayabled, then null will be returned. The
	* rect returned may not be the full size of the control as it may be cut off by
	* its parents.
	**/
//	===================================================================
	public static Rect getRectInWindow(Control ct,Rect dest,boolean onlyIfVisible)
//	===================================================================
	{
		return getRectInWindow(ct,dest,onlyIfVisible,null);
	}
	private static Rect parentRect = new Rect();
	/**
	* This gets the rect of the control relative to the top left of the controls
	* containing window. If it is not displayabled, then null will be returned. The
	* rect returned may not be the full size of the control as it may be cut off by
	* its parents.
	 * @param ct the control.
	 * @param dest a destination rectangle. When this method returns
	 * the x and y co-ordinates hold the x and y co-ordinates of the
	 * top left unclipped portion of the Control relative to the Window.
	 * The width and height hold the unclipped width and height of the Control.
	 * @param onlyIfVisible if this is true and no part of the Control is
	 * visible, then null is returned.
	 * @param actualPosition if this is not null this will hold the x and y co-ordinate of the top left
	 * corner of the Control regardless of any clipping.
	 * @return the destination Rectangle or a new one if it was null.
	 * If onlyIfVisible is true and none of the control is visible, then
	 * this will return null.
	 */
	public static Rect getRectInWindow(Control ct,Rect dest,boolean onlyIfVisible,Point actualPosition)
//	===================================================================
	{
		if (ct == null) return null;
		if (actualPosition != null) actualPosition.set(ct.x,ct.y);
		dest = Rect.unNull(dest);
		synchronized(parentRect){
			Rect par = parentRect;
			dest.set(ct.x,ct.y,ct.width,ct.height);
			if (ct.width < 1 || ct.height < 1) return null;
			if (onlyIfVisible)
				if ((ct.modifiers & Invisible) != 0)
					return null;
			Control c = ct;
			for (c = c.getParent(); c != null; c = c.getParent()){
				if (onlyIfVisible)
					if ((c.modifiers & Invisible) != 0)
						return null;
				c.getDim(par);
				par.getIntersection(dest,dest);
				if (dest.width < 1 || dest.height < 1) return null;
			 	dest.x += c.x;
			  dest.y += c.y;
				if (actualPosition != null) {
					actualPosition.x += c.x;
					actualPosition.y += c.y;
				}
			 	if (c instanceof Window){
					if (!((Window)c).firstDisplay){//canDisplay) {
						return null;
					}else{
						break;
					}
			 	}
			}
		}
		return dest;
	}
	
	/**
	* This gets the rect of the control relative to the top left of the controls
	* containing window.
	**/
//	===================================================================
	public static Rect getAppRect(Control ct,Rect dest)
//	===================================================================
	{
		Rect r = dest;
		if (r == null) r = new Rect();
		if (ct == null) return r;
		r.set(ct.x,ct.y,ct.width,ct.height);
		Control c = ct;
		for (c = c.getParent(); c != null; c = c.getParent()){
			r.x += c.x; r.y += c.y;
		}
		return r;
	}
//	==================================================================
	public static Rect getAppRect(Control ct)
//	==================================================================
	{
		return getAppRect(ct,null);
	}
//	==================================================================
	public static Point getPosInParent(Control c,Container parent,Point dest)
//	==================================================================
	{
		dest = Point.unNull(dest);
		dest.set(0,0);
		if (c == parent) return dest;
		Rect r = c.getCachedRect();
		c.getRect(r);
		Point p = dest.set(r.x,r.y);
		for (c = c.getParent(); c != parent && c != null; c = c.getParent()){
			c.getRect(r);
			p.translate(r.x,r.y);
		}
		c.cache(r);
		return p;
	}
//	==================================================================
	public static SavedScreen saveScreen(Window w,Rect area,boolean doCapture)
//	==================================================================
	{
		return new SavedScreen(w,area,doCapture);//false); 
//	Disabled this because it messes with the SIP
		/*
		if (true || mApp.platform.equals("Java") || mApp.platform.equals("PalmOS")) return new SavedScreen(w,area,false);
		else return new SavedScreen(w,area,doCapture);
		*/
	}
	
//	==================================================================
	public static void refreshScreen(Window w){refreshScreen(w,(Rect)null);}
	public static void refreshScreen(Window w,Rect area)
//	==================================================================
	{
		if (w != null)
			w.repaintNow(null,area);
	}
//	==================================================================
	public static void refreshScreen(Control c)
//	==================================================================
	{
		refreshScreen(c.getWindow(),getAppRect(c));
	}
	/**
	* Capture the image of a Control from the screen if possible.
	**/
	/*
//	===================================================================
	public static void captureControl(Control ct,Graphics dest,Rect dim)
//	===================================================================
	{
		int x = 0, y = 0, w = dim.width, h = dim.height;
		int ox = dim.x, oy = dim.y;
		for (Control c = ct; c != null; c = c.getParent()){
			c.getRect(dim);
			x += dim.x; y += dim.y;
		}
		dim.set(ox,oy,w,h);
		Window win = ct.getWindow();
		if (win == null) return;
		Graphics g = win.getGraphics();
		if (g != null){
			dest.copyRect(g,x,y,w,h,0,0);
			g.free();
		}
	}
	*/
	/**
	 * This is called if a Control detects that the user pressed the pen on an area
	 * of the screen that is not covered by the top-most frame. This is significant
	 * because depending on the situation, the program may want to close the top frame,
	 * focus on a new frame or ignore the press.
	 * @param onWho the Control that was pressed.
	 * @param whereOnWho the Point on the Control that was pressed.
	 * @return true if the event was handled, false if not.
	 */
//	==================================================================
	public static boolean pressedOutsideTopFrame(Control onWho,Point whereOnWho)
//	==================================================================
	{
		if (onWho == null) return true;
		Frame f2 = onWho.getFrame();
		if (f2 == null) return true;
		if (f2.isControlPanel) return true;
		Frame f = topFrame(onWho);
		if (f == null) return true;
		Rect r = getAppRect(onWho);
		if (f.wantPressedOutside) {
			Point p = new Point(whereOnWho.x+r.x,whereOnWho.y+r.y);
			f.pressedOutside(p);
			boolean ret = !f.capturePressedOutside;
			if (ret){
				Window w = onWho.getWindow();
				if (w != null) w.focus = onWho;
			}
			return ret;
		}
		Sound.beep(Sound.BEEP_GUI);
		return false;
	}
	
//	===================================================================
	private static Rect rp, rp2;// = new Rect();
	public static synchronized boolean requestPaint(Control who)
//	===================================================================
	{
		Window w = who.getWindow();
		if (w == who || w == null) return true;
		//
		// FIXME! Something more efficient?
		//
		//
		Frame mine = who.getFrame();
		if (mine == w.contents) return true;
		if (who.getParent() == w) return true;
		//
		Vector ff = w.frames;
		int fz = ff.size();
		Frame top = (fz != 0) ? (Frame)ff.get(fz-1) : null;
		if (top == null) return true;
		Vector vv = top.controlsToRefresh;
		boolean canPaint = true;
		Rect dest = Rect.getCached(), other = Rect.getCached();
		getAppRect(who, dest);
		try{
			if (true){
				for (int i = fz-1; i >= 0; i--){
					Frame cf = (Frame)ff.get(i);
					if (cf == mine || cf == who) break;
					//getAppRect(cf,other);
					if (getRectInWindow(cf, other, true) == null)
						continue;
					if (other.intersects(dest)){
						//System.out.println("Cannot repaint: "+dest+" intersects: "+cf+", "+other);
						return canPaint = false;
					}
				}
			}
			//
			int x = 0, y = 0;
			for (Control c = top; c != null; c = c.getParent())
				if (c == who) return true;
			if (vv != null && vv.indexOf(who) != -1) return false; 
			for (Control c = who; c != null; c = c.getParent()){
				if (c == top) return true;
				x += c.x;
				y += c.y;
			}
			if (rp == null) {
				rp = new Rect();
				rp2 = new Rect();
			}
			//if (!getAppRect(top,rp).intersects(rp2.set(x,y,who.width,who.height))) return true;
			Rect r = getRectInWindow(top,rp,false);
			if (r == null || !r.intersects(rp2.set(x,y,who.width,who.height))) 
				return true;
			//System.out.println(top+" overrides: "+who);
			return canPaint = false;
		}finally{
			if (!canPaint){
				if (vv == null) vv = top.controlsToRefresh = new Vector();
				if (vv.indexOf(who) == -1) vv.add(who);
			}
			dest.cache();
			other.cache();
		}		
	}
//	===================================================================
	public static void refreshTopFrame(Control who)
//	===================================================================
	{
		if (who instanceof Window) return;
		Window w = who.getWindow();
		if (w == null) return;
		if (who.parent == w.contents || who.parent == w) return;
		Control top = topFrame(who);
		if (top == null) return;
		for (Control c = who; c != null; c = c.parent){
			if (c == top) return;
			if (c.parent == null && !(c instanceof Window)) return; //Not on screen.
		}
		top.repaintNow();
	}
	
	public static final int CENTER_FRAME = 0x1;
	public static final int FILL_FRAME = 0x2;
	/**
	* This should not be OR'ed with FILL_HEIGHT. Use FILL_FRAME instead.
	**/
	public static final int FILL_WIDTH = 0x4;
	/**
	* This should not be OR'ed with FILL_WIDTH. Use FILL_FRAME instead.
	**/
	public static final int FILL_HEIGHT = 0x8;
	public static final int NEW_WINDOW = 0x10;
	static final int ALL_DISPLAY_OPTIONS = 0x1f;

	public static final int PUTTING_POPUP = 0x20;
	static final int ALREADY_PLACED_IN_NEW_WINDOW = 0x40;
	
	private static Form getForm(Frame f)
	{
		if (f instanceof FormFrame)
			return ((FormFrame)f).myForm;
		return null;
	}
//	-------------------------------------------------------------------
	protected static Container setupNewWindow(Frame f,Container parent,boolean modal)
//	-------------------------------------------------------------------
	{
		int toSet = modal ? Window.FLAG_IS_MODAL:0;
		int toClear = 0;
		//
		Window w = null;
		//FormFrame ff = null;
		Form wc = getForm(f);
		Object icon = null;
		if (wc != null){
			icon = wc.windowIcon;
			w = wc.createWindow();
			if (f.font == null && w != null)
				f.font = w.font;
			f.make(false);
			toSet |= wc.windowFlagsToSet;
			toClear |= wc.windowFlagsToClear;
			if (!wc.resizable) toClear |= Window.FLAG_CAN_RESIZE|Window.FLAG_CAN_MAXIMIZE|Window.FLAG_CAN_MINIMIZE;
			else toSet |= Window.FLAG_CAN_RESIZE|Window.FLAG_CAN_MAXIMIZE|Window.FLAG_CAN_MINIMIZE;
		}else{
			w = new Window(true);
			if (f.font == null && w != null)
				f.font = w.font;
			f.make(false);
		}
		Dimension d = f.getPreferredSize(null);
		Rect sz = new Rect(toSet,toClear,d.width,d.height);
		//
		if (WindowSurface.noCloseButtons){
			toSet &= ~Window.FLAG_HAS_CLOSE_BUTTON;
			toClear |= Window.FLAG_HAS_CLOSE_BUTTON;
		}
		//
		int flg = w.getFlagsForSize(d.width,d.height,toSet,toClear);
		//flg &= ~toClear;
		Control top = null;
		boolean shrankIt = false;
		if ((flg & Window.FLAG_FOR_SIZE_NO_TITLE) == 0) {
			if (wc == null || !((FormFrame)f).hasExtraTitleControls)
				top = f.top;
		}
		if (true && (top != null)){
			top.modify(f.ShrinkToNothing,0);
			f.relayoutMe(false);
			d = f.getPreferredSize(d);
			shrankIt = true;
		}
		sz.set(WindowCreationData.DEFAULT_VALUE,WindowCreationData.DEFAULT_VALUE,d.width,d.height);
		if ((toSet & Window.FLAG_IS_DEFAULT_SIZE) != 0)
			sz.width = sz.height = WindowCreationData.DEFAULT_VALUE;
		if (w.creationData == null)
			w.creationData = new WindowCreationData();
		if (icon != null) w.creationData.icon = Device.toDeviceIcon(icon);
		else w.creationData.icon = Device.toDeviceIcon(Window.defaultWindowIcon);
		if (parent != null) w.creationData.parentWindow = parent.getWindow();
		//
		if (WindowSurface.noCloseButtons){
			toSet &= ~Window.FLAG_HAS_CLOSE_BUTTON;
			toClear |= Window.FLAG_HAS_CLOSE_BUTTON;
		}
		//
		if (!w.create(sz,f.name,toSet,toClear,w.creationData))
			throw new RuntimeException("Could not create native window!");
		if (shrankIt)
			if ((w.getWindowFlags() & Window.FLAG_HAS_TITLE) == 0){
				//ewe.sys.Vm.messageBox("UnShrinking Title!","I will un-shrink the title.",ewe.sys.Vm.MB_TYPE_OK);
				f.top.modify(0,f.ShrinkToNothing);
				f.relayoutMe(false);
			}
		//
		f.closeWindow = true;
		return w.contents;
	}
	private static int windowCheck = -1;
	private static boolean noWindows = false;
	/**
	This forces the system to act as if multiple windows are not supported.
	This cannot be undone.
	**/
//	===================================================================
	public static void setNoMultipleWindows()
//	===================================================================
	{
		windowCheck = 0;
		noWindows = true;
		//FIXME - activate Vm.setParameter(Vm.SET_NO_WINDOWS,1);
		//Vm.setParameter(Vm.SET_NO_WINDOWS,1);
		if (Application.mainApp != null && Application.mainApp.isCreated()){
			Application.mainApp.setWindowFlags(Window.FLAG_IS_VISIBLE);
		}
	}
	public static boolean getNoMultipleWindows()
	{
		checkWindows();
		return windowCheck == 0;
	}
//	-------------------------------------------------------------------
	private static void checkWindows()
//	-------------------------------------------------------------------
	{
		if (windowCheck == -1)
			windowCheck = Window.supportsMultiple() && !noWindows ? 1 : 0;
		if (windowCheck == 0) NullParentFrameToMainApp = true;
	}

	static void shutdown()
	{
		if (softkeyMadeFrame != null)
			doHideFrame(softkeyMadeFrame);
		setAllParentFrame(null);
	}
	static Frame softkeyMadeFrame;
	private static Frame allParentFrame;
	/**
	This returns the parent frame for a control's popup menu.
	**/
//	===================================================================
	public static Frame getPopupMenuParentFrame(Control c)
//	===================================================================
	{
		Frame f = SoftKeyBar.getSofkeyControlMenuFrame(c);
		if (f != null) return f;
		if (allParentFrame != null) return allParentFrame;
		return c.getWindow().contents;
	}
	private static Dimension screenSize;
	/**
	* A possible flag for screenIs.
	**/
	public static final int BIG_SCREEN = 1;
	/**
	* A possible flag for screenIs.
	**/
	public static final int WIDE_SCREEN = 2;
	/**
	* A possible flag for screenIs.
	**/
	public static final int LONG_SCREEN = 3;
	/**
	* A possible flag for screenIs.
	**/
	public static final int DESKTOP_SCREEN = 4;
	/**
	* A possible flag for screenIs.
	**/
	public static final int DESKTOP_WIDTH = 5;
	/**
	* A possible flag for screenIs.
	**/
	public static final int DESKTOP_HEIGHT = 6;
	/**
	* A possible flag for screenIs.
	**/
	public static final int PDA_SCREEN = 7;
	
	/**
	 * This returns a static Dimension - do not change its contents.
	 */
	public static Dimension getScreenSize()
	{
		if (screenSize == null)
			Application.mainApp.surface.getScreenRect(screenSize = new Dimension());
		return new Dimension(screenSize.width,screenSize.height);
	}
	/**
	* Check if the user screen is of a certain type.
	* @param flags One of the XXX_SCREEN or DESKTOP_XXX constants.
	* @return true if the screen is considered to be of the type specified by the flag.
	*/
//	===================================================================
	public static boolean screenIs(int flags)
//	===================================================================
	{
		//if (true) return false;
		if (screenSize == null)
			Application.mainApp.surface.getScreenRect(screenSize = new Dimension());
		if (flags == BIG_SCREEN)
			return screenSize.width >= 600 && screenSize.height >= 300;
		else if (flags == WIDE_SCREEN)
			return screenSize.width >= 600 || screenSize.width > screenSize.height;
		else if (flags == LONG_SCREEN)
			return screenSize.height >= 290 || screenSize.height > screenSize.width;
		else if (flags == DESKTOP_SCREEN)
			return screenSize.height >= 480 && screenSize.width >= 640;
		else if (flags == DESKTOP_WIDTH)
			return screenSize.width >= 640;
		else if (flags == DESKTOP_HEIGHT)
			return screenSize.height >= 480;
		else if (flags == PDA_SCREEN)
			return screenSize.width <= 350 && screenSize.height <= 350;
		return false;
	}
	static Vector startupTasks = new Vector();
	//
	static void addStartupTask(Handle h)
	{
		if (Vm.inSystemThread()) startupTasks.add(h);
		else h.waitUntilCompletion();
	}
	static void doStartupTasks()
	{
		if (Vm.inSystemThread()) return;
		for (int i = 0; i<startupTasks.size(); i++){
			((Handle)startupTasks.get(i)).waitUntilCompletion();
		}
		startupTasks.removeAllElements();
	}
	/**
	Set the system to believe that multiple windows are not possible and that
	all new Frames should be shown in the specified Frame. If the specified Frame is
	null then the system will revert back to the normal operation.
	**/
//	===================================================================
	public static void setAllParentFrame(final Frame f)
//	===================================================================
	{
		allParentFrame = f;
		if (f == null){
			windowCheck = -1;
			checkWindows();
			Application.mainApp.surface.getScreenRect(screenSize = new Dimension()); 
		}else{
			windowCheck = 0;
			NullParentFrameToMainApp = true;
			Dimension d = f.getSize(new Dimension());
			if (d.width == 0 || d.height == 0)
				addStartupTask(new Task(){
					protected void doRun(){
						if (f.getWindow() != null){
							f.getWindow().waitForResize(-1);
						}
						screenSize = f.getSize(new Dimension());
					}					
				}.start());
			else
				screenSize = f.getSize(new Dimension());
		}
	}
	/*
//	-------------------------------------------------------------------
	static Form getTopmostForm(Control c)
//	-------------------------------------------------------------------
	{
		Form top = null;
		for (; c != null; c = c.getParent())
			if (c == allParentFrame) break;
			else if (c instanceof Form) top = (Form)c;
		return top;
	}
	*/
	/**
	 * Close all Frames denoted as popup frames in the Window containing the control.
	 * @param window Either the window or a Control within the window.
	 * @return true if all popups were closed successfully, false if not.
	 */
//	===================================================================
	public static boolean closePopups(Control window)
//	===================================================================
	{
		return closePopups(window,0,0);
	}
//	===================================================================
	public static boolean closePopups(Control window,int why, int flags)
//	===================================================================
	{
		Frame last = null;
		while(true){
			Frame f = topFrame(window);
			if (f == null) return true;
			if (f == last) return false;
			if (f.popupController == null) return true;
			last = f;
			f.popupController.closePopup(why,flags);
		}
	}
//	-------------------------------------------------------------------
	protected static Container checkParent(Container parent,int options)
//	-------------------------------------------------------------------
	{
		checkWindows();
		if (windowCheck == 0) options &= ~NEW_WINDOW;
		if (parent == null && ((options & NEW_WINDOW) == 0)){
			if (NullParentFrameToMainApp) {
				parent = allParentFrame;
				/*
				if (parent == null){
					parent = Application.appFrame;
					if ((Application.mainApp.getWindowFlags() & Window.FLAG_IS_VISIBLE) == 0) parent = null;
				}
				*/
				if (parent == null)
					parent = Application.mainApp.contents;
			}
		}
		if ((options & PUTTING_POPUP) == 0)
			closePopups(parent);
			
		return parent;
	}
//	-------------------------------------------------------------------
	protected static void doExecFrame(Frame f,Container parent,int options)
//	-------------------------------------------------------------------
	{
		Window w = parent.getWindow();
		Vector frames = w.frames;
		Window.topFrameChanging();
		if (frames.indexOf(f) != -1) return;
		//f.doSaveScreen = true;
		Control c = focusedControl();
		if (c != null) c.lostFocus(ByRequest);
		//inFocus.add(null);
		notifyTop(w,false);
		frames.add(f);
		notifyTop(w,true);
	}
	
//	===================================================================
	public static void moveFrameTo(Frame f,Rect where)
//	===================================================================
	{
		Rect now = getAppRect(f);
		int old = f.modify(Invisible,0);
		refreshScreen(f.getWindow(),now);
		f.setRect(where);
		f.restore(old,Invisible);
		f.repaintNow();
	}
	
	static void sendShow(final Frame f,final boolean doNotifyTop)
	{
		new WindowThreadTask(){
			protected void doRun(){
				f.shown();
				if (doNotifyTop) notifyTop(window,true);
				Form ff = f instanceof FormFrame ? ((FormFrame)f).myForm : null;
				if (ff != null){
					Control c = ff.firstFocus;
					if (c == null) ff.focusFirst();
					else takeFocus(c,ByRequest);
				}
			}
		}.run(f,true);
	}
	static Object frameChangeLock = new Object();
	/**
	* This will add the frame to the container and call a make() on it.
	* This also sets the frame to be modal.
	* If you specify an option of FILL_FRAME, CENTER_FRAME or FILL_WIDTH or FILL_HEIGHT, then the
	* frame will be positioned and displayed on screen. If not 
	* you will have to call setRect()/repaintNow() on the frame to cause it
	* to be positioned and painted.
	*/
//	==================================================================
	public static void execFrame(Frame f,Container parent,int options)
//	==================================================================
	{
		boolean nt = false;
		synchronized(frameChangeLock){
			//if (getForm(f) instanceof MessageBox) freezeSIP();
			if (f.popupController != null) options |= PUTTING_POPUP;
			f.isModal = true;
			parent = checkParent(parent,options);
			if (parent == null) options = NEW_WINDOW;
			if (windowCheck == 0) options &= ~NEW_WINDOW;
			inFocus.add(null);
			if ((options & NEW_WINDOW) != 0){
				if (f instanceof FormFrame) ((FormFrame)f).useSizeBar = false;
				parent = setupNewWindow(f,parent,true);
				options = FILL_FRAME|ALREADY_PLACED_IN_NEW_WINDOW;
			}else{
				
			}
			/*
			if (f instanceof FormFrame)
				System.out.println("Exec: "+((FormFrame)f).myForm.title);
			else
				System.out.println("Exec: "+f);
			*/
			_makeModal(f,parent.getWindow(),true);
			doExecFrame(f,parent,options);
			nt = doShowFrame(f,parent,options);
		}
		sendShow(f,nt);
	}

//	===================================================================
	public static int fixShowOptions(Container parent,int options)
//	===================================================================
	{
		checkWindows();
		if ((options & NEW_WINDOW) != 0 && (options & 0xf) == 0) options |= CENTER_FRAME;
		if (windowCheck == 0) options &= ~NEW_WINDOW;
		if ((options & NEW_WINDOW) != 0) return options;
		if (checkParent(parent,options) == null) return NEW_WINDOW;
		if (windowCheck == 0) {
			NullParentFrameToMainApp = true;
			options &= ~NEW_WINDOW;
		}
		return options;
	}
//	===================================================================
	public static boolean dontPaintNextFrame = false;//true;
//	===================================================================
	/**
	* This will add the frame to the container and call a make() on it.
	* This does not set the frame to be modal.
	* If you specify an option of FILL_FRAME or CENTER_FRAME or FILL_WIDTH or FILL_HEIGHT, then the
	* frame will be positioned and displayed on screen. If not 
	* you will have to call setRect()/repaintNow() on the frame to cause it
	* to be positioned and painted.
	*/
//	==================================================================
	public static void showFrame(Frame f,Container parent,int options)
//	==================================================================
	{
		boolean doExec = false;
		if (!disableModalProtection)
		synchronized(frameChangeLock){
			doExec = WindowSurface.getModal() != null;
		}
		if (doExec){
			execFrame(f, parent, options);
			return;
		}
		boolean nt = doShowFrame(f,parent,options);
		sendShow(f,nt);
	}
	private static boolean doShowFrame(Frame f,Container parent,int options)
	{
		//if (mApp.mainApp.isLocked()) return;
		boolean doNotifyTop = false;
		synchronized(frameChangeLock){
			if (f.openState != null)
				f.openState.set(Handle.Running);
			Form form = getForm(f);
			boolean sipFreeze = (form instanceof MessageBox); 
			//if (sipFreeze) freezeSIP();
			if (f.popupController != null) options |= PUTTING_POPUP;
			parent = checkParent(parent,options);
			if (parent == null) options = NEW_WINDOW;
			if (windowCheck == 0) options &= ~NEW_WINDOW;
			boolean inNewWindow = false;
			if ((options & NEW_WINDOW) != 0){
				if (f instanceof FormFrame) ((FormFrame)f).useSizeBar = false;
				inNewWindow = true;
				parent = setupNewWindow(f,parent,false);
				options = FILL_FRAME;
			}else if (form != null && parent != null){
				if ((form.windowFlagsToSet & Window.FLAG_MAXIMIZE) != 0) 
					options |= FILL_FRAME;
				else if ((form.windowFlagsToSet & Window.FLAG_MAXIMIZE_ON_PDA) != 0 && (screenIs(PDA_SCREEN)||hasSoftKeys)){
					options |= FILL_FRAME;
				}
			}
			if ((options & ALREADY_PLACED_IN_NEW_WINDOW) != 0)
				inNewWindow = true;
		 	if (f != parent){
				parent.addDirectly(f);
				Frame pf = parent instanceof Frame ? (Frame)parent : null;
				if (pf == null) pf = parent.getFrame();
				//if (pf == null) pf = Application.appFrame;
				if (pf != null && pf != f) pf.addChildFrame(f);
			}
			f.displayOptions = options;
			f.make(false);
			Window w = parent.getWindow();
			if (form != null && form.acceptsDroppedFiles)
				w.acceptDroppedFiles(true);
			if (!inNewWindow) w.waitForResize();
			if ((options & ALL_DISPLAY_OPTIONS) != 0){
				Dimension r = f.getPreferredSize(null);
				Rect cr = parent.getRect(null);
				/*
				if (parent == mApp.appFrame && f.resizeOnSIP) {
					cr.width = mApp.mainApp.visibleWidth;
					cr.height = mApp.mainApp.visibleHeight; 
				}
				*/
				/*
				if (form != null){
					if ((form.windowFlagsToSet & Window.FLAG_MAXIMIZE) != 0) options |= FILL_FRAME;
				}
				*/
				if ((options & (FILL_FRAME|FILL_WIDTH)) != 0) r.width = cr.width;
				if ((options & (FILL_FRAME|FILL_HEIGHT)) != 0) r.height = cr.height;
				if (r.width > cr.width) r.width = cr.width;
				if (r.height > cr.height) r.height = cr.height;
				if (sipFreeze){
					Rect vr = visibleWindowClientArea(parent,new Rect());
					if (vr.height > cr.height) vr.height = cr.height;
					if (vr == null) f.setRect((cr.width-r.width)/2,(cr.height-r.height)/2,r.width,r.height);
					else{
						if (vr.height < r.height) r.height = vr.height;
						f.setRect((cr.width-r.width)/2,vr.y+(vr.height-r.height)/2,r.width,r.height);
					}
				}else
					f.setRect((cr.width-r.width)/2,(cr.height-r.height)/2,r.width,r.height);
				//if (!dontPaintNextFrame) refreshScreen(f); //Why this one? Safer?
				if (!inNewWindow && !dontPaintNextFrame) {
					f.repaintNow();
					//f.shown(); - Causes deadlock
				}else
					doNotifyTop = true;
			}
			dontPaintNextFrame = false;
			f.openState.setFlags(Handle.Running|f.SizedFlag,Handle.Stopped);
			if ((w.modifiers & DontBuffer) != 0)
				f.modifyAll(DontBuffer,0);
			w.contentsAdded();
			//
			// This is critical in Java for there not to be a
			// window activated race condition.
			//
			if (!f.isPopup() && form != null && ((form.windowFlagsToClear & WindowConstants.FLAG_IS_VISIBLE) == 0)){
				form.fixWindowTitle();
				f.getWindow().waitUntilPainted(6000);
			}
		}
		return doNotifyTop;
		//if (doNotifyTop)
		//notifyTop(parent.getWindow(),true);
	}

//	==================================================================
	public static void execFrame(Frame f,Container parent) {execFrame(f,parent,0);}
	public static void showFrame(Frame f,Container parent) {showFrame(f,parent,0);}
//	==================================================================
//	==================================================================
	public static void removeFrom(Container c,Control ctrl)
//	==================================================================
	{
		c.remove(ctrl);
	}
	
	static void _makeModal(Frame f, Window w, boolean make)
	{
		Control.firstPress = true;
		Handle h = f.openState;
		w.surface.setModal(make);
		if (make){
			h.setFlags(h.Running,h.Stopped);
			Thread t = Thread.currentThread();
			if (t instanceof WindowEventThread){
				Window win = ((WindowEventThread)t).window;
				f.createdWindowThread = new WindowEventThread(win);
			}else
				f.createdWindowThread = null;
		}else{
			h.setFlags(Handle.Stopped,Handle.Running);
			if (f.createdWindowThread != null) f.createdWindowThread.close();
		}
	}

	public static void freezeSIP(Control forWho)
	{
		WindowEventThread wt = Window.findOrMakeWindowEventThread();
		wt.freezeSip = true;
	}
	public static EventThreadData getEventThreadData()
	{
		WindowEventThread wt =  Window.findOrMakeWindowEventThread();
		return wt.data;	
	}
	public static PenEvent currentPenPress()
	{
		return getEventThreadData().currentPenPress;
	}
	public static void setCurrentPenPress(PenEvent ev)
	{
		getEventThreadData().currentPenPress = ev;
	}
	public static void hideFrame(final Frame f)
	{
		doHideFrame(f);
		/*
		Window w = f.getWindow();
		if (w == null) return;
		if (true || w.inEventThread()) doHideFrame(f);
		else
			new WindowThreadTask(){
				protected void doRun(){
					doHideFrame(f);
				}
			}.execute(w);
		*/
	}
//	==================================================================
	private static void doHideFrame(Frame f)
//	==================================================================
	{
		Window toClose = null;
		Control oldFocus = null;
		Control newFocus = null;
		//
		// Change this back to false if there is trouble.
		//
		boolean deferFocus = true;
		synchronized(frameChangeLock){
			try{
			Window ma = Application.mainApp;
			if (ma == null) return;
			if (ma.focus != null)
				if (ma.focus.isChildOf(f))
					ma.focus = null;
			Window w = f.getWindow();
			if (w == null) return;
			Vector frames = w.frames;
			if (f == null) {
				//new Exception().printStackTrace();
				return;
			}
			if (f.parentFrame != null) f.parentFrame.removeChildFrame(f);
			Rect r = getAppRect(f);
			if (r == null) return;
			if (frames.indexOf(f) != -1) {
				notifyTop(w,false);
				frames.remove(f);
				if (frames.size() != 0);
				notifyTop(w,true);
				int sz = inFocus.size();
				if (sz != 0)  {
					sz--;
					oldFocus = (Control)inFocus.get(sz);
					inFocus.removeElementAt(sz);
					sz--;
					boolean tookOff = false;
					if (sz >= 0){
						Control c = (Control)inFocus.get(sz);
						if (c != null) {
							newFocus = c;
							if (!deferFocus && oldFocus != null) {
								takeFocusOff(oldFocus,ByFrameChange,c);
								oldFocus = null;
								tookOff = true;
							}
							if (c.hasModifier(c.ShowSIP,false) && !f.isPopup() && c.canEdit()) changeSip(1);
							else if (!c.hasModifier(c.KeepSIP,false) && !(f instanceof CarrierFrame)/* && !Frame.hasSipResized(w)*/) changeSip(0);
							else if (c.hasModifier(c.KeepSIP,false)) changeSip(prevSip);
						}
					}
					if (!deferFocus && !tookOff && oldFocus != null) {
						takeFocusOff(oldFocus,ByFrameChange,null);
						oldFocus = null;
					}
				}
			}
			Container c = f.getParent();
			if (c != null) {
				removeFrom(c,f);
				Vector vv = f.controlsToRefresh;
				f.controlsToRefresh = null;
				if (vv != null){
					for (int i = 0; i<vv.size(); i++){
						Control cc = (Control)vv.get(i); 
						cc.repaintNow();
					}
				}
				//c.repaint();
			}
			if (!deferFocus && newFocus != null){
				setFocusOn(newFocus,ByFrameChange,null);
				newFocus = null;
			}
			if (!f.closeWindow){
				if (f.savedScreen != null) {
					f.savedScreen.restore();
					f.eraseSavedScreen();
				}
				else refreshScreen(w,r);
			}
			f.postEvent(new FrameEvent(FrameEvent.CLOSED,f));
			if (f.closeWindow) {
				((WindowSurface)w.getSurface()).setVisible(false);
			}else{
				//if (f.isModal) w.closeModal(false);
			}
			if (!f.isModal)
				f.openState.setFlags(Handle.Stopped,Handle.Running);
			else
				_makeModal(f,w,false);
			if (f.closeWindow) toClose = w;
			}finally{
				//ewe.sys.Vm.debug(""+f.listeners+", "+f.getParent()+", "+f.parentFrame);
				//ewe.sys.Vm.debug("Hidden: "+inFocus.toString());
			}
		}
		if (toClose != null) toClose.close();
		f.hidden();
		if (f.closeWindow) Window.applicationToFront();
		if (oldFocus != null)
			takeFocusOff(oldFocus, ByFrameChange, newFocus);
		if (newFocus != null)
			setFocusOn(newFocus,ByFrameChange,null);
	}
	/**
	* If this is true, each time a control is activated, it acts as if it were activated by a
	* keyboard selection (i.e. the used TAB to access it), unless the control was activated by
	* a pen/mouse press. This only works on devices that have no mouse pointer and is used to
	* facilitate one handed entry on devices that have a Jog Wheel or other such input device.
	**/
	public static boolean showActiveControlOnPDA = true;

	//private static Rect fullRect = new Rect(), cRect = new Rect();
	/**
	* This returns the very top frame in a window.
	**/
//	===================================================================
	public static Frame windowFrame(Control who)
//	===================================================================
	{
		if (who == null) return Application.mainApp.contents;
		Window w = who.getWindow();
		if (w == null) return null;
		return w.contents;
	}
	/**
	* This returns the area on the Window of the control that is not obscured by the SIP. This is relative to the
	* client area of the Window. If no area is visible it will return null;
	**/
//	===================================================================
	public static Rect visibleWindowClientArea(Control who,Rect dest)
//	===================================================================
	{
		Window w = who.getWindow();
		if (w == null) return null;
		Rect r = w.getWindowRect(Rect.getCached(),false);
		Rect rc = w.getWindowRect(Rect.getCached(),true);
		try{
			int x = r.x, y = r.y;
			int cx = rc.x, cy = rc.y;
			rc.x += x; rc.y += y;
			if (Window.visibleWidth != 0){
				r.set(0,0,Window.visibleWidth,Window.visibleHeight);
				rc.getIntersection(r,rc);
			}
			rc.x -= (x+cx); rc.y -= (y+cy);
			if (rc.width <= 0 || rc.height <= 0) return null;
			rc.y -= w.contents.y;
			return Rect.unNull(dest).set(rc);
		}finally{
			rc.cache(); r.cache();
		}
	}
	
	/**
	Set this true if you wish to send FrameEvent.NOT_ON_TOP and FrameEvent.NOW_ON_TOP 
	events.
	**/
	public static boolean sendFrameOnTopEvents = false;
	
//	-------------------------------------------------------------------
	static void sendFrameEvent(Control c,int which)
//	-------------------------------------------------------------------
	{
		if (!(c instanceof Frame)) return;
		c.postEvent(new FrameEvent(which,c));
	}

//	-------------------------------------------------------------------
	static void notifyTop(Window w,boolean onTop)
//	-------------------------------------------------------------------
	{
		int which = onTop ? FrameEvent.NOW_ON_TOP : FrameEvent.NOT_ON_TOP;
		if (w == null) return;
		if (w.frames.size() != 0){
	 		Frame c = (Frame)w.frames.get(w.frames.size()-1);
	 		Form wc = getForm(c);
			if (wc != null && !c.isPopup()){
				wc.fixWindowTitle();
			}
			if (sendFrameOnTopEvents) sendFrameEvent(c,which);
		}else{
			if (sendFrameOnTopEvents){
				Iterator it = w.contents.getCachedChildren(false);
				for (;it.hasNext();)
					sendFrameEvent((Control)it.next(),which);
				Cache.put(it);
			}
		}
	}
//	===================================================================
	public static void frameOnTop(Control c)
//	===================================================================
	{
		Frame f = c.getFrame();
		Window w = c.getWindow();
		if (f != null && w != null) {
			Window.topFrameChanging();
			Frame top = topFrame(c);
			notifyTop(w,false);
			w.frames.remove(f);
			w.frames.add(f);
			notifyTop(w,true);
		}
	}
	
	private static Vector inFocus = new Vector();
	/**
	 * Return the Control currently in focus.
	 */
//	==================================================================
	public static Control focusedControl()
//	==================================================================
	{
		if (inFocus.size() == 0) return null;
		return (Control)inFocus.get(inFocus.size()-1);
	}
	/**
	 * Returns the topmost Frame for the Window that a Control is on.
	 * @param who the Window or child of the Window.
	 * @return the topmost Frame for the Window.
	 */
//	==================================================================
	public static Frame topFrame(Control who)
//	==================================================================
	{
		if (who == null) return null;
		Window w = (who instanceof Window) ? (Window)who : who.getWindow();
		if (w == null) return null;
		synchronized(w.frames){
			int sz = w.frames.size();
			if (sz != 0) {
				Frame f = (Frame)w.frames.get(sz-1);
				if (f != allParentFrame) 
					return f;
			}
		}
		if (allParentFrame != null && allParentFrame.tail instanceof Frame)
			return (Frame)allParentFrame.tail;
		if (w.contents.tail instanceof Frame)
			return (Frame)w.contents.tail;
		return null;
	}

//	-------------------------------------------------------------------
	private static void setFocusOn(Control c, int how, Control old)
//	-------------------------------------------------------------------
	{
		//if (!(c instanceof EditControl)) c.getWindow().checkSipCoverage(c);
		c.gotFocus(how);
		//if (c instanceof mCheckBox) new Exception().printStackTrace();
		//Application._Application.setFocus(c);//DONT PUT THIS. CAUSES EVENT DIRECTION PROBLEMS.
		if (focusedControl() == c){
			Window w = c.getWindow();
			if (w != null) {
				//new Exception().printStackTrace();
				w.focus = c;//w.setFocus(c);
			}
			ControlEvent ce = new ControlEvent(ControlEvent.FOCUS_IN,c);
			ce.oldOrNewFocus = old;
			c.postEvent(ce);
		}else{
			//System.out.println("Nope not in focus!");
		}
	}
//	-------------------------------------------------------------------
	private static void takeFocusOff(Control c, int how, Control newFocus)
//	-------------------------------------------------------------------
	{
		//System.out.println("Lost focus: "+c);
		c.lostFocus(how);
		//Application._Application.setFocus(c);//DONT PUT THIS. CAUSES EVENT DIRECTION PROBLEMS.
		ControlEvent ce = new ControlEvent(ControlEvent.FOCUS_OUT,c);
		ce.oldOrNewFocus = newFocus;
		c.postEvent(ce);
	}
	/**
	 * Call this if you are removing a Control from the screen and you want to ensure
	 * that any Control that has the focus and which may be a child of the Control being
	 * removed
	 * will lose the focus.
	 * @param c the Control being removed.
	 * @return true if a child Control did have its focus removed.
	 */
	public static boolean removing(Control c)
	{
		Control f = focusedControl();
		if (f == null) return false;
		if (f == c) {
			Gui.takeFocus(null,ByRequest);
			return true;
		}
		if (!(c instanceof Container)) return false;
		if (!f.isChildOf((Container)c)) return false;
		Gui.takeFocus(null,ByRequest);
		return true;
	}
	public static void ensureVisible(Control c)
	{
		Rect cRect = Rect.getCached();
		Rect fullRect = Rect.getCached();
		Point tp = Point.getCached(0,0);
		try{
		if (c.parent != null && !c.parent.dontAutoScroll){
			boolean didScroll = false;
			Container useParent = c.parent;
			cRect.set(c.x,c.y,c.width,c.height);
			
			if (c.promptControl != null && c.promptControl.parent != null){
				Control cp = c.promptControl;
				useParent = cp.parent;
				if (useParent != c.parent){
					Point pp = Gui.getPosInParent(c,useParent,tp);
					if (pp != null) {
						cRect.x += pp.x;
						cRect.y += pp.y;
					}
				}
				cRect.unionWith(fullRect.set(cp.x, cp.y, cp.width, cp.height));
				if (useParent.scrollToVisible(cRect.x,cRect.y,cRect.width,cRect.height))
					didScroll = true;
				cRect.set(c.x,c.y,c.width,c.height);
				if (useParent != c.parent){
					Point pp = Gui.getPosInParent(c,useParent,tp);
					if (pp != null) {
						cRect.x += pp.x;
						cRect.y += pp.y;
					}
				}
			}
			
			if (useParent.scrollToVisible(cRect.x, cRect.y, cRect.width, cRect.height)){
				didScroll = true;
			}
			if (didScroll) c.parent.repaintNow();
		}
		}finally{
			cRect.cache();
			fullRect.cache();
			tp.cache();
		}
	}
	static void releaseFocus()
	{
		
	}
	
	private static Control waitingForFocus = null;
	private static boolean inTakeFocus = false;
	/**
	 * This tells the Gui to assign focus to a particular control. This will also handle removing
	 * the focus from any previously focused control. You can also use a null control to remove
	 * focus altogether.
	 * @param c The control to receive the focus, or null to remove the focus altogether.
	 * @param how Should be Control.ByRequest for a programmatic focus change. But it can also be:
		 	Control.ByKeyboard, Control.ByMouse, Control.ByPen (same as ByMouse), Control.ByFrameChange.
	 */
//	==================================================================
	public static void takeFocus(Control c,int how)
//	==================================================================
	{
		//System.out.println("TF: "+c+", "+how);
		synchronized(Gui.class){
			if (inTakeFocus){
				if (c != null) waitingForFocus = c;
				return;
			}
			inTakeFocus = true;
		}
		try{
			boolean first = true;
			while(first || waitingForFocus != null){
				if (!first){
					c = waitingForFocus;
					how = ByRequest;
					waitingForFocus = null;
				}
				first = false;
				WindowEventThread wt = Window.findOrMakeWindowEventThread();
				Rect cr1 = Rect.getCached(), cr2 = Rect.getCached();
				Point tp = Point.getCached(0,0);
				Rect fullRect = cr1, cRect = cr2;
				try{
					if (showActiveControlOnPDA && !hasMousePointer && how != Control.ByMouse) {
						how = ByKeyboard;
					}
					try{
						if (focusCount == 0) newSip = -1;
						focusCount++;
						if (c != null){
							if (!c.amOnTopFrame()) {
								return;
							}
							sipWindow = c.getWindow();
						}
						//if (c != null) ewe.sys.Vm.debug(c.getClass().toString());
						int sz = inFocus.size();
						if (sz == 0) {
							inFocus.add(null);
						}
						else sz--;
						Control cur = (Control)inFocus.get(sz);
						if (cur == c) return;
						//System.out.println("From: "+cur+" to: "+c);
						//if (c == null) new Exception().printStackTrace();
						inFocus.setElementAt(c,sz);
						if (cur != null) {
							takeFocusOff(cur,how,c);
						}
						if (c != null) {
							ensureVisible(c);
							if (c.hasModifier(c.ShowSIP,false) && c.canEdit()) newSip = 1;
							else if (!c.hasModifier(c.KeepSIP,false) && !wt.freezeSip){// && !Frame.hasSipResized(sipWindow)) {
								Frame cf = c.getFrame();
								if (cf != null) 
									if (!cf.isPopup())
										cf = null;
								if (cf == null) newSip = 0;
							}else{
								newSip = prevSip;
							}
							setFocusOn(c,how,cur);
						}else{
							newSip = 0;
						}
					}finally{
						focusCount--;
						if (focusCount == 0 && newSip != -1){
							changeSip(newSip);
						}
					}
				}finally{
					cr1.cache(); cr2.cache(); tp.cache();
				}
			}
		}finally{
			inTakeFocus = false;
		}
			//if (Control.debugFlag) ((Object)null).toString();
	}
	
//public static Object staticPaintLock = new Object();
//public static Rect rectBuff = new Rect(), rectBuff2 = new Rect();
//public static Dimension dimBuff = new Dimension(), dimBuff2 = new Dimension();
	
//public static Object guiLock = new Object();
/** An option for flashMessage. Will also beep when the message is shown. **/
public static final int FLASH_BEEP = 0x1;
/**
Display a short message on the screen, and keep it on the screen until
flashMessageOff() is called.
* @param message A single-line message to display.
* @param parent The parent Control.
* @return an Object that you should use with flashMessageOff() when you
* want to remove the message.
*/
//===================================================================
public static Object flashMessageOn(String message, Control parent)
//===================================================================
{
	return flashMessageOn(message.indexOf('\n') == -1 ? new Label(message) : new MessageArea(message),parent);
}
/**
 * Display a custom Control modally in the center of the Frame of the parent control. 
 * The Control is displayed in a Form with a Light blue background without
 * any title bar with an "bump" border. To remove the message call close() or
 * exit() on the returned Form.
 *  
 * @param toDisplay the Control to display.
 * @param parent the parent Control to display the control in.
 * @return the Form the Control is displayed in.
 */
//===================================================================
public static Form flashMessageOn(Control toDisplay, Control parent)
//===================================================================
{
	Form f = new Form();
	f.windowTitle = f.WINDOW_TITLE_DONT_CHANGE;
	f.backGround = Color.LightBlue;
	f.foreGround = Color.Black;
	f.addNext(toDisplay);
	f.hasTopBar = false;
	f.resizable = false;
	f.setBorder(f.EDGE_BUMP|f.BDR_OUTLINE,2);
	f.exitButtonDefined = true;
	f.exec(parent.getFrame(),CENTER_FRAME|PUTTING_POPUP);
	return f;
}

/**
Remove the short message as displayed by flashMessageOn().
* @param message The object returned by flashMessageOn().
*/
//===================================================================
public static void flashMessageOff(Object message)
//===================================================================
{
	if (message instanceof Form) 
		((Form)message).close(0);
}
//===================================================================
public static void flashMessage(String message, Control parent)
//===================================================================
{
	flashMessage(message,750,parent,FLASH_BEEP);
}

//===================================================================
public static void flashMessage(String message,final int timeInMillis, Control parent,int flash_options)
//===================================================================
{
	//
	// FIXME dont cover the dontCover
	//
	final Form f = (Form)flashMessageOn(message,parent);
	if ((flash_options & FLASH_BEEP) != 0) Sound.beep();
	new Task(){
		protected void doRun(){
			sleep(timeInMillis);
			f.close(0);
		}
	}.start();
	f.waitUntilClosed();
}
public static WindowSurface getMainWindowSurface()
{
	return Application.mainApp.surface;
}

public static int getGuiFlags()
{
	return getMainWindowSurface().getGuiFlags();
}

/**
* This will setup an the title bar on a Form if the main ewe window does
* not have a title and a close button.
**/
//===================================================================
public static void setAppFormTitle(Form form,String title)
//===================================================================
{
	setFormTitle(Application.mainApp,form,title);
}
/**
* This will setup an the title bar on a Form if the main ewe window does
* not have a title and a close button.
**/
//===================================================================
public static void setFormTitle(Window w,Form form,String title)
//===================================================================
{
	boolean setTitle = true;
	if (w != null){
		int flag = w.getWindowFlags();
		if ((flag & (w.FLAG_HAS_TITLE|w.FLAG_HAS_CLOSE_BUTTON)) == (w.FLAG_HAS_TITLE|w.FLAG_HAS_CLOSE_BUTTON))
			setTitle = false;
	}
	if (setTitle) {
		form.hasTopBar = true;
		form.title = title;
		form.exitButtonDefined = false;
	}else{
		form.hasTopBar = false;
	}
}
/**
* This will set the OK/Cancel of a form to be either in the title bar (for mobile devices)
* or on the bottom for desktop devices.
**/
//===================================================================
public static void setOKCancel(Form f,boolean useNonDefaultButtons)
//===================================================================
{
	//if (isSmartPhone){
	int ob = useNonDefaultButtons ? Form.OKB : Form.DEFOKB;
	int cb = useNonDefaultButtons ? Form.CANCELB : Form.DEFCANCELB;
	if (hasSoftKeys){
		SoftKeyBar sb = new SoftKeyBar();
		sb.setKey(1,"OK|"+Form.EXIT_IDOK,f.tick,null);
		sb.setKey(2,"Cancel|"+Form.EXIT_IDCANCEL,f.cross,null);
		f.setSoftKeyBarFor(null,sb);
	}else if ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_IS_MOBILE) != 0){
		if ((f.windowFlagsToSet & Window.FLAG_MAXIMIZE_ON_PDA) != 0)
			f.doButtons(ob|cb);
		else{
			f.titleCancel = new Button(f.cross);
			f.titleOK = new Button(f.tick);
			f.hasTopBar = true;
			f.windowFlagsToClear |= Window.FLAG_HAS_TITLE;
		}
	}else
		f.doButtons(ob|cb);
}
/**
* This will set the OK/Cancel of a form to be either in the title bar (for mobile devices)
* or on the bottom for desktop devices.
**/
//===================================================================
public static void setOKCancel(Form f)
//===================================================================
{
	setOKCancel(f,false);
}
/**
* This will iconize a button/control that has its text already set. If an icon is found
* successfully it will be displayed. If leaveText is true then the text is displayed with
* the icon, otherwise only the icon is displayed.
**/
//===================================================================
public static boolean iconize(Control c,String image,boolean leaveText,FontMetrics fm)
//===================================================================
{
	return iconize(c,Control.loadImage(image),leaveText,fm);
}
/**
* This will iconize a button/control that has its text already set. If an icon is found
* successfully it will be displayed. If leaveText is true then the text is displayed with
* the icon, otherwise only the icon is displayed.

**/
//===================================================================
public static boolean iconize(Control c,IImage image,boolean leaveText,FontMetrics fm)
//===================================================================
{
	if (image == null) return false;
	if (image.getWidth() == 0) return false;
	if (fm == null) fm = c.getFontMetrics();
	if (leaveText) {
		c.image = new IconAndText(image,c.makeHot(c.text,null).toString(),fm);
		((IconAndText)c.image).textColor = null;
	}else c.image = image;
	c.text = "";
	return true;
}
static final int anchors[] = 
{'W',UIConstants.WEST,'E',UIConstants.EAST,'N',UIConstants.NORTH,'S',UIConstants.SOUTH,'H',UIConstants.HEXPAND,'h',UIConstants.HCONTRACT,'V',UIConstants.VEXPAND,'v',UIConstants.VCONTRACT,'F',UIConstants.FILL};
static final int aligns[] = {'L',UIConstants.LEFT,'R',UIConstants.RIGHT};
//-------------------------------------------------------------------
static int decode(String specs,int [] codes)
//-------------------------------------------------------------------
{
	int ret = 0;
	for (int i = 0; i<codes.length; i+=2)
		if (specs.indexOf((char)codes[i]) != -1) ret |= codes[i+1];
	return ret;
}
public static int decodeAnchor(String specs) {return decode(specs,anchors);}
public static int decodeAlignment(String specs) {return decode(specs,aligns);}
//-------------------------------------------------------------------
static Form getTopmostForm(Control c)
//-------------------------------------------------------------------
{
	Form top = null;
	for (; c != null; c = c.getParent())
		if (c == allParentFrame) break;
		else if (c instanceof Form) top = (Form)c;
	return top;
}
//===================================================================
public static Dimension getPreferredDialogSize()
//===================================================================
{
	Dimension d = new Dimension(500,300);
	/*
	Rect r = (Rect)mApp.mainApp.getInfo(Window.INFO_PARENT_RECT,null,new Rect(),0);
	if (r.height <= 320 || r.width <= 240) {
		d.width = r.width;
		d.height = r.height;
	}else{
		d.width = 500;
		d.height = 400;
	}
	*/
	return d;
}

/**
 * Get the best file chooser Form for the platform. This is either a SimpleFileChooser
 * or a eve.ui.filechooser.FileChooser.
 * @param parameters the parameters for the file chooser.
 * @param forFile the file to execute the chooser for. If this is not null and the
 * method getBestFileChooser() of the File returns a valid Form - then that Form
 * will be returned.
 * @return the best file chooser Form for the platform.
 */
public static Form getBestFileChooser(FileChooserParameters parameters,File forFile)
{
	Object obj = forFile == null ? null : forFile.getBestFileChooser(parameters);
	if (obj instanceof Form) return (Form)obj;
	Type t = new Type(parameters.getString(parameters.FILE_TYPE_HINT,"none").equalsIgnoreCase("image")
			? "eve.ui.filechooser.ImageFileChooser" : "eve.ui.filechooser.FileChooser");
	if (t.exists() && !isSmartPhone){
		return (Form)t.newInstance("(Leve/io/FileChooserParameters;)V",new Object[]{parameters});
	}
	return new SimpleFileChooser(parameters);
}
public static File chooseFile(boolean forSaving,String title, String masks, String start, int fcpOptions, File baseFile)
{
	FileChooserParameters fcp = new FileChooserParameters();
	fcp.set(fcp.TYPE,forSaving ? fcp.TYPE_SAVE : fcp.TYPE_OPEN);
	fcp.setInt(fcp.OPTIONS,fcpOptions);
	fcp.set(fcp.TITLE, title);
	fcp.add(fcp.FILE_MASK,masks);
	if (start != null) 
		fcp.set(fcp.START_LOCATION,start);
	Form fc = Gui.getBestFileChooser(fcp,baseFile != null ? baseFile.getNewFile() : File.getNewFile());
	if (fc.execute() == Form.IDCANCEL) return null;
	return (File)fcp.getValue(fcp.CHOSEN_FILE,null);
}
public static File chooseFile(boolean forSaving,String title, String masks, String start)
{
	return chooseFile(forSaving,title,masks,start,0,null);
}

public static boolean hasPendingEvents()
{
	synchronized(Window.openWindows){
		int sz = Window.openWindows.size();
		for (int i = 0; i<sz; i++){
			Window w = (Window)Window.openWindows.get(i);
			if (w != null && w.hasPendingEvents() 
					&& !w.inCurrentEventThread()
					) return true;
		}
	}
	return false;
}
/**
 * Yield to GUI events if any are pending up to a maximum length of time.
 * Use with care since doing a yield may not actually handle any events if all
 * the other Window threads are busy. Note that if this Thread is the current window
 * event thread, and this window has pending events (but no other does) then a yield
 * will not be done since those events would never be handled by this thread
 * yielding anyway.<p>
 * Note that calls to Device.yieldToEvents() will end up at this call here once
 * the eve.ui package is present.<p> 
 * @param max the maximum length of time to yield while there are still events pending.
 */
public static void yieldToEvents(int max)
{
	try{
		if (!hasPendingEvents()) return;
		long now = System.currentTimeMillis();
		while(true){
			if (!hasPendingEvents()) return;
			try{
				Thread.sleep(5);
			}catch(InterruptedException e){
				return;
			}
			if (System.currentTimeMillis()-now >= max) return;
		}
	}catch(Throwable t){}
}

/**
 * This must be called in eveMain() and 
 * makes a PocketPC style PDA act like a Windows Mobile 5/6 Smartphone/PocketPC
 * with two Soft keys on the bottom or an Android type Smartphone
 * with a single menu key. On a touch screen PDA (e.g. older versions
 * of PocketPC or the Zaurus) the two soft keys can only be activated using
 * the screen.
 * @param softkeyType one of the SoftKeyBar.TYPE_XXX values.
 */
public static void simulateSoftkeysOnPDA(int softkeyType)
{
	int flags = Vm.getParameter(Vm.VM_FLAGS);
	String windowsVersion = Vm.getProperty("windows.version","none");		
	resetFlags();
	if (!isPDA || hasKeyboard) return;
	/*
	*/
	try{
		if (softkeyType == SoftKeyBar.TYPE_MENU){
			if ((flags & VmConstants.VM_FLAG_HIDDEN_SOFTKEYS) != 0)
				return;
			if (!windowsVersion.equalsIgnoreCase("mobile 5")&&!windowsVersion.equalsIgnoreCase("mobile 6")){
				Vm.setProperty("windows.version","mobile 5");
				if ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_SIP_BUTTON_ON_SCREEN) != 0)
					SIPButton.sipActuallyOnRight = true;
			}
			Vm.setParameter(VmConstants.TURN_ON_VM_FLAG_BITS,VmConstants.VM_FLAG_HAS_SOFT_KEYS|VmConstants.VM_FLAG_HIDDEN_SOFTKEYS);
			simulateSoftKeys = true;
			setNoMultipleWindows();
		}else{
			if (hasSoftKeys || windowsVersion.equalsIgnoreCase("mobile 5") || windowsVersion.equalsIgnoreCase("mobile 6"))
				return;
			Vm.setProperty("windows.version","mobile 5");
			simulateSoftKeys = true;
			SoftKeyBar.rawKeys = softkeyType == SoftKeyBar.TYPE_SINGLE ? 1 : 2;
			setNoMultipleWindows();
			if ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_SIP_BUTTON_ON_SCREEN) != 0)
				SIPButton.sipActuallyOnRight = true;
			Vm.setParameter(VmConstants.TURN_ON_VM_FLAG_BITS,VmConstants.VM_FLAG_HAS_SOFT_KEYS);
		}
	}finally{
		
	}
}
/**
 * This must be called in eveMain() and is used to simulate the SoftKeyBar
 * on a PDA that does not normally support them (e.g. PocketPC 200x). 
 */
public static void simulateSoftkeysOnPDA()
{
	simulateSoftkeysOnPDA(
			//SoftKeyBar.TYPE_MENU
			//SoftKeyBar.TYPE_SINGLE
			SoftKeyBar.TYPE_DOUBLE
			);
}
/**
 * This must be called in eveMain().
 * @param simulateSoftKeys one of the SoftKeyBar.TYPE_XXX values
 * to simulate a SoftKeyBar on a mobile system that does not have
 * any (e.g. PocketPC 200x), use TYPE_NONE not to simulate a SoftKeyBar.
 */
public static void setupFullScreen(int simulateSoftkeys)
{
	if (simulateSoftkeys != SoftKeyBar.TYPE_NONE)
		Gui.simulateSoftkeysOnPDA(simulateSoftkeys);
	SoftKeyBar.hideRemovesSoftKeyBar = true;
	new WindowCreationData().setForDefaultSurface(
			Window.FLAG_FULL_SCREEN, Window.FLAG_HAS_TITLE|Window.FLAG_HAS_CLOSE_BUTTON)
			.create();
}
/**
 * This must be called in eveMain().
 * @param simulateDoubleSoftKeys true to simulate a double SoftKeyBar on a
 * mobile system that does not have any (e.g. PocketPC 200x), false
 * not to simulate a SoftKeyBar..
 */
public static void setupFullScreen(boolean simulateDoubleSoftKeys)
{
	setupFullScreen(simulateDoubleSoftKeys ? SoftKeyBar.TYPE_DOUBLE : SoftKeyBar.TYPE_NONE);
}
/*
static Object pauseThread(Control forControl)
{
	return WindowEventThread.execThread(forControl.getWindow(),forControl);
}
static void resumeThread(Object fromPause)
{
	WindowEventThread.endExecThread(fromPause);
}
*/
}
//####################################################
