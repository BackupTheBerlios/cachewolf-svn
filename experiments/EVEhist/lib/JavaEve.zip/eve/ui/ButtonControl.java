package eve.ui;
import eve.fx.Color;
import eve.fx.Point;
import eve.sys.mThread;

/**
* This is an intermediate class which is the base for mButtons and mCheckBoxes.
**/
//##################################################################
public class ButtonControl extends Control{
//##################################################################

//==================================================================
protected boolean pressState = false, inPress = false;
//==================================================================
public boolean state = false;
public boolean shouldRepeat = false;
public boolean actionOnPress = false;
public boolean flatInside = false;
public int alignment = CENTER;
public int anchor = CENTER;
public int imageAnchor = CENTER;
//==================================================================
/**
* This allows an optional arrow to be displayed along with the text and
* icon. If it is 0, then no arrow is displayed. Otherwise it can be set
* to Up, Down, Left and Right.
**/
public int arrowDirection = 0;//Down;
{
borderColor = Color.Black;
}
//==================================================================
public ButtonControl()
//==================================================================
{
	modify(WantDrag|TakesKeyFocus|WantHoldDown,0);
	holdDownPause = 500;
}

private Color oldBackground;
private boolean switched = false;

//===================================================================
public void gotFocus(int how)
//===================================================================
{
	if (how == ByKeyboard || Gui.useNativeTextInput){
		if (!Gui.useNativeTextInput) borderStyle |= BDR_DOTTED;
		else if (!switched){
			switched = true;
			oldBackground = backGround;
			backGround = Color.LightGreen;
		}
		repaintNow();
	}
	super.gotFocus(how);
}
//===================================================================
public void lostFocus(int how)
//===================================================================
{
	if ((borderStyle & BDR_DOTTED) != 0){
		borderStyle &= ~BDR_DOTTED;
		repaintNow();
	}
	if ( switched){
		backGround = oldBackground;
		switched = false;
		repaintNow();
	}
	super.lostFocus(how);
}

//===================================================================
public void penPressed(Point p) 
//===================================================================
{
	try{
		int flags = getModifiers(true);
		if (!(((flags & (NotEditable|DisplayOnly)) == 0) || ((flags & NotAnEditor) != 0))) return;
		if (!menuIsActive()){
			inPress = pressState = true; 
			if (actionOnPress) fullAction(ByMouse); 
			else repaintNow();
			doPenPress(p);
		}else{
			closeMenu();
		}
	}finally{
	}
}
//===================================================================
public void penHeld(Point p)
//===================================================================
{
	boolean clickedOnPrompt = true;
	if (!isOnMe(p,clickedOnPrompt) || !inPress) return; 
	if (shouldRepeat) {
		fullAction(ByMouse,false); 
		wantAnotherPenHeld = true;
	}
	else doPenHeld(p);
}
//===================================================================
public void penReleased(Point p) 
//===================================================================
{
	boolean clickedOnPrompt = true;
	try{
		if (!inPress && !pressState) return;
		boolean repaintAndLeave = !inPress && pressState;
		inPress = pressState = false; 
		if (repaintAndLeave){
			repaintNow();
			return; 
		}
		//new Exception().printStackTrace();
		if (isOnMe(p,clickedOnPrompt) && !actionOnPress){ 
			fullAction(ByMouse); 
		}else 
			repaintNow();
	}finally{
	}
}
//===================================================================
public void startDragging(DragContext dc) 
//===================================================================
{
	int flags = getModifiers(true);
	if (!(((flags & (NotEditable|DisplayOnly)) == 0) || ((flags & NotAnEditor) != 0))) return; 
	dragged(dc);
}
//===================================================================
public void stopDragging(DragContext dc) 
//===================================================================
{
	int flags = getModifiers(true);
	if (!(((flags & (NotEditable|DisplayOnly)) == 0) || ((flags & NotAnEditor) != 0))) return; 
	penClicked(dc.curPoint);
}
//Point dragPoint = new Point();
//===================================================================
public void fullAction(int how) 
//===================================================================
{
	fullAction(how,true);
}
//===================================================================
public void fullAction(int how,boolean repaint)
//===================================================================
{
	doAction(how); 
	if (repaint) repaintNow(); 
	notifyAction();
}
//===================================================================
public void doAction(int how)
//===================================================================
{
	if (how != ByMouse){
		int bs = borderStyle;
		borderStyle &= ~BDR_DOTTED;
		pressState = true;
		repaintNow();
		mThread.nap(100);
		pressState = false;
		borderStyle = bs;
		repaintNow();
	}
	super.doAction(how);
}
//===================================================================
public void dragged(DragContext dc) 
//===================================================================
{
	boolean clickedOnPrompt = true;
	int flags = getModifiers(true);
	if (!(((flags & (NotEditable|DisplayOnly)) == 0) || ((flags & NotAnEditor) != 0)) || menuIsActive()) return;
	boolean last = pressState;
	pressState = isOnMe(dc.curPoint,clickedOnPrompt);
	if (last != pressState) repaintNow();
}
//===================================================================
public void penRightReleased(Point p)
//===================================================================
{
	if (!startDropMenu(p)) super.penRightReleased(p);
}
//===================================================================
public void doPenHeld(Point p)
//===================================================================
{
	if (!startDropMenu(p)) return;
}
//===================================================================
public void doPenPress(Point p)
//===================================================================
{
}
//===================================================================
public boolean startDropMenu(Point p)
//===================================================================
{
	if (getMenu() == null) return false;
	inPress = false;
	pressState = true;
	return tryStartMenu(p);
}
//===================================================================
public void deactivate()
//===================================================================
{
	inPress = pressState = false;
	repaintNow();
}
//===================================================================
public void activate()
//===================================================================
{
	inPress = false;
	pressState = true;
	repaintNow();
}

//##################################################################
}
//##################################################################

