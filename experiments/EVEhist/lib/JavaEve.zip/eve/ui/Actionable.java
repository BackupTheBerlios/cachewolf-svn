/*
 * Created on Jul 31, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

/**
 * This interface is implemented by Controls that are associated
 * with generating some kind of Action event (e.g. Buttons).
 * @author Michael L Brereton
 *
 */
//####################################################
public interface Actionable {

	public void setAction(String action);
	public String getAction();
}
//####################################################
