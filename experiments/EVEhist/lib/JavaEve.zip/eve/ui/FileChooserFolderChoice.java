package eve.ui;
import java.util.Vector;

import eve.fx.FontMetrics;
import eve.fx.IImage;
import eve.fx.IconAndText;
import eve.io.File;
import eve.util.mString;

//##################################################################
public class FileChooserFolderChoice extends Choice{
//##################################################################

{
	useMenuItems = true;
	alwaysDrop = true;
	indentDropItems = true;
	prompt = "Choose Folder";
	menuOptions |= MENU_FULL_WIDTH;
	menuOptions |= MENU_SHOW_TITLE_IF_EXPANDED;
	dontAllowKeyChangeChoice = true;
}

private Vector levels = new Vector();
//===================================================================
public void updateMenu(File newCurrentDirectory, String[] roots, Vector fileChooserLinks)
//===================================================================
{
	File afile = newCurrentDirectory;
	Vector v = new Vector();
	for(File p = newCurrentDirectory; p != null; p = p.getParentFile()){
		String s = p.getFileExt();
		if (!s.equals(".")){
			v.insertElementAt(s,0);
		}
	}
	removeAll();
	levels.clear();
	File cur = null;
	FontMetrics fm = getMenuFontMetrics();
	int start = 0;
	Vector links = fileChooserLinks;
	if (links != null){
		start = links.size();
		for (int i = 0; i<start; i++){
			FileChooserLink l = (FileChooserLink)links.get(i);
			MenuItem mi = l.addToMenu(this,fm);
			mi.indentLevel = 0;
			levels.add(afile.getNew(l.path));
		}
	}
	String [] all = roots;
	String cd = (String)v.get(0);
	if (all == null) all = new String[]{cd};
	cd = mString.leftOf(cd,':');
	cd = cd.replace('\\','/');
	boolean did = false;
	int sel = 0;
	IImage drive = loadImage("eve/drive.png");
	IImage openFolder = loadImage("eve/openfolder.png");
	for (int r = 0; r<all.length; r++){
		String ss = all[r].replace('\\', '/'); 
		if (!did && mString.leftOf(ss,':').equalsIgnoreCase(cd)){
			did = true;
			int sz = v.size();
			for (int i = 0; i<sz; i++) {
				String dir = (String)v.get(i);
				levels.add(cur = afile.getNew(cur,dir));
				boolean isDrive = i == 0 ? dir.indexOf(':') != -1 : false;
				if (isDrive) dir = dir.toUpperCase();
				MenuItem mi = addItem(dir);
				mi.image = new IconAndText(isDrive ? drive : openFolder,dir,fm).setColor(null,null);
				mi.indentLevel = i;
			}
			sel = sz+r-1+start;
		}else{
			levels.add(afile.getNew(ss));
			//if (all[r].indexOf(':') != -1) all[r] = all[r].toUpperCase();
			MenuItem mi = addItem(all[r]);
			mi.image = new IconAndText(drive,ss,fm).setColor(null,null);
			mi.indentLevel = 0;
		}
	}
	//String msg = did+": "+cd+"\n"+v; Device.messageBox("Debug", msg, Device.MB_TYPE_OK);
	select(sel);
}

//===================================================================
public File getSelectedFolder()
//===================================================================
{
	int idx = selectedIndex;
	if (idx == -1) return null;
	return (File)levels.get(idx);
}
//##################################################################
}
//##################################################################

