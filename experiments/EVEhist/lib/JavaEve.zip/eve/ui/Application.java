/*
 * Created on Jul 31, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import java.util.Hashtable;
import java.util.Iterator;

import eve.fx.Font;
import eve.fx.Sound;
import eve.fx.gui.WindowCreationData;
import eve.fx.gui.WindowSurface;
import eve.fx.sound.SoundClip;
import eve.sys.Vm;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Application extends Window implements Runnable {
	static Hashtable fonts;

	/**
	 * This is NEVER to be executed. It simply embedds in this class
	 * all the essential classes needed by the VM.
	 *
	 */
	static void linkEssensialClasses()
	{
		try{
			new SoundClip("");
		}catch(Exception e){}
	}
	public static String mainTitle = WindowSurface.defaultWindowTitle;
	public static Application mainApp;
	static IApplicationHandler appHandler; 
	//static Frame appFrame;
	
	public static void setApplicationHandler(IApplicationHandler appHandler)
	{
		Application.appHandler = appHandler;
		if (appHandler != null) WindowSurface.noCloseButtons = true;
	}
	public static Font guiFont = new Font("helvetica",Font.PLAIN,12);
	/**
	 * This was the time of the last GUI event.
	 */
	public static long lastKeyPress;
	/**
	 * This is used by WindowSurface to get the default window title.
	 * @return
	 */
	public static String getDefaultWindowTitle()
	{
		return mainTitle;
	}
	public Application()
	{
		super(true);
		if (mainApp == null){
			mainApp = this;
			Sound.setupSounds();
		}
		Vm.addShutdown(this);
		myMainApp = mainApp;
	}
	/**
	* This will be called by mobileWindowEvent() if a Close message is sent by the OS and the
	* application is running on a mobile device. This is because mobile OS's such as WinCE will
	* send Close messages to applications when there is a shortage of free memory to run new
	* applications. By default this simply closes the application immediately.
	You should save the state of the application if necessary and then call exit()
	* to quit the application.
	* @param targetWindow The window that received the CLOSE event.
	* @param flags This will have the Window.FLAG_CLOSE_BY_USER bit set if the system <b>knows</b> for
	* certain that the user pressed a system button to generate the Window.CLOSE event. This is only true
	* for the 'OK' button under Windows CE. It is not possible to tell the difference between the user pressing
	* an 'X' button and the system generating a CLOSE message.
	* @return 
	*/
	/*
//	===================================================================
	public void closeMobileApp(Window targetWindow,int flags)
//	===================================================================
	{
		if (targetWindow == this){
			exit(0);
		}
		else if (targetWindow != null)
			if ((flags & WindowEvent.FLAG_CLOSE_BY_USER) == 0)
				if ((targetWindow.getWindowFlags() & FLAG_HAS_CLOSE_BUTTON) == 0){
					exit(0);
				}
	}
	*/

	public static void exit(int retValue)
	{
		Vm.exit(retValue);
	}
	/**
	 * Call this method to alert the application that fonts have been changed other than through setFont().

	 */
//	===================================================================
	public static void fontsChanged()
//	===================================================================
	{
		guiFont = findFont("gui");
	}
	/**
	 * Add a Font to the application font library. This is basically a Hashtable
		of Fonts which the Eve library and your application can use. The ewe UI library
		uses the Font which is named as "gui" as the default font for controls.
	 * @param font The Font to add.
	 * @param name The name of the Font. Important font names include "gui", "system", "fixed", "text", "small" and "big"
	 */
//	===================================================================
	public static void addFont(Font font,String name)
//	===================================================================
	{
		name = name.toLowerCase();
		if (name.equals("gui")) guiFont = font;
		if (fonts == null) fonts = new Hashtable();
		fonts.put(name,font);
	}
	/**
	* Find a font in the application Font library. This is basically a Hashtable
		of Fonts which the ewe library and your application can use. The ewe UI library
		uses the Font which is named as "gui" as the default font for controls.
	* @param name The name of the Font to look for.  Important font names include "gui", "system", "fixed", "text", "small" and "big"
	* @return The Font found. If no Font is found for that name, the "system" font is returned.
	*/
//	===================================================================
	public static Font findFont(String name)
//	===================================================================
	{
		return findFont(name,true);
	}
	/**
	* Find a font in the application Font library. This is basically a Hashtable
		of Fonts which the ewe library and your application can use. The ewe UI library
		uses the Font which is named as "gui" as the default font for controls.
	* @param name The name of the Font to look for.  Important font names include "gui", "system", "fixed", "text", "small" and "big"
	* @param doDefault If this is true and no font is found for the name, the "system" font is returned. 
	If it is false and no font is found for the name, null will be returned.
	* @return The Font found. 
	*/
//	===================================================================
	public static Font findFont(String name,boolean doDefault)
//	===================================================================
	{
		if (fonts == null) fonts = new Hashtable();
		Font f = (Font)fonts.get(name.toLowerCase());
		if (f != null) return f;
		f = (Font)fonts.get("system");
		if (f == null) f = new Font("Helvetica",Font.PLAIN,12);
		return f;
	}

	/**
	 * Get an Iterator for all the entries in the fonts hashtable.
	 * Each item returned by the Iterator will be java.util.Map.Entry object that
		can be used to get the font name (the "key" for the entry) and the font itself (the "value" for the entry).
		This can be used to change all font entries as necessary. If you do change the fonts using the entries
		then you should call the fontsChanged() method.
	 * @return an Iterator for all the entries in the fonts hashtable.
	 */
//	===================================================================
	public static Iterator getFonts()
//	===================================================================
	{
		if (fonts == null) fonts = new Hashtable();
		return fonts.entrySet().iterator();
	}
	/**
	 * This is used to shutdown the application.
	 */
	public void run()
	{
		Gui.shutdown();
		try{
			if (mainApp != null) mainApp.close();
		}catch(Throwable t){}
		applicationStarted = false;
		mainApp = null;
		openWindows.clear();
		WindowSurface.shutdown();
	}
	//
	private static boolean applicationStarted = false;
	//
	/**
	 * Call this as the first line of your Gui Application's main() method.
	 * This will ensure that eveMain() is called before the main() method
	 * code is called.
	 * @param args the args as presented to main().
	 */
	public static void startApplication(String args[])
	{
		try{
		Gui.resetFlags();
		String calling = Vm.getCallingClassName("eve.ui.Application");
		Vm.startEve(args,calling);
		if (applicationStarted) return;
		applicationStarted = true;
		Gui.resetFlags();
		//VMOptions.getVMOptions().apply();
		VMOptions.doApply();
		guiFont = findFont("gui");
		if (mainApp == null) {
			WindowSurface ws = WindowSurface.getMainSurface();
			mainApp = new Application();
			if (ws == null){
				WindowCreationData wcd = new WindowCreationData();
				//wcd.bounds.width = 240; wcd.bounds.height = 320;
				wcd.title = mainTitle;
				wcd.setForDefaultSurface(0, 0);
				mainApp.create(wcd);
			}else{
				mainApp.create(ws);
				mainApp.setTitle(mainTitle);
			}
		}
		if (Gui.getNoMultipleWindows()){
			WindowSurface ws = (WindowSurface)mainApp.getSurface();
			if ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_NO_VISIBLE_WINDOW) == 0){
				ws.setVisible(true);
				ws.setState(ws.STATE_TO_FRONT);
			}
		}
		int softkeySetup = 0;
		//softkeySetup |= SoftKeyBar.SETUP_USE_KEYPAD; //FIXME remove this.
		if ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_USE_SOFT_KEYPAD) == Vm.VM_FLAG_USE_SOFT_KEYPAD)
			softkeySetup |= SoftKeyBar.SETUP_USE_KEYPAD;
		if (Gui.hasSoftKeys)
			softkeySetup |= SoftKeyBar.SETUP_SHOW_SOFTKEYS;
		if (softkeySetup != 0){
			SoftKeyBar.setupScreen(softkeySetup);
		}
		Gui.doStartupTasks();
		}catch(Throwable t){
			t.printStackTrace();
		}
	}

}
//####################################################
