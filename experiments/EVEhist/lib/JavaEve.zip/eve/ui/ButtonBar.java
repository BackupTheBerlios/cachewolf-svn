package eve.ui;
/**
* A ButtonBar is a simple CellPanel which allows you to easily add
* buttons which will be displayed with equal widths.
**/
//##################################################################
public class ButtonBar extends CellPanel{
//##################################################################
{
	equalWidths = true;
	//defaultAddMeCellConstraints = HSTRETCH;
}
//==================================================================
public ButtonBar(){}
//==================================================================
//==================================================================
public Button add(String name)
//==================================================================
{
	Button b = new Button(name);
	addNext(b);
	return b;
}
//==================================================================
public Button [] add(String [] names)
//==================================================================
{
	int num = names.length;
	Button [] b = new Button[num];
	for (int i = 0; i<num; i++) 
		b[i] = add(names[i]);
	return b;
}
//##################################################################
}
//##################################################################

