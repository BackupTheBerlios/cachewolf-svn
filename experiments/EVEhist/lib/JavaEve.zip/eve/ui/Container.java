package eve.ui;

import java.util.Iterator;

import eve.sys.Cache;
import eve.sys.Vm;
import eve.ui.event.KeyEvent;
import eve.ui.event.PenEvent;

/**
 * Container is a control that contains child controls - but you would not likely use
 * it directly. Instead you would use a CellPanel or Panel to add Controls to. Those
 * Containers manage the layout of the Controls within themselves.
 */

public class Container extends Control
{
/**
* If this is set to true, then when child Controls gain the focus the GUI 
* will not attempt to scroll so that the focused Control is visible.
**/
public boolean dontAutoScroll = false;

/**
 * You would generally not use this method. It is used
 * @param control
 */
//===================================================================
public void addDirectly(Control control)
//===================================================================
{
	add(control);
}
/**
 * Adds a child control to this container - you should not generally use
 * this method. Instead you would use the addNext()/addLast() of a Panel.
 */
//===================================================================
protected void add(Control control)
//===================================================================
	{
	if (control.parent != null)
		control.parent.remove(control);
	// set children, next, prev, tail and parent
	control.next = null;
	if (children == null)
		children = control;
	else
		tail.next = control;
	control.prev = tail;
	tail = control;
	control.parent = this;
	control.penStatus |= PenIsOn;
	if (!(control instanceof Container) && hasModifier(MouseSensitive,false))
		control.modify(MouseSensitive,0);
	if (control.hasModifier(MouseSensitive,false) && !(control instanceof Container) && ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_NO_MOUSE_POINTER) == 0)){
		PenEvent.wantPenMoved(control,PenEvent.WANT_PEN_MOVED_ONOFF,true);
		control.penStatus &= ~PenIsOn;
	}
}

private HideControl getHidden(Control child)
{
	if (child == null) return null;
	HideControl hc = (HideControl)child.getTag(TAG_HIDE_CONTROL_OBJECT,null);
	if (hc == null){
		hc = new HideControl(child,this);
		child.setTag(TAG_HIDE_CONTROL_OBJECT,hc);
	}
	return hc;
}
/**
 * Temporarily set the size of a Control to zero and relayout this container.
 * For every call to hide() there must be a matching call to unhide() OR a call
 * to setHidden() to override the hide()/unhide() behaviour. 
 * @param child the child to hide. 
 * @param update set true to relayout and repaint this control, false otherwise.
 * If you do not update the Control now you must do relayout(true) later to do an update.
 */
public synchronized void hide(Control child,boolean update)
{
	getHidden(child).hide(update);
}
/**
 * Make visible a Control hidden by hide().
 * For every call to hide() there must be a matching call to unhide() OR a call
 * to setHidden() to override the hide()/unhide() behaviour. 
 * @param child the child to hide. 
 * @param update set true to relayout and repaint this control, false otherwise.
 * If you do not update the Control now you must do relayout(true) later to do an update.
 */
public synchronized void unhide(Control child,boolean update)
{
	getHidden(child).unhide(update);
}
/**
 * Unconditionally set the hidden state of the child.
 * @param child the child to make hidden or unhidden.
 * @param isHidden true for it to be hidden, false for it to be unhidden.
 * @param update set true to relayout and repaint this control, false otherwise.
 * If you do not update the Control now you must do relayout(true) later to do an update.
 */
public synchronized void setHidden(Control child,boolean isHidden, boolean update)
{
	getHidden(child).setHidden(isHidden,update);
}
/**
* Force a recalculation of all preferredSize() and resizing/positioning of the panel.
* This method calls reShow() and then repaints it if redisplay is true.
 * @param redisplay set true to repaint the Container.
 */
public void relayout(boolean redisplay) 
//===================================================================
{
	reShow(x,y,width,height);
	if (redisplay) {
		repaintNow();
	}
}
/**
 * Resize the control and force all subcontrols to be considered to be reshown and
 * relaid out.
 * @param x the new or same x location.
 * @param y the new or same y location.
 * @param toWidth the new or same width.
 * @param toHeight the new or same height.
 */
//===================================================================
public void reShow(int x,int y,int toWidth,int toHeight)
//===================================================================
{
	modifyAll(ForceResize,CalculatedSizes,true);
	setRect(x,y,toWidth,toHeight);
}

/**
 * Removes a child control from the container. Normally you would not use this
 * but use a higher function provided by an inherited Control.
 */
public void remove(Control control)
{
	if (control.parent != this)
		return;
	// set children, next, prev, tail and parent
	Control prev = control.prev;
	Control next = control.next;
	if (prev == null)
		children = next;
	else
		prev.next = next;
	if (next != null)
		next.prev = prev;
	if (tail == control)
		tail = prev;
	control.next = null;
	control.prev = null;
	control.parent = null;
}


/** Returns the child located at the given x and y coordinates. */
public Control findChild(int x, int y)
{
	Container container;
	Control child;

	container = this;
	while (true){
		child = container.tail;
		while (child != null && !child.contains(x, y))
			child = child.prev;
		if (child == null) return container;
		if (!(child instanceof Container)) return child;
		x -= child.x;
		y -= child.y;
		container = (Container)child;
	}
}
/**
* This is used to "make" the control before being displayed. 
* @param reMake if this is true then you should do a full re-make.
*/
//===================================================================
public void make(boolean reMake)
//===================================================================
{
	
	for (Iterator it = getChildren(null,false); it.hasNext(); ){
		Control c = (Control)it.next();
		if (c != null) c.make(reMake);
	}
}

/** Called by the system to draw the children of the container. */
/*
public void _paintChildren(Graphics g, int x, int y, int width, int height)
	{
	Control child = children;
	while (child != null)
		{
		int x1 = x;
		int y1 = y;
		int x2 = x + width - 1;
		int y2 = y + height - 1;
		int cx1 = child.x;
		int cy1 = child.y;
		int cx2 = cx1 + child.width - 1;
		int cy2 = cy1 + child.height - 1;
		// trivial clip
		if (x2 < cx1 || x1 > cx2 || y2 < cy1 || y1 > cy2)
			{
			child = child.next;
			continue;
			}
		if (x1 < cx1)
			x1 = cx1;
		if (y1 < cy1)
			y1 = cy1;
		if (x2 > cx2)
			x2 = cx2;
		if (y2 > cy2)
			y2 = cy2;
		g.setClip(x1, y1, x2 - x1 + 1, y2 - y1 + 1);
		g.translate(cx1, cy1);
		child.onPaint(g);
		g.clearClip();
		if (child instanceof Container)
			{
			Container c = (Container)child;
			c.paintChildren(g, x1 - cx1, y1 - cy1, x2 - x1 + 1, y2 - y1 + 1);
			}
		g.translate(- cx1, - cy1);
		child = child.next;
		}
	}
	*/

public ControlIterator getChildren(ControlIterator it, boolean backwards)
{
	return ControlIterator.unNull(it).setFor(this,backwards);
}
//===================================================================
  public void repaintDataNow()
//===================================================================
{
  	Iterator it = getCachedChildren(false);
	for (;it.hasNext();)
		((Control)it.next()).repaintDataNow();
	Cache.put(it);
}

//MLB
//===================================================================
public void removeAll()
//===================================================================
{
	while(children != null) remove(children);
}

//===================================================================
public void dismantle(Control stopAt)
//===================================================================
{
	if (stopAt == this) return;
	Iterator it = getChildren((ControlIterator)Cache.get(ControlIterator.class),false);
	while(it.hasNext()){
		Control c = (Control)it.next();
		if (c instanceof Container)
			((Container)c).dismantle(stopAt);
	}
	Cache.put(it);
	removeAll();
}
//===================================================================
public final void dismantle()
//===================================================================
{
	dismantle(null);
}
//-------------------------------------------------------------------
protected boolean doHotKey(Control from,KeyEvent ev)
//-------------------------------------------------------------------
{
	if (super.doHotKey(from,ev)) return true;
	Iterator it = getCachedChildren(false);
	try{
		while(it.hasNext()) {
			Control c2 = (Control)it.next();
			if (c2 == from) continue;
			if (c2.doHotKey(this,ev)) return true;
		}
	}finally{
		Cache.put(it);
	}
	if (from == parent || this instanceof Frame || parent == null) return false;
	return parent.doHotKey(this,ev);
}

/**
If this is true then the keyboard focus cannot be moved to the Container's child controls
using the TAB or cursor keys. You should also call modifyAll(NoFocus,TakesKeyFocus,false)
on the Container after adding the sub-controls.
**/
public boolean dontFocusOnChildren = false;

/**
If this is true then the keyboard focus cannot be moved outside of this Container using
the TAB or cursor keys.
**/
public boolean closedFocus = false;
/**
If this is true then the keyboard focus will cycle from the first to the last control
in this container when the focus has moved to the very first or very last control.
**/
public boolean cycleFocus = false;
/**
* Determine which sub-control should receive the keyboard focus. This method is normally
* called when the user moves the focus off of one control using TAB or the cursor keys.
* A control which has no children should not look for sub controls.
* @param sourceChild the child control from which the call came from, or null if the call
* came from the parent of this control, or this control itself.
* @param forwards true if the user wants to go to the next control, false if the user wants
* to go to the previous one.
* @return the control (which may be this control) that should receive the focus, or null
* if none should.
*/
//===================================================================
public Control getNextKeyFocus(Control sourceChild,boolean forwards)
//===================================================================
{
	if (dontFocusOnChildren || ((modifiers & ShrinkToNothing) != 0)) return super.getNextKeyFocus(sourceChild,forwards);
	ControlIterator it = getChildren((ControlIterator)Cache.get(ControlIterator.class),!forwards);
	try{
		if (sourceChild == null){ // Request came from parent or myself, so find the first/last available control.
			while(it.hasNext()) {
				Control c2 = (Control)it.next();
				Control c =  c2.getNextKeyFocus(null,forwards);
				if (c != null) return c;
			}
			return null;
		}
		// It came from one of my children, so find the next control.
		while(it.hasNext()){
			Control c = (Control)it.next();
			if (c == sourceChild) {
				while(it.hasNext()){
					Control c2 = (Control)it.next();
					Control ch = c2.getNextKeyFocus(null,forwards);
					if (ch != null) return ch;
				}
			}
		}
		// Could not find another one inside me, so ask my parent.
		Control pc = ((parent == null) || closedFocus ? null : parent.getNextKeyFocus(this,forwards));
		if (pc != null) return pc;
		if (!cycleFocus) return null;
		return getNextKeyFocus(null,forwards);
	}finally{
		Cache.put(it);
	}
}

//-------------------------------------------------------------------
protected Control getFirstFocus()
//-------------------------------------------------------------------
{
	Iterator it = getChildren((ControlIterator)Cache.get(ControlIterator.class),false);
	try{
		while(it.hasNext()){
			Control c2 = (Control)it.next();
			Control c = (c2 instanceof Container) ? ((Container)c2).getFirstFocus() : c2.getNextKeyFocus(null,true);
			if (c != null) {
				return c;
			}
		}
	}finally{
		Cache.put(it);
	}
	return null;
}
/**
 * On a normal Control this will set the promptControl variable to "prompt", but
 * on a Container, the first child non-container will have "prompt" assigned to it.
 * @param prompt the Control acting as the prompt (usually an mLabel).
 */
protected boolean takePromptControl(Control prompt)
{
	Iterator it = getSubControls((ControlIterator)Cache.get(ControlIterator.class));
	try{
		while (it.hasNext()){
			Control c =(Control)it.next();
			if (c != null)
				if (c.takePromptControl(prompt)) return true;
		}
		return false;
	}finally{
		Cache.put(it);
	}
}
/**
 * Normally the child of a Container would get the focus if a call to Gui.takeFocus(aContainer,ByRequest)
 * is called. However if this is set true, then the next time takeFocus() sends
 * the focus to the container, the container itself will keep the focus. This
 * value is reset after the next takeFocus() back to false.
 */
public boolean takeNextFocus = false;

private boolean haveTheFocus = false;
/**
Returns true if the Container itself has the focus instead of one of its
children.
**/
//===================================================================
public boolean containerHasFocus()
//===================================================================
{
	return haveTheFocus;
}
/**
Put the focus on the container itself rather than any of its children.
@param how one of the Control.ByXXX values (e.g. ByRequest)
**/
//===================================================================
public void focusOnContainer(int how)
//===================================================================
{
	takeNextFocus = true;
	Gui.takeFocus(this,how);
}
/**
Put the focus on the data within the container. This calls focusFirst().
@param how one of the Control.ByXXX values (e.g. ByRequest)
**/
//===================================================================
public void focusOnData(int how)
//===================================================================
{
	focusFirst(how);
}
/**
If a container gets the focus via an explicit focusOnContainer() then it
will take the focus, otherwise it will call pass focus to the first 
control within it that wants the focus. If there are none then it will
take the focus itself.
**/
//===================================================================
public void gotFocus(int how)
//===================================================================
{
	if (takeNextFocus){
		haveTheFocus = true;
		takeNextFocus = false;
	}else{
	//if (how == ByPen) return;
		Control c = getFirstFocus();
		if (c != null) Gui.takeFocus(c,how);//focusFirst();
		else haveTheFocus = true;
	}
}
//===================================================================
public void lostFocus(int how)
//===================================================================
{
	haveTheFocus = false;
}
//===================================================================
public void focusFirst()
//===================================================================
{
	focusFirst(ByRequest);
}
//===================================================================
public void focusFirst(int how)
//===================================================================
{
	Control c = getFirstFocus();
	if (c == null) c = this;
	Gui.takeFocus(c,how);
	//Window w = getWindow();
	//if (w != null) w.setFocus(c);
}
//===================================================================
public void takeFocus(int how)
//===================================================================
{
	focusFirst(how);
}

//===================================================================
public boolean scrollToVisible(int x, int y, int width, int height)
//===================================================================
{
	if (parent != null){
		return parent.scrollToVisible(x+this.x,y+this.y, width, height);
	}else{
		return false;
	}
}

}

