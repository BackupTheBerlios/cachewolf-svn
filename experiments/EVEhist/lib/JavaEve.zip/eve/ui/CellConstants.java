package eve.ui;

//##################################################################
public interface CellConstants{
//##################################################################
//..................................................................
// Alignment and stretch positions. How an object is aligned in the cell.
//..................................................................
public static final int CELLFLAG = 0x10000000;
public static final int LEFT = 0x1, RIGHT = 0x2, TOP = 0x4, BOTTOM = 0x8;
public static final int HEXPAND = 0x10, HCONTRACT = 0x20, VEXPAND = 0x40, VCONTRACT = 0x80;
public static final int HGROW = 0x100, HSHRINK = 0x200, VGROW = 0x400, VSHRINK = 0x800;
public static final int CELLMASK = 0x1ff00, CONTROLMASK = 0xff;
public static final int DONTCHANGE = 0x1000;
public static final int INITIALLY_CLOSED = 0x2000;
public static final int INITIALLY_MINIMIZED = 0x4000;
public static final int INITIALLY_PREFERRED_SIZE = 0x8000;
public static final int ALWAYS_STRETCHABLE = 0x10000;
public static final int INITIALLY_HIDDEN = 0x20000;
//..................................................................
public static final int 
	HSTRETCH = HGROW|HSHRINK, VSTRETCH = VGROW|VSHRINK, GROW = HGROW|VGROW, SHRINK = VSHRINK|HSHRINK, STRETCH = HSTRETCH|VSTRETCH;
public static final int 
	HFILL = HEXPAND|HCONTRACT, VFILL = VEXPAND|VCONTRACT, FILL = HFILL|VFILL;
public static final int DONTSTRETCH = CELLFLAG;
public static final int DONTFILL = CELLFLAG;
public static final int HCENTER = CELLFLAG,VCENTER = CELLFLAG, CENTER = CELLFLAG;
//..................................................................
public static final int NORTH = TOP;
public static final int NORTHWEST = TOP|LEFT;
public static final int NORTHEAST = TOP|RIGHT;
public static final int SOUTH = BOTTOM;
public static final int SOUTHWEST = BOTTOM|LEFT;
public static final int SOUTHEAST = BOTTOM|RIGHT;
public static final int WEST = LEFT;
public static final int EAST = RIGHT;
//......................................................
// Used in the set(int,Object) method of Constraint
//......................................................
/** A Tag type for use in Control.setTag() - use a eve.fx.Insets object as the "value" object. **/
/** @deprecated use TAG_INSETS instead.*/
public static final int INSETS = 4;
/** A Tag type for use in Control.setTag() - use a eve.fx.Dimension object as the "value" object. **/
public static final int TAG_PREFERREDSIZE = 1;
/** A Tag type for use in Control.setTag() - use a eve.fx.Dimension object as the "value" object. **/
public static final int TAG_MINIMUMSIZE = 2;
/** A Tag type for use in Control.setTag() - use a eve.fx.Dimension object as the "value" object. **/
public static final int TAG_MAXIMUMSIZE = 3;
/** A Tag type for use in Control.setTag() - use a eve.fx.Insets object as the "value" object. **/
public static final int TAG_INSETS = 4;
/** A Tag type for use in Control.setTag() - use a eve.fx.Dimension object as the "value" object. **/
public static final int TAG_SPAN = 6;
/** A Tag type for use in Control.setTag() - use a eve.fx.Dimension object as the "value" object. **/
public static final int TAG_FIXEDSIZE = 7;
/** A Tag type for use in Control.setTag() - use a eve.fx.Dimension object as the "value" object. **/
public static final int TAG_TEXTSIZE = 8;
/** A Tag type for use in Control.setTag(), used to set the absolute location of a Control
within a Panel - use a eve.fx.Rect object as the "value" object. **/
public static final int TAG_RECT = 9;
public static final int TAG_EXPOSE_GROUP = 10;
/** A Tag type for use in Control.setTag(), used to set a background image - use a eve.fx.BackgroundImage object as the "value" object. **/
public static final int TAG_BACKGROUND_IMAGE = 11;
/** A Tag type for use in Control.setTag(), 
 * used to specify which parent Container for the Control is used to hide() or
 * unhide() the Control. By default, the Frame of the Control is used.**/
public static final int TAG_HIDE_PARENT = 12;

static final int TAG_HIDE_CONTROL_OBJECT = 13;

/** @deprecated use TAG_PREFERREDSIZE instead**/
public static final int PREFERREDSIZE = 1;
/** @deprecated use TAG_MINIMUMSIZE instead**/
public static final int  MINIMUMSIZE = 2;
/** @deprecated use TAG_MAXIMUMSIZE instead**/
public static final int MAXIMUMSIZE = 3;
/** @deprecated **/
//public static final int BORDER = 5;
/** @deprecated use TAG_BORDER instead**/
public static final int SPAN = 6;
/** @deprecated use TAG_SPAN instead**/
//public static final int FIXEDSIZE = 7;
/** @deprecated use TAG_TEXTSIZE instead**/
public static final int TEXTSIZE = 8;
/** @deprecated use TAG_RECT instead**/
public static final int RECT = 9;
/** @deprecated use TAG_EXPOSE_GROUP instead**/
//public static final int EXPOSE_GROUP = 10;

//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 
//public static final int 

//##################################################################
}
//##################################################################

