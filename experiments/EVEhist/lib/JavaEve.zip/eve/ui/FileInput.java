package eve.ui;
import eve.data.PropertyList;
import eve.fx.IImage;
import eve.io.File;
import eve.io.FileChooserParameters;
import eve.sys.Reflection;
import eve.sys.Vm;
import eve.ui.Button;
import eve.ui.ButtonControl;
import eve.ui.Control;
import eve.ui.Form;
import eve.ui.Gui;
import eve.ui.Input;
import eve.ui.event.DataChangeEvent;
import eve.util.mString;

//##################################################################
public class FileInput extends Form{
//##################################################################

{
	modify(TakeControlEvents,0);
}
/**
 * This is the input used to display/input a file name.
 * Modify this to DisplayOnly to force the user to select the file via
 * the file select button.<p> 
 * You can modify this or set this to null entirely to not display
 * any input at all.
 */
public Control input = new Input();
/**
 * This is the button used to select a file/directory.
 */
public ButtonControl select = new Button("Select");
{
	if (select instanceof Button)((Button)select).action = "select";
}
public boolean alwaysUseSimpleFileChooser = false;
/**
* This is sent to the persistentHistoryKey of the created FileChooser.
**/
//public String persistentHistoryKey;

public String file = "";

/**
 * If this is not null then the FileChooser will always start from this
 * directory instead of from the parent of the currently chosen file.
 */
public String initialDirectory;

//public String extraDirectory = "";

//public File fileModel = Vm.newFileObject();

public void setText(String text)
{
	file = text; 
	if (input != null) 
		input.setText(file = text);
}

public String getText() 
{
	if (input != null) return input.getText();
	return file;
}

/**
 * You can explicitly set this to be a FileChooser. It must implement the constructor
 * with a single parameter of type FileChooser or have a default constructor.
 */
public Class fileChooserClass;

/**
 * This contains parameters for the created FileChooser.
 */
public FileChooserParameters fileChooserParameters = new FileChooserParameters();

//public mVector masks = new mVector();
public int frameOption = Gui.FILL_FRAME;
//public String defaultExtension = null;
public IImage chooseImage = loadImage("eve/ChooseFile.png");

/**
 * Get the File used as a model for the file chooser. This value should be set
 * in the fileChooserParameters value as a File object using: 
 * fileChooserParameters.set(FileChooserParameters.FILE_MODEL,fileModel);
 * @return the File used as a model for the file chooser.
 */
public File getFileModel()
{
	File f = (File)fileChooserParameters.getValue(FileChooserParameters.FILE_MODEL,null);
	if (f == null) f = Vm.newFileObject();
	return f;
}

//===================================================================
public FileInput setTitleAndTip(String title)
//===================================================================
{
	select.setToolTip(this.title = title);
	return this;
}
//===================================================================
public FileInput() {this(null,20);}
//===================================================================
public FileInput(String mask,int length)
//===================================================================
{
	FileChooserParameters fcp = fileChooserParameters;
	fcp.set(fcp.TYPE,fcp.TYPE_OPEN);
	if (input != null) input.columns = length;
	select.modify(MouseSensitive,0);
	Gui.iconize(select,chooseImage,false,null);
	if (mask != null) fcp.set(fcp.FILE_MASK,mask);
}
/**
This constructor is used by UIBuilder.
**/
//===================================================================
public FileInput(PropertyList fieldProperties)
//===================================================================
{
	FileInput mf = this;
	PropertyList pl = fieldProperties;
	//mf.fileChooserOptions = pl.getInt("fileChooserOptions",mf.fileChooserOptions);
	//mf.title = pl.getString("title","Select File...");
	fileChooserParameters.set(FileChooserParameters.TITLE,pl.getString("title","Select File..."));
	String de = pl.getString("defaultExtension",null);
	if (de != null) fileChooserParameters.set(fileChooserParameters.DEFAULT_EXTENSION,de);
	String masks = pl.getString("masks","");
	String allMasks[] = mString.split(masks,';');
	for (int i = 0; i<allMasks.length; i++)
		fileChooserParameters.add(FileChooserParameters.FILE_MASK,allMasks[i]);
}
//===================================================================
public void setData(Object data)
//===================================================================
{
	if (data instanceof File){
		File f = (File)data;
		fileChooserParameters.set(FileChooserParameters.FILE_MODEL,f.getNew("/"));
		setText(f.getFullPath());
	}
}
//===================================================================
public void getData(Object data)
//===================================================================
{
	if (data instanceof File){
		File f = (File)data;
		f.set(null,file);
	}
}
//===================================================================
public void make(boolean remake)
//===================================================================
{
	if (!made){
		if (input != null) addNext(input);
		//addField(,"file");
		if (select != null){
			addNext(select).setCell(VSTRETCH);
			//addField(,"sel");
			select.modify(NoFocus,0);
		}
	}
	super.make(remake);
}
//===================================================================
public void onDataChangeEvent(DataChangeEvent ev)
//===================================================================
{
	super.onDataChangeEvent(ev);
	if (ev.target == input) {
		file = input.getText();
		//notifyDataChange(); Don't need this since I take control events.
	}
}
/**
* This is called to create a new FileChooser when the select button is pressed. Override it
* if necessary to provide a new type of FileChooser (e.g. an ImageFileChooser).
**/
//-------------------------------------------------------------------
protected Form createFileChooser()
//-------------------------------------------------------------------
{
	FileChooserParameters fcp = fileChooserParameters;
	if (fcp.get(fcp.FILE_MODEL) == null) fcp.set(fcp.FILE_MODEL,Vm.newFileObject());
	fcp.defaultTo(fcp.TYPE,fcp.TYPE_OPEN);
	fcp.defaultTo(fcp.TITLE,"Select file...");
	String type = (String)fcp.getValue(fcp.TYPE, null);
	if (initialDirectory != null) fcp.set(fcp.START_LOCATION,initialDirectory);
	else if (file != null){
		File f = getFile();
		if (!type.equals(fcp.TYPE_DIRECTORY_SELECT))
			f = f.getParentFile();
		if (f != null) fcp.set(fcp.START_LOCATION,f.toString());
	}
	if (fileChooserClass != null){
		Form f = (Form)Reflection.newInstance(fileChooserClass,"Leve/io/FileChooserParameters;",new Object[]{fcp});
		if (f != null) return f;
		f = (Form)Reflection.newInstance(fileChooserClass);
		if (f != null) return f;
	}
	if (alwaysUseSimpleFileChooser) return new SimpleFileChooser(fcp);
	return Gui.getBestFileChooser(fileChooserParameters,(File)fcp.getValue(fcp.FILE_MODEL,null));
}
/**
* If you override this, first call super.setupFileChooser(fc) and then continue
* with your further modifications.
**/
//-------------------------------------------------------------------
protected void setupFileChooser(Form fc)
//-------------------------------------------------------------------
{
	/*
	fc.defaultExtension = defaultExtension;
	fc.title = title;
	for (int i = 0; i<masks.size(); i++){
		if (i == 0) fc.mask = masks.get(i).toString();
		fc.addMask(masks.get(i).toString());
	}
	fc.persistentHistoryKey = persistentHistoryKey;
	*/
}
/**
 * This gets called when the FileChooser box accepts a new file name - unlike
 * setText() this will generate a DataChangedEvent.
 * @param fileName the new file selected.
 */
public void newFileSelected(String fileName)
{
	setText(fileName);
	if (input != null) input.updateData();
	notifyDataChange();
}
/**
 * This is called when the Select File button is pressed.
 *
 */
public void selectNow()
{
	if ((getModifiers(true) & (NotEditable|DisplayOnly)) != 0) return;
	/*
	String ed = extraDirectory == null ? "" : extraDirectory;
	if (ed.length() > 1) ed = mString.removeTrailingSlash(extraDirectory);
	if (ed.length() != 0) {
		File ff = fileModel.getNew(ed);
		if (ff != null) ff = ff.getChild(file);
		if (ff != null) ed = ff.getFullPath();
	}else 
		ed = file;
		*/
	Form.showWait();
	Form fc = createFileChooser();//fileChooserOptions,ed,fileModel);
	setupFileChooser(fc);
	int got = fc.execute(null,frameOption);
	try{
		if (got == IDCANCEL) return;
		File cff = (File)fileChooserParameters.getValue(FileChooserParameters.CHOSEN_FILE,null);
		String cf = cff == null ? "" : cff.toString(); 
		if (!cf.equals(file)) newFileSelected(cf);
	}finally{
		fc.dismantle();
		fc = null;
	}
}
public boolean handleAction(String action)
{
	if (action.equals("select")){
		selectNow();
		return true;
	}
	return false;
}

/**
* This returns a File as specified by the file name and of the same type as the file model.
**/
//===================================================================
public File getFile()
//===================================================================
{
	return getFileModel().getNew(file);
}

public static void main(String[] args)
{
	Application.startApplication(args);
	Form f = new Form();
	f.title = "Test File Input";
	f.addNext(new Label("Select a file")).setCell(Form.DONTSTRETCH);
	f.addLast(new FileInput()).setCell(Form.STRETCH);
	f.execute();
	System.exit(0);
}

//##################################################################
}
//##################################################################

