/*
 * Created on Jul 2, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.ui;

import java.util.Vector;

import eve.fx.Font;
import eve.fx.FontMetrics;
import eve.fx.IImage;
import eve.fx.IconAndText;
import eve.fx.Insets;
import eve.sys.Locale;
import eve.sys.Vm;
import eve.util.Utils;
import eve.util.mVector;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class FontSelector extends Holder {
	/**
	* If this is set true, then the text in the drop-down menu for Fonts will
	* be in the same Font instead of being rendered in their own face.
	**/
	public static boolean dontShowDifferentFonts = true;

	public static String [] fonts;
	protected static Vector fontItems;
	public int size = 14;
	public boolean bold = false;
	public boolean italic = false;
	public boolean underline = false;
	private int myOptions = 0;
	public static final int OPTION_NO_NAME = FontUpDownChooser.OPTION_NO_NAME;
	public static final int OPTION_NO_SIZE = FontUpDownChooser.OPTION_NO_SIZE;
	public static final int OPTION_NO_STYLE = FontUpDownChooser.OPTION_NO_STYLE;
	public static final int OPTION_NO_SAMPLE =FontUpDownChooser.OPTION_NO_SAMPLE;
	//public static final int OPTION_NO_SAMPLE =FontUpDownChooser.OPTION_NO_SAMPLE;
	
	boolean chooseStyle = false;
	boolean chooseSize = true;
	boolean chooseName = true;
	
	public String fontName = "Helvetica";
	public int fontSize = 14;
	public int fontStyle = Font.PLAIN;
	
	public FontSelector(int options)
	{
		myOptions = options;
		chooseStyle = (options & OPTION_NO_STYLE) == 0;
		chooseSize = (options & OPTION_NO_SIZE) == 0;
		chooseName = (options & OPTION_NO_NAME) == 0;
	}
	public Font toFont()
	{
		return new Font(fontName,fontStyle,fontSize);
	}
	
	private FontInput fontInput;
	
	public void fromFont(Font f)
	{
		fontName = f.getName();
		fontStyle = f.getStyle();
		fontSize = f.getSize();
		update();
	}
	private void update()
	{
		if (fontInput != null) fontInput.fromFont(toFont());
	}
//	===================================================================
	public void make(boolean reMake)
//	===================================================================
	{

		try{
			Form f = new Form();
			addLast(f);
			FieldHandler fh = new FieldHandler(this){
				protected void fieldChanged(Control c, Form f){
					if (c.fieldTransfer.fieldName.equals("fontInput")){
						fromFont(((FontInput)c).toFont());
						//notifyDataChange(); <- Don't need to do this.
					}else{
						fontStyle = 0;
						if (bold) fontStyle |= Font.BOLD;
						if (italic) fontStyle |= Font.ITALIC;
						if (underline) fontStyle |= Font.UNDERLINE;
					}
				}
			};
			f.addFieldHandler(fh);
			if (Gui.isSmartPhone){
				FontInput fi = fontInput = new FontInput(myOptions);
				fi.fromFont(toFont());
				f.addLast(fh.add("fontInput",fi));
				return;
			}
			//
			// Not smartphone.
			//
			if (fonts == null){
				fonts = Font.listFonts(Application.mainApp.getSurface());
				Utils.sort(fonts,Vm.getLocale().getStringComparer(Locale.IGNORE_CASE),false);
				fontItems = new mVector(fonts);
				if (!dontShowDifferentFonts){
					fontItems.clear();
					Font gf = Application.guiFont;
					int size = gf.getSize();
					for (int i = 0; i<fonts.length; i++){
						Font ff = new Font(fonts[i],Font.PLAIN,size);
						FontMetrics fm = Application.mainApp.getFontMetrics(ff);
						IImage ln = new IconAndText((IImage)null,fonts[i],fm);//fonts[i],fm);
						fontItems.add(new MenuItem(fonts[i],ln));
					}
				}
			}
			ComboBox mcb = new ComboBox();
			mcb.input.columns = 20;
			mcb.input.prompt = "Font Name";
			mcb.choice.items = fontItems;//new ewe.util.Vector(fonts);
			mcb.choice.menuOptions |= Choice.MENU_FULL_WIDTH;
			CellPanel cp = new CellPanel();
			cp.addNext(fh.add("fontName",mcb)).setCell(cp.HSTRETCH);
			if (chooseSize){
				mcb = new ComboBox(new String[]{"8","10","11","12","14","16","20"},0);
				mcb.input.columns = 3;
				mcb.input.prompt = "Font Size";
				cp.addNext(fh.add("fontSize",mcb)).setCell(cp.DONTSTRETCH);
			}
			if (chooseStyle){
				CellPanel style = new CellPanel(); style.equalWidths = true;
				style.addNext(fh.add("bold",new ButtonCheckBox("B")));
				style.addNext(fh.add("italic",new ButtonCheckBox("I")));
				style.addNext(fh.add("underline",new ButtonCheckBox("U")));
				cp.addNext(style).setCell(cp.DONTSTRETCH).setTag(cp.TAG_INSETS,new Insets(0,4,0,0));
				style.modifyAll(style.NoFocus,0);
			}
			f.addLast(cp);
			/*
			if (chooseSize){
				CellPanel sz = new CellPanel(); sz.equalWidths = true;
				ed.addField(sz.addNext(new Button("+")),"increase");
				ed.addField(sz.addNext(new Button("-")),"decrease");
				cp.addNext(sz).setCell(cp.DONTSTRETCH).setTag(cp.INSETS,new Insets(0,4,0,0));
				sz.modifyAll(ed.NoFocus,0);
			}
			*/
			
		}finally{
			update();
			super.make(reMake);
		}
/*
			//
	}
	*/
	}
}
//####################################################
