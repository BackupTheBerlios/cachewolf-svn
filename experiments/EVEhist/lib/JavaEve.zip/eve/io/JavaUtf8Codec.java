package eve.io;
import java.io.IOException;
import java.io.UTFDataFormatException;
import eve.util.*;
/**
 * This Codec is used to translate between 16-bit Unicode Characters (Java "char" data)
 * and 8-bit bytes using the Java Modified UTF-8 method, with the restriction that unicode
 * characters will only be in the range 0x0000 and 0xffff.
 * <p>
 * This is different to Standard UTF-8 in that in Standard UTF-8 the null character 0x0000 is converted to a
 * zero byte value, where as in Java UTF-8 the zero byte value is converted into the 
 * two byte sequence 0xC0 0x80.
 * <p>
 * @author Michael L Brereton
 *
 */

//##################################################################
public class JavaUtf8Codec extends TextCodecObject{
//##################################################################

static final int USE_STANDARD_UTF8 = 0x4;

/**
 * Usually a modified Java UTF8 codec can decode data created from a standard UTF8 codec
 * and vice versa, but if the STRICT option is used then any deviation from the exact
 * method will generate an error.
 */
// TODO - implement JavaUtf8Codec STRICT option in Java and C++ 
//public static final int STRICT = _STRICT;
/**
* This is a creation option. It specifies that CR characters should be removed when
* encoding text into UTF.
**/
public static final int STRIP_CR_ON_DECODE = _STRIP_CR_ON_DECODE;
/**
* This is a creation option. It specifies that CR characters should be removed when
* decoding text from UTF.
**/
public static final int STRIP_CR_ON_ENCODE = _STRIP_CR_ON_ENCODE;
/**
* This is a creation option. It specifies that CR characters should be removed when
* decoding text from UTF AND encoding text to UTF.
**/
public static final int STRIP_CR = STRIP_CR_ON_DECODE|STRIP_CR_ON_ENCODE;

//===================================================================
public JavaUtf8Codec(int options)
//===================================================================
{
	flags = options;
}
//===================================================================
public JavaUtf8Codec()
//===================================================================
{
	this(0);
}
//===================================================================
public ByteArray encodeText(char [] text, int start, int length, boolean endOfData, ByteArray dest) throws IOException
//===================================================================
{
	if (dest == null) dest = new ByteArray();
	if (hasNative) try{
		encodeDecode(_UTF8_CODEC,true,text,start,length,endOfData,dest,flags);
		return dest;
	}catch(SecurityException e){
		hasNative = false;
	}catch(UnsatisfiedLinkError e2){
		hasNative = false;
	}
	//
	int size = length == 0 ? 0 : Utils.sizeofJavaUtf8String(text,start,length);
	if (dest.data == null || dest.data.length < size+dest.length){
		byte[] old = dest.data;
		dest.data = new byte[size+dest.length];
		if (dest.length != 0) System.arraycopy(old,0,dest.data,0,dest.length);
	}
	byte [] destination = dest.data;
	int s = dest.length;
	for (int i = 0; i<length; i++){
		char c = text[i+start];
		if (c == 13 && ((flags & STRIP_CR_ON_DECODE) != 0)) continue;
		if (c == 0 && (flags & USE_STANDARD_UTF8) != 0)
			destination[s++] = (byte)c;
		else if (c >= 0x1 && c <= 0x7f) destination[s++] = (byte)c;
		else if (c == 0 || (c >= 0x80 && c <= 0x7ff)) {
			//eve.sys.Vm.debug(">"+(int)c);
			destination[s++] = (byte)(0xc0 | ((c >> 6) & 0x1f));
			destination[s++] = (byte) (0x80 | (c & 0x3f));
		}else{
			destination[s++] = (byte)(0xe0 | ((c >> 12) & 0xf));
			destination[s++] = (byte) (0x80 | ((c >> 6) & 0x3f));
			destination[s++] = (byte) (0x80 | (c  & 0x3f));
		}
	}
	//Utils.encodeJavaUtf8String(text,start,length,dest.data,0);
	dest.length = s;
	return dest;
}

//-------------------------------------------------------------------
private IOException badFormat()
//-------------------------------------------------------------------
{
	return new UTFDataFormatException("Bad format");
}

/**
* If dest is null, this will return the number of output chars that will be produced. If
* dest is not null this will return the number of unprocessed bytes at the end (either 0, 1 
* or 2).
**/
//-------------------------------------------------------------------
private int decodeUtf(byte[] encoded, int start, int length, char[] dest, int destOffset)
//-------------------------------------------------------------------
{
	if (dest == null) destOffset = 0;
	int i = 0, t = destOffset;
	char ch;
	for (i = 0; i<length; i++){
		byte c = encoded[i+start];
		if ((c & 0x80) == 0){ 
			ch = (char)c;
			if (ch == 13 && ((flags & STRIP_CR_ON_DECODE) != 0)) t--;
			else if (dest != null) dest[t] = ch;
		}else if ((c & 0xe0) == 0xc0) {
			if (i == length-1){ // No more bytes.
				if (dest == null) return t-destOffset;
				else return 1;
			}
			ch = (char)((((char)c & 0x1f)<<6) + ((char)encoded[i+start+1] & 0x3f));
			if (ch == 13 && ((flags & STRIP_CR_ON_DECODE) != 0)) t--;
			else if (dest != null) dest[t] = ch;
			i++;
		}else if ((c & 0xf0) == 0xe0) {
			if (i > length-3){//Not enough bytes, need two more.
				if (dest == null) return t-destOffset;
				else return length-i;
			}
			ch = (char)((((char)c & 0x0f)<<12) + (((char)encoded[i+start+1] & 0x3f)<<6)+((char)encoded[i+start+2] & 0x3f));
			if (ch == 13 && ((flags & STRIP_CR_ON_DECODE) != 0)) t--;
			else if (dest != null) dest[t] = ch;
			i += 2;
		}
		t++;
		//eve.sys.Vm.debug("<"+(int)buffer[t]);
	}
	if (dest == null) return t-destOffset;
	else return 0;
}
//===================================================================
public CharArray decodeText(byte [] encoded, int start, int length, boolean endOfData, CharArray dest) throws IOException
//===================================================================
{
	int toPut = -1;
	if (dest == null) dest = new CharArray();
	if (hasNative) try{
		encodeDecode(_UTF8_CODEC,false,encoded,start,length,endOfData,dest,flags);
		return dest;
	}catch(SecurityException e){
		hasNative = false;
	}catch(UnsatisfiedLinkError e2){
		hasNative = false;
	}
//	dest.length = 0;
	//
	// First check if there are any bytes left over from the last run.
	//
	if (byteOne != -1){
		if ((byteOne & 0xe0) == 0xc0){ //Need one more byte.
			if (length < 1) {//No bytes available in the array.
				if (endOfData) throw badFormat();
				else return dest;
			}else{//Yes, at least one byte available in the array.
				char got = (char)((((char)byteOne & 0x1f)<<6) + ((char)encoded[start] & 0x3f));
				toPut = (int)got & 0xffff;
				start++; length--;
				byteOne = byteTwo = -1;
			}
		//
		//Must need two more bytes.
		//
		}else{ 
			if (byteTwo == -1){
				if (length < 1){//No bytes available in the array.
					if (endOfData) throw badFormat();
					else return dest;
				}else{//Yes, at least one byte available in the array.
					byteTwo = (int)encoded[start] & 0xff;
					start++; length--;
				}
			}
			//At this point byteTwo WILL be valid.
			if (length < 1){//No bytes available in the array.
				if (endOfData) throw badFormat();
				else return dest;
			}else{//Yes, at least one byte available in the array.
				char got = (char)((((char)byteOne & 0x0f)<<12) + (((char)byteTwo & 0x3f)<<6)+((char)encoded[start] & 0x3f));
				toPut = (int)got & 0xffff;
				start++; length--;
				byteOne = byteTwo = -1;
			}
		}
	}
	//
	int need = decodeUtf(encoded,start,length,null,0);
	if (toPut == 13 && ((flags & STRIP_CR_ON_DECODE) != 0)) toPut = -1;
	if (toPut != -1) need++;
	//
	if (dest.data == null || dest.data.length < need+dest.length){
		char[] old = dest.data;
		dest.data = new char[need+dest.length];
		if (dest.length != 0) System.arraycopy(old,0,dest.data,0,dest.length);
	}
	//
	if (toPut != -1) dest.data[dest.length] = (char)toPut;
	int left = decodeUtf(encoded,start,length,dest.data,dest.length+((toPut != -1) ? 1 : 0));
	dest.length += need;
	byteOne = byteTwo = -1;
	//eve.sys.Vm.debug("Left: "+left);
	if (left > 0) byteOne = (int)encoded[start+length-1] & 0xff;
	if (left > 1) {
		byteTwo = byteOne;
		byteOne = (int)encoded[start+length-2] & 0xff;
	}
	if (left != 0 && endOfData) throw badFormat();
	return dest;
}
//===================================================================
public void closeCodec() throws IOException
//===================================================================
{
	byteOne = byteTwo = -1;
}
/*
//===================================================================
static void outputData(CharArray ca)
//===================================================================
{
	String out = "";
	for (int i = 0; i<ca.length; i++)
		out += eve.sys.Long.l1.set(ca.data[i]).toString(4,eve.sys.Long.HEX|eve.sys.Long.ZERO_FILL)+" ";
	if (ca.length != 0) eve.sys.Vm.debug("Got: "+out);
	else eve.sys.Vm.debug("Got: Nothing");
}
//===================================================================
public static void main(String args[]) throws IOException
//===================================================================
{
	eve.sys.Vm.startEwe(args);
	char [] source = new char[]{0x12,0x123,0x11,0xf123,0x21};
	JavaUtf8Codec jc = new JavaUtf8Codec();
	ByteArray ba = jc.encodeText(source,0,source.length,true,null);
	eve.sys.Vm.debug("Size: "+ba.length);
	CharArray ca = null;
	int end = ba.length;
	int step = 2;
	for (int i = 0; i<end; i += step){
		int num = end-i;
		if (num > step) num = step;
		outputData(ca = jc.decodeText(ba.data,i,num,false,ca));
	}
	outputData(ca = jc.decodeText(null,0,0,true,ca));
	eve.sys.Vm.exit(0);
}
*/
//===================================================================
public Object getCopy()
//===================================================================
{
	return new JavaUtf8Codec(flags);
}
//##################################################################
}
//##################################################################

