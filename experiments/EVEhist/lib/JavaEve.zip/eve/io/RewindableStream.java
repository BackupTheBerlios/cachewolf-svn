package eve.io;

import java.io.IOException;
import java.io.InputStream;

/**
* A RewindableStream adapts an InputStream so that a particular section of
* the stream (i.e. a set number of bytes, starting from the first byte) can
* be accessed randomly, while the remaining bytes can only be accessed
* sequentially.<p>
* 
* Such a Stream can be used when you need to decode data from an Input stream,
* but some pre-processing of some number of starting bytes is needed - for example
* in image decoding.<p>
* 
* As data is read from the stream it is copied into a buffer as well as being
* returned for consumption. A rewind() operation then causes the stream to seek to
* the start of the stream, and you can subsequently seek() up to that point.<p>
* 
* You would not create a RewindableStream directly - you would instead use
* the toRewindableStream() method instead to return a Stream that acts as a
* RandomStream.<p>
* 
* You should not use a RewindableStream as a general purpose RandomStream
* due to the fact it can only seek within
* the rewind buffer.
**/

//##################################################################
public class RewindableStream extends RandomStream{
//##################################################################

long curPos;
boolean rewound;
int inBuffer;
byte [] saved = new byte[0];

InputStream stream;
RandomStream ras;

/**
 * Return a Stream that can act as at least a limited RandomStream by being
 * able to rewind after reading a number of bytes. If the provided stream is
 * a true RandomStream then it will be returned - otherwise a RewindableStream
 * will be created and returned.
 * @param stream the InputStream to be made rewindable.
 * @return a Stream that can be rewinded.
 */
//===================================================================
public static RandomStream toRewindableStream(InputStream stream)
//===================================================================
{
	if (!(stream instanceof RewindableStream) && (stream instanceof RandomStream)) return (RandomStream)stream;
	else return new RewindableStream(stream);
}
/**
 * Rewind a Stream created by toRewindableStream(). From that point you will
 * be reading from the start of the stream again.
 * @param stream the RandomStream returned by toRewindableStream().
 * @throws IOException if an IO error occurs. 
 */
//===================================================================
public static void rewind(RandomStream stream) throws IOException
//===================================================================
{
	if (stream instanceof RewindableStream) ((RewindableStream)stream).rewind();
	else stream.setPosition(0);
}
//===================================================================
public boolean isOpenForWriting()
//===================================================================
{
	return false;
}
//===================================================================
private RewindableStream(InputStream stream)
//===================================================================
{
	super("r");
	this.stream = stream;
	if (!(stream instanceof RewindableStream) && (stream instanceof RandomStream)) 
		ras = (RandomStream)stream;
}
public void close() throws IOException
{
	stream.close();
}

private byte[] buff = new byte[1];

public synchronized int read() throws IOException
{
	int r = read(buff,0,1);
	if (r <= 0) return r;
	return ((int)buff[0]) & 0xff;
}

public synchronized int read(byte[] buffer, int start, int length) throws IOException
{
	if (ras != null) return ras.read(buffer,start,length);
	if (rewound){
		if (curPos >= inBuffer){
			//System.out.println("Reading directly: "+length);
			int readIn = stream.read(buffer,start,length);
			if (readIn <= 0) return readIn;
			curPos += readIn;
			return readIn;
		}
	}
	if (curPos < inBuffer){
		int buffered = (int)(inBuffer-curPos);
		if (buffered < length) length = buffered;
		System.arraycopy(saved,(int)curPos,buffer,start,length);
		curPos += length;
		//System.out.println("Reading from buffer: "+length);
		return length;
	}
	int readIn = stream.read(buffer,start,length);
	//System.out.println("Reading and saving: "+length);
	if (readIn <= 0) return readIn;
	if (!rewound){
		if (curPos+readIn > (long)saved.length){
			int extra = (int)(curPos+readIn-saved.length);
			if (extra < 1024) extra = 1024;
			byte [] nb = new byte[saved.length+extra];
			System.arraycopy(saved,0,nb,0,inBuffer);
			saved = nb;
		}
		System.arraycopy(buffer,start,saved,inBuffer,readIn);
		inBuffer += readIn;
	}
	curPos += readIn;
	return readIn;
}

//-------------------------------------------------------------------
private void throwAccessError() throws IOException
//-------------------------------------------------------------------
{
	throw new IOException("Access out of rewind range.");	
}

public long skip(long num) throws IOException
{
	return read(new byte[(int)num]);
}
//===================================================================
public void setPosition(long pos) throws IOException
//===================================================================
{
	if (ras != null) {
		ras.setPosition(pos);
		return;
	}
	//
	//if (pos < curPos && rewound){}
	//
	if (pos == curPos) return;
	else if (pos < curPos){
		if (curPos > inBuffer) throwAccessError();
		curPos = pos;
	}else{
		skip(pos-curPos);
		curPos = pos;
	}
}
/**
 * Retrieve the file position. This is non-blocking
 * @return the position of the stream or -1 if the position is not known yet.
 * @exception IOException if an error occured while getting the position.
 */
//===================================================================
public long getPosition() throws IOException
//===================================================================
{
	//ewe.sys.Vm.debug("tell()");
	if (ras != null) return ras.getPosition();
	return curPos;
}


//===================================================================
private void rewind() throws IOException
//===================================================================
{
	rewound = true;
	//System.out.println("rewind @ "+curPos+" "+hashCode());
	setPosition(0);	
}
public void write(int b) throws IOException
{
	throwCantWrite();
}
public void write(byte[] buff,int start,int length) throws IOException
{
	throwCantWrite();
}

//##################################################################
}
//##################################################################

