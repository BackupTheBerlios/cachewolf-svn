package eve.io;
import eve.data.HasProperties;
import eve.data.MutableTreeNodeObject;
import eve.data.Named;
import eve.data.PropertyList;
import eve.sys.Convert;
import eve.sys.LocalResource;

//##################################################################
public class TreeConfigNode extends MutableTreeNodeObject implements Named, HasProperties, LocalResource{
//##################################################################
public String name = "/";
public PropertyList properties = new PropertyList();
public PropertyList getProperties(){return properties;}

public String _fields = "name,properties";
//===================================================================
public String getName() {return name;}
/**
 * By default this does a direct comparison between name and getName(). 
 * @see eve.data.Named#isNamed(java.lang.String)
 */
public boolean isNamed(String name)
{
	String me = getName();
	if (me == null) return name == null;
	else return me.equals(name);
}
//===================================================================
public TreeConfigNode(){}
//===================================================================

public TreeConfigNode(String name)
//===================================================================
{
	this.name = name;
}
//===================================================================
public String toString()
//===================================================================
{
	return name+", "+properties;
}
//===================================================================
public Object get(int value,Object defaultValue)
//===================================================================
{
	return get(Convert.toString(value),defaultValue);
}
//===================================================================
public Object get(String value,Object defaultValue)
//===================================================================
{
	return properties.getValue(value,defaultValue);
}
//##################################################################
}
//##################################################################

