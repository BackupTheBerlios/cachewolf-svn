package eve.io;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

import eve.io.AsciiCodec;
import eve.io.Io;
import eve.io.TextCodec;
import eve.util.CharArray;
/**
 * This class reads characters from a byte input stream.   The characters
 * read are converted from bytes in the underlying stream by a 
 * decoding layer that you specify.  The decoding layer transforms bytes to chars according
 * to an encoding standard.  
 * It is recommended that applications do not use 
 * <code>EncodedStreamReader</code>'s
 * directly.  Rather, for efficiency purposes, an object of this class
 * should be wrapped by a <code>BufferedReader</code>.
 * <p>
 * An application can install a named Codec using Io.addCodec() and this class
 * <b>is</b> able to access that codec via the name supplied to addCodec(). The
 * java.io.InputStreamReader however will not be able to access these codecs when
 * run under a Java VM. Therefore if you must use a specific Codec then you should
 * use this class instead.
 * @see java.io.InputStreamReader
 * @see java.io.BufferedReader
 * @see java.io.InputStream
 *
 * @author Aaron M. Renn (arenn@urbanophile.com)
 * @author Per Bothner <bothner@cygnus.com>
 * @date April 22, 1998.  
 */
public class EncodedStreamReader extends Reader
{
  /*
   * This is the byte-character decoder class that does the reading and
   * translation of bytes from the underlying stream.
   */
	private TextCodec codec;
	private InputStream in;
	private CharArray readIn = new CharArray();
	private byte[] buff;
	private int readOut = 0;
	private boolean readEnd = false;
	
  private EncodedStreamReader(InputStream in, boolean makeDefaultCodec)
  {
    if (in == null) throw new NullPointerException();
    this.in = in;
    if (makeDefaultCodec) try{
    	codec = Io.getCodec(Io.getDefaultCodecName(),false);
    }catch(Exception e){
    	codec = new AsciiCodec();
    }
  }
  /**
   * This method initializes a new instance of <code>EncodedStreamReader</code>
   * to read from the specified stream using the default encoding.
   *
   * @param in The <code>InputStream</code> to read from 
   */
  public EncodedStreamReader(InputStream in)
  {
    this(in,true);
  }

  /**
   * This method initializes a new instance of <code>EncodedStreamReader</code>
   * to read from the specified stream using a caller supplied character
   * encoding scheme.  Note that due to a deficiency in the Java language
   * design, there is no way to determine which encodings are supported.
   * 
   * @param in The <code>InputStream</code> to read from
   * @param encoding_name The name of the encoding scheme to use
   *
   * @exception UnsupportedEncodingException If the encoding scheme 
   * requested is not available.
   */
  public EncodedStreamReader(InputStream in, String encoding_name)
    throws UnsupportedEncodingException
  {
  	this(in,false);
  	if (encoding_name == null) throw new NullPointerException();
  	codec = Io.getCodec(encoding_name,false);
  }
  /**
   * This method initializes a new instance of <code>EncodedStreamReader</code>
   * to read from the specified stream using a caller supplied character
   * encoding scheme.  Note that due to a deficiency in the Java language
   * design, there is no way to determine which encodings are supported.
   * 
   * @param in The <code>InputStream</code> to read from
   * @param encoding_name The name of the encoding scheme to use
   *
   * @exception UnsupportedEncodingException If the encoding scheme 
   * requested is not available.
   */
  public EncodedStreamReader(InputStream in, TextCodec codec)
  {
  	this(in,false);
  	if (codec == null) throw new NullPointerException();
  	this.codec = codec;
  }

  /**
   * This method closes this stream, as well as the underlying 
   * <code>InputStream</code>.
   *
   * @exception IOException If an error occurs
   */
  public void close() throws IOException
  {
    in.close();
    in = null;
  }

  /**
   * This method returns the name of the encoding that is currently in use
   * by this object.  If the stream has been closed, this method is allowed
   * to return <code>null</code>.
   *
   * @param The current encoding name
   */
  public TextCodec getCodec()
  {
		return codec;
  }

  /**
   * This method checks to see if the stream is read to be read.  It
   * will return <code>true</code> if is, or <code>false</code> if it is not.
   * If the stream is not ready to be read, it could (although is not required
   * to) block on the next read attempt.
   *
   * @return <code>true</code> if the stream is ready to be read, 
   * <code>false</code> otherwise
   *
   * @exception IOException If an error occurs
   */
		/*
  public boolean ready() throws IOException
  {
    if (in == null)
      throw new IOException("Reader has been closed");
		return false;
    //return in.ready();
  }
*/
//-------------------------------------------------------------------
private int getBufferSize() {return 1024*10;}
//-------------------------------------------------------------------
  /**
   * This method reads up to <code>length</code> characters from the stream into
   * the specified array starting at index <code>offset</code> into the
   * array.
   *
   * @param buf The character array to recieve the data read
   * @param offset The offset into the array to start storing characters
   * @param length The requested number of characters to read.
   *
   * @return The actual number of characters read, or -1 if end of stream.
   *
   * @exception IOException If an error occurs
   */
//===================================================================
public int read(char[] dest, int offset, int length) throws IOException
//===================================================================
{
  if (in == null) throw new IOException("Reader has been closed");
	if (buff == null) buff = new byte[getBufferSize()];
	if (length <= 0) return 0;
	while(true){
		//
		//Check if there is any data in the decoded readIn CharArray.
		//
		if (readIn != null){
			if (readOut < readIn.length){
				int toRead = readIn.length-readOut;
				if (toRead > length) toRead = length;
				System.arraycopy(readIn.data,readOut,dest,offset,toRead);
				readOut += toRead;
				return toRead;
			}
		}
		//
		// No data in readIn, read bytes from the Stream and do a decode.
		//
		if (readEnd) return -1;
		int got = in.read(buff,0,buff.length);
		if (readIn != null) readIn.length = 0;
		if (got == -1) {
			readEnd = true;
			readIn = codec.decodeText(null,0,0,true,readIn);
		}else
			readIn = codec.decodeText(buff,0,got,false,readIn);
		readOut = 0;
	}
}

  /**
   * This method reads a single character of data from the stream.
   *
   * @return The char read, as an int, or -1 if end of stream.
   *
   * @exception IOException If an error occurs
   */
		/*
  public int read() throws IOException
  {
    if (in == null)
      throw new IOException("Reader has been closed");
    
    return in.read();
  }
*/
   /**
    * Skips the specified number of chars in the stream.  It
    * returns the actual number of chars skipped, which may be less than the
    * requested amount.
    *
    * @param num_chars The requested number of chars to skip
    *
    * @return The actual number of chars skipped.
    *
    * @exception IOException If an error occurs
    */
		/*
   public long skip(long count) throws IOException
   {
     if (in == null)
       throw new IOException("Reader has been closed");
     
     return super.skip(count);
  }
*/
} // class EncodedStreamReader

