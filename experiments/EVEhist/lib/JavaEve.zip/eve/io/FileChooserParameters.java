package eve.io;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import eve.data.PropertyList;
import eve.sys.Device;
import eve.sys.ImageData;
import eve.util.mString;

//##################################################################
public class FileChooserParameters extends PropertyList{
//##################################################################

private static Hashtable icons;

public static final String TYPE_OPEN = "open";
public static final String TYPE_SAVE = "save";
public static final String TYPE_BROWSE = "browse";
public static final String TYPE_DIRECTORY_SELECT = "directory";

/**
This property is used to indicate what type of file is being loaded. If you
set the value to "image" then it indicates that a FileChooser with an Image preview 
should be selected.
**/
public static final String FILE_TYPE_HINT = "fileType";
//public static final String TYPE_OPEN = "open";
//public static final String TYPE_OPEN = "open";

/**
This property is used with a FileChooserLink object to specify a location
folder the user can select. There can be multiple values for LOCATION.
**/
public static final String LOCATION = "location";

public static final String PERSISTENT_HISTORY = "persistentHistory";
/**
This property is used to set the title of the FileChooser.
**/
public static final String TITLE = "title";
/**
This is property is used to select the type of the FileChooser. This
should be "open" or "save" or "browse".
**/
public static final String TYPE = "type";
/**
This is property is used to set the default extension.
**/
public static final String DEFAULT_EXTENSION = "defaultExtension";
/**
This is a property for the FileChooser, which should be a String value.
**/
public static final String START_LOCATION = "startLocation";
/**
This is a property for the FileChooser - you can have more than one, which should be a String value.
**/
public static final String FILE_MASK = "mask";
/**
This is a property for the FileChooser - it should be of type eve.io.File.
**/
public static final String FILE_MODEL = "fileModel";
/**
This is set on return - it is the list of chosen files as an array of File objects.
If multiple file selection is not allowed, there will be only one element in the list.
**/
public static final String CHOSEN_FILES = "chosenFiles";
/**
This is set on return - it is the chosen file as an eve.io.File object.
**/
public static final String CHOSEN_FILE = "chosenFile";
/**
This is used to set the options for the FileChooser. This should be an integer value
which would be any of the OPTION_XXX values ORed together.
**/
public static final String OPTIONS = "options";
/**
This is a property for the FileChooser and is the list of icons associated with
file extensions - it should be of type java.util.Hashtable.
**/
public static final String ICONS = "icons";
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_QUICK_SELECT = 0x4;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_FILE_MUST_EXIST = 0x8;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_DIRECTORY_TREE = 0x10;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_NO_DIRECTORY_CHANGE = 0x20;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_ACCEPT_ANY = 0x40;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_READ_ONLY = 0x80;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_INSTALL_SELECT = 0x100;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_DESKTOP_VERSION = 0x200;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_NO_CONFIRM_OVERWRITE = 0x400;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_MULTI_SELECT = 0x1000;
/**
This is an option to be used with the OPTIONS property 
- it indicates that files will be displayed in Directory Select
mode.
**/
public static final int OPTION_SHOW_FILES_WITH_DIRECTORY_SELECT = 0x20000;
/**
This is an option to be used with the OPTIONS property 
- it indicates
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_NO_EXECUTE = 0x8000;
//
// Start others at 0x100000
//
/**
This is an option to be used with the OPTIONS property 
- it indicates that file extensions should not be displayed.
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_DONT_SHOW_FILE_EXTENSION = 0x100000;

/**
This is an option to be used with the OPTIONS property.
- it is OPTION_DONT_SHOW_EXTENSION|OPTION_NO_DIRECTORY_CHANGE.
You can bitwise OR together this option with any of the others.
**/
public static final int OPTION_SIMPLE = OPTION_DONT_SHOW_FILE_EXTENSION|OPTION_NO_DIRECTORY_CHANGE;
/**
 * Set or clear bits in the OPTIONS value.
 * @param optionsToSet the bits to set.
 * @param optionsToClear the bits to clear.
 * @return the final value of the OPTIONS value.
 */
public int setOptions(int optionsToSet, int optionsToClear)
{
	int opt = getInt(OPTIONS,0);
	opt |= optionsToSet;
	opt &= ~optionsToClear;
	setInt(OPTIONS,opt);
	return opt;
}
public File getChosenFile()
{
	return (File)getValue(CHOSEN_FILE,null);
}
public File [] getChosenFiles()
{
	return (File [])getValue(CHOSEN_FILES,null);
}
/**
 * Retrieve the global File Icons hashtable, which will be setup with the
 * default values.
 */
public static synchronized Hashtable getFileIconsHashtable()
{
	if (icons == null) {
		icons = new Hashtable();
		setupIcons("eve|evesmall|ewe|ewesmall|exe|programsmall|zip|zipsmall",icons);
		setupIcons("bmp;png;jpg;jpeg;gif;ico;icon|imagesmall|txt;doc;lst|textsmall",icons);
		setupIcons("htm;html|websmall",icons);
	}
	return icons;
}
/**
 * Correctly associate a file extension with an 16x16 Image icon.
 * @param destination a destination Hashtable. If this is null the default icons hashtable
 * @param extension the extension or a semicolon seperated list of extensions, in any case, with or without the leading "."
 * @param an Object to be sent to Device.loadPicture() to be used.
 * will be used.
 */
public static void associateFileIcon(Hashtable destination,String extension, Object image)
{
	associateFileIcon(extension, Device.loadPicture(image),destination);
}
/**
 * Correctly associate a file extension with an 16x16 Image icon.
 * @param extension the extension or a semicolon seperated list of extensions, in any case, with or without the leading "."
 * @param image the ImageData to be used.
 * @param destination a destination Hashtable. If this is null the default icons hashtable
 * will be used.
 */
public static void associateFileIcon(String extension, ImageData image, Hashtable destination)
{
	if (image == null) return;
	if (image.getImageWidth() != 16 || image.getImageHeight() != 16){
		try{
			image = Device.scaleImage(image,16,16);
		}catch(Exception e){}
	}
		
	if (destination == null) destination = getFileIconsHashtable();
	String[] all = mString.checkSplit(extension,";,| ");
	if (all != null){
		for (int i = 0; i<all.length; i++){
			extension = all[i];
			String key = extension.charAt(0) == '.' ? extension.substring(1).toUpperCase() : extension.toUpperCase();
			destination.put(key,image);
		}
	}else{
		String key = extension.charAt(0) == '.' ? extension.substring(1).toUpperCase() : extension.toUpperCase();
		destination.put(key,image);
	}
}
/**
 * Correctly lookup a 16x16 Image icon for a file extension.
 * @param extension the extension, in any case, with or without the leading "."
 * @param lookup a lookup Hashtable. If this is null the default icons hashtable
 * will be used.
 * @param defaultIfNotFound the value to return if no icon was found.
 * @return the icon found or the defaultIfNotFound value if it was not found.
 */
public static ImageData getFileIcon(String extension,Hashtable lookup,ImageData defaultIfNotFound)
{
	if (extension.length() < 1) return defaultIfNotFound;
	if (lookup == null) lookup = getFileIconsHashtable();
	String key = extension.charAt(0) == '.' ? extension.substring(1).toUpperCase() : extension.toUpperCase();
	Object got = lookup.get(key);
	return got instanceof ImageData ? (ImageData)got : defaultIfNotFound;
}
private static void setupIcons(String extAndIcons,Hashtable ht)
{
	String[] all = mString.split(extAndIcons,'|');
	for (int i = 0; i<all.length; i += 2)
		associateFileIcon(ht,all[i],"eve/"+all[i+1]+".png");
}
private static ImageData doubleSizeIt(ImageData got)
{
	int w = got.getImageWidth(), h = got.getImageHeight();
	if (h <= 17 && w <= 17){
		return Device.scaleImage(got,w*2,h*2);
	}
	return got;
}

public static void doubleSizeAll(Hashtable icons)
{
	Hashtable ht = icons == null ? FileChooserParameters.getFileIconsHashtable() : icons;
	Vector vc = new Vector();
	for (Enumeration e = ht.keys(); e.hasMoreElements(); )
		vc.add(e.nextElement());
	for (int i = 0; i<vc.size(); i++){
		Object k = vc.get(i);
		Object v = ht.get(k);
		if (!(v instanceof ImageData)) continue;
		ImageData ii = doubleSizeIt((ImageData)v);
		ht.put(k,ii);
	}
}
//##################################################################
}
//##################################################################

