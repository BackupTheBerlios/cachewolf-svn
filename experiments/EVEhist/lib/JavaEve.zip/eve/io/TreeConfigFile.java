package eve.io;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Vector;

import eve.data.DataUtils;
import eve.data.TreeNode;
import eve.sys.LocalResource;
import eve.sys.Locale;
import eve.sys.Vm;
import eve.util.TextDecoder;
//##################################################################
public class TreeConfigFile implements Comparable{
//##################################################################

public String configFileName = "";

TreeConfigNode root = new TreeConfigNode("/");

public static boolean cacheFullConfigFiles = false;

public static Vector configFiles = new Vector();


//===================================================================
public static TreeConfigFile getConfigFile(InputStream stream,String uniqueName)
throws IOException
//===================================================================
{
	int idx = configFiles.indexOf(uniqueName);
	if (idx != -1) return (TreeConfigFile)configFiles.get(idx);
	if (stream == null) return null;
	TreeConfigFile tcf = new TreeConfigFile();
	tcf.configFileName = uniqueName;
	boolean ok = tcf.decodeFrom(stream);
	stream.close();
	if (!ok) return null;
	if (cacheFullConfigFiles) configFiles.add(tcf);
	return tcf;
}
//===================================================================
public static TreeConfigFile getConfigFile(File file)
//===================================================================
{
	if (file == null) return null;
	String path = file.getFullPath();
	int idx = configFiles.indexOf(path);
	if (idx != -1) return (TreeConfigFile)configFiles.get(idx);
	try{
		return getConfigFile(file.toReadableStream(),path);
	}catch(IOException e){
		return null;
	}
}
//===================================================================
public static TreeConfigFile getConfigFile(String path)
//===================================================================
{
	int idx = configFiles.indexOf(path);
	if (idx != -1) return (TreeConfigFile)configFiles.get(idx);
	try{
		return getConfigFile(Vm.openResource(null,path),path);
	}catch(IOException e){
		return null;
	}
}
/**
This is used by ewe.sys.Locale - use getConfigFile() instead.
**/
//===================================================================
public TreeConfigFile findOrMake(String path)
//===================================================================
{
	return getConfigFile(path);
}
//===================================================================
public boolean equals(Object other)
//===================================================================
{
	return compareTo(other) == 0;
}
//===================================================================
public int compareTo(Object other)
//===================================================================
{
	if (other instanceof String) return configFileName.compareTo((String)other);
	else if (other instanceof TreeConfigFile) return configFileName.compareTo(((TreeConfigFile)other).configFileName);
	return super.equals(other) ? 0 : 1;
}
//===================================================================
public TreeConfigFile()
//===================================================================
{
}

//===================================================================
public TreeConfigNode find(String name)
//===================================================================
{
	if (name == null) return null;
	if (name.startsWith("/")) name = name.substring(1);
	if (name.length() == 0) return root;
	int [] got = DataUtils.addressOfChild(root,name);
	if (got == null) return null;
	return (TreeConfigNode)DataUtils.getChildAt(root,got);
}
//===================================================================
public TreeNode getRoot(){return root;}
//===================================================================

//===================================================================
public boolean decodeFrom(InputStream in) throws IOException
//===================================================================
{
	BufferedReader br = new BufferedReader(new InputStreamReader(in));
	TreeConfigNode tcn = root;
	while(true){
		String got = br.readLine();
		if (got == null) break;
		got = got.trim();
		if (got.startsWith(";")) continue;
		if (got.startsWith("{..}")){
			if (tcn == root) break;
			else tcn = (TreeConfigNode)tcn.getParent();
			continue;
		}
		if (got.startsWith("{")){
			int idx = got.indexOf('}');
			if (idx == -1) idx = got.length();
			TreeConfigNode nn = new TreeConfigNode(got.substring(1,idx));
			tcn.addChild(nn);
			tcn = nn;
			continue;
		}
		int eq = got.indexOf('=');
		if (eq != -1){
			tcn.getProperties().add(got.substring(0,eq),TextDecoder.decode(Vm.getStringChars(got),eq+1,got.length()-eq-1));
		}
	}
	in.close();
	return true;
}

//===================================================================
public LocalResource getLocalResourceObject(Locale forWho,String moduleName)
//===================================================================
{
	String language = forWho.getString(forWho.LANGUAGE_SHORT,0,0);
	String fullLanguage = language+"-"+forWho.getString(forWho.COUNTRY_SHORT,0,0);
	TreeConfigNode tcf = find(moduleName+"/LocalResources");
	if (tcf == null) return null;
	TreeConfigNode ret = (TreeConfigNode)DataUtils.findNamedChild(tcf,fullLanguage);
	if (ret == null) ret = (TreeConfigNode)DataUtils.findNamedChild(tcf,language);
	if (ret != null && !cacheFullConfigFiles) ret.setParent(null);
	return ret;
}

//##################################################################
}
//##################################################################

