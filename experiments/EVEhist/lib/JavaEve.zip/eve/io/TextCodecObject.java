/*
 * Created on Apr 3, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.IOException;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
abstract class TextCodecObject implements TextCodec{
/* Don't move these three variables. **/
int flags = 0;
int byteOne = -1;
int byteTwo = -1;
int encodeByteOne = -1;
int encodeByteTwo = -1;
/**
* This is a creation option. It specifies that CR characters should be removed when
* encoding text into UTF.
**/
static final int _STRIP_CR_ON_DECODE = 0x1;
/**
* This is a creation option. It specifies that CR characters should be removed when
* decoding text from UTF.
**/
static final int _STRIP_CR_ON_ENCODE = 0x2;
/**
* This is a creation option. It specifies that CR characters should be removed when
* decoding text from UTF.
**/
static final int _STRICT = 0x8;

//Start new options at 0x100

static final int _UTF8_CODEC = 1;
static final int _ASCII_CODEC = 2;
static final int _UTF16_CODEC = 3;

static boolean hasNative = true;

native void encodeDecode(int which, boolean isEncode, Object src, int offset, int length, boolean isEndOfInput, Object dest, int flags)
throws IOException;

public void reset()
{
	byteOne = byteTwo = -1;
	encodeByteOne = encodeByteTwo = -1;
}
}
//####################################################
