
package eve.io;

import java.io.StreamCorruptedException;
import java.util.zip.DataFormatException;


/**
 * Inflater is used to decompress data that has been compressed according 
 * to the "deflate" standard described in rfc1950.
 *
 * The usage is as following.  First you have to set some input with
 * <code>setInput()</code>, then inflate() it.  If inflate doesn't
 * inflate any bytes there may be three reasons:
 * <ul>
 * <li>needsInput() returns true because the input buffer is empty.
 * You have to provide more input with <code>setInput()</code>.  
 * NOTE: needsInput() also returns true when, the stream is finished.
 * </li>
 * <li>needsDictionary() returns true, you have to provide a preset 
 *     dictionary with <code>setDictionary()</code>.</li>
 * <li>finished() returns true, the inflater has finished.</li>
 * </ul>
 * Once the first output byte is produced, a dictionary will not be
 * needed at a later stage.
 *
 * @author John Leuner, Jochen Hoenicke
 * @author Tom Tromey
 * @date May 17, 1999
 * @since JDK 1.1
 */
public class Inflater
{
	java.util.zip.Inflater inflater;
//
// Don't move these six. They must match Deflater.java
//
	/*
int nativeObject = 0;
private int status = 1;
private int remaining;
private long totalRead;
private long totalWritten;
private int adler;
//
*/
  /**
   * This variable stores the nowrap flag that was given to the constructor.
   * True means, that the inflated stream doesn't contain a header nor the
   * checksum in the footer.
   */
  private boolean nowrap;

  /**
   * Creates a new inflater.
   */
  public Inflater ()
  {
    this (false);
  }

  /**
   * Creates a new inflater.
   * @param nowrap true if no header and checksum field appears in the
   * stream.  This is used for GZIPed input.  For compatibility with
   * Sun JDK you should provide one byte of input more than needed in
   * this case.
   */
  public Inflater (boolean nowrap)
  {
    this.nowrap = nowrap;
    reset();
  }

 public void reset()
 {
 	reset(nowrap);
 }
 
 private void reset(boolean noWrap)
 {
 	inflater = new java.util.zip.Inflater(noWrap);
 }
 public void setInput(byte[]b, int off, int len)
 {
 	inflater.setInput(b,off,len);
 }
 public void setDictionary(byte[]b, int off, int len)
 {
 	inflater.setDictionary(b,off,len);
 }
 public void end()
 {
 	inflater.end();
 }

 public void setInput(byte[]b)
 {
 	setInput(b,0,b.length);
 }
 public void setDictionary(byte[]b)
 {
 	setDictionary(b,0,b.length);
 }
 public int inflate(byte[] b, int off, int len) throws StreamCorruptedException 
 {
 	try{
 		return inflater.inflate(b,off,len);
 	}catch(DataFormatException e){
 		throw new StreamCorruptedException();
 	}
 }
 public int inflate(byte[] b) throws StreamCorruptedException
 {
 	return inflate(b,0,b.length);
 }
 public boolean finished()
 {
 	return inflater.finished();
 }
 public boolean needsInput()
 {
 	return inflater.needsInput();
 }
 public boolean needsDictionary()
 {
 	return inflater.needsDictionary();
 }
 public int getRemaining()
 {
 	return inflater.getRemaining();
 }

 /*
 public int getRemaining()
 {
 	return remaining;
 }
 */
 public long getBytesRead()
 {
 	return inflater.getTotalIn();
 }
 public long getBytesWritten()
 {
 	return inflater.getTotalOut();
 }
 public int getTotalIn()
 {
 	return inflater.getTotalIn();
 }
 public int getTotalOut()
 {
 	return inflater.getTotalOut();
 }
 public int getAdler()
 {
 	return inflater.getAdler();
 }
}
