package eve.io;

import java.io.IOException;

import eve.sys.Vm;

//##################################################################
public class CorruptedDataException extends IOException{
//##################################################################

public CorruptedDataException() {super();}
public CorruptedDataException(String message) {super(message);}
//===================================================================
public CorruptedDataException(Throwable cause) {Vm.setCause(this,cause);}
//===================================================================
public CorruptedDataException(String message,Throwable cause) {super(message); Vm.setCause(this,cause);}
//===================================================================

//##################################################################
}
//##################################################################

