package eve.io;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;

import eve.nativeaccess.NativeAccess;
import eve.nativeaccess.NativeStream;
import eve.sys.Vm;

//##################################################################
public abstract class RandomStream extends InputStream{
//##################################################################
	private String mode;
	private long marker = -1, endMarker;

	private int getNativeStream()
	{
		try{
			return NativeAccess.getSetVariable(this,0,true,null);
		}catch(Throwable t){
			return 0;
		}
	}
	public static final String READ_ONLY = "r";
	public static final String READ_WRITE = "rw";

//	-------------------------------------------------------------------
	protected RandomStream(String mode) throws IllegalArgumentException
//	-------------------------------------------------------------------
	{
		setMode(mode);
	}

//	-------------------------------------------------------------------
	protected RandomStream(){}
//	-------------------------------------------------------------------

	/**
	 * Validate the specified mode, which must be "r" or "rw".
	 * @param mode the mode to validate.
	 * @return the READ_ONLY or READ_WRITE String values if mode is valid.
	 * @exception IllegalArgumentException if the mode parameter is not valid.
	 */
//	===================================================================
	public static String validateMode(String mode) throws IllegalArgumentException
//	===================================================================
	{
		return isReadWrite(mode) ? READ_WRITE : READ_ONLY;
	}
	/**
	 * Checks if the specified mode is read/write or read only.
	 * @param mode the mode.
	 * @return true if it is read/write, false if it is read only.
	 * @exception IllegalArgumentException if it is not "r" or "rw".
	 */
//	===================================================================
	public static boolean isReadWrite(String mode) throws IllegalArgumentException
//	===================================================================
	{
		if (READ_ONLY.equals(mode)) return false;
		else if (READ_WRITE.equals(mode)) return true;
		else throw new IllegalArgumentException();
	}

	private long doRandomOp(int op, long value)
	throws IOException
	{
		int s = getNativeStream();
		if (s == 0){
			AbstractMethodError e = new AbstractMethodError();
			Vm.fixFillInStackTrace(1);
			e.fillInStackTrace();
			throw e;
		}
		return NativeStream.streamOperation(s,op,null,0,value);
	}

	/**
	 * Return the full length of the Stream.
	 * @exception IOException if an IO error occured.
	 */
	public long getLength() throws IOException
	{
		return doRandomOp(NativeStream.RANDOM_OP_GET_LENGTH,0);
	}
	/**
	 * Attempt to set the length of the stream if this is supported.
	 * This will truncate the stream or extend the stream to the requested length.
	 * @exception IOException if the length cannot be set or if there was an error.
	 */
	public void setLength(long length) throws IOException
	{
		doRandomOp(NativeStream.RANDOM_OP_SET_LENGTH,length);
	}
	/**
	 * Return the current read/write stream pointer.
	 * @exception IOException on error.
	 */
	public long getPosition() throws IOException
	{
		return doRandomOp(NativeStream.RANDOM_OP_GET_POSITION,0);
	}
	/**
	 * Set the Stream position. This position actually set may be different if, say, 
	 * the requested position is greater than the actual size of the Stream.
	 * @param newPosition the new position to set.
	 * @exception IOException on error.
	 */
	public void setPosition(long newPosition) throws IOException
	{
		doRandomOp(NativeStream.RANDOM_OP_SET_POSITION,newPosition);
	}
	/**
	 * Returns true if this Stream was open in Read-Write mode as opposed to Read-Only mode.
	 * The default implementation checks the mode as set by setMode().
	 */
//	===================================================================
	public boolean isOpenForWriting()
//	===================================================================
	{
		return this.mode.equals(READ_WRITE);
	}
	/**
	 * Return if this Stream has the capability to set the stream length in Read/Write mode.
	 */
//	===================================================================
	public boolean canSetLength()
//	===================================================================
	{
		return false;
	}
	/**
	 * Set the mode of this RandomStream. You usually call this from the constructor.
	 * @param mode either "r" or "rw". Any other throws an IllegalArgumentException
	 * @exception IllegalArgumentException if the mode is not "r" or "rw"
	 */
//	-------------------------------------------------------------------
	protected void setMode(String mode) throws IllegalArgumentException
//	-------------------------------------------------------------------
	{
		this.mode = validateMode(mode);
	}
	/**
	 * Get an OutputStream for writing to the RandomStream.
	 * The OutputStream will write to the RandomStream from the current position.
	 * @return an OutputStream for writing to the RandomStream.
	 * @exception IOException if an OutputStream could not be created.
	 */
//	===================================================================
	public OutputStream toOutputStream() throws IOException
//	===================================================================
	{
		if (!isOpenForWriting()) {
			throwCantWrite();
			return null;
		}
		return new OutputStream(){
			public void write(int data) throws IOException
				{RandomStream.this.write(data);}
			public void write(byte[] source, int offset, int count) throws IOException
				{RandomStream.this.write(source,offset,count);}
			public void close() throws IOException
				{RandomStream.this.close();}
			public void flush() throws IOException
				{RandomStream.this.flush();}
		};
	}

//	===================================================================
	public synchronized void mark(int readLimit)
//	===================================================================
	{
		try{
			marker = getPosition();
			endMarker = marker+readLimit;
		}catch(IOException e){}
	}
//	===================================================================
	public synchronized void reset() throws IOException
//	===================================================================
	{
		if (marker == -1){
			throw new IOException();
		}
		if (getPosition() > endMarker) {
			// I do nothing, because there is a bug in Java's sound system.
			// It incorrectly sets the read limit when reading .wav files.
		}
		setPosition(marker);
		marker = -1;
	}
//	===================================================================
	public boolean markSupported()
//	===================================================================
	{
		return true;
	}

//	===================================================================
	public long skip(long num) throws IOException
//	===================================================================
	{
		long pos = getPosition();
		long length = getLength();
		if (num+pos > length) num = length-pos;
		setPosition(num+pos);
		return num;
	}

	private long doOutputOp(int op, byte[] data, int offset, long length)
	throws IOException
	{
		int nativeStream = getNativeStream();
		if (nativeStream == 0){
			AbstractMethodError e = new AbstractMethodError();
			Vm.fixFillInStackTrace(1);
			e.fillInStackTrace();
			throw e;
		}
		return NativeStream.streamOperation(nativeStream,op,data,offset,length);
	}

	  /**
	   * This method writes a single byte to the output stream.  The byte written
	   * is the low eight bits of the <code>int</code> passed as the argument.
	   * <p>
	   * Subclasses must provide an implementation of this method.
	   *
	   * @param b The byte to be written to the output stream, passed as
	   *          the low eight bits of an <code>int</code> 
	   *
	   * @exception IOException If an error occurs
	   */
	  public void write(int b) throws IOException
	  {
	  	doOutputOp(NativeStream.OUTPUT_OP_WRITE,null,0,b);
	  }
	    /**
	   * This method all the writes bytes from the passed array to the
	   * output stream.  This method is equivalent to <code>write(b, 0,
	   * buf.length)</code> which is exactly how it is implemented in this
	   * class.
	   *
	   * @param b The array of bytes to write
	   *
	   * @exception IOException If an error occurs
	   */
	  public void write (byte[] b) throws IOException, NullPointerException
	  {
	    write (b, 0, b.length);
	  }

	  /**
	   * This method writes <code>len</code> bytes from the specified array
	   * <code>b</code> starting at index <code>off</code> into the array.
	   * <p>
	   * This method in this class calls the single byte <code>write()</code>
	   * method in a loop until all bytes have been written.  Subclasses should
	   * override this method if possible in order to provide a more efficent
	   * implementation.
	   *
	   * @param data The array of bytes to write from
	   * @param offset The index into the array to start writing from
	   * @param count The number of bytes to write
	   * 
	   * @exception IOException If an error occurs
	   */
	  public void write (byte[] data, int offset, int count) throws IOException, NullPointerException, IndexOutOfBoundsException
	  {
		if (getNativeStream() == 0) throw new AbstractMethodError();
	  	if (count == 0) return;
	  	if (data == null) throw new NullPointerException();
	  	if (count < 0) throw new IllegalArgumentException();
	    if (offset < 0 ||  offset + count > data.length)
	      throw new ArrayIndexOutOfBoundsException ();
	  	doOutputOp(NativeStream.OUTPUT_OP_WRITE,data,offset,count);
	  }

	  /**
	   * This method forces any data that may have been buffered to be written
	   * to the underlying output device.  Please note that the host environment
	   * might perform its own buffering unbeknowst to Java.  In that case, a
	   * write made (for example, to a disk drive) might be cached in OS
	   * buffers instead of actually being written to disk.
	   * <p>
	   * This method in this class does nothing.
	   *
	   * @exception IOException If an error occurs
	   */
	  public void flush () throws IOException
	  {
	  	if (getNativeStream() == 0) return;
	  	doOutputOp(NativeStream.OUTPUT_OP_FLUSH,null,0,0);
	  }
	  /**
	   * Throw an IOException indicating that you cannot write to this RandomStream.
	   * @exception IOException always thrown.
	   */
	  protected void throwCantWrite() throws IOException
	  {
	  	throw new IOException("Stream is not open for writing.");
	  }

//##################################################################
}
//##################################################################

