/*
 * Created on Mar 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class FileRandomStream extends RandomStream {
private RandomAccessFile raf;
	/**
	 * @param filePath
	 * @param mode should be either "r" or "rw"
	 * @throws IllegalArgumentException
	 * @throws FileNotFoundException
	 */
	public FileRandomStream(String filePath, String mode) throws IllegalArgumentException, FileNotFoundException {
		this(new java.io.File(filePath),mode);
	}
	/**
	 * @param file
	 * @param mode should be either "r" or "rw"
	 * @throws IllegalArgumentException
	 * @throws FileNotFoundException
	 */
	public FileRandomStream(File file, String mode) throws IllegalArgumentException, FileNotFoundException {
		this(file.getAbsolutePath(),mode);
	}
	/**
	 * @param file
	 * @param mode should be either "r" or "rw"
	 * @throws IllegalArgumentException
	 * @throws FileNotFoundException
	 */
	public FileRandomStream(java.io.File file, String mode) throws IllegalArgumentException, FileNotFoundException {
		super(mode);
		try{
			raf = new RandomAccessFile(file,mode);
		}catch(SecurityException se){
			throw new FileNotFoundException(file.toString());
		}
	}
	
	private FileRandomStream(RandomAccessFile rf,String mode) throws IllegalArgumentException, IOException {
		super(mode);
		raf = rf;
	}
	
	public int read() throws IOException {
		return raf.read();
	}
	public int read(byte[] dest, int offset, int count) throws IOException{
		return raf.read(dest,offset,count);
	}
	public void write(int ch) throws IOException {
		raf.write(ch);
	}
	public void write(byte[] src, int offset, int count) throws IOException{
		raf.write(src,offset,count);
	}
	/**
	 * Return the full length of the Stream.
	 * @exception IOException if an IO error occured.
	 */
	public long getLength() throws IOException
	{
		return raf.length();
	}
	/**
	 * Attempt to set the length of the stream if this is supported.
	 * This will truncate the stream or extend the stream to the requested length.
	 * @exception IOException if the length cannot be set or if there was an error.
	 */
	public void setLength(long length) throws IOException
	{
		raf.setLength(length);
	}
	/**
	 * Return the current read/write stream pointer.
	 * @exception IOException on error.
	 */
	public long getPosition() throws IOException
	{
		return raf.getFilePointer();
	}
	/**
	 * Set the Stream position. This position actually set may be different if, say, 
	 * the requested position is greater than the actual size of the Stream.
	 * @param newPosition the new position to set.
	 * @exception IOException on error.
	 */
	public void setPosition(long newPosition) throws IOException
	{
		raf.seek(newPosition);
	}
	/**
	 * Return if this Stream has the capability to set the stream length in Read/Write mode.
	 */
//	===================================================================
	public boolean canSetLength()
//	===================================================================
	{
		return true;
	}
	//
	// There's no flush in RandomAccessFile - go figure.
	//
	public void flush () throws IOException{
		//raf.flush();
	}
	/**
	 * Convert a RandomAccessFile to a RandomStream using the most efficient method.
	 * @param raf the already open RandomAccessFile.
	 * @param mode the mode the RandomAccessFile is open for (either "r" or "rw").
	 * @return a RandomStream for reading from the open RandomAccessFile. 
	 * @throws IllegalArgumentException if the mode is not "r" or "rw"
	 * @throws IOException if the conversion could not be made for any reason.
	 */
	public static synchronized RandomStream toRandomStream(RandomAccessFile raf,String mode) throws IllegalArgumentException, IOException 
	{
		return new FileRandomStream(raf,mode);
	}
	public void close() throws IOException{
		raf.close();
	}
}
//####################################################
