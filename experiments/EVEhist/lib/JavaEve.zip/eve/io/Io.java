/*
 * Created on Apr 2, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StreamCorruptedException;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.Vector;

import eve.sys.Convert;
import eve.sys.IRegistryKey;
import eve.sys.Rapi;
import eve.sys.Registry;
import eve.sys.Vm;
import eve.util.IntArray;
import eve.util.Utils;
import eve.util.mString;
import eve.util.ByteArray;
import eve.util.mVector;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Io {
	
	/**
	 * This is the host name associated with the infra-red port.
	 */
	public static final String infraRedHostName = "infra-red";

	public static final String JAVA_UTF8_CODEC_NAME = "Java-UTF-8";
	public static final String STANDARD_UTF8_CODEC_NAME = "UTF-8";
	public static final String ASCII_CODEC_NAME = "ASCII";
	public static final String ISO_8859_1_CODEC_NAME = "ISO-8859-1";
	
private static Hashtable codecs = new Hashtable();

static{
	addCodec(new JavaUtf8Codec(),"Java-UTF-8,Java-UTF8,JavaUTF8");
	addCodec(new Utf8Codec(),"UTF-8,UTF8");
	addCodec(new AsciiCodec(),"ASCII,US-ASCII,Cp1252");
	addCodec(new AsciiCodec(),"ISO-8859-1,ISO-LATIN-1,8859_1,LATIN_1");
	addCodec(new Utf16Codec(true,Utf16Codec.IGNORE_ENDIAN_MARKER_ON_DECODE),"UTF-16BE,UnicodeBigUnmarked");
	addCodec(new Utf16Codec(false,Utf16Codec.IGNORE_ENDIAN_MARKER_ON_DECODE),"UTF-16LE,UnicodeLittleUnmarked");
	addCodec(new Utf16Codec(true,Utf16Codec.MUST_HAVE_ENDIAN_MARKER_ON_DECODE|Utf16Codec.WRITE_ENDIAN_MARKER_ON_ENCODE),"UTF-16,Unicode");
}
private static String defaultCodec = "UTF-8";
/**
 * Add a codec with the specified names.
 * @param codec The TextCodec.
 * @param names A comma separated list of names for the codec.
 */
public static void addCodec(TextCodec codec, String names)
{
	String[] all = mString.split(names,',');
	for (int i = 0; i<all.length; i++)
		codecs.put(all[i].toUpperCase(),codec);
}
/**
 * Get a TextCodec with the specified name.
 * @param name The name of the codec.
 * @param useDefaultIfNotFound if this is true then the default codec will be returned
 * if the codec with the specified name was not found. Otherwise an UnsupportedEncodingException
 * will be thrown.
 * @return the TextCodec with the specified name.
 * @throws UnsupportedEncodingException if no codec was found.
 */
public static TextCodec getCodec(String name, boolean useDefaultIfNotFound) throws UnsupportedEncodingException
{
	TextCodec got = (TextCodec)codecs.get(name.toUpperCase());
	if (got == null && useDefaultIfNotFound) got = (TextCodec)codecs.get(defaultCodec.toUpperCase());
	if (got == null) throw new UnsupportedEncodingException(name);
	return (TextCodec)got.getCopy();
}
/**
 * Get a TextCodec with the specified name.
 * @param name The name of the codec.
 * @param defaultIfNotFound A codec to return
 * if the codec with the specified name was not found. If this is null and
 * a codec is not found then an UnsupportedEncodingException
 * will be thrown.
 * @return the TextCodec with the specified name.
 * @throws UnsupportedEncodingException if no codec was found.
 */
public static TextCodec getCodec(String name, TextCodec defaultIfNotFound) throws UnsupportedEncodingException
{
	TextCodec got = (TextCodec)codecs.get(name.toUpperCase());
	if (got == null) got = defaultIfNotFound;
	if (got == null) throw new UnsupportedEncodingException(name);
	return (TextCodec)got.getCopy();
}
/**
 * Return the platform's default TextCodec name. This is used by TextReader and TextWriter
 * but not by InputStreamReader or OutputStreamWriter.
 */
public static String getDefaultCodecName()
{
	return defaultCodec;
}
/**
 * Return the platform's default codec. This should never return null since it must
 * exist. 
 */
public static TextCodec getDefaultCodec()
{
	try{
		return getCodec(getDefaultCodecName(),false);
	}catch(UnsupportedEncodingException e){
		throw new InternalError("No default Text Codec found!");
	}
}
/**
 * Set the platform's default TextCodec. Note that this may not have any effect
 * if you are using an InputStreamReader or OutputStreamWriter. This method call will have
 * no effect on those classes under a Java VM, but the call <b>will</b> have an effect
 * on TextReader and TextWriter. They call getDefaultCodec() if you do not specify a
 * codec.
 */
public static void setDefaultCodec(TextCodec tc,String name)
{
	if (tc == null || name == null) throw new NullPointerException();
	defaultCodec = name;
	addCodec(tc,name);
}
//===================================================================
public static ByteArray processAll(DataProcessor dp,byte [] source)
//===================================================================
{
	try{
		return processAll(dp,source,0,source.length,null);
	}catch(IOException e){
		return null;
	}
}
//===================================================================
public static ByteArray processAll(DataProcessor dp,byte [] source,int offset,int length)
//===================================================================
{
	try{
		return processAll(dp,source,offset,length,null);
	}catch(IOException e){
		return null;
	}
}
//===================================================================
public static ByteArray processAll(DataProcessor dp,byte [] source,int offset,int length,ByteArray dest)
throws IOException
//===================================================================
{
	if (dest == null) dest = new ByteArray();
	dest.clear();
	int bs = dp.getBlockSize();
	if (bs <= 0) bs = 1;
	int max = dp.getMaxBlockSize();
	if (max <= 0) max = 0;
	if ((max == 0 || length <= max) && (length % bs) == 0){
		return dp.processBlock(source,offset,length,true,dest);
	}
	ByteArray buff = new ByteArray(), buff2 = null;
	int did = 0;
	while(did < length){
		//
		// Get up to max of the data.
		//
		buff.clear();
		if ((max != 0) && ((length-did) > max)){
			buff.append(source,offset,max);
			did += max;
		}else{
			buff.append(source,offset,(length-did));
			did = length;
		}
		//
		int toAppend = bs-(length%bs);
		if (toAppend != 0 && toAppend != bs)
			buff.append(new byte[toAppend],0,toAppend);
		if (max == 0 || length <= max) //All I would have done is padded the data.
			return dp.processBlock(buff.data,0,buff.length,true,dest);
		else{
			buff2 = dp.processBlock(buff.data,0,buff.length,(length == did),buff2);
			dest.append(buff2.data,0,buff2.length);
			buff2.clear();
		}
	}
	return dest;
}
/*
private static Object tryType(String name, String parameter, Object data)
{
	Type t = new Type(name);
	if (!t.exists()) return null;
	return t.newInstance(parameter,new Object[]{data});
}
public static InputStream getInflaterInputStream(InputStream byteSource)
{
	return getInflaterInputStream(byteSource,false);
}
public static InputStream getInflaterInputStream(InputStream byteSource,boolean noWrap)
{
	Type t = null;
	t = new Type("java.util.zip.InflaterInputStream");
	if (t.exists()){
		//System.out.println(t.getClassName());
		Type inf = new Type("java.util.zip.Inflater");
		Object i = inf.newInstance("Z",new Object[]{Boolean.valueOf(noWrap)});
		Object iis = t.newInstance("Ljava/io/InputStream;Ljava/util/zip/Inflater;",new Object[]{byteSource,i});
		if (iis != null) return (InputStream)iis;
	}
	t = new Type("eve.nativeaccess.InflaterInputStream");
	if (t.exists()){
		//System.out.println(t.getClassName());
		Type inf = new Type("eve.nativeaccess.Inflater");
		Object i = inf.newInstance("Z",new Object[]{Boolean.valueOf(noWrap)});
		Object iis = t.newInstance("Ljava/io/InputStream;Leve/nativeaccess/Inflater;",new Object[]{byteSource,i});
		if (iis != null) return (InputStream)iis;
	}
	return null;
}
public static OutputStream getDeflaterOutputStream(OutputStream byteDest)
{
	Object ret = null;
	if (ret == null) ret = tryType("java.util.zip.DeflaterOutputStream","Ljava/io/OutputStream;",byteDest);
	if (ret == null) ret = tryType("eve.nativeaccess.DeflaterOutputStream","Ljava/io/OutputStream;",byteDest);
	return (OutputStream)ret;
}
*/
private static ByteArray converted;

private synchronized static int inflate2(Inflater inflater, byte[] src, int offset, int length, Object destination) throws StreamCorruptedException
{
	if (converted == null) converted = new ByteArray();
	converted.clear();
	ByteArray dest = converted;
	if (destination instanceof ByteArray){
		dest = (ByteArray)destination;
	}
	inflater.reset();
	inflater.setInput(src,offset,length);
	int total = 0;
	int buffLen = 10240;
	while(true){
		dest.ensureCapacity(dest.length+buffLen);
		int got = inflater.inflate(dest.data,dest.length,buffLen);
		if (got <= 0) break;
		dest.length += got;
		total += got;
	}
	if (destination instanceof ByteArray) return total;
	Utils.toInts(dest.data,0,dest.length,(IntArray)destination);
	return total/4;
}

private synchronized static int deflate2(Deflater deflater, Object src, int offset, int length, ByteArray destination)
{
	if (converted == null) converted = new ByteArray();
	byte[] sb = null;
	if (src instanceof int[]){
		int[] all = (int[])src;
		converted.clear();
		Utils.toBytes(all,offset,length,converted);
		sb = converted.data;
		offset = 0; 
		length = converted.length;
	}else
		sb = (byte[])src;
	//
	deflater.reset();
	if (length != 0) deflater.setInput(sb,offset,length);
	deflater.finish();
	//
	int total = 0;
	int buffLen = 10240;
	while(true){
		destination.ensureCapacity(destination.length+buffLen);
		int got = deflater.deflate(destination.data,destination.length,buffLen);
		if (got <= 0) break;
		destination.length += got;
		total += got;
	}
	return total;
}
/**
 * Using the most efficient method possible, compress using deflation a single block
 * of bytes producing a single block of bytes which are appended to a destination
 * ByteArray. Dictionaries cannot be used with this method.
 * @param src the source of the bytes to compress.
 * @param offset the start of the bytes to compress.
 * @param length the number of bytes to compress.
 * @param destination an destination ByteArray which must not be null.
 * @return the number of bytes created during the compression. 
 */
public static int deflate( byte[] src, int offset, int length, ByteArray destination)
throws IOException
{
	return deflate2(new Deflater(),src,offset,length,destination);
}
/**
 * Using the most efficient method possible, compress using deflation a single block
 * of bytes producing a single block of bytes which are appended to a destination
 * ByteArray. 
 * @param def a non-null Deflater to use for deflation.
 * @param src the source of the bytes to compress.
 * @param offset the start of the bytes to compress.
 * @param length the number of bytes to compress.
 * @param destination an destination ByteArray which must not be null.
 * @return the number of bytes created during the compression. 
 */
public static int deflate(Deflater def, byte[] src, int offset, int length, ByteArray destination)
throws IOException
{
	if (def == null || src == null || destination ==  null) throw new NullPointerException();
	if (offset < 0 || offset+length > src.length || length < 0)
		throw new ArrayIndexOutOfBoundsException();
	return deflate2(def,src,offset,length,destination);
}
/**
 * Using the most efficient method possible, compress using deflation a single block
 * of ints producing a single block of bytes which are appended to a destination
 * ByteArray. 
 * @param def a non-null Deflater to use for deflation.
 * @param src the source of the ints to compress.
 * @param offset the start of the ints to compress.
 * @param length the number of ints to compress.
 * @param destination an destination ByteArray which must not be null.
 * @return the number of bytes created during the compression. 
 */
public static int deflate(Deflater def, int[] src, int offset, int length, ByteArray destination)
throws IOException
{
	if (def == null || src == null || destination ==  null) throw new NullPointerException();
	if (offset < 0 || offset+length > src.length || length < 0)
		throw new ArrayIndexOutOfBoundsException();
	return deflate2(def,src,offset,length,destination);
}
/**
 * Using the most efficient method possible, decompress using inflate a single block
 * of bytes producing a single block of bytes which are appended to a destination
 * ByteArray. Dictionaries cannot be used with this method.
 * @param src the source of the bytes to decompress.
 * @param offset the start of the bytes to decompress.
 * @param length the number of bytes to decompress.
 * @param destination an destination ByteArray which must not be null.
 * @return the number of bytes created during the decompression. 
 */
public static int inflate( byte[] src, int offset, int length, ByteArray destination)
throws IOException
{
	return inflate2(new Inflater(),src,offset,length,destination);
}
/**
 * Using the most efficient method possible, decompress using inflation a single block
 * of bytes producing a single block of bytes which are appended to a destination
 * ByteArray. 
 * @param def a non-null Inflater to use for inflation.
 * @param src the source of the bytes to decompress.
 * @param offset the start of the bytes to decompress.
 * @param length the number of bytes to decompress.
 * @param destination an destination ByteArray which must not be null.
 * @return the number of bytes created during the decompression. 
 */
public static int inflate(Inflater inf, byte[] src, int offset, int length, ByteArray destination)
throws IOException
{
	if (inf == null || src == null || destination ==  null) throw new NullPointerException();
	if (offset < 0 || offset+length > src.length || length < 0)
		throw new ArrayIndexOutOfBoundsException();
	return inflate2(inf,src,offset,length,destination);
}
/**
 * Using the most efficient method possible, decompress using inflation a single block
 * of bytes producing a single block of ints which are appended to a destination
 * IntArray. 
 * @param def a non-null inflater to use for inflation.
 * @param src the source of the bytes to decompress.
 * @param offset the start of the bytes to decompress.
 * @param length the number of bytes to decompress.
 * @param destination an destination IntArray which must not be null.
 * @return the number of <b>ints</b> created during the compression. 
 */
public static int inflate(Inflater inf, byte[] src, int offset, int length, IntArray destination)
throws IOException
{
	if (inf == null || src == null || destination ==  null) throw new NullPointerException();
	if (offset < 0 || offset+length > src.length || length < 0)
		throw new ArrayIndexOutOfBoundsException();
	return inflate2(inf,src,offset,length,destination);
}
/**
 * Convert a file length to K or M notation.
 * @param len the length to convert.
 * @return a String representing the file length in K or M notation.
 */
//===================================================================
public static String fileLengthDisplay(long len)
//===================================================================
{
	String add = "";
	if (len > 9999) {
		len/=1024;
		add = "K";
	}
	if (len > 9999) {
		len/=1024;
		add = "M";
	}
	if (add.length() == 0) return Convert.toString(len);
	return len+add;
}
/**
 * Given a configuration name, determine the file that
 * it would be stored in if saveConfigInfo() was used with the SAVE_IN_FILE_xxx option.
 * @param name the name of the configuration.
 * @return the file that would be assigned to the configuration.
 */
public static File getConfigFile(String keyName)
//-------------------------------------------------------------------
{
	return getConfigFile(keyName,false,null);
}
/**
 * Given a configuration name, find and optionally reset the file name that
 * it would be stored in if saveConfigInfo() was used with the SAVE_IN_FILE_xxx option.
 * The name is determined from the HOME environment variable, and if that is
 * not present, then the Program Directory is used.
 * 
 * @param name the name of the configuration.
 * @param resetConfig if this is true then the old config file name is ignored
 * (the one stored in the registry) and a new one is generated and saved.
 * @return the file that would be assigned to the configuration.
 */
public static File getConfigFile(String keyName,boolean resetConfig)
//-------------------------------------------------------------------
{
	return getConfigFile(keyName,resetConfig,null);
}
/**
 * Given a configuration name, find and optionally reset the file name that
 * it would be stored in if saveConfigInfo() was used with the SAVE_IN_FILE_xxx option.
 * The name is determined from the HOME environment variable, and if that is
 * not present, then the Program Directory is used.
 * 
 * @param name the name of the configuration.
 * @param resetConfig if this is true then the old config file name is ignored
 * (the one stored in the registry) and a new one is generated and saved.
 * @param the user home directory name (which will be used in Unix/Linux platforms)
 * or null to let the system determine that if necessary using 
 * Registry.getUserHomeDirectory().
 * @return the file that would be assigned to the configuration.
 */
public static File getConfigFile(String keyName,boolean resetConfig,String userHomeDirectory)
//-------------------------------------------------------------------
{
	String fullKey = "HKEY_LOCAL_MACHINE\\SOFTWARE\\"+keyName;
	if (!resetConfig){
		String where = Registry.readRegistryString(fullKey,"File");
		if (where != null) return File.getNewFile(where);
	}
	int idx = keyName.lastIndexOf('\\');
	String got = (idx == -1 ? keyName : keyName.substring(idx+1))+".cfg";
	got = "."+got;
	String home = userHomeDirectory;
	if (home == null) Registry.getUserHomeDirectory();
	if (home == null) home = File.getProgramDirectory();
	//System.out.println("Home: "+home+" for: "+Registry.getUserName());
	//String home = Vm.getEnvOrProperty("HOME",File.getProgramDirectory());
	File ret = File.getNewFile(home).getChild(got);
	if (!ret.exists()){
		File nf = File.getNewFile(home).getChild(".eve-config");
		if (!nf.isDirectory()) nf.mkdirs();
		if (nf.isDirectory()){
			got = keyName.replace('\\','-')+".cfg";
			ret = nf.getChild(got);
		}
	}
	Registry.writeRegistryString(fullKey,"File",ret.getAbsolutePath());
	return ret;
}
public static String getConfigInfo(String name) throws IOException
{
	return getConfigInfo(name,null);
}
public static String getConfigInfo(String name,String userHomeDirectory) throws IOException
{
	File configFile = null;
	IRegistryKey ik = Vm.getRegistryKey(true,"HKEY_LOCAL_MACHINE\\SOFTWARE\\"+name,false,false);
	if (ik != null){
		Object got = ik.getValue("File");
		if (got instanceof String)
			configFile = Vm.newFileObject().getNew((String)got);
		else{
			got = ik.getValue(null);
			if (got instanceof String) return (String)got;
		}
	}
	//
	if (configFile != null && !configFile.getParentFile().isDirectory())
		configFile = null;
	//
	if (configFile == null) configFile = getConfigFile(name,true,userHomeDirectory);
	if (!configFile.exists()) return null;
	BufferedReader br = new BufferedReader(new InputStreamReader(configFile.toReadableStream()));
	String ret = br.readLine();
	br.close();
	return ret;
}

public static void saveConfigInfo(String data, String name, int options) throws IOException
{
	saveConfigInfo(data, name, options, null);
}

public static void saveRemoteConfigInfo(String data, String name,String destinationDirectory) throws IOException
{
	String originalName = name;
	File root = Rapi.getRapiRootFile();
	if (root == null) throw new IOException("Cannot write to device.");
	File d = root.getNew("\\My Documents");
	if (!d.isDirectory()) d = root.getNew(destinationDirectory);
	d = d.getChild(".eve-config");
	if (!d.mkdirs()) throw new IOException("Cannot write to device.");
	name = name.replace('\\','-');
	File t = d.getChild(name+".tmp");
	PrintWriter pw = new PrintWriter(t.toWritableStream(false));
	pw.println(data);
	pw.close();
	d = d.getChild(name+".cfg");
	d.delete();
	if (!t.move(d)) throw new IOException("Cannot write to device.");
	IRegistryKey k = Rapi.getRemoteRegistry();
	if (k == null) return;
	k = k.getSubKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\"+originalName);
	if (!k.createKey(true)) return;
	k.setValue("File", d.getAbsolutePath());
}

public static void saveConfigInfo(String data, String name, int options,String userHomeDirectory) throws IOException
{
	boolean toRegistry = ((options == SAVE_IN_REGISTRY) || 
			((options == SAVE_IN_FILE_OR_REGISTRY) && (data.length() < 256)));
	String saveFile = null;
	File configFile = null;
	IRegistryKey ik = null; 
	ik = Vm.getRegistryKey(true,"HKEY_LOCAL_MACHINE\\SOFTWARE\\"+name,true,true);
	/*
	if (ik != null) ik.delete();
	ik = Vm.getRegistryKey(true,"HKEY_LOCAL_MACHINE\\SOFTWARE\\"+name,true,true);
	*/
	if (ik == null) toRegistry = false;
	else {
		Object obj = ik.getValue("File"); 
		if (obj instanceof String){
			saveFile = (String)obj;
		}else if (toRegistry){
			if (ik.setValue(null,data)) return;
		}
	}
	if (saveFile == null){
		configFile = getConfigFile(name,true,userHomeDirectory);
	}else{
		configFile =  Vm.newFileObject().getNew(saveFile);
	}
	if (!configFile.getParentFile().isDirectory())
		configFile = getConfigFile(name,true,userHomeDirectory);
	SafeFile sf = new SafeFile(configFile);
	File out = sf.getTempFile();
	PrintWriter pw = new PrintWriter(out.toWritableStream(false));
	pw.println(data);
	pw.close();
	sf.setNewFile(out);
	
	if (ik != null){
		String put = sf.getFile().getFullPath();
		ik.setValue("File",put);
		//String got = (String)ik.getValue("File");
		//Device.messageBox("Did",put+"\n\n"+got,Device.MB_TYPE_OK);
	}
}
/**
* Option for saveConfigInfo().
**/
public static final int SAVE_IN_REGISTRY = 0x1;
/**
* Option for saveConfigInfo().
**/
public static final int SAVE_IN_FILE = 0x2;
/**
* Option for saveConfigInfo().
**/
public static final int SAVE_IN_FILE_OR_REGISTRY = 0;


/**
 * Save a Vector containing a list of strings using saveConfigInfo. The strings will be separated using
 * a '\n' separator.
 * @param text The list of strings to save.
 * @param keyName The key name to use. This will be passed to saveConfigInfo().
 * @param saveOptions one of the SAVE_IN options.
 * @exception IOException If there was an error saving the information.
 */
//===================================================================
public static void saveStringList(Vector text,String keyName,int saveOptions) throws IOException
//===================================================================
{
	String s = "";
	if (text != null)
		for (int i = 0; i<text.size(); i++){
			if (i != 0) s += '\n';
			s += mString.toString(text.get(i));
		}
	saveConfigInfo(s,keyName,saveOptions);
}
/**
 * Read a Vector containing a list of string using getConfigInfo.
 * @param keyName The name of the key to save under.
 * @return null if the data is not present, else a Vector of strings.
 * @exception IOException If there was an error reading the information.
 */
//===================================================================
public static Vector getStringList(String keyName) throws IOException
//===================================================================
{
	String got = getConfigInfo(keyName);
	if (got == null) return null;
	return new mVector(mString.split(got,'\n'));
}
/**
 * Get a BufferedReader using an EncodedStreamReader with a specific codec that
 * reads from an InputStream from the specified file.
 * @param f the file to read.
 * @param codec the codec to use.
 * @return a BufferedReader.
 * @throws IOException on an error opening the file.
 */
public static BufferedReader getBufferedReader(File f, TextCodec codec) throws IOException
{
	return new BufferedReader(new EncodedStreamReader(f.toReadableStream(),codec));
}

public static BufferedReader getBufferedReader(File f) throws IOException
{
	return new BufferedReader(new InputStreamReader(f.toReadableStream()));
}
public static PrintWriter getPrintWriter(File f, boolean append) throws IOException
{
	return new PrintWriter(f.toWritableStream(append));
}
public static PrintWriter getPrintWriter(File f) throws IOException
{
	return getPrintWriter(f,false);
}

public static OutputStream newFileOutputStream(String name, boolean append)
throws IOException
{
	File f = File.getNewFile(name);
	return f.toWritableStream(append);
}
public static InputStream newFileInputStream(String name)
throws IOException
{
	File f = File.getNewFile(name);
	return f.toReadableStream();
}
public static RandomStream newFileRandomStream(String name,String mode)
throws IOException
{
	File f = File.getNewFile(name);
	return f.toRandomStream(mode);
	
}
/*
*/
}
//####################################################
