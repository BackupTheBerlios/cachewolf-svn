/*
 * Created on Apr 2, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import eve.util.CharArray;

/**
 * A TextReader works very similarly to an InputStreamReader except that you
 * can provide a TextCodec object directly to it for decoding byte encoded text.
 * <p>
 * Additionally, TextReader also acts as a BufferedReader, buffering input data and
 * providing a readLine() method. However it provides additional effeciency in that
 * the readLine() method can output to an eve.util.CharArray allowing you to re-use
 * memory instead of having to create a new String for each call to readLine().
 * <p>
 * @author Michael L Brereton
 *
 */
//####################################################
/**
 * @author Michael L Brereton
 *
 */
public class TextReader extends Reader {
private InputStream input;
private byte[] buffer;
private CharArray readIn = new CharArray();
private int out;
private TextCodec decoder;
private String codecName;
private boolean inputAtEOF;
private CharArray lineBuffer; 
private static final int DefaultBufferSize = 10240;
	/**
	 * Create a TextReader which decodes characters from an InputStream.
	 * You can provide a codec or you can use one of the eve.io.Io.getCodec() methods
	 * to get a codec by name.
	 * @param in The InputStream to read from. 
	 * @param bufferSize the size of the internal buffer to use when reading bytes.
	 * @param codec the TextCodec to use for converting bytes into characters.
	 */
	public TextReader(InputStream in, int bufferSize, TextCodec codec) {
		if (codec == null) try{
			codec = Io.getCodec(Io.getDefaultCodecName(),false);
		}catch(UnsupportedEncodingException e){
			decoder = new AsciiCodec();
		}
		decoder = codec;
		input = in;
		if (bufferSize < 1) bufferSize = DefaultBufferSize;
		buffer = new byte[bufferSize];
	}

	/**
	 * Create a TextReader which decodes characters from an InputStream
	 * using the default codec and default buffer size.
	 * @param in The InputStream to read from. 
	 */
	public TextReader(InputStream in) {
		this(in,DefaultBufferSize,null);
	}
	/**
	 * Create a TextReader which decodes characters from an InputStream
	 * using the default codec.
	 * @param in The InputStream to read from. 
	 * @param bufferSize the size of the buffer to use.
	 */
	public TextReader(InputStream in, int bufferSize) {
		this(in,bufferSize,null);
	}
	/**
	 * Create a TextReader which decodes characters from an InputStream
	 * using the default buffer size.
	 * You can provide a codec or you can use one of the eve.io.Io.getCodec() methods
	 * to get a codec by name.
	 * @param in The InputStream to read from. 
	 * @param codec the TextCodec to use for converting bytes into characters.
	 */
	public TextReader(InputStream in, TextCodec codec) {
		this(in,DefaultBufferSize,codec);
	}

	private boolean readMoreIfNeed() throws IOException
	{
		//
		// Make sure there are characters available.
		//
		while (readIn.length-out == 0){
			if (inputAtEOF) return false;
			int got = input.read(buffer);
			readIn.clear();
			out = 0;
			if (got == -1) {
				inputAtEOF = true;
				decoder.decodeText(null,0,0,true,readIn);
				if (readIn.length == 0) return false;
				else return true;
			}
			decoder.decodeText(buffer,0,got,false,readIn);
		}
		return true;
	}
	public int read(char[] buf, int offset, int count) throws IOException 
	{
		if (!readMoreIfNeed()) return -1;
		//
		// Read out what you can.
		//
		int takeOut = readIn.length-out;
		if (takeOut > count) takeOut = count;
		System.arraycopy(readIn.data,out,buf,offset,takeOut);
		out += takeOut;
		return takeOut;
	}

	public int read() throws IOException
	{
		if (!readMoreIfNeed()) return -1;
		return (int)readIn.data[out++] & 0xffff;
	}
	
	public void close() throws IOException {
		input.close();
	}

	private static boolean hasNative = true;
	private static native int nativeLocateEOL(char[] ch,int offset,int length);
	
	private static int locateEOL(char[] ch,int offset,int length)
	{
		if (hasNative) try{
			return nativeLocateEOL(ch,offset,length);
		}catch(UnsatisfiedLinkError e){
			hasNative = false;
		}catch(SecurityException se){
			hasNative = false;
		}
		for (int i = 0; i<length; i++){
			char c = ch[offset];
			if (c == '\r' || c == '\n') return offset;
			offset++;
		}
		return -1;
	}
	/**
	 * Read a full line of text from the input and append it to the destination CharArray.
	 * 
	 * @param destination a destination CharArray to write the characters to.
	 * @return The number of characters in the line, not including the line-termination character, or -1
	 * if the end of the Stream has been reached.
	 * @throws IOException if an IO or text decoding error occurs.
	 */
	public int readLine(CharArray destination) throws IOException
	{
		int got = 0;
		while(true){
			int left = readIn.length - out; 
			if (left > 0){
				int end = locateEOL(readIn.data,out,left);
				int takeOut = (end == -1) ? left : end-out;
				destination.append(readIn.data,out,takeOut);
				out += takeOut; //out is equal to end now.
				got += takeOut;
				if (end == -1) continue;
				else {
					// I found EOL, skip past it.
					out++; // out should be end+1.
					if (readIn.data[end] == '\n') break;
					// It was a '\r' so see if the next one is '\n'
					// and skip past that too if it is.
					if (out >= readIn.length)
							if (!readMoreIfNeed()) break;
					if (readIn.data[out] == '\n') out++;
					break;
				}
			}else{
				if (!readMoreIfNeed()){
					return got == 0 ? -1 : got;
				}
			}
		}
		return got;
	}
	/**
	 * Read a full line of text from the input and append it to the destination CharArray.
	 * @return the line of text without any line-termination characters, or null
	 * if the end of the stream has been reached.
	 * @throws IOException if an IO or text decoding error occurs.
	 */
	public String readLine() throws IOException
	{
		if (lineBuffer == null) lineBuffer = new CharArray();
		if (readLine(lineBuffer.clear()) == -1) return null;
		return new String(lineBuffer.data,0,lineBuffer.length);
	}
}

//####################################################
