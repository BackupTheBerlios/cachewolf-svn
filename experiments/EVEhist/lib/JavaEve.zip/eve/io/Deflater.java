
package eve.io;

/** 
 * This is the Deflater class.  The deflater class compresses input
 * with the deflate algorithm described in RFC 1951.  It has several
 * compression levels and three different strategies described below.
 *
 * This class is <i>not</i> thread safe.  This is inherent in the API, due
 * to the split of deflate and setInput.
 *
 * @author Jochen Hoenicke
 * @date Jan 5, 2000 
 */
public class Deflater
{
	java.util.zip.Deflater deflater;
	//
	//	Don't move these 8, the first 6 must match Inflater.java
	//
	/*
	int nativeObject = 0;
	private int status = 1;
	private int remaining;
	private long totalRead;
	private long totalWritten;
	private int adler;
	//
	*/
	private int level;
	private int strategy;
  /**
   * The best and slowest compression level.  This tries to find very
   * long and distant string repetitions.  
   */
  public static final int BEST_COMPRESSION = 9;
  /**
   * The worst but fastest compression level.  
   */
  public static final int BEST_SPEED = 1;
  /**
   * The default compression level.
   */
  public static final int DEFAULT_COMPRESSION = -1;
  /**
   * This level won't compress at all but output uncompressed blocks.
   */
  public static final int NO_COMPRESSION = 0;

  /**
   * The default strategy.
   */
  public static final int DEFAULT_STRATEGY = 0;
  /**
   * This strategy will only allow longer string repetitions.  It is
   * useful for random data with a small character set.
   */
  public static final int FILTERED = 1;

  /** 
   * This strategy will not look for string repetitions at all.  It
   * only encodes with Huffman trees (which means, that more common
   * characters get a smaller encoding.  
   */
  public static final int HUFFMAN_ONLY = 2;

  /**
   * The compression method.  This is the only method supported so far.
   * There is no need to use this constant at all.
   */
  public static final int DEFLATED = 8;
 /**
 * This variable stores the nowrap flag that was given to the constructor.
 * True means, that the inflated stream doesn't contain a header nor the
 * checksum in the footer.
 */
private boolean nowrap;
 /**
  * Creates a new inflater.
  */
 public Deflater ()
 {
 	this(DEFAULT_COMPRESSION,false);
 }
 public Deflater (int level)
 {
 	this(level,false);
 }
 public Deflater(int level, boolean noWrap)
 {
    this.nowrap = noWrap;
    this.strategy = DEFAULT_STRATEGY;
	if ((level < 0 || level > 9) && (level != DEFAULT_COMPRESSION)) throw new IllegalArgumentException();
	this.level = level;
    reset();
 }
public void setLevel(int level)
{
	if ((level < 0 || level > 9) && (level != DEFAULT_COMPRESSION)) throw new IllegalArgumentException();
	this.level = level;
	setLevelAndStrategy(level,strategy);
}
public void setStrategy(int strategy)
{
	if ((strategy < 0 || strategy  > 2) && (strategy  != DEFAULT_STRATEGY)) throw new IllegalArgumentException();
	this.strategy = strategy;
	setLevelAndStrategy(level,strategy);
}

public void reset()
{
	reset(nowrap,level,strategy);
}

private void reset(boolean noWrap,int level,int strategy)
{
	deflater = new java.util.zip.Deflater(level,noWrap);
	deflater.setStrategy(strategy);
}
private void setLevelAndStrategy(int level,int strategy)
{
	deflater.setLevel(level);
	deflater.setStrategy(strategy);
}
public int deflate(byte[] b, int off, int len)
{
	return deflater.deflate(b,off,len);
}
public void setInput(byte[]b, int off, int len)
{
	deflater.setInput(b,off,len);
}
public void setDictionary(byte[]b, int off, int len)
{
	deflater.setDictionary(b,off,len);
}
public void end()
{
	deflater.end();
}
public void finish()
{
	deflater.finish();
}

public void setInput(byte[]b)
{
	setInput(b,0,b.length);
}
public void setDictionary(byte[]b)
{
	setDictionary(b,0,b.length);
}
public int deflate(byte[] b)
{
	return deflate(b,0,b.length);
}
public boolean finished()
{
	return deflater.finished();
}
public boolean needsInput()
{
	return deflater.needsInput();
}
/*
public boolean needsDictionary()
{
	return deflater.needsI
	return status == 3;
}
public int getRemaining()
{
	return deflater.;
}
*/
public long getBytesRead()
{
	return deflater.getTotalIn();
}
public long getBytesWritten()
{
	return deflater.getTotalOut();
}
public int getTotalIn()
{
	return deflater.getTotalIn();
}
public int getTotalOut()
{
	return deflater.getTotalOut();
}
public int getAdler()
{
	return deflater.getAdler();
}

}
