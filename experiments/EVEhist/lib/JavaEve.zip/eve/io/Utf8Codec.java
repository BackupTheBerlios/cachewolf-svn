/*
 * Created on Apr 2, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

/**
 * This Codec is used to translate between 16-bit Unicode Characters (Java "char" data)
 * and 8-bit bytes using the Standard UTF-8 method, with the restriction that unicode
 * characters will only be in the range 0x0000 and 0xffff.
 * <p>
 * This is different to Java UTF-8 in that in Standard UTF-8 the null character 0x0000 is converted to a
 * zero byte value, where as in Java UTF-8 the zero byte value is converted into the 
 * two byte sequence 0xC0 0x80.
 * <p>
 * @author Michael L Brereton
 *
 */
//####################################################
public class Utf8Codec extends JavaUtf8Codec {

	public Utf8Codec(int options) {
		super(options | USE_STANDARD_UTF8);
	}

	public Utf8Codec() {
		super(USE_STANDARD_UTF8);
	}

	public Object getCopy() {return new Utf8Codec(flags);}
}
//####################################################
