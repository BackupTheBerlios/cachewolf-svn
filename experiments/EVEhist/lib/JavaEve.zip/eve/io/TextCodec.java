package eve.io;
import java.io.IOException;
import eve.util.Copyable;
import eve.util.ByteArray;
import eve.util.CharArray;
/**
* This class is used by the InputStreamReader and OutputStreamWriter classes to convert Unicode text (Strings)
* into bytes, <b>encodeText()</b>, and to convert encoded bytes into Unicode text, <b>decodeText()</b>.
**/
//##################################################################
public interface TextCodec extends Copyable{
//##################################################################
/**
 * Reset the codec for both input and output.
 */
public void reset();
/**
 * Enocde the Unicode characters into a byte Stream.
* @param text The characters to encode. This can be null if length is zero and endOfData is true. You
would use those settings to tell the codec that no more characters are to be encoded and
the final set of output bytes (if any) should be output.
* @param start The start of the characters in the text array.
* @param length The number of characters to encode.
* @param endOfData If this is true this tells the codec that no more characters are to be
* encoded and the final set of output bytes (if any) should be output.
* @param destination A ByteArray to hold the output data. The output data is <b>appended</b> to the data member and
* and the length member holds how many bytes were output.
* @return The destination ByteArray or a new one if the destination was null.
* @exception IOException if an error occurs during encoding.
*/
public ByteArray encodeText(char[] text, int start, int length, boolean endOfData, ByteArray destination) throws IOException;
/**
 * Decode the bytes into Unicode characters.
 * @param encodedText The encoded bytes. This can be null if length is zero and endOfData is true. You
would use those settings to tell the codec that no more characters are to be decoded and
the final set of decoded characters (if any) should be output.
* @param start The start of the bytes in the byte array.
* @param length The number of bytes to decode.
* @param endOfData If this is true this tells the codec that no more characters are to be decoded and
the final set of decoded characters (if any) should be output.
* @param destination A CharArray to hold the output data. The output data is <b>appended</b> to the data member and
* and the length member will be updated to indicate how many bytes were appended.
* @return The destination CharArray or a new one if the destination was null.
* @exception IOException if an error occurs during decoding, including badly formatted data.
 */
public CharArray decodeText(byte[] encodedText,  int start, int length, boolean endOfData, CharArray destination) throws IOException;
/**
* This aborts any on-going processing and frees resources associated with the codec. 
* The codec should not be used again after this. 
* An IOException should be thrown if there was an error closing the process.
**/
public void closeCodec() throws IOException;

/**
* This should return a new instance of the TextCodec, ready to begin converting a new set of
* data. The returned codec should be in a reset state.
**/
public Object getCopy();

//##################################################################
}
//##################################################################

