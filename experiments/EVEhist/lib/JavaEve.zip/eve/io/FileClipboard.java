package eve.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;

import eve.sys.Handle;
import eve.sys.Task;
import eve.sys.Vm;

//##################################################################
public class FileClipboard{
//##################################################################

public static interface FileClipboardSource {
	public static final int FILES_TAKEN = 1;
	public static final int FILES_REJECTED = 2;
	public boolean fileClipboardOperation(FileClipboard clip,int type);
	public static final int ERROR_COULD_NOT_CREATE_DESTINATION = 1;
	public static final int ERROR_COULD_NOT_READ_SOURCE = 2;
	public static final int ERROR_COULD_NOT_REMOVE_SOURCE = 3;
	public boolean continueAfterError(File f, Throwable error, int errorType, boolean hasMoreFiles);
}

public File sourceDir;
public String sourceFiles[];
public boolean isCut;
public FileClipboardSource source;

//===================================================================
public void set(File sourceDir,String sourceFiles [],boolean isCut,FileClipboardSource source)
//===================================================================
{
	clear();
	this.sourceDir = sourceDir;
	this.sourceFiles = sourceFiles;
	this.isCut = isCut;
	this.source = source;
}
/**
 * This will return true if the source file list contains directories.
 * @return
 */
public boolean hasDirectories()
{
	if (sourceDir == null) return false;
	if (sourceFiles == null) return false;
	File s = sourceDir.getNew("");
	for (int i = 0; i<sourceFiles.length; i++){
		s.set(sourceDir,sourceFiles[i]);
		if (s.isDirectory()) return true;
	}
	return false;
}
/**
 * See if the specified file is in the list.
 * @param parent the parent file.
 * @param file the named file.
 * @return true if it is in this list.
 */
//===================================================================
public boolean isInClipboard(File parent,String file)
//===================================================================
{
	if (parent == null) return false;
	if (sourceDir == null) return false;
	while(true){
		if (sourceDir.equals(parent))
			for (int i = 0; i<sourceFiles.length; i++)
				if (sourceFiles[i].equals(file)) return true;
		file = parent.getFileExt();
		parent = parent.getParentFile();
		if (parent == null) return false;
	}
}
/**
 * See if the specified file is in the list and is considered
 * "cut".
 * @param parent the parent file.
 * @param file the named file.
 * @return true if it is in this list and is considered cut.
 */
//===================================================================
public boolean isCut(File parent,String file)
//===================================================================
{
	return isCut && isInClipboard(parent,file);
}
/*
//===================================================================
public boolean isACutSubFolder(File who)
//===================================================================
{
	if (!isCut || sourceDir == null) return false;
	for (File f = who; f != null;){
		File p = f.getParentFile();
		if (sourceDir.equals(p)){
			String fe = f.getFileExt();
			for (int i = 0; i<sourceFiles.length; i++)
				if (sourceFiles[i].equals(fe))
					return true;
			return false;
		}
		f = p;
	}
	return false;
}
*/
//===================================================================
public boolean hasFiles()
//===================================================================
{
	return sourceDir != null && sourceFiles != null && sourceFiles.length != 0;
}
//===================================================================
public void taken() {clear(FileClipboardSource.FILES_TAKEN);}
//===================================================================
//===================================================================
public void clear() {clear(FileClipboardSource.FILES_REJECTED);}
//===================================================================
//-------------------------------------------------------------------
protected void clear(int message)
//-------------------------------------------------------------------
{
	FileClipboardSource s = source;
	if (isCut && sourceDir != null) sourceDir.refresh();
	boolean wasCut = isCut;
	source = null;
	sourceDir = null;
	sourceFiles = null;
	isCut = false;
	if (s != null && wasCut) 
		s.fileClipboardOperation(this,message);
}
//public static FileClipboard clipboard = new FileClipboard();

//===================================================================
public boolean canPasteInto(File folder)
//===================================================================
{
	if (!hasFiles()) return false;
	if (!folder.isDirectory()) return false;
	if (folder.equals(sourceDir)) return false;
	return !isInClipboard(folder.getParentFile(),folder.getFileExt());
	/*
	if (sourceDir == null || folder == null) return false;
	if (!isCut) return true;
	if (sourceDir.equals(folder)) return false;
	if (isACutSubFolder(folder)) return false;
	return true;
	*/
}

private boolean getChildren(Handle h,File one,String dirName,Vector dest)
{
	h.yield();
	dest.add(dirName);
	if (one == null) one = sourceDir.getChild(dirName);
	else one.set(sourceDir,dirName);
	if (!one.isDirectory()) return true;
	String[] all = one.list();
	if (all == null || all.length == 0) return true;
	for (int i = 0; !h.shouldStop && i<all.length; i++){
		String me = dirName+"/"+all[i];
		one.set(sourceDir,me);
		if (!getChildren(h,one,me,dest))
			return false;
	}
	return !h.shouldStop;
}
/**
 * This method prepares to do a Copy/Paste operation that
 * will run in a separate Thread, copying the source
 * files to the destination and deleting them from the source IF the
 * "isCut" field is true.<p>
 * The method returns an array of two Handles. The Handle at index 0 is
 * the main progress handle. <b>You must call start() on that Handle to
 * begin the operation.</b> You should then monitor the state of that Handle.
 * When the Stopped bit is set the operation is complete.<p>
 * The Handle at index 1 indicates the progress of each individual file
 * as they are copied.<p>
 * During the operation, if any error occurs the continueAfterError() method
 * is called on the FileClipboardSource Object set as the "source" field. If
 * that method returns true then the operation continues on the next file.
 * If that method returns false OR if the "source" field is null the operation
 * will fail with an IOException. 
 * @param dest the destination directory.
 * @param copyDirectoryChildren if this is true then the files in any
 * directories are also copied. If it is false only the directory are
 * created in the destination, but no child files are copied.
 * @return an array of two Handles as explained above.
 */
public Handle[] copyTo(File dest, boolean copyDirectoryChildren)
{
	if (dest == null) throw new NullPointerException();
	return copyDelete(dest,copyDirectoryChildren,false);
}

/**
 * This method prepares to do a delete operation that
 * will run in a separate Thread, deleting the source
 * files.<p>
 * The method returns a Handle.
 * <b>You must call start() on that Handle to
 * begin the operation.</b> You should then monitor the state of that Handle.
 * When the Stopped bit is set the operation is complete.<p>
 * During the operation, if any error occurs the continueAfterError() method
 * is called on the FileClipboardSource Object set as the "source" field. If
 * that method returns true then the operation continues on the next file.
 * If that method returns false OR if the "source" field is null the operation
 * will fail with an IOException. 
 * @param deleteDirectoryChildren if this is true then the files in any
 * directories are also delete. If it is false then the directories will
 * be deleted if they are empty only.
 * @return an Handle as explained above.
 */
public Handle delete(boolean deleteDirectoryChildren)
{
	return copyDelete(null,deleteDirectoryChildren,true)[0];
}

private Handle[] copyDelete(final File dest,final boolean doDirectoryChildren,final boolean isDelete)
{
	final Handle fileHandle = new Handle();
	Task t = new Task(){
		protected boolean continueAfterError(File f, int error, Exception cause,boolean hasMore)
		{
			if (source != null && source.continueAfterError(f,cause,error,hasMore)) 
				return true;
			String err = "Could not read source.";
			if (error == FileClipboardSource.ERROR_COULD_NOT_CREATE_DESTINATION)
				err = "Could not write to destination.";
			else if (error == FileClipboardSource.ERROR_COULD_NOT_REMOVE_SOURCE)
				err = "Could not remove source.";
			IOException e = new IOException(err);
			if (cause != null) Vm.setCause(e,cause);
			fail(e);
			return false;
		}
		protected void doRun(){
			int waitTime = 100;
			try{
				File from = sourceDir.getNew("");
				File to = isDelete ? null : dest.getNew("");
				if (!isDelete){
					if (dest.equals(sourceDir)) fail(new IOException("Destination is the same as source."));
					if (!dest.isDirectory()) fail(new IOException("Destination is not a directory."));
				}
				String[] sf = sourceFiles;
				if (doDirectoryChildren){
					startDoing("Getting file list...");
					Vector dest = new Vector();
					for (int i = 0; i<sourceFiles.length; i++){
						if (!getChildren(this,from,sourceFiles[i],dest)){
							setFlags(Aborted,Running);
							return;
						}
					}
					sf = new String[dest.size()];
					dest.copyInto(sf);
				}
				if (isDelete) startDoing("Deleting files...");
				else startDoing(isCut ? "Moving Files..." : "Copying Files...");
				for (int i = 0; !shouldStop && i<sf.length; i++){
					boolean hasMore = i<sf.length-1;
					String nm = sf[i];
					from.set(sourceDir,nm);
					try{
						OutputStream out = null;
						InputStream in = null;
						try{
							if (!isDelete){
								to.set(dest,nm);
								if (from.isDirectory()){
									if (!to.mkdirs())
										throw new IOException("Can't create directory: "+to);
									continue;
								}else{
									try{
										out = to.toWritableStream(false);
									}catch(Exception e){
										if (!continueAfterError(sourceDir.getChild(nm),FileClipboardSource.ERROR_COULD_NOT_CREATE_DESTINATION,e,true))
											return;
										else
											continue;
									}
									try{
										in = from.toReadableStream();
									}catch(Exception e){
										try{out.close();}catch(Exception e2){}
										to.delete();
										if (!continueAfterError(sourceDir.getChild(nm),FileClipboardSource.ERROR_COULD_NOT_READ_SOURCE,e,true))
											return;
										else
											continue;
									}
									fileHandle.startDoing(nm);
									StreamUtils.transfer(fileHandle,in,out,from.getLength(),StreamUtils.CLOSE_INPUT|StreamUtils.CLOSE_OUTPUT);
									out = null;
									in = null;
								}
							}else
								if (from.isDirectory()) continue;
							if ((isDelete || isCut) && !from.delete()){
								if (!continueAfterError(sourceDir.getChild(nm),FileClipboardSource.ERROR_COULD_NOT_REMOVE_SOURCE,new IOException("Could not delete file."),true))
									return;
							}
						}finally{
							if (out != null) out.close();
						}
					}catch(IOException e){
						if (!continueAfterError(sourceDir.getChild(nm),FileClipboardSource.ERROR_COULD_NOT_READ_SOURCE,e,true)) {
							fail(e);
							return;
						}
					}
					if(shouldStop){
						setFlags(Aborted,Running);
						return;
					}
					int c = setProgress((float)(i+1)/sf.length);
					waitTime = checkChangeAccepted(c,waitTime);
				}
				if (isCut||isDelete){
					doing = "Removing folders...";
					changed();
					for (int i = sf.length-1; i >= 0; i--){
						boolean hasMore = i != 0;
						String nm = sf[i];
						from.set(sourceDir,nm);
						if (from.isDirectory()){
							if (!from.delete()){
								if (!continueAfterError(sourceDir.getChild(nm),FileClipboardSource.ERROR_COULD_NOT_REMOVE_SOURCE,new IOException("Could not delete file."),true))
									return;
							}
						}
					}
				}
				succeed(null);
			}finally{
				fileHandle.stop(0);
				fileHandle.set(Stopped);
			}
		}
	};
	Handle [] both = new Handle[]{t,fileHandle};
	return both;
}
//##################################################################
}
//##################################################################

