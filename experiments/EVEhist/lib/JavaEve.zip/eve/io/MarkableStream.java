package eve.io;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

import eve.util.ByteArray;

//##################################################################
public class MarkableStream extends FilterInputStream{
//##################################################################

private byte [] buffered = null;
private byte[] one;
private ByteArray saving = null;
private byte[] skipBuffer;
private int leftInBuffered = 0, readFromBuffered = 0;

public synchronized int read() throws IOException
{
	if (one == null) one = new byte[1];
	if (read(one,0,1) == -1) return -1;
	return (int)one[0] & 0xff;
}
private int didRead(byte[] dest, int offset, int did)
{
	if (did <= 0 || saving == null) return did;
	saving.append(dest,offset,did);
	return did;
}
public synchronized int read(byte[] dest, int offset, int count) throws IOException
{
	if (leftInBuffered != 0){
		if (count > leftInBuffered) count = leftInBuffered;
		System.arraycopy(buffered,readFromBuffered,dest,offset,count);
		leftInBuffered -= count;
		readFromBuffered += count;
		if (leftInBuffered == 0) buffered = null;
		return didRead(dest,offset,count);
	}
	int ret = in.read(dest,offset,count);
	return didRead(dest,offset,ret);
}
public boolean markSupported()
{
	return true;
}
public synchronized void mark(int readLimit)
{
	saving = new ByteArray();
	saving.ensureCapacity(readLimit);
}
public synchronized void reset() throws IOException
{
	if (saving == null) return;
	if (leftInBuffered != 0)
		saving.append(buffered,readFromBuffered,leftInBuffered);
	buffered = saving.data; 
	leftInBuffered = saving.length;
	readFromBuffered = 0;
	if (leftInBuffered == 0) buffered = null;
	saving = null;
}
public MarkableStream(InputStream input)
{
	super(input);
}
public static InputStream toMarkableStream(InputStream input)
{
	if (input.markSupported()) return input;
	return new MarkableStream(input);
}
/*
public synchronized int read2(byte[] buffer, int start, int length) throws IOException
{
	if (ras != null) return ras.read(buffer,start,length);
	if (rewound){
		if (curPos >= inBuffer){
			//System.out.println("Reading directly: "+length);
			int readIn = stream.read(buffer,start,length);
			if (readIn <= 0) return readIn;
			curPos += readIn;
			return readIn;
		}
	}
	if (curPos < inBuffer){
		int buffered = (int)(inBuffer-curPos);
		if (buffered < length) length = buffered;
		System.arraycopy(saved,(int)curPos,buffer,start,length);
		curPos += length;
		//System.out.println("Reading from buffer: "+length);
		return length;
	}
	int readIn = stream.read(buffer,start,length);
	//System.out.println("Reading and saving: "+length);
	if (readIn <= 0) return readIn;
	if (!rewound){
		if (curPos+readIn > (long)saved.length){
			int extra = (int)(curPos+readIn-saved.length);
			if (extra < 1024) extra = 1024;
			byte [] nb = new byte[saved.length+extra];
			System.arraycopy(saved,0,nb,0,inBuffer);
			saved = nb;
		}
		System.arraycopy(buffer,start,saved,inBuffer,readIn);
		inBuffer += readIn;
	}
	curPos += readIn;
	return readIn;
}
*/
/*
long curPos;
boolean rewound;
int inBuffer;
byte [] saved = new byte[0];

InputStream stream;
RandomStream ras;
*/
/**
 * Return a Stream that can act as at least a limited RandomStream by being
 * able to rewind after reading a number of bytes. If the provided stream is
 * a true RandomStream then it will be returned - otherwise a RewindableStream
 * will be created and returned.
 * @param stream the InputStream to be made rewindable.
 * @return a Stream that can be rewinded.
 */
/*
//===================================================================
public static RandomStream toRewindableStream(InputStream stream)
//===================================================================
{
	if (!(stream instanceof MarkableStream) && (stream instanceof RandomStream)) return (RandomStream)stream;
	else return new MarkableStream(stream);
}
*/
/**
 * Rewind a Stream created by toRewindableStream(). From that point you will
 * be reading from the start of the stream again.
 * @param stream the RandomStream returned by toRewindableStream().
 * @throws IOException if an IO error occurs. 
 */
/*
//===================================================================
public static void rewind(RandomStream stream) throws IOException
//===================================================================
{
	if (stream instanceof MarkableStream) ((MarkableStream)stream).rewind();
	else stream.setPosition(0);
}

//===================================================================
private MarkableStream(InputStream stream)
//===================================================================
{
	super("r");
	this.stream = stream;
	if (!(stream instanceof MarkableStream) && (stream instanceof RandomStream)) 
		ras = (RandomStream)stream;
}

//-------------------------------------------------------------------
private void throwAccessError() throws IOException
//-------------------------------------------------------------------
{
	throw new IOException("Access out of rewind range.");	
}
*/

public synchronized long skip(long num) throws IOException
{
	if (skipBuffer == null) skipBuffer = new byte[1024*10];
	long did = 0;
	while(num > 0){
		long toDo = num;
		if (toDo > skipBuffer.length) toDo = skipBuffer.length;
		int r = read(skipBuffer,0,(int)toDo);
		if (r < 0) return did;
		did += r;
		num -= r;
	}
	return did;
}

//##################################################################
}
//##################################################################

