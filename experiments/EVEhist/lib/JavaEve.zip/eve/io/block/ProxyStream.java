package eve.io.block;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import eve.util.ByteArray;
/**
 * This class is used to implement streams across a remote connection - you
 * should not use it directly.
 */
public class ProxyStream implements IDataStream{

	ByteArray buffer = new ByteArray();
	boolean atEOF = false;
	boolean closed = false;
	IOException error;
	int needToRead = 0;
	String myName;
	IDataStream remote;
	byte[] single = new byte[1];
	InputStream localInput;
	OutputStream localOutput;
	boolean ready = true;
	RemoteCallTask task;
	private boolean haveThread = false;
	
	private synchronized IDataStream getRemote(String name)
	{
		if (remote == null && name != null) 
			remote = (IDataStream)task.createProxy(IDataStream.class, name);
		return remote;
	}
	ProxyStream(RemoteCallTask task,String remoteName, String myName) {
		this.myName = myName;
		this.task = task;
		getRemote(remoteName);
	}

	ProxyStream(RemoteCallTask task,InputStream in, String myName) {
		localInput = in;
		this.myName = myName;
		this.task = task;
	}

	ProxyStream(RemoteCallTask task,OutputStream out, String myName) {
		localOutput = out;
		this.myName = myName;
		this.task = task;
	}

	protected void finalize() {
		try {
			//System.out.println("Finalizing proxy stream!");
			close();
		} catch (Throwable t) {
		}
	}
	private byte[] readFromRemote(int numBytes) throws IOException {
		return remote.remoteRead(numBytes, myName);
	}

	private boolean writeToRemote(byte[] data, int offset, int length)
			throws IOException {
		return remote.remoteWrite(data, offset, length, myName);
	}

	private boolean closeRemote() throws IOException {
		return remote.remoteClose(myName);
	}
	private void callStreamReady() {
		if (remote != null)
			remote.remoteStreamReady();
	}
	
	OutputStream getOutputStream() {
		return new OutputStream() {
			public void write(byte[] data, int offset, int length)
			throws IOException {
				ProxyStream.this.write(data, offset, length);
			}
			public void write(int data)
			throws IOException {
				single[0] = (byte)data;
				ProxyStream.this.write(single, 0, 1);
			}
			public void flush()
			{
				
			}
			public void close() throws IOException
			{
				ProxyStream.this.close();
			}
		};
	}
	InputStream getInputStream() {
		return new InputStream() {
			public int read(byte[] data, int offset, int length)
					throws IOException {
				return ProxyStream.this.read(data, offset, length);
			}

			public int read() throws IOException {
				int got = read(single, 0, 1);
				if (got == -1)
					return -1;
				return ((int) single[0]) & 0xff;
			}

			public void close() throws IOException {
				ProxyStream.this.close();
			}
		};
	}

	public void close() throws IOException {
		if (localInput != null){
			localInput.close();
			return;
		}
		if (localOutput != null){
			localOutput.close();
			return;
		}
		while (true) {
			synchronized (this) {
				if (closed)
					return;
				if (error != null)
					throw error;
				if (!ready) {
					try {
						wait();
					} catch (Exception e) {
						continue;
					}
				}
				ready = false;
			}
			try {
				if (closeRemote()) {
					closed = true;
					return;
				}
			} catch (IOException e) {
				error = e;
				ready = true;
				throw e;
			}
		}
	}

	void write(byte[] data, int offset, int length) throws IOException {
		while (true) {
			synchronized (this) {
				if (closed)
					throw new IOException("OutputStream closed");
				if (error != null)
					throw error;
				if (!ready) {
					try {
						wait();
					} catch (Exception e) {
						continue;
					}
				}
				ready = false;
			}
			try {
				if (writeToRemote(data, offset, length)){
					ready = true;
					return;
				}
			} catch (IOException e) {
				error = e;
				ready = true;
				throw e;
			}
		}
	}

	//
	// Local entity calls this. Must request data from remote.
	//
	int read(byte[] data, int offset, int length) throws IOException {
		while (true) {
			synchronized (this) {
				if (atEOF)
					return -1;
				if (error != null)
					throw error;
				if (!ready) {
					try {
						wait();
					} catch (Exception e) {
						continue;
					}
				}
				ready = false;
			}
			try {
				byte[] got = readFromRemote(length);
				if (got == null) {
					ready = true;
					atEOF = true;
					return -1;
				}
				if (got.length == 0)
					continue;
				ready = true;
				System.arraycopy(got, 0, data, offset, got.length);
				return got.length;
			} catch (IOException e) {
				error = e;
				ready = true;
				throw e;
			}
		}
	}

	private static byte[] empty = new byte[0];

	private void _requestBackgroundOperation()
	{
		if (!haveThread){
			haveThread = true;
			task.handler.addTask(RemoteCallWorkerThread.getCached(this,localInput != null));
		}
		notifyAll();
	}
	//
	// Remote entity calls this - it must be non-blocking.
	//
	public synchronized byte[] remoteRead(int numBytes, String remoteName)
			throws IOException {
		if (buffer.length != 0) {
			int take = numBytes;
			if (take > buffer.length)
				take = buffer.length;
			byte[] ret = new byte[take];
			System.arraycopy(buffer.data, 0, ret, 0, take);
			buffer.delete(0, take);
			return ret;
		}
		if (closed)
			throw new IOException("InputStream closed.");
		if (atEOF)
			return null; // Indicates closed.
		if (needToRead == -1)
			return empty; // Indicates that it is waiting to close.
		if (error != null)
			throw error;
		getRemote(remoteName);
		needToRead += numBytes;
		_requestBackgroundOperation();
		return empty;
	}

	public synchronized boolean remoteWrite(byte[] data, int offset,
			int length, String remoteName) throws IOException {
		getRemote(remoteName);
		if (closed)
			throw new IOException("OutputStream closed.");
		if (needToRead == -1)
			return false;
		if (error != null)
			throw error;
		if (buffer.length != 0){
			return false;
		}
		buffer.append(data, offset, length);
		_requestBackgroundOperation();
		return true;
	}

	public synchronized boolean remoteClose(String remoteName)
			throws IOException {
		getRemote(remoteName);
		if (error != null) throw error;
		if (closed) return true;
		needToRead = -1;
		_requestBackgroundOperation();
		return false;
	}

	public synchronized void remoteStreamReady()
	{
		ready = true;
		notifyAll();
	}
	
	void localWriteThread() {
		try{
			while (true) {
				synchronized (this) {
					if (buffer.length == 0 && needToRead != -1) {
						if (error != null || closed)
							return;
						haveThread = false;
						return;
						//try {wait();}catch (Exception e) {}
						//continue;
					}
				}
				try {
					if (buffer.length != 0) {
						localOutput.write(buffer.data, 0, buffer.length);
						buffer.length = 0;
						callStreamReady();
					} else {
						needToRead = 0;
						localOutput.close();
						closed = true;
						//System.out.println("Closed!");
						haveThread = false;
						callStreamReady();
						return;
					}
				} catch (IOException e) {
					error = e;
					haveThread = false;
					callStreamReady();
					return;
				}
			}
		}finally{
			//System.out.println("Write thread leaving.");
		}
	}

	void localReadThread() {
		//System.out.println("Read thread!");
		try{
			while (true) {
				int doRead = 0;
				while (doRead == 0) {
					synchronized (this) {
						if (closed || error != null)
							return;
						doRead = needToRead;
						if (doRead == 0){
							haveThread = false;
							return;
							//try {wait();}catch (Exception e) {}
							//continue;
						}
					}
				}
				if (doRead == -1) {
					try {
						localInput.close();
						closed = true;
						//System.out.println("Closed!");
					} catch (IOException e) {
						error = e;
					}
					needToRead = 0;
					haveThread = false;
					callStreamReady();
					return;
				}
				buffer.ensureCapacity(doRead);
				try {
					int got = localInput.read(buffer.data, 0, doRead);
					synchronized (this) {
						if (got == -1) {
							atEOF = true;
							got = 0;
						}
						buffer.length = got;
						needToRead = 0;
					}
					callStreamReady();
					continue;
				} catch (IOException e) {
					error = e;
					haveThread = false;
					callStreamReady();
					return;
				}
			}
		}finally{
			//System.out.println("Read thread leaving!");
		}
	}
}
