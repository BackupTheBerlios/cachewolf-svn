/*
 * Created on Nov 6, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io.block;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface RemoteCallHandler {

	public boolean call(RemoteCall rc,String targetCode);
	
}
//####################################################
