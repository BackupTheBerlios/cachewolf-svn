package eve.io.block;

import java.io.IOException;
import java.net.Socket;

import eve.sys.Handle;
import eve.sys.IRemoteProxyMaker;
/**
 * This class, along with RemoteProxy, makes it easy to implement 
 * remote method calls over a streaming connection. Usually you will
 * not need to use this class directly - you would create a RemoteProxy
 * and then call makeServerObject(). However that method assumes the simplest
 * mode of operation and if you need more advanced handling then you should
 * use this class directly.
 * The easiest way to create a remote proxy accross a connection is:
 *  <ul>
 *  <li>Define an interface that covers all the methods you want to
 *  call across the connection.</li>
 *  <li>Make the connection somehow - either via a Socket or
 *  by creating connected Input/Output streams or BlockInput/BlockOutput
 *  streams.</li>
 *  <li>On the client side create a RemoteProxy object, set the connection
 *  and then call createProxy() to get an Object that implements the interface
 *  and which automatically sends remote calls across the connection.</li>
 *  <li>On the server side create a RemoteProxyServer object, add the server
 *  Object that implements the interface and then start it running with the
 *  connection.</li>
 *  <li>Call close() on the RemoteProxy or RemoteProxyServer to close the 
 *  connection when done.</li>
 *  </ul>
 * These classs can handle a single threaded mode of operation, where only a
 * single call can be made at a time (this is the most memory efficient way)
 * or multi threaded where multiple calls can be made simultaneously.
 */
//public 
class RemoteProxyServer {

	protected RemoteCallHandlerObject rco;
	
	/*
	public boolean multiThreaded = false;
	public long callTimeoutInMillis = 15*1000;
	public boolean closeIfTimedOut = 
	*/
	int options = 0;
	
	RemoteProxyServer(RemoteProxy rp)
	{
		this(new RemoteCallHandlerObject());
		rco.timeOut = (int)rp.callTimeoutInMillis;
		options = rp.getProxyOptions();
	}
	/*
	public RemoteProxyServer(int options)
	{
		this(new RemoteCallHandlerObject());
	}
	*/
	/**
	 * This is a more specialized version of the constructor that
	 * lets you specify the RemoteCallHandlerObject being used.
	 * @param rco the RemoteCallHandlerObject to use.
	 */
	protected RemoteProxyServer(RemoteCallHandlerObject rco)
	{
		this.rco = rco;
		rco.remoteCallTask = new RemoteCallTask();
		rco.remoteCallTask.handler = rco;
	}
	/**
	 * Setup the connection but don't start operations. Use run() or runInCurrentThread()
	 * to run it.
	 * @param input - this can be an InputStream, a BlockInputStream or a Socket.
	 * @param output - this can be an OutputStream, a BlockOutputStream or a Socket.
	 */
	public void setConnection(Object input, Object output) throws IOException
	{
		BlockInputStream in = RemoteProxy.toBlockInputStream(input);
		BlockOutputStream out = RemoteProxy.toBlockOutputStream(output);
		rco.setStreams(in, out);
	}
	
	public void setConnection(Socket sock) throws IOException
	{
		setConnection(sock,sock);
	}
	private boolean added = false;
	
	/**
	 * Add a target object that incoming remote calls will be invoked on.
	 * @param targetCode a distinct name for the Object. If this is null or ""
	 * then this target will be the default target.
	 * @param target the target object that will have remote calls invoked on.
	 * @param asClass an optional Class that specifies what class or interface
	 * the Object should expose for method invokes. This is because anonymous
	 * objects may not be public and so the method you expect to be public
	 * may not be so. To ensure that the methods are invokes you provide the
	 * Class that will be used when searching for methods. If this is null
	 * then getClass() is called on the target.
	 */
	public void addTarget(String targetCode,Object target,Class asClass)
	{
		rco.addTarget(targetCode, target, asClass);
		added = true;
	}
	/**
	 * A simpler version of addTarget() which uses null as the targetCode
	 * (which sets the target as the default target) and the targetClass
	 * using getClass() on the target.
	 * @param target the target Object that will have methods
	 * invoked on via remote calls.
	 */
	public void addTarget(Object target)
	{
		addTarget(null,target,target.getClass());
	}
	/**
	 * Get a Handle that can be used to monitor the connection. If the Stopped
	 * bit is set in the handle, this indicates the connection has closed.
	 * @return a Handle that can be used to monitor the connection.
	 */
	public Handle getRunningHandle()
	{
		return rco;
	}
	/**
	 * Close the communication streams and therefore the remote connection.
	 */
	public void close()
	{
		rco.close();
	}
	/**
	 * Start the RemoteProxyServer so that it can now receive incoming
	 * method calls and direct them to the correct target objects.
	 * If no targets were added the this Object itself becomes the default
	 * target.
	 * @return the Handle used to monitor the connection.
	 */
	public Handle run()
	{
		if (!added) addTarget(this);
		rco.runInSingleThread = ((options & IRemoteProxyMaker.OPTION_IS_MULTITHREADED) != 0);//!multiThreaded;
		rco.start();
		return rco;
	}
	/**
	 * Runs the RemoteProxyServer in a single thread (overriding 
	 * the value of multiThreaded) and does not return until close()
	 * is called on the connection.
	 */
	/*
	public void runInCurrentThread()
	{
		if (!added) addTarget(this);
		multiThreaded = false;
		rco.runInCurrentThread();
	}
	*/
}
