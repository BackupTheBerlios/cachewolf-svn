package eve.io.block;

import java.io.IOException;

public interface IDataStream {
	public boolean remoteWrite(byte[] data, int offset, int length,String from) throws IOException;
	public boolean remoteClose(String from) throws IOException;
	public byte[] remoteRead(int numBytes,String from) throws IOException;
	public void remoteStreamReady();
}
