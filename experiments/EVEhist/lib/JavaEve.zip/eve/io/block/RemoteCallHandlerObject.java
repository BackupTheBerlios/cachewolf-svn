package eve.io.block;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Hashtable;
import java.util.Vector;

import eve.sys.Convert;
import eve.sys.Countdown;
import eve.sys.Task;
import eve.sys.ThreadPool;
import eve.sys.TimeOut;
import eve.sys.mThread;
import eve.util.ByteArray;
import eve.util.ByteEncoder;
import eve.util.Tag;
import eve.util.mVector;
/**
* A remote call handler is a class that performs two functions:
* <ul>
* <li>It receives remote calls from a remote object, invokes it on a local object
* and then dispatches the results to the source remote object.
* <li>It takes local remote calls, dispatches it to a remote object and waits for
* the results.
* </ul>
* <br>
* This implementation performs these functions with the following constraints:
* <ul>
* <li>Remote calls are received and dispatch via a single stream.
* </ul>
* <br>
* This implementation handles calls to multiple objects by using a Hashtable to map
target codes to local objects. To override this implementation - override the
<b>Object findTarget(String targetCode)</b> method.
* <p>
* If you want to change the method for receiving and sending data (i.e. not via the default
* stream) you must override <b>boolean sendData(ByteArray data)</b> and <b>TextDecoder getData(ByteArray dest)</b>
*<p>
* To close the RemoteCallHandler simply close the streams. If you want to close the handler
* without closing the streams, call the close() method.
**/
//##################################################################
public class RemoteCallHandlerObject extends Task implements RemoteCallHandler{
//##################################################################

	/**
	 * If this is true then the RemoteCallHandlerObject will use a Thread pool
	 * to run threads. Use getThreadPool() to get the thread pool it uses and
	 * to modify its parameters if necessary.
	 */
public static boolean useThreadPool = false;

public static boolean alwaysMultiThreaded = true;
/**
* The length of time to wait (in seconds) before timing out and closing the connection.
* By default it is 60 seconds.
**/
static int KeepAliveTimeout = 60;

private Vector sends = new Vector(), oldReplies = new Vector();

Vector sent = new Vector();
Vector pendingInvokes = new Vector();

/**
 * If this is set true then only a single thread will be used that will
 * receive a call request, invoke the method, and then send the reply
 * and then repeat until the streams are closed.
 * No other operations can be done so this will limit the object to
 * only handling incoming calls, and it cannot be used to handle
 * outgoing calls at the same time.
 */
public boolean runInSingleThread = false;

Hashtable streams = new Hashtable();
/**
* This Hashtable contains the local target objects and is used by the 
* default implementation to match a target code with the target object.
* Add to it as needed.
**/
//===================================================================
//public 
Hashtable targets = new Hashtable();
//===================================================================
private Hashtable targetClasses = new Hashtable();

/**
 * This has the same effect as setting runInSingleThread to true
 * and then calling run(). Only the current thread will be used that will
 * receive a call request, invoke the method, and then send the reply 
 * and then repeat until the streams are closed.
 * No other operations can be done so this will limit the object to
 * only handling incoming calls, and it cannot be used to handle
 * outgoing calls at the same time.
 */
public void runInCurrentThread()
{
	runInSingleThread = true;
	run();
}
/**
 * Add a target object that incoming remote calls will be invoked on.
 * @param targetCode a distinct name for the Object. If this is null or ""
 * then this target will be the default target.
 * @param target the target object that will have remote calls invoked on.
 * @param asClass an optional Class that specifies what class or interface
 * the Object should expose for method invokes. This is because anonymous
 * objects may not be public and so the method you expect to be public
 * may not be so. To ensure that the methods are invokes you provide the
 * Class that will be used when searching for methods. If this is null
 * then getClass() is called on the target.
 */
public void addTarget(String targetCode,Object target,Class asClass)
{
	if (targetCode == null) targetCode = "";
	targets.put(targetCode,target);
	targetClasses.put(target,asClass == null ? target.getClass() : asClass);
}
public void removeTarget(String targetCode)
{
	if (targetCode == null) targetCode = "";
	Object obj = targets.get(targetCode);
	if (obj == null) return;
	targets.remove(targetCode);
	targetClasses.remove(obj);
}
public Class getTargetClass(Object target)
{
	return (Class)targetClasses.get(target);
}
/**
* Override this to find a target given a text encoded targetCode. 
**/
//-------------------------------------------------------------------
public Object findTarget(String targetCode)
//-------------------------------------------------------------------
{
	if (targetCode == null) targetCode = "";
	else if (targetCode.equals("*")) return this;
	return targets.get(targetCode);
}

/**
 * This returns the ThreadPool being used by the RemoteCallHandlerObjects. You can
 * adjust the parameters of the ThreadPool for better server efficiency.
 */
public static synchronized ThreadPool getThreadPool()
{
	if (threadPool == null){
		threadPool = new ThreadPool(5,-1);
	}
	return threadPool;
}

void addTask(Runnable rb)
{
	if (useThreadPool) getThreadPool().addTask(rb);
	else new Thread(rb).start();
}
/**
* Create a RemoteCallHandler with no streams.
* Use setStreams() to set the streams and start() to start it running.
**/
//===================================================================
public RemoteCallHandlerObject(){}
//===================================================================
/**
* Create a RemoteCallHandler to operate on the specified streams.
* Use start() to start it running.
**/
public RemoteCallHandlerObject(InputStream in,OutputStream out)
//===================================================================
{
	setStreams(in,out);
}
//===================================================================
/**
* Create a RemoteCallHandler to operate on the specified streams.
* Use start() to start it running.
**/
public RemoteCallHandlerObject(BlockInputStream in,BlockOutputStream out)
//===================================================================
{
	setStreams(in,out);
}

public void setStreams(BlockInputStream in,BlockOutputStream out)
{
	this.in = in;
	this.out = out;
}
public void setStreams(InputStream in,OutputStream out)
{
	this.in = new BlockInputStream(in);
	this.out = new BlockOutputStream(out);
}
protected BlockOutputStream out;
protected BlockInputStream in;
/**
* This is responsible for sending data - either remote calls or replies
* to remote calls. <p>This method may block the current mThread - the other operations
* of the handler operate in their own mThread threads.
**/
//-------------------------------------------------------------------
public void sendData(ByteArray data) throws IOException
//-------------------------------------------------------------------
{
	//System.out.println("Sending: "+data);
	if (out == null) throw new IOException("No output stream");
	//System.out.println(hashCode()+" - Sending "+data.length);
	//whenTX = ewe.sys.Vm.getTimeStamp();
	out.writeBlock(data);
}
/**
* This is responsible for receiving data - either remote calls or replies
* to remote calls. By default it reads a 32-bit integer value specifying the 
* size of an array of bytes, which represents the call itself.
* <p>This method should block the current Thread until a full ByteArray object
* has been read - the other operations
* of the handler operate in their own Threads.
* @returns A ByteArray object if successful, null if not (i.e. stream is closed).
**/
//-------------------------------------------------------------------
public ByteArray getData(ByteArray dest) throws IOException
//-------------------------------------------------------------------
{
	if (in == null) {
		return null;
	}
	ByteArray ret = in.readBlock(dest);
	//System.out.println("Got: "+ret);
	//if (whenTX != -1) System.out.println(hashCode()+" - RX: "+(ewe.sys.Vm.getTimeStamp()-whenTX)+" at "+ret.length);
	return ret;
}
/**
* If this stream is not null, then the handler will send and receive
* remote calls from it. If it is null then you will have to override
* the sendReply() and getCall() methods.
**/
//public Stream stream;
/**
* This is the timeout in milliseconds for receiving a reply. You can change
* this as you wish.
**/
public int timeOut = 5000;

/**
* If an IOException occured, it will be placed here. An IOException will terminate the
* operations of the handler.
**/
public IOException ioException;

protected boolean closed = false;
private Object sendLock = new Object();

static long whenReceived = -1, whenSent = -1, whenTX = -1;

/**
* Closes the RemoteCallHandler and stops its operation. The streams are not
* closed however UNLESS runInSingleThread is true since closing the streams
* is the only way to stop the call receiving thread in that case.
* Note that closing the stream will automatically stop
* the handlers operation as well.
**/
//===================================================================
public void close()
//===================================================================
{
	closed = true;
	if (runInSingleThread){
		try{
			in.close();
			out.close();
		}catch(Exception e){}
	}
	synchronized(sendLock){
		sendLock.notifyAll();
	}
	set(Stopped);
}
/**
* Closes the RemoteCallHandler and stops its operation and closes the stream connection.
**/
//===================================================================
public void closeConnection()
//===================================================================
{
	close();
	try{
		if (out != null) out.close();
		if (in != null) in.close();
	}catch(IOException e){}
}
/**
 * This will close the RemoteCallHandler.
 */
public void stop(int reason)
{
	super.stop(reason);
	close();
}
TimeOut keepAlive = TimeOut.Forever;//new TimeOut(KeepAliveTimeout*1000);
static final ByteArray emptyByteArray = new ByteArray();

boolean readIn = false;
IOException readError = null;
Thread readThread;
private int numObjects; 
// FIXME

protected static ThreadPool threadPool;

RemoteCallTask remoteCallTask;

private boolean doNextGet() throws IOException
{
	readThread = Thread.currentThread();
	synchronized(readThread){
		readIn = false;
		addTask(RemoteCallWorkerThread.getCached(this,RemoteCallWorkerThread.FUNCTION_RECEIVE_CALLS));
		while(!readIn && !closed){
			try{
				readThread.wait();
			}catch(InterruptedException e){}
		}
		if (closed){
			return false;
		}
		if (readError != null) throw readError;
		return true;
	}
}

synchronized void switchToMultiThreaded() //throws IllegalStateException
{
	runInSingleThread = false;
	int v = check();
	if ((v & Stopped) != 0) return;
	if ((v & Running) == 0) {
		start();
	}else{
		addTask(RemoteCallWorkerThread.getCached(this, RemoteCallWorkerThread.FUNCTION_START_MULTITHREADED));
	}
}

protected void doRun()
{
	if (!alwaysMultiThreaded && runInSingleThread){
		ByteArray call = new ByteArray();
		ByteEncoder bo = new ByteEncoder();
		try{
			while(runInSingleThread){
				try{
					call.clear();
					call = getData(call);
					if (call == null) {
						//System.out.println("Leaving!");
						return; //Stream closed.
					}
					String callId = bo.decodeStringField(call,"<id>");
					String callName = bo.decodeStringField(call,"<c>");
					if (callName == null || callId == null) continue;
					int id = Convert.toInt(callId) | 0x80000000;
					Tag tg = null;
					try{
						RemoteCall rc = new RemoteCall(call.data,0,call.length);
						String trg = (String)bo.decodeObjectField(call,"<t>");
						Object target = findTarget(trg);
						if (target == null) throw new InvocationTargetException(new IllegalArgumentException("No remote target: "));
						ByteArray te = doInvoke(target,rc);
						bo.encodeField(te,"<r>","");
						bo.encodeField(te,"<id>",callId);
						if (runInSingleThread) sendData(te);
						else queueSend(te,id,false);
					}catch(Throwable t){
						ByteArray te = new ByteArray();
						RemoteCall.encodeException(bo,t,te,true);
						bo.encodeField(te,"<r>","");
						bo.encodeField(te,"<id>",callId);
						if (runInSingleThread) sendData(te);
						else queueSend(te,id,false);
					}
				}catch(IOException e){
					return;
				}catch(Throwable t){
					//t.printStackTrace();
					continue;
				}
			}
			//
			// No longer running in single thread.
			// Must wait until closed.
			//
			waitUntilCompletion();
		}finally{
		}
	}else{
		startMultiThreaded();
	}
}

private boolean multiThreadedStarted;

//
//RemoteCallWorkerThread calls this.
//
void replySenderRun()
{
	while(!closed){
		Tag s = null;
		ByteArray reply = null;
		synchronized(sendLock){
			if (sends.size() == 0)
				try{
					sendLock.wait();
				}catch(InterruptedException e){}
			if (sends.size() == 0) continue;
			s = (Tag)mVector.pop(sends);
			reply = (ByteArray)s.value;
		}
		if ((s.tag & 0x80000000) != 0){
			oldReplies.add(s);
			s.tag &= ~0x80000000;
			//System.out.println("Saving reply: "+s.tag);
		}
		while (oldReplies.size() > 10) mVector.pop(oldReplies);
		if (reply != null) try{
			sendData(reply);
		}catch(IOException e){
			ioException = e;
			break;
		}
	}
	//Vm.debug("Sender ending!");
}
//
// RemoteCallWorkerThread calls this.
//
void keepAliveRun()
{
	ByteArray te = new ByteArray();
	int to = KeepAliveTimeout/4;
	if (to == 0) to = 1;
	Countdown cd = new Countdown();
	cd.start(to);
	while(!closed){
		mThread.nap(1000);
		if (keepAlive.hasExpired()){
			closeConnection();
		}
		if (cd.hasExpired()){
			queueSend(te,0,false);
			cd.start(to);
		}
	}
}
void startMultiThreaded()
{
	synchronized(this){
		if (multiThreadedStarted) return;
		multiThreadedStarted = true;
	}
	addTask(RemoteCallWorkerThread.getCached(this, RemoteCallWorkerThread.FUNCTION_KEEP_ALIVE));
	addTask(RemoteCallWorkerThread.getCached(this, RemoteCallWorkerThread.FUNCTION_REPLY_SENDER));
	/*
//===================================================================
	new Thread(new Runnable(){ //This is the call receiver thread.
//===================================================================
		public void run() {
			*/
	readThread = Thread.currentThread();
	try{
		while(true) try{
			//numObjects = Vm.countObjects(false);
			if (!doNextGet()) break;
		}catch(IOException e){
			ioException = e;
			close();
			break;
		}
	}finally{
		set(Stopped);
	}
	/*
	try{
			while(!closed && !shouldStop){
				//System.out.println("Waiting for a call!");
				try{
					final ByteArray call = getData(null);
					if (call == null) {
						close(); //Must be closed.
						break;
					}
					//System.out.println("Got: "+call.length);
					keepAlive.reset();
					if (call.length != 0){
						whenReceived = System.currentTimeMillis();
						new Thread(){
							public void run(){
								callReceived(call);
							}
						}.start();
					}
				}catch(IOException e){
				}
			}
			//Vm.debug("Receiver ending!");
	}finally{
		close();
	}
	*/
}

//-------------------------------------------------------------------
protected void queueSend(ByteArray toSend,int id,boolean isCall)
//-------------------------------------------------------------------
{
	Tag tg = new Tag();
	tg.value = toSend;
	tg.tag = id & 0x7fffffff;
	if (!isCall) tg.tag |= 0x80000000;
	queueSend(tg);
}

//-------------------------------------------------------------------
protected void queueSend(Tag toSend)
//-------------------------------------------------------------------
{
	synchronized(sendLock){
		mVector.add(sends,toSend);
		sendLock.notifyAll();
	}
}
//-------------------------------------------------------------------
protected ByteArray doInvoke(Object target,RemoteCall rc)
//-------------------------------------------------------------------
{
	ByteArray ba = rc.invokeOn(target,getTargetClass(target),remoteCallTask);
	return ba;
}
/*
//-------------------------------------------------------------------
protected Tag findTag(int id,Vector where)
//-------------------------------------------------------------------
{
	for (int i = 0; i<where.size(); i++){
		Tag tg = (Tag)where.get(i);
		if (tg.tag == id) return tg;
	}
	return null;
}
*/
private ByteEncoder encoder = new ByteEncoder();

private ByteEncoder getByteEncoder()
{
	return encoder;
}
void sendNonCall(ByteEncoder bo, ByteArray toSend, String mainTag, String id, Throwable t)
{
	bo.encodeField(toSend,mainTag,"");
	bo.encodeField(toSend,"<id>",id);
	if (t != null) RemoteCall.encodeException(bo,t,toSend,true);
	queueSend(toSend,Convert.toInt(id),false);
}
int curId = 0;

/*
//-------------------------------------------------------------------
protected boolean callReceived(ByteArray received)
//-------------------------------------------------------------------
{
	ByteEncoder bo = new ByteEncoder();
}
*/
/*
class dataStream {
	
	String remoteStream;
	boolean canSend;
	IOException streamError;
	ByteArray te = new ByteArray();
	ByteEncoder bo = new ByteEncoder();
	
	void write(byte[] data, int offset, int length) throws IOException
	{
		while(length > 0){
			te.clear();
			bo.encodeField(te,"<send>","");
			bo.encodeField(te,"<data>",data,offset,length);
			bo.encodeField(te,"<id>",remoteStream);
			String callId = null;
			RemoteCall rc = new RemoteCall("a()");
			rc.id = destName;
			synchronized(sent){
				callId = ""+(++curId);
				sent.add(rc);
			}
			queueSend(te,Convert.toInt(callId),true);
			TimeOut waitFor = new TimeOut(timeOut);
			while(true){
				try{
					rc.waitUntilStopped(waitFor);
					break;
				}catch(InterruptedException e){}
			}
			synchronized(rc){
				if (!rc.replied) {
					rc.timeout();
				}else if (rc.returnValue instanceof Wrapper){
					rxed = ((Wrapper)rc.returnValue).getInt();
				}
			}
			synchronized(sent){
				sent.remove(rc);
			}
			if (rc.error instanceof IOException) throw (IOException)rc.error;
			if (rc.error != null) throw new IOException(rc.error.toString());
			if (data == null) break;
			length -= rxed;
			offset += rxed;
			
	}
}

private void sendData( String destName, byte[] data,int offset,int length)
throws IOException
{
	if ((check() & Stopped) != 0){
		throw new IOException("Connection to remote host closed.");
	}
		int rxed = length; 
		ByteArray te = (ByteArray)Cache.get(ByteArray.class);
		ByteEncoder bo = (ByteEncoder)Cache.get(ByteEncoder.class);
		try{
			while(length > 0){
				te.clear();
				if (data == null) bo.encodeField(te,"<close>","");
				else {
					bo.encodeField(te,"<send>","");
					bo.encodeField(te,"<data>",data,offset,length);
				}
				bo.encodeField(te,"<id>",destName);
				String callId = null;
				RemoteCall rc = new RemoteCall("a()");
				rc.id = destName;
				synchronized(sent){
					callId = ""+(++curId);
					sent.add(rc);
				}
				queueSend(te,Convert.toInt(callId),true);
				TimeOut waitFor = new TimeOut(timeOut);
				while(true){
					try{
						rc.waitUntilStopped(waitFor);
						break;
					}catch(InterruptedException e){}
				}
				synchronized(rc){
					if (!rc.replied) {
						rc.timeout();
					}else if (rc.returnValue instanceof Wrapper){
						rxed = ((Wrapper)rc.returnValue).getInt();
					}
				}
				synchronized(sent){
					sent.remove(rc);
				}
				if (rc.error instanceof IOException) throw (IOException)rc.error;
				if (rc.error != null) throw new IOException(rc.error.toString());
				if (data == null) break;
				length -= rxed;
				offset += rxed;
			}
		}finally{
			Cache.put(te);
			Cache.put(bo);
		}
		
}
*/
private ByteArray encode(RemoteCall rc,ByteEncoder bo,String targetCode,boolean sendIt)
{
	ByteArray te = new ByteArray();
	if (bo == null) bo = new ByteEncoder();
	rc.encodeBytes(te);
	bo.encodeField(te,"<c>","");
	if (targetCode != null) bo.encodeField(te,"<t>",targetCode);
	synchronized(sent){
		bo.encodeField(te,"<id>",(rc.id = ""+(++curId)));
		if (sendIt) sent.add(rc);
	}
	return te;
}
/**
 * This is called by the remote entity when a Proxy at the remote end has
 * been freed (no longer referenced) and this indicates that the object at 
 * this end, which has the specified target code, should be removed from
 * the table of targets and therefore allowed to be freed on this end as
 * well.
 * @param proxyTargetCode the target code assigned to the proxy at this end.
 */
public void freeProxy(String proxyTargetCode)
{
	removeTarget(proxyTargetCode);
}
/**
* This dispatches the RemoteCall to the remote handler. The targetCode can be
* null if the remote handler only handles invokation on a single object (e.g. this
* RemoteCallHandler). It returns true once the remote call has been queued for
* dispatch. The RemoteCall is itself a Handle and you should poll it to see
* when the Success or Failure flags have been set. 
**/
//===================================================================
public boolean call(final RemoteCall rc,final String targetCode)
//===================================================================
{
	if ((check() & Stopped) != 0){
		rc.fail(new RemoteCallException(rc,null,"Connection to remote host closed."));
		return true;
	}
	if ((check() & Running) == 0) synchronized(this){
		//System.out.println("Not running "+System.identityHashCode(this)+": "+rc);
		ByteEncoder bo = new ByteEncoder();
		ByteArray te = encode(rc,bo,targetCode,false);
		try{
			sendData(te);
			te.length = 0;
			ByteArray received = null;
			while(true){
				received = getData(te);
				if (received == null) throw new IOException("Connection closed.");
				String callId = bo.decodeStringField(received,"<id>");
				if (callId == null) continue; //A keep alive.
				if (!callId.equals(rc.id))
					throw new IOException("Bad ID in reply from remote server.");
				break;
			}
			String reply = (String)bo.decodeObjectField(received,"<r>");
			if (reply == null) throw new IOException("Bad data from remote server.");
			rc.reply(received);
			return true;
		}catch(Throwable t){
			//t.printStackTrace();
			rc.fail(new RemoteCallException(t));
			return true;
		}
	}
	addTask(RemoteCallWorkerThread.getCached(this, rc, targetCode));
	return true;
}
//
// Called by RemoteCallWorkerThread
//
void sendCall(RemoteCall rc, String targetCode)
{
	try{
		ByteArray te = encode(rc,null,targetCode,true);
		queueSend(te,Convert.toInt(rc.id),true);
		TimeOut waitFor = new TimeOut(rc.timeOut == 0 ? timeOut : rc.timeOut);
		while(true){
			try{
				rc.waitUntilStopped(waitFor);
				break;
			}catch(InterruptedException e){}
		}
		//System.out.println("Replied or timed out: "+rc);
		synchronized(rc){
			if (!rc.replied) {
				rc.timeout();
			}
		}
		synchronized(sent){
			sent.remove(rc);
		}
	}catch(Exception e){
		rc.fail(e);
	}
}
/**
* This calls and waits for the remote call to complete, fail or timeout. It returns the
* Wrapper which has the return value. If the return value is null, then there was an error.
**/
/*
//===================================================================
public Wrapper call(RemoteCall call,String targetCode,Wrapper destination)
//===================================================================
{
	callAndWait(call,targetCode);
	
	if (call.error != null || call.errorObject != null){
		if (error != null){
			error.setLength(0);
			if (call.error != null)
				error.append(call.error);
			else if (call.errorObject instanceof Throwable)
				error.append(((Throwable)call.errorObject).getMessage());
			else
				error.append(call.errorObject);
		}
		return null;
	}
	if (!(call.returnValue instanceof Wrapper)) return new Wrapper();
	else return (Wrapper)call.returnValue;
}
*/


int curStream = 0;

/**
 * @deprecated
 * @return
 */
/*
public synchronized String createInputStream()
{
	String name = "Stream-"+(++curStream);
	streams.put(name,new Stream(name));
	return name;
}
*/
/**
 * @deprecated
 * @return
 */
/*
public InputStream getStream(String name) throws IOException
{
	InputStream ret = (InputStream)streams.get(name);
	if (ret == null) throw new IOException("No such stream.");
	return ret;
}
public OutputStream connectTo(String remoteStreamName)
{
	return new myOutputStream(remoteStreamName);
}
class  myOutputStream extends OutputStream
{
	String myName;
	ByteArray buffer = new ByteArray();
	IOException writeError;
	boolean doFlush;
	boolean doClose;
	boolean closed;
	int delay = 100;
	
	myOutputStream(String name)
	{
		myName = name;
		new Thread(){
			Countdown cd = new Countdown();
			public void run(){
				Object sync = myOutputStream.this;
				ByteArray taken = new ByteArray();
				while(true){
					synchronized(sync){
						while(!closed){
							if (!doFlush && !doClose && buffer.length == 0){
								try{
									sync.wait();
								}catch(InterruptedException e){}
								continue;
							}
							// Something in the buffer.
							if (!doFlush && !doClose && delay > 0){
								cd.start(delay);
								while(!cd.hasExpired()){
									try{
										cd.waitOn(sync);
									}catch(InterruptedException e){}
									if (doFlush) break;
								}
							}
							break;
						}
						if (closed) return;
						taken.clear();
						taken.append(buffer.data,0,buffer.length);
						buffer.clear();
					}
					//
					try{
						if (taken.length != 0)
							sendData(myName,taken.data,0,taken.length);
						else if (doClose)
							sendData(myName,null,0,taken.length);
					}catch(IOException e){
						synchronized(sync){
							writeError = e;
							doClose = doFlush = false;
							sync.notifyAll();
						}
						break;
					}
					synchronized(sync){
						if (buffer.length == 0)
							doFlush = false;
						doClose = false;
						sync.notifyAll();
					}
				}
			}
		}.start();
	}
	byte[] buff = new byte[1];
	
	public synchronized void write(int ch) throws IOException
	{
		buff[0] = (byte)ch;
		write(buff,0,1);
	}
	public synchronized void write(byte[] data,int offset,int length) throws IOException
	{
		if (closed) throw new IOException("Stream closed.");
		if (writeError != null) throw writeError;
		buffer.append(data,offset,length);
		notifyAll();
	}
	public synchronized void flush() throws IOException
	{
		if (closed) throw new IOException("Stream closed.");
		if (writeError != null) throw writeError;
		if (buffer.length == 0) return;
		doFlush = true;
		while (doFlush){ 
			notifyAll();
			try{
				wait();
			}catch(Exception e){}
		}
		if (writeError != null) throw writeError;
	}
	public synchronized void close() throws IOException
	{
		if (closed) return;
		flush();
		doClose = true;
		while (doClose){ 
			notifyAll();
			try{
				wait();
			}catch(Exception e){}
		}
		closed = true;
		notifyAll();
		if (writeError != null) throw writeError;
	}
};
*/
/*
 * This is the incoming data stream. 
 *
 */
/*
class Stream extends MemoryStream {
	public String myId;
	public Stream(String id)
	{
		myId = id;
	}
	public void close() throws IOException
	{
		streams.remove(myId);
		super.close();
	}
	public int canWriteWithoutBlocking() {return canWrite();}
	public int nonBlockingWrite(byte[] data, int offset, int length)
	throws IOException
	{
		int cb = canWriteWithoutBlocking();
		if (cb == 0) return 0;
		if (cb < 0 || cb > length) cb = length;
		write(data,offset,length);
		return cb;
	}
}
*/
//##################################################################
}
//##################################################################

