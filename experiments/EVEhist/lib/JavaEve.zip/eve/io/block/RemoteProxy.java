package eve.io.block;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import eve.io.MemoryStream;
import eve.sys.Handle;
import eve.sys.IRemoteProxyMaker;

/**
 * This class, along with RemoteProxyServer, makes it easy to implement 
 * remote method calls over a streaming connection. The easiest way
 * to do this is:
 *  <ul>
 *  <li>Define an interface that covers all the methods you want to
 *  call across the connection.</li>
 *  <li>Make the connection somehow - either via a Socket or
 *  by creating connected Input/Output streams or BlockInput/BlockOutput
 *  streams.</li>
 *  <li>On the client side create a RemoteProxy object, set the connection
 *  and then call createProxy() to get an Object that implements the interface
 *  and which automatically sends remote calls across the connection.</li>
 *  <li>On the server side create a RemoteProxyServer object, add the server
 *  Object that implements the interface and then start it running with the
 *  connection.</li>
 *  <li>Call close() on the RemoteProxy or RemoteProxyServer to close the 
 *  connection when done.</li>
 *  </ul>
 * These class can handle a single threaded mode of operation, where only a
 * single call can be made at a time (this is the most memory efficient way)
 * or multi threaded where multiple calls can be made simultaneously.
 */
public class RemoteProxy implements IRemoteProxyMaker{
	
	/** This is the set of interfaces each proxy Object will implement. **/
	public Class[] interfaces;
	/** By default a single-threaded model is used - which is the most
	 * memory efficient implementation. Setting this to true allows
	 * multiple Threads to make calls across the connection.
	 */
	public boolean multiThreaded = false;
	/**
	 * Setup the timeout for calls. Setting a value of -1 means calls never
	 * timeout.
	 */
	public long callTimeoutInMillis = 15*1000;
	/**
	 * If this is true then the connection is closed if a timeout should occur.
	 */
	public boolean closeIfTimedOut = false;
	
	/** The default name for the target remote object, which can be null. **/
	
	public String defaultTargetName = null;
	
	/** The ClassLoader to use for proxy creation. This can be null. **/
	
	public ClassLoader proxyClassLoader = null;
	
	private RemoteCallTask myTask;
	
	int getProxyOptions()
	{
		int op = 0;
		if (multiThreaded) op |= OPTION_IS_MULTITHREADED;
		if (closeIfTimedOut) op |= OPTION_CLOSE_ON_TIMEOUT;
		return op;
	}
	public long getTimeOut() {return callTimeoutInMillis;}
	
	public void setTimeOut(long timeoutInMillis)
	{
		callTimeoutInMillis = timeoutInMillis;
	}
	/**
	 * After calling this constructor you must set the interfaces member
	 * to hold the list of interfaces proxy objects will implement. The
	 * proxy connection will be single threaded unless multiThreaded is
	 * set to true. 
	 * Call setConnection() followed by createProxy() to
	 * connect to the remote server and to create an Object that you can
	 * invoke the interface methods on, which will then cause remote
	 * calls to be sent to the remote Object.
	 */
	public RemoteProxy() {}
	/**
	 * Create a RemoteProxy and set the interfaces list to hold a single interface.
	 * The proxy connection will be single threaded unless multiThreaded is
	 * set to true.	 
	 * Call setConnection() followed by createProxy() to
	 * connect to the remote server and to create an Object that you can
	 * invoke the interface methods on, which will then cause remote
	 * calls to be sent to the remote Object.
	 * @param interfaceClass the interface that proxy objects will implement.
	 * @param iRemoteProxyMakerOptions any of the IRemoteProxyMaker.OPTION_XXX
	 * @param proxyClassLoader an optional ClassLoader to be used when making the proxy.
	 * values ORed together.
	 */
	public RemoteProxy(Class interfaceClass,int iRemoteProxyMakerOptions,ClassLoader proxyClassLoader) 
	{
		interfaces = new Class[]{interfaceClass};
		multiThreaded = (iRemoteProxyMakerOptions & OPTION_IS_MULTITHREADED) != 0;
		closeIfTimedOut = (iRemoteProxyMakerOptions & OPTION_CLOSE_ON_TIMEOUT) != 0;
		this.proxyClassLoader = proxyClassLoader;
	}
	/**
	 * Create a RemoteProxy and set the interfaces list and multiThreaded option.
	 * Call setConnection() followed by createProxy() to
	 * connect to the remote server and to create an Object that you can
	 * invoke the interface methods on, which will then cause remote
	 * calls to be sent to the remote Object.
	 * @param interfaces the list of interfaces that proxy objects will implement.
	 * @param multiThreaded true for multithreaded implementations, false for single threaded.
	 */
	public RemoteProxy(Class[] interfaces, boolean multiThreaded)
	{
		this.interfaces = (Class[])interfaces.clone();
		this.multiThreaded = multiThreaded;
	}
	/**
	 * Create a RemoteProxy to implement a single interface, in single threaded
	 * mode with no special ClassLoader.
	 * @param interfaceClass the interface the proxy will implement.
	 */
	public RemoteProxy(Class interfaceClass)
	{
		this(interfaceClass,0,null);
	}
	static BlockInputStream toBlockInputStream(Object input) throws IOException
	{
		BlockInputStream in = null;
		if (input instanceof BlockInputStream) in = (BlockInputStream)input;
		else if (input instanceof InputStream) in = new BlockInputStream((InputStream)input);
		else if (input instanceof Socket) in = new BlockInputStream(((Socket)input).getInputStream());
		else throw new IllegalArgumentException();
		return in;
	}
	static BlockOutputStream toBlockOutputStream(Object output) throws IOException
	{
		BlockOutputStream out = null;
		if (output instanceof BlockOutputStream) out = (BlockOutputStream)output;
		else if (output instanceof OutputStream) out = new BlockOutputStream((OutputStream)output);
		else if (output instanceof Socket) out = new BlockOutputStream(((Socket)output).getOutputStream());
		else throw new IllegalArgumentException();
		return out;
	}
	/**
	 * Setup the connection. If you want multiThreaded operation, set it true before calling this.
	 * After calling this, use createProxy() to create an Object that implements
	 * all the Interfaces in the interfaces array.
	 * @param input - this can be an InputStream, a BlockInputStream or a Socket.
	 * @param output - this can be an OutputStream, a BlockOutputStream or a Socket.
	 */
	public void setConnection(Object input, Object output) throws IOException
	{
		BlockInputStream in = toBlockInputStream(input);
		BlockOutputStream out = toBlockOutputStream(output);
		RemoteCallTask rt = new RemoteCallTask();
		final RemoteCallHandlerObject rco = new RemoteCallHandlerObject(in,out);
		rco.timeOut = (int)callTimeoutInMillis;
		rco.remoteCallTask = rt;
		rt.start(rco,multiThreaded);
		myTask = rt;
	}
	/**
	 * Setup the connection. If you want multiThreaded operation, set it true before calling this.
	 * After calling this, use createProxy() to create an Object that implements
	 * all the Interfaces in the interfaces array.
	 * @param connection - a connected Socket.
	 */
	public void setConnection(Socket connection) throws IOException
	{
		setConnection(connection,connection);
	}
	/**
	 * Return if the connection is open.
	 */
	public synchronized boolean isOpen()
	{
		return myTask != null;
	}
/**
 * Close the connection, after which calls to any proxies created will fail.
 */	
	public synchronized void close()
	{
		if (myTask != null) try{
			myTask.close();
		}finally{
			myTask = null;
		}
	}
	/**
	 * Get a Handle that can be used to monitor the connection. If the Stopped
	 * bit is set in the handle, this indicates the connection has closed.
	 * @return a Handle that can be used to monitor the connection.
	 */
	public synchronized Handle getRunningHandle()
	{
		if (myTask == null) return null;
		return myTask.handler;
	}
	/**
	 * Create an Object that implements the interfaces by making remote calls
	 * to a peer object across the connection specified in setConnection.
	 * @param targetName the name of the target object, which may be null.
	 * @return an Object that implements the interface list.
	 */
	public Object createProxy(String targetName)
	{
		return myTask.createProxy(interfaces,targetName);
	}
	/**
	 * Create an Object that implements the interfaces by making remote calls
	 * to a peer object across the connection specified in setConnection. The
	 * default name is used for identifying the remote object the method calls
	 * will be invoked on.
	 * @return an Object that implements the interface list.
	 */
	public Object createProxy()
	{
		return createProxy(defaultTargetName);
	}
	/**
	 * Create a local MemoryStream connection across which remote calls will
	 * be made. Then setup a RemoteProxyServer which will have the serverObject
	 * added as the default target object. Then create and return a proxy that
	 * implements this RemoteProxy's interfaces and which will invoke the
	 * methods on the serverObject across the MemoryStream connection. 
	 * @param serverObject the serverObject that will have calls invoked on it
	 * over the connection link.
	 * @return a proxy Object which implements the interfaces.
	 * @throws IOException on any IO error, which should be none since a 
	 * MemoryStream is used.
	 */
	public Object createTestConnection(Object serverObject)
	throws IOException
	{
		InputStream inputs[] = new InputStream[2];
		OutputStream outputs[] = new OutputStream[2];
		createTestStreams(inputs, outputs);
		setConnection(inputs[0],outputs[0]);
		makeServerObject(serverObject, inputs[1], outputs[1]);
		return createProxy();
	}
	/**
	 * Create input and output streams connected to each other via MemoryStreams.
	 * This is useful for testing remote calls.
	 * @param inputs an array of 2 InputStreams. inputs[0] and outputs[0] should
	 * be used by one side of the connection and inputs[1] and outputs[1] should
	 * be used on the other side.
	 * @param outputs an array of 2 OutputStreams. inputs[0] and outputs[0] should
	 * be used by one side of the connection and inputs[1] and outputs[1] should
	 * be used on the other side.
	 */
	public static void createTestStreams(InputStream[] inputs, OutputStream[] outputs)
	{
		MemoryStream.pipe2(inputs,outputs,0);
	}
	/**
	 * Used on the server side to make a connection over the input/output channels such that the
	 * specified serverObject acts as a server Object for incoming remote
	 * method calls on the inputChannel. The connection will be multithreaded
	 * only if this RemoteProxy is multithreaded.<p>
	 * This RemoteProxy should have been setup to handle a single interface
	 * and the serverObject must implement that interface.
	 * @param serverObject the object that implements the interface.
	 * @param inputChannel this can be an InputStream, a BlockInputStream or
	 * a Socket.
	 * @param outputChannel this can be an OutputStream, a BlockOutputStream or
	 * a Socket.
	 * @return a Handle that indicates if the connection is still active. You
	 * can call stop(int reason) on the Handle to stop and close the connection.
	 * @throws IOException on any IO error.
	 */
	public Handle makeServerObject(Object serverObject,Object inputChannel,Object outputChannel) throws IOException
	{
		RemoteProxyServer rs = new RemoteProxyServer(this);
		rs.setConnection(inputChannel,outputChannel);
		rs.addTarget(null,serverObject,interfaces[0]);
		rs.run();
		return rs.getRunningHandle();
	}
}
