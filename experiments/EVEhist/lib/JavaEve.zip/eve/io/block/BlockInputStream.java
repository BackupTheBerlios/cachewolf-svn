package eve.io.block;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import eve.io.StreamUtils;
import eve.util.ByteArray;
import eve.util.Utils;
/**
* A BlockInputStream is used to read in discrete blocks of data as sent by BlockOutputStream.
* The data sent by the BlockOutputStream may be Secure Documents as represented by eve.security.SecureDocument
* and this BlockInputStream will then attempt to decode and validate them using the encryption
* parameters as provided by setPassword() and setKeys().
**/
//##################################################################
public class BlockInputStream {
//##################################################################
protected InputStream in;
protected byte[] intBuff = new byte[4];
private ByteArray decryptBuffer;
/**
 * By default this is 5 MB. If any incoming block is bigger than this
 * an IOException is thrown.
 */
public static int maximumInputBlockSize = 5*1024*1024;

/**
* Create a BlockInputStream using the provided InputStream for reading
* in data.
**/
//===================================================================
public BlockInputStream(InputStream in)
//===================================================================
{
	this.in = in;
}

/**
* Set the decryptor to be used explicitly.
**/
/*
//===================================================================
public void setDecryptor(DataProcessor decryptor) throws IOException
//===================================================================
{
	getSecureDocument().setDecryptor(decryptor);
}
*/
/**
* Set the decryptor by creating a new Decryptor which uses the provided password.
**/
/*
//===================================================================
public void setDecryptor(String password) throws IOException
//===================================================================
{
	getSecureDocument().setPassword(password);
}
*/
/**
* This is used to read the next block of incoming data.
* @param dest an optional destination ByteArray. If this is null a new one is created.
* The destination ByteArray is always cleared before the new data is added.
* @return the destination ByteArray or a new ByteArray. On a clean end-of-stream this will
* return null.
* @exception IOException if an error occured reading or decoding or decrypting the data.
 * @throws UnknownEncodingException if the data could not be decoded/decrypted.
*/
//===================================================================
public synchronized ByteArray readBlock(ByteArray dest) throws IOException, UnknownEncodingException
//===================================================================
{
	if (dest == null) dest = new ByteArray();
	else dest.clear();
	//
	int did = 0;
	while(did < 4){
		int got = in.read(intBuff,did,4-did);
		if (got == -1)
			if (did == 0) return null; //EOF
			else throw new EOFException();
		did += got;
	}
	int length = Utils.readInt(intBuff,0,4);
	boolean hasEncryption = false;
	if (length < 0){
		hasEncryption = true;
		length = -length;
	}
	if (length > maximumInputBlockSize) throw new BlockTooBigException(length);
	int got = 0;
	if (hasEncryption && decryptBuffer == null)
		decryptBuffer = new ByteArray();
	ByteArray get = hasEncryption ? decryptBuffer : dest;
	get.makeSpace(0,length);
	StreamUtils.readFully(in,get.data,0,length);
	if (!hasEncryption) return get;
	decrypt(get.data,0,length,dest);
	return dest;
	/*
	SecureDocument sd = getSecureDocument();
	sd.setData(get.data,0,get.length);
	return sd.decode(dest);
	*/
}

/**
 * If the incoming data block is encoded/encrypted then after it is read in the raw bytes
 * are passed to this method before being returned. By default this method will
 * throw an UnknownEncodingException.
 * @param data the data bytes read in.
 * @param offset the offset of the data.
 * @param length the number of bytes of data.
 * @param dest a destination ByteArray that will not be null and would have been
 * cleared before being passed here.
 * @return the destination byte array.
 * @throws UnknownEncodingException if the data could not be decoded/decrypted.
 * @throws IOException if there was a problem decrypting the data.
 */
protected void decrypt(byte[] data,int offset,int length,ByteArray dest)
throws UnknownEncodingException, IOException
{
	throw new UnknownEncodingException();
}
/**
* This is used to read the next block of incoming data.
* @return A new ByteArray containing the data or null if the stream has closed cleanly.
* @exception IOException if an error occured reading or decoding or decrypting the data.
*/
//===================================================================
public ByteArray readBlock() throws IOException
//===================================================================
{
	return readBlock(null);
}
/**
* close this BlockInputStream and the underlying input stream.
* @exception IOException if an error occured closing the underlying stream.
*/
//===================================================================
public void close() throws IOException
//===================================================================
{
	in.close();
}
/**
 * Set the Public/Private keys.
 * @param myPrivateKey This is used to decrypt the symmetric session key for each block of data.
 * @param remotePublicKey The remotePublicKey is used to verify the signature
 * of data signed by the sender. If it is null signatures will not be verified.
 */
/*
//===================================================================
public void setKeys(EncryptionKey myPrivateKey, EncryptionKey remotePublicKey)
//===================================================================
{
	SecureDocument sd = getSecureDocument();
	sd.setKeys(myPrivateKey,remotePublicKey);
}
*/
//##################################################################
}
//##################################################################

