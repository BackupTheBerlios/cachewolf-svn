package eve.io.block.secure;
import java.io.IOException;
import java.io.OutputStream;

import eve.io.DataProcessor;
import eve.io.block.BlockOutputStream;
import eve.security.EncryptionKey;
import eve.security.SecureDocument;
import eve.util.ByteArray;
/**
* A BlockOutputStream is used to write out a block of data that is received
* by a BlockInputStream as a single block.<p>
* You can also provide an Encryptor for the Stream in which case the receiving BlockInputStream
* must also have a matching Decryptor.
**/
//##################################################################
public class SecureBlockOutputStream extends BlockOutputStream{
//##################################################################
	protected SecureDocument secureDocument;
//	-------------------------------------------------------------------
	protected synchronized SecureDocument getSecureDocument()
//	-------------------------------------------------------------------
	{
		if (secureDocument == null) secureDocument = createSecureDocument();
		return secureDocument;	
	}
//	-------------------------------------------------------------------
	protected SecureDocument createSecureDocument()
//	-------------------------------------------------------------------
	{
		return new SecureDocument();
	}
/**
* Create a BlockOutputStream using the provided OutputStream for writing
* out data.
**/
//===================================================================
public SecureBlockOutputStream(OutputStream out)
//===================================================================
{
	super(out);
}
/**
* This is used to set the dontUseCompression option for data encryption.
**/
//===================================================================
public void setDontUseCompression(boolean dontUseCompression) 
//===================================================================
{
	getSecureDocument().dontUseCompression = dontUseCompression;
}
/**
 * Explicitly set the encryptor to use.
 * @exception IOException 
 */
//===================================================================
public void setEncryptor(DataProcessor encryptor) throws IOException
//===================================================================
{
	getSecureDocument().setEncryptor(encryptor);
}
/**
 * Set the encryptor to be a new Encryptor using the specified password.
 * @exception IOException 
 */
//===================================================================
public void setEncryptor(String password) throws IOException
//===================================================================
{
	getSecureDocument().setPassword(password);
}
/**
* This forces the output stream to change its encryption. This is only
* used when a remote Public Key is available. The new encryption key is
* encrypted using the receiver's Public Key and then sent along with the data
* encrypted using that new key.
**/
//===================================================================
public void changeEncryption() throws IOException
//===================================================================
{
	getSecureDocument().changeEncryption();
}
/**
 * This is called during the writeBlock() method. If encryption of the data is
 * to be done it should encrypt the data and place it into dest and then return true.
 * If no encryption is to be done it should simply return false.
 * @param source the source data.
 * @param offset the offset of the source data bytes.
 * @param length the number of bytes to be sent.
 * @param dest a destination ByteArray that will not be null and will be cleared
 * before being passed.
 * @return true if encryption was done and the result is now in dest, false if no
 * encryption was done.
 * @exception IOException if there was an error encrypting the data.
 */
protected boolean encrypt(byte[] source,int offset,int length,ByteArray dest) throws IOException
{
	boolean usesEncryption = false;
	if (secureDocument != null)
		usesEncryption = secureDocument.hasEncryptionParameters();
	if (!usesEncryption) return false;
	else{
		SecureDocument sd = getSecureDocument();
		sd.setData(source,offset,length);
		sd.encode(dest);
		return true;
	}
}
/**
 * Set the Public/Private keys.
 * @param remotePublicKey This is the public key of the
 * receiver and the symmetric key used to encrypt each block of data will be encrypted
 * using this key. 
 * @param myPrivateKey if this is not null it will be used to sign data being transmitted.
 * If you do not want to sign outgoing data, you can leave this null.
 */
//===================================================================
public void setKeys(EncryptionKey remotePublicKey,EncryptionKey myPrivateKey)
//===================================================================
{
	SecureDocument sd = getSecureDocument();
	sd.setKeys(remotePublicKey,myPrivateKey);
}
//##################################################################
}
//##################################################################

