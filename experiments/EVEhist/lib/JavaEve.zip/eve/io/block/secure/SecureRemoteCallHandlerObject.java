/*
 * Created on Nov 23, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io.block.secure;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import eve.io.DataProcessor;
import eve.io.block.BlockInputStream;
import eve.io.block.BlockOutputStream;
import eve.io.block.RemoteCallHandlerObject;
import eve.security.Decryptor;
import eve.security.EncryptionKey;
import eve.security.Encryptor;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class SecureRemoteCallHandlerObject extends RemoteCallHandlerObject {

	/**
	 * 
	 */
	public SecureRemoteCallHandlerObject() {
		super();
	}
	/**
	 * @param in
	 * @param out
	 * @param target
	 */
	public SecureRemoteCallHandlerObject(InputStream in, OutputStream out,
			Object target, Class targetClass) {
		super(new SecureBlockInputStream(in),new SecureBlockOutputStream(out));
	}
	/**
	 * @param in
	 * @param out
	 * @param target
	 */
	public SecureRemoteCallHandlerObject(BlockInputStream in,
			BlockOutputStream out) {
		super(in, out);
	}
	private void checkSecurity()
	{
		if (!(out instanceof SecureBlockOutputStream) || !(in instanceof SecureBlockInputStream))
			throw new IllegalStateException("Communication streams are not secure.");
	}
	/**
	* Set the encryption to use for sending and receiving calls.
	**/
//	===================================================================
	public void setEncryption(DataProcessor decryptor,DataProcessor encryptor)
	throws IOException, IllegalStateException
//	===================================================================
	{
		checkSecurity();
		((SecureBlockOutputStream)out).setEncryptor(encryptor);
		((SecureBlockInputStream)in).setDecryptor(decryptor);
	}
	/**
	* Set the encryption to use for sending and receiving calls.
	**/
//	===================================================================
	public void setEncryption(String password)
	throws IOException
//	===================================================================
	{
		setEncryption(new Decryptor(password),new Encryptor(password));
	}
//	===================================================================
	public void setKeys(EncryptionKey remotePublicKey,EncryptionKey localPrivateKey)
	throws IOException
//	===================================================================
	{
		checkSecurity();
		((SecureBlockOutputStream)out).setKeys(remotePublicKey,null);
		((SecureBlockInputStream)in).setKeys(localPrivateKey,null);
	}
}

//####################################################
