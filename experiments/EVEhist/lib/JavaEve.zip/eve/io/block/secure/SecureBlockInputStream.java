package eve.io.block.secure;
import java.io.IOException;
import java.io.InputStream;

import eve.io.DataProcessor;
import eve.io.block.BlockInputStream;
import eve.io.block.UnknownEncodingException;
import eve.security.EncryptionKey;
import eve.security.SecureDocument;
import eve.util.ByteArray;
/**
* A SecureBlockInputStream is used to read in discrete blocks of data as sent by BlockOutputStream.
* The data sent by the BlockOutputStream may be Secure Documents as represented by eve.security.SecureDocument
* and this BlockInputStream will then attempt to decode and validate them using the encryption
* parameters as provided by setPassword() and setKeys().
**/
//##################################################################
public class SecureBlockInputStream extends BlockInputStream{
//##################################################################
	protected SecureDocument secureDocument;
//	-------------------------------------------------------------------
	protected synchronized SecureDocument getSecureDocument()
//	-------------------------------------------------------------------
	{
		if (secureDocument == null) secureDocument = createSecureDocument();
		return secureDocument;	
	}
//	-------------------------------------------------------------------
	protected SecureDocument createSecureDocument()
//	-------------------------------------------------------------------
	{
		return new SecureDocument();
	}
/**
* Create a SecureBlockInputStream using the provided InputStream for reading
* in data.
**/
//===================================================================
public SecureBlockInputStream(InputStream in)
//===================================================================
{
	super(in);
}

/**
* Set the decryptor to be used explicitly.
**/
//===================================================================
public void setDecryptor(DataProcessor decryptor) throws IOException
//===================================================================
{
	getSecureDocument().setDecryptor(decryptor);
}
/**
* Set the decryptor by creating a new Decryptor which uses the provided password.
**/
//===================================================================
public void setDecryptor(String password) throws IOException
//===================================================================
{
	getSecureDocument().setPassword(password);
}
/**
 * Set the Public/Private keys.
 * @param myPrivateKey This is used to decrypt the symmetric session key for each block of data.
 * @param remotePublicKey The remotePublicKey is used to verify the signature
 * of data signed by the sender. If it is null signatures will not be verified.
 */
//===================================================================
public void setKeys(EncryptionKey myPrivateKey, EncryptionKey remotePublicKey)
//===================================================================
{
	SecureDocument sd = getSecureDocument();
	sd.setKeys(myPrivateKey,remotePublicKey);
}
/**
 * This decrypts the incoming data.
 * @param data the data bytes read in.
 * @param offset the offset of the data.
 * @param length the number of bytes of data.
 * @param dest a destination ByteArray that will not be null and would have been
 * cleared before being passed here.
 * @return the destination byte array.
 * @throws UnknownEncodingException if the data could not be decoded/decrypted.
 * @throws IOException if there was a problem decrypting the data.
 */
protected void decrypt(byte[] data,int offset,int length,ByteArray dest)
throws UnknownEncodingException, IOException
{
	SecureDocument sd = getSecureDocument();
	sd.setData(data,offset,length);
	sd.decode(dest);
}

//##################################################################
}
//##################################################################

