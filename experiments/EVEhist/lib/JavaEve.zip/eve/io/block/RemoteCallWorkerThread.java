/**
 * 
 */
package eve.io.block;

import java.io.IOException;

import eve.sys.Cache;
import eve.sys.Convert;
import eve.util.ByteArray;
import eve.util.ByteEncoder;
import eve.util.Tag;
/**
 * This class is used by RemoteCallHandlerObject and is not meant to be used
 * directly.
 */
public final class RemoteCallWorkerThread implements Runnable{
	static final int FUNCTION_KEEP_ALIVE = 1;
	static final int FUNCTION_RECEIVE_CALLS = 2;
	static final int FUNCTION_REPLY_SENDER = 3;
	static final int FUNCTION_START_MULTITHREADED = 4;
	static final int FUNCTION_SEND_CALL = 5;
	static final int FUNCTION_START_TASK = 6;
	static final int FUNCTION_PROXY_INPUT = 7;
	static final int FUNCTION_PROXY_OUTPUT = 8;
	
	/**
	 * 
	 */
	private RemoteCallHandlerObject remoteCallHandlerObject;
	private RemoteCallTask task;
	private ByteArray call;
	private ByteEncoder bo;
	private int function;
	private String target;
	private RemoteCall rc;
	private ProxyStream ps;
	public RemoteCallWorkerThread()
	{
		
	}
	static RemoteCallWorkerThread getCached(RemoteCallHandlerObject forWho, int whichFunction)
	{
		RemoteCallWorkerThread rct = (RemoteCallWorkerThread)Cache.get(RemoteCallWorkerThread.class);
		rct.function = whichFunction;
		rct.remoteCallHandlerObject = forWho;
		return rct;
	}
	static RemoteCallWorkerThread getCached(RemoteCallHandlerObject forWho, RemoteCall toSend, String target)
	{
		RemoteCallWorkerThread rct = getCached(forWho,FUNCTION_SEND_CALL);
		rct.target = target;
		rct.rc = toSend;
		return rct;
	}
	static RemoteCallWorkerThread getCached(RemoteCallTask task)
	{
		RemoteCallWorkerThread rct = getCached(null,FUNCTION_START_TASK);
		rct.task = task;
		return rct;
	}
	static RemoteCallWorkerThread getCached(ProxyStream ps, boolean isInput)
	{
		RemoteCallWorkerThread rct = getCached(null,isInput ? FUNCTION_PROXY_INPUT : FUNCTION_PROXY_OUTPUT);
		rct.ps = ps;
		return rct;
	}
	//
	//
	public void run(){
		try{
			//System.out.println("Function: "+function);
			if (function == FUNCTION_KEEP_ALIVE){
				remoteCallHandlerObject.keepAliveRun();
			}else if (function == FUNCTION_PROXY_INPUT){
				ps.localReadThread();
			}else if (function == FUNCTION_PROXY_OUTPUT){
				ps.localWriteThread();
			}else if (function == FUNCTION_SEND_CALL){
				remoteCallHandlerObject.sendCall(rc, target);
			}else if (function == FUNCTION_START_TASK){
				task.waitUntilHandlerStops();
			}else if (function == FUNCTION_REPLY_SENDER){
					remoteCallHandlerObject.replySenderRun();
			}else if (function == FUNCTION_START_MULTITHREADED){
				remoteCallHandlerObject.startMultiThreaded();
			}else if (function == FUNCTION_RECEIVE_CALLS){
				if (call == null) call = new ByteArray();
				if (bo == null) bo = new ByteEncoder();
				synchronized(this.remoteCallHandlerObject.readThread){
					try{
						call.length = 0;
						if (false) throw new IOException();
						call = this.remoteCallHandlerObject.getData(call);
						if (call == null) {
							this.remoteCallHandlerObject.close(); //Must be closed.
							return;
						}
						//int added = Vm.countObjects(false)-numObjects;
						//if (added != 0) Vm.debug("Added: "+added);
						//else Vm.debug("None added!");
					}catch(IOException e){
						this.remoteCallHandlerObject.readError = e;
						return;
					}finally{
						this.remoteCallHandlerObject.readIn = true;
						this.remoteCallHandlerObject.readThread.notify();
					}
				}
				this.remoteCallHandlerObject.keepAlive.reset();
				//
				// Now handle the call, outside of the synchronized block.
				//
				callReceived();
				//System.out.println("RX: "+call.toString());
			}
		}finally{
			task = null;
			remoteCallHandlerObject = null;
			rc = null;
			target = null;
			Cache.put(this);
		}
	}
	//
	
	private boolean callReceived()
	{
		ByteArray received = call;
		try{
			String callId = bo.decodeStringField(received,"<id>");
			String call = bo.decodeStringField(received,"<c>");
			if (call != null){
				int id = Convert.toInt(callId) | 0x80000000;
				Tag tg = null;
				try{
					RemoteCall rc = new RemoteCall(received.data,0,received.length);
					Object target = this.remoteCallHandlerObject.findTarget((String)bo.decodeObjectField(received,"<t>"));
					if (target == null) return false;
					tg = new Tag();
					tg.value = rc;
					tg.tag = id;
					this.remoteCallHandlerObject.pendingInvokes.add(tg); // Requires add to be synchronized (it is).
					ByteArray te = this.remoteCallHandlerObject.doInvoke(target,rc);
					bo.encodeField(te,"<r>","");
					bo.encodeField(te,"<id>",callId);
					this.remoteCallHandlerObject.queueSend(te,id,false);
					this.remoteCallHandlerObject.pendingInvokes.remove(tg);
					return true;
				}catch(Throwable t){
					ByteArray te = new ByteArray();
					RemoteCall.encodeException(bo,t,te,true);
					bo.encodeField(te,"<r>","");
					bo.encodeField(te,"<id>",callId);
					this.remoteCallHandlerObject.queueSend(te,id,false);
					if (tg != null) this.remoteCallHandlerObject.pendingInvokes.remove(tg);
					return true;
				}
			}
			/*
			String send = bo.decodeStringField(received,"<send>");
			String close = bo.decodeStringField(received,"<close>");
			if (send != null || close != null)try{ //Remote entity has sent data to a stream.
				Stream s = (Stream)this.remoteCallHandlerObject.streams.get(callId);
				if (s == null) {
					throw new IOException("No such stream.");
				}else if (send != null){
					//sendNonCall(bo,emptyByteArray,"<sent>",callId,null);
					byte[] got = (byte[])bo.decodeObjectField(received,"<data>");
					//s.getOutputStream().write(got);
					int wrote = s.nonBlockingWrite(got, 0, got.length);
					if (wrote == got.length)
						this.remoteCallHandlerObject.sendNonCall(bo,RemoteCallHandlerObject.emptyByteArray,"<r>",callId,null);
					else{
						ByteArray ba = new ByteArray();
						bo.encodeField(ba,"<ret>",new Wrapper().setInt(wrote));
						this.remoteCallHandlerObject.sendNonCall(bo,ba,"<r>",callId,null);
					}
				}else if (close != null){
					//s.getOutputStream().close();
					s.close();
					//this.remoteCallHandlerObject.streams.remove(callId);
					this.remoteCallHandlerObject.sendNonCall(bo,RemoteCallHandlerObject.emptyByteArray,"<r>",callId,null);
				}
				return true;
			}catch(IOException e){
				this.remoteCallHandlerObject.sendNonCall(bo,RemoteCallHandlerObject.emptyByteArray,"<r>",callId,e);
				return true;
			}
			*/
			String reply = (String)bo.decodeObjectField(received,"<r>");
			if (reply != null){
				String id = callId;
				if (id != null) {
					RemoteCall rc = null;
					synchronized(this.remoteCallHandlerObject.sent){
						for (int i = 0; i<this.remoteCallHandlerObject.sent.size(); i++){
							rc = (RemoteCall)this.remoteCallHandlerObject.sent.get(i);
							if (rc.id.equals(id)){
								this.remoteCallHandlerObject.sent.removeElementAt(i);
								//System.out.println("rc has replied!");
								break;
							}
							rc = null;
						}
					}
					if (rc != null) rc.reply(received);
				}
				return true;
			}
			return false;
		}catch(Exception e){
			//e.printStackTrace();
			return false;
		}finally{
			//System.out.println("Call Done");
		}
	}
}