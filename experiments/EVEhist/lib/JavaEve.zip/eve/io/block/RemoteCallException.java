package eve.io.block;

import eve.sys.RemoteMethodException;

//##################################################################
public class RemoteCallException extends RemoteMethodException{
//##################################################################

public RemoteCall call;
//-------------------------------------------------------------------
public RemoteCallException(RemoteCall rc,Throwable error,String message)
//-------------------------------------------------------------------
{
	super(message,error);
	this.call = rc;
}
//===================================================================
public RemoteCallException(Throwable cause) {super(cause);}
//===================================================================
public RemoteCallException(String message,Throwable cause) {super(message,cause);}
//===================================================================

//##################################################################
}
//##################################################################

