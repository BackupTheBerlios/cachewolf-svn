/*
 * Created on Nov 23, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io.block;

import java.io.IOException;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class UnknownEncodingException extends IOException {

	/**
	 * 
	 */
	public UnknownEncodingException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public UnknownEncodingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

//####################################################
