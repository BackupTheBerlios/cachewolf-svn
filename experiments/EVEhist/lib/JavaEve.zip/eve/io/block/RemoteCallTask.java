package eve.io.block;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Socket;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import eve.io.MemoryStream;
import eve.sys.Reflection;
import eve.sys.RemoteInterface;
import eve.sys.RemoteMethodException;
import eve.sys.TimedOutException;
import eve.sys.Wrapper;
import eve.util.WeakCache;

/**
* This class was useful before the java.lang.reflect.Proxy class was introduced.
* Now, to handle RemoteCalls it is easier to use the RemoteProxy object instead.
* <p>
* A RemoteCallTask provides an easy way to create an object that is to be controlled
* remotely via RemoteCalls, or to act as a local proxy for a remote object that will be
* controlled via RemoteCalls.
<p>
The usual way to use this is to construct it using a Steaming connection that has been
made between the two communicating entities and then provide methods for servicing the
remote calls. That is to say, the default method of setup is to have incoming remote
calls be invoked on this very object.

**/

//##################################################################
public class RemoteCallTask implements InvocationHandler{
//##################################################################
/**
* This is the handler used for incoming/outgoing calls. It is created using
* one of the start methods, or you can set it explicitly.
**/
public RemoteCallHandlerObject handler;

/**
 * If you are using the createProxy() method, this is the ClassLoader
 * that is used to create the proxy. If you keep it as null it will default
 * to being the System ClassLoader or all registered class loaders.
 */
public ClassLoader proxyClassLoader;
/**
 * Create a new RemoteCallTask. You will need to call one of the start() methods before
 * you can use it.
 */
//===================================================================
public RemoteCallTask()
//===================================================================
{
	
}
/**
 * Create a new RemoteCallTask that automatically calls start() with the specified streams and
 * target object.
* @param in the input stream to the remote application.
* @param out the output stream to the remote application.
* @param target The target object that incoming remote calls will be invoked on. If it is null
* then incoming remote calls will be invoked on this object.
*/
//===================================================================
public RemoteCallTask(InputStream in, OutputStream out, Object target, Class targetClass)
//===================================================================
{
	start(in,out,target,targetClass);
}
/**
 * Create a new RemoteCallTask that automatically calls start() with the specified streams.
	Incoming remote calls will be invoked on this object.
* @param in the input stream to the remote application.
* @param out the output stream to the remote application.
* @param target The target object that incoming remote calls will be invoked on.
*/
//===================================================================
public RemoteCallTask(InputStream in, OutputStream out)
//===================================================================
{
	start(in,out,this,null);
}
/**
 * Create a new RemoteCallTask that automatically calls start() with the specified streams and
 * target object.
* @param in the input stream to the remote application.
* @param out the output stream to the remote application.
* @param target The target object that incoming remote calls will be invoked on. If it is null
* then incoming remote calls will be invoked on this object.
*/
//===================================================================
public RemoteCallTask(BlockInputStream in, BlockOutputStream out, Object target, Class targetClass)
//===================================================================
{
	start(in,out,target,targetClass);
}
/**
 * Create a new RemoteCallTask that automatically calls start() with the specified streams.
	Incoming remote calls will be invoked on this object.
* @param in the input stream to the remote application.
* @param out the output stream to the remote application.
* @param target The target object that incoming remote calls will be invoked on.
*/
//===================================================================
public RemoteCallTask(BlockInputStream in, BlockOutputStream out)
//===================================================================
{
	start(in,out,this,null);
}
//
// Called by RemoteCallWorkerThread
//
void waitUntilHandlerStops()
{
	handler.waitUntilCompletion();
	connectionClosed();
}
/**
 * Start using a predefined handler.
 */
//===================================================================
public void start(final RemoteCallHandlerObject handler, boolean startMultiThreaded)
//===================================================================
{
	this.handler = handler;
	if (startMultiThreaded || RemoteCallHandlerObject.alwaysMultiThreaded){
		handler.start();
		handler.addTask(RemoteCallWorkerThread.getCached(this));
	}
}
/**
 * Start in multithreaded mode.
 * @param handler the handler for the Task.
 */
public void start(RemoteCallHandlerObject handler)
{
	start(handler,true);
}
/**
 * Run and don't return until the RemoteCallTask has closed (due to the connection
 * being closed).
 */
public void run(final RemoteCallHandlerObject handler)
{
	this.handler = handler;
	handler.start();
	handler.waitUntilCompletion();
	connectionClosed();
}
/**
* Start the RemoteCallHandler - only use this if you used the default constructor.
* @param in the input stream to the remote application.
* @param out the output stream to the remote application.
* @param target The target object that incoming remote calls will be invoked on. If it is null
* then incoming remote calls will be invoked on this object.
 */
//===================================================================
public void start(InputStream in, OutputStream out, Object targetObject,Class targetClass)
//===================================================================
{
	RemoteCallHandlerObject r = new RemoteCallHandlerObject(in,out);
	r.addTarget(null,targetObject == null ? this : targetObject,targetClass);
	start(r);
}
/**
* Start the RemoteCallHandler - only use this if you used the default constructor.
* @param in the input stream to the remote application.
* @param out the output stream to the remote application.
* @param target The target object that incoming remote calls will be invoked on. If it is null
* then incoming remote calls will be invoked on this object.
 */
//===================================================================
public void start(BlockInputStream in,BlockOutputStream out, Object targetObject,Class targetClass)
//===================================================================
{
	RemoteCallHandlerObject r = new RemoteCallHandlerObject(in,out);
	r.addTarget(null,targetObject == null ? this : targetObject,targetClass);
	start(r);
}
/**
* Get a new RemoteCall to be invoked on the object on the other side of the
* connection. You can use the call() method on the returned RemoteCall.
* @param method The full encoded method name and parameters.
* @return a new RemoteCall to be invoked on the object on the other side.
*/
//===================================================================
public RemoteCall newCall(String method)
//===================================================================
{
	RemoteCall rc = new RemoteCall(method);
	rc.myHandler = handler;
	return rc;
}
/**
* Get a new RemoteCall to be invoked on the object on the other side of the
* connection. You can use the call() method on the returned RemoteCall.
* @param method A method matching the method to be called on the other side.
* @return a new RemoteCall to be invoked on the object on the other side.
*/
public RemoteCall newCall(Method method)
{
	return newCall(Reflection.getEncodedMethod(method));
}
/**
* Get a new RemoteCall to be invoked on the object on the other side of the
* connection. You can use the call() method on the returned RemoteCall.
* @param methodName the name of the method.
* @param parameterTypes the parameter types.
* @param returnType the return type of the method.
* @return a new RemoteCall to be invoked on the object on the other side.
 */
public RemoteCall newCall(String methodName, Class[] parameterTypes, Class returnType)
{
	return newCall(Reflection.getEncodedMethod(methodName,parameterTypes,returnType));
}

/**
* This gets called when the connection between the two RemoteHandlers is
* closed. You must override this to do something useful.
**/
//-------------------------------------------------------------------
protected void connectionClosed()
//-------------------------------------------------------------------
{
	
}
/**
* Close the handler, and the stream.
**/
//===================================================================
public void close()
//===================================================================
{
	handler.close();
	handler.closeConnection();
}

private WeakCache proxies = new WeakCache(){
	protected void valuesRemoved(Vector v){
		for (Iterator it = v.iterator(); it.hasNext();){
			String nm = (String)it.next();
			//System.out.println("Removed: "+nm);
			RemoteCall rc = newCall("freeProxy(Ljava/lang/String;)V");
			rc.add(nm);
			handler.call(rc, "*");
		}
	}
};

/*
 * This keeps track of whether methods have any RemoteInterface objects.
 */
private static Hashtable remoteMethods = new Hashtable();

private synchronized static Class[] getMethodProxyParameters(Method m)
{
	Class[] got = (Class[])remoteMethods.get(m);
	if (got != null) return got;
	Class[] all = m.getParameterTypes();
	boolean hasOne = false;
	got = new Class[all.length];
	for (int i = 0; i<all.length; i++){
		Class c = all[i];
		if (
				c.equals(InputStream.class) || c.equals(OutputStream.class)||
				(c.isInterface() && RemoteInterface.class.isAssignableFrom(c))){
			hasOne = true;
			got[i] = c;
		}
			 
	}
	if (!hasOne) got = new Class[0];
	remoteMethods.put(m,got);
	return got;
}

private int proxyCount = 0;

Object findLocalProxy(String name)
{
	return proxies.getKeyForValue(name);
}
Wrapper toProxy(Wrapper w) throws ClassNotFoundException
{
	ProxyHolder obj = (ProxyHolder)w.getObject(ProxyHolder.class);
	if (obj == null) return w;
	else{
		//System.out.println("Switch to multiThreaded 2: "+System.identityHashCode(handler));
		handler.switchToMultiThreaded();
		Class c = Reflection.forName(obj.interfaceName);
		if (c == null) throw new ClassNotFoundException();
		synchronized(this){
			Object pxy = findLocalProxy(obj.targetObject);
			if (pxy == null) {
				if (c.equals(InputStream.class))
					pxy = connectToRemoteInputStream(obj.targetObject, "stream:"+(++proxyCount));
				else if (c.equals(OutputStream.class))
					pxy = connectToRemoteOutputStream(obj.targetObject, "stream:"+(++proxyCount));
				else
					pxy = createProxy(c, obj.targetObject); 
			}
			w.setObject(pxy);
		}
	}
	return w;
}
Wrapper toOutgoingRemoteInterface(Class returnClass, Wrapper w)
{
	if (w.getType() != w.OBJECT) return w;
	Object ri = null;
	if (returnClass.isInterface()) w.getObject(RemoteInterface.class);
	if (ri == null && returnClass.equals(InputStream.class)) ri = w.getObject(InputStream.class);
	if (ri == null && returnClass.equals(OutputStream.class)) ri = w.getObject(OutputStream.class);
	if (ri == null) return w;
	w.setObject(outgoingRemoteInterface(returnClass, ri));
	return w;
}

Object outgoingRemoteInterface(Class inter, Object obj)
{
	if (obj == null) return obj;
	int count = 0;
	ProxyHolder ph = null;
	synchronized(this){
		for (Iterator e = handler.targets.entrySet().iterator(); ph == null && e.hasNext();){
			Map.Entry me = (Map.Entry)e.next();
			if (me.getValue() == obj){
				String ky = (String)me.getKey();
				if (!ky.startsWith("proxy:"))
					continue;
				ph = new ProxyHolder();
				ph.interfaceName = inter.getName();
				ph.targetObject = ky;
			}
		}
		if (ph == null){
			count = ++proxyCount;
			ph = new ProxyHolder();
			ph.interfaceName = inter.getName();
			ph.targetObject = "proxy:"+count;
			if (inter.equals(InputStream.class))
				createServerInputStream((InputStream)obj,ph.targetObject);
			else if (inter.equals(OutputStream.class))
				createServerOutputStream((OutputStream)obj,ph.targetObject);
			else
				handler.addTarget(ph.targetObject, obj, inter);
		}
	}
	handler.switchToMultiThreaded();
	return ph;
}

private Object[] modifyParameters(Method m, Object[] args)
{
	Class[] got = getMethodProxyParameters(m);
	if (got == null || got.length == 0 || got.length != args.length) return args;
	Object[] ret = new Object[args.length];
	for (int i = 0; i<ret.length; i++){
		Class c = got[i];
		if (c == null || args[i] == null) ret[i] = args[i];
		else ret[i] = outgoingRemoteInterface(c,args[i]);
	}
	return ret;
}
//##################################################################
/* (non-Javadoc)
 * @see java.lang.reflect.InvocationHandler#invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[])
 */
public Object invoke(Object proxy, Method method, Object[] args) throws Throwable 
{
	//
	Wrapper w = Reflection.handleProxyObjectMethod(proxy,method,args);
	if (w != null) return w.toJavaWrapper();
	//
	String nm = method.getName();
	RemoteCall rc = newCall(method);
	args = modifyParameters(method, args);
	//int v = Vm.getTrackKey(rc);
	rc.setParameters(args);
	try{
		//System.out.println("RC+ "+method);
		w = toProxy(rc.call((String)proxies.get(proxy)));
		//System.out.println("RC- "+method);
		return w.toJavaWrapper();
	}catch(RemoteMethodException e){
		throw e;
	}catch(InvocationTargetException e){
		Throwable t = e.getTargetException();
		t.fillInStackTrace();
		if (t != null && Reflection.methodThrows(method,t))
			throw t;
		throw new RemoteCallException("The server responded with exception: "+t,t);
	}catch(TimedOutException e){
		throw new RemoteCallException(method.getName()+"() timed out.",e);
	/*
	}catch(Throwable e){
		System.out.println("rc.call() threw: ");
		e.printStackTrace();
		throw new RemoteCallException(e);
	*/
	}catch(Throwable t){
		throw t;
	}
}
/**
 * Create a Proxy for the specified interface that will operate by making
 * remote calls over this RemoteCallTask. The returned object can be cast
 * to the specified interface class.
 * @param interf the interface implemented by the proxy.
 * @param targetName the name of the target object on the remote connection.
 * @return a Proxy object implementing the interface.
 */
public Object createProxy(Class interf, String targetName)
{
	Object got = Reflection.newProxyInstance(proxyClassLoader,new Class[]{interf},this);
	if (targetName != null) proxies.put(got,targetName); 
	return got;
}
/**
 * Create a Proxy for the specified interface that will operate by making
 * remote calls over this RemoteCall. The returned object can be cast
 * to the specified interface class.
 * @param interfaces the interfaces implemented by the proxy.
 * @param targetName the name of the target object on the remote connection.
 * @return a Proxy object implementing the interfaces.
 */
public Object createProxy(Class[] interfaces, String targetName)
{
	Object got = Reflection.newProxyInstance(proxyClassLoader,interfaces,this);
	if (targetName != null) proxies.put(got,targetName);
	return got;
}
/**
 * Create a Proxy for the specified interface that will operate by making
 * remote calls over this RemoteCall, to the default
 * target object. The returned object can be cast
 * to the specified interface class.
 * @param interf the interface implemented by the proxy.
 * @return a Proxy object implementing the interfaces.
 */
public Object createProxy(Class interf)
{
	return createProxy(interf,null);
}
/**
 * Create two RemoteCallTask objects connected via MemoryStreams.
 * @param target1 the Object that will have calls invoked on in the first
 * created RemoteCallTask.
 * @param target1Class the Class to use for finding methods on Target1.
 * If this is null then getClass() will be used on target1 to determine the class.
 * @param target2 the Object that will have calls invoked on in the second
 * created RemoteCallTask.
 * @param target2Class the Class to use for finding methods on Target2.
 * If this is null then getClass() will be used on target2 to determine the class.
 * @return an array of two RemoteCallTasks.
 */
public static RemoteCallTask[] createTest(Object target1, Class target1Class, Object target2, Class target2Class)
{
	Object[] clientToServer = MemoryStream.pipe(0);
	Object[] serverToClient = MemoryStream.pipe(0);
	RemoteCallTask client = new RemoteCallTask();
	client.start((InputStream)clientToServer[0],(OutputStream)serverToClient[1],target1,target1Class);
	RemoteCallTask server = new RemoteCallTask();
	server.start((InputStream)serverToClient[0],(OutputStream)clientToServer[1],target2,target2Class);
	return new RemoteCallTask[]{client,server};
}
/**
 * Make and start a connection between two RemoteCall tasks. They
 * are connected via MemoryStreams.
 * @param one the first RemoteCallTask.
 * @param two the second RemoteCallTask.
 */
public static void connect(RemoteCallTask one, RemoteCallTask two)
{
	Object[] clientToServer = MemoryStream.pipe(0);
	Object[] serverToClient = MemoryStream.pipe(0);
	RemoteCallTask client = one;
	client.start((InputStream)clientToServer[0],(OutputStream)serverToClient[1],null,null);
	RemoteCallTask server = two;
	server.start((InputStream)serverToClient[0],(OutputStream)clientToServer[1],null,null);
}
/**
 * Create a RemoteCallTask that can be used for creating proxies for interfaces which
 * are then called using a single Thread only.
 * @param input - this can be an InputStream, a BlockInputStream or a Socket.
 * @param output - this can be an OutputStream, a BlockOutputStream or a Socket.
 * @return a RemoteCallTask used for creating proxies for use by a single Thread.
 */
public static RemoteCallTask createProxyClient(Object input, Object output) throws IOException
{
	RemoteCallTask rt = new RemoteCallTask();
	BlockInputStream in = null;
	BlockOutputStream out = null;
	if (input instanceof BlockInputStream) in = (BlockInputStream)input;
	else if (input instanceof InputStream) in = new BlockInputStream((InputStream)input);
	else if (input instanceof Socket) in = new BlockInputStream(((Socket)input).getInputStream());
	else throw new IllegalArgumentException();
	if (output instanceof BlockOutputStream) out = (BlockOutputStream)output;
	else if (output instanceof OutputStream) out = new BlockOutputStream((OutputStream)output);
	else if (output instanceof Socket) out = new BlockOutputStream(((Socket)output).getOutputStream());
	else throw new IllegalArgumentException();
	rt.handler = new RemoteCallHandlerObject(in,out); 
	return rt;
}
/**
 * Create a RemoteCallTask that can be used for creating proxies for interfaces which
 * are then called using a single Thread only.
 * @param input - this can be an InputStream, a BlockInputStream or a Socket.
 * @param output - this can be an OutputStream, a BlockOutputStream or a Socket.
 * @return a RemoteCallTask used for creating proxies for use by a single Thread.
 */
public static RemoteCallTask createProxyClient(Socket connection) throws IOException
{
	return createProxyClient(connection,connection);
}
public void createServerInputStream(InputStream local, String name)
{
	ProxyStream ps = new ProxyStream(this,local,name);
	handler.addTarget(name,ps,ProxyStream.class);
}
public void createServerOutputStream(OutputStream local, String name)
{
	ProxyStream ps = new ProxyStream(this,local,name);
	handler.addTarget(name,ps,ProxyStream.class);
}
public InputStream connectToRemoteInputStream(String remoteName,String myName)
{
	ProxyStream ps = new ProxyStream(this,remoteName,myName);
	handler.addTarget(myName,ps,ProxyStream.class);
	return ps.getInputStream();
}
public OutputStream connectToRemoteOutputStream(String remoteName,String myName)
{
	ProxyStream ps = new ProxyStream(this,remoteName,myName);
	handler.addTarget(myName,ps,ProxyStream.class);
	return ps.getOutputStream();
}

}
//##################################################################

