package eve.io.block;

import eve.util.Encodable;
/**
 * This is used internally by the RemoteCall system.
 */
public class ProxyHolder implements Encodable{

	public String interfaceName;
	public String targetObject;
	
	public String toString() {return targetObject+" implements: "+interfaceName;}
}
