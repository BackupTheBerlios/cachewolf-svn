package eve.io.block;

import java.io.IOException;

public class BlockTooBigException extends IOException {

	int blockSize;
	
	public BlockTooBigException(int size) {
		super("Block size too large: "+size);
		blockSize = size;
	}

	public BlockTooBigException(String message, int size) {
		super(message);
		blockSize = size;
	}

}
