/*
 * Created on Jul 29, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface FileConstants {
	/**
	* The file system is a DOS/Windows type system.
	**/
	public static final int DOS_SYSTEM = 1;
	/**
	* The file system is a Unix/Linux type system.
	**/
	public static final int UNIX_SYSTEM = 2;
	/**
	* The file system is a PalmOS type system - whatever that may be.
	**/
	public static final int PALM_SYSTEM = 3;
	/**
	* The file system is temporary memory based system.
	**/
	public static final int MEMORY_SYSTEM = 4;
	/** Used with getIcon() */
	public static final int OpenFolderIcon = 1;
	/** Used with getIcon() */
	public static final int ClosedFolderIcon = 2;
	/** Used with getIcon() */
	public static final int PageIcon = 3;
	/** Used with getIcon() */
	public static final int FileIcon = 5;
	/** Used with getIcon() */
	public static final int DriveIcon = 4;
	public static final char separatorChar = java.io.File.separatorChar;//(char)Vm.getParameter(Vm.VM_FILE_SEPARATOR);
	public static final char pathSeparatorChar = java.io.File.pathSeparatorChar;//(char)Vm.getParameter(Vm.VM_PATH_SEPARATOR);
	public static final String separator = java.io.File.separator;//new String(new char[]{separatorChar});
	public static final String pathSeparator = java.io.File.pathSeparator;//new String(new char[]{pathSeparatorChar});
	/**
	* Used with getInfo().
	* This requests the default version of the icon for the file - as an IImage object. 
	* sourceParameters - none
	* options - INFO_OPTION_ICON_SMALL, INFO_OPTION_ICON_MEDIUM, INFO_OPTION_ICON_LARGE.
	* Use getObject() on the Wrapper returned by getInfo() to get
	* the icon as an IImage object.
	* That value will be null if no icon was found.
	**/
	public static final int INFO_ICON = 0x1;
	/**
	* An <b>option</b> used with INFO_ICON and getInfo().
	* This requests the small version of the icon for the file - as an IImage object. 
	* Use getObject() on the Wrapper returned by getInfo() to get
	* the icon as an IImage object.
	* That value will be null if no icon was found.
	**/
	public static final int INFO_OPTION_ICON_SMALL = 0x1;
	/**
	* An <b>option</b> used with INFO_ICON and getInfo().
	* This requests the medium version of the icon for the file - as an IImage object. 
	* Use getObject() on the Wrapper returned by getInfo() to get
	* the icon as an IImage object.
	* That value will be null if no icon was found.
	**/
	public static final int INFO_OPTION_ICON_MEDIUM = 0x2;
	/**
	* An <b>option</b> used with INFO_ICON and getInfo().
	* This requests the large version of the icon for the file - as an IImage object. 
	* Use getObject() on the Wrapper returned by getInfo() to get
	* the icon as an IImage object.
	* That value will be null if no icon was found.
	**/
	public static final int INFO_OPTION_ICON_LARGE = 0x3;
	/**
	* Used with getInfo().
	* This requests the names of the root directory of all drives - as an array of Strings.
	* sourceParameters - none
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get
	* the root devices as an array of Strings.
	* That value will be null if this is not supported (e.g. under WinCE or Unix/Linux) 
	* this implies that there is only one root i.e. "/"
	**/
	public static final int INFO_ROOT_LIST = 0x2;
	/**
	* NOT IMPLEMENTED YET.
	* Used with getInfo().
	* If this File is considered a link/shortcut to another file or directory, this will return
	* the name of the target file/directory, otherwise it will return null.
	* sourceParamerters - none
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get the file linked to as
	* a String, or null if it is not a link.
	**/
	public static final int INFO_LINK_DESTINATION = 0x3;
	/**
	* Used with getInfo().
	* This retrieves a String which is the directory where the running application is installed. Under Java,
	* if this cannot be determined, then the current working directory is returned. This is provided
	* because there is no concept of "Current Working Directory" in WindowsCE.
	* sourceParamerters - none
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get the name of the directory.
	**/
	public static final int INFO_PROGRAM_DIRECTORY = 0x4;
	/**
	* Used with getInfo().
	* This retrieves a String which is the directory where temporary files can be created.
	* sourceParamerters - none
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get the name of the directory.
	**/
	public static final int INFO_TEMPORARY_DIRECTORY = 0x5;
	/**
	* Used with getInfo().
	* This retrieves a String which is the name of the device or computer.
	* sourceParamerters - none
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get the name of the computer.
	**/
	public static final int INFO_DEVICE_NAME = 0x6;
	/**
	* Used with getInfo().
	* This gets a set of File or device specific flags. For FLAG_SLOW_ACCESS indicates that directory
	* access/listing on this device is very slow (e.g. over a serial line).
	* sourceParamerters - none
	* options - none defined yet.
	* Use getInt() on the Wrapper returned by getInfo() to get the flags.
	**/
	public static final int INFO_FLAGS = 0x7;

	public static final int FLAG_SLOW_LIST = 0x10;
	public static final int FLAG_SLOW_CHILD_COUNT = 0x20;
	/**
	* This is a flag returned from getInfo(INFO_FLAGS);
	**/
	public static final int FLAG_SLOW_ACCESS = FLAG_SLOW_LIST|FLAG_SLOW_CHILD_COUNT;
	/**
	* This is a flag returned from getInfo(INFO_FLAGS);
	* @deprecated - use getPermissionsAndFlags() and setPermissionsAndFlags()
	**/
	public static final int FLAG_READ_ONLY = 0x2;
	/**
	* This is a flag returned from getInfo(INFO_FLAGS);
	**/
	public static final int FLAG_FILE_SYSTEM_IS_READ_ONLY = 0x4;
	/**

	* This is a flag returned from getInfo(INFO_FLAGS);
	**/
	public static final int FLAG_CASE_SENSITIVE = 0x8;

	/**
	* Used with getInfo().
	* This returns an IImage representing the device on which the file is stored.
	* sourceParamerters - none
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get the icon for the device.
	**/
	public static final int INFO_DEVICE_ICON = 0x8;
	/**
	* Used with getInfo().
	* This returns a the number of free bytes on the disk.
	* sourceParamerters - none
	* options - none defined yet.
	* Use getLong() on the Wrapper returned by getInfo() to get the free space on the device
	* or -1 if the value could not be determined.
	**/
	public static final int INFO_FREE_DRIVE_SPACE = 9;
	/**
	* Used with getInfo().
	* This returns a the total number of bytes on the disk.
	* sourceParamerters - none
	* options - none defined yet.
	* Use getLong() on the Wrapper returned by getInfo() to get the space on the device
	* or -1 if the value could not be determined.
	**/
	public static final int INFO_TOTAL_DRIVE_SPACE = 10;
	/**
	* Used with getInfo().
	* This should return an array of Strings giving the details to display about a file in the filechooser box. It
	* will not include the name of the file - which is always displayed.
	* sourceParamerters - none
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get the detail names as an array
	* of Strings.
	**/
	public static final int INFO_DETAIL_NAMES = 11;
	/**
	* Used with getInfo().
	* This should return EITHER an array of ints giving the width of each detail column (except for name) or an
	* array of Strings which represent the widest string expected for each column. You should provide a PropertyList 
	* with an entry for "fontMetrics" being the FontMetrics being used by the table.
	* sourceParamerters - a PropertyList object with an entry for "fontMetrics" being the FontMetrics being used by the table. 
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get the detail widths as an array
	* of int values or an array of String values.
	**/
	public static final int INFO_DETAIL_WIDTHS = 12;
	/**
	* Used with getInfo().
	* This should return a String representing a "tool-tip" to display for a file in the Filechooser box.
	* sourceParamerters - none
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get the tool-tip as a String.
	**/
	public static final int INFO_TOOL_TIP = 13;
	/**
	* Used with getInfo().
	* This should return a String a particular detail for the file.
	* sourceParamerters - none
	* options - the index of the detail required starting from 0.
	* Use getObject() on the Wrapper returned by getInfo() to get the detail as a String value.
	**/
	public static final int INFO_DETAILS = 14;
	/**
	* Used with getInfo()/setInfo().
	* This is used to get/set the owner of a file. The object returned with getInfo() is dependent
	* on the operating system, but if toString() is called on the returned object it will return
	* a value that equates to the user name of the owner (as on Unix) systems. 
	* sourceParamerters - none
	* options - none defined yet.
	* Use getObject() on the Wrapper returned by getInfo() to get the owner name as an object value.
	**/
	public static final int INFO_OWNER = 15;
	/**
	* This is used to get/set the three file times for a file - the creation date, the last modification date
	* and the last access date, in that order. <p>For a getInfo() operation the resultDestination wrapper should 
	* be set to an array of 3 Time objects, each of which _may_ be null. On return the dates that are available on that system will
	* be placed in the array in the order shown. If any of the values are 0 then that date is unknown on the system.
	* <p>With a setInfo() operation the sourceParameter should again be an array of 3 Time objects, with
	* with any value that you do not wish to set being null.
	* sourceParamerters - none
	**/
	public static final int INFO_FILE_TIMES = 16;
	/**
	* This is used to get/set the group of a file. The object returned with getInfo() is dependent
	* on the operating system, but if toString() is called on the returned object it will return
	* a value that equates to the user name of the group (as on Unix) systems. If getInfo() returns
	* null this indicates that the OS does not keep group information on files.
	**/
	public static final int INFO_GROUP = 17;
	/**
	* Used for getting the file system type. Use null sourceParameters and resultDestination.
	* The value returned by getInfo() will be a ewe.sys.Long which holds one of the FileSys.XXX_SYSTEM
	* values - or null if the type could not be determined.
	**/
	public static final int INFO_SYSTEM_TYPE = 18;
	/**
	 * If the file is a symbolic link, return the target of the file.
	 */
	public static final int INFO_SYMBOLIC_LINK_TARGET = 19;

	public static final int INFO_SET_USER_AND_GROUP = 20;
	
	static final int INFO_CREATE_TEMP = 21;
	
	/**
	 * This value is zero indicating that it is the default list sorting criteria.
	 */
	public static final int LIST_BY_NAME = 0x0; 
	/**
	 * This value is zero indicating that it is the default list directory handling criteria.
	 */
	public static final int LIST_DIRECTORIES_FIRST = 0x0;
	public static final int LIST_DESCENDING = 0x1;
	public static final int LIST_DIRECTORIES_LAST = 0x2;
	public static final int LIST_DIRECTORIES_ONLY = 0x4;
	public static final int LIST_FILES_ONLY = 0x8;
	public static final int LIST_BY_DATE = 0x10;
	public static final int LIST_BY_TYPE = 0x20;
	public static final int LIST_DONT_SORT = 0x40;
	/**
	* This option treats directories and files as being the same.
	**/
	public static final int LIST_IGNORE_DIRECTORY_STATUS = 0x80;
	/**
	* This option lists all directories even if they don't match the supplied
	* mask.
	**/
	public static final int LIST_ALWAYS_INCLUDE_DIRECTORIES = 0x100;
	/**
	* This option request that only a check for matching children is done, rather
	* than a listing. It will cause list() to behave as follows:
	* No matching children = return null.
	* At least one child = return a String array of 0 length.
	**/
	public static final int LIST_CHECK_FOR_ANY_MATCHING_CHILDREN = 0x200;
	public static final int LIST_BY_SIZE = 0x400;
	public static final int LIST_DONT_LIST_HIDDEN_FILES = 0x800;

}
//####################################################
