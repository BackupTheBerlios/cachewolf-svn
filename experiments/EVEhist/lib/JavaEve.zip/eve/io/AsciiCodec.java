/*
 * Created on Apr 3, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.IOException;

import eve.util.ByteArray;
import eve.util.CharArray;
//####################################################
public class AsciiCodec extends TextCodecObject {
	/**
	* This is a creation option. It specifies that CR characters should be removed when
	* encoding text into UTF.
	**/
	public static final int STRIP_CR_ON_DECODE = _STRIP_CR_ON_DECODE;
	/**
	* This is a creation option. It specifies that CR characters should be removed when
	* decoding text from UTF.
	**/
	public static final int STRIP_CR_ON_ENCODE = _STRIP_CR_ON_ENCODE;
	/**
	* This is a creation option. It specifies that CR characters should be removed when
	* decoding text from UTF AND encoding text to UTF.
	**/
	public static final int STRIP_CR = STRIP_CR_ON_DECODE|STRIP_CR_ON_ENCODE;
// <ta>
	/**
	* This is a creation option. It specifies that CR characters should be added 
	* before every LF when encoding text into ASCII.
	**/
	public static final int ADD_CR_ON_ENCODE = 0x4;
	/** This is the length of the dest array
	 */
	protected int destlength;
	/** Overriding native call
	 */
	static boolean hasNative;
	/** This is the version of the class
	 */
	private static String stVersion = "2.0";
// </ta>

	/* (non-Javadoc)
	 * @see eve.io.TextCodec#encodeText(char[], int, int, boolean, eve.util.ByteArray)
	 */
	public ByteArray encodeText(char[] text, int start, int length,
			boolean endOfData, ByteArray dest) throws IOException {
		if (dest == null) dest = new ByteArray();
// <ta>
		hasNative = false;
// </ta>
		if (hasNative) try{
			encodeDecode(_ASCII_CODEC,true,text,start,length,endOfData,dest,flags);
			return dest;
		}catch(SecurityException e){
			hasNative = false;
		}catch(UnsatisfiedLinkError e2){
			hasNative = false;
		}
		//
		if (length <= 0) return dest;
		dest.ensureCapacity(dest.length+length);
		int st = dest.length;
		boolean strip = (flags & STRIP_CR_ON_ENCODE) != 0;
// <ta>
//		if (strip)
		boolean add = (flags & ADD_CR_ON_ENCODE) != 0;
		if ( strip || add )
		{
			destlength = dest.length+length;
// </ta>
			for (int i = 0; i<length; i++){
				char c = text[start++];
// <ta>
//				if (c == '\r') continue;
				if ( (c == '\r') && strip ) continue;
				if ( (c == '\n') && add )
				{
					byte[] nd = new byte[++destlength];
					System.arraycopy(dest.data,0,nd,0,destlength-1);
					dest.data = nd;
					dest.data[st++] = (byte) '\r';
				}
// </ta>
				dest.data[st++] = (byte)c;
			}
		}
		else // For faster processing.
			for (int i = 0; i<length; i++)
				dest.data[st++] = (byte)text[start++];
		dest.length = st;
		return dest;
	}

	/* (non-Javadoc)
	 * @see eve.io.TextCodec#decodeText(byte[], int, int, boolean, eve.util.CharArray)
	 */
	public CharArray decodeText(byte[] encodedText, int start, int length,
			boolean endOfData, CharArray dest) throws IOException {
		if (dest == null) dest = new CharArray();
		if (hasNative) try{
			encodeDecode(_ASCII_CODEC,false,encodedText,start,length,endOfData,dest,flags);
			return dest;
		}catch(SecurityException e){
			hasNative = false;
		}catch(UnsatisfiedLinkError e2){
			hasNative = false;
		}
		//
		if (length <= 0) return dest;
		dest.ensureCapacity(dest.length+length);
		int st = dest.length;
		boolean strip = (flags & STRIP_CR_ON_DECODE) != 0;
		if (strip)
			for (int i = 0; i<length; i++){
				char c = (char)((int)encodedText[start++] & 0xff);
				if (c == '\r') continue;
				dest.data[st++] = c;
			}
		else
			for (int i = 0; i<length; i++)
				dest.data[st++] = (char)((int)encodedText[start++] & 0xff);
		
		dest.length = st;
		return dest;
	}

	/* (non-Javadoc)
	 * @see eve.io.TextCodec#closeCodec()
	 */
	public void closeCodec() throws IOException {
	}

	/* (non-Javadoc)
	 * @see eve.util.Copyable#getCopy()
	 */
	public Object getCopy() {
// <ta>
//		return new AsciiCodec(flags);
		return new AsciiCodec(flags);
// </ta>
	}

	public AsciiCodec(int options)
	{
		flags = options;
	}
	public AsciiCodec()
	{
		this(0);
	}
// <ta>
	/** Returns the version of the class.
	 * 
	 * @return Returns the version of the class.
	 */
	public static String getVersion ()
	{
		return stVersion;
	}
// </ta>
}

