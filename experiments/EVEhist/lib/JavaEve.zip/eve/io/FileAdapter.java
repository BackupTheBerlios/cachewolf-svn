/*
 * Created on Mar 10, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.IOException;

import eve.sys.Wrapper;
import eve.util.CharArray;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public abstract class FileAdapter extends File{
//####################################################
	
public void set(File parent, String name)
{
	// !IMPLEMENT this should be native.
	this.name.clear();
	if (parent == null) this.name.append(name);
	else {
		String p = parent.getCreationName();
		this.name.append(removeTrailingSlash(p)+"/"+removeTrailingSlash(name));
	}
}
//-------------------------------------------------------------------
protected void setFullPathName(File parent,String file)
//-------------------------------------------------------------------
{
	name.clear().append(makePath(parent,file));
}

protected FileAdapter(){}

protected FileAdapter(String name)
{
	this(null,name);
}
protected FileAdapter(File directory, String name)
{
	set(directory,name);
}
/* (non-Javadoc)
 * @see eve.io.FileBase#getNewInstance()
 */
protected File getNewInstance()
{
	throw new RuntimeException("Override getNewInstance() if you don't override getNew()");
}

/* (non-Javadoc)
 * @see eve.io.FileBase#createDir()
 */
public abstract boolean createDir();

/* (non-Javadoc)
 * @see eve.io.FileBase#delete()
 */
public abstract boolean delete();

/* (non-Javadoc)
 * @see eve.io.FileBase#exists()
 */
public abstract boolean exists();

/* (non-Javadoc)
 * @see eve.io.FileBase#isDirectory()
 */
public abstract boolean isDirectory();

public boolean isSymbolicLink()
{
	return false;
}
/* (non-Javadoc)
 * @see eve.io.FileBase#getFullPath()
 */
public abstract String getFullPath();

/* (non-Javadoc)
 * @see eve.io.FileBase#deleteOnExit()
 */
public abstract void deleteOnExit();

public final CharArray list(String mask, int listAndSortOptions, CharArray dest)
throws IOException
{
	String[] got = list(mask,listAndSortOptions);
	if (got == null) return null;
	if (dest == null) dest = new CharArray();
	for (int i = 0; i<got.length; i++){
		if (i != 0) dest.append('|');
		dest.append(got[i]);
	}
	return dest;
}
/* (non-Javadoc)
 * @see eve.io.FileBase#list(java.lang.String, int)
 */
public abstract String[] list(String mask, int listAndSortOptions);

/* (non-Javadoc)
 * @see eve.io.FileBase#getSetModified(eve.sys.Time, boolean)
 */
protected abstract long getSetModified(long time, boolean doGet) throws IOException;

/* (non-Javadoc)
 * @see eve.io.FileBase#move(eve.io.File)
 */
public abstract boolean move(File newFile);

public Wrapper getInfo(int infoCode, Wrapper sourceParameters, int options)
{
	if (sourceParameters == null) sourceParameters = new Wrapper();
	sourceParameters.clear();
	return sourceParameters;
}
public boolean setInfo(int infoCode,Wrapper sourceParameters,int options)
{
	return false;
}

/* (non-Javadoc)
 * @see eve.io.FileBase#getLength()
 */
public abstract long getLength();
//-------------------------------------------------------------------
protected int getSetPermissionsAndFlags(boolean isGet, int valuesToSetOrGet, int valuesToClear) throws IOException
//-------------------------------------------------------------------
{
	return 0;
}
/**
 * Returns a value indicating which of the flags
 * specified in the interestedFlags parameter is supported by the
 * underlying system.
 * @param interestedFlags the flags you wish to check OR'ed together.
 * @return the supported flags OR'ed together.
 */
public int getSupportedPermissionsAndFlags(int interestedFlags)
{
	return 0;
}
/**
 * Create a symbolic link to a specified target file.
 * @param target the file to link to.
 * @return true if created, false if not (if not supported on the platform).
 */
public boolean createSymbolicLink(String target)
{
	return false;
}
/**
 * If this file is a symbolic link, return the target of the link.
 * @return the target of the symbolic link.
 */
public File getSymbolicLinkTarget()
{
	return null;
}
/**
 * This returns null by default - since a FileAdapter does not represent an OS File.
 */
public java.io.File toJavaFile()
{
	return null;
}
}

//####################################################
