package eve.io;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

import eve.data.DataUtils;
import eve.data.MutableTreeNode;
import eve.data.MutableTreeNodeObject;
import eve.data.Named;
import eve.data.Property;
import eve.data.PropertyList;
import eve.data.TreeNode;
import eve.sys.Handle;
import eve.sys.Time;
import eve.sys.Vm;
import eve.sys.Wrapper;
import eve.util.ByteArray;
import eve.util.CharArray;
import eve.util.Comparer;
import eve.util.Utils;
import eve.util.mString;
/**
A FakeFileSystem is used to simulate a FileSystem, possibly starting from another read-only File
system. The FakeFileSystem provides a File object that can be used to browse and access the
FakeFileSystem using the File methods getNew(), getChild() and list().
<p>
Usually you would start the FakeFileSystem with entries found in another file storage system
like a ZipFile or a EveFile. Then the FakeFileSystem would allow data to be written into the
FakeFileSystem - but the data would be written into memory and not into the original system
(e.g. ZipFile).
<p>
For example, when a Eve application is being run in a WebBrowser by a Java VM, upon startup
the VM looks for a file called "_filesystem.zip" on the server. If that file is found it is
used as the start of the FakeFileSystem and the default file system for the application then
becomes that FileSystem. Here is an excerpt from the source code that does this:
<p>
<pre>
	try{
		eve.zip.ZipFile zf = new eve.zip.ZipFile(eve.sys.Vm.openRandomAccessStream("_filesystem.zip","r"));
		System.out.println("Loading virtual file system.");
		eve.zip.ZipEntryFile zef = new eve.zip.ZipEntryFile(zf);
		fileSystem = new eve.io.FakeFileSystem();
		fileSystem.addVolume("Disk1",zef.getNew("/"));
		zf.close();
	}catch(IOException e){} //No virtual file system found.
</pre>
<p>
The addVolume() method is used to add a volume (simulated root drive) to the FakeFileSystem
and the method <b>getFile()</b> returns a File object that can be used to access the
FakeFileSystem.
**/
//##################################################################
public class FakeFileSystem extends MutableTreeNodeObject{
//##################################################################

/**
* This is the name of the File system which by default is
* "Virtual File System". You can change this to be anything else.
**/
public String deviceName = "Virtual File System";

//===================================================================
public void addVolume(String systemName,File root)
//===================================================================
{
	if (systemName == null) systemName = "Disk1:";
	//if (!systemName.endsWith("/") && !systemName.endsWith("\\")) systemName += "/";
	if (!systemName.endsWith(":")) systemName += ":";
	addChild(new FileNode().set(root,systemName,""));
}
//===================================================================
public File getFile() 
//===================================================================
{
	if (getChildCount() == 0) addVolume(null,null);
	if (sorted == null) sortNames();
	return new FakeFile();
}
//===================================================================
public String defaultVolume()
//===================================================================
{
	int count = getChildCount();
	if (count == 0) return null;
	return getChild(0).toString();		
}

public PropertyList unsortedNames;// = new PropertyList();
public PropertyList sorted;

Comparer stringComparer;

//-------------------------------------------------------------------
protected void sortNames()
//-------------------------------------------------------------------
{
	if (unsortedNames == null) return;
	Object [] all = new Object[unsortedNames.size()];
	unsortedNames.copyInto(all);
	stringComparer = Vm.getLocale().getStringComparer(0);
	Utils.sort(all,new Comparer(){
		public int compare(Object one,Object two){
			return stringComparer.compare(((Property)one).name,((Property)two).name);
		}
	}
	,false);
	sorted = new PropertyList();
	sorted.addAll(all);
}

//-------------------------------------------------------------------
public int find(String name)
//-------------------------------------------------------------------
{
	int size = sorted.size();
	if (size < 1) return 0;
	int ul = size, ll = -1;
	while(true) {
		if (ul-ll <= 1) {
			//System.out.println(ul);
			return ul;
		}
		int where = ((ul-ll)/2)+ll;
		Property p = (Property)sorted.get(where);
		int cmp = stringComparer.compare(name,p.name);
		if (cmp > 0) ll = where;
		else ul = where;
	}
/*
	for (int i = 0; i<max; i++){
		int cmp = comparer.compare(searchData,get(i,buffer,data));
		if (flip) cmp = -cmp;
		if (cmp <= 0) return i;
	}
	return max;
*/
}

//===================================================================
public FileNode findNode(String name)
//===================================================================
{
	int val = find(name);
	if (val >= sorted.size()) return null;
	Property p = (Property)sorted.get(val);
	if (p.name.equals(name)) return (FileNode)p.value;
	return null;
}
	//##################################################################
	class FileNode extends MutableTreeNodeObject implements Named{
	//##################################################################
	
	public String name = "unnamed";
	public String getName() {return name.endsWith(":") ? name+"/" : name;}
	public Time time = new Time();
	
	public boolean isNamed(String nm)
	{
		if (nm.equals(name)) return true;
		return ((nm+"/").equals(name));
	}
	boolean isDirectory = false;
	ByteArray data;
	
	public int getLength()
	{
		if (data == null) return 0;
		return data.length;
	}
	
	int openReads = 0, openWrites = 0;
	
	synchronized RandomStream getRandomStream(final String mode) throws IOException
	{
		if (openWrites != 0) throw new IOException("File already open for writing.");
		if (!mode.equals("r")){
			if (openReads != 0) throw new IOException("File already open.");
			openWrites++;
		}else{
			// This fakes an error.
			// if (true) throw new IOException("No reading allowed.");
			openReads++;
		}
		if (data == null) data = new ByteArray();
		ByteArrayRandomStream bos = new ByteArrayRandomStream(data,mode){
			public void close() throws IOException
			{
				try{
					super.close();
				}finally{
					synchronized(FileNode.this){
						if (mode.equals("r"))
							openReads--;
						else
							openWrites--;
					}
				}
			}
		};
		return bos;
	}
	public FileNode set(File f,String asName,String parentName)
	{
		name = asName;
		if (f != null){
			try{
				f.getModified(time);
			}catch(Exception e){
				time.setToCurrentTime();
			}
			if (name == null) name = f.getFileExt();
			isDirectory = f.isDirectory();
		}else
			isDirectory = true;
		if (unsortedNames != null) unsortedNames.add(parentName+name,this);
		if (f != null){
			if (isDirectory){
				String [] all = f.list();
				for (int i = 0; i<all.length; i++)
					addChild(new FileNode().set(f.getChild(all[i]),all[i],parentName+name+"/"));
			}else{
				try{
					InputStream in = f.toReadableStream();
					data = StreamUtils.readAllBytes(null,in,null);
				}catch(Exception e){
					data = null;
				}
			}
		}
		return this;
	}
	public String toString() {return getName();}
	
	//##################################################################
	}
	//##################################################################
	
	//##################################################################
	class FakeFile extends FileAdapter{
	//##################################################################


	//-------------------------------------------------------------------
	FileNode findNode()
	//-------------------------------------------------------------------
	{
		String path = getFullPath();
		if (path.indexOf(':') == -1) {
			path = path.replace('\\','/');
			if (path.startsWith("/")) path = path.substring(1);
			path = defaultVolume()+path;
		}
		if (unsortedNames != null) return FakeFileSystem.this.findNode(path);
		int [] got = DataUtils.addressOfChild(FakeFileSystem.this,path);
		if (got == null) return null;
		TreeNode tn = DataUtils.getChildAt(FakeFileSystem.this,got);
		if (tn instanceof FileNode) return (FileNode)tn;
		return null;
	}
	
	//===================================================================
	public boolean exists()
	//===================================================================
	{
		FileNode fn = findNode();
		if (fn == null) return false;
		return true;
	}
	
	//===================================================================
	public void set(File f,String name)
	//===================================================================
	{
		if (f == null) {
			this.name = new CharArray(name);
			if (name.length() != 1)
				this.name = new CharArray(mString.removeTrailingSlash(this.name.toString()));
		}else {
			this.name = new CharArray(f.getFullPath());
			this.name = new CharArray(mString.removeTrailingSlash(this.name.toString()));
			if (name != null)
				if (name.trim().length() != 0){
					this.name = new CharArray(mString.removeTrailingSlash(this.name.toString()));	
					this.name.append("/"+name);
				}
		}
		this.name = new CharArray(fixupPath(this.name.toString()));
		if (this.name.length != 0)
			if (this.name.data[this.name.length-1] == ':')
				this.name.append('/');
	}
	//===================================================================
	public File getNew(File parent,String file)
	//===================================================================
	{
		File f = new FakeFile();
		f.set(parent,file);
		return f;
	}
	//===================================================================
	public boolean isDirectory()
	//===================================================================
	{
		FileNode fn = findNode();
		if (fn == null) return false;
		return fn.isDirectory;
	}
	/*
	int curFind = 0;
	FileNode me = null;
	//-------------------------------------------------------------------
	protected int startFind(String mask)
	//-------------------------------------------------------------------
	{
		curFind = 0;
		me = findNode();
		if (me == null) return 0;
		if (!me.isDirectory) return 0;
		return 1;
	}
	//-------------------------------------------------------------------
	protected Object findNext(int search)
	//-------------------------------------------------------------------
	{
		if (curFind >= me.getChildCount()) return null;
		return ((LiveTreeNode)me.getChild(curFind++)).getName();
	}
	protected void endFind(int search){me = null;}
	*/

	//===================================================================
	public long getLength()
	//===================================================================
	{
		FileNode fn = findNode();
		if (fn == null) return 0;
		return fn.getLength();
	}
	//===================================================================
	FileNode makeEntry(FileNode with)
	//===================================================================
	{
		FileNode fn = findNode();
		if (fn != null) return null;
		FakeFile ff = ((FakeFile)getParentFile());
		if (ff == null) return null;
		FileNode p = ff.findNode();
		if (p == null) return null;
		if (with != null){
			MutableTreeNode ltn = (MutableTreeNode)with.getParent();
			if (!(ltn instanceof FileNode)) return null;
			ltn.removeChild(with);
			p.addChild(with);
			with.name = getFileExt();
			return with;
		}else{
			fn = new FileNode();
			fn.name = getFileExt();
			fn.isDirectory = false;
			fn.data = new ByteArray();
			p.addChild(fn);
			return fn;		
		}
	}
	
	//===================================================================
	public boolean createDir()
	//===================================================================
	{
		FileNode fn = makeEntry(null);
		if (fn == null) return false;
		fn.isDirectory = true;
		return true;
	}
	
	//===================================================================
	public boolean move(File newFile)
	//===================================================================
	{
		FileNode fn = findNode();
		if (fn == null) return false;
		return ((FakeFile)newFile).makeEntry(fn) != null;
	}
	
	//===================================================================
	public boolean delete()
	//===================================================================
	{
		FileNode fn = findNode();
		if (fn == null) return false;
		if (fn.getChildCount() != 0) return false;
		TreeNode p = fn.getParent();
		if (!(p instanceof FileNode)) return false;
		((FileNode)p).removeChild(fn);
		return true;
	}
	//-------------------------------------------------------------------
	protected  void getSetModified(Time time,boolean doGet)
	//-------------------------------------------------------------------
	{
		FileNode fn = findNode();
		if (fn == null) return;
		if (doGet) time.setTime(fn.time.getTime());
		else fn.time.setTime(time.getTime());
	}
	
	public synchronized Wrapper getInfo(int infoCode, Wrapper sourceParameters, int options)
	{
		if (sourceParameters == null) sourceParameters = new Wrapper();
		Wrapper ret = new Wrapper();
		switch(infoCode){
		case INFO_DEVICE_NAME:
			return ret.setObject(deviceName);
		case INFO_PROGRAM_DIRECTORY:
			return ret.setObject(defaultVolume());
		case INFO_ROOT_LIST:
			String [] all = new String[getChildCount()];
			for (int i = 0; i<all.length; i++)
				all[i] = FakeFileSystem.this.getChild(i).toString()+"/";
			return ret.setObject(all);
		case INFO_FLAGS:
			return ret.setInt(FLAG_SLOW_CHILD_COUNT|FLAG_CASE_SENSITIVE|FLAG_SLOW_LIST); 
		}
		return super.getInfo(infoCode,sourceParameters,options);
	}

	
	//===================================================================
	public RandomStream toRandomStream(String mode) throws IOException
	//===================================================================
	{
		FileNode node = findNode();
		if (node == null){
			if (mode.equals("r")) throw new IOException("Cannot read from: "+this);
			node = makeEntry(null);
			if (node == null) throw new IOException("Cannot write to: "+this);;
		}
		return node.getRandomStream(mode);
	}
	//##################################################################

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#getFullPath()
	 */
	public String getFullPath() {
		return name.toString();
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#deleteOnExit()
	 */
	public void deleteOnExit() {
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#list(java.lang.String, int)
	 */
	public synchronized String[] list(String mask, int listAndSortOptions) {
		FileNode me = findNode();
		if (me == null) return null;
		if (!me.isDirectory) return null;
		Vector v = new Vector();
		FileComparer fc = new FileComparer(this,Vm.getLocale(),listAndSortOptions,mask);
		int max = me.getChildCount();
		for (int i = 0; i<max; i++){
			try{
				String s = ((Named)me.getChild(i)).getName();
				Thread.yield();
				if (s == null) break;
				if (!fc.accept(this,s)) {
					continue;
				}
				v.add(s);
				if ((listAndSortOptions & LIST_CHECK_FOR_ANY_MATCHING_CHILDREN) != 0) break;
			}catch(Exception e){
				break;
			}
		}
		if ((listAndSortOptions & LIST_CHECK_FOR_ANY_MATCHING_CHILDREN) != 0)
			if (v.size() == 0) return null;
		else
			return new String[0];
		Object [] ret = new Object[v.size()];
		v.copyInto(ret);
		Handle h = new Handle();
		Utils.sort(h,ret,fc,((listAndSortOptions & LIST_DESCENDING) != 0));
		String [] r2 = new String[ret.length];
		for (int i = 0; i<ret.length; i++)
			if (ret[i] instanceof File) r2[i] = ((File)ret[i]).getName();
			else r2[i] = (String)ret[i];
		return r2;
	}

	/* (non-Javadoc)
	 * @see eve.io.FileAdapter#getSetModified(long, boolean)
	 */
	protected long getSetModified(long time, boolean doGet) throws IOException {
		FileNode n = findNode();
		if (n == null) throw new IOException();
		if (doGet) return n.time.getTime();
		else n.time.setTime(time);
		return time;
	}
	}
	//##################################################################
/*
//=================================================================
public static void main(String[] args)
//=================================================================
{
	Application.startApplication(args);
	FakeFileSystem ffs = new FakeFileSystem();
	try{
		String name = args.length == 0 ? "_filesystem.zip" : args[0];
		ZipFile zf = new ZipFile(Vm.openResourceAsRandomStream(null,name));
		ProgressBarForm.display("Reading","Reading Virtual File System",null);
		File zef = zf.getFileSystem(null);
		ffs.addVolume("Disk1",zef.getNew("/"));
		ffs.addVolume("Disk2",null);
		zf.close();
	}catch(IOException e){ //No virtual file system found.
		System.out.println("Warning, no zip file found!");
	}finally{
		ProgressBarForm.clear();
	}	
	Vm.setFileSystem(ffs.getFile());
	new FileChooserDemo().run();
	System.exit(0);
}
*/
//##################################################################
}
//##################################################################

