package eve.io;
import java.io.IOException;
import java.io.InputStream;

/**
* This class is used to get a "sub-stream" of data from another Stream. The
* partial stream can limit the amount of data which can be read from the original
* Stream. Note the following:
* <nl>
* <li>Calling close() on a PartialInputStream does not close the original stream, unless closeUnderlying is true.
* <li>Setting a limit of -1 will not impose any limit on the number of bytes which
* can be read.
* <li>Input begins at the current point in the source input stream.
*</nl>

**/
//##################################################################
public class PartialInputStream extends InputStream{
//##################################################################
//
// Do not move the next 2 variables.
long limit;
long filepos;
private InputStream input;
private boolean closed;
/**
* If this is true, then a call to close() will close the underlying stream
* as well - by default it is false.
**/
public boolean closeUnderlying = false;
/**
* Creates a new PartialInputStream with no limit.
**/
//===================================================================
public PartialInputStream(InputStream input)
//===================================================================
{
	this(input,-1);
}
/**
* Creates a new PartialInputStream with the specified limit. If the limit
* is -1, then there will be no limit imposed
**/
//===================================================================
public PartialInputStream(InputStream input,long limit)
//===================================================================
{
	this.input = input;
	this.limit = limit;
	filepos = 0;
}
/*
//===================================================================
public boolean pushback(byte [] bytes,int start,int count)
//===================================================================
{
	if (stream instanceof BufferedStream)
		return ((BufferedStream)stream).pushback(bytes,start,count);
	return super.pushback(bytes,start,count);
}
//===================================================================
public int nonBlockingWrite(byte [] buff,int start,int length) {return READWRITE_ERROR;}
//===================================================================
*/
//===================================================================
public int read(byte [] buff,int offset,int count) throws IOException
//===================================================================
{
	if (closed) return -1;
	if (limit >= 0 && filepos >= limit) return -1;
	if (limit >= 0 && count > limit-filepos) count = (int)(limit-filepos);
	int got = input.read(buff,offset,count);
	if (got == -1) return got;
	filepos += got;
	return got;
}
private byte[] buffer;
public int read() throws IOException
{
	if (buffer == null) buffer = new byte[1];
	int got = read(buffer,0,1);
	if (got == -1) return -1;
	return (int)buffer[0] & 0xff;
}
/**
* This will not close the underlying stream unless closeUnderlying is true.
**/
//===================================================================
public void close() throws IOException
//===================================================================
{
	closed = true;
	if (closeUnderlying) input.close();
}
//===================================================================
public boolean isOpen()
//===================================================================
{
	return !closed;
}
//##################################################################
}
//##################################################################

