package eve.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import eve.util.mString;

/**
 * SerialPort accesses a device's or PC's serial port.
 * <p>
 * Serial port access under Java on a PC requires the Dynamic Link Library java_ewe.dll
 * <p>
 * When a serial port is created, an attempt is made to open the port.
 */
public class SerialPort 
{
	private int nativeObject;
	private serialOutputStream out;
	private serialInputStream in;
	private boolean amClosed;
/*	
private static boolean nativeInitialized = false;
static{
	try{
		System.loadLibrary("java_eve");
		nativeInitialized = true;
	}catch(Throwable t2){
		//t2.printStackTrace();
		nativeInitialized = false;
	}
}
*/
public static final int NOPARITY = 0;
public static final int ODDPARITY = 1;
public static final int EVENPARITY = 2;
public static final int MARKPARITY = 3;
public static final int SPACEPARITY = 4;

public static final int DEFAULT_FLOW_CONTROL = -1;
public static final int SOFTWARE_FLOW_CONTROL = 2;
public static final int HARDWARE_FLOW_CONTROL = 1;
public static final int NO_FLOW_CONTROL = 0;
/**
 * Create a new open SerialPort.
 * @param options The options for the opening the Serial Port.
 * @exception IOException if the Serial Port could not be opened successfully.
 */
public SerialPort(SerialPortSpecs options) throws IOException 
{
	_nativeCreate(options.portName,options.baudRate,options.bits,options.parity,options.stopBits,options.flowControl,options.reset);
}
/**
 * Opens a serial port. The number passed is the number of the
 * serial port for devices with multiple serial ports. 
 * <p>
 * On Windows devices, port numbers map to COM port numbers.
 * For example, serial port 2 maps to "COM2:".
 * <p>
 * Here is an example of opening serial port COM2: on a Windows device:
 * <pre>
 * SerialPort port = new SerialPort(2, 57600, 8, SerialPort.NOPARITY, 1);
 * </pre>
 * No serial XON/XOFF flow control (commonly called software flow control)
 * is used and RTS/CTS flow control (commonly called hardware flow control)
 * is turn on by default on all platforms but Windows CE. 
 *
 * @param number port number
 * @param baudRate baud rate
 * @param bits bits per char [5 to 8]
 * @param parity NOPARITY, EVENPARITY, ODDPARITY, MARKPARITY, SPACEPARITY
 * @param stopBits number of stop bits
 * @see #setFlowControl
 */
public SerialPort(int number, int baudRate, int bits, int parity, int stopBits)
throws IOException
	{
	_nativeCreate(portNumberToName(number), baudRate, bits, parity, stopBits,DEFAULT_FLOW_CONTROL,false);
	}
/**
 * Opens a serial port. <p>
 * Here is an example of opening serial port COM2: on a Windows device:
 * <pre>
 * SerialPort port = new SerialPort("COM2:", 57600, 8, SerialPort.NOPARITY, 1);
 * </pre>
 * No serial XON/XOFF flow control (commonly called software flow control)
 * is used and RTS/CTS flow control (commonly called hardware flow control)
 * is turn on by default on all platforms but Windows CE. 
 *
 * @param name port name - e.g. "COM1:" on Win32/WinCE systems.
 * @param baudRate baud rate
 * @param bits bits per char [5 to 8]
 * @param parity NOPARITY, EVENPARITY, ODDPARITY, MARKPARITY, SPACEPARITY
 * @param stopBits number of stop bits
 * @see #setFlowControl
 */
public SerialPort(String name, int baudRate, int bits, int parity, int stopBits)
throws IOException
	{
	_nativeCreate(name, baudRate, bits, parity, stopBits,DEFAULT_FLOW_CONTROL,false);
	}
	
/** 
 * Open a serial port with settings of 8 bits, no parity and 1 stop bit.
 * These are the most commonly used serial port settings.
 */
public SerialPort(int number, int baudRate)
throws IOException
	{
	this(number, baudRate, 8, NOPARITY, 1);
	}
/** 
 * Open a serial port with settings of 8 bits, no parity and 1 stop bit.
 * These are the most commonly used serial port settings.
 */
public SerialPort(String name, int baudRate)
throws IOException
	{
	this(name, baudRate, 8, NOPARITY, 1);
	}

private native void nativeClose();
private native void create(String name, int baudRate,int bits, int parity, int stopBits, int flow, boolean reset) throws IOException;

public static native boolean canOpen(String name);

private void _nativeCreate(String name, int baudRate,
	int bits, int parity, int stopBits, int flowControl, boolean reset) throws IOException
{
	if (name == null) throw new NullPointerException();
	create(name,baudRate,bits,parity,stopBits,flowControl,reset);
}

/**
 * Closes the port. Returns true if the operation is successful
 * and false otherwise.
 */
public synchronized void close() throws IOException
{
	if (amClosed) return;
	amClosed = true;
	nativeClose();
}

/**
 * Port numbers go from 1 to the maximum available on the running computer. Not
 * all ports can be opened successfully.
 * This returns the maximum for this computer.
 */
public static native int getMaxPortNumber();
/**
 * Port numbers go from 1 to the maximum available on the running computer. This
 * method will convert a port number to a String that can be sent to open().
**/
public static native String portNumberToName(int portNumber);
/**
 * Return port names separated by ';'
 * @return
 */
private static native String getAvailablePorts();
/**
 * Returns true if the port is open and false otherwise. This can
 * be used to check if opening the serial port was successful.
 */
//public native boolean isOpen();


/**
 * Selects different flow control - hardware, software (XON/XOFF) or none. Use combinations of HARDWARE_FLOW_CONTROL and SOFTWARE_FLOW_CONTROL
 * or NO_FLOW_CONTROL.
 * @param type HARDWARE_FLOW_CONTROL or SOFTWARE_FLOW_CONTROL or both or NO_FLOW_CONTROL.
 */
public native boolean setFlowControl(int type);

/**
* Enumerate all <b>available</b> Comm ports.
**/
//===================================================================
public static String [] enumerateAvailablePorts()
//===================================================================
{
	String got = getAvailablePorts();
	if (got == null) return new String[0];
	return mString.split(got,';');
}

//public static native boolean canOpen(String name);
protected void finalize() throws Throwable
{
	close();
}
//

public static final int PURGE_ALL = -1;
public static final int PURGE_RX_ABORT = 0x1;
public static final int PURGE_RX_CLEAR = 0x2;
public static final int PURGE_TX_ABORT = 0x4;
public static final int PURGE_TX_CLEAR = 0x8;

public native void purge(int purgeType) throws IOException;
/**
* This does a purge() and close() on the port, even if there is data pending to be sent.
* This may be necessary under some circumstances if you need to change the port configuration
* or reset the port by creating a new SerialPort object.
**/
public void kill() throws IOException
{
	purge(-1);
	close();
}
private void checkClosed() throws IOException
{
	if (amClosed) throw new IOException("Already closed!");
}

public synchronized OutputStream getOutputStream() throws IOException
{
	checkClosed();
	if (out == null) out = new serialOutputStream(this);
	return out;
}


public void shutdownOutput() throws IOException
{
	getOutputStream();
	out.amShutdown = true;
}

public boolean isOutputShutdown()
{
	if (out == null) return false;
	return out.amShutdown;
}
public synchronized InputStream getInputStream() throws IOException
{
	checkClosed();
	if (in == null) in = new serialInputStream(this);
	return in;
}

public void shutdownInput() throws IOException
{
	getInputStream();
	in.amShutdown = true;
}

public boolean isInputShutdown()
{
	if (in == null) return false;
	return in.amShutdown;
}

private native int readByte() throws IOException;
private native int readBytes(byte[] dest, int offset, int length) throws IOException;
private native void writeByte(int value) throws IOException;
private native void writeBytes(byte[] src, int offset, int length) throws IOException;

int read() throws IOException
{
	checkClosed();
	return readByte();
}
int read(byte[] dest, int offset, int length) throws IOException
{
	checkClosed();
	if (dest == null) throw new NullPointerException();
	if (offset < 0 || offset+length > dest.length) throw new ArrayIndexOutOfBoundsException();
	return readBytes(dest,offset,length);
}
void write(int value) throws IOException
{
	checkClosed();
	writeByte(value);
}
void write(byte[] src, int offset, int length) throws IOException
{
	checkClosed();
	if (src == null) throw new NullPointerException();
	if (offset < 0 || offset+length > src.length) throw new ArrayIndexOutOfBoundsException();
	writeBytes(src,offset,length);
}

}

//####################################################
class serialOutputStream extends OutputStream{
//####################################################
boolean amShutdown;
SerialPort mySerial;

serialOutputStream(SerialPort s)
{
	mySerial = s;
}
public void write(int data) throws IOException
{
	if (amShutdown) throw new IOException("Output stream has been shut down.");
	mySerial.write(data);
}
public void write(byte[] data) throws IOException
{
	write(data,0,data.length);
}
public void write(byte[] data, int offset,int count) throws IOException
{
	if (amShutdown) throw new IOException("Output stream has been shut down.");
	mySerial.write(data,offset,count);
}

public void close() throws IOException
{
	super.close();
	mySerial.close();
}
//####################################################
}
//####################################################
//####################################################
class serialInputStream extends InputStream{
//####################################################
boolean amShutdown;
SerialPort mySerial;

serialInputStream(SerialPort s)
{
	mySerial = s;
}
public int read() throws IOException
{
	if (amShutdown) return -1;
	return mySerial.read();
}
public int read(byte[] data, int offset,int count) throws IOException
{
	if (amShutdown) return -1;
	return mySerial.read(data,offset,count);
}

public void close() throws IOException
{
	super.close();
	mySerial.close();
}
//####################################################
}
//####################################################
