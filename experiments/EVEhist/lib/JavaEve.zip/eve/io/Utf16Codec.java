/*
 * Created on Apr 3, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.IOException;

import eve.util.ByteArray;
import eve.util.CharArray;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Utf16Codec extends TextCodecObject {
	static final int BIG_ENDIAN = 0x100;
	public static final int MUST_HAVE_ENDIAN_MARKER_ON_DECODE = 0x200;
	public static final int WRITE_ENDIAN_MARKER_ON_ENCODE = 0x400;
	public static final int IGNORE_ENDIAN_MARKER_ON_DECODE = 0x800;
	/**
	* This is a creation option. It specifies that CR characters should be removed when
	* encoding text into UTF.
	**/
	public static final int STRIP_CR_ON_DECODE = _STRIP_CR_ON_DECODE;
	/**
	* This is a creation option. It specifies that CR characters should be removed when
	* decoding text from UTF.
	**/
	public static final int STRIP_CR_ON_ENCODE = _STRIP_CR_ON_ENCODE;
	/**
	* This is a creation option. It specifies that CR characters should be removed when
	* decoding text from UTF AND encoding text to UTF.
	**/
	public static final int STRIP_CR = STRIP_CR_ON_DECODE|STRIP_CR_ON_ENCODE;

	/* (non-Javadoc)
	 * @see eve.io.TextCodec#encodeText(char[], int, int, boolean, eve.util.ByteArray)
	 */
	public ByteArray encodeText(char[] text, int start, int length,
			boolean endOfData, ByteArray dest) throws IOException {
		if (dest == null) dest = new ByteArray();
		if (hasNative) try{
			encodeDecode(_UTF16_CODEC,true,text,start,length,endOfData,dest,flags);
			return dest;
		}catch(SecurityException e){
			hasNative = false;
		}catch(UnsatisfiedLinkError e2){
			hasNative = false;
		}
		boolean bigEndian = (flags & BIG_ENDIAN) != 0;
		boolean strip = (flags & STRIP_CR_ON_ENCODE) != 0;
		//
		int st = dest.length;
		if (encodeByteTwo == -1){
			if ((flags & WRITE_ENDIAN_MARKER_ON_ENCODE) != 0){
				dest.ensureCapacity(dest.length+2);
				if (bigEndian){
					dest.data[st++] = (byte)0xfe;
					dest.data[st++] = (byte)0xff;
				}else{
					dest.data[st++] = (byte)0xff;
					dest.data[st++] = (byte)0xfe;
				}
			}
			encodeByteTwo = bigEndian ? 1 : 0;
		}
		//
		dest.length = st;
		if (length <= 0) return dest;
		dest.ensureCapacity(dest.length+(length*2));
		if (strip)
			for (int i = 0; i<length; i++){
				char c = text[start++];
				if (c == '\r') continue;
				if (bigEndian){
					dest.data[st++] = (byte)(c>>8);
					dest.data[st++] = (byte)c;
				}else{
					dest.data[st++] = (byte)c;
					dest.data[st++] = (byte)(c>>8);
				}
			}
		else // For faster processing.
			for (int i = 0; i<length; i++){
				char c = text[start++];
				if (bigEndian){
					dest.data[st++] = (byte)(c>>8);
					dest.data[st++] = (byte)c;
				}else{
					dest.data[st++] = (byte)c;
					dest.data[st++] = (byte)(c>>8);
				}
			}
		dest.length = st;
		return dest;
	}

	/* (non-Javadoc)
	 * @see eve.io.TextCodec#decodeText(byte[], int, int, boolean, eve.util.CharArray)
	 */
	public CharArray decodeText(byte[] encodedText, int start, int length,
			boolean endOfData, CharArray dest) throws IOException {
		if (dest == null) dest = new CharArray();
		if (hasNative) try{
			encodeDecode(_UTF16_CODEC,false,encodedText,start,length,endOfData,dest,flags);
			return dest;
		}catch(SecurityException e){
			hasNative = false;
		}catch(UnsatisfiedLinkError e2){
			hasNative = false;
		}
		//
		boolean bigEndian = (flags & BIG_ENDIAN) != 0;
		boolean strip = (flags & STRIP_CR_ON_DECODE) != 0;
		//
		if (length <= 0) return dest;
		//
		int st = dest.length;
		//
		int toPut = -1;
		if (byteTwo == -1){ // Have not read in the BOM marker.
			if (byteOne == -1){
				if (length == 0) return dest;
				byteOne = (int)encodedText[start++] & 0xff;
				length--;
			}
			//
			// At this point byteOne is not -1.
			//
			if (length < 1){
				if (endOfData) throw new IOException("Missing byte.");
				else return dest;
			}
			//
			// Get the second byte.
			//
			int s = (int)encodedText[start++] & 0xff;
			length--;
			//
			// Now I have the first two bytes.
			//
			if ((flags & IGNORE_ENDIAN_MARKER_ON_DECODE) != 0){
				toPut = bigEndian ? 
					(((byteOne & 0xff) << 8) | (s & 0xff)):
					((byteOne & 0xff) | ((s & 0xff) << 8));
				byteTwo = bigEndian ? 1 : 0;
			}else {
				if (byteOne == 0xff && s == 0xfe) byteTwo = 0;
				else if (byteOne == 0xfe && s == 0xff) byteTwo = 1;
				if (((flags & MUST_HAVE_ENDIAN_MARKER_ON_DECODE) != 0) && (byteTwo == -1))
					throw new IOException("No Byte Order Marker found.");
				else if (byteTwo == -1){
					//
					// It was not the BOM.
					//
					byteTwo = bigEndian ? 1 : 0;
					toPut = bigEndian ? 
						(((byteOne & 0xff) << 8) | (s & 0xff)):
						((byteOne & 0xff) | ((s & 0xff) << 8));
				}
			}
			byteOne = -1;
		}
		//
		if (toPut != -1){
			dest.ensureCapacity(st+1);
			dest.data[st++] = (char)toPut;
		}		
		dest.ensureCapacity(dest.length+(length/2)+1);
		//
		if (byteOne != -1){
			if (length < 1){ // No more bytes.
				if (endOfData) throw new IOException("Missing byte.");
				else return dest;
			}else{
				byte c = encodedText[start++];
				length--;
				dest.data[st++] = bigEndian ? 
						(char)((byteOne << 8) | ((int)c & 0xff)):
						(char)((byteOne &0xff) | (((int)c & 0xff) << 8));
				byteOne = -1;
			}
		}
		//
		for (int i = 0; i<length; i+=2){
			char c = (char)((int)encodedText[start++] & 0xff);
			if (i == length-1){
				if (endOfData) throw new IOException("Missing byte.");
				else{
					byteOne = (int)c & 0xff;
					break;
				}
			}
			if (bigEndian) c = (char)((c << 8) | ((int)encodedText[start++] & 0xff));
			else c = (char)(c | (((int)encodedText[start++] & 0xff)<<8));
			if (strip && c == '\r') continue;
			dest.data[st++] = c;
		}
		dest.length = st;
		return dest;
	}

	/* (non-Javadoc)
	 * @see eve.io.TextCodec#closeCodec()
	 */
	public void closeCodec() throws IOException {
	}

	/* (non-Javadoc)
	 * @see eve.util.Copyable#getCopy()
	 */
	public Object getCopy() {
		return new Utf16Codec(flags);
	}

	/**
	 * Create a Utf16Codec that will default to either big-endian byte encoding or 
	 * little-endian byte encoding unless
	 * a Byte Order Marker (BOM) is present as the first two bytes, in which case
	 * the BOM will determine the endianess (endianity?) of the data.
	 * <p>
	 * If the MUST_HAVE_ENDIAN_MARKER_ON_DECODE option is specified then the marker
	 * <b>must</b> be present as the first two bytes in the encoded stream. If the
	 * IGNORE_ENDIAN_MARKER_ON_DECODE option is specified then the marker is ignored
	 * and the endianess is always determined by bigEndianByDefault.
	 * <p>
	 * On encoding the endianess will be as specified by the bigEndianByDefault parameter
	 * and a BOM marker will be written if the WRITE_ENDIAN_MARKER_ON_ENCODE option is specified.
	 * @param bigEndianByDefault if true the codec will default to being big-endian,
	 * if false the codec will default to being little-endian. 
	 * @param options any of the class constants values OR'ed together.
	 */
	public Utf16Codec(boolean bigEndianByDefault,int options)
	{
		flags = options;
		if (bigEndianByDefault) flags |= BIG_ENDIAN;
	}
	
	private Utf16Codec(int flags)
	{
		this.flags = flags;
	}
}

//####################################################
