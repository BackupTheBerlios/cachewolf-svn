/*
 * Created on Jun 19, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io.filestore;

import java.io.IOException;

import eve.data.MutableTreeNodeObject;
import eve.util.SubString;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public abstract class FileStoreEntry extends MutableTreeNodeObject {
  protected String name;
  protected int size;

  boolean isDir = false;
  FileStoreEntry linkTo;
  SubString myFileName;
	 
  public String getName()
  {
  	return name;
  }
  
  public long getSize()
  {
  	return size;
  }
  
  public abstract long getTime() throws IOException;
  
}

//####################################################
