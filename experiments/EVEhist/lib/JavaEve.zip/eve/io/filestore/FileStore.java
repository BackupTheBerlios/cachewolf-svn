/*
 * Created on Jun 19, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io.filestore;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;

import eve.sys.Handle;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface FileStore {

	/**
	 * Get an enumeration to go through the entries in the file.
	 * Each entry provided is a FileStoreEntry.
	 */
	public Enumeration getStoreEntries() throws IOException;
	/**
	 * Expose the hashtable of entries if available. The hashtable should consist
	 * of a set of FileStoreEntry objects each one stored with a key that is equal
	 * to the name of the entry.
	 * @return the hashtable of entries if available, or null if not available.
	 */
	public Hashtable getStoreHashtable() throws IOException;
	
	public FileStoreEntry getNewEntry(String forName) throws IOException;
	
	public FileStoreEntryFile getFileSystem(Handle h) throws IOException;
	
	public String getStoreName();
	
	public InputStream openInputStream(FileStoreEntry entry) throws IOException;
	
	public FileStoreEntry findEntry(String fullName) throws IOException;
	
	public void close() throws IOException;
}
//####################################################
