/*
 * Created on Jun 19, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io.filestore;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Vector;

import eve.io.File;
import eve.io.FileAdapter;
import eve.io.FileComparer;
import eve.sys.Handle;
import eve.sys.Locale;
import eve.sys.Vm;
import eve.sys.Wrapper;
import eve.util.SubString;
import eve.util.Utils;
import eve.util.mString;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public abstract class FileStoreEntryFile extends FileAdapter{
	
	public FileStoreEntry root;
	public FileStoreEntry myEntry;
	public FileStore store;
	public String storeName = "FileStore File";

	public boolean isValid() {return root != null;}
	public boolean exists() {return myEntry != null;}
	public boolean isDirectory() 
	{
		if (myEntry == null) return false; 
		return myEntry.isDir;
	}
	public long getLength()
	{
		FileStoreEntry ze = myEntry;
		if (ze == null) return 0;
		if (ze.linkTo != null) ze = ze.linkTo;
		return ze.getSize();
	}
	
	protected FileStoreEntryFile(FileStore store)
	{
		this.store = store;
	}
	protected abstract FileStoreEntryFile createNew(FileStore store);

//	===================================================================
	public File getNew(File parent,String file)
//	===================================================================
	{
		FileStoreEntryFile zf = createNew(store);
		zf.root = root;
		zf.set(parent,file);
		return zf;
	}
//	===================================================================
	public FileStoreEntryFile(FileStore fs,Handle h)
//	===================================================================
	{
		store = fs;
		storeName = store.getStoreName();
		this.root = createTree(this,fs,h);
		//if (h != null) h.set(root != null ? h.Succeeded : h.Failed);
	}
	
//===================================================================
public static FileStoreEntry createTree(FileStoreEntryFile dest,FileStore store, Handle h) 
//===================================================================
{
	try{
	if (h == null) h = new Handle();
	Locale l = Vm.getLocale();
	Enumeration it = store.getStoreEntries();
	if (it == null) return null;
	Vector subs = new Vector();
	SubString ss = new SubString();
	FileStoreEntry root = store.getNewEntry("/");
	dest.root = root;
	root.isDir = true;
	int st = 0;
	while (it.hasMoreElements()){
		/*
		if (h != null){
			mThread.yield();
			if (h.shouldStop) return null;
		}
		*/
		//Vm.debug("-- "+i);
		FileStoreEntry entry = (FileStoreEntry)it.nextElement();
		String name = entry.getName();
//	.....................................................................
		char [] ch = Vm.getStringChars(name);
		int len = ss.set(ch,0,ch.length).split('/',subs);
		if (ch.length != 0)
			if (ch[ch.length-1] == '/'){
				len--;
				entry.isDir = true;
			}
		//int len = 0;
		//for (;st+len<ch.length;len++) if (ch[st+len] == '/') break;
		FileStoreEntry cur = root;
		for(int depth = 0; depth<len; depth++){
			int num = cur.getChildCount();
			SubString mine = (SubString)subs.get(depth);
			boolean found = false;
			FileStoreEntry child = null;
			for (int tn = 0; tn<num; tn++){
				child = (FileStoreEntry)cur.getChild(tn);
				SubString cs = child.myFileName;
				if (cs.length != mine.length) continue;
				//Vm.debug("Checking: "+cs+" against: "+mine);
				int match = 0;
				if (l.compare(ch,mine.start,mine.length,cs.data,cs.start,mine.length,l.IGNORE_CASE) != 0)
					continue;
				/*
				for (int c = 0; c<mine.length; c++)
					if (l.compare(ch[mine.start+c],cs.data[cs.start+c],l.IGNORE_CASE) != 0) break;
					else match++;
				if (match != mine.length) {
					//Vm.debug(cs+" is not "+mine);
					continue;
				}//else
					//Vm.debug(cs+" IS "+mine);
					 */
				cur = child;
				found = true;
				break;
			}
			if (found){
				if (depth == len-1) cur.linkTo = entry;
				continue;
			}
			if (depth == len-1) {
				child = entry;
			}else {
				child = entry;
				child = store.getNewEntry(mine.toString());
				child.isDir = true;
			}
			child.myFileName = new SubString().set(mine.data,mine.start,mine.length);
			cur.addChild(child);
			//Vm.debug(cur.myFileName+"->"+child.myFileName.toString());
			cur = child;
			h.setProgress(-1);
		}
//	.....................................................................
	}
	return root;
	}catch(IOException e){
		if (h != null) h.fail(e);
		return null;
	}
}

public void set(File parent,String file)
{
	name.clear().append(file).replace('\\','/');
	if (parent instanceof FileStoreEntryFile) {
		root = ((FileStoreEntryFile)parent).root;
		String nm = ((FileStoreEntryFile)parent).name.toString();
		if (nm == null) nm = "";
		name.clear().append(nm);
		name = removeTrailingSlash(name);
		if (name.length == 1 && name.data[0] == '/') name.append(file);
		else name.append('/').append(file);
	}
	if (name.length() == 0) name.append('/');
	else {
		if (name.charAt(0) != '/') name.insert('/',0);
		if (name.length() != 1)
			removeTrailingSlash(name);
	}
	myEntry = null;
	if (name.length() == 1 && name.charAt(0) == '/') myEntry = root;
	else{
		String [] got = mString.split(name.toString(),'/');
		FileStoreEntry cur = root;
		SubString mine = new SubString();
		for (int i = 1; i<got.length; i++){
			mine.set(got[i]);
			int num = cur.getChildCount();
			boolean found = false;
			FileStoreEntry child = null;
			for (int tn = 0; tn<num; tn++){
				child = (FileStoreEntry)cur.getChild(tn);
				SubString cs = child.myFileName;
				//ewe.sys.Vm.debug(cs.toString()+" = "+mine.toString());
				if (SubString.equals(cs.data,cs.start,cs.length,mine.data,mine.start,mine.length,SubString.IGNORE_CASE)){
					//ewe.sys.Vm.debug("Found!");
					cur = child;
					found = true;
					break;
				}
			}
			if (found) continue;
			cur = null;
			break;
		}
		myEntry = cur;
	}
}
//-------------------------------------------------------------------
public String [] list(String mask,int listAndSortOptions)
//-------------------------------------------------------------------
{
	Vector v = new Vector();
	FileComparer fc = new FileComparer(this,Vm.getLocale(),listAndSortOptions,mask);
	int got = startFind(mask);
	if (got == 0) return null;
	try{
		while(true){
			Object s = findNext(got);
			Thread.yield();
			if (s == null) break;
			if (!fc.accept(this,s)) continue;
			v.add(s);
			if ((listAndSortOptions & LIST_CHECK_FOR_ANY_MATCHING_CHILDREN) != 0) break;
		}
	}finally{
		endFind(got);
	}
	if ((listAndSortOptions & LIST_CHECK_FOR_ANY_MATCHING_CHILDREN) != 0)
		if (v.size() == 0) return null;
	else
		return new String[0];
	Object [] ret = new Object[v.size()];
	v.copyInto(ret);
	Handle h = new Handle();
	Utils.sort(h,ret,fc,((listAndSortOptions & LIST_DESCENDING) != 0));
	String [] r2 = new String[ret.length];
	for (int i = 0; i<ret.length; i++)
		if (ret[i] instanceof File) r2[i] = ((File)ret[i]).getName();
		else r2[i] = (String)ret[i];
	return r2;
}

int curFind = 0;
//-------------------------------------------------------------------
protected int startFind(String mask)
//-------------------------------------------------------------------
{
	curFind = 0;
	if (!isDirectory()) return 0;
	return 1;
}
//-------------------------------------------------------------------
protected Object findNext(int search)
//-------------------------------------------------------------------
{
	if (curFind >= myEntry.getChildCount()) return null;
	FileStoreEntry ze = (FileStoreEntry)myEntry.getChild(curFind++);
	return ze.myFileName.toString();
}

protected void endFind(int search){}

//-------------------------------------------------------------------
public Wrapper getInfo(int infoCode, Wrapper sourceParameters, int options)
{
	if (sourceParameters == null) sourceParameters = new Wrapper();
	Wrapper ret = new Wrapper();
	switch(infoCode){
	case INFO_DEVICE_NAME:
		return ret.setObject(storeName);
	}
	return sourceParameters;
}
/* (non-Javadoc)
 * @see eve.io.FileAdapter#getSetModified(long, boolean)
 */
protected long getSetModified(long time, boolean doGet) throws IOException{
	FileStoreEntry ze = (FileStoreEntry)myEntry;
	if (ze != null) {
		if (ze.linkTo != null) ze = ze.linkTo;
		if (doGet) return ze.getTime();
	}
	return System.currentTimeMillis();	
}
/* (non-Javadoc)
 * @see eve.io.FileAdapter#move(eve.io.File)
 */
public boolean move(File newFile) {
	// TODO Auto-generated method stub
	return false;
}
/* (non-Javadoc)
 * @see eve.io.FileAdapter#createDir()
 */
public boolean createDir() {
	// TODO Auto-generated method stub
	return false;
}
/* (non-Javadoc)
 * @see eve.io.FileAdapter#delete()
 */
public boolean delete() {
	// TODO Auto-generated method stub
	return false;
}
/* (non-Javadoc)
 * @see eve.io.FileAdapter#getFullPath()
 */
public String getFullPath() {
	return name.toString();
}
/* (non-Javadoc)
 * @see eve.io.FileAdapter#deleteOnExit()
 */
public void deleteOnExit() {
	// TODO Auto-generated method stub
	
}
//===================================================================
public InputStream toReadableStream() throws IOException
//===================================================================
{
	if (myEntry != null) return store.openInputStream(myEntry);
	else throw new IOException("Could not read file.");
}

}

//####################################################
