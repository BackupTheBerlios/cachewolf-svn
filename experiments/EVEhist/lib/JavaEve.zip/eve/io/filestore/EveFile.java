/*
 * Created on Jun 19, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io.filestore;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;

import eve.io.CorruptedDataException;
import eve.io.RandomStream;
import eve.io.StreamUtils;
import eve.sys.Handle;
import eve.util.Utils;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class EveFile implements FileStore{

protected RandomStream rs;
private Hashtable entries;
private String name;
private boolean closed = false;

static class EveEntryFile extends FileStoreEntryFile{
	/**
	 * @param fs
	 * @param h
	 */
	public EveEntryFile(FileStore fs, Handle h) {
		super(fs, h);
	}

	public EveEntryFile(FileStore fs)
	{
		super(fs);
	}
	/* (non-Javadoc)
	 * @see eve.io.filestore.FileStoreEntryFile#createNew(eve.io.filestore.FileStore)
	 */
	protected FileStoreEntryFile createNew(FileStore store) {
		return new EveEntryFile(store);
	}
}

static class EveEntry extends FileStoreEntry{
	int offset;
	
	public EveEntry(String name,int length, int offset)
	{
		this.name = name;
		this.offset = offset;
		this.size = length;
	}
	/* (non-Javadoc)
	 * @see eve.io.filestore.FileStoreEntry#getTime()
	 */
	public long getTime() {
		// TODO Auto-generated method stub
		return System.currentTimeMillis();
	}
}

private void seek(long where) throws IOException
{
	rs.setPosition(where);
}
byte buff[] = new byte[4];

//-------------------------------------------------------------------
byte [] readFully(byte [] dest,int len) throws IOException
//-------------------------------------------------------------------
{
	if (dest == null) dest = new byte[len];
	StreamUtils.readFully(rs,dest,0,len);
	return dest;
}
//-------------------------------------------------------------------
int readInt() throws IOException 
//-------------------------------------------------------------------

{
	return Utils.readInt(readFully(buff,4),0,4);
}
//-------------------------------------------------------------------
int readShort() throws IOException
//-------------------------------------------------------------------
{
	return Utils.readInt(readFully(buff,2),0,2);
}

//===================================================================
protected void readEntries() throws IOException, CorruptedDataException
//===================================================================
{
	entries = new Hashtable();
	int baseP = 0;
	seek(baseP+4);
	int numRecs = readInt();
	for (int i = 0; i<numRecs; i++){
		int off = readInt();
		int nextOff = readInt();
		int size = nextOff-off;
		long here = rs.getPosition();
		seek(baseP+off);
		int nameLen = readShort();
		size -= nameLen+2;
		if (nameLen > buff.length) buff = new byte[nameLen];
		readFully(buff,nameLen);
		int strLen = nameLen;
		while(buff[strLen-1] == 0) strLen--;
		String inFile = Utils.decodeJavaUtf8String(buff,0,strLen);
		entries.put(inFile,new EveEntry(inFile,size,baseP+off+nameLen+2));
		seek(here-4);
	}
}

/**
 * Create an EveFile opened via the specified RandomStream for read-only access.
 * @param rs the RandomStream of the open EveFile.
 */
public EveFile(RandomStream rs,String name)
{
	this.rs = rs;
	if (name == null) name = "Eve File";
	this.name = name;
}
	/* (non-Javadoc)
	 * @see eve.io.filestore.FileStore#getStoreEntries()
	 */
	public Enumeration getStoreEntries() throws IOException {
		return getStoreHashtable().elements();
	}

	/* (non-Javadoc)
	 * @see eve.io.filestore.FileStore#getStoreHashtable()
	 */
	public Hashtable getStoreHashtable() throws IOException {
		if (entries == null) readEntries();
		return entries;
	}

	/* (non-Javadoc)
	 * @see eve.io.filestore.FileStore#getNewEntry(java.lang.String)
	 */
	public FileStoreEntry getNewEntry(String forName) {
		return new EveEntry(forName,0,0);
	}

	/* (non-Javadoc)
	 * @see eve.io.filestore.FileStore#getStoreName()
	 */
	public String getStoreName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see eve.io.filestore.FileStore#openInputStream(eve.io.filestore.FileStoreEntry)
	 */
	public synchronized InputStream openInputStream(FileStoreEntry entry) throws IOException {
		long where = ((EveEntry)entry).offset;
		long len = entry.getSize();
		byte[] all = new byte[(int)len];
		rs.setPosition(where);
		StreamUtils.readFully(rs,all);
		return new ByteArrayInputStream(all);
	}

	/* (non-Javadoc)
	 * @see eve.io.filestore.FileStore#findEntry(java.lang.String)
	 */
	public FileStoreEntry findEntry(String fullName) {
		try{
			return (FileStoreEntry)getStoreHashtable().get(fullName);
		}catch(IOException e){
			return null;
		}
	}
	/* (non-Javadoc)
	 * @see eve.io.filestore.FileStore#getFileSystem(eve.sys.Handle)
	 */
	public FileStoreEntryFile getFileSystem(Handle h) {
		// TODO Auto-generated method stub
		return new EveEntryFile(this,h);
	}

	public static InputStream getInputStream(RandomStream s, String name) throws IOException
	{
		EveFile ef = new EveFile(s,"Eve File");
		EveEntry ee = (EveEntry)ef.findEntry(name);
		if (ee == null) return null;
		return ef.openInputStream(ee);
	}
	  public void close() throws IOException
	  {
	    synchronized (rs)
	      {
		closed = true;
		entries = null;
		rs.close();
	      }
	  }
	
}
//####################################################
