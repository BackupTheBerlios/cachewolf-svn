/*
 * Created on Apr 4, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

import eve.sys.Vm;
import eve.util.ByteArray;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class TextWriter extends Writer {
private OutputStream out;
private ByteArray output = new ByteArray();
private TextCodec codec;
private boolean autoflush;
private boolean error = false;



/**
 * 
 */
	public TextWriter(OutputStream out, boolean autoFlush, TextCodec codec) {
		this.out = out;
		if (codec == null) try{
			codec = Io.getCodec(Io.getDefaultCodecName(),false);
		}catch(UnsupportedEncodingException e){
			codec = new AsciiCodec();
		}
		this.codec = codec;
		this.autoflush = autoFlush;
	}

	/* (non-Javadoc)
	 * @see java.io.Writer#close()
	 */
	public void close()
	{
		if (output == null) return;
		try{
			codec.encodeText(null,0,0,true,output.clear());
			if (output.length != 0) out.write(output.data,0,output.length);
			output = null;
			out.flush();
			out.close();
		}catch(IOException e){
			error = true;
		}
	}

	/* (non-Javadoc)
	 * @see java.io.Writer#write(char[], int, int)
	 */
	public void write(char[] text, int offset, int len)
	{
		try{
			if (output == null) throw new IOException("Writer closed.");
			codec.encodeText(text,offset,len,false,output.clear());
			if (output.length != 0) out.write(output.data,0,output.length);
		}catch(IOException e){
			error = true;
		}
	}
	/**
	   * This method can be called by subclasses to indicate that an error
	   * has occurred and should be reported by <code>checkError</code>.
	   */
	  protected void setError()
	  {
	    error = true;
	  }

	  /**
	   * This method checks to see if an error has occurred on this stream.  Note
	   * that once an error has occurred, this method will continue to report
	   * <code>true</code> forever for this stream.  Before checking for an
	   * error condition, this method flushes the stream.
	   *
	   * @return <code>true</code> if an error has occurred, 
	   * <code>false</code> otherwise
	   */
	  public boolean checkError()
	  {
	    flush();
	    return error;
	  }

	  /**
	   * This method flushes any buffered chars to the underlying stream and
	   * then flushes that stream as well.
	   */
	  public void flush()
	  {
	    try
	      {
		out.flush();
	      }
	    catch (IOException ex)
	      {
		error = true;
	      }
	  }

	  /**
	   * This method prints a <code>String</code> to the stream.  The actual
	   * value printed depends on the system default encoding.
	   *
	   * @param str The <code>String</code> to print.
	   */
	  public void print(String str)
	  {
	    write(str == null ? "null" : str);
	  }

	  /**
	   * This method prints a char to the stream.  The actual value printed is
	   * determined by the character encoding in use.
	   *
	   * @param ch The <code>char</code> value to be printed
	   */
	  public void print(char ch)
	  {
	    write((int) ch);
	  }

	  /**
	   * This method prints an array of characters to the stream.  The actual
	   * value printed depends on the system default encoding.
	   *
	   * @param charArray The array of characters to print.
	   */
	  public void print(char[] charArray)
	  {
	    write(charArray, 0, charArray.length);
	  }

	  /**
	   * This methods prints a boolean value to the stream.  <code>true</code>
	   * values are printed as "true" and <code>false</code> values are printed
	   * as "false".
	   *
	   * @param bool The <code>boolean</code> value to print
	   */
	  public void print(boolean bool)
	  {
	    // We purposely call write() and not print() here.  This preserves
	    // compatibility with JDK 1.2.
	    write (bool ? "true" : "false");
	  }

	  /**
	   * This method prints an integer to the stream.  The value printed is
	   * determined using the <code>String.valueOf()</code> method.
	   *
	   * @param inum The <code>int</code> value to be printed
	   */
	  public void print(int inum)
	  {
	    // We purposely call write() and not print() here.  This preserves
	    // compatibility with JDK 1.2.
	    write(Integer.toString(inum));
	  }

	  /**
	   * This method prints a long to the stream.  The value printed is
	   * determined using the <code>String.valueOf()</code> method.
	   *
	   * @param lnum The <code>long</code> value to be printed
	   */
	  public void print(long lnum)
	  {
	    // We purposely call write() and not print() here.  This preserves
	    // compatibility with JDK 1.2.
	    write(Long.toString(lnum));
	  }

	  /**
	   * This method prints a float to the stream.  The value printed is
	   * determined using the <code>String.valueOf()</code> method.
	   *
	   * @param fnum The <code>float</code> value to be printed
	   */
	  public void print(float fnum)
	  {
	    // We purposely call write() and not print() here.  This preserves
	    // compatibility with JDK 1.2.
	    write(Float.toString(fnum));
	  }

	  /**
	   * This method prints a double to the stream.  The value printed is
	   * determined using the <code>String.valueOf()</code> method.
	   *
	   * @param dnum The <code>double</code> value to be printed
	   */
	  public void print(double dnum)
	  {
	    // We purposely call write() and not print() here.  This preserves
	    // compatibility with JDK 1.2.
	    write(Double.toString(dnum));
	  }

	  /**
	   * This method prints an <code>Object</code> to the stream.  The actual
	   * value printed is determined by calling the <code>String.valueOf()</code>
	   * method.
	   *
	   * @param obj The <code>Object</code> to print.
	   */
	  public void print(Object obj)
	  {
	    // We purposely call write() and not print() here.  This preserves
	    // compatibility with JDK 1.2.
	    write(obj == null ? "null" : obj.toString());
	  }

	  /**
	   * This is the system dependent line separator
	   */
	  private static final char[] line_separator = Vm.getProperty("line.separator","\n").toCharArray();

	  /**
	   * This method prints a line separator sequence to the stream.  The value
	   * printed is determined by the system property <xmp>line.separator</xmp>
	   * and is not necessarily the Unix '\n' newline character.
	   */
	  public void println()
	  {
	    synchronized (lock)
	      {
		try
		  {
		    write(line_separator, 0, line_separator.length);
		    if (autoflush)
		      out.flush();
		  }
		catch (IOException ex)
		  {
		    error = true;
		  }
	      }
	  }

	  /**
	   * This methods prints a boolean value to the stream.  <code>true</code>
	   * values are printed as "true" and <code>false</code> values are printed
	   * as "false".
	   *
	   * This method prints a line termination sequence after printing the value.
	   *
	   * @param bool The <code>boolean</code> value to print
	   */
	  public void println(boolean bool)
	  {
	    synchronized (lock)
	      {
		print(bool);
		println();
	      }
	  }

	  /**
	   * This method prints an integer to the stream.  The value printed is
	   * determined using the <code>String.valueOf()</code> method.
	   *
	   * This method prints a line termination sequence after printing the value.
	   *
	   * @param inum The <code>int</code> value to be printed
	   */
	  public void println(int inum)
	  {
	    synchronized (lock)
	      {
		print(inum);
		println();
	      }
	  }

	  /**
	   * This method prints a long to the stream.  The value printed is
	   * determined using the <code>String.valueOf()</code> method.
	   *
	   * This method prints a line termination sequence after printing the value.
	   *
	   * @param lnum The <code>long</code> value to be printed
	   */
	  public void println(long lnum)
	  {
	    synchronized (lock)
	      {
		print(lnum);
		println();
	      }
	  }

	  /**
	   * This method prints a float to the stream.  The value printed is
	   * determined using the <code>String.valueOf()</code> method.
	   *
	   * This method prints a line termination sequence after printing the value.
	   *
	   * @param fnum The <code>float</code> value to be printed
	   */
	  public void println(float fnum)
	  {
	    synchronized (lock)
	      {
		print(fnum);
		println();
	      }
	  }

	  /**
	   * This method prints a double to the stream.  The value printed is
	   * determined using the <code>String.valueOf()</code> method.
	   *
	   * This method prints a line termination sequence after printing the value.
	   *
	   * @param dnum The <code>double</code> value to be printed
	   */
	  public void println(double dnum)
	  {
	    synchronized (lock)
	      {
		print(dnum);
		println();
	      }
	  }

	  /**
	   * This method prints an <code>Object</code> to the stream.  The actual
	   * value printed is determined by calling the <code>String.valueOf()</code>
	   * method.
	   *
	   * This method prints a line termination sequence after printing the value.
	   *
	   * @param obj The <code>Object</code> to print.
	   */
	  public void println(Object obj)
	  {
	    synchronized (lock)
	      {
		print(obj);
		println();
	      }
	  }

	  /**
	   * This method prints a <code>String</code> to the stream.  The actual
	   * value printed depends on the system default encoding.
	   *
	   * This method prints a line termination sequence after printing the value.
	   *
	   * @param str The <code>String</code> to print.
	   */
	  public void println(String str)
	  {
	    synchronized (lock)
	      {
		print(str);
		println();
	      }
	  }

	  /**
	   * This method prints a char to the stream.  The actual value printed is
	   * determined by the character encoding in use.
	   *
	   * This method prints a line termination sequence after printing the value.
	   *
	   * @param ch The <code>char</code> value to be printed
	   */
	  public void println(char ch)
	  {
	    synchronized (lock)
	      {
		print(ch);
		println();
	      }
	  }

	  /**
	   * This method prints an array of characters to the stream.  The actual
	   * value printed depends on the system default encoding.
	   *
	   * This method prints a line termination sequence after printing the value.
	   *
	   * @param charArray The array of characters to print.
	   */
	  public void println(char[] charArray)
	  {
	    synchronized (lock)
	      {
		print(charArray);
		println();
	      }
	  }

	  /**
	   * This method writes a single char to the stream. 
	   * 
	   * @param ch The char to be written, passed as a int
	   */
	  public void write(int ch)
	  {
	  	char[] cc = new char[1];
	  	cc[0] = (char)ch;
	  	write(cc,0,1);
	  }


	  /**
	   * This method writes <code>count</code> chars from the specified
	   * <code>String</code> to the output starting at character position
	   * <code>offset</code> into the <code>String</code>
	   *
	   * @param str The <code>String</code> to write chars from
	   * @param offset The offset into the <code>String</code> to start writing from
	   * @param count The number of chars to write.
	   */
	  public void write(String str, int offset, int count)
	  {
	  	write(Vm.getStringChars(str),offset,count);
	  }

	  /**
	   * This method write all the chars in the specified array to the output.
	   *
	   * @param charArray The array of characters to write
	   */
	  public void write(char[] charArray)
	  {
	  	write(charArray, 0, charArray.length);
	  }  

	  /**
	   * This method writes the contents of the specified <code>String</code>
	   * to the underlying stream.
	   *
	   * @param str The <code>String</code> to write
	   */
	  public void write(String str)
	  {
	    write(str, 0, str.length());
	  }  

}
//####################################################
