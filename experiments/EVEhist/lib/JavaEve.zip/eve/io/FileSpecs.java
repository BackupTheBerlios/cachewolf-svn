package eve.io;

import java.io.IOException;
import java.util.Vector;

import eve.sys.Cache;
import eve.sys.Time;
import eve.sys.Vm;
import eve.util.Comparer;
import eve.util.SimpleCollator;
import eve.util.StringCollator;
import eve.util.Utils;
import eve.util.mVector;

/**
 * This holds information about a file.
 * Normally this would be available through individual methods calls on a file
 * (such as isDirectory()) but when processing large lists of files it is more
 * efficient to have this information available in a static data structure. 
 */
public class FileSpecs implements FilePermissions, FileConstants{
	/**
	 * The parent directory. If this is null then usually the name will be 
	 * the full path name of the file. 
	 */
	public File parent;
	/**
	 * The name or possibly full path of the file. This will not normally
	 * contain any directory separators if parent is not null. If parent is null
	 * then this may be the entire file path.
	 */
	public String name;
	/**
	 * Contains FilePermissions.FLAG_XXX or the Unix permission values ORed together.
	 */
	public int flagsAndPermissions;
	/**
	 * Holds whether the file exists.
	 */
	public boolean exists;
	/**
	 * Holds if the file is a directory.
	 */
	public boolean isDirectory;
	/**
	 * Holds if the file is a symbolic link.
	 */
	public boolean isSymbolicLink;
	/**
	 * The modified time represented as a long.
	 */
	public long modifiedTime;
	/**
	 * The length of the file if not a directory.
	 */
	public long length;
	
	public synchronized static void setCollator(StringCollator collator)
	{
		nameComparer = collator;
	}
	
	private static StringCollator nameComparer;
	
	public static synchronized StringCollator getCollator()
	{
		if (nameComparer == null) nameComparer = new SimpleCollator();
		return nameComparer;
	}
	private static int compare(StringCollator c, String one, String two, boolean ignoreCase, boolean startsWith)
	{
		int o = 0;
		if (ignoreCase) o |= StringCollator.OPTION_IGNORE_CASE;
		if (startsWith)  o |= StringCollator.OPTION_STARTS_WITH;
		return c.compare(Vm.getStringChars(one),0,one.length(), Vm.getStringChars(two),0,two.length(),o);
	}
	private static int compare(StringCollator c, String one, String two, int twoStart, int twoLength, boolean ignoreCase, boolean startsWith)
	{
		int o = 0;
		if (ignoreCase) o |= StringCollator.OPTION_IGNORE_CASE;
		if (startsWith)  o |= StringCollator.OPTION_STARTS_WITH;
		return c.compare(Vm.getStringChars(one),0,one.length(), Vm.getStringChars(two),twoStart,twoLength,o);
	}
	/**
	 * Compare this FileSpecs to another based on list sort options.
	 * @param other the other FileSpecs.
	 * @param listOptions the sort ORed with the directory handling criteria.
	 * The sort criteria can be ONE of LIST_BY_NAME, LIST_BY_TYPE, LIST_BY_DATE, LIST_BY_SIZE.
	 * The directory handling criteria can be ONE of LIST_DIRECTORIES_FIRST, LIST_DIRECTORIES_LAST, LIST_IGNORE_DIRECTORY_STATUS.
	 * @return a value less than zero if the other is considered greater than this, 
	 * greater than zero if the other is considered less than this, 0 if they are
	 * considered equal.
	 */
	public int listCompare(FileSpecs other, int listOptions)
	{
		boolean ignoreCase = true;
		StringCollator nameComparer = getCollator();
		int ret = 0;
		// Check the directory status first.
		if ((listOptions & LIST_IGNORE_DIRECTORY_STATUS) == 0){
			if (isDirectory && !other.isDirectory) ret = -1;
			else if (!isDirectory && other.isDirectory) ret = 1;
			if ((listOptions & LIST_DIRECTORIES_LAST) != 0) ret = -ret;
			if (ret != 0) return ret;
			if (isDirectory && other.isDirectory){
				return compare(nameComparer,name, other.name,ignoreCase,false);
			}
		}
		//
		if ((listOptions & LIST_DONT_SORT) != 0) return 0;
		//
		if ((listOptions & LIST_BY_DATE) != 0){
			if (other.modifiedTime > modifiedTime) ret = -1;
			else if (other.modifiedTime < modifiedTime) ret = 1;
		}else if ((listOptions & LIST_BY_SIZE) != 0){
			if (other.length > length) ret = -1;
			else if (other.length < length) ret = 1;
		}
		if (ret != 0) return ret;
		return compare(nameComparer,name, other.name,ignoreCase,false);
	}
	/**
	 * Get a Comparer that compares two FileSpecs based on the listOptions.
	 * @param listOptions the listOptions to use for comparing.
	 * @return a Comparer that compares two FileSpecs based on the listOptions.
	 */
	public static Comparer getListComparer(final int listOptions)
	{
		return new Comparer(){

			public int compare(Object one, Object two) {
				return ((FileSpecs)one).listCompare((FileSpecs)two,listOptions);
			}
			
		};
	}
	
	private static boolean wordMatches(String what,int start,int length,String prefix,boolean isFullName,StringCollator nameComparer)
	{
		boolean ignoreCase = true;
		String w = what, p = prefix;
		if (isFullName) return compare(nameComparer,p,w,start,length,ignoreCase,false) == 0; 
		else if (p.length() == 0) return true;
		else return compare(nameComparer,p,w,start,length,ignoreCase,true) == 0;
	}
	private static String getExt(String full)
	{
		String s = full;
		int last = s.lastIndexOf('.');
		//if (last == -1 || last == 0) return "."; //This is incorrect.
		if (last == -1) return ".";
		else if (last == 0) return s;
		return s.substring(last);
	}
	private static String getFile(String full)
	{
		String s = full;
		int last = s.lastIndexOf('.');
		if (last == -1 || last == 0) return s;
		return s.substring(0,last);
	}
	
	/**
	 * Filter and sort the Vector of FileSpecs according to the file mask and the listOptions. 
	 * @param fileSpecs the list of FileSpec objects.
	 * @param mask the mask used to filter the file names.
	 * @param listOptions any of the LIST_XXX options ORed together.
	 * @param destination a destination Vector to hold the filtered sorted data or null to create and return a new one.
	 * @return the destination or new Vector.
	 */
	public static Vector filterAndSort(Vector fileSpecs, String mask, int listOptions,Vector destination)
	{
		if (mask == null || mask.equals("*")) mask = "*.*";
		if (destination == null) destination = new Vector();
		String filePrefix,extPrefix;
		boolean fileIsFull,extIsFull;
		//
		{
			String f = getFile(mask);
			int i = f.indexOf('*');
			filePrefix = f;
			fileIsFull = true;
			if (i != -1) {
				filePrefix = f.substring(0,i);
				fileIsFull = false;
			}
			f = getExt(mask);
			i = f.indexOf('*');
			extPrefix = f;
			extIsFull = true;
			if (i != -1) {
				extPrefix = f.substring(0,i);
				extIsFull = false;
			}
		}
		//
		StringCollator c = getCollator();
		boolean ignoreDirectoryStatus = (listOptions & LIST_IGNORE_DIRECTORY_STATUS) != 0;
		boolean alwaysListDirectories = (listOptions & LIST_ALWAYS_INCLUDE_DIRECTORIES) != 0;
		boolean filesOnly = (listOptions & LIST_FILES_ONLY) != 0;
		boolean directoriesOnly = (listOptions & LIST_DIRECTORIES_ONLY) != 0;
		boolean includeHiddenFiles = (listOptions & LIST_DONT_LIST_HIDDEN_FILES) == 0;
		char[] fp = Vm.getStringChars(filePrefix);
		char[] ep = Vm.getStringChars(extPrefix);
		/*
		int s1 = -1, s2 = -1;
		boolean mustHaveExt = false;
		int pi = mask.indexOf('.');
		s1 = mask.indexOf('*');
		if (s1 >= 0) {
			pi = mask.indexOf('.',s1+1);
			if (pi >= 0){
				s2 = mask.indexOf('*',pi+1);
			}
		}*/
		for (int i = 0; i<fileSpecs.size(); i++){
			FileSpecs fs = (FileSpecs)fileSpecs.get(i);
			boolean isDir = fs.isDirectory && !ignoreDirectoryStatus;
			if (isDir && filesOnly) continue;
			if (!isDir && directoriesOnly) continue;
			if (!includeHiddenFiles && ((fs.flagsAndPermissions & FLAG_HIDDEN) != 0)) continue;
			if (!isDir || !alwaysListDirectories){
				String fileName = fs.name;
				if (fileName == null) continue;
				int idx = fileName.lastIndexOf('.');
				if (idx == -1) idx = fileName.length();
				if (!wordMatches(fileName,0,idx,filePrefix,fileIsFull,c)) continue;
				idx = fileName.lastIndexOf('.');
				if (idx == -1){
					fileName = ".";
					idx = 0;
				}
				if (!wordMatches(fileName,idx,fileName.length()-idx,extPrefix,extIsFull,c)) {
					continue;
				}
			}
			destination.add(fs);
		}
		//
		if ((listOptions & LIST_DONT_SORT) == 0){
			Object[] all = new Object[destination.size()];
			destination.copyInto(all);
			Utils.sort(all,getListComparer(listOptions),(listOptions & LIST_DESCENDING) != 0);
			destination.clear();
			mVector.addAll(destination, all);
		}
		return destination;
	}
	/**
	 * Set this FileSpecs to be that of a specific file.
	 * @param src the file to get the data from.
	 * @return this FileSpecs
	 */
	public FileSpecs getFrom(File src)
	{
		
		parent = src.getParentFile();
		name = src.getFileExt();
		exists = src.exists();
		isDirectory = src.isDirectory();
		isSymbolicLink = src.isSymbolicLink();
		try{
			flagsAndPermissions = src.getPermissionsAndFlags(ALL_DOS_FLAGS|ALL_UNIX_PERMISSIONS);
			Time t = (Time)Cache.get(Time.class); 
			modifiedTime = src.getModified(t).getTime();
			Cache.put(t);
			length = src.getLength();
		}catch(IOException e){}
		return this;
	}
	
	/**
	 * This returns the name field of the FileSpec.
	 */
	public String toString()
	{
		String ret = name;
		if (isDirectory) ret += "/";
		return ret;
	}
	/**
	 * This is called if a FileSpecs object is placed in the cache.
	 */
	public void cached()
	{
		
	}
	/*
	public static void main(String[] args)
	{
		Vm.startEve(args);
		File parent = new File("c:\\projects\\eve");
		String[] all = parent.list();
		Vector v = new Vector();
		File check = parent.getNew("");
		for (int i = 0; i<all.length; i++){
			check.set(parent,all[i]);
			v.add(new FileSpecs().getFrom(check));
		}
		v = FileSpecs.filterAndSort(v, "a*.*", LIST_DIRECTORIES_LAST, null);
		System.out.println(v);
		Vm.exit(0);
	}
	*/
}
