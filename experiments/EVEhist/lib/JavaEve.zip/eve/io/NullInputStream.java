/*
 * Created on Nov 20, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class NullInputStream extends InputStream {
	boolean returnError;
	/**
	 * Create a NullInputStream that will either always throw an IOException
	 * or will always return EOF.
	 * @param returnError if this is true any attempted read will throw an IOException,
	 * otherwise it will return EOF.
	 */
	public NullInputStream(boolean returnError) {
		this.returnError = returnError;
	}
	public int read() throws IOException
	{
		if (!returnError) return -1;
		throw new IOException("Cannot read from the stream.");
	}
	public int read(byte[] dest, int offset, int count) throws IOException
	{
		return read();
	}
	public long skip(long toSkip) throws IOException
	{
		if (!returnError) return 0;
		throw new IOException("Cannot read from the stream.");
	}
	public void close() throws IOException
	{
		returnError = true;
	}
}

//####################################################
