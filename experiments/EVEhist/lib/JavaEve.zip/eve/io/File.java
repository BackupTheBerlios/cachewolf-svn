/*
 * Created on Mar 10, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import eve.applet.EveApplet;
import eve.sys.Cache;
import eve.sys.Device;
import eve.sys.Handle;
import eve.sys.Locale;
import eve.sys.Time;
import eve.sys.Vm;
import eve.sys.Wrapper;
import eve.util.CharArray;
import eve.util.StringModifier;
import eve.util.Textable;
import eve.util.Utils;
import eve.util.mVector;
import eve.util.mString;

/**
 * The base implementation of this class represents a File on the local file system,
 * but it is different from a java.io.File in a number of ways:
 * <p>
 * 1. It is mutable - the set() methods can be used to change the File that it refers to.
 * <br>
 * 2. It may be overridden so that it does not access any local File resources at all.
 * However if you are doing that, it is better to override FileAdapter instead to ensure
 * that you do not use any local File system resources.
 * 
 * @author Michael L Brereton
 *
 */
//####################################################
public class File implements FileConstants, Textable,  FilePermissions{
//####################################################
	protected CharArray name = new CharArray(); //Do not move this. It must be first.
	public Object getBestFileChooser(FileChooserParameters fcp)
	{
		return null;
	}

//	-------------------------------------------------------------------
	private static int curTemp = 1000;
//	-------------------------------------------------------------------
	/**
	* This creates an empty temporary file with the specified prefix and suffix. If the
	* suffix is null then ".tmp" will be used. If the dir is null, the system temporary
	* folder will be used. Note that this method may return a file name that is different
	* from the requested file name. This depends on the underlying system and how it provides
	* temporary file support.
	**/
//	===================================================================
	public File createTempFile(String prefix,String suffix,File dir)
//	===================================================================
	{
		File f = (File)this;
		if (suffix == null) suffix = "tmp";
		if (prefix == null) prefix = "temp";
		if (suffix.length() > 0 && suffix.charAt(0) == '.') suffix = suffix.substring(1);
		if (dir == null){
			String d = (String)f.getNew("").getInfo(f.INFO_TEMPORARY_DIRECTORY).getObject();
			if (d == null) return null;
			dir = f.getNew(d);
			if (!dir.isDirectory()) return null;
		}	
		while(true){
			File tryFile = f.getNew(dir,prefix+(++curTemp)+"."+suffix);
			if (!tryFile.exists()){
				try{
					OutputStream raf = tryFile.toWritableStream(false);
					raf.close();
					tryFile.deleteOnExit();
					return tryFile;
				}catch(IOException e){
				}
			}
		}
	}
	/**
	* This creates an empty file with a specific name in a temporary directory. If the file
	* already exists in the directory it will be deleted and the new one will be created. If
	* dir is null then the file will be created in the system temporary directory.
	**/
//	===================================================================
	public File createTempFile(String fileName,File dir)
//	===================================================================
	{
		File f = (File)this;
		File temp = createTempFile(null,null,dir);
		if (temp == null) return null;
		if (dir == null) dir = temp.getParentFile();
		File want = f.getNew(dir,fileName);
		want.delete();
		if (!temp.rename(fileName)) return null;
		File other = f.getNew(dir,fileName);
		other.deleteOnExit();
		return want;
	}
	private static Object openFolder, closedFolder, page, drive;
	/**
	* Get one of the icons: OpenFolderIcon, ClosedFolderIcon and PageIcon.
	**/
//	===================================================================
	public static Object getIcon(int whichIcon)
//	===================================================================
	{
		switch(whichIcon){
			case OpenFolderIcon: 
				if (openFolder == null) openFolder = Device.loadPicture("eve/OpenFolder.png");
				return openFolder;
			case ClosedFolderIcon:
				if (closedFolder == null) closedFolder = Device.loadPicture("eve/ClosedFolder.png");
				return closedFolder;
			case PageIcon: case FileIcon:
				if (page == null) page = Device.loadPicture("eve/Page.png");
				return page;
			case DriveIcon:
				if (drive == null) drive = Device.loadPicture("eve/Drive.png");
				return drive;
			default:
				return null;
		}
	}


	/**
	* Get a new File object given the directory and new path. This is for objects which
	* inherit from File. The default implementation of this will call getNewInstance()
	* and then call set(File directory,String path).
	* If you do not override getNew() you must override getNewInstance().
	**/
//	===================================================================
	public File getNew(File directory,String path)
//	===================================================================
	{
		File nw = getNewInstance();
		nw.set(directory,path);
		return nw;
	}
	/**
	* Lists the files contained in a directory. The strings returned are the
	* names of the files and directories contained within this directory.
	* This method returns null if the file is not a directory or if the directory can't be read or if the
	* operation fails. If mask is null or "*" then all files will be listed.
		<p>
		The default method calls the list() method and then splits the returned char array.
	* @param mask A file mask.
	* @param listAndSortOptions Use the LIST_XXX values OR'ed together.
	* @return An array of file names.
	*/
//	===================================================================
	public String [] list(String mask,int listAndSortOptions)
//	===================================================================
	{
		try{
			CharArray ca = list(mask,listAndSortOptions,null);
			if (ca == null) return null;
			return mString.split(ca.toString(),'|');
		}catch(IOException e){
			return null;
		}
	}
	/**
	* Lists the files contained in a directory using a complex mask - which
	* may actually consist of multiple masks (e.g. "*.jpg,*.gif - Image Files.").
	* @param compositeMask A possibly complex file mask.
	* @param listAndSortOptions Use the LIST_XXX values OR'ed together.
	* @return An array of file names.
	*/
//	===================================================================
	public String [] listMultiple(String compositeMask, int listAndSortOptions)
//	===================================================================
	{
		int idx = compositeMask.indexOf(' ');
		String mask = idx == -1 ? compositeMask : compositeMask.substring(0,idx);
		String[] found;
		if ((mask.indexOf(',') == -1 && mask.indexOf(';') == -1)){
			found = list(mask,listAndSortOptions|LIST_ALWAYS_INCLUDE_DIRECTORIES);
		}else{
			char c = mask.indexOf(',') == -1 ? ';' : ',';
			String masks [] = mString.split(mask,c);
			String dirs [] = new String[0];
			if ((listAndSortOptions & LIST_FILES_ONLY) == 0)
				dirs = list("*.*",LIST_DIRECTORIES_ONLY);
			if ((listAndSortOptions & LIST_DIRECTORIES_ONLY) == 0)
				found = list("*.*",File.LIST_FILES_ONLY|listAndSortOptions);
			else{
				found = dirs;
				dirs = new String[0];
			}
			FileComparer [] fcs = new FileComparer[masks.length];

			Locale loc = Vm.getLocale();
			for (int i = 0; i<masks.length; i++)
				fcs[i] = new FileComparer((File)this,loc,listAndSortOptions,masks[i]);
			if (found == null) return found;
			int left = found.length;
			for (int i = 0; i<found.length; i++){
				boolean matched = false;
				for (int f = 0; f<fcs.length; f++){
					if (fcs[f].matches(found[i])){
						matched = true;
						break;
					}
				}
				if (!matched) {
					found[i] = null;
					left--;
				}
			}
			String [] isMatching = new String[dirs.length+left];
			System.arraycopy(dirs,0,isMatching,0,dirs.length);
			for (int i = 0, d = dirs.length; i<found.length; i++)
				if (found[i] != null)
					isMatching[d++] = found[i];
			found = isMatching;
		}	
		return found;
	}
	/**
	* List files asynchronously. NOTE: version 1.16 of Ewe does not list the files
	* asynchronously - it is synchronous. Therefore it always returns a Handle that
	* is completed.<p>
		By default this method calls the doList() method and then returns a completed Handle
		that either indicates success or failure. Methods that inherit from FileBase are encouraged
		to provide a better version of this (preferrable one that spawns a thread).
	* @param mask The a file maks using '*' characters.
	* @param listAndSortOptions LIST_ and SORT_ options ORed together.
	* @return A Handle which can be used to monitor the progress of the operation.
	*/
//	===================================================================
//	public abstract Handle listFiles(String mask,int listAndSortOptions);
//	===================================================================
	private static char dirSep = 0, pathSep = 0;
	/**
	* This converts any '/' directory separators to the one that is native to the running OS (ie '\' on Windows)
	* and any ';' path separtors to the one that is native to the running OS (ie ':' on Unix/Linux).<p>
	* Your initial constructed path(s) SHOULD use '/' for directories and ';' for path separators.<p>
	* This is generally only necessary for a few system dependant functions and is not necessary for
	* standard file access.
	**/
//	===================================================================
	public static String toSystemDependantPath(String path)
//	===================================================================
	{
		if (path == null) return path;
		if (dirSep == 0){
			try{
				String got = Vm.getProperty("file.separator","/");
				dirSep = got.charAt(0);
				got = Vm.getProperty("path.separator",";");
				pathSep = got.charAt(0);
			}catch(Exception e){
				if (dirSep == 0) dirSep = '/';
				if (pathSep == 0) pathSep = ';';
			}
		}
		if (dirSep != '/') path = path.replace('/',dirSep);
		if (pathSep != ';') path = path.replace(';',pathSep);
		return path;
	}
//	===================================================================
	public boolean renameTo(File newFile)
//	===================================================================
	{
		return move(newFile);
	}
//	private Time tempTime = new Time();

//	===================================================================
	/**
	* Return the time the file was last modified - but this method is not as powerful
	* as getModified(). 
	* @return the time the file was last modified in milliseconds, or 0L if there was
	* an error accessing the modification time.
	*/
	public long lastModified()
//	===================================================================
	{
		try{
			return getSetModified(0,true);
		}catch(IOException e){
			return 0;
		}
	}
//	===================================================================
	/**
	* Set the time the file was last modified - but this method is not as powerful
	* as setModified(). 
	* @param time the time in milliseconds to set the modified time to.
	* @return true if the operation was successful false if not.
	*/
	public boolean setLastModified(long time)
//	===================================================================
	{
		try{
			getSetModified(time,false);
			return true;
		}catch(IOException e){
			return false;
		}
	}
	/**
	* Lists all files on the directory that this File object
	* represents, sorted by name - with directories listed first.
	* This simply calls the list(String mask,int listAndSortOptions) method
	* with the parameters null and 0.
	**/
//	===================================================================
	public String [] list()
//	===================================================================
	{
		return list(null,0);
	}

	/**
	* List all files in this directory using the specified filter.
	* @param filter The filter to use for accepting/rejecting files.
	* @return An array of file names that satisfy the filter.
	*/
//	===================================================================
	public String [] list(FilenameFilter filter)
//	===================================================================
	{
		if (filter == null) throw new NullPointerException();
		String [] got = list();
		if (got == null) return null;
		mVector v = new mVector();
		for (int i = 0; i<got.length; i++)
			if (filter.accept((File)this,got[i])) v.add(got[i]);
		String [] ret = new String[v.size()];
		v.copyInto(ret);
		return ret;
	}
	/**
	* Get a new File object given the directory and new path. This is for objects which
	* inherit from File.
	**/
//	===================================================================
	public File getNew(String path) {if (path == null) path = ""; return getNew(null,path);}
//	===================================================================
	public File getChild(String path) {return getNew((File)this,path);}
//	===================================================================
	public File getCopy()
	{
		return getNew(null,getAbsolutePath());
	}
	/** Returns true if the file exists and can be read. */
//	===================================================================
	public boolean canRead()
//	===================================================================
	{
		return (exists() && !isDirectory());
	}
//	===================================================================
	public boolean isFile()
//	===================================================================
	{
		return (exists() && !isDirectory());
	}
	/** Return the file's path, as specified when created. */
//	===================================================================
	public final String getCreationName()
//	===================================================================
	{
		CharArray ca = getCreationName(((CharArray)Cache.get(CharArray.class)).clear());
		String ret = ca.toString();
		Cache.put(ca);
		return ret;
	}
	/** Return the file's path, as specified when created. */
//	===================================================================
	public CharArray getCreationName(CharArray dest)
//	===================================================================
	{
		if (dest == null) dest = new CharArray();
		dest.append(name.data,0,name.length);
		return dest;
	}



//	===================================================================
	/**
	* Checks if the name of the file as specified during creation is an absolute file name.
	* For it to be an absolute file name the first character has to be '\' or '/' or one of these
	* two characters have to follow a "drive:" spececifier.
	* @return true if the name of the file as specified during creation is an absolute file name.
	*/
	public boolean isAbsolute()
//	===================================================================
	{
		if (name.startsWith("/")) return true;
		if (name.startsWith("\\")) return true;
		int idx = name.indexOf(':');
		if (idx == -1) return false;
		if (idx == name.length()-1) return false;
		if (name.charAt(idx+1) == '/' || name.charAt(idx+1) == '\\') return true;
		return false;
	}
//	-------------------------------------------------------------------
	private static int getPastSeparator(String str,int start)
//	-------------------------------------------------------------------
	{
		int i;
		for (i = start; i>=0; i--){
			char c = str.charAt(i);
			if (c == '\\' || c == '/' || c == ':') continue;
			else break;
		}
		if (i<0) return i;
		for (i--;i>=0; i--){
			char c = str.charAt(i);
			if (c == '\\' || c == '/' || c == ':') return i;
		}
		return -1;
	}
//	-------------------------------------------------------------------
	private static int getParentEnd(String str)
//	-------------------------------------------------------------------
	{
		if (str == null) return -1;
		int len = str.length();
		if (len == 0) return -1;
		for (int i = len-1; i>=0; i--){
			char c = str.charAt(i);
			if (c == '\\' || c == '/' || c == ':'){
				if (i == len-1) return getPastSeparator(str,i);
				else return i;
			}else
				if (i == 0) return -1;
		}
		return -1;
	}
	/** Return only the filename and extension of the file. **/
//	===================================================================
	public String getFileExt()
//	===================================================================
	{
		return getFileExt(getFullPath());
	}
	/** Return only the drive and path of the file. **/
//	===================================================================
	public String getDrivePath()
//	===================================================================
	{
		return getDrivePath(getFullPath());
	}
//	===================================================================
	public static String getFileExt(String str)
//	===================================================================
	{
		//str = str.substring(str.indexOf(':')+1).replace('\\','/');
		int p = getParentEnd(str);
		if (p == -1) return str;
		return str.substring(p+1,str.length());
	}
//	===================================================================
	public static String getDrivePath(String str)
//	===================================================================
	{
		String fe = getFileExt(str);
		if (fe.length() <= str.length()) 
			return str.substring(0,str.length()-fe.length());
		else
			return new String();
	}

	/**
	* Utility to create a path name given a parent and child.
	* @param parent The parent File - which may be null.
	* @param child The child name.
	* @return The correct path name representing the child within the parent directory.
	*/
//	===================================================================
	public static String makePath(File parent,String child)
//	===================================================================
	{
		return makePath(parent == null ? "" : parent.getFullPath(),child);
	}
	/**
	* Utility to create a path name given a parent and child.
	* @param parent The parent path - which may be null.
	* @param child The child name.
	* @return The correct path name representing the child within the parent directory.
	*/
//	===================================================================
	public static String makePath(String parent,String child)
//	===================================================================
	{
		if (parent == null) parent = new String();
		if (parent.length() != 0){
			char c = parent.charAt(parent.length()-1);
			if (c == '/' || c == ':' || c == '\\')
				;
			else parent += "/";
		}
		if (child == null) child = new String();
		return parent+child;
	}

//	===================================================================
	public String getParent()
//	===================================================================
	{
		String str = getFullPath();
		//str = str.substring(str.indexOf(':')+1).replace('\\','/');
		int p = getParentEnd(str);
		if (p == -1) return null;
		char c = (p == 0) ? str.charAt(p) : str.charAt(p-1);
		if (c == '\\' || c == '/' || c == ':') p++;
		return str.substring(0,p);
	}
	/**
	* Get a File object representing the parent direcotry of this File. This is provided
	* so you don't have to decypher the path. Returns null if there is no parent.
	**/
//	===================================================================
	public File getParentFile()
//	===================================================================
	{
		String got = getParent();
		if (got == null) return null;
		return getNew(null,got);
	}
	/**
	* This renames the file in place. It does not move or change the
	* directory of the file. The newName parameter is a single name without
	* directory specifiers within it.
	**/
//	===================================================================
	public boolean rename(String newName)
//	===================================================================
	{
		File f = getParentFile();
		if (f == null) return false;
		return move(getNew(f,newName));
	}
//	===================================================================
	/**
	* Get the Time that the file was last modified.
	* @param dest an optional destination Time object to hold the time.
	* @return the dest Time or a new Time if dest was null. 
	* @throws IOException if an error occurs getting the time.
	*/
	public Time getModified(Time dest) throws IOException
//	===================================================================
	{
		if (dest == null) dest = new Time();
		dest.setTime(getSetModified(0,true));
		return dest;
	}
//	===================================================================
	/**
	* Set the Time the file was last modified.
	* @param modifiedTime the Time to set the modified time to. If this is null then the
	* current time will be used.
	* @throws IOException if an error occurs setting the time.
	*/
	public void setModified(Time modifiedTime) throws IOException
//	===================================================================
	{
		getSetModified(modifiedTime == null ? System.currentTimeMillis() : modifiedTime.getTime(),false);
	}
	/**
	* A quick way of doing getInfo(infoCode,null,null,0);
	* @param infoCode one of the INFO_XXX values.
	* @return A Wrapper holding the returned value. This will never be null, although the
	* data returned by getObject() may be null to indicate failure.
	*/
	public Wrapper getInfo(int infoCode) 
	{
		try{
			return getInfo(infoCode,null,0);
		}catch(IOException e){
			return new Wrapper().setObject(null);
		}
	}
	/**
	* A quick way to get the flags from getInfo().
	**/
//		===================================================================
	public int getFlags()
//		===================================================================
	{
		try{
			Wrapper w = getInfo(INFO_FLAGS,Wrapper.getCached(),0);
			int ret = w.getInt();
			w.cache();
			return ret;
		}catch(IOException e){
			return 0;
		}
	}
//	===================================================================
	/**
	* A quick way to get the program directory for the application.
	**/
//	===================================================================
	public static String getProgramDirectory()
//	===================================================================
	{
		File f = Vm.newFileObject();
		String s = (String)f.getInfo(INFO_PROGRAM_DIRECTORY).getObject();
		if ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_IS_APPLET) != 0) return s;
		return f.getNew(s).getFullPath();
	}
	public File [] roots()
	{
		String [] s = (String [])getInfo(INFO_ROOT_LIST).getObject();
		if (s == null) return null;
		File [] ret = new File[s.length];
		for (int i = 0; i<ret.length; i++)
			ret[i] = getNew(s[i]);
		return ret;
	}
	/**
	* List all the root files in the default file system. This will return null
	* if the roots could not be determined (e.g. under Java 1.1)
	* @return an array of File objects representing the available roots.
	*/
//	===================================================================
	public static File [] listRoots()
//	===================================================================
	{
		return Vm.newFileObject().roots();
	}
	/**
	* Create a directory and all necessary parent directories. Returns false if it could
	* not create the directory, true if it can or if it already exists.
	**/
//	===================================================================
	public boolean mkdirs()
//	===================================================================
	{
		if (isDirectory()) return true;
		mVector v = new mVector();
		File cur = (File)this;
		for (; cur != null; cur = cur.getParentFile())
			if (cur.isDirectory()) break;
			else v.add(cur);
		if (cur == null) return false;
		for (int i = v.size(); i>0;)
			if (!((File)v.get(--i)).createDir()) return false;
		return isDirectory();
	}

//	===================================================================
	public boolean mkdir()
//	===================================================================
	{
		return createDir();
	}
//	===================================================================
	public String toString() 
//	===================================================================
	{
		String got = getCreationName();
		if (got != null) got = got.replace('\\','/');
		return got;
	}
//	===================================================================
	public static String fixupPath(String path)
//	===================================================================
	{
		if (path == null) return "";
		path = path.replace('\\','/');
			int where = path.length()-1;
			while(true){
				if (where < 0) break;
				where = path.lastIndexOf("/..",where);
				if (where <= 0) break;
				if (where < path.length()-3)
					if (path.charAt(where+3) != '/'){
						where--;
						continue;
					}
				int before = path.lastIndexOf('/',where-1);
				if (before == -1) before = where;
				String np = path.substring(0,before)+path.substring(where+3);
				path = np;
				where = path.length()-1;
				continue;
			}
			where = path.length()-1;
			while(true){
				if (where < 0) break;
				where = path.lastIndexOf("/.",where);
				if (where <= 0) break;
				if (where < path.length()-2)
					if (path.charAt(where+2) != '/'){
						where--;
						continue;
					}
				String np = path.substring(0,where)+path.substring(where+2);
				//System.out.println(np);
				path = np;
				where = path.length()-1;
				continue;
			}
		if (path.indexOf(':') != -1){
			char [] chars = Vm.getStringChars(path);
			int i = 0;
			for (i = 0; chars[i] == '/' || chars[i] == '\\'; i++)
				;
			if (i != 0) path = path.substring(i);
		}
		return path;
	}

//	===================================================================
	public static CharArray removeTrailingSlash(CharArray ca)
//	===================================================================
	{
		if (ca == null) return ca;
		int l = ca.length();
		if (l == 0 || l == 1) return ca;
		char[] chars = ca.data;
		char last = chars[l-1];
		char sl = chars[l-2];
		if (last != '/' && last != '\\') return ca;
		if (sl == last || sl == ':') return ca;
		ca.length--;
		return ca;
	}
//	===================================================================
	public static String removeTrailingSlash(String path)
//	===================================================================
	{
		StringModifier ca = ((StringModifier)Cache.get(StringModifier.class)).set(path);
		try{
			removeTrailingSlash(ca);
			if (ca.originalLength == ca.length) return path;
			return ca.toString();
		}finally{
			Cache.put(ca);
		}
	}
	/**
	* This checks to see if the two files refer to the same object in the file
	* system. Currently it does that by comparing their full paths.
	**/
//	===================================================================
	public boolean equals(Object other)
//	===================================================================
	{
		if (this == other) return true;
		if (!(other instanceof File)) return false;
		File f = (File)other;
		return filePathsAreEqual(fixupPath(getFullPath()),fixupPath(f.getFullPath()));
	}
//	===================================================================
	public int hashCode()
//	===================================================================
	{
		return fixupPath(getFullPath()).hashCode();
	}
//	===================================================================
	public boolean filePathsAreEqual(String one,String two)
//	===================================================================
	{
		if ((getFlags() & FLAG_CASE_SENSITIVE) == 0) return one.equalsIgnoreCase(two);
		else return one.equals(two);
	}
	public String getText() {return getFullPath();}
	public void setText(String text) {set(null,text);}

	/**
	* This differs from getFullPath() in that this will convert all '\' characters
	* to '/' characters.
	**/
//	===================================================================
	public String getAbsolutePath() 
//	===================================================================
	{
		return fixupPath(getFullPath());
	}
//	===================================================================
	public File getAbsoluteFile()
//	===================================================================
	{
		return getNew(null,fixupPath(getFullPath()));
	}
//	===================================================================
	public String getCanonicalPath() throws IOException
//	===================================================================
	{
		return fixupPath(getFullPath());
	}
//	===================================================================
	public File getCanonicalFile() throws IOException
//	===================================================================
	{
		return getNew(null,fixupPath(getFullPath()));
	}
//	===================================================================
	public String getName()
//	===================================================================
	{
		return getFileExt();
	}
	/*
//	===================================================================
	public String getPath()
//	===================================================================
	{
		return getDrivePath();
	}
	*/
	/**
	* This tells the File system to consider any cached directory invalid so
	* so that a list() call will do a true lookup.

	* @return A Handle indicating the progress of the refresh.
	*/
//	===================================================================
	public Handle refresh()
//	===================================================================
	{
		return new Handle(Handle.Succeeded,null);
	}
	
	/**
	* Returns true if the other file system is considered the same as this one.
	* By default this compares the class names of this File and the other File and returns
		true if they are equal.
	* @param other another File object representing a File on a possibly different file system.
	* @return true if the two File objects are considered to be on the same system.
	*/
//	===================================================================
	public boolean isSameFileSystem(File other)
//	===================================================================
	{
		return other.getClass().getName().equals(getClass().getName());
	}

	/**
	* Checks if the volume which contains the other File is considered the same as the one that
		contains this File.
	* Generally move() operations will not succeed across volumes.
	* @param other another File object representing a File on a possibly different volume.
	* @return true if the two File objects are considered to be on the same file system and the same volume.
	*/
//	===================================================================
	public boolean isSameVolume(File other)
//	===================================================================
	{
		if (!isSameFileSystem(other)) return false;
		return true;
	}

//	===================================================================
	public static File getTrueParent(File parent,String child,File aFile)
//	===================================================================
	{
		if (child.indexOf('/') != -1 || child.indexOf('\\') != -1){
			return aFile.getNew(parent,child).getParentFile();
		}
		return parent;
	}
//	===================================================================
	public static String getTrueChild(File parent,String child,File aFile)
//	===================================================================
	{
		if (child.indexOf('/') != -1 || child.indexOf('\\') != -1)
			return aFile.getNew(parent,child).getName();
		return child;
	}
	/**
	* A utility method to convert from "r" or "rw" to READ_ONLY or READ_WRITE mode. It will throw
	* an IllegalArgumentException if the mode is not one of these two.
	* @param mode must be "r" or "rw"
	* @return READ_ONLY or READ_WRITE.
	* @exception IllegalArgumentException if mode is not "r" or "rw"
	*/
	/*
//	===================================================================
	public static int convertMode(String mode)
//	===================================================================
	{
		if ("rw".equals(mode)) return READ_WRITE;
		else if (!"r".equals(mode)) throw new IllegalArgumentException("mode must be \"r\" or \"rw\"");
		return READ_ONLY;
	}
//	===================================================================
	public Handle toStream(boolean isRandom,String type) throws IllegalArgumentException
//	===================================================================
	{
		try{
			if (isRandom)
				return new Handle(Handle.Succeeded,toRandomAccessStream(type));
			else if (type.equals("r"))
				return new Handle(Handle.Succeeded,toReadableStream());
			else if (type.equals("a"))
				return new Handle(Handle.Succeeded,toWritableStream(true));
			else if (type.equals("w"))
				return new Handle(Handle.Succeeded,toWritableStream(false));
			else 
				throw new IllegalArgumentException("type must be \"r\" or \"a\" or \"w\"");
		}catch(IllegalArgumentException e){
			throw e;
		}catch(IOException io){
			return new Handle(io);
		}
	}
	*/
	/**
	* Create and return a Stream to use for reading from the File.
	* @return An open Steam that can be used for reading from the File.
	* @exception IOException if an open stream could not be created.
	*/
//	===================================================================
	public InputStream toReadableStream() throws IOException
//	===================================================================
	{
		RandomStream ras = toRandomStream("r");
		ras.setPosition(0);
		return ras;
	}
	/**
	* Create and return a Stream to use for writing to the File. 
	* If the file does not exist it will be created.
	* @param append set this true if you want to append to the existing file.
	* @return An open Steam that can be used for reading from the File.
	* @exception IOException if an open stream could not be created, or if the file exists but could not
	* be written to or erased (if not appending), or if you requested append but append mode is not supported
	* for this File.
	*/
//	===================================================================
	public OutputStream toWritableStream(boolean append) throws IOException
//	===================================================================
	{
		if (exists() && !append) 
			if (!delete()) throw new IOException("Could not open/delete file for writing: "+this);
		RandomStream ras = toRandomStream("rw");
		ras.setPosition(ras.getLength());
		return ras.toOutputStream();
	}
	/**
	* Create and return a RandomAccessStream for reading/writing to the data associated with this File object.
	* @param mode must be "r" or "rw".
	* @return An open RandomAccessStream
	* @exception IOException if an open stream could not be created.
	* @exception IllegalArgument exception if mode is not "r" or "rw"
	*/
//	===================================================================
	public RandomStream toRandomStream(String mode) throws IOException
//	===================================================================
	{
		return new FileRandomStream((File)this,mode);
	}

	/**
	* Get a new File object for the default file system used by the VM. 
	*/
//	===================================================================
	public static File getNewFile()
//	===================================================================
	{
		return Vm.newFileObject();
	}
	/**
	* Get a new File object for the default file system used by the VM.
	*/
//	===================================================================
	public static File getNewFile(String name)
//	===================================================================
	{
		File f = Vm.newFileObject();
		f.set(null,name);
		return f;
	}
	/**
	* Get a new File object for the default file system used by the VM.
	*/
//	===================================================================
	public static File getNewFile(File directory,String name)
//	===================================================================
	{
		File f = Vm.newFileObject();
		f.set(directory,name);
		return f;
	}
//	===================================================================
	/**
	* Get ther permissions/flags for this File - see ewe.io.FilePermissions for a list of
	* the available flag permissions.
	* @param interestedFlags The flags whose values you are interested in.
	* @return The permission/flag types ORed together.
	* @exception IOException if the file does not exist or some other error occured.
	* @exception IllegalArgumentException if one of the flags you are interested in is not supported
	* on this file system.
	*/
//	===================================================================
	public int getPermissionsAndFlags(int interestedFlags) throws IOException, IllegalArgumentException
//	===================================================================
	{
		return (getSetPermissionsAndFlags(true,interestedFlags,0) & interestedFlags);
	}
	/**
	* Change ther permissions/flags for this File - see ewe.io.FilePermissions for a list of
	* the available flag permissions.
	* @param valuesToSet The permissions/flags to set.
	* @param valuesToClear The permissions/flags to clear.
	* @return true if all the requested changes were made, false if not.
	* @exception IOException if the file does not exist or some other IO error occured.
	* @exception IllegalArgumentException if one of the flag values is not supported.
	*/
//	===================================================================
	public boolean changePermissionsAndFlags(int valuesToSet, int valuesToClear) throws IOException, IllegalArgumentException
//	===================================================================
	{
		int val = getSetPermissionsAndFlags(false,valuesToSet,valuesToClear);
		if ((val & valuesToSet) != valuesToSet) return false;
		if ((val & valuesToClear) != 0) return false;
		return true;
	}
	/**
	This is used to implement getPermissionsAndFlags() and changePermissionsAndFlags(). It should
	work like this: 
	<p>
	If isGet is true, then the valuesToSetOrGet parameter will hold the flags that the user is
	interested in. If any of these flags are invalid on this system an IllegalArgumentException should be thrown.
	Otherwise the current state of the flags should be returned - it is OK to return extra flags
	even if they are not specified as flags the user is interested in.
	<p>
	If isGet is false, then the valuesToSetOrGet parameter will hold the flags to set and the valuesToClear parameter
	will hold the flags to clear. If any of these are not valid then an IllegalArgumentException 
	should be thrown. Otherwise the flags should be changed and then the state of the flags AFTER
	the change has been made should be returned.
	**/
//	-------------------------------------------------------------------
	protected int getSetPermissionsAndFlags(boolean isGet, int valuesToSetOrGet, int valuesToClear) throws IOException
//	-------------------------------------------------------------------
	{
		if (hasNative) try{
			return getSetPermissionsAndFlags(nativePath(), isGet, valuesToSetOrGet, valuesToClear);
		}catch(Throwable t){
			Device.checkNoNativeMethod(t);
			hasNative = false;
		}
		return 0;
	}
	/**
	 * Returns a value indicating which of the flags
	 * specified in the interestedFlags parameter is supported by the
	 * underlying system.
	 * @param interestedFlags the flags you wish to check OR'ed together.
	 * @return the supported flags OR'ed together.
	 */
	public int getSupportedPermissionsAndFlags(int interestedFlags)
	{
		if (hasNative) try{
			return getSupportedPermissionsAndFlags() & interestedFlags;
		}catch(Throwable t){
			Device.checkNoNativeMethod(t);
			hasNative = false;
		}
		return 0;
	}
	/**
	* Change the permissions/flags for this File - see eve.io.FilePermissions for a list of
	* the available flag permissions.
	* @param valuesToSet The permissions/flags to set.
	* @param valuesToClear The permissions/flags to clear.
	* @return the new value of the permissions and flags but only containing
	* bits specified by valuesToSet and valuesToClear.
	* @exception IOException if the file does not exist or some other IO error occured.
	*/
	//===================================================================
	public int setPermissionsAndFlags(int valuesToSet, int valuesToClear) throws IOException, IllegalArgumentException
	//===================================================================
	{
		return getSetPermissionsAndFlags(false,valuesToSet,valuesToClear);
	}
	/**
	 * Perform a Unix like chmod changing all the unix owner/group/other permissions
	 * in one operation.
	 * @param newPermissions the new state for all the owner/group/other permissions.
	 * @return the new state of the owner/group/other permissions.
	 * @throws IOException if an IO error occured while changing the permissions. If
	 * the method fails because the current process does not have the rights to change
	 * the file, the method NOT throw an exception.
	 */
	public int chmod(int newPermissions) throws IOException
	{
		return setPermissionsAndFlags(newPermissions, FilePermissions.ALL_UNIX_PERMISSIONS ^ newPermissions);
	}
	/**
	 * Change the user and group if supported.
	 * @param newUser the new user name. This can be null if newGroup is not null.
	 * @param newGroup the new group name. This can be null if newUser is not null.
	 * @return true on success, false if the values are invalid or you do not
	 * have permission to make the change.
	 * @throws IOException if there an IO error occured.
	 * @throws NullPointerException if both newUser and newGroup is null.
	 */
	public boolean chown(String newUser, String newGroup) throws IOException
	{
		if (newUser == null && newGroup == null)
			throw new NullPointerException();
		return setInfo(INFO_SET_USER_AND_GROUP,new Wrapper().setObject(new String[]{newUser,newGroup}),0);
	}
	
	/**
	 * Create a symbolic link to a specified target file.
	 * @param target the file to link to.
	 * @return true if created, false if not (if not supported on the platform).
	 */
	public boolean createSymbolicLink(String target)
	{
		if (hasNative) try{
			return createSymbolicLink(nativePath(),target);
		}catch(Throwable t){
			Device.checkNoNativeMethod(t);
			hasNative = false;
		}
		return false;
	}
	/**
	 * If this file is a symbolic link, return the target of the link.
	 * @return the target of the symbolic link.
	 */
	public File getSymbolicLinkTarget()
	{
		String got = (String)getInfo(INFO_SYMBOLIC_LINK_TARGET).getObject();
		if (got == null) return null;
		return getNew(got);
	}

	private static String spacing = "   ";
//	-------------------------------------------------------------------
	private static String addTime(String prompt,Time t)
//	-------------------------------------------------------------------
	{
		if (t == null) return "";
		t.format = Vm.getLocale().getString(Locale.LONG_DATE_FORMAT,0,0);
		String ret = prompt+"\n"+spacing+t.toString()+"\n"+spacing;
		t.format = Vm.getLocale().getString(Locale.TIME_FORMAT,0,0);
		ret += t.toString()+"\n";
		return ret;
	}
	private static final String [] permissions = new String[]
	{"Read","Write","Execute","Read","Write","Execute","Read","Write","Execute","Hidden","Archive","System","Read-only","ROM","ROM-Module"};
	private static final int [] permissionValues = new int []
	{
	OWNER_READ,OWNER_WRITE,OWNER_EXECUTE,GROUP_READ,GROUP_WRITE,GROUP_EXECUTE,OTHER_READ,OTHER_WRITE,OTHER_EXECUTE,
	FLAG_HIDDEN,FLAG_ARCHIVE,FLAG_SYSTEM,FLAG_READONLY,FLAG_ROM,FLAG_ROMMODULE
	};

//	-------------------------------------------------------------------
	private static String getFlag(int flag,int presentFlag)
//	-------------------------------------------------------------------
	{

		if ((flag & presentFlag) == 0) return "";
		for (int i = 0; i<permissionValues.length; i++)
			if (permissionValues[i] == flag) return permissions[i]+" ";
		return "";
	}
	/**
	 * Get the owner user name of the file or null if that is
	 * not supported on the platform. 
	 */
	public String getOwner() 
	{
		return (String)getInfo(INFO_OWNER).getObject(String.class); 
	}
	/**
	 * Get the group name of the file or null if that is
	 * not supported on the platform. 
	 */
	public String getGroup() 
	{
		return (String)getInfo(INFO_GROUP).getObject(String.class); 
	}
	
	//===================================================================
	public String getPropertiesString()// throws IOException
	//===================================================================
	{
		String ret = "";
		ret += "Name:\n"+spacing+getName()+"\n";
		String s = getParent();
		if (s != null) ret += "Location:\n"+spacing+s+"\n";
		//
		try{
		if (isSymbolicLink()) ret += "Links to:\n"+spacing+getSymbolicLinkTarget()+"\n";
		}catch(Exception e){ret += "Could not determine symbolic link target.\n";}
		//
		try{
		if (!isDirectory()) ret += "Size:\n"+spacing+Vm.getLocale().format(getLength(),",",0)+" bytes\n";
		}catch(Exception e){ret += "Could not determine file size.\n";}
		//
		try{
			Time [] times = (Time [])getInfo(INFO_FILE_TIMES).getObject();
			if (times == null) {
				times = new Time[3];
				times[1] = getModified(new Time());
			}
			if (times != null){
				ret += addTime("Created:",times[0]);
				ret += addTime("Modified:",times[1]);
				ret += addTime("Accessed:",times[2]);
			}
		}catch(Exception e){ret += "Could not determine file times.\n";}
		Object owner = getInfo(INFO_OWNER).getObject();
		if (owner != null) ret += "Owner:\n"+spacing+owner+"\n";
		Object group = getInfo(INFO_GROUP).getObject();
		if (group != null) ret += "Group:\n"+spacing+group+"\n";

		int value = 0;
		try{
		if (getSupportedPermissionsAndFlags(ALL_UNIX_PERMISSIONS) == ALL_UNIX_PERMISSIONS){
			value = getPermissionsAndFlags(ALL_UNIX_PERMISSIONS);
			if ((value & (OWNER_READ|OWNER_WRITE|OWNER_EXECUTE)) != 0)
				ret += "Owner Permissions:\n"+spacing+getFlag(OWNER_READ,value)+getFlag(OWNER_WRITE,value)+getFlag(OWNER_EXECUTE,value)+"\n";
			if ((value & (GROUP_READ|GROUP_WRITE|GROUP_EXECUTE)) != 0)
				ret += "Group Permissions:\n"+spacing+getFlag(GROUP_READ,value)+getFlag(GROUP_WRITE,value)+getFlag(GROUP_EXECUTE,value)+"\n";
			if ((value & (OTHER_READ|OTHER_WRITE|OTHER_EXECUTE)) != 0)
				ret += "Other Permissions:\n"+spacing+getFlag(OTHER_READ,value)+getFlag(OTHER_WRITE,value)+getFlag(OTHER_EXECUTE,value)+"\n";
		}
		}catch(Exception e){ret += "Could not determine permissions.\n";}
		try{
		value = getPermissionsAndFlags(ALL_DOS_FLAGS);
		if (value != 0)
			ret += "Attributes:\n"+spacing+getFlag(FLAG_READONLY,value)+getFlag(FLAG_ARCHIVE,value)+getFlag(FLAG_HIDDEN,value)+getFlag(FLAG_SYSTEM,value)+getFlag(FLAG_ROM,value)+getFlag(FLAG_ROMMODULE,value)+"\n";
		}catch(Exception e){ret += "Could not determine file flags.\n";}
		return ret;
	}
private java.io.File jfile;

/**
* Modifies the File to point to a different file on the file system. This
* means that ewe.io.File objects are not immutable, but this avoids a lot
* of object creation when dealing with large directories.
**/
//===================================================================
public void set(File directory,String path) 
//===================================================================
{
	try{
		name.length = 0;
		name.append(_nativeCreate(directory,path)); 
		jfile = new java.io.File(name == null ? "" : name.toString());
		String s = _jfilegetAbsolutePath();
	}catch(Throwable t){
		jfile = null;
	}
}
//===================================================================
public void setJavaFile(java.io.File file)
//===================================================================
{
	try{
		jfile = file;
		name.length = 0; // Used by _jfilegetAbsolutePath;
		name.append(_jfilegetAbsolutePath());
	}catch(Throwable t){
		jfile = null;
	}
}
//===================================================================
public void setJavaFile(java.io.File dir, String file)
//===================================================================
{
	set(new File(dir),file);
}
//===================================================================
public File(java.io.File file)
//===================================================================
{
	setJavaFile(file);
}
//===================================================================
public File(java.io.File dir, String file)
//===================================================================
{
	setJavaFile(dir,file);
}
//-------------------------------------------------------------------
protected String _jfilegetAbsolutePath()
//-------------------------------------------------------------------
{
	String s = jfile.getAbsolutePath().replace('\\','/');
	if (name.length() == 0 && (s.endsWith("//")))
		s = s.substring(0,s.length()-1);
	return s;	
}
private static final String odd = "/\\";
//-------------------------------------------------------------------
private String _nativeCreate(File directory,String path)
//-------------------------------------------------------------------
{
	//path = removeTrailingSlash(path);
	if (directory == null) return path;
	if (directory.jfile == null) return path;
	if (path == null) path = "";
	java.io.File f = new java.io.File(directory.jfile,path);
	String s = f.getPath();
	if (s.startsWith(odd)) s = "/"+s.substring(2); //Fix a bug in Microsoft's JVM
	else if (s.indexOf(odd) != -1) {
		int i = s.indexOf(odd);
		s = s.substring(0,i)+"/"+s.substring(i+2);
	}
	return s;
}

//===================================================================
protected File()
//===================================================================
{
}

//===================================================================
public File(String name)
//===================================================================
{
	this((eve.io.File)null,name);
}
//===================================================================
public File(File directory,String path)
//===================================================================
{
	if (directory == null && path == null) return;
	name.clear().append(_nativeCreate(directory,path));
	try{jfile = new java.io.File(name.toString());}catch(Throwable t){}
}
/* (non-Javadoc)
 * @see eve.io.FileBase#getNewInstance()
 */
protected File getNewInstance() {
	return new File();
}
/* (non-Javadoc)
 * @see eve.io.FileBase#createDir()
 */
public boolean createDir()
{
	return jfile.mkdir();
}

//===================================================================
public boolean delete()
//===================================================================
{
	return jfile.delete();
}
//===================================================================
public boolean exists()
//===================================================================
{
	try{
		return jfile.exists();
	}catch(Throwable t){
		return false;
	}
}

public boolean canWrite()
{
	return jfile.canWrite();
}

public boolean isHidden()
{
	return jfile.isHidden();
}
//===================================================================
public boolean isDirectory() 
//===================================================================
{
	try{
		return jfile.isDirectory();
	}catch(Throwable t){
		return false;
	}
}
private String nativePath()
{
	return toSystemDependantPath(jfile.getAbsolutePath());	
}

public boolean isSymbolicLink()
{
	if (hasNative) try{
		return isSymbolicLink(nativePath());
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	return false;
}
public String getFullPath()
{
	String s = _jfilegetAbsolutePath();
	if (s.endsWith(".")){
		if (s.endsWith("/.") && s.length() > 2)
			s = s.substring(0,s.length()-2);
	}else if (s.endsWith("/")){
		if (s.endsWith("/./")  && s.length() > 3)
			s = s.substring(0,s.length()-3);
	}
	return s;
}

/* (non-Javadoc)
 * @see eve.io.FileBase#deleteOnExit()
 */
public void deleteOnExit()
{
	jfile.deleteOnExit();
}
/**
 * This method creates a new file of zero length with the same name as
 * the path of this <code>File</code> object if an only if that file
 * does not already exist.
 * <p>
 * A <code>SecurityManager</code>checkWrite</code> check is done prior
 * to performing this action.
 *
 * @return <code>true</code> if the file was created, <code>false</code> if
 * the file alread existed.
 *
 * @exception IOException If an I/O error occurs
 * @exception SecurityException If the <code>SecurityManager</code> will
 * not allow this operation to be performed.
 *
 * @since 1.2
 */
public boolean createNewFile() throws IOException
{
	return jfile.createNewFile();
}

private String[] doList(String mask, int listAndSortOptions)
{
	String msk = mask;
	if ((listAndSortOptions & LIST_CHECK_FOR_ANY_MATCHING_CHILDREN) != 0)
		msk = null;
	FileComparer fc = new FileComparer(File.this,Vm.getLocale(),listAndSortOptions,msk);
	if (!jfile.isDirectory()) return null;
	String [] got = jfile.list(fc);
	if (got == null) got = new String[0];
	if ((listAndSortOptions & LIST_CHECK_FOR_ANY_MATCHING_CHILDREN) != 0){
		//if (got.length == 0) got = null;
		//else got = new String[0];
	}else{
		Utils.sort(got,fc,((listAndSortOptions & LIST_DESCENDING) != 0));
	}
	return got;
}

public CharArray list(String mask, int listAndSortOptions,CharArray dest) throws IOException
{
	if (dest == null) dest = new CharArray();
	String[] all = doList(mask,listAndSortOptions);
	if (all == null) return null;
	for (int i = 0; i<all.length; i++){
		if (i != 0) dest.append("|");
		dest.append(all[i]);
	}
	return dest;
}
/* (non-Javadoc)
 * @see eve.io.FileBase#getSetModified(eve.sys.Time, boolean)
 */
protected long getSetModified(long time, boolean doGet) throws IOException
{
	if (!exists()) throw new IOException("File does not exist.");
	if (doGet){
		return jfile.lastModified();
	}else{
		jfile.setLastModified(time);
		return time;
	}
}
/* (non-Javadoc);
 * @see eve.io.FileBase#move(eve.io.File)
 */
public boolean move(File newFile)
{
	return jfile.renameTo(newFile.jfile);
}

protected Wrapper getSetInfo(int infoCode, Wrapper sourceParameters, int options,boolean isGet) throws IOException
{
	if (sourceParameters == null) sourceParameters = new Wrapper();
	Wrapper dest = sourceParameters;
	if (isGet){
		switch(infoCode){
		case INFO_ROOT_LIST:
			//try{
				java.io.File [] roots = java.io.File.listRoots();
				if (roots == null) return null;
				String [] r = new String[roots.length];
				for (int i = 0; i<roots.length; i++)
					r[i] = roots[i].getAbsolutePath();
				sourceParameters.setObject(r);
				break;
				/*
			}catch(Error e){
				if (gotRoots != null) return gotRoots;
				if (isDrive('C') != null){
					ewe.util.Vector v = new ewe.util.Vector();
					v.add("A:/"); v.add("C:/");
					char ch;
					for (ch = 'D'; ch <= 'Z'; ch++){
						String d = isDrive(ch);
						if (d != null) v.add(d);
					}
					gotRoots = new String[v.size()];
					v.copyInto(gotRoots);
					return gotRoots;
				}
				else
					return "/";
			}
					*/
		case INFO_PROGRAM_DIRECTORY:
			String ret = EveApplet.programDirectory; 
			if (ret == null) ret = ".";
			if (ret.equals("."))
				if (Vm.getApplet() != null)
					ret = "/";
			ret = removeTrailingSlash(ret);
			return sourceParameters.setObject(ret);
		case INFO_TEMPORARY_DIRECTORY:
			try{
				java.io.File tf = java.io.File.createTempFile("eve",null,null);
				sourceParameters.setObject(tf.getParent().toString());
				tf.delete();
			}catch(IOException e){
				sourceParameters.clear();
			}
			break;
		case INFO_DEVICE_NAME:
			sourceParameters.setObject("My Computer");
			break;
		case INFO_SYMBOLIC_LINK_TARGET:
			dest.clear();
			if (hasNative)try{
				dest.setObject(getLinkTarget(nativePath()));
			}catch(Throwable t){
				Device.checkNoNativeMethod(t);
				hasNative = false;
			}
			break;
		case INFO_OWNER:
		case INFO_GROUP:
			dest.clear();
			if (hasNative)try{
				dest.setObject(getOwnerOrGroup(nativePath(), infoCode == INFO_GROUP));
			}catch(Throwable t){
				Device.checkNoNativeMethod(t);
				hasNative = false;
			}
			break;
			
			/*
		case INFO_FLAGS:
		case INFO_SYSTEM_TYPE:
			if (!(resultDestination instanceof ewe.sys.Long)) 
				resultDestination = new ewe.sys.Long();
			((ewe.sys.Long)resultDestination).value = (infoCode == INFO_SYSTEM_TYPE) ? DOS_SYSTEM : 0;
			return resultDestination;
		case INFO_FILE_TIMES:
			if (!(resultDestination instanceof Time []))
				resultDestination = new Time[3];
			for (int i = 0; i<3; i++)
				((Time[])resultDestination)[i] = null;
			Time t = new Time();
			getSetModified(t,true);
			((Time[])resultDestination)[1] = t;
			return resultDestination;
			*/
		default:
			if (sourceParameters != null) sourceParameters.clear();
			break;
		}
		return sourceParameters;
	}else{
		switch(infoCode){
			case INFO_SET_USER_AND_GROUP:
			if (hasNative) try{
				Object[] a = (Object[])sourceParameters.getObject();
				String usr = (String)a[0], group = (String)a[1];
				dest.setBoolean(chown(nativePath(),usr,group));
				break;
			}catch(Throwable t){
				Device.checkNoNativeMethod(t);
				hasNative = false;
			}
			dest.setBoolean(false);
			break;
			default:
				if (sourceParameters != null) sourceParameters.clear();
				break;
		}
		return sourceParameters;
	}
}
public Wrapper getInfo(int infoCode, Wrapper sourceParameters, int options) throws IOException
{
	return getSetInfo(infoCode,sourceParameters,options,true);
}
public boolean setInfo(int infoCode,Wrapper sourceParameters,int options)
{
	try{
		return getSetInfo(infoCode,sourceParameters,options,false).getBoolean();
	}catch(Exception e){
		return false;
	}
}
//===================================================================
public java.io.File toJavaFile()
//===================================================================
{
	return jfile;
}

//===================================================================
public long getLength()
//===================================================================
{
	return jfile.length();
}

/*
public boolean tryDelete(int tryWaitTime)
{
	if (tryWaitTime <= 0) return delete();
	long end = System.currentTimeMillis()+tryWaitTime;
	while(true){
		if (delete()) return true;
		long left = end-System.currentTimeMillis();
		if (left <= 0) return false;
		if (left > 10) left = 10;
		try{
			Thread.sleep(left);
		}catch(Exception e){}
	}
}
public InputStream tryRead(int tryWaitTime) throws IOException
{
	if (tryWaitTime <= 0) return toReadableStream();
	long end = System.currentTimeMillis()+tryWaitTime;
	while(true){
		try{
			return toReadableStream();
		}catch(IOException e){}
		long left = end-System.currentTimeMillis();
		if (left <= 0) throw new IOException("Cannot open for reading: "+this);
		if (left > 10) left = 10;
		try{
			Thread.sleep(left);
		}catch(Exception e){}
	}
}
public boolean tryMove(File newFile, int tryWaitTime)
{
	if (tryWaitTime <= 0) return move(newFile);
	long end = System.currentTimeMillis()+tryWaitTime;
	while(true){
		if (move(newFile)) return true;
		long left = end-System.currentTimeMillis();
		if (left <= 0) return false;
		if (left > 10) left = 10;
		try{
			Thread.sleep(left);
		}catch(Exception e){}
	}
}
*/
public boolean setExecutable(boolean executable, boolean ownerOnly)
{
	if (getSupportedPermissionsAndFlags(OWNER_EXECUTE) == 0)
		return false;
	try{
		int s = OWNER_EXECUTE; if (!ownerOnly) s |= OTHER_EXECUTE|GROUP_EXECUTE;
		int got = setPermissionsAndFlags(executable ? s : 0, executable ? 0 : s);
		if (executable) return (got & s) == s;
		else return (got & s) == 0;
	}catch(IOException e){
		return false;
	}
}
public boolean setReadable(boolean readable, boolean ownerOnly)
{
	if (getSupportedPermissionsAndFlags(OWNER_READ) == 0)
		return false;
	try{
		int s = OWNER_READ; if (!ownerOnly) s |= OTHER_READ|GROUP_READ;
		int got = setPermissionsAndFlags(readable ? s : 0, readable ? 0 : s);
		if (readable) return (got & s) == s;
		else return (got & s) == 0;
	}catch(IOException e){
		return false;
	}
}
public boolean setWritable(boolean writable, boolean ownerOnly)
{
	if (getSupportedPermissionsAndFlags(OWNER_WRITE) == 0){
		if (getSupportedPermissionsAndFlags(FLAG_READONLY) != 0)try{
			int got = setPermissionsAndFlags(writable ? 0 : FLAG_READONLY, writable ? FLAG_READONLY : 0);
			if (writable) return (got & FLAG_READONLY) == 0;
			else return (got & FLAG_READONLY) == FLAG_READONLY;
		}catch(IOException e){
			return false;
		}
		return false;
	}
	try{
		int s = OWNER_WRITE; if (!ownerOnly) s |= OTHER_WRITE|GROUP_WRITE;
		int got = setPermissionsAndFlags(writable ? s : 0, writable ? 0 : s);
		if (writable) return (got & s) == s;
		else return (got & s) == 0;
	}catch(IOException e){
		return false;
	}
}
public boolean setReadOnly()
{
	return setWritable(false,false);
}

private static boolean hasNative = true;
private static native boolean isSymbolicLink(String name);
private static native boolean createSymbolicLink(String name, String target);
private static native int getSetPermissionsAndFlags(String name, boolean isGet, int valuesToSetOrGet, int valuesToClear) throws IOException;
private static native int getSupportedPermissionsAndFlags();
private static native String getLinkTarget(String name);
private static native String getOwnerOrGroup(String name, boolean getGroup);
private static native boolean chown(String name, String user, String group);
}
