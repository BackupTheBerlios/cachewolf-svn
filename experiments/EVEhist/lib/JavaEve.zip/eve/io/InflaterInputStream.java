
package eve.io;

import java.io.FilterInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.StreamCorruptedException;

/**
 * This filter stream is used to decompress data compressed in the "deflate"
 * format. The "deflate" format is described in RFC 1951.
  * <p>
 * This class works exactly the same as java.util.zip.Inflater, however the
 * java.util.zip package is an optional package for the Eve VM. However <b>this</b>
 * version of Inflater and InflaterInputStream will always exist in any Eve VM.
 *<p>
*
 * This stream may form the basis for other decompression filters, such
 * as the <code>GZIPInputStream</code>.
 *
 * @author John Leuner
 * @since 1.1
 */
public class InflaterInputStream extends FilterInputStream
{
  /**
   * Decompressor for this filter 
   */
  protected Inflater inf;

  /**
   * Byte array used as a buffer 
   */
  protected byte[] buf;

  protected int len;
  /*
   * We just use this if we are decoding one byte at a time with the read() call
   */
  private byte[] onebytebuffer = new byte[1];

  /**
   * Create an InflaterInputStream with the default decompresseor
   * and a default buffer size.
   *
   * @param in the InputStream to read bytes from
   */
  public InflaterInputStream(InputStream in) 
  {
    this(in, new Inflater(), 4096);
  }

  /**
   * Create an InflaterInputStream with the specified decompresseor
   * and a default buffer size.
   *
   * @param in the InputStream to read bytes from
   * @param inf the decompressor used to decompress data read from in
   */
  public InflaterInputStream(InputStream in, Inflater inf) 
  {
    this(in, inf, 4096);
  }

  /**
   * Create an InflaterInputStream with the specified decompresseor
   * and a specified buffer size.
   *
   * @param in the InputStream to read bytes from
   * @param inf the decompressor used to decompress data read from in
   * @param size size of the buffer to use
   */
  public InflaterInputStream(InputStream in, Inflater inf, int size) 
  {
    super(in);
    this.inf = inf;
    this.len = 0;
    
    if (size <= 0)
      throw new IllegalArgumentException("size <= 0");
    buf = new byte[size]; //Create the buffer

    if (in == null)
      throw new NullPointerException("InputStream null");
    if (inf == null)
      throw new NullPointerException("Inflater null");
  }

  /**
   * Returns 0 once the end of the stream (EOF) has been reached.
   * Otherwise returns 1.
   */
  public int available() throws IOException
  {
    return inf.finished() ? 0 : 1;
  }

  /**
   * Closes the input stream
   */
  public void close() throws IOException
  {
    in.close();
    //in = null;
  }

  /**
   * Fills the buffer with more data to decompress.
   */
  protected boolean fill() throws IOException
  {
    if (in == null)
      throw new IOException ("InflaterInputStream is closed");
    	len = in.read(buf, 0, buf.length);
    if (len < 0){
      // Can't do this - some zip streams inside a Zip file
      // will not produce an END_OF_STREAM condition from 
      // the ZLIB inflater. So if it says it needs more, but
      // there is no more, then we just have to assume it is ok.
      //
    	return false;
      //throw new ZipException("Deflated stream ends early.");
    }
    
    inf.setInput(buf, 0, len);
    return true;
  }

  /**
   * Reads one byte of decompressed data.
   *
   * The byte is in the lower 8 bits of the int.
   */
  public int read() throws IOException
  { 
    int nread = read(onebytebuffer, 0, 1); //read one byte
    
    if (nread > 0)
      return onebytebuffer[0] & 0xff;
    
    return -1;
  }
  /**
   * Decompresses data into the byte array
   *
   * @param b the array to read and decompress data into
   * @param off the offset indicating where the data should be placed
   * @param len the number of bytes to decompress
   */
  public int read(byte[] b, int off, int len) throws IOException
  {
  //	try{
	    if (len == 0) return 0;
	    
		if (inf.needsDictionary()
			    | inf.finished())
			  return -1;
		
	    for (;;)
	      {
		int count;
		try
		  {
		    count = inf.inflate(b, off, len);
		  } 
		catch (StreamCorruptedException dfe) 
		  {
		    throw new IOException(dfe.getMessage());
		  }
	
		if (count > 0)
		  return count;
		
		if (inf.needsDictionary() | inf.finished())
		  return -1;
		else if (inf.needsInput()){
		  if (!fill()) return -1;
		}else
		  throw new InternalError("Don't know what to do");
	      }
	    /*
  	}catch(IOException e){
  		e.printStackTrace();
  		throw e;
  	}catch(RuntimeException e){
  		e.printStackTrace();
  		throw e;
  	}catch(Error er){
  		er.printStackTrace();
  		throw er;
  	}*/
  }

  /**
   * Skip specified number of bytes of uncompressed data
   *
   * @param n number of bytes to skip
   */
  public long skip(long n) throws IOException
  {
    if (n < 0)
      throw new IllegalArgumentException();
    int len = 2048;
    if (n < len)
      len = (int) n;
    byte[] tmp = new byte[len];
    return (long) read(tmp);
  }

  /**
   * Since this stream tends to buffer large (unpredictable?) amounts
   * of stuff, it causes problems to the mark/reset mechanism.  Hence,
   * it claims not to support mark.
   *
   * @return false
   */
  public boolean markSupported()
  {
    return false;
  }
}
