/*
 * Created on Nov 20, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.io;

import java.io.IOException;
import java.io.OutputStream;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class NullOutputStream extends OutputStream {

	boolean returnError;
	/**
	 * Create a NullOutputStream that will either always throw an IOException
	 * or will always ignore writes.
	 * @param returnError if this is true any attempted write will throw an IOException,
	 * otherwise it will be ignored.
	 */
	public NullOutputStream(boolean returnError) {
		this.returnError = returnError;
	}

	public void write(int ch) throws IOException
	{
		if (returnError) throw new IOException("Cannot write to stream.");
	}
	public void write(byte[] src, int offset, int count) throws IOException
	{
		write(0);
	}
	public void flush() throws IOException
	{
		write(0);
	}
	public void close() throws IOException
	{
		returnError = true;
	}
}

//####################################################
