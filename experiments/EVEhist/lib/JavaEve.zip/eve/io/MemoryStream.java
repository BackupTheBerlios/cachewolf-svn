package eve.io;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import eve.sys.Handle;
import eve.sys.Task;
import eve.sys.TimeOut;
import eve.sys.TimedOutException;
import eve.util.ByteArray;
/**
* A MemoryStream is a Stream that stores all data written to it using standard Stream write() calls,
* in an array of bytes and then allows that data to be read out again, usually 
* through standard Stream read() calls. Essentially a memory pipe.<p>
* You can also use it to provide a standard Streaming interface to a non-Streaming
* data source/sink, by setting it to be read-only/write-only and overriding the
* methods that provide or use the data.
**/
//##################################################################
public class MemoryStream extends InputStream{
//##################################################################
private ByteArray data = new ByteArray();
public int maxBufferSize = -1;

/**
* Set this true to allow for read() calls only. You will then have to place data
* into the Stream directly using putInBuffer().
**/
//protected boolean readOnly = false;
/**
* Set this true to allow for write() calls only. You will then have to read data
* from the Stream directly using getFromBuffer().
**/
//protected boolean writeOnly = false;
/**
* Set this true to allow the getMoreData() method to start and control a background thread
* for retrieving data for reading. If you set this true then you must override the loadAndPutDataBlock()
* method.
**/
//protected boolean useBackgroundThread = false;

private Task provideDataTask;
private boolean dataNeeded;

/**
 * This method should be overriden if you are using a separate thread to provide
 * data, but don't want to use getOutputStream() to write data into the buffer.
 * <p> 
 * This method should basically loop calling waitForDataRequest(). If waitForDataRequest()
 * returns false this indicates that no more input is needed and the method should
 * exit. Otherwise it should gather data and then call write() to put the data
 * in the buffer.
 * <p>
 * When there is no more data to write it can then simply exit and the output
 * portion will be closed.
 * @param h a Handle that can be used to stop the doGenerateData(). If shouldStop
 * is true then the method should exit immediately.
 */
protected void doGenerateData(Handle h)
{
	
}
/**
 * This is used to start the thread that provides data. It will call doGenerateData().
 * When doGenerateData() returns it will call noMoreData() to close the MemoryStream.
 * @return a Handle that can be used to monitor and possibly stop the doGenerateData()
 * method.
 */
protected Handle startGeneratingData()
{
	return new Task(){
		protected void doRun(){
			try{
				doGenerateData(this);
			}finally{
				noMoreData();
			}
		}
	}.start();
}
/**
 * Call this from doGenerateData(). It waits until a read operation has been performed
 * but there is not data in the buffer to read. 
 * @return true if a read request was made, false if no more reading is possible.
 */
protected final boolean waitForDataRequest()
{
	try{
		return waitForDataRequest(TimeOut.Forever);
	}catch(TimedOutException e){
		return true;
	}
}
/**
 * Call this from doGenerateData(). It waits until a read operation has been performed
 * but there is not data in the buffer to read. 
 * @param waitFor a length of time to wait for. If it is null then it will wait forever.
 * @return true if a read request was made, false if no more reading is possible.
 * @exception TimedOutException if the request timed out with no read request being made.
 */
protected final boolean waitForDataRequest(TimeOut waitFor) throws TimedOutException
{
	if (waitFor == null) waitFor = TimeOut.Forever;
	synchronized(data){
		while(true){
			if (streamEnded) return false;
			if (streamError != null) return false;
			if (dataNeeded) return true;
			if (waitFor.hasExpired()) throw new TimedOutException();
			try {waitFor.waitOn(data);}catch(InterruptedException e){}
		}
	}
}
/**
 * Used if you are placing data into the Stream using the direct write() methods. It
 * indicates that no more data will be placed in the stream. 
 *
 */
protected void noMoreData()
{
	synchronized(data){
		streamEnded = true;
		data.notifyAll();
	}
}

/**
 * This will cause an IOException to be thrown on calling one of the read() methods.
 * @param e the IOException to be thrown.
 */
protected void generateInputError(IOException e)
{
	synchronized(data){
		streamError = e;
		data.notifyAll();
	}
}
/**
 * Returns if the close() was called on the MemoryStream. Attempting a write to
 * a closed MemoryStream will generate an IOException. 
 * @return true if the close() was called on the MemoryStream.
 */
protected final boolean inputWasClosed()
{
	return noMoreInput;
}

/**
 * Returns the number of bytes that can be written to the buffer without blocking.
 * -1 will be returned if no maximum buffer size was set and so write() will never
 * block.
 * @return the number of bytes that can be written to the buffer without blocking or
 * -1 if there is no limit.
 */
protected final int canWrite()
{
	synchronized(data){
		if (maxBufferSize <= 0) return -1;
		int canWrite = maxBufferSize-data.length;
		if (canWrite <= 0) return 0;
		return canWrite;
	}	
}
/**
 * Place data into the buffer. If maxBufferSize is greater than zero and this
 * write would cause the buffer to overrun, it will block until all the data can
 * be placed in the buffer without going above the limit.
 * @param source the source of the bytes.
 * @param offset the offset in the source of the data.
 * @param length the number of bytes to write.
 * @throws IOException only if close() has been called on the MemoryStream so
 * that no further reads are possible.
 */
protected final void write(byte[] source, int offset, int length) throws IOException
{
	synchronized(data){
		while(true){
			if (length <= 0) return;
			if (noMoreInput) throw new IOException("Input closed.");
			int canWrite = maxBufferSize > 0 ? maxBufferSize-data.length : length;
			if (canWrite <= 0) {
				try{data.wait();}catch(Exception e){}
				continue;
			}
			if (canWrite > length) canWrite = length;
			data.append(source,offset,canWrite);
			dataNeeded = false;
			data.notifyAll();
			offset += canWrite;
			length -= canWrite;
			continue;
		}
	}
}
protected final void flush() throws IOException
{
	return;
	/* NO! This will block incorrectly.
	synchronized(data){
		while(true){
			int leftToGo = data.length;
			if (leftToGo <= 0) return; 
			if (noMoreInput) throw new IOException("Input closed.");
			if (streamError != null) throw new IOException("An error occured.",streamError);
			try{data.wait();}catch(Exception e){}
		}
	}*/
}

private OutputStream out;
/**
 * Get an OutputStream to write to the MemoryStream for reading back from the
 * InputStream.
 */
public synchronized OutputStream getOutputStream()
{
	if (out == null){
		outBuff = new byte[1];
		out = new OutputStream(){
			public void close() throws IOException {
				noMoreData();
			}
			public void flush() throws IOException {
				MemoryStream.this.flush();
			}
			public void write(int data) throws IOException
			{
				outBuff[0] = (byte)(data & 0xff);
				write(outBuff,0,1);
			}
			public void write(byte[] src, int offset, int length) throws IOException
			{
				MemoryStream.this.write(src,offset,length);
			}
		};
	}
	return out;
}
private boolean streamEnded;
private boolean noMoreInput;
private IOException streamError;
private byte[] inBuff = new byte[1];
private byte[] outBuff;

/**
 * Close the MemoryStream for input.
 */
public void close() throws IOException
{
	synchronized(data){
		noMoreInput = true;
		data.notifyAll();
	}
}

public int read() throws IOException{
	int got = read(inBuff,0,1);
	if (got == -1) return got;
	return (int)inBuff[0] & 0xff;
}

public int read(byte[] dest, int offset, int length) throws IOException{
	boolean requested = false; 
	while(true){
		synchronized(data){
			if (data.length != 0){
				if (length > data.length) length = data.length;
				System.arraycopy(data.data,0,dest,offset,length);
				data.delete(0,length);
				data.notifyAll();
				return length;
			}
			if (streamEnded){
				return -1;
			}
			if (streamError != null) throw streamError;
			if (requested){
				try{
					dataNeeded = true;
					data.notifyAll();
					data.wait();
					continue;
				}catch(InterruptedException e){}
			}
		}
		// Not synchronized with data.
		requested = true;
		readBlocked(length);
	}
}
/**
 * Use of this method is optional - this is called if a read is requested but there is no data available.
 * You can use this to request the generation of data but remember that it
 * may only be called once so whatever is done here must eventually result
 * in the addition of data or the closing of the stream or an stream error
 * being generated. 
 * It is not synchronized so it is safe to block in this method while
 * setting up data.
 * @param waitingFor the number of bytes that is requested.
 */
protected void readBlocked(int waitingFor) throws IOException
{
	
}
/**
 * Get the number of bytes in the buffer.
 * @return the number of bytes in the buffer.
 */
public int bytesInBuffer()
{
	return data.length;
}
/**
 * Get the number of bytes in the buffer.
 * @return the number of bytes in the buffer.
 */
public int available()
{
	return data.length;
}
//===================================================================
public MemoryStream() {this(0);}
//===================================================================
//===================================================================
public MemoryStream(int maxCapacity)
//===================================================================
{
	this.maxBufferSize = maxCapacity;
	data.data = new byte[1024];
}
/**
 * Create a MemoryStream and return an InputStream and an OutputStream for it. Any data
 * written to the OutputStream will be read by the InputStream.
 * @param bufferSize an optional maximum buffer size to use. If it is 0 or less then no
 * maximum is applied.
 * @return an array of two object - the one at index 0 will be an InputStream and the one
 * at index 1 will be the OutputStream.
 */
public static Object[] pipe(int bufferSize)
//===================================================================
{
	MemoryStream ms = new MemoryStream(bufferSize);
	Object[] ret = new Object[2];
	ret[0] = ms.getInputStream();
	ret[1] = ms.getOutputStream();
	return ret;
}
/**
 * Create two pipes and return their Input/Output streams such that inputs[0]
 * and outputs[0] should be used by an entity on one side of the connection
 * and inputs[1] and outputs[1] should be used by an entity on the other side.
 * @param inputs an array of InputStreams of length 2. 
 * It will be setup such
 * that data written to outputs[1] is read on inputs[0] and data written to
 * outputs[0] is read on inputs[1].
 * @param outputs an array of InputStreams of length 2.
 * It will be setup such
 * that data written to outputs[1] is read on inputs[0] and data written to
 * outputs[0] is read on inputs[1].
 * @param bufferSize an optional maximum buffer size to use. If it is 0 or less then no
 * maximum is applied.
 */
public static void pipe2(InputStream[] inputs, OutputStream[] outputs,int bufferSize)
{
	MemoryStream ms = new MemoryStream(bufferSize);
	inputs[0] = ms.getInputStream();
	outputs[1] = ms.getOutputStream();
	ms = new MemoryStream(bufferSize);
	inputs[1] = ms.getInputStream();
	outputs[0] = ms.getOutputStream();
}
/**
 * Return an InputStream to read from the MemoryStream - which in this implementation
 * is itself.
 * @return an InputStream to read from the MemoryStream - which in this implementation
 * is itself.
 */
public InputStream getInputStream()
{
	return this;
}
/**
* Create two Streams that represent either end of a memory based communication stream.
* Data written to one Stream can be read by the other.
**/
/*
//===================================================================
public static Object[] pipe2()
//===================================================================
{
	Object[] ret = new Object[2];
	Object[] p1 = pipe(), p2 = pipe();
	ret[0] = new StreamAdapter((InputStream)p1[0],(OutputStream)p2[1]);
	ret[1] = new StreamAdapter((InputStream)p2[0],(OutputStream)p1[1]);
	return ret;
}
*/
//##################################################################
}
//##################################################################

