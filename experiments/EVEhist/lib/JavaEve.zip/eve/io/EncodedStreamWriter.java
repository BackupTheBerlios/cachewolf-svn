package eve.io;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

import eve.util.ByteArray;
//import gnu.java.io.EncodingManager;
//import gnu.java.io.encode.Encoder;

/**
 * This class writes characters to an output stream that is byte oriented
 * It converts the chars that are written to bytes using an encoding layer,
 * which is specific to a particular encoding standard.  The desired
 * encoding can either be specified by name, or if no encoding is specified,
 * the system default encoding will be used.  The system default encoding
 * name is determined from the system property <code>file.encoding</code>.
 * The only encodings that are guaranteed to be available are "8859_1"
 * (the Latin-1 character set) and "UTF8".  Unfortunately, Java does not
 * provide a mechanism for listing the encodings that are supported in
 * a given implementation.
 * <p>
 * <p>
 * An application can install a named Codec using Io.addCodec() and this class
 * <b>is</b> able to access that codec via the name supplied to addCodec(). The
 * java.io.OutputStreamWriter however will not be able to access these codecs when
 * run under a Java VM. Therefore if you must use a specific Codec then you should
 * use this class instead.
 *
 * @author Aaron M. Renn (arenn@urbanophile.com)
 * @author Per Bothner <bothner@cygnus.com>
 * @date April 17, 1998.  
 */
public class EncodedStreamWriter extends Writer
{

  /**
   * This is the byte-character encoder class that does the writing and
   * translation of characters to bytes before writing to the underlying
   * class.
   */
 // private Encoder out;
	private TextCodec codec = new JavaUtf8Codec();
	private OutputStream out;
	private boolean closed = false;
	private ByteArray outBytes = new ByteArray();
	
	  private EncodedStreamWriter(OutputStream out, boolean makeDefaultCodec)
	  {
	    if (out == null) throw new NullPointerException();
	    this.out = out;
	    if (makeDefaultCodec) try{
	    	codec = Io.getCodec(Io.getDefaultCodecName(),false);
	    }catch(Exception e){
	    	codec = new AsciiCodec();
	    }
	  }

  /**
   * This method initializes a new instance of <code>EncodedStreamWriter</code>
   * to write to the specified stream using a caller supplied character
   * encoding scheme.  Note that due to a deficiency in the Java language
   * design, there is no way to determine which encodings are supported.
   *
   * @param out The <code>OutputStream</code> to write to
   * @param encoding_name The name of the encoding scheme to use for 
   * character to byte translation
   *
   * @exception UnsupportedEncodingException If the named encoding is 
   * not available.
   */
  public EncodedStreamWriter (OutputStream out, String encoding_name) 
    throws UnsupportedEncodingException
  {
    this(out,false);
    if (encoding_name == null) throw new NullPointerException();
  	codec = Io.getCodec(encoding_name,false);
  }

  public EncodedStreamWriter (OutputStream out, TextCodec codec)
  {
  	this(out,false);
  	if (codec == null) throw new NullPointerException();
  	this.codec = codec;
  }
  /**
   * This method initializes a new instance of <code>EncodedStreamWriter</code>
   * to write to the specified stream using the default encoding.
   *
   * @param out The <code>OutputStream</code> to write to
   */
  public EncodedStreamWriter (OutputStream out)
  {
  	this(out,true);
  }

  /**
   * This method closes this stream, and the underlying 
   * <code>OutputStream</code>
   *
   * @exception IOException If an error occurs
   */
//===================================================================
public void close() throws IOException
//===================================================================
{
	if (closed) return;
	try{
		outBytes = codec.encodeText(null,0,0,true,outBytes);
		if (outBytes.length > 0) out.write(outBytes.data,0,outBytes.length);
		outBytes.length = 0;
		flush();
	}finally{
		out.close();
		closed = true;
	}
}

  /**
   * This method returns the name of the character encoding scheme currently
   * in use by this stream.  If the stream has been closed, then this method
   * may return <code>null</code>.
   *
   * @return The encoding scheme name
   */
  public TextCodec getCodec()
  {
  	return codec;
  }

  /**
   * This method flushes any buffered bytes to the underlying output sink.
   *
   * @exception IOException If an error occurs
   */
  public void flush () throws IOException
  {
    out.flush ();
  }

  /**
   * This method writes <code>count</code> characters from the specified
   * array to the output stream starting at position <code>offset</code>
   * into the array.
   *
   * @param buf The array of character to write from
   * @param offset The offset into the array to start writing chars from
   * @param count The number of chars to write.
   *
   * @exception IOException If an error occurs
   */
  public void write (char[] chars, int offset, int length) throws IOException
  {
		if (closed) throw new IOException("Stream closed!");
		if (length < 1) return;
		outBytes = codec.encodeText(chars,offset,length,false,outBytes);
		if (outBytes.length > 0) try{
			out.write(outBytes.data,0,outBytes.length);
		}finally{
			outBytes.length = 0;
		}
	}
  /**
   * This method writes <code>count</code> bytes from the specified 
   * <code>String</code> starting at position <code>offset</code> into the
   * <code>String</code>.
   *
   * @param str The <code>String</code> to write chars from
   * @param offset The position in the <code>String</code> to start 
   * writing chars from
   * @param count The number of chars to write
   *
   * @exception IOException If an error occurs
   */
		/*
  public void write (String str, int offset, int count) throws IOException
  {
    out.write (str, offset, count);
  }
*/
  /**
   * This method writes a single character to the output stream.
   *
   * @param c The char to write, passed as an int.
   *
   * @exception IOException If an error occurs
   */
		/*
  public void write (int ch) throws IOException
  {
    out.write (ch);
  }
*/
} // class EncodedStreamWriter

