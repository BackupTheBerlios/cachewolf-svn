package eve.io;

import java.io.IOException;
import java.io.InputStream;

import eve.util.ByteArray;

/**
 * This is a RandomStream object that uses a ByteArray for storage
 * of data.
**/
//##################################################################
public class ByteArrayRandomStream extends RandomStream{
//##################################################################
/**
 * This is the data being read from or written to. You can
 * access this data at any time.
 */
public ByteArray data = new ByteArray();

private boolean closed;
private int ptr = 0;

public void close() throws IOException
{
	closed = true;
}

//-------------------------------------------------------------------
public int read(byte buf[], int start, int count) throws IOException
//-------------------------------------------------------------------
{
	if (closed || ptr >= data.length) return -1;
	if (ptr+count > data.length) count = data.length-ptr;
	if (count < 0) count = 0;
	if (count != 0) System.arraycopy(data.data,ptr,buf,start,count);
	ptr += count;
	/*
	int cs = 0;
	for (int i = 0; i<count; i++)
		cs += (int)(buf[start+i]) & 0xff;
    System.out.println("BS: "+cs+" @: "+ptr);
    */
	return count;
}
public int read() throws IOException
{
	if (closed || ptr >= data.length) return -1;
	return (int)data.data[ptr++] & 0xff;
}

private void checkClosed(boolean forWriting) throws IOException
{
	if (closed) throw new IOException("Stream closed.");
	else if (forWriting && !isOpenForWriting()) throw new IOException("Cannot write to this stream.");
}
//-------------------------------------------------------------------
public void write(byte buf[], int start, int count) throws IOException
//-------------------------------------------------------------------
{
	checkClosed(true);
	if (count <= 0) return;
	if (ptr+count > data.length) data.makeSpace(ptr,ptr+count-data.length);
	System.arraycopy(buf,start,data.data,ptr,count);
	ptr += count;
}
public void write(int ch) throws IOException
{
	checkClosed(true);
	if (ptr+1 > data.length) data.makeSpace(ptr,ptr+1-data.length);
	data.data[ptr++] = (byte)ch;
}
public long getLength() throws IOException
{
	return data.length;
}

public void setPosition(long pos) throws IOException
{
	checkClosed(false);
	if (pos < 0) throw new IOException("Position out of range: "+pos);
	if (pos > data.length) pos = data.length;
	ptr = (int)pos;
	if ((long)ptr != pos) throw new IOException("Position out of range.");
}

public long getPosition() throws IOException
{
	checkClosed(false);
	return ptr;
}
//===================================================================
public void setLength(long length) throws IOException
//===================================================================
{
	checkClosed(true);
	if (length > data.length) {
		data.makeSpace(data.length,(int)(length-data.length));
	}else if (length < data.length){
		int num = (int)(data.length-length);
		data.delete(data.length-num, num);
		if (ptr > data.length) ptr = data.length;
		//System.out.println("Deleting: "+(data.length-length)+"-"+data.length);
	}
	//System.out.println(getLength());
}

//===================================================================
/**
 * Create a new ByteArrayRandomStream that you can read and write
 * to.  
 */
public ByteArrayRandomStream() 
//===================================================================
{
	super("rw");
}
//===================================================================
public ByteArrayRandomStream(ByteArray dataToUse,String mode)
//===================================================================
{
	super(mode);
	data = dataToUse;
}
/**
 * Create a ByteArray random stream from an array of bytes.
 * A copy of the bytes is made.
 * @param bytes 
 * @param start 
 * @param length 
 * @param mode either "r" or "rw".
 */
//===================================================================
public ByteArrayRandomStream(byte[] bytes,int start,int length,String mode)
//===================================================================
{
	super(mode);
	if (length < 0) length = 0;
	data.data = new byte[length];
	data.length = length;
	if (length != 0) System.arraycopy(bytes,start,data.data,0,length);
}
/**
* This creates a ByteArrayRandomStream from an input File. All bytes from the stream are
* read in and written to the memory file. Alterations to the returned ByteArrayRandomStream
* will not affect the original data source. The original File is closed.
**/
//===================================================================
public ByteArrayRandomStream(InputStream in,String mode) throws IOException
//===================================================================
{
	super(mode);
	StreamUtils.readAllBytes(null,in,data);
}

//##################################################################
}
//##################################################################

