package eve.fx;

import eve.sys.Device;

//##################################################################
public class ImageBuffer{
//##################################################################
public Image image;
public Graphics graphics;

/**
 * This is the maximum image size in pixels (width*height) that should be cached. Anything greater
 * than this and the image and graphics will be freed when placed in the cache.
 */
public static int maxCachedSize = Device.isMobile() ? 320*240 : 640*480;
//==================================================================
public void free()
//==================================================================
{
	if (image != null) image.free();
	if (graphics != null) graphics.free();
	image = null;
	graphics = null;
}
//==================================================================
public boolean isSameSize(int width,int height)
//==================================================================
{
	if (image == null) return false;
	if (width <= 0) width = 1;
	if (height <= 0) height = 1;
	return (image.getWidth() == width && image.getHeight() == height);
}
//===================================================================
public Graphics get(int width,int height)
//===================================================================
{
	return get(width,height,false);
}

//===================================================================
public int imageCreationOptions = 0;
//===================================================================

protected Image newImage(int width, int height, int creationOptions)
{
	return new Image(width,height,creationOptions);
}
protected Image newBuffer(int width, int height, int creationOptions)
{
	return new Buffer(width,height,creationOptions);
}

//==================================================================
public Graphics get(int width,int height,boolean exactly)
//==================================================================
{
	if (width <= 0) width = 1;
	if (height <= 0) height = 1;
	int rw = width, rh = height;
	if (image != null) 
		if (exactly){
			if (image.getWidth() != width || image.getHeight() != height)
				free();
		}else if (image.getWidth() < width || image.getHeight() < height){
			if (rw < image.getWidth()) rw = image.getWidth();
			if (rh < image.getHeight()) rh = image.getHeight();
			free();
		}
	if (image == null) {
		image = newImage(rw,rh,imageCreationOptions);
		graphics = image.newGraphics();
	}
	graphics.reset();
	graphics.setClip(0,0,rw,rh);
	return graphics;
}

//===================================================================
public Graphics getBuffer(int width,int height,Rect area,Color background,boolean exactly)
//===================================================================
{
	if (width <= 0) width = 1;
	if (height <= 0) height = 1;
	if (image != null) 
		if (!(image instanceof Buffer) || image.getWidth() < width || image.getHeight() < height)
			free();
		else if (exactly)
			if (image.getWidth() != width || image.getHeight() != height)
				free();
	if (image == null) image = newBuffer(width,height,imageCreationOptions);
	if (graphics != null) graphics.free();
	if (area != null){
		graphics = ((Buffer)image).clear(area.x,area.y,area.width,area.height,background);
		graphics.setClip(area.x,area.y,area.width,area.height);
	}else{
		graphics = ((Buffer)image).clear(0,0,width,height,background);
		graphics.setClip(0,0,width,height);
	}
	return graphics;
}

public void cached()
{
	if (image != null && (image.getWidth()*image.getHeight() > maxCachedSize)){
		//System.out.println("I must free:"+image.getWidth()+"x"+image.getHeight());
		free();
	}
}
//##################################################################
}
//##################################################################

