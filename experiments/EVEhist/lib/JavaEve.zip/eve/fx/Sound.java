/*
 * Created on Aug 6, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import java.io.IOException;

import eve.sys.Device;
import eve.sys.Handle;
import eve.sys.Reflection;
import eve.sys.Type;
import eve.util.FormattedDataSource;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Sound {

	private Sound(){}
	
	/** Calling beep with this value will have no effect. **/
	public final static int BEEP_NONE = 0;
	
	public final static int BEEP_DEFAULT = 1;
	/** This is a beep that would play if you pressed an inactive control. */
	public final static int BEEP_GUI = 1;
	/** This is a beep that would play if a popup question was displayed. */
	public final static int BEEP_QUESTION = 2;
	/** This is a beep that would play if a popup alert box was displayed. */
	public final static int BEEP_ALERT = 3;
	/** This is a beep that would play if a popup error box was displayed. */
	public final static int BEEP_ERROR = 4;
	/** This is a beep that would play if a popup menu was displayed. */
	public final static int BEEP_POPUP = 5;
	
	public static void beep()
	{
		beep(BEEP_DEFAULT);
	}
	private static int canBeep = -1;
	public static Object popupSound;
	
	private static boolean setup = false;
	
	/**
	 * Call this to force a startup of the Sounds. This is not
	 * done automatically as it takes some time and may
	 * slow down application startup.
	 */
	public static synchronized void setupSounds()
	{
		if (setup) return;
		setup = true;
		try{
			popupSound = makeSoundClip(new FormattedDataSource().set("eve/popup.wav").readIntoMemory());
		}catch(IOException e){
			popupSound = null;
		}
	}
	/**
	 * Play a beep.
	 * @param beepType one of the BEEP_XXX values.
	 */
	public static void beep(int beepType)
	{
		if (beepType == BEEP_NONE) return;
		setupSounds();
		if (canBeep == -1){
			canBeep = (Device.getGUICapabilities() & Device.GUI_CAN_BEEP) != 0 ? 1 : 0;
		}
		if (true){
			int bv = Device.MB_OPTION_ICONEXCLAMATION;
			switch(beepType){
			case BEEP_ALERT : bv = Device.MB_OPTION_ICONEXCLAMATION ; break; 
			case BEEP_ERROR : bv = Device.MB_OPTION_ICONERROR ; break; 
			case BEEP_QUESTION : bv = Device.MB_OPTION_ICONQUESTION ; break; 
			case BEEP_GUI : bv = 0 ; break; 
			case BEEP_POPUP : 
				{
					if (popupSound != null) {
						playSoundClip(popupSound);
					}
					return;
					//bv = Device.MB_ICONASTERISK ; break;
				}
			}
			if (canBeep == 1) Device.messageBeep(bv);
		}else{
			//TODO - play via SoundClip
		}
	}
	private static Type scType;
	/**
	 * A simple way to make a sound clip if it is supported by the VM.
	 * @param source the name of the sound.
	 * @return an Object that you can use with playSoundClip() to play the
	 * sound, or null if the sound clip could not be made for any reason.
	 */
	public synchronized static Object makeSoundClip(String source)
	{
		try{
			return makeSoundClip(new FormattedDataSource().set(source));
		}catch(IOException e){
			return null;
		}
	}
	/**
	 * A simple way to make a sound clip if it is supported by the VM.
	 * @param source the source of the sound.
	 * @return an Object that you can use with playSoundClip() to play the
	 * sound, or null if the sound clip could not be made for any reason.
	 */
	public synchronized static Object makeSoundClip(FormattedDataSource source)
	{
		if (scType == null) scType = new Type("eve.fx.sound.SoundClip");
		if (!scType.exists()) return null;
		Object obj = scType.newInstance("(Leve/util/FormattedDataSource;)",new Object[]{source});
		if (obj != null){
			scType.invoke(obj,"readIntoMemory()V",null);
			scType.invoke(obj,"reserveSharedOutput()V",null);
		}
		return obj;
	}
	/**
	 * Play a sound clip returned by makeSoundClip().
	 * @param clip the clip as returned from makeSoundClip() to play.
	 * @return true if the clip played, false if not.
	 */
	public static Handle playSoundClip(Object clip)
	{
		Object obj = null;
		if (scType != null && clip != null) {
			obj = scType.invoke(clip,"play()Leve/sys/Handle;",Reflection.emptyParameters);
		}
		if (obj instanceof Handle) return (Handle)obj;
		Handle h = new Handle();
		h.fail(new IOException("Sound clip could not be played."));
		return h;
	}
}
