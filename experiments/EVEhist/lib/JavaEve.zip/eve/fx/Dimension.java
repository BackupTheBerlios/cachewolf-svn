package eve.fx;

import eve.sys.Cache;
import eve.util.Encodable;

//##################################################################
public class Dimension implements Encodable{
//##################################################################
public int width, height; // Do not move these two!
public Dimension(){this(0,0);}
public Dimension(int w,int h) {width = w; height = h;}
public String toString() {return "("+width+","+height+")";}
//===================================================================
public Dimension set(int w,int h) {width = w; height = h; return this;}
public Dimension set(Dimension r) {width = r.width; height = r.height; return this;}
public Dimension set(Rect r) {width = r.width; height = r.height; return this;}
public static Dimension unNull(Dimension r) {return r == null ? new Dimension():r;}
//===================================================================
//{new Exception().printStackTrace();}
//public static Dimension buff = new Dimension();
public boolean equals(Object other)
{
	if (!(other instanceof Dimension)) return super.equals(other);
	Dimension r = (Dimension)other;
	return (r.width == width && r.height == height);
}
public static Dimension getCached(int width, int height) 
{
	return ((Dimension)Cache.get(Dimension.class)).set(width,height);
}
public Dimension cache()
{
	Cache.put(this);
	return null;
}
//##################################################################
}
//##################################################################

