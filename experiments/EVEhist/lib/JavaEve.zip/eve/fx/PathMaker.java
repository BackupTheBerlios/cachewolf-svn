package eve.fx;

/**
 * This class is used to add extra geometry functionality on top of an IPath
 * Object. For example drawing ellipses, arcs and pie sections.
 */
public class PathMaker {

	/**
	 * The IPath being drawn to.
	 */
	protected IPath path;
	protected boolean started = false;
	protected boolean closed = false;
	protected double lastX, lastY;
	public boolean hasStarted()
	{
		return started;
	}
	public boolean hasClosed()
	{
		return closed;
	}
	/**
	 * Create a new PathMaker for the IPath.
	 * @param path the IPath object.
	 */
	public PathMaker(IPath path)
	{
		this.path = path;
	}
	/**
	 * When an elliptical arc is being drawn it is split up into smaller
	 * segments so as to fit as close as possible using a Bezier curve.
	 * This value is the angle (in degrees) that is used as the maximum angle for
	 * each segment. The default value is 90 and this should be the
	 * maximum size. For greater accuracy a smaller size can be used.
	 */
	public float arcSegmentAngle = 90;
	/**
	 * For each elliptical arc segment drawn the Bezier control points are at a
	 * tangent to the start and end points. 
	 * The length of these tangent control points the same for both
	 * the start and end points. The actual length is then scaled by
	 * a value to get a Bezier fit. The default value is: 0.5522847
	 * which gives a fairly accurate fit at 90 degrees or lower, but you
	 * can change this value if you need to.  
	 */
	public double arcControlValue = 0.55228475; 
		
	private double[] arc = new double[8];
	
	private void ellipseTangent(double hr, double vr, float angle, float arcSize, double[] dest, boolean startPoint)
	{
		double rad = (Math.PI*angle)/180;
		double x = Math.cos(rad)*hr;
		double y = Math.sin(rad)*vr;
		double w = -(hr*y)/vr;
		double h = (vr*x)/hr;
		if ((startPoint && arcSize <= 0) ||(!startPoint && arcSize > 0)){
			w = -w;
			h = -h;
		}
		double s = arcSize;
		if (s < 0) s = -s;
		double newSize = arcControlValue*(s/90)*Math.sqrt((h*h)+(w*w));
		double theta = Math.atan2(h, w);
		w = newSize*Math.cos(theta);
		h = newSize*Math.sin(theta);
		if (startPoint){
			dest[0] = x; dest[1] = y; dest[2] = w; dest[3] = h;
		}else{
			dest[6] = x; dest[7] = y; dest[4] = w; dest[5] = h;
		}
	}
	
	private synchronized void arcSection(double x, double y, double hr, double vr, float start, float size)
	{
		start = -start;
		size = -size;
		ellipseTangent(hr, vr, start, size, arc, true);
		ellipseTangent(hr, vr, start+size, size, arc, false);
		arc[0] += x+hr; arc[6] += x+hr;
		arc[1] += y+vr; arc[7] += y+vr;
		arc[2] += arc[0]; arc[3] += arc[1];
		arc[4] += arc[6]; arc[5] += arc[7];
	}
	/**
	 * Draw an arc of an ellipse that fits within the specified bounding
	 * box.
	 * The ellipse fits into the bounding box given by x, y, width, height.
	 * @param startOptions one of the START_XXX values.
	 * @param x the x co-ordinate of the ellipse bounding box.
	 * @param y the y co-ordinate of the ellipse bounding box.
	 * @param width the width of the ellipse bounding box.
	 * @param height the height of the ellipse bounding box.
	 * @param startAngle the starting point of the arc given in degrees
	 * where 0 is the 3 O'clock position and a positive value indicates
	 * an anti-clockwise direction. Therefore 90 is the 12 O'clock and
	 * -90 (or 270) is the 6 O'clock. 
	 * @param angle the size of the arc in degrees. A positive value indicates
	 * an anti-clockwise direction.
	 */
	public void arc(int startOptions, double x, double y, double width, double height, float startAngle, float angle)
	{
		synchronized(this){
			int arcDir = angle < 0 ? -1 : 1;
			if (arcDir < 0) angle = -angle;
			double s = startAngle;
			boolean first = true;
			while(true){
				float left = angle;
				if (left <= 0) break;
				if (left > arcSegmentAngle) left = arcSegmentAngle;
				angle -= left;
				left *= arcDir;
				arcSection(x,y,width/2,height/2,startAngle,left);
				if (first) doStart(startOptions,arc[0],arc[1]);
				first = false;
				path.addToPath(arc[2],arc[3],arc[4], arc[5], arc[6], arc[7]);
				started = true;
				lastX = arc[6];
				lastY = arc[7];
				startAngle += left;
			}
		}
	}
/*
	public static final int QUADRANT_TOPRIGHT = 0;
	public static final int QUADRANT_TOPLEFT = 1;
	public static final int QUADRANT_BOTTOMLEFT = 2;
	public static final int QUADRANT_BOTTOMRIGHT = 3;
	*/
	/**
	 * A possible startOptions value.
	 * This indicates that a startPath() operation should be done for
	 * the first point in the curve being drawn.
	 */
	public static final int START_NEW_PATH = 0;
	/**
	 * A possible startOptions value.
	 * This indicates that a line should be drawn to the first point of the curve
	 * being drawn using addToPath(x,y). 
	 */
	public static final int START_LINE_TO = 1;
	/**
	 * A possible startOptions value.
	 * This indicates that the a move to the first point has already been done.
	 */
	public static final int START_ALREADY_STARTED = 2;
	
	private void doStart(int startOptions,double x, double y)
	{
		int st = startOptions & 0x3;
		if (st == START_NEW_PATH) path.startPath(x,y);
		else if (st == START_LINE_TO) path.addToPath(x, y);
	}
	/* Can't fit on the Eve VM.
	private void quadPoints(int startOptions,double x0, double y0,double x1,double y1,double x2,double y2,double x3, double y3)
	{
		int st = startOptions & 0x3;
		if (st == START_NEW_PATH) path.startPath(x0,y0);
		else if (st == START_LINE_TO) path.addToPath(x0, y0);
		path.addToPath(x1, y1, x2, y2, x3, y3);
	}
	*/
	/**
	 * Draw a full ellipse quadrant. 
	 * The ellipse fits into the bounding box given by x, y, width, height.
	 * @param startOptions one of the START_XXX values.
	 * @param x the x co-ordinate of the ellipse bounding box.
	 * @param y the y co-ordinate of the ellipse bounding box.
	 * @param width the width of the ellipse bounding box.
	 * @param height the height of the ellipse bounding box.
	 * @param which the quadrant to draw. This should be one of the QUADRANT_XXX
	 * @param clockwise if true the quadrant is drawn in a clockwise direction.
	 * values.
	 */
	/*
	public void quadrant(int startOptions, double x, double y, double width, double height, int which, boolean clockwise)
	{
		double hr = width/2;
		double vr = height/2;
		double m = 0.55228475;
		double hrm = hr*m;
		double vrm = vr*m;
		if (clockwise){
			switch(which){
				case QUADRANT_TOPRIGHT:
					doStart(startOptions,x+hr,y);path.addToPath(x+hr+hrm,y, x+width,y+vr-vrm, x+width,y+vr); break;
				case QUADRANT_BOTTOMRIGHT:
					doStart(startOptions,x+width,y+vr);path.addToPath( x+width,y+vr+vrm, x+hr+hrm,y+height, x+hr,y+height); break;
				case QUADRANT_BOTTOMLEFT:
					doStart(startOptions, x+hr,y+height);path.addToPath( x+hr-hrm,y+height, x,y+vr+vrm, x,y+vr); break;
				case QUADRANT_TOPLEFT:
					doStart(startOptions, x,y+vr);path.addToPath( x,y+vr-vrm, x+hr-hrm,y, x+hr,y); break;
			}
		}else{
			switch(which){
				case QUADRANT_TOPRIGHT:
					doStart(startOptions,x+width,y+vr);path.addToPath(x+width,y+vr-vrm, x+hr+hrm,y, x+hr,y); break;
				case QUADRANT_TOPLEFT:
					doStart(startOptions, x+hr,y);path.addToPath(x+hr-hrm,y,  x,y+vr-vrm, x,y+vr); break;
				case QUADRANT_BOTTOMLEFT:
					doStart(startOptions,x,y+vr);path.addToPath( x,y+vr+vrm, x+hr-hrm,y+height, x+hr,y+height); break;
				case QUADRANT_BOTTOMRIGHT:
					doStart(startOptions, x+hr,y+height);path.addToPath( x+hr+hrm,y+height, x+width,y+vr+vrm, x+width,y+vr); break;
			}			
		}
	}
	*/
	/**
	 * Create a closed ellipse as a new path.
	 * The ellipse fits into the bounding box given by x, y, width, height.
	 * @param startOptions one of the START_XXX values.
	 * @param x the x co-ordinate of the ellipse bounding box.
	 * @param y the y co-ordinate of the ellipse bounding box.
	 * @param width the width of the ellipse bounding box.
	 * @param height the height of the ellipse bounding box.
	 */
	public void ellipse(double x, double y, double width, double height)
	{
		started = true;
		arc(0, x, y, width, height, 0, 360);
		closePath();
	}
	/**
	 * Create a rounded rectangle as a new path.
	 * The rectangle fits into the bounding box given by x, y, width, height.
	 * @param startOptions one of the START_XXX values.
	 * @param x the x co-ordinate of the ellipse bounding box.
	 * @param y the y co-ordinate of the ellipse bounding box.
	 * @param width the width of the ellipse bounding box.
	 * @param height the height of the ellipse bounding box.
	 * @param radius the radius of the circles drawn on the corners.
	 */
	public void roundRect(double x, double y, double width, double height, double radius)
	{
		started = true;
		double d = radius*2;
		double r = radius;
		path.startPath(x+r, y);
		path.addToPath(x+width-r, y);
		arc(START_ALREADY_STARTED,x+width-d,y,d,d,90,-90);
		path.addToPath(x+width, y+height-r);
		arc(START_ALREADY_STARTED,x+width-d,y+height-d,d,d,0,-90);
		path.addToPath(x+r, y+height);
		arc(START_ALREADY_STARTED,x,y+height-d,d,d,-90,-90);
		path.addToPath(x, y+r);
		arc(START_ALREADY_STARTED,x,y,d,d,-180,-90);
		closePath();
	}
	/**
	 * Draw a closed pie section of an ellipse as a new closed path.
	 * The ellipse fits into the bounding box given by x, y, width, height.
	 * @param x the x co-ordinate of the ellipse bounding box.
	 * @param y the y co-ordinate of the ellipse bounding box.
	 * @param width the width of the ellipse bounding box.
	 * @param height the height of the ellipse bounding box.
	 * @param startAngle the starting point of the arc given in degrees
	 * where 0 is the 3 O'clock position and a positive value indicates
	 * an anti-clockwise direction. Therefore 90 is the 12 O'clock and
	 * -90 (or 270) is the 6 O'clock. 
	 * @param angle the size of the arc in degrees. A positive value indicates
	 * an anti-clockwise direction.
	 */
	public void pie(double x, double y, double width, double height, float startAngle, float angle)
	{
		started = true;
		arc(0,x,y,width,height,startAngle,angle);
		path.addToPath(x+width/2, y+height/2);
		closePath();
	}
	/**
	 * Draw a closed arc section of an ellipse as a new closed path.
	 * The ellipse fits into the bounding box given by x, y, width, height.
	 * @param x the x co-ordinate of the ellipse bounding box.
	 * @param y the y co-ordinate of the ellipse bounding box.
	 * @param width the width of the ellipse bounding box.
	 * @param height the height of the ellipse bounding box.
	 * @param startAngle the starting point of the arc given in degrees
	 * where 0 is the 3 O'clock position and a positive value indicates
	 * an anti-clockwise direction. Therefore 90 is the 12 O'clock and
	 * -90 (or 270) is the 6 O'clock. 
	 * @param angle the size of the arc in degrees. A positive value indicates
	 * an anti-clockwise direction.
	 */
	public void closedArc(double x, double y, double width, double height, float startAngle, float angle)
	{
		started = true;
		arc(0,x,y,width,height,startAngle,angle);
		closePath();
	}
	/**
	 * Close the destination path.
	 */
	public void closePath()
	{
		path.closePath();
		closed = true;
	}
	public void startPath(double x, double y)
	{
		started = true;
		path.startPath(x, y);
		lastX = x; lastY = y;
	}
	/**
	 * Add a straight line segment to the path.
	 */
	public void addToPath(double x, double y)
	{
		started = true;
		path.addToPath(x, y);
		lastX = x; lastY = y;
	}
	/**
	 * Add a Cubic Bezier curve segment from the current point to (x3,y3) using
	 * (x1, y1) and (x2, y2) as the control points.
	 */
	public void addToPath(double x1, double y1, double x2, double y2, double x3, double y3)
	{
		started = true;
		path.addToPath(x1, y1, x2, y2, x3, y3);
		lastX = x3; lastY = y3;
	}
	/**
	 * Add a Cubic Bezier curve segment (or segments) that approximates a Quadratic
	 * segment.
	 * @param x1 the quadratic control point x co-ordinate.
	 * @param y1 the quadratic control point y co-ordinate.
	 * @param x2 the end point x co-ordinate.
	 * @param y2 the end point y co-ordinate.
	 */
	public void addQuadToPath(double x1, double y1, double x2, double y2)
	{
		double s = 1.2;
		//double dd = Math.sqrt((lastX-x2)*(lastX-x2)+(lastY-y2)*(lastY*y2));
		{
			double w = x1-lastX, h = y1-lastY;
			double newSize = arcControlValue*s*Math.sqrt((h*h)+(w*w));
			double theta = Math.atan2(h, w);
			w = newSize*Math.cos(theta);
			h = newSize*Math.sin(theta);
			arc[2] = lastX+w; arc[3] = lastY+h;
		}		
		{
			double w = x1-x2, h = y1-y2;
			double newSize = arcControlValue*s*Math.sqrt((h*h)+(w*w));
			double theta = Math.atan2(h, w);
			w = newSize*Math.cos(theta);
			h = newSize*Math.sin(theta);
			arc[4] = x2+w; arc[5] = y2+h;
		}		
		addToPath(arc[2], arc[3], arc[4], arc[5], x2, y2);
		lastX = x2; lastY = y2;
	}
}
