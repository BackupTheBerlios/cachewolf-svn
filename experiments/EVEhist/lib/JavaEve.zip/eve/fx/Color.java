package eve.fx;

import eve.sys.Cache;

/**
 * Color represents a color.
 * <p>
 * A color is defined as a mixture of red, green and blue color values.
 * Each value is in the range of 0 to 255 where 0 is darkest and 255 is brightest.
 * For example, Color(255, 0, 0) is the color red.
 * <p>
 * Here are some more examples:
 * <ul>
 * <li>Color(0, 0, 0) is black
 * <li>Color(255, 255, 255) is white
 * <li>Color(255, 0, 0 ) is red
 * <li>Color(0, 255, 0) is green
 * <li>Color(0, 0, 255) is blue
 * </ul>
 */

public class Color
{
//Do not move these 4
int red;
int green;
int blue;
int alpha = 0xff;
//
boolean nullColor;

//===================================================================
public void setNull(boolean set)
//===================================================================
{
	nullColor = set;
}
//===================================================================
public boolean isNull()
//===================================================================
{
	return nullColor;
}
//===================================================================
public static boolean isNull(Color c)
//===================================================================
{
	return c == null || c.isNull();
}
public Color()
{
}
/**
 * Constructs a color object with the given red, green and blue values.
 * @param red the red value in the range of 0 to 255
 * @param green the green value in the range of 0 to 255
 * @param blue the blue value in the range of 0 to 255
 */
public Color(int red, int green, int blue){this(red,green,blue,0xff);}
public Color(int red, int green, int blue, int alpha)
	{
	this.red = red;
	this.green = green;
	this.blue = blue;
	this.alpha = alpha;
	}
/** Returns the blue value of the color. */
public int getBlue()
	{
	return blue;
	}

/** Returns the green value of the color. */
public int getGreen()
	{
	return green;
	}

/** Returns the red value of the color. */
public int getRed()
	{
	return red;
	}
public int getAlpha() {return alpha;}
//==================================================================
// MLB
//==================================================================
public static final Color Null = new Color(0,0,0);
static{
	Null.setNull(true);
}
public static Color 
	Black = new Color(0,0,0),
	White = new Color(0xff,0xff,0xff),
	DarkGray = new Color(96,96,96),
	LightGray = new Color(192,192,192),
	LighterGray = new Color(220,220,220),
	DarkBlue = new Color(0,0,128),
	Sand = new Color(217,217,195),
	LightBlue = new Color(220,220,255),
	LighterBlue = new Color(240,240,255),
	MediumBlue = new Color(128,214,255),
	LightGreen = new Color(220,255,220), 
	Pink = new Color(255,220,220),
	Red = new Color(255,0,0);
	
private static boolean isMono = false;
public static void setMonochrome(boolean mono)
{
	isMono = mono;
	if (mono) {
		DarkGray.set(Black);
		LightGray.set(White);
		LighterGray.set(White);
		DarkBlue.set(Black);
	}else{
		DarkGray.set(new Color(96,96,96));
		LightGray.set(new Color(192,192,192));
		LighterGray.set(new Color(220,220,220));
		DarkBlue.set(new Color(0,0,128));
	}
}
public static boolean getMonochrome()
{
	return isMono;
}
public void set(int r,int g,int b){set(r,g,b,0xff);}
public void set(int r,int g,int b,int a)
{
	setNull(false);
	red = r; green = g; blue = b; alpha = a; 
}
//===================================================================
public void set(Color other)
//===================================================================
{
	if (other != null) set(other.red,other.green,other.blue,other.alpha);
	if (other == null || other.nullColor) nullColor = true;
}
public String toString()
{
	return red+", "+green+", "+blue;
}
public boolean equals(Object other)
{
	if (!(other instanceof Color)) return super.equals(other);
	if (other == this) return true;
	Color c = (Color)other;
	return (c.red == red && c.blue == blue && c.green == green && c.alpha == alpha);
}
//===================================================================
public int toInt()
//===================================================================
{
	return alpha << 24 | red << 16 | green << 8 | blue;
}
//===================================================================
public void fromInt(int value)
//===================================================================
{
	set((value >> 16)&0xff,(value >> 8)&0xff,(value >> 0)&0xff,(value >> 24)&0xff);
}
//===================================================================
public Color toOpaque()
//===================================================================
{
	if (alpha == 0xff) return this;
	else return new Color(red,green,blue,0xff);
}
//===================================================================
public Color getCopy()
//===================================================================
{
	Color c = new Color(red,green,blue,alpha);
	c.nullColor = nullColor;
	return c;
}

public static Color getCached(int r, int g, int b)
{
	Color c = (Color)Cache.get(Color.class);
	c.set(r,g,b);
	return c;
}
public static Color getCached(Color other)
{
	Color c = (Color)Cache.get(Color.class);
	c.set(other);
	return c;
	
}
public static Color getCached()
{
	return (Color)Cache.get(Color.class);
}
public void cache()
{
	Cache.put(this);
}
}
