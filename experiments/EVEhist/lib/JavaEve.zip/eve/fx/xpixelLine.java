package eve.fx;

//##################################################################
class xpixelLine {
//##################################################################
	int line;
	int [] pixels;
	int pixelsStart;
	int x;
	int destFreq;
	int srcFreq;
	int numPixels;
	boolean set(Rect srcArea, int trueLine, int []pixels, int pixStart, int xOffset,int destFreq, int numPixels, int srcFreq)
	{
		if (srcFreq < 1) srcFreq = 1;
		if (destFreq < 1) destFreq = 1;
		//
		int sx = srcArea.x, sy = srcArea.y, sw = srcArea.width, sh = srcArea.height;
		//
		// First, is the line in range.
		//
		if (trueLine < sy || trueLine >= sy+sh) return false;
		this.line = trueLine-sy;
		//
		// Next trim the line to fit into the x range.
		//
		// First make sure the left is correct. 
		//
		if (xOffset < sx){
			int skip = ((sx-xOffset)+(destFreq-1))/destFreq;
			if (skip >= numPixels) return false;
			numPixels -= skip;
			xOffset += destFreq*skip;
			pixStart += srcFreq*skip;
		}
		//
		// Next make sure the last pixel is in range.
		//
		{
			int canFit = (((sx+sw)-xOffset)+(destFreq-1))/destFreq;
			if (canFit <= 0) return false;
			if (numPixels > canFit) numPixels = canFit;
		}
		this.pixels = pixels;
		this.pixelsStart = pixStart;
		this.numPixels = numPixels;
		this.x = xOffset-sx;
		this.srcFreq = srcFreq;
		this.destFreq = destFreq;
		return true;
		
	}
	boolean setPixelLine(ImageMaker dest, Rect srcArea, int line, int[] pixels, int pixStart, int xOffset, int destFreq, int numPixels, int srcFreq)
	{
		if (!set(srcArea,line,pixels,pixStart,xOffset,destFreq,numPixels,srcFreq))
			return false;
		return dest.setScanLinePixels(this.line, this.pixels, this.pixelsStart, this.x, this.destFreq, this.numPixels, this.srcFreq);
	}
	//
	//bool setInFullMemory(int *fullPixels, int rowStride);
	//bool setInImageData(class timage_data &data);
//##################################################################
};
//##################################################################
