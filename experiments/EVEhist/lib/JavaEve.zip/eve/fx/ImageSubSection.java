/*
 * Created on Jan 10, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.ImageData;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class ImageSubSection extends ImageObject{

private int x, y;
private ImageData source;
private boolean haveAlpha;


	public void setFor(ImageData source, int x, int y, int width, int height)
	{
		if (source == null) throw new NullPointerException();
		try{
		if (x < 0 || x+width > source.getImageWidth()) 
			throw new IllegalArgumentException((x+width)+" > "+source.getImageWidth());
		if (y < 0 || y+height > source.getImageHeight())
			throw new IllegalArgumentException((y+height)+" > "+source.getImageHeight());
		if (width <= 0 || height <= 0) throw new IllegalArgumentException();
		}catch(IllegalArgumentException e){
			//System.out.println(new Rect().set(x,y,width,height)+", "+new Dimension().set(source.getImageWidth(), source.getImageHeight()));
			throw e;
		}
		this.x = x;
		this.y = y;
		this.height = height;
		this.width = width;
		this.source = source;
		haveAlpha = source.getImageType() == TYPE_ARGB;
	}
	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength) throws IllegalStateException {
		getPixels((int[])destArray,offset,0,startLine,width,numLines,destScanLineLength);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength) throws IllegalStateException {
		getPixels((int[])sourceArray,offset,0,startLine,width,numLines,sourceScanLineLength);
	}
	/* (non-Javadoc)
	 * @see eve.sys.ImageData#isWriteableImage()
	 */
	public boolean isWriteableImage() {
		return source == null ? false : source.isWriteableImage();
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#isReadableImage()
	 */
	public boolean isReadableImage() {
		return source == null ? false : source.isReadableImage();
	}
	/* (non-Javadoc)
	 * @see eve.sys.ImageData#freeImage()
	 */
	public void freeImage() {
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getPixels(int[], int, int, int, int, int, int)
	 */
	public int[] getPixels(int[] dest, int offset, int x, int y, int width, int height, int rowStride) {
		return source.getPixels(dest,offset,x+this.x,y+this.y,width,height,rowStride);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setPixels(int[], int, int, int, int, int, int)
	 */
	public boolean setPixels(int[] src, int offset, int x, int y, int width, int height, int rowStride) {
		return source.setPixels(src,offset,x+this.x,y+this.y,width,height,rowStride);
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#draw(eve.fx.Graphics, int, int, int)
	 */
	public void draw(Graphics g, int x, int y, int options) {
		
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#usesAlpha()
	 */
	public boolean usesAlpha() {
		return haveAlpha;
	}

}
//####################################################
