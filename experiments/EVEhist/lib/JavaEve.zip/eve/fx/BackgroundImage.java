/*
 * Created on Feb 13, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.ImageData;

/**
 * This specifies parameters for a "background" image.
 */
//####################################################
public class BackgroundImage {

	/** An exclusive value for displayType. */
	public static final int DISPLAY_TYPE_SCALED = 0x1;
	/** An exclusive value for displayType - this one keeps a copy of the scaled image. */
	public static final int DISPLAY_TYPE_CACHED_SCALED = 0x4;
	/** An exclusive value for displayType. */
	public static final int DISPLAY_TYPE_TILED = 0x2;
	/** An exclusive value for displayType. */
	public static final int DISPLAY_TYPE_SINGLE = 0x3;
	
	public ImageData originalImage;
	public ImageData imageToDraw;
	/**
	 * This should be one of the DISPLAY_TYPE_XXX values.
	 */
	public int displayType = DISPLAY_TYPE_CACHED_SCALED;
	/**
	 * This is only used if the type is DISPLAY_TYPE_SINGLE. It determines
	 * where the image should be placed.
	 */
	public int anchor = 0;
	/**
	 * This is only used if the type is DISPLAY_TYPE_SCALED. It determines
	 * what scale options should be used.
	 */
	public int scaleOptions = 0;
	
	private Rect src, dest, old;
	
	/**
	 * Create a BackgroundImage.
	 * @param im the Image to display.
	 * @param displayType one of the DISPLAY_TYPE_XXX values.
	 * @param anchorOrScaleOptions the anchor for DISPLAY_TYPE_SINGLE
	 * or the scale options for DISPLAY_TYPE_SCALED.
	 */
	public BackgroundImage(ImageData im, int displayType, int anchorOrScaleOptions)
	{
		originalImage = imageToDraw = im;
		this.displayType = displayType;
		if (displayType == DISPLAY_TYPE_SCALED || displayType == DISPLAY_TYPE_CACHED_SCALED) scaleOptions = anchorOrScaleOptions;
		else anchor = anchorOrScaleOptions;
	}
	/**
	 * When using DISPLAY_TYPE_CACHED_SCALE this pre-scales the image. This is
	 * optional as a call to display() will automatically scale the image and
	 * keep a cache of the scaled version.
	 * @param width the new width.
	 * @param height the new height.
	 * @param scaleOnTopOf an optional Color to scale on top of.
	 */
	public void scaleImageTo(int width, int height, Color scaleOnTopOf)
	{
		if (scaleOnTopOf == null)
			scaleImageTo(width,height,(Image)null);
		Image im = new Image(width,height);
		Graphics g = new Graphics(im);
		g.setColor(scaleOnTopOf);
		g.fillRect(0,0,width,height);
		g.free();
		scaleImageTo(width,height,im);
		im.free();
	}
	/**
	 * When using DISPLAY_TYPE_CACHED_SCALE this pre-scales the image. This is
	 * optional as a call to display() will automatically scale the image and
	 * keep a cache of the scaled version.
	 * @param width the new width.
	 * @param height the new height.
	 * @param scaleOnTopOf an optional Image to scale on top of (which should
	 * have the dimensions the same as width and height). You can free() that
	 * image as a picture of the final image is used.
	 */
	public void scaleImageTo(int width, int height, Image scaleOnTopOf)
	{
		Graphics g = null;
		if (scaleOnTopOf == null || scaleOnTopOf.getWidth() != width || scaleOnTopOf.getHeight() != height){
			scaleOnTopOf = new Image(width,height);
			g = new Graphics(scaleOnTopOf);
			g.setColor(Color.White);
			g.fillRect(0,0,width,height);
		}
		if (g == null) g = new Graphics(scaleOnTopOf);
		g.drawImageData(originalImage,new Rect(0,0,originalImage.getImageWidth(),originalImage.getImageHeight()),new Rect(0,0,width,height),scaleOptions);
		g.free();
		imageToDraw = scaleOnTopOf.toPicture();
	}
	/**
	 * Display the BackgroundImage in the Graphics within the specified location.
	 * @param g
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 */
	public synchronized void display(Graphics g, int x, int y, int width, int height)
	{
		if (width <= 0 || height <= 0) return;
		if (imageToDraw == null) return;
		if (src == null){
			src = new Rect();
			dest = new Rect();
			old = new Rect();
		}
		src.set(0,0,imageToDraw.getImageWidth(),imageToDraw.getImageHeight());
		if (src.width == 0 || src.height == 0) return;
		Rect c = g.reduceClip(x,y,width,height,old);
		try{
			if (displayType == DISPLAY_TYPE_SCALED){
				g.drawImageData(imageToDraw, src, dest.set(x,y,width,height), scaleOptions);
			}else if (displayType == DISPLAY_TYPE_CACHED_SCALED){
				if (src.width != width && src.height != height){
					scaleImageTo(width,height,(Image)null);
				}
				g.draw(imageToDraw,x,y);
			}else if (displayType == DISPLAY_TYPE_TILED){
				int nr = (height+src.height-1)/src.height;
				int nc = (width+src.width-1)/src.width;
				for (int yy = 0; yy < nr; yy++){
					for (int xx = 0; xx < nc; xx++)
						g.draw(imageToDraw,x+xx*src.width,y+yy*src.height);
				}
			}else{
				Metrics.anchor(src,dest.set(x,y,width,height),anchor);
				g.draw(imageToDraw,src.x,src.y);
			}
		}finally{
			g.restoreClip(c);
		}
	}
}
//####################################################
