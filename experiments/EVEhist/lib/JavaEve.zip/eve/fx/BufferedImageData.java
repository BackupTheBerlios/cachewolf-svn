/*
 * Created on Dec 8, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import java.awt.image.BufferedImage;

import eve.fx.ImageObject;
import eve.sys.ImageData;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class BufferedImageData extends ImageObject {
	public BufferedImage bi;
	
	public BufferedImageData(BufferedImage bi)
	{
		this.bi = bi;
		this.width = bi.getWidth();
		this.height = bi.getHeight();
	}
	static BufferedImage createBI(int width,int height,boolean alpha)
	{
		return new java.awt.image.BufferedImage(width,height,
				alpha
				? java.awt.image.BufferedImage.TYPE_INT_ARGB : java.awt.image.BufferedImage.TYPE_INT_RGB);
	}
	
	public BufferedImageData(ImageData from)
	{
		width = from.getImageWidth();
		height = from.getImageHeight();
		bi = createBI(width,height,from.getImageType() == TYPE_ARGB);
		int[] line = new int[width];
		for (int i = 0; i<height; i++){
			from.getPixels(line,0,0,i,width,1,width);
			setPixels(line,0,0,i,width,1,width);
		}
	}
	/* (non-Javadoc)
	 * @see eve.fx.IImage#draw(eve.fx.Graphics, int, int, int)
	 */
	public void draw(Graphics g, int x, int y, int options) {
		// TODO Auto-generated method stub
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#free()
	 */
	public void free() {
		bi.flush();
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#getPixels(int[], int, int, int, int, int, int)
	 */
	public int[] getPixels(int[] dest, int offset, int x, int y, int width,
			int height, int rowStride) {
		if (rowStride < width) rowStride = width;
		if (dest != null && (rowStride*(height-1))+offset+width > dest.length) dest = null;
		if (dest == null) dest = new int[rowStride*height+offset];
		bi.getRGB(x,y,width,height,dest,offset,rowStride);
		return dest;
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#setPixels(int[], int, int, int, int, int, int)
	 */
	public boolean setPixels(int[] src, int offset, int x, int y, int width,
			int height, int rowStride) {
		if (rowStride <= 0) rowStride = width;
		bi.setRGB(x,y,width,height,src,offset,rowStride);
		return true;
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#usesAlpha()
	 */
	public boolean usesAlpha() {
		return bi == null ? false : bi.getType() == bi.TYPE_INT_ARGB;
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void getImageScanLines(int startLine, int numLines,
			Object destArray, int offset, int destScanLineLength)
			throws IllegalStateException {
		getScanLinesUsingPixels(startLine,numLines,destArray,offset,destScanLineLength);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void setImageScanLines(int startLine, int numLines,
			Object sourceArray, int offset, int sourceScanLineLength)
			throws IllegalStateException {
		setScanLinesUsingPixels(startLine,numLines,sourceArray,offset,sourceScanLineLength);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#isWriteableImage()
	 */
	public boolean isWriteableImage() {
		return true;
	}

}

//####################################################
