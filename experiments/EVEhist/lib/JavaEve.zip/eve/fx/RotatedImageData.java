/*
 * Created on May 6, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.ImageData;
import eve.util.Utils;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class RotatedImageData extends ImageObject{

	private ImageData source;
	private int rotation;
	
	public static final int ROTATE_NONE = 0x0;
	public static final int ROTATE_90 = 0x1;
	public static final int ROTATE_180 = 0x2;
	public static final int ROTATE_270 = 0x3;
	
	public RotatedImageData(ImageData source, int rotationType)
	{
		this.source = source;
		rotation = rotationType;
		width = source.getImageWidth();
		height = source.getImageHeight();
		if (rotation == ROTATE_90 || rotation == ROTATE_270){
			int t = width; width = height; height = t;
		}
	}
	/* (non-Javadoc)
	 * @see eve.fx.IImage#usesAlpha()
	 */
	public boolean usesAlpha() {
		return source.getImageType() == TYPE_ARGB;
	}
	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength) throws IllegalStateException {
		getScanLinesUsingPixels(startLine,numLines,destArray,offset,destScanLineLength);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength) throws IllegalStateException {
		setScanLinesUsingPixels(startLine,numLines,sourceArray,offset,sourceScanLineLength);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#isWriteableImage()
	 */
	public boolean isWriteableImage() {
		return source.isWriteableImage();
	}
/*
	private void reverse(int numLines, int[] data, int offset, int length, int lineStride)
	{
		int max = length/2;
		for (int i = 0; i<numLines; i++){
			int off = offset+lineStride*i;
			int t = 0;
			for (int j = 0; j<max; j++){
				t = data[off+j];
				data[off+j] = data[off+length-j];
				data[off+length-j] = t;
			}
		}
	}
*/
	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getPixels(int[], int, int, int, int, int, int)
	 */
	public int[] getPixels(int[] dest, int offset, int x, int y, int width, int height, int rowStride) {
		if (rotation == ROTATE_NONE)
			return source.getPixels(dest,offset,x,y,width,height,rowStride);
		if (dest == null || offset+width+(height-1)*rowStride > dest.length)
			dest = new int[offset+rowStride*height];
		//dest = ImageTool.validatePixelBuffer(true,this,dest,offset,rotation == ROTATE_180 ? width : height, rotation == ROTATE_180 ? height : width,rowStride);
		try{
			if (rowStride <= 0) rowStride = width;
			for (int i = 0; i<height; i++){
				int off = offset+rowStride*i;
				int ww = width;
				int hh = 1;
				int xx = this.width-x-width;
				int yy = this.height-y-height-i;
				if (rotation == ROTATE_180){
					source.getPixels(dest,off,xx,yy,ww,hh,ww);
					Utils.reverse(dest,off,ww);
				}else{
					ww = 1;
					hh = width;
					xx = rotation == ROTATE_90 ? this.height-y-1-i : y;
					yy = rotation == ROTATE_90 ? x : this.width-x-width-i;
					//System.out.println(this.height+", "+x+", "+height+", "+i);
					//System.out.println((rotation == ROTATE_90)+", "+new Rect().set(x,y,width,height)+"->"+new Rect().set(xx,yy,ww,hh));
					source.getPixels(dest,off,xx,yy,ww,hh,ww);
					if (rotation == ROTATE_270) Utils.reverse(dest,off,hh);
				}
			}
		}catch(Throwable e){
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return dest;
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setPixels(int[], int, int, int, int, int, int)
	 */
	public boolean setPixels(int[] src, int offset, int x, int y, int width, int height, int rowStride) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see eve.fx.Drawable#draw(eve.fx.Graphics, int, int, int)
	 */
	public void draw(Graphics g, int x, int y, int options) {
		ImageTool.drawScaled(this,g,x,y,this.width,this.height,options);		
	}

}
//####################################################
