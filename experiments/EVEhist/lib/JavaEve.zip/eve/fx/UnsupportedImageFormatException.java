package eve.fx;
/**
 * This is thrown during Image decoding if the image format is not supported.
 * @author Michael L Brereton
 *
 */

//##################################################################
public class UnsupportedImageFormatException extends IllegalArgumentException{
//##################################################################

//===================================================================
public UnsupportedImageFormatException()
//===================================================================
{
	super("This image format is not supported.");
}

//##################################################################
}
//##################################################################

