package eve.fx;
/**
 * This is thrown during Image decoding if the named image was not found.
 * @author Michael L Brereton
 *
 */
//##################################################################
public class ImageNotFoundException extends IllegalArgumentException{
//##################################################################

//===================================================================
public ImageNotFoundException(String path)
//===================================================================
{
	super("Image: "+path+" not found.");
}

//##################################################################
}
//##################################################################

