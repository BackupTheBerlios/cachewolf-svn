package eve.fx;

import eve.sys.ImageData;

/**
* This is an interface that is implemented by objects that can draw themselves
* onto a Graphics context. It extends ImageData and provides an easier interface
* on most of the methods provided by ImageData.
**/
//##################################################################
public interface IImage extends ImageData, Drawable{
//##################################################################
/**
* This returns a background color if one is set for the image.
**/
public Color getBackground();
/**
 * Returns whether the image uses the Alpha channel.
 */
public boolean usesAlpha();

//##################################################################
}
//##################################################################

