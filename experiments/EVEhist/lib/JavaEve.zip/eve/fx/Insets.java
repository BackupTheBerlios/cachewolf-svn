package eve.fx;

import eve.util.Encodable;

//##################################################################
public class Insets implements Encodable{
//##################################################################
public int top, bottom, left, right;

public Insets()
{
}
//===================================================================
public Insets(int t,int l,int b,int r)
//===================================================================
{
	top = t;
	bottom = b;
	left = l;
	right = r;
}
/**
* Apply the specified Insets to the Rect r. If the Insets is null nothing is done.
**/
//===================================================================
public static void apply(Insets in,Rect r)
//===================================================================
{
	if (in == null) return;
	r.x += in.left; r.y += in.top;
	r.width -= (in.left+in.right);
	r.height -= (in.top+in.bottom);
}
/**
* Apply this Insets to the Rect r.
**/
//===================================================================
public void apply(Rect r) {apply(this,r);}
//===================================================================

//##################################################################
}
//##################################################################

