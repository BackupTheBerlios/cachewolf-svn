package eve.fx;

import java.awt.Toolkit;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import eve.io.ByteArrayRandomStream;
import eve.io.InflaterInputStream;
import eve.io.RandomStream;
import eve.io.StreamUtils;
import eve.sys.Cache;
import eve.sys.ImageData;
import eve.sys.ImageDataInfo;
import eve.util.ArraySection;
import eve.util.ByteArray;
import eve.util.FormattedDataSource;
import eve.util.Utils;


/**
* This is the PNG coder/decoder. Currently only decoding is supported.
*
* As of ewe 1.01 it is a pure Java implementation only an is pretty slow,
* but it does seem to correctly decode all PNG images.
*
* It uses the 1.01 ewe.zip library, which currently only works for reading
* zip files and streams, but not for writing them.
* 
* To use it first call boolean decode(RandomStream ras) and then
* call toImage()
**/
//##################################################################
 public class ImageDecoder { 
//##################################################################

 int width; //Must be first.
 int height; //Must be second.
 int type; //Must be third.
 int bitDepth; //Must be fourth.
 int compression; //Must be fifth.
 int filter; //Must be sixth.
 int interlace; //Must be 7th.
 byte [] paletteBytes; //Must be 8th.
 byte [] transparencyBytes; //Must be 9th.
protected int transparentColor; //Must be 10th.
protected int transparentColorLow; //Must be 11th.
Rect sourceArea;
Dimension newSize;

 boolean isBMPFile;
 boolean isJPEGFile;
 boolean isGIFFile;
 boolean isPNGFile;
 static boolean canDecodeGIF = true;
 static boolean canDecodeJPEG = true;

protected final static int [] signature = {137,80,78,71,13,10,26,10};

//-------------------------------------------------------------------
protected pngChunk getChunk(RandomStream ras) throws IOException
//-------------------------------------------------------------------
{
 	pngChunk pc = new pngChunk();
 	pc.read(ras);
 	return pc;
}

/**
* This is the background color if one was specified.
**/
 Color background;
/**
* This is the transparent color if one was specified.
**/
 Color transparent;

pngChunk palette, header, firstDat, transparency;

RandomStream source;

static void readFully(InputStream in, byte[] dest)
throws IOException
{
	StreamUtils.readFully(in,dest);
}
static void readFully(InputStream in, byte[] dest,int offset,int length)
throws IOException
{
	StreamUtils.readFully(in,dest,offset,length);
}
//ByteArray data = new ByteArray();
//===================================================================
 static boolean hasPNGSignature(byte [] startData)
//===================================================================
{
	if (startData == null) return false;
	if (startData.length < signature.length) return false;
	for (int i = 0; i<signature.length; i++)
		if ((startData[i] & 0xff) != signature[i])
			return false;
	return true;
}
//===================================================================
 static boolean hasBMPSignature(byte [] startData)
//===================================================================
{
	if (startData == null) return false;
	if (startData.length < 3) return false;
	return (startData[0] == (byte)'B' && startData[1] == (byte)'M');
}
//===================================================================
 static boolean hasGIFSignature(byte [] startData)
//===================================================================
{
	if (startData == null) return false;
	if (startData.length < 3) return false;
	return (startData[0] == (byte)'G' && startData[1] == (byte)'I' && startData[2] == (byte)'F');
}
//===================================================================
 static boolean hasJPEGSignature(byte [] startData)
//===================================================================
{
	if (startData == null) return false;
	if (startData.length < 10) return false;
	return (
			startData[0] == (byte)0xff &&
			startData[1] == (byte)0xd8 &&
			startData[2] == (byte)0xff
/*
	startData[6] == (byte)'J' && startData[7] == (byte)'F' &&
	startData[8] == (byte)'I' && startData[9] == (byte)'F'
	*/
	);
}

//===================================================================
 static boolean isDecodable(byte [] first16Bytes)
//===================================================================
{
	if (hasPNGSignature(first16Bytes)) return true;
	if (hasBMPSignature(first16Bytes)) return true;
	if (hasJPEGSignature(first16Bytes)) return true;
	if (hasGIFSignature(first16Bytes)) return true;
	return false;
}

private static final int
//============================================================
	readInt(byte [] source,int offset,int numBytes)// throws IOException
//============================================================
{
	int ret = 0;
	for (int i = offset+numBytes-1; i>=offset; i--) {
		ret = (ret<<8) & 0xffffff00;
		ret |= ((int)source[i])&0xff;
	}
	return ret;
}

private BufferedImageData decodedImage;

private boolean decodeFully(FormattedDataSource source,RandomStream ras) throws IOException, ImageDecodingException
{
	ras.setPosition(0);
	final ArraySection as = source.getAllBytes(null);
	Toolkit tk = Toolkit.getDefaultToolkit();
	java.awt.Image im = tk.createImage((byte[])as.data,as.startIndex,as.length);
	if (!(new ImagePreparer().prepare(im,false))) throw new ImageDecodingException(null);
	width = im.getWidth(null);
	height = im.getHeight(null);
	decodedImage = Image.toBufferedImage(im);
	im.flush();
	return true;
}
//===================================================================
private boolean decodeNonPNG(FormattedDataSource fds, RandomStream ras) throws IOException, ImageDecodingException
//===================================================================
{
	source = ras;
	ras.setPosition(0);
	byte [] p = new byte[16];
	readFully(ras,p); 
	if (hasJPEGSignature(p)){
		isJPEGFile = true;
		return decodeFully(fds,ras);
	}
	if (hasGIFSignature(p)){
		isGIFFile = true;
		return decodeFully(fds,ras);
	}
	ras.setPosition(0);
	p = new byte[36];
	readFully(ras,p); 
	if (p[0] == (byte)'B' && p[1] == (byte)'M'){
		int bitmapOffset = readInt(p,10,4);
		int infoSize = readInt(p,14,4);
		if (infoSize == 40){
			width = readInt(p,18,4);
			height = readInt(p,22,4);
			if (width < 65535 && height < 65535){
				if (height < 0) height = -height;
				int bpp = readInt(p,28,2);
				if (bpp == 1 || bpp == 4 || bpp == 8 || bpp == 24){
					int compression = readInt(p,30,4);
					if (compression == 0){
						isBMPFile = true;
						return true;
					}
				}
			}
		}
	}
	return false; 
}
 boolean decode(FormattedDataSource source) throws IOException, ImageDecodingException
{
	RandomStream rs = source.getRewindableStream();
	boolean ret = decode(source,rs);
	source.rewind();
	return ret;
}

/**
* Call this first to decode the parameters of the PNG image.
**/
//===================================================================
private boolean decode(FormattedDataSource fds, RandomStream ras) throws IOException, ImageDecodingException
//===================================================================
{
	source = ras;
	//ras.setPosition(0);
	byte [] sig = new byte[signature.length];
	try{
		readFully(ras,sig); 
	}catch(EOFException e){
		return decodeNonPNG(fds,ras);
	}
	for (int i = 0; i<sig.length; i++)
		if ((sig[i] & 0xff) != signature[i])
			return decodeNonPNG(fds,ras);
	pngChunk pc = getChunk(ras);
	if (pc == null || !pc.name.equals("IHDR")) throw new ImageDecodingException("No IHDR");
	isPNGFile = true;
	header = pc;
	width = Utils.readInt(pc.data,0,4);
	height = Utils.readInt(pc.data,4,4);
	bitDepth = pc.data[8] & 0xff;
	type = pc.data[9] & 0xff;
	compression = pc.data[10] & 0xff;
	filter = pc.data[11] & 0xff;
	interlace = pc.data[12] & 0xff;
	
	int scale = 0;
	switch(bitDepth){
		case 1:  scale = 7; break;
		case 2:  scale = 6; break;
		case 4:  scale = 4; break;
		default:  scale = 0; break;
	}
	
	for (pc = getChunk(ras); pc != null; pc = getChunk(ras)){
		if (pc.name.equals("IDAT")) {
			firstDat = pc;
			break;
		}
		else if (pc.name.equals("PLTE")){
			palette = pc;
			paletteBytes = pc.data;
		}
		else if (pc.name.equals("bKGD")){
			switch(type){
				case 0:
					if (pc.data.length < 2) break;
					int v = bitDepth == 16 ? pc.data[0] & 0xff : (pc.data[1] & 0xff) << scale;
					background = new Color(v,v,v);
					break;
				case 3:
					if (pc.data.length < 1 || palette == null) break;
					int idx = pc.data[0] & 0xff;
					if (idx >= palette.data.length/3) break;
					background = new Color(palette.data[idx*3] & 0xff,palette.data[idx*3+1] & 0xff,palette.data[idx*3+2] & 0xff);
					break;
				case 2:
				case 6:
					if (pc.data.length < 6) break;
					if (bitDepth == 16)
						background = new Color(pc.data[0] & 0xff,pc.data[2] & 0xff,pc.data[4] & 0xff);
					else
						background = new Color(pc.data[1] & 0xff,pc.data[3] & 0xff,pc.data[5] & 0xff);
				default:
					break;
			}
		}
		else if (pc.name.equals("tRNS")){
			transparency = pc;
			transparencyBytes = pc.data;
			switch(type){
				case 0: //Grayscale.
					if (pc.data.length < 2) transparency = null;
					else {
						transparentColor = (pc.data[0] & 0xff)<<8|(pc.data[1] & 0xff);
						int v = bitDepth == 16 ? pc.data[0] & 0xff : pc.data[1] & 0xff;
						v = v << scale;
						transparent = new Color(v,v,v);
					}
					break;
				case 2: //True Color.
					if (pc.data.length < 6) transparency = null;
					else {
						transparentColor = bitDepth == 16 ?
							(pc.data[0] & 0xff) << 16 |(pc.data[2] & 0xff) << 8 |(pc.data[4] & 0xff):
							(pc.data[1] & 0xff) << 16 |(pc.data[3] & 0xff) << 8 |(pc.data[5] & 0xff);
						transparentColorLow = bitDepth == 16 ?
							(pc.data[1] & 0xff) << 16 |(pc.data[3] & 0xff) << 8 |(pc.data[5] & 0xff):
							0;
						transparent = new Color((transparentColor >> 16) & 0xff,(transparentColor >> 8) & 0xff,(transparentColor >> 0) & 0xff);
					}
					break;
				case 3: //Palette.
					if (palette == null) break;
					int tsize = pc.data.length;
					if (tsize > palette.data.length/3) tsize = palette.data.length/3;
					if (tsize == 1){
						for (int i = 0; i<tsize; i++){
							if (pc.data[i] == 0){
								transparent = new Color((palette.data[i*3] & 0xff),(palette.data[i*3+1] & 0xff),(palette.data[i*3+2] & 0xff));
								//ewe.sys.Vm.debug(transparent.toString(),1);
								break;
							}
						}
					}
					break;
				default:
					transparency = null;
					break;
			}
		}
		else if (pc.name.equals("IEND")) break;
	}
	return true;
}

//-------------------------------------------------------------------
int PaethPredictor (int a,int b,int c)
//-------------------------------------------------------------------
{
	int p = a+b-c;
	int pa = p-a; if (pa < 0) pa = -pa;
	int pb = p-b; if (pb < 0) pb = -pb;
	int pc = p-c; if (pc < 0) pc = -pc;
	if (pa <= pb && pa <= pc) return a;
	else if (pb <= pc) return b;
	else return c;
}

//-------------------------------------------------------------------
boolean unfilter(byte [] line,byte [] old,int length,int bbp)
throws ImageDecodingException
//-------------------------------------------------------------------
{
		if (line[0] == 1)
			for (int w = 0; w<length-1; w++){
				if (w >= bbp)
					line[1+w] += line[1+w-bbp];
			}
		else if (line[0] == 2)
			for (int w = 0; w<length-1; w++){
				if (old != null)
					line[1+w] += old[1+w];
			}
		else if (line[0] == 3)
			for (int w = 0; w<length-1; w++){
				int av = 0;
				if (w >= bbp) av += (line[1+w-bbp] & 0xff);
				if (old != null) av += (old[1+w] & 0xff);
				av /= 2;
				line[1+w] += av;
			}
		else if (line[0] == 4)
			for (int w = 0; w<length-1; w++){
					line[1+w] += 
						PaethPredictor(w >= bbp ? line[1+w-bbp] & 0xff: 0,old != null ? old[1+w] & 0xff: 0, old != null && w >= bbp ? old[1+w-bbp] & 0xff :0);
			}
		else if (line[0] != 0)
			throw new ImageDecodingException("Unknown filter: "+line[0]);
		return true;
}

//ADAM7 interlacing use.
static final int [] hoffset = {0,4,0,2,0,1,0};
static final int [] voffset = {0,0,4,0,2,0,1};
static final int [] hfreq = {8,8,4,4,2,2,1};
static final int [] vfreq = {8,8,8,4,4,2,2};

private boolean nativeToImage(ImageData dest, InputStream is) throws IOException
{
	throw new IOException("Cannot decode PNG in Java yet.");
}
/**
 * 
 * @param source
 * @return
 * @throws IOException
 * @throws ImageDecodingException
 */
public boolean analyze(FormattedDataSource source) throws IOException, ImageDecodingException
{
	return analyze(source,(ImageInfo)null);
}
/**
 * Analyze the image represented by source and set the width and
 * height of the image.
 * After calling
 * this method you can call one of the decodeFully() methods after
 * setting up a destination for the image.
 * @param source the source image.
 * @return true if successfully decoded, false if not.
 * @throws IOException
 * @throws ImageDecodingException
 */
public void analyze(FormattedDataSource source, Dimension size) throws IOException, ImageDecodingException
{
	if (!analyze(source)) throw new ImageDecodingException("Could not decode image.");
	size.width = width;
	size.height = height;
}
/**
 * Call this after analyze() to 
 * setup the requested source area to decode and final size of the
 * decoded image. This allows a portion of the image to be decoded and
 * scaled to fit the requested size. 
 * @param srcArea the source area to decode - this will be adjusted
 * to fit within the image if it is too large. If it is null then the
 * entire image is selected.
 * @param newSize the new size of the decoded area. This will be adjusted
 * if CREATE_OPTION_KEEP_ASPECT_RATIO or CREATE_OPTION_DONT_SCALE_UP is used.
 * @param createOptions any of the CREATE_OPTION_XXX values that affect scaling.
 * @param trueNewSize if this is not null this will hold the final true size of the
 * image that will be decoded. You would use this if you are sending a possibly null newSize
 * and/or null srcArea parameter but still want to know what the final size of the
 * decoded image will be.
 */
public void setSourceAndDestination(Rect srcArea, Dimension newSize, int createOptions, Dimension trueNewSize)
{
	ImageTool.adjustAreaAndScale(width, height, srcArea, newSize, createOptions);
	if (srcArea == null) sourceArea = new Rect(0,0,width,height);
	else sourceArea = new Rect().set(srcArea);
	this.newSize = new Dimension(sourceArea.width,sourceArea.height);
	if (newSize != null) this.newSize.set(newSize);
	if (trueNewSize != null) trueNewSize.set(this.newSize);
}
/**
 * Decode a portion of the Image to the ImageMaker.
 * @param source the data source.
 * @param maker the destination ImageMaker.
 * @param srcArea the area within the source image.
 * @throws ImageDecodingException
 */
public void decode(FormattedDataSource source, ImageMaker maker, Rect srcArea, Dimension newSize, int createOptions) throws ImageDecodingException
{
	try{
		if (!analyze(source)) throw new ImageDecodingException(source,null);
		ImageDataInfo id = new ImageDataInfo();
		getImageDataInfo(id);
		setSourceAndDestination(srcArea, newSize, createOptions, null);
		id.width = this.newSize.width; id.height = this.newSize.height;
		Rect r = Rect.getCached(0,0,id.width,id.height);
		try{
			maker.createImageFor(id,r);
		}finally{
			r.cache();
		}
		decodeFully(maker);
	}catch(IllegalArgumentException e2){
		throw new ImageDecodingException(source,e2);
	}catch(IOException e){
		throw new ImageDecodingException(source,e);
	}
}
public boolean analyze(FormattedDataSource source, ImageInfo destInfo) throws IOException, ImageDecodingException
{
	RandomStream rs = source.getRewindableStream();
	boolean ret = decode(source,rs);
	source.rewind();
	if (destInfo != null){
		destInfo.width = width;
		destInfo.height = height;
		destInfo.size = width*height*4;
		destInfo.canScale = true;
		destInfo.format = destInfo.FORMAT_PNG;
		if (isBMPFile) destInfo.format = destInfo.FORMAT_BMP;
		else if (isJPEGFile) destInfo.format = destInfo.FORMAT_JPEG;
		else if (isGIFFile) destInfo.format = destInfo.FORMAT_GIF;
	}
	sourceArea = new Rect(0,0,width,height);
	return ret;
}
public ImageDataInfo getImageDataInfo(ImageDataInfo destInfo)
{
	if (destInfo == null) destInfo = new ImageDataInfo();
	destInfo.width = width;
	destInfo.height = height;
	destInfo.isReadable = true;
	destInfo.isWriteable = true;
	// FIXME - put more meaningful info.
	destInfo.type = ImageData.TYPE_UNKNOWN;
	return destInfo;
}
public void decode(FormattedDataSource source, ImageMaker maker) throws ImageDecodingException
{
	try{
		if (!analyze(source)) throw new ImageDecodingException(source,null);
		maker.createImageFor(getImageDataInfo(null),sourceArea);
		decodeFully(maker);
	}catch(IllegalArgumentException e2){
		throw new ImageDecodingException(source,e2);
	}catch(IOException e){
		throw new ImageDecodingException(source,e);
	}
}

public ImageDecoder(){}

public ImageDecoder(FormattedDataSource source, ImageMaker maker) throws ImageDecodingException
{
	decode(source,maker);
}
/**
 * Only call this after calling analyze() and then optionally calling
 * setSourceAndDestination().
 */
public Picture decodeFully() throws IOException
{
	int w = width, h = height;
	if (newSize != null){
		w = newSize.width; h = newSize.height;
	}else if (sourceArea != null){
		w = sourceArea.width; h = sourceArea.height;
	}
	PixelBuffer pb = new PixelBuffer();
	pb.resizeTo(w, h, null);
	decodeFully(pb);
	return new Picture(pb,0);
}
/**
 * Decode a possibly scaled image.
 * @param fds the source of the image - this will be closed after decoding.
 * @param newWidth the new width of the image if scaled.
 * @param newHeight the new height of the image if scaled.
 * @param shouldScale true to scale the image, false if not to.
 * @param scaleOptions any of the ImageData.CREATE_OPTION_XXX values.
 * @param fullSize an optional dimension to hold the full size of the image.
 * @param destination a destination ImageMaker to hold the data (e.g. a PixelBuffer)
 * or null to decode and return a Picture.
 * @throws IOException
 * @throws ImageDecodingException
 * @return the decoded and possibly scaled image.
 */
public static IImage decodeScaled(FormattedDataSource fds, int newWidth, int newHeight, boolean shouldScale, int scaleOptions, Dimension fullSize, ImageMaker destination)
throws IOException, ImageDecodingException
{
	ImageDecoder id = new ImageDecoder();
	Dimension d = Dimension.getCached(0, 0);
	try{
		id.analyze(fds,d);
		if (fullSize != null) fullSize.set(d);
		if (shouldScale){
			d.set(newWidth, newHeight);
			id.setSourceAndDestination(null, d, scaleOptions, null);
		}
		if (destination == null) return id.decodeFully();
		else{
			ImageDataInfo io = (ImageDataInfo)Cache.get(ImageDataInfo.class);
			Rect r = Rect.getCached(0,0,id.width,id.height);
			try{
				if (id.newSize != null) r.set(0,0,id.newSize.width, id.newSize.height);
				id.getImageDataInfo(io);
				io.width = r.width; io.height = r.height;
				destination.createImageFor(io, r);
			}finally{
				Cache.put(io);
				Cache.put(r);
			}
			id.decodeFully(destination);
			return ImageAdapter.toIImage(destination.getImageData(),null);
		}
	}finally{
		d.cache();
		fds.close();
	}
}
/**
 * Decode a possibly scaled picture.
 * @param fds the source of the image - this will be closed after decoding.
 * @param newWidth the new width of the image if scaled.
 * @param newHeight the new height of the image if scaled.
 * @param shouldScale true to scale the image, false if not to.
 * @param keepAspectRatio true to keep the aspect ratio of the original.
 * @param scaleDownOnly true to only scale down, not up.
 * @param fullSize an optional dimension to hold the full size of the image.
 * @throws IOException
 * @throws ImageDecodingException
 * @return the decoded and possibly scaled image.
 */
public static Picture decodeScaledPicture(FormattedDataSource fds, int newWidth, int newHeight, boolean shouldScale, boolean keepAspectRatio, boolean scaleDownOnly, Dimension fullSize)
throws IOException, ImageDecodingException
{
	int opts = 0;
	if (keepAspectRatio) opts |= ImageData.CREATE_OPTION_KEEP_ASPECT_RATIO;
	if (scaleDownOnly) opts |= ImageData.CREATE_OPTION_DONT_SCALE_UP;
	return (Picture)decodeScaled(fds,newWidth,newHeight,shouldScale,opts,fullSize,null);
}
/**
 * Decode a possibly scaled picture.
 * @param fds the source of the image - this will be closed after decoding.
 * @param newSize the new width and height of the image if scaled, or null for no scaling.
 * @param keepAspectRatio true to keep the aspect ratio of the original.
 * @param scaleDownOnly true to only scale down, not up.
 * @param fullSize an optional dimension to hold the full size of the image.
 * @throws IOException
 * @throws ImageDecodingException
 * @return the decoded and possibly scaled image.
 */
public static Picture decodeScaledPicture(FormattedDataSource fds, Dimension newSize, boolean keepAspectRatio, boolean scaleDownOnly, Dimension fullSize)
throws IOException, ImageDecodingException
{
	int opts = 0;
	if (keepAspectRatio) opts |= ImageData.CREATE_OPTION_KEEP_ASPECT_RATIO;
	if (scaleDownOnly) opts |= ImageData.CREATE_OPTION_DONT_SCALE_UP;
	return (Picture)decodeScaled(fds,newSize != null ? newSize.width : 0,newSize != null ? newSize.height : 0,newSize != null,opts,fullSize,null);
}
private ImageMaker adjustDest(ImageMaker dest)
{
	if (newSize != null){
		int sw = width, sh = height;
		if (sourceArea != null){
			sw = sourceArea.width;
			sh = sourceArea.height;
		}
		if (sw != newSize.width && sh != newSize.height)
			return new imageScaler(dest,sw,sh,newSize.width,newSize.height,0);
	}
	return dest;
}

//-------------------------------------------------------------------
//protected static native boolean toImagePixels(pngSpecs specs,BasicStream dataStream,Image image);
//-------------------------------------------------------------------
public void decodeFully(ImageMaker dest) throws IOException
{
	if (dest == null) throw new NullPointerException();
	dest = adjustDest(dest);
	if (isPNGFile){
		InputStream str = firstDat.getDataStream();
		if (str == null) throw new IOException("Could not get Data Stream");
		InputStream is = new InflaterInputStream(str);
		if (is == null) throw new IOException("No InflaterInputStream in library!");
		if (!javaToImage(dest,is)) throw new IOException("An exception occured decoding the image!");
		is.close();
	}else if (isBMPFile){
		readBMP(source,null,dest);
	}else if (isJPEGFile || isGIFFile){
		int[] pix = new int[width];
		xpixelLine pixLine = new xpixelLine();
		for (int i = 0; i<height; i++){
			decodedImage.getPixels(pix,0,0,i,width,1,width);
			pixLine.setPixelLine(dest,sourceArea,i,pix,0,0,1,width,1);
		}
		dest.scanLinesComplete();
	}else{
		throw new IOException("Cannot decode this format.");
	}
}
/**
* Call this after calling decode to convert it to an Image.
**/
//===================================================================
private boolean javaToImage(ImageMaker im,InputStream is) throws IOException, ImageDecodingException
//===================================================================
{
	//if (type != 2 && type != 0 && type != 3) 
		//return (Image)returnError("PNGCodec cannot decode type: "+type,null);
	int bytesPerLine = width*3;
	int bbp = 3;
	int maskStart = 0xFF;
	int maskShift = 8;
	int scale = 0;
	int freq = 8/bitDepth;
	int maxIdx = palette != null ? palette.data.length/3 : 0;
	int maxT = transparency != null ? transparency.data.length : 0;
	int byteStep = 1;
	if (type == 2 || type == 6){ 
		if (bitDepth == 16){
			bbp = type == 6 ? 8:6;
			bytesPerLine = width*bbp;
		}else{
			bbp = type == 6 ? 4:3;
			bytesPerLine = width*bbp;
		}
	}else if (type != 2){
		if (bitDepth >= 8) {
			bbp = bitDepth/8;
			bytesPerLine = width*bbp;
			byteStep = bbp;
		}else{
			bbp = 1;
			bytesPerLine = (width+freq-1)/freq;
			switch(bitDepth){
			case 1: maskStart = 0x80; maskShift = 1; scale = 7; break;
			case 2: maskStart = 0xC0; maskShift = 2; scale = 6; break;
			case 4: maskStart = 0xF0; maskShift = 4; scale = 4; break;
			case 8: maskStart = 0xFF; maskShift = 8; scale = 0; break;
			}
		}
		if (type == 4) {
			bbp *= 2;
			byteStep *= 2;
			bytesPerLine = width*bbp;
		}
	}
		
	//InputStream str = firstDat.getDataStream();
	//InputStream is = Io.getInflaterInputStream(str);
	byte [] line = new byte[bytesPerLine+1];
	byte [] old = new byte[bytesPerLine+1];
	byte [] temp;
	int [] all = new int[width*height];
	try{
//..................................................................
	if (interlace == 0){
//..................................................................
		for (int i = 0; i<height; i++){
			int count = line.length;
			readFully(is,line);
			if (!unfilter(line,i == 0 ? null : old,line.length,bbp)) return false;
			if (type == 2 || type == 6){
				//......................................................
				// True Color.
				//......................................................
				int o = i*width;
				for (int w = 0; w<width; w++){
					int wo = w*bbp;
					int alpha = 0xff000000;
					int colorLow = 0;
					int color = (bbp == 3 || bbp == 4) ?
						((line[1+wo] & 0xff) << 16)|((line[2+wo] & 0xff) << 8)|((line[3+wo] & 0xff)):
						((line[1+wo] & 0xff) << 16)|((line[3+wo] & 0xff) << 8)|((line[5+wo] & 0xff));
					if (bbp > 4) 
						colorLow = ((line[2+wo] & 0xff) << 16)|((line[4+wo] & 0xff) << 8)|((line[6+wo] & 0xff));
					if (bbp == 4) alpha = (line[4+wo] & 0xff) << 24;
					else if (bbp == 8) alpha = (line[7+wo] & 0xff) << 24;
					else if (transparency != null && color == transparentColor && colorLow == transparentColorLow)
						alpha = 0;
					all[o+w] = alpha|color;
					//if (type == 6) im.alphaChannel[o+w] = (byte)((alpha >> 24) & 0xff);
				}
			}else{
				int mask = maskStart;
				int idx = 1;
				int o = i*width;
				int shift = 8-maskShift;
				for (int w = 0; w<width; w++){
					boolean maxed = false;
					int v = (line[idx] & mask);
					maxed = v == mask;
					v = v >> shift;
					int fullV = bitDepth == 16 ? (line[idx+1] & mask)|v << 8: v;
					int alpha = 0xff000000;
					
					if ((transparency != null) && (fullV == transparentColor)){
						//ewe.sys.Vm.debug(fullV+", "+transparentColor,0);
						alpha = 0;
					}
					if (type == 0 || type == 4){
						//......................................................
						// Grayscale.
						//......................................................
						if (maxed) v = 0xff;
						else v = v << scale;
						int gray = (v << 16)|(v << 8)|(v);
						if (type == 4) alpha = (line[idx+bbp/2] & 0xff)<<24;
						all[o+w] = alpha|gray;
						//if (type == 4) im.alphaChannel[o+w] = (byte)((alpha >> 24) & 0xff);
					}else{
						//......................................................
						// Palette.
						//......................................................
						if (v >= maxIdx) v = 0;
						int color = ((palette.data[v*3] & 0xff) << 16)|((palette.data[v*3+1] & 0xff) << 8)|((palette.data[v*3+2] & 0xff));
						alpha = (v < maxT) ? (transparency.data[v] & 0xff) << 24 : 0xff000000;
						all[o+w] = alpha|color;
					}
					if (shift == 0) {
						mask = maskStart;
						shift = 8-maskShift;
						idx += byteStep;
					}else{
						mask >>= maskShift;
						shift -= maskShift;
					}
				}
			}
			temp = old; old = line; line = temp;
		}
//..................................................................
	}else if (interlace == 1){
//..................................................................
		for (int pass = 1; pass <= 7; pass++){
			int numLines = (height-voffset[pass-1]+(vfreq[pass-1]-1))/vfreq[pass-1];
			int numPixels = (width-hoffset[pass-1]+(hfreq[pass-1]-1))/hfreq[pass-1];
			int numBytes = bbp >= 2 ? bbp*numPixels : (numPixels+freq-1)/freq;
			int pixelLine = voffset[pass-1];
			for (int ln = 0; ln<numLines; ln++){
				readFully(is,line,0,numBytes+1);
				if (!unfilter(line,ln == 0 ? null : old,numBytes+1,bbp)) return false;
				if (type == 2 || type == 6){
					//......................................................
					// True Color.
					//......................................................
					int o = pixelLine*width;
					int pixelCol = hoffset[pass-1];
					for (int w = 0; w<numPixels; w++){
						int wo = w*bbp;
						int alpha = 0xff000000;
						int colorLow = 0;
						int color = (bbp == 3 || bbp == 4) ?
							((line[1+wo] & 0xff) << 16)|((line[2+wo] & 0xff) << 8)|((line[3+wo] & 0xff)):
							((line[1+wo] & 0xff) << 16)|((line[3+wo] & 0xff) << 8)|((line[5+wo] & 0xff));
						if (bbp > 4) 
							colorLow = ((line[2+wo] & 0xff) << 16)|((line[4+wo] & 0xff) << 8)|((line[6+wo] & 0xff));
						if (bbp == 4) alpha = (line[4+wo] & 0xff) << 24;
						else if (bbp == 8) alpha = (line[7+wo] & 0xff) << 24;
						else if (transparency != null && color == transparentColor && colorLow == transparentColorLow)
							alpha = 0;
						all[o+pixelCol] = alpha|color;
						pixelCol += hfreq[pass-1];
					}
				}else{
					int mask = maskStart;
					int idx = 1;
					int o = pixelLine*width;
					int pixelCol = hoffset[pass-1];
					int shift = 8-maskShift;
					for (int w = 0; w<numPixels; w++){
						boolean maxed = false;
						int v = (line[idx] & mask);
						maxed = v == mask;
						v = v >> shift;
						int fullV = bitDepth == 16 ? (line[idx+1] & mask)|v << 8: v;
						int alpha = 0xff000000;
						if ((transparency != null) && (fullV == transparentColor))
							alpha = 0;
						if (type == 0 || type == 4){
							//......................................................
							// GrayScale.
							//......................................................
							if (maxed) v = 0xff;
							else v = v << scale;
							int gray = (v << 16)|(v << 8)|(v);
							if (type == 4) alpha = (line[idx+bbp/2] & 0xff)<<24;
							all[o+pixelCol] = alpha|gray;
							pixelCol += hfreq[pass-1];
						}else{
							//......................................................
							// Palette.
							//......................................................
							if (v >= maxIdx) v = 0;
							int color = ((palette.data[v*3] & 0xff) << 16)|((palette.data[v*3+1] & 0xff) << 8)|((palette.data[v*3+2] & 0xff));
							alpha = (v < maxT) ? (transparency.data[v] & 0xff) << 24 : 0xff000000;
							all[o+pixelCol] = alpha|color;
							pixelCol += hfreq[pass-1];
						}
						if (shift == 0) {
							mask = maskStart;
							shift = 8-maskShift;
							idx += byteStep;
						}else{
							mask >>= maskShift;
							shift -= maskShift;
						}
					}
				}
				temp = old; old = line; line = temp;
				pixelLine += vfreq[pass-1];
			}
		}
	}else{
		throw new ImageDecodingException("Unknown interlace method: "+interlace);
	}
	xpixelLine pl = new xpixelLine();
	for (int y = 0; y<height; y++){
		pl.setPixelLine(im,sourceArea,y,all,y*width,0,1,width,1);
	}
	}finally{
		im.scanLinesComplete();
	}
	return true;
}

private void pixelsToRGB(int bitsPerPixel, int width, byte pixels[], int pixelOffset,
		int rgb[], int rgbOffset, int cmap[])
		{
		if (bitsPerPixel == 24){
			int alpha = 255<<24;
			for (int i = 0, px = pixelOffset; i<width; i++){
				rgb[rgbOffset+i] = alpha|((int)pixels[px] & 0xff)<< 0 | ((int)pixels[px+1] & 0xff) << 8 | ((int)pixels[px+2] & 0xff) << 16;
				px += 3;
			}
			return;
		}
		int mask, step;
		if (bitsPerPixel == 1)
			{
			mask = 0x1;
			step = 1;
			}
		else if (bitsPerPixel == 4)
			{
			mask = 0x0F;
			step = 4;
			}
		else // bitsPerPixel == 8
			{
			mask = 0xFF;
			step = 8;
			}
		int bit = 8 - step;
		int bytnum = pixelOffset;
		int byt = pixels[bytnum++];
		int x = 0;
		while (true)
			{
			int colorIndex = ((mask << bit) & byt) >> bit;
			rgb[rgbOffset++] = cmap[colorIndex] | (0xFF << 24);
			if (++x >= width)
				break;
			if (bit == 0)
				{
				bit = 8 - step;
				byt = pixels[bytnum++];
				}
			else
				bit -= step;
			}
		}


	private static int inGetUInt32(byte bytes[], int off)
	{
	return ((bytes[off + 3]&0xFF) << 24) | ((bytes[off + 2]&0xFF) << 16) |
		((bytes[off + 1]&0xFF) << 8) | (bytes[off]&0xFF);
	}

//	Intel architecture getUInt16
	private static int inGetUInt16(byte bytes[], int off)
	{
	return ((bytes[off + 1]&0xFF) << 8) | (bytes[off]&0xFF);
	}

	private static int readBytes(DataInputStream data, byte b[])
	{
	int nread = 0;
	int len = b.length;
	while (true)
		{
		int n = 0;
		try { n = data.read(b, nread, len - nread); }
		catch (Exception e) {}
		if (n <= 0)
			return -1;
		nread += n;
		if (nread == len)
			return len;
		}
	}
	
	 static boolean debugImages = false;//true;
	
	private void readBMP(InputStream in, String name, ImageMaker dest)
	{
//	 read header (54 bytes)
//	 0-1   magic chars 'BM'
//	 2-5   uint32 filesize (not reliable)
//	 6-7   uint16 0
//	 8-9   uint16 0
//	 10-13 uint32 bitmapOffset
//	 14-17 uint32 info size
//	 18-21 int32  width
//	 22-25 int32  height
//	 26-27 uint16 nplanes
//	 28-29 uint16 bits per pixel
//	 30-33 uint32 compression flag
//	 34-37 uint32 image size in bytes
//	 38-41 int32  biXPelsPerMeter (unused)
//	 32-45 int32  biYPelsPerMeter (unused)
//	 46-49 uint32 colors used (unused)
//	 50-53 uint32 important color count (unused)
	byte header[] = new byte[54];
	DataInputStream data = new DataInputStream(in);
	if (readBytes(data, header) != 54)
		{
		System.out.println("ERROR: can't read image header for " + name);
		return;
		}
	if (header[0] != 'B' || header[1] != 'M')
		{
		System.out.println("ERROR: " + name + " is not a BMP image");
		return;
		}
	int bitmapOffset = inGetUInt32(header, 10);

	int infoSize = inGetUInt32(header, 14);
	if (infoSize != 40)
		{
		System.out.println("ERROR: " + name + " is old-style BMP");
		return;
		}
	int width = inGetUInt32(header, 18);
	int height = inGetUInt32(header, 22);
	if (width < 0 || height < 0 || width > 65535 || height > 65535)
		{
		System.out.println("ERROR: " + name + " has invalid width/height");
		return;
		}
	int bpp = inGetUInt16(header, 28);
	if (bpp != 1 && bpp != 4 && bpp != 8 && bpp != 24)
		{
		System.out.println("ERROR: " + name + " is not a 2, 16, 256 or 24-bit color image");
		return;
		}
	int compression = inGetUInt32(header, 30);
	if (compression != 0)
		{
		System.out.println("ERROR: " + name + " is a compressed image");
		return;
		}
	int numColors = 1 << bpp;
	int scanlen = (width * bpp + 7) / 8; // # bytes
	scanlen = ((scanlen + 3) / 4) * 4; // end on 32 bit boundry
//	 read colormap
	//
//	 0-3 uint32 col[0]
//	 4-7 uint32 col[1]
//	 ...
	int cmapSize = bitmapOffset - 54;
	byte cmapData[] = new byte[cmapSize];
	if (cmapSize != 0)
		if (readBytes(data, cmapData) != cmapSize)
			{
			System.out.println("ERROR: can't read colormap of " + name);
			return;
			}
			
	if (cmapSize == 0) numColors = 0;
	int cmap[] = new int[numColors];
	int j = 0;
	for (int i = 0; i < numColors && j<=cmapSize-4; i++)
		{
		byte blue = cmapData[j++];
		byte green = cmapData[j++];
		byte red = cmapData[j++];
		j++; // skip reserved
		cmap[i] = ((red & 0xFF) << 16) | ((green & 0xFF) << 8) | (blue & 0xFF);
		}

//	 read pixels and store in RGB buffer
	int[] rgb = new int[width];
	byte pixels[] = new byte[scanlen];
	xpixelLine pl = new xpixelLine();
	for (int y = height - 1; y >= 0; y--)
		{
		if (readBytes(data, pixels) != scanlen)
			{
			System.out.println("ERROR: scanline " + y + " bad in image " + name);
			return;
			}
		if (width == 0)
			continue;
		pixelsToRGB(bpp, width, pixels, 0, rgb, 0, cmap);
		//dest.setPixels(rgb,0,0,y,width,1,width);
		//FIXME use sourceArea.
		pl.setPixelLine(dest,sourceArea,y,rgb,0,0,1,width,1);
		}
	dest.scanLinesComplete();
	if (debugImages) 
		System.out.println(width+", "+height+", "+scanlen);

	/*
	java.awt.image.MemoryImageSource imageSource;
	imageSource = new java.awt.image.MemoryImageSource(width, height, rgb, 0, width);
	java.awt.Toolkit awtToolkit = java.awt.Toolkit.getDefaultToolkit();
	_awtImage = toBufferedImage(awtToolkit.createImage(imageSource));
	*/
}

/**
* This is used for debugging only. Specifies the number of milliseconds it took to convert the image.
* (This is the first step in toImage()).
**/
 int convertTime;
/**
* This is used for debuggin only. Specifies the number of milliseconds it took to create the
* image from the raw pixel values. (This is the second step in toImage())
**/
 int setPixelTime;
//===================================================================
 public String toString()
//===================================================================
{
	return "("+width+", "+height+"), Color-type: "+type+", Bit-depth: "+bitDepth+", Compression: "+compression+", Filter: "+filter+", Interlace: "+interlace;
}
/*
//-------------------------------------------------------------------
static boolean readFully(BasicStream in,byte [] dest,int start,int length)
//-------------------------------------------------------------------
{
	while(length != 0){
		int got = in.nonBlockingRead(dest,start,length);
		if (got < 0) return false;
		length -= got; start += got;
	}
	return true;
}
*/
//static 
byte [] gifBuffer;
final static int NULL =   0;
final static int MAX_CODES =  4095;

/* Static variables */
int curr_size;                     /* The current code size */
int clear;                         /* Value for a clear code */
int ending;                        /* Value for a ending code */
int newcodes;                      /* First available code */
int top_slot;                      /* Highest code for current size */
int slot;                          /* Last read code */
/* The following static variables are used
 * for seperating out codes
 */
int navail_bytes = 0;              /* # bytes left in block */
int nbits_left = 0;                /* # bits left in current byte */
byte b1;                           /* Current byte */
byte [] byte_buff = new byte[257];               /* Current block */
int pbytes;                     /* Pointer to next byte in block */

int [] code_mask = {
     0,
     0x0001, 0x0003,
     0x0007, 0x000F,
     0x001F, 0x003F,
     0x007F, 0x00FF,
     0x01FF, 0x03FF,
     0x07FF, 0x0FFF
     };

int stack[] = new int[MAX_CODES + 1];            /* Stack for storing pixels */
int suffix[] = new int[MAX_CODES + 1];           /* Suffix table */
int prefix[] = new int[MAX_CODES + 1];           /* Prefix linked list */

/* This function initializes the decoder for reading a new image.
 */
int init_exp(int size)
{
   curr_size = size + 1;
   top_slot = 1 << curr_size;
   clear = 1 << size;
   ending = clear + 1;
   slot = newcodes = ending + 1;
   navail_bytes = nbits_left = 0;
   return(0);
}

static byte [] byteBuffer = new byte[1];

//===================================================================
int getByte(InputStream s) throws IOException
//===================================================================
{
	return s.read();
}


boolean getMoreBytes(InputStream in) throws IOException
{
	if (navail_bytes > 0) return true;
	pbytes = 0;
	boolean ret = true;
	if ((navail_bytes = getByte(in)) < 0) ret = false;
	else if (navail_bytes != 0){
		readFully(in,byte_buff,0,navail_bytes);
	}
	//if (!ret) ewe.sys.Vm.debug("getMoreBytes() failed!");
	return ret;
}

int lastCode = -1;
int didCodes = 0;
/* get_next_code()
 * - gets the next code from the GIF file.  Returns the code, or else
 * a negative number in case of file errors...
 */
//===================================================================
int getNextCode(InputStream in) throws IOException
//===================================================================
   {
   int i, x;
   int ret;

   if (nbits_left == 0){
			if (!getMoreBytes(in)) return -1;
      b1 = byte_buff[pbytes++];
      nbits_left = 8;
      --navail_bytes;
   }
	 ret = (int)b1 & 0xff;
   ret = (ret >> (8 - nbits_left)) & 0xff;
   while (curr_size > nbits_left){
			if (!getMoreBytes(in)) return -1;
      b1 = byte_buff[pbytes++];
      ret |= ((int)b1 & 0xff) << nbits_left;
      nbits_left += 8;
      --navail_bytes;
   }
   nbits_left -= curr_size;
   ret &= code_mask[curr_size];
	 /*	
	 if (didCodes++ < 10) {
	 		ewe.sys.Vm.debug("Code: "+ret);
			lastCode = ret;
	 }
	 */
   return ret;
   }
int badCodeCount;

int curLine = 0;
int lastOff = 0;
int interlacePass = -1;
int lastInterlaceValue = -8;
int interlaceValues[] = new int[]{8,0,8,4,4,2,2,1};
//===================================================================
int outputGifLine(pngSpecs specs,Image im,int [] buff)
//===================================================================
{
	int lineWidth = specs.width;
	for (int i = 0; i<lineWidth; i++){
		if (gifColors != null){
				//int alpha = 0xff000000;
				if (buff[i] > gifColors.length-1 || buff[i] < 0)
					;//ewe.sys.Vm.debug("Error: "+buff[i]+", "+gifColors.length);
				else{
						if (buff[i] == transparentIndex)
							buff[i] = gifColors[buff[i]];
						else
							buff[i] = gifColors[buff[i]]|0xff000000;
				}
		}else{
			int off = buff[i]*50;
			if (off > lastOff) {
				//ewe.sys.Vm.debug("Off: "+off);
				lastOff = off;
			}
			buff[i] = off << 16 | off << 8 | off;
		}
	}
	int actualLine = curLine;
	if (interlacePass >= 0){
		while(true){
			actualLine = lastInterlaceValue+interlaceValues[interlacePass*2];
			if (actualLine > specs.height-1){
				interlacePass++;
				if (interlacePass == 4) return 0;
				lastInterlaceValue = interlaceValues[interlacePass*2+1]-interlaceValues[interlacePass*2];
				continue;
			}
			lastInterlaceValue = actualLine;
			break;
		}
	}
	im.setPixels(buff,0,0,actualLine,lineWidth,1,0);
	curLine++;
	//ewe.sys.Vm.debug("Output: "+lineWidth);
	return 0;
}
int gifDecode(pngSpecs specs,InputStream s,Image im) throws IOException
   {		
    int sp, bufptr;
   	int [] buf;
    int code, fc, oc, bufcnt;
    int c, size, ret;
		int linewidth = specs.width;
		curLine = badCodeCount = 0;
   /* Initialize for decoding a new image...
    */		
   if ((size = getByte(s)) < 0)
      return(size);
   if (size < 2 || 9 < size)
      return(-1);//BAD_CODE_SIZE);
   init_exp(size);

   /* Initialize in case they forgot to put in a clear code.
    * (This shouldn't happen, but we'll try and decode it anyway...)
    */
   oc = fc = 0;

   /* Allocate space for the decode buffer
    */
		buf = new int[linewidth+1];

   /* Set up the stack pointer and decode buffer pointer
    */
   sp = 0;//stack;
   bufptr = 0;//buf;
   bufcnt = linewidth;

   /* This is the main loop.  For each code we get we pass through the
    * linked list of prefix codes, pushing the corresponding "character" for
    * each code onto the stack.  When the list reaches a single "character"
    * we push that on the stack too, and then start unstacking each
    * character for output in the correct order.  Special handling is
    * included for the clear code, and the whole thing ends when we get
    * an ending code.
    */
   while ((c = getNextCode(s)) != ending)
      {

      /* If we had a file error, return without completing the decode
       */
      if (c < 0)
         {
				 //ewe.sys.Vm.debug("c<0");
         return(0);
         }

      /* If the code is a clear code, reinitialize all necessary items.
       */
      if (c == clear)
         {
         curr_size = size + 1;
         slot = newcodes;
         top_slot = 1 << curr_size;

         /* Continue reading codes until we get a non-clear code
          * (Another unlikely, but possible case...)
          */
         while ((c = getNextCode(s)) == clear)
            ;

         /* If we get an ending code immediately after a clear code
          * (Yet another unlikely case), then break out of the loop.
          */
         if (c == ending)
            break;

         /* Finally, if the code is beyond the range of already set codes,
          * (This one had better NOT happen...  I have no idea what will
          * result from this, but I doubt it will look good...) then set it
          * to color zero.
          */
         if (c >= slot)
            c = 0;

         oc = fc = c;

         /* And let us not forget to put the char into the buffer... And
          * if, on the off chance, we were exactly one pixel from the end
          * of the line, we have to send the buffer to the outputGifLine()
          * routine...
          */
					buf[bufptr++] = c;
         //*bufptr++ = c;
         if (--bufcnt == 0)
            {
            if ((ret = outputGifLine(specs,im, buf)) < 0)
               {
               return(ret);
               }
						if (curLine >= specs.height) return 0;
            bufptr = 0;//buf;
            bufcnt = linewidth;
            }
         }
      else
         {

         /* In this case, it's not a clear code or an ending code, so
          * it must be a code code...  So we can now decode the code into
          * a stack of character codes. (Clear as mud, right?)
          */
         code = c;

         /* Here we go again with one of those off chances...  If, on the
          * off chance, the code we got is beyond the range of those already
          * set up (Another thing which had better NOT happen...) we trick
          * the decoder into thinking it actually got the last code read.
          * (Hmmn... I'm not sure why this works...  But it does...)
          */
         if (code >= slot)
            {
            if (code > slot)
               ++badCodeCount;
            code = oc;
						stack[sp++] = fc; //*sp++ = fc;
            }

         /* Here we scan back along the linked list of prefixes, pushing
          * helpless characters (ie. suffixes) onto the stack as we do so.
          */
         while (code >= newcodes)
            {
            stack[sp++] = suffix[code];
            code = prefix[code];
            }

         /* Push the last character on the stack, and set up the new
          * prefix and suffix, and if the required slot number is greater
          * than that allowed by the current bit size, increase the bit
          * size.  (NOTE - If we are all full, we *don't* save the new
          * suffix and prefix...  I'm not certain if this is correct...
          * it might be more proper to overwrite the last code...
          */
         stack[sp++] = code;
         if (slot < top_slot)
            {
            suffix[slot] = fc = code;
            prefix[slot++] = oc;
            oc = c;
            }
         if (slot >= top_slot)
            if (curr_size < 12)
               {
               top_slot <<= 1;
               ++curr_size;
               } 

         /* Now that we've pushed the decoded string (in reverse order)
          * onto the stack, lets pop it off and put it into our decode
          * buffer...  And when the decode buffer is full, write another
          * line...
          */
         while (sp > 0)//stack)
            {
						buf[bufptr++] = stack[--sp];
            //*bufptr++ = *(--sp);
            if (--bufcnt == 0)
               {
               if ((ret = outputGifLine(specs,im, buf)) < 0)
                  {
                  //free(buf);
                  return(ret);
                  }
							if (curLine >= specs.height) return 0;
               bufptr = 0;
               bufcnt = linewidth;
               }
            }
         }
      }
   ret = 0;
   if (bufcnt != linewidth)
      ret = outputGifLine(specs,im, buf);//, (linewidth - bufcnt));
   //free(buf);
   return(ret);
   }

int [] gifColors;
int transparentIndex = -1;

//-------------------------------------------------------------------
int [] getColorTable(InputStream dataStream,int size,int [] dest,boolean save)
throws IOException
//-------------------------------------------------------------------
{
	size = size*3;
	if (size != 0){
		if (gifBuffer.length < size)
			gifBuffer = new byte[size];
		readFully(dataStream,gifBuffer,0,size);
		if (!save) return new int[0];
		else{
			if (dest == null || dest.length < size/3)
				dest = new int[size/3];
			int c = 0;
			int max = dest.length;
			for (int i = 0; i<max; i++){
				dest[i] = (gifBuffer[c] & 0xff) << 16 | (gifBuffer[c+1] & 0xff) << 8 |(gifBuffer[c+2] & 0xff);
				c += 3;
			}
			return dest;
		}
	}else
		return new int[0];
}

/*
//===================================================================
 boolean skipGifImage(InputStream dataStream) throws IOException
//===================================================================
{
	if (getByte(dataStream) < 0) return false;
	while(true){
		int num = getByte(dataStream);
		if (num < 0) return false;
		if (num == 0) return true;
		readFully(dataStream,gifBuffer,0,num);
	}
}
*/
//-------------------------------------------------------------------
 int getGIFSpecs(int whichImage,pngSpecs specs,InputStream dataStream,Object imageResource)
 throws IOException
//-------------------------------------------------------------------
{
 	return -1;
}

//-------------------------------------------------------------------
//static native boolean decodeGif(pngSpecs specs,BasicStream dataStream,Image image,Rect sourceArea,int [] colorTable, byte [] gifBuffer);
//-------------------------------------------------------------------

//-------------------------------------------------------------------
boolean getGIFSpecs(pngSpecs specs,InputStream dataStream) throws IOException
//-------------------------------------------------------------------
{
	return getGIFSpecs(0,specs,dataStream,null) == 1;	
}
//-------------------------------------------------------------------
boolean toGIFPixels(pngSpecs specs,InputStream dataStream,Image image)
throws IOException
//-------------------------------------------------------------------
{
	return getGIFSpecs(0,specs,dataStream,image) == 1;	
}


//===================================================================
 ImageInfo getImageInfo(InputStream dataStream,int imageIndex,ImageInfo destination,boolean createImage)
throws IllegalArgumentException, IOException
//===================================================================
{
	if (imageIndex < 0) return null;
	if (destination == null) destination = new ImageInfo();
	pngSpecs s = new pngSpecs(this);
	Picture [] got = createImage ? new Picture[1] : null;
	int ret = getGIFSpecs(imageIndex,s,dataStream,got);
	if (ret == 0) throw new IllegalArgumentException();
	else if (ret == -1) return null; //Requested image does not exist.
	destination.width = s.width;
	destination.height = s.height;
	destination.x = s.x;
	destination.y = s.y;
	destination.format = destination.FORMAT_GIF;
	destination.canScale = false;
	destination.size = s.width*s.height*4;
	destination.pauseInMillis = s.pause*10;
	destination.image = got == null ? null : got[0];
	return destination;
}
//===================================================================
 ImageInfo [] getImages(InputStream stream,boolean createImages)
//===================================================================
{
	try{
		RandomStream ras = stream instanceof RandomStream ? (RandomStream)stream : null;
		if (ras == null){
			ByteArray ba = StreamUtils.readAllBytes(null,stream,null);
			ras = new ByteArrayRandomStream(ba,"r"); 
		}
		ras.setPosition(0);
		pngSpecs s = new pngSpecs(this);
		int num = getGIFSpecs(-1,s,ras,null);
		if (num == 0) throw new IllegalArgumentException();
		ImageInfo [] ret = new ImageInfo[num];
		for (int i = 0; i<num; i++){
			ras.setPosition(0L);
			ret[i] = getImageInfo(ras,i,null,true);
			if (ret[i] == null)
				throw new IllegalArgumentException();
		}
		if (ras != stream) ras.close();
		return ret;
	}catch(IOException e){
		e.printStackTrace();
		throw new IllegalArgumentException();
	}
}

//##################################################################
}
//##################################################################

//##################################################################
class pngChunk {
//##################################################################

long position;
String name;
int dataLength;
//CRC32 crc = new CRC32();
byte [] data;
RandomStream source;
RandomStream dataStream;

//===================================================================
 void read(RandomStream ras) throws IOException
//===================================================================
{
	//crc.reset();
	source = ras;
	byte [] got = new byte[8];
	position = ras.getPosition();
	ImageDecoder.readFully(ras,got);
	dataLength = Utils.readInt(got,0,4);
	char [] by = new char[4];
	for (int i = 0; i<4; i++) by[i] = (char)(got[4+i] & 0xff);
	//crc.update(got);
	name = new String(by);
	if (name.equals("IDAT")) return;// true;//return skipOver();
	data = new byte[dataLength];
	if (dataLength != 0){
		ImageDecoder.readFully(ras,data);
		//crc.update(data);
	}
	ImageDecoder.readFully(ras,got,0,4);
	//crc.update(got,0,4);
	return;// true;
}

//===================================================================
 void skipOver() throws IOException
//===================================================================
{
	source.setPosition(position+8+dataLength+4);
}

//===================================================================
 public String toString()
//===================================================================
{
	return name+": "+dataLength+" bytes.";
}

//===================================================================
 pngChunk getNextData() throws IOException
//===================================================================
{
	skipOver();
	pngChunk pc = new pngChunk();
	pc.read(source);
	if (!pc.name.equals("IDAT")) return null;
	return pc;
}

//===================================================================
 InputStream getDataStream()
//===================================================================
{
	if (name.equals("IDAT")) return new pngDataStream(this);
	else return null;
}
//##################################################################
}
//##################################################################

//##################################################################
class pngDataStream extends InputStream{
//##################################################################

pngChunk curChunk;
//===================================================================
 pngDataStream(pngChunk first)
//===================================================================
{
	curChunk = first;
}

 int pos = 0;
byte[] buff = new byte[1];

 public int read() throws IOException
{
	int got = read(buff,0,1);
	if (got == -1) return -1;
	return (int)buff[0] & 0xff;
}

//-------------------------------------------------------------------
 public int read(byte [] dest,int offset,int length)
throws IOException
//-------------------------------------------------------------------
{
	if (curChunk == null) return -1;
	
	while (pos >= curChunk.dataLength){
		curChunk = curChunk.getNextData();
		if (curChunk == null) return -1;
		pos = 0;
	}
	
	if (length > curChunk.dataLength-pos) length = curChunk.dataLength-pos;
	curChunk.source.setPosition(curChunk.position+8+pos);
	ImageDecoder.readFully(curChunk.source,dest,offset,length);
	pos += length;
	return length;
}

//##################################################################
}
//##################################################################

