/*
 * Created on Jan 3, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import java.io.IOException;

import eve.sys.Device;
import eve.sys.ImageData;
import eve.sys.ImageDataInfo;
import eve.util.FormattedDataSource;
import eve.util.IntArray;

/**
 * This class will be removed as its functions can now be done
 * directly in ImageDecoder.
 * @deprecated
 */
//####################################################
public class ScaledImageMaker implements ImageMaker {

	public boolean ignoreAlpha;
	public boolean useRoughScaling;
	public boolean highQualityOnly;
	public boolean keepAspectRatio;
	public boolean scaleDownOnly;
	public int requestedNewWidth;
	public int requestedNewHeight;
	public int newWidth;
	public int newHeight;
	public ImageDataInfo imageInfo;
	/**
	 * This is initially null. If you know the size of the image you can set this
	 * to be a Rect within the source image. If you leave it as null then the entire
	 * image is scaled to the new width and height. 
	 */
	public Rect sourceRect;
	// The buffer for output.
	IntArray buffer;
	boolean noScaling;
	int x, y, width, height;
	int dx, rx, dy, ry;
	int maxScale;
	int need, total;
	int options;
	Rect src;
	Dimension size;
	
	public ScaledImageMaker(){}
	/**
	 * After using this constructor use ImageDecoder.decode(source,this) to decode the
	 * image, and then getImageData() or getPicture() or getPixelBuffer() to get
	 * the decoded image.
	 * @param newWidth the requested new width of the scaled image.
	 * @param newHeight the requested new height of the scaled iamge.
	 * @param keepAspectRatio whether to keep the aspect ratio of the image.
	 */
	public ScaledImageMaker(int newWidth, int newHeight, boolean keepAspectRatio)
	{
		requestedNewHeight = newHeight;
		requestedNewWidth = newWidth;
		this.keepAspectRatio = keepAspectRatio;
	}
	/**
	 * After using this constructor use ImageDecoder.decode(source,this) to decode the
	 * image, and then getImageData() or getPicture() or getPixelBuffer() to get
	 * the decoded image.
	 * @param srcArea the source area within the image that will be decoded.
	 * @param newWidth the requested new width of the scaled image.
	 * @param newHeight the requested new height of the scaled iamge.
	 * @param keepAspectRatio whether to keep the aspect ratio of the sourceArea.
	 */
	public ScaledImageMaker(Rect srcArea, int newWidth, int newHeight, boolean keepAspectRatio)
	{
		requestedNewHeight = newHeight;
		requestedNewWidth = newWidth;
		this.keepAspectRatio = keepAspectRatio;
		sourceRect = new Rect().set(srcArea);
	}
	private static native void scaleLine(int scanLine, int[] pixels, int offset,
			int destX, int destFrequency, int numPixels, int srcFrequency,int[] data, Rect src,Dimension size,int options);
	private static boolean hasNative = true; 
	
	public void setBuffer(IntArray bufferToUse)
	{
		buffer = bufferToUse;
	}
	/**
	 * Only call this if you override createImageFor(). createImageFor()
	 * is provided with the dimensions for the image. You can then 
	 * determine what section of the source image you wish to decode
	 * and what the new width and height will be. Then call this
	 * method with those parameters. 
	 * 
	 * @param srcX The x co-ordinate within the image to start.
	 * @param srcY The y co-ordinate within the image to start.
	 * @param srcWidth The width of the sub-area.
	 * @param srcHeight The height of the sub-area.
	 * @param newWidth The new width of the sub-area which will be the
	 * final width for the image produced.
	 * @param newHeight The new height of the sub-area which will be the
	 * fial height for the image produced.
	 */
	protected void setFor(int srcX, int srcY, int srcWidth, int srcHeight, int newWidth, int newHeight)
	{
		if (src == null) src = new Rect();
		if (size == null) size = new Dimension();
		src.set(srcX,srcY,srcWidth,srcHeight);
		size.set(newWidth,newHeight);
		dx = newWidth/srcWidth; rx = newWidth%srcWidth;
		dy = newHeight/srcHeight; ry = newHeight%srcHeight;
		maxScale = srcWidth*srcHeight;
		total = newWidth*newHeight;
		if (buffer == null) buffer = new IntArray();
		if (noScaling){
			buffer.ensureCapacity(total);
		}else{
			try{
				need = total*(ignoreAlpha ? 3 : 4);
				buffer.ensureCapacity(need);
				if (false){
					// Simulate not enough memory.
					buffer.data = new int[0];
					throw new OutOfMemoryError();
				}
			}catch(OutOfMemoryError e){
				if (highQualityOnly) throw e;
				buffer.ensureCapacity(total);
			}
		}
		options = 0;
		if (ignoreAlpha) options |= 1;
		this.x = srcX;
		this.y = srcY;
		this.width = srcWidth;
		this.height = srcHeight;
		this.newWidth = newWidth;
		this.newHeight = newHeight;
		//System.out.println(src+", "+size+", "+buffer.data.length+", "+need);
	}
	/**
	 * You can override this method and then determine what will be the source area
	 * of the image you want to decode and what the final dimension will be.
	 * Then call setFor() with the parameters for the source area of the
	 * image and the final width and height for the created image.
	 * This is called at the start of decoding - to let the ImageMaker know the parameters
	 * of the image to be created. The minimum this will provide is the width and height
	 * of the image - but other information may not be available. No matter what type of
	 * image is being decoded the pixels are always provided in ARGB int format using
	 * setScanLinePixels.
	 * @param imageInfo information on the image to be decoded.
	 * @param interestedArea this will be modified to provide only
	 * the area this ScaledImageMaker is interested in.
	 * @throws IllegalArgumentException if the ImageMaker decides it cannot create the image.
	 */
	public void createImageFor(ImageDataInfo imageInfo,Rect interestedArea)
			throws IllegalArgumentException {
		//setFor(imageInfo.width/4,imageInfo.height/4,imageInfo.width/2,imageInfo.height/2,150,100);//(int)(imageInfo.width*1),(int)(imageInfo.height*.9));
		this.imageInfo = (ImageDataInfo)imageInfo.getCopy();
		if (requestedNewHeight <= 0) requestedNewHeight = 200;
		if (requestedNewWidth <= 0) requestedNewWidth = 200;
		//
		if (sourceRect == null) sourceRect = new Rect(0,0,imageInfo.width,imageInfo.height);
		Rect r = new Rect(0,0,imageInfo.width,imageInfo.height);
		sourceRect.getIntersection(r,sourceRect);
		//
		int ow = sourceRect.width, oh = sourceRect.height;
		double scx = (double)requestedNewWidth/ow;
		double scy = (double)requestedNewHeight/oh;
		if (keepAspectRatio){
			if (scx > scy) scx = scy;
			else scy = scx;
		}
		if (scaleDownOnly){
			if (scx > 1 || scy > 1) scx = scy = 1;
		}
		noScaling = scx == 1 && scy == 1;
		interestedArea.set(sourceRect);
		setFor(sourceRect.x,sourceRect.y,sourceRect.width,sourceRect.height,(int)(ow*scx),(int)(oh*scy));
	}
	public boolean setScanLinePixels(int scanLine, int[] pixels, int offset,
			int destX, int destFrequency, int numPixels, int srcFrequency) {
	if (scanLine < y || scanLine >= y+height) {
		return true;
	}
	if (pixels == null) throw new NullPointerException();
	if (offset < 0 || offset+(numPixels-1)*srcFrequency >= pixels.length) throw new ArrayIndexOutOfBoundsException();
	//if (destX < 0 || destX+numPixels > width) throw new IndexOutOfBoundsException();
	if (noScaling && srcFrequency == 1 && destFrequency == 1){
		if (destX < x){
			numPixels -= (x-destX);
			offset += (x-destX);
			destX = x;
		}
		int xo = (destX-x);
		int left = newWidth-xo;
		if (left > 0){
			int off = (scanLine-y)*newWidth+xo;
			if (left > numPixels) left = numPixels; 
			System.arraycopy(pixels, offset, buffer.data, off, left);
		}
		return true;
	}
	if (hasNative) try{
		scaleLine(scanLine,pixels,offset,destX,destFrequency,numPixels,srcFrequency,buffer.data,src,size,options);
		return true;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	int srcWidth = width, srcHeight = height;
	int oy = scanLine-this.y;
	int startY = oy*dy, startQy = oy*ry;
	int roff = 0, goff = total, boff = total*2, aoff = total*3;
	int[] data = buffer.data;
	startY += startQy/srcHeight;
	startQy = startQy%srcHeight;
	
	for (int i = 0, x = destX, sx = offset; i<numPixels; i++){
		if (x >= this.x+width) break;
		if (x >= this.x){
			int ox = x-this.x;
			int startX = ox*dx, startQx = ox*rx;
			startX += startQx/srcWidth;
			startQx = startQx%srcWidth;
			int v = pixels[sx];
			int a = (v >> 24) & 0xff;
			int r = (v >> 16) & 0xff;
			int g = (v >> 8) & 0xff;
			int b = (v) & 0xff;
			int sqy = startQy;
			int ph = newHeight;
			for (int yy = startY; ph > 0 && yy < newHeight; yy++){
				int lefty = srcHeight-sqy;
				if (lefty > ph) lefty = ph;
				int off = (int)startX+yy*newWidth;
				int sqx = startQx;
				int pw = newWidth;
				for (int xx = startX; pw > 0 && xx < newWidth; xx++){
					int leftx = srcWidth-sqx;
					if (leftx > pw) leftx = pw;
					int scale = leftx*lefty;
					if (data.length < need){
						// If there was not enough memory for all.
						v = data[off];
						int aa = (v >> 24) & 0xff;
						int rr = (v >> 16) & 0xff;
						int gg = (v >> 8) & 0xff;
						int bb = (v) & 0xff;
						/*
						aa += (a*scale)/maxScale;
						rr += (r*scale)/maxScale;
						gg += (g*scale)/maxScale;
						bb += (b*scale)/maxScale;
						*/
						aa += (a*scale+maxScale-1)/maxScale;
						if (aa > 255) aa = 255;
						rr += (r*scale+maxScale-1)/maxScale;
						if (rr > 255) rr = 255;
						gg += (g*scale+maxScale-1)/maxScale;
						if (gg > 255) gg = 255;
						bb += (b*scale+maxScale-1)/maxScale;
						if (bb > 255) bb = 255;
						if (ignoreAlpha) aa = 255;
						data[off] = ((aa << 24) & 0xff000000)|((rr << 16) & 0xff0000)|((gg << 8) & 0xff00)|((bb) & 0xff);
					}else{
						data[off] += r*scale;
						data[off+goff] += g*scale;
						data[off+boff] += b*scale;
						if (!ignoreAlpha)
							data[off+aoff] += a*scale;
						//System.out.println(data[0]+", "+data[total]+", "+data[total*2]);
					}
					off++;
					pw -= leftx;
					sqx = 0;
				}
				ph -= lefty;
				sqy = 0;
			}
		}
		x += destFrequency;
		sx += srcFrequency;
	}
	return true;
	}
	public void scanLinesComplete(){}
	
	/* (non-Javadoc)
	 * @see eve.sys.ImageMaker#getImageData()
	 */
	public ImageData getImageData() {
		return getPixelBuffer(false);
	}
	/**
	 * Return the Image as a Picture.
	 */
	public Picture getPicture()
	{
		PixelBuffer pb = getPixelBuffer(false);
		return pb.toPicture();
	}
	
	private boolean converted = false;
	public synchronized PixelBuffer getPixelBuffer(boolean copyData)
	{
		int[] data = buffer.data;
		if (!converted){
			if (noScaling){
			}else{
				if (hasNative) try{
					scaleLine(0,null,0,0,0,0,0,buffer.data,src,size,options);
				}catch(Throwable t){
					Device.checkNoNativeMethod(t);
					hasNative = false;
				}
				if (!hasNative){
					int scale = width*height;
					int total = newWidth*newHeight;
					int roff = 0, goff = total, boff = total*2, aoff = total*3;
					if (data.length >= need){
						if (ignoreAlpha)
							for (int i = 0; i<total; i++){
								data[i] =
									(0xff000000)|
									(((int)(data[i]/scale) & 0xff) << 16)|
									(((int)(data[i+goff]/scale) & 0xff) << 8)|
									(((int)(data[i+boff]/scale) & 0xff));
							}
						else
							for (int i = 0; i<total; i++){
								data[i] =
									(((int)(data[i+aoff]/scale) & 0xff) << 24)|
									(((int)(data[i]/scale) & 0xff) << 16)|
									(((int)(data[i+goff]/scale) & 0xff) << 8)|
									(((int)(data[i+boff]/scale) & 0xff));
							}
					}
				}
			}
		}
		converted = true;
		if (copyData){
			int[] nd = new int[total];
			System.arraycopy(data,0,nd,0,total);
			data = nd;
		}
		PixelBuffer ret = new PixelBuffer(newWidth,newHeight,data);
		return ret;
	}
	
	public void free()
	{
		if (buffer != null) buffer.data = new int[0];
	}
	/**
	 * Load a scaled image that is a scaled version of an entire original image.
	 * @param fds the source of the Image.
	 * @param newWidth the requested new width. 
	 * @param newHeight the requested new height;
	 * @param keepAspectRatio true to keep the aspect ratio of the original image.
	 * @param loadAsPixelBuffer true to return a PixelBuffer instead of a Picture.
	 * @return either a PixelBuffer or a Picture which is a scaled version of the
	 * original image.
	 * @throws ImageDecodingException if an error occurs during ImageDecoding.
	 */
	/*
	public static IImage loadScaledImage(FormattedDataSource fds, int newWidth, int newHeight, boolean keepAspectRatio, boolean loadAsPixelBuffer)
	throws ImageDecodingException
	{
		ScaledImageMaker sim = new ScaledImageMaker(newWidth,newHeight,keepAspectRatio);
		sim.ignoreAlpha = true;
		new ImageDecoder().decode(fds,sim);
		return loadAsPixelBuffer ? (IImage)sim.getPixelBuffer(false) : (IImage)sim.getPicture();
	}
	*/
	/**
	 * Load a scaled image that is a scaled version of an entire original image.
	 * @param name the name of the source of the Image.
	 * @param newWidth the requested new width. 
	 * @param newHeight the requested new height;
	 * @param keepAspectRatio true to keep the aspect ratio of the original image.
	 * @param loadAsPixelBuffer true to return a PixelBuffer instead of a Picture.
	 * @return either a PixelBuffer or a Picture which is a scaled version of the
	 * original image.
	 * @throws ImageDecodingException if an error occurs during ImageDecoding.
	 */
	/*
	public static IImage loadScaledImage(String name, int newWidth, int newHeight, boolean keepAspectRatio, boolean loadAsPixelBuffer)
	throws ImageDecodingException
	{
		FormattedDataSource fds = new FormattedDataSource();
		try{
			return loadScaledImage(fds.set(name),newWidth,newHeight,keepAspectRatio,loadAsPixelBuffer);
		}catch(IOException e){
			throw new ImageDecodingException(fds,e);
		}
	}
	*/
	/**
	 * Decode the formatted image using a new ImageDecoder().
	 * @param source the image source.
	 * @param loadAsPixelBuffer if true the image is returned as a PixelBuffer()
	 * otherwise it is returned as a picture.
	 */
	public IImage decode(FormattedDataSource source, boolean loadAsPixelBuffer)
	throws ImageDecodingException
	{
		new ImageDecoder().decode(source,this);
		return loadAsPixelBuffer ? (IImage)getPixelBuffer(false) : (IImage)getPicture();
	}
	/**
	 * Decode the formatted image using a new ImageDecoder().
	 * @param imageName the image source.
	 * @param loadAsPixelBuffer if true the image is returned as a PixelBuffer()
	 * otherwise it is returned as a picture.
	 */
	public IImage decode(String imageName, boolean loadAsPixelBuffer)
	{
		FormattedDataSource fds = new FormattedDataSource();
		try{
			return decode(fds.set(imageName),loadAsPixelBuffer);
		}catch(IOException e){
			e.printStackTrace();
			throw new ImageDecodingException(fds,e);
		}
	}
}

//####################################################
