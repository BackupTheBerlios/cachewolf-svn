package eve.fx;
/**
 * This is thrown during Image decoding if the image type is not supported.
 * @author Michael L Brereton
 *
 */
//##################################################################
public class ImageTypeNotSupportedException extends IllegalArgumentException{
//##################################################################

//===================================================================
public ImageTypeNotSupportedException(int type)
//===================================================================
{
	super("The image type is not supported.");
}

//##################################################################
}
//##################################################################

