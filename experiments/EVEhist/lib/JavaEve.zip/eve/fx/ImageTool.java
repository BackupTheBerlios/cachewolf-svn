package eve.fx;

import eve.sys.Device;
import eve.sys.ImageData;
import eve.sys.SystemResourceException;
import eve.util.IntArray;
import eve.util.Utils;

/**
This class is used for two purposes. It can be used as an Image creator, creating
images of a specific type. And it contains a set of useful static methods for
manipulating images and image data.
**/
//##################################################################
/**
 * @author Michael L Brereton
 *
 */
public class ImageTool{
//##################################################################
/*
//===================================================================
public static int toImageDataType(int imageCreationOptionsOrImageDataType)
//===================================================================
{
	int ic = imageCreationOptionsOrImageDataType;
	if ((ic & ImageData.IS_AN_IMAGE_DATA_TYPE) != 0) return ic;
	if ((ic & Image.ARGB_IMAGE) != Image.ARGB_IMAGE) ic &= ~Image.ALPHA_CHANNEL;
	return 
	(ic &
		(Image.INDEXED_2_IMAGE|Image.INDEXED_4_IMAGE|Image.INDEXED_16_IMAGE|Image.INDEXED_256_IMAGE|
		Image.GRAY_SCALE_2_IMAGE|Image.GRAY_SCALE_4_IMAGE|Image.GRAY_SCALE_16_IMAGE|Image.GRAY_SCALE_256_IMAGE|
		Image.RGB_IMAGE|Image.ARGB_IMAGE)
	)|ImageData.IS_AN_IMAGE_DATA_TYPE;
}
*/
/**
Convert an ImageData.TYPE_XXXX value to an Image.XXX_IMAGE option for
creating an image.
**/
	/*
//===================================================================
public static int imageDataTypeToImageCreationOptions(int imageDataType) throws IllegalArgumentException
//===================================================================
{
	return imageDataType & ~ImageData.IS_AN_IMAGE_DATA_TYPE;
}
*/
	
/**
 * Adjust the newSize value such that scaling oldWidth and oldHeight
 * to newSize.width and newSize.height will
 * adhere to the options specified in createOptions.
 */
public static void adjustScale(Dimension newSize, int oldWidth, int oldHeight, int createOptions)
{
	if ((createOptions & ImageData.CREATE_OPTION_DONT_SCALE_UP) != 0)
		if (oldWidth < newSize.width && oldHeight < newSize.height){
			newSize.set(oldWidth,oldHeight);
			return;
		}
	//
	if ((createOptions & ImageData.CREATE_OPTION_KEEP_ASPECT_RATIO) == 0) 
		return;
	//
	double scx = (double)newSize.width/oldWidth;
	if (oldHeight*scx > newSize.height){
		if (newSize.height == oldHeight) newSize.width = oldWidth;
		else newSize.width = (newSize.height*oldWidth)/oldHeight;
	}else{
		if (newSize.width == oldWidth) newSize.height = oldHeight;
		else newSize.height = (newSize.width*oldHeight)/oldWidth;
	}
}
/**
 * Adjust an image srcArea to fit within the original size of the image
 * and adjust the newSize according to the scale options.
 * @param originalWidth the original image width.
 * @param originalHeight the original image height.
 * @param srcArea the source area within the image.
 * @param newSize the new size of the source area.
 * @param createOptions - any of the ImageData.CREATE_OPTION_XXX values.
 */
public static void adjustAreaAndScale(int originalWidth, int originalHeight, Rect srcArea, Dimension newSize,int createOptions)
{
	Rect r = Rect.getCached(0,0,originalWidth,originalHeight);
	if (srcArea != null) {
		r.getIntersection(srcArea, r);
		srcArea.set(r);
	}
	try{
		if (newSize != null) adjustScale(newSize, r.width, r.height, createOptions);
	}finally{
		r.cache();
	}
}
//===================================================================
public static boolean isAnIndexedImage(int imageDataType)
//===================================================================
{
	int it = imageDataType;
	return (it == ImageData.TYPE_INDEXED_2 ||it == ImageData.TYPE_INDEXED_4||it == ImageData.TYPE_INDEXED_16||it == ImageData.TYPE_INDEXED_256);
}
//===================================================================
public static boolean isAGrayScaleImage(int imageDataType)
//===================================================================
{
	int it = imageDataType;
	return (it == ImageData.TYPE_GRAY_SCALE_2 ||it == ImageData.TYPE_GRAY_SCALE_4||it == ImageData.TYPE_GRAY_SCALE_16||it == ImageData.TYPE_GRAY_SCALE_256);
}
//===================================================================
public static boolean usesColorTable(int imageDataType)
//===================================================================
{
	return isAnIndexedImage(imageDataType);	
}

/** These are the options that will be used for createImage(). 
By default it is zero.
**/
public int createOptions;
/** This is the optional color map that will be used for createImage(). This is
only necessary for the INDEX_xxx_IMAGE types.
**/
public int[] createColorTable;

//===================================================================
public ImageTool()
//===================================================================
{
	this(0,null);
}
//===================================================================
public ImageTool(int createOptions)
//===================================================================
{
	this(createOptions,null);
}
//===================================================================
public ImageTool(int createOptions, int[] createColorTable)
//===================================================================
{
	this.createOptions = createOptions;
	this.createColorTable = createColorTable;
}
/**
This creates an Image using the createOptions and createColorTable fields.
**/
//===================================================================
public Image createImage(int width, int height)
throws SystemResourceException, ImageTypeNotSupportedException, IllegalArgumentException
//===================================================================
{
	if (createColorTable == null && usesColorTable(createOptions)) createColorTable = makeDefaultColorTable(createOptions);
	if (createColorTable == null) return new Image(width,height,createOptions);
	else return new Image(width,height,createOptions,null,0,0,createColorTable);
}
/**
If the specified ImageTool is null, then an image will be
created using the default options, otherwise the specified ImageTool is used to create the image.
**/
//===================================================================
public static Image createImageUsing(ImageTool it, int width, int height, int defaultOptions)
throws SystemResourceException, ImageTypeNotSupportedException, IllegalArgumentException
//===================================================================
{
	if (it == null) return new Image(width,height,defaultOptions);
	else return it.createImage(width,height);
}
/**
Create a new Image that is compatible with the source ImageData, given a specific destination ImageData type.
* @param source The source ImageData.
* @param destinationImageDataType The desired new ImageData type. If this is one of the
* TYPE_INDEXED_XXX values, then the source ImageData must be of the exact same type so that
* the source color table can be transferred to the new image.
* @param newWidth The new width for the image.
* @param newHeight The new height for the image.
* @return The newly created image.
* @exception IllegalArgumentException 
* @exception ewe.sys.SystemResourceException 
* @exception ImageTypeNotSupportedException
*/
//===================================================================
public static Image createCompatibleImage(ImageData source,int destinationImageDataType,int newWidth,int newHeight)
throws IllegalArgumentException, SystemResourceException, ImageTypeNotSupportedException
//===================================================================
{
	int options = destinationImageDataType;
	int[] colorTable = null;
	int sourceImageDataType = source.getImageType();
	if (isAnIndexedImage(destinationImageDataType)){
		if (destinationImageDataType != sourceImageDataType) throw new IllegalArgumentException();
		colorTable = source.getImageColorTable();
	}
	if (colorTable != null)
		return new Image(newWidth,newHeight,options,null,0,0,colorTable);
	else
		return new Image(newWidth,newHeight,options);
}
/**
Create a new Image that is compatible with the source ImageData.
* @param source The source ImageData.
* @param newWidth The new width for the image.
* @param newHeight The new height for the image.
* @return The newly created image.
* @exception IllegalArgumentException 
* @exception ewe.sys.SystemResourceException 
* @exception ImageTypeNotSupportedException
*/
//===================================================================
public static Image createCompatibleImage(ImageData source,int newWidth,int newHeight)
throws IllegalArgumentException, SystemResourceException, ImageTypeNotSupportedException
//===================================================================
{
	return createCompatibleImage(source,source.getImageType(),newWidth,newHeight);	
}
/**
An option for the scale() methods. It indicates that rough scaling should be done.
**/
public static final int SCALE_ROUGH = 0x1;
/**
An option for one of the scale() methods. It indicates that the aspect ration of the
original image should be kept.
**/
public static final int SCALE_KEEP_ASPECT_RATIO = 0x2;
/**
An option for one of the scale() methods. It indicates that the created scaled image
should be made to be of the same type as the source image.
**/
public static final int SCALE_USE_EXACT_TYPE = 0x4;
//-------------------------------------------------------------------
private static int findBestImageDataType(ImageData source,int newWidth,int newHeight,int scaleOptions)
//-------------------------------------------------------------------
{
	boolean scaleDown = source.getImageWidth() > newWidth || source.getImageHeight() > newHeight;
	if ((scaleOptions & SCALE_ROUGH) != 0) scaleDown = false;
	int st = source.getImageType();
	if (scaleDown) 
		if (isAnIndexedImage(st)) st = ImageData.TYPE_RGB;
		else if (isAGrayScaleImage(st)) st = ImageData.TYPE_GRAY_SCALE_256;
	return st;
}
/**
 * Scale an image and return a new image.
 * @param source the source ImageData
 * @param newWidth the new width for the image.
 * @param newHeight the new height for the image.
 * @param scaleOptions any of the SCALE_XXX options.
 * @return a scaled image. The type of the scaled image may not be the same as the 
 * source ImageData <b>if</b> the image was scaled down and smooth scaling was selected.
 * @exception IllegalArgumentException 
 * @exception ewe.sys.SystemResourceException 
 * @exception ImageTypeNotSupportedException 
 */
//===================================================================
public static Image scale(ImageData source,int newWidth,int newHeight,int scaleOptions)
throws IllegalArgumentException, SystemResourceException, ImageTypeNotSupportedException
//===================================================================
{
	return scaleSection(source,newWidth,newHeight,null,scaleOptions);
}
/*
public static void scale(ImageData source, Rect sourceArea, ImageData dest, Rect destArea, int options)
{
	
}
*/
/**
 * Scale a section of an image and return a new image.
 * @param source the source ImageData
 * @param sourceArea the area within the source image to scale.
 * @param newWidth the new width for the entire image.
 * @param newHeight the new height for the entire image.
 * @param scaleOptions any of the SCALE_XXX options.
 * @return a scaled image. The type of the scaled image may not be the same as the 
 * source ImageData <b>if</b> the image was scaled down and smooth scaling was selected.
 * @exception IllegalArgumentException 
 * @exception ewe.sys.SystemResourceException 
 * @exception ImageTypeNotSupportedException 
 */
//===================================================================
public static Image scaleSourceSection(ImageData source,Rect sourceArea,int newWidth,int newHeight,int scaleOptions)
throws IllegalArgumentException, SystemResourceException, ImageTypeNotSupportedException
//===================================================================
{
	if (sourceArea == null) return scaleSection(source,newWidth,newHeight,null,scaleOptions);
	//
	if (newWidth < 0 || newHeight < 0) throw new IllegalArgumentException();
	//
	int width = source.getImageWidth();
	int height = source.getImageHeight();
	//
	if ((scaleOptions & SCALE_KEEP_ASPECT_RATIO) != 0){
		double xscale =(double)newWidth/width;
		double yscale = (double)newHeight/height;
		double scale = Math.min(xscale,yscale);
		newWidth = (int)(scale*width);
		newHeight = (int)(scale*height);
		if (newWidth < 1) newWidth = 1;
		if (newHeight < 1) newHeight = 1;
	}
	//
	double xscale =(double)newWidth/width;
	double yscale = (double)newHeight/height;
	//
	Rect destArea = new Rect((int)(sourceArea.x*xscale),(int)(sourceArea.y*yscale),(int)(sourceArea.width*xscale),(int)(sourceArea.height*yscale));
	if (destArea.width <= 0) destArea.width = 1;
	if (destArea.height <= 0) destArea.height = 1;
	//
	scaleOptions &= ~SCALE_KEEP_ASPECT_RATIO;
	return scaleSection(source,newWidth,newHeight,destArea,scaleOptions);
}

/**
 * Scale an image and return a section of the scaled image.
 * @param source the source ImageData
 * @param newWidth the new width for the image.
 * @param newHeight the new height for the image.
 * @param destinationArea the area in the <b>scaled</b> image to return.
 * @param scaleOptions any of the SCALE_XXX options.
 * @return a scaled image. The type of the scaled image may not be the same as the 
 * source ImageData <b>if</b> the image was scaled down and smooth scaling was selected.
 * @exception IllegalArgumentException 
 * @exception ewe.sys.SystemResourceException 
 * @exception ImageTypeNotSupportedException 
 */
//===================================================================
public static Image scaleSection(ImageData source,int newWidth,int newHeight,Rect destinationArea,int scaleOptions)
throws IllegalArgumentException, SystemResourceException, ImageTypeNotSupportedException
//===================================================================
{
	//
	if (newWidth < 0 || newHeight < 0) throw new IllegalArgumentException();
	//
	int width = source.getImageWidth();
	int height = source.getImageHeight();
	//
	if ((scaleOptions & SCALE_KEEP_ASPECT_RATIO) != 0){
		double xscale =(double)newWidth/width;
		double yscale = (double)newHeight/height;
		double scale = Math.min(xscale,yscale);
		newWidth = (int)(scale*width);
		newHeight = (int)(scale*height);
		if (newWidth < 1) newWidth = 1;
		if (newHeight < 1) newHeight = 1;
	}
	//
	if (destinationArea == null) destinationArea = new Rect(0,0,newWidth,newHeight);	
	//
	// This is the best way to do it.
	//
	Image destination = createCompatibleImage(source,findBestImageDataType(source,newWidth,newHeight,scaleOptions),destinationArea.width,destinationArea.height);
	scaleSection(source,newWidth,newHeight,destination,destinationArea.x,destinationArea.y,scaleOptions);
	return destination;
	//
	// This is an alternate way of doing this.
	// I use this to test the various parts of it.
	//
	/*
	ArrayImageData aid = new ArrayImageData().set(findBestImageDataType(source,newWidth,newHeight,scaleOptions),destinationArea.width,destinationArea.height);
	scaleSection(source,newWidth,newHeight,aid,destinationArea.x,destinationArea.y,scaleOptions);
	Image im = aid.toImage();
	return im;
	*/
}
/**
Scale a source Image so that it fits exactly into the destination Image using smooth
scaling.
* @param source The source ImageData
* @param destination The destination Image.
*/
//===================================================================
public static void scale(ImageData source, ImageData destination)
//===================================================================
{
	scaleSection(source,destination.getImageWidth(),destination.getImageHeight(),destination,0,0,0);
}
/**
Scale a source Image so that it fits exactly into the destination Image.
* @param source The source ImageData
* @param destination The destination Image.
* @param options only SCALE_ROUGH or 0.
*/
//===================================================================
public static void scale(ImageData source, ImageData destination, int options)
//===================================================================
{
	scaleSection(source,destination.getImageWidth(),destination.getImageHeight(),destination,0,0,options);
}
//
// DONT CHANGE THESE VALUES - THEY ARE USED BY THE NATIVE METHOD.
//
static final int S_GRAY = 1, S_MONO = 2, S_COLOR = 3;
//
//private static RGBImageData sourceWrapper, destWrapper;
/**
Return the best ImageData implementation for the specified IImage. If the IImage
implements ImageData, then the image will be returned, otherwise the IImage will
be wrapped in an RGBImageData value and returned.
**/
//===================================================================
public static ImageData toImageData(IImage image)
//===================================================================
{
	if (image instanceof ImageData) 
		return ((ImageData)image);
	/* !Fix - replace this with Drawing?
	else if (image instanceof mImage && !image.usesAlpha() && ((mImage)image).image != null)
 		return ((mImage)image).image;
 		*/
	else return new RGBImageData(image);
}
private static native boolean nativeScaleSection(ImageData source,int newWidth, int newHeight,ImageData dest,int destX, int destY, int options);
private static int []srcRGB = null;
private static int []destRGB = null;
private static int []red = null;
private static int []green = null;
private static int []blue = null;
private static int []alpha = null;
private static int []scales = null;
private Rect sa = new Rect(), da = new Rect();
private static IntArray scaleFull;
private static int[] getBuffer(int[] buffer, int size)
{
	if (buffer == null || buffer.length < size)
		return new int[size];
	return buffer;
}
/**
Scale an image and then place a section of the scaled image into an ImageData object.
The section will be the same width and height as the destination.
* @param source The source image.
* @param newWidth The width of the complete image after scaling.
* @param newHeight The heigh to the complete image after scaling.
* @param dest The destination imageData.
* @param destX The x point within the scaled image that should go into the destination image.
* @param destY The y point within the scaled image that should go into the destination image.
* @param options Options for scaling - so far only the SCALE_ROUGH is supported.
*/
//===================================================================
public synchronized static void scaleSection(ImageData source,int newWidth, int newHeight,ImageData dest,int destX, int destY, int options)
//===================================================================
{
	//Debug.startTiming("Scaling");
	if (hasNative) try{
		nativeScaleSection(source,newWidth,newHeight,dest,destX,destY,options);
		//Debug.endTiming();
		//Vm.debug("did native scale!");
		return;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	int destWidth = dest.getImageWidth();
	int destHeight = dest.getImageHeight();
	int srcWidth = source.getImageWidth();
	int srcHeight = source.getImageHeight();
	srcRGB = getBuffer(srcRGB,srcWidth);
	destRGB = getBuffer(destRGB,destWidth);
	red = getBuffer(red,destWidth);
	blue = getBuffer(blue,destWidth);
	green = getBuffer(green,destWidth);
	alpha = getBuffer(alpha,destWidth);
	scales = getBuffer(scales,destWidth);
	
	boolean useFull = destWidth*destHeight*4 < 1000000;
	int[] destBuffer = null;
	if (useFull) try{
		if (scaleFull == null) scaleFull = new IntArray();
		scaleFull.ensureCapacity(destWidth*destHeight);
		destBuffer = scaleFull.data;
	}catch(OutOfMemoryError e){
		destBuffer = null;
	}

	boolean isRough = (options & SCALE_ROUGH) != 0;
	//
	int curSourceScanLine = -1;
	//
	int dx = srcWidth/newWidth;
	int rx = srcWidth%newWidth;
	//
	int dy = srcHeight/newHeight;
	int ry = srcHeight%newHeight;
	int yq = 0;
	int maxX = destWidth+destX;
	//
	long maxScale = isRough ? 1 : (long)(dx+1)*(long)(dy+1);
	boolean runAverage = (maxScale*255) > 0x7fffffff;
	boolean usesAlpha = source.getImageType() == ImageData.TYPE_ARGB && dest.getImageType() == ImageData.TYPE_ARGB;
	int sy = 0;
	boolean ended = false;
	int sourceWidthNeed = ((destWidth*srcWidth)/newWidth)+2;
	int y; for(y = 0; y<destY+destHeight && y<newHeight; y++){
		int yt = dy;
		yq += ry;
		if (yq >= newHeight) {
			yt++; //How many source lines to use.
			yq -= newHeight;
		}
		if (y >= destY){
			//
			int yyt = yt == 0 ? 1 : yt;
			//
			// yyt now holds the number of source scan lines that will be used for the current
			// destination scan line.
			// 
			// The only way we can be on the same scan line we did last time,
			// is if we only done one scan line.
			//
			boolean dontPrepare = sy == curSourceScanLine;
			if (dontPrepare){
				yyt = 0;
			}else{
				Utils.zeroArrayRegion(red,0,destWidth);
				Utils.zeroArrayRegion(green,0,destWidth);
				Utils.zeroArrayRegion(blue,0,destWidth);
				Utils.zeroArrayRegion(alpha,0,destWidth);
				Utils.zeroArrayRegion(scales,0,destWidth);
				if (isRough) yyt = 1;
			}
			int yy; for(yy = 0; yy<yyt; yy++){
				//
				// Read in the current scan line.
				//
				int srcLine = sy+yy;
				// FROM HERE!
				//
				// Now go across horizontally.
				//
				int xq = 0, di = 0, sx = 0;
				int x; for(x = 0; x<newWidth && x<maxX; x++){
					int xt = dx, xxt;
					xq += rx;
					if (xq >= newWidth){
						xt++;
						xq -= newWidth;
					}
					xxt = xt == 0 ? 1 : xt;
					boolean dt = false;
					if (isRough) xxt = 1;
					if (x >= destX){
						if (di == 0){
							if (sx+sourceWidthNeed > srcWidth)
								sourceWidthNeed = srcWidth-sx;
							if (srcLine != curSourceScanLine)
								source.getPixels(srcRGB,sx,sx,srcLine,sourceWidthNeed,1,srcWidth);
							curSourceScanLine = srcLine;
						}
						int ss = sx;
						int xx; for(xx = 0; xx<xxt; xx++){
							int r, g, b, a = 0;
							int value = srcRGB[ss++];
							a = (value >> 24) & 0xff;
							r = (value >> 16) & 0xff;
							g = (value >> 8) & 0xff;
							b = (value) & 0xff;
							if (usesAlpha && a == 0) r = g = b = 0;
							if (runAverage){
								long didAlready = (yy*xxt)+xx;
								red[di] = (int)((((long)red[di]*didAlready)+r)/(didAlready+1));
								green[di] = (int)((((long)green[di]*didAlready)+g)/(didAlready+1));
								blue[di] = (int)((((long)blue[di]*didAlready)+b)/(didAlready+1));
								alpha[di] = (int)((((long)alpha[di]*didAlready)+a)/(didAlready+1));
							}else{
								red[di] += r;
								green[di] += g;
								blue[di] += b;
								alpha[di] += a;
							}
							dt = false;
						}
						//
						// Done all the horizontal pixels on this line, for this dest pixel.
						// Now move on to the next pixel on this line.
						//
						scales[di] = xxt*yyt;
						di++;
					}
					sx += xt;
				}
			}
			//
			// Have done one destination scan line.
			// So now average it out and write it.
			//
			if (!dontPrepare){
				int i;
				if (!isRough && !runAverage)
					for (i = 0; i<destWidth && i+destX < newWidth; i++){
						red[i] /= scales[i];
						green[i] /= scales[i];
						blue[i] /= scales[i];
						alpha[i] /= scales[i];
					}
				for (i = 0; i<destWidth && i+destX < newWidth; i++){
					destRGB[i] = ((red[i] & 0xff) << 16)|((green[i] & 0xff) << 8)|(blue[i] & 0xff);
					if (usesAlpha) destRGB[i] |= (alpha[i] & 0xff) << 24;
					else destRGB[i] |= 0xff000000;
				}
				//for (int dd = 0; dd<dest.width; dd++) destRGB[dd] = 0xffff00ff;
				//fromARGB(destRGB,dest.width,dest,destScan,dest.scanLineLength,1);
			}
			//destination.setImageScanLines(destScan,y-destY,1,dest.scanLineLength);
			/*
			if (true){
				System.out.println("Y = "+(y-destY));
				for (int i = 0; i<destWidth; i++)
					System.out.print(Integer.toHexString(destRGB[i])+", ");
				System.out.println();
			}
			*/
			if (destBuffer == null)
				dest.setPixels(destRGB,0,0,y-destY,destWidth,1,destWidth);
			else{
				System.arraycopy(destRGB,0,destBuffer,(destWidth)*(y-destY),destWidth);
			}
		}
		sy += yt;
	}
	if (destBuffer != null)
		dest.setPixels(destBuffer,0,0,0,destWidth,destHeight,destWidth);
}
/**
This method "imprints" the data in the small ImageData into the big ImageData
at the top left corner of the big ImageData.
**/
//===================================================================
public static void imprint(ImageData big, ImageData small)
//===================================================================
{
	if (big.getImageScanLineType() != small.getImageScanLineType()) throw new IllegalArgumentException();
	int sh = small.getImageHeight();
	int bh = big.getImageHeight();
	int whichLine = (bh-sh)/2;
	int sw = small.getImageWidth();
	int bw = big.getImageWidth();
	if (sw > bw || sh > bh) throw new IllegalArgumentException();
	int bsll = big.getImageScanLineLength();
	int ssll = small.getImageScanLineLength();
	int size = bsll > ssll ? bsll : ssll;
	Object got = big.getImageScanLineType() == ImageData.SCAN_LINE_INT_ARRAY ?
		(Object)(new int[size]) : (Object)(new byte[size]);
	for (int i = 0; i<sh; i++){
		big.getImageScanLines(i,1,got,0,0);
		small.getImageScanLines(i,1,got,0,0);
		big.setImageScanLines(i,1,got,0,0);
	}
}
private static int[] gs2, gs4, gs16, gs256;
/**
Create and return a Gray scale color table. The returned table should <b>not</b>
be altered.
*/
//===================================================================
public synchronized static int[] getGrayScaleColorTable(int imageDataType)
//===================================================================
{
	int imageType = imageDataType;
	if (gs256 == null) {
		gs256 = new int[256];
		for (int i = 0; i<256; i++)
			gs256[i] = (i << 16)|(i<<8)|(i);
	}
	if (gs16 == null) gs16 = new int[]
		{
			0x000000,0x111111,0x222222,0x333333,
			0x444444,0x555555,0x666666,0x777777,
			0x888888,0x999999,0xaaaaaa,0xbbbbbb,
			0xcccccc,0xdddddd,0xeeeeee,0xffffff
		};
	if (gs4 == null) gs4 = new int[]{0,0x555555,0xaaaaaa,0xffffff};
	if (gs2 == null) gs2 = new int[]{0,0xffffff};
	
	if (imageType == ImageData.TYPE_GRAY_SCALE_256) return gs256;
	else if (imageType == ImageData.TYPE_GRAY_SCALE_16) return gs16;
	else if (imageType == ImageData.TYPE_GRAY_SCALE_4) return gs4;
	else if (imageType == ImageData.TYPE_GRAY_SCALE_2) return gs2;
	else return null;
	
}

private static int[] c256, c16, c4, c2;
/**
Create and return a Color Table for one of the TYPE_INDEXED_XXX types. The returned table may
be modified if necessary.
**/
//===================================================================
public static int[] makeDefaultColorTable(int imageDataType)
//===================================================================
{
	int imageType = imageDataType;
	if (c2 == null) c2 = new int[]{0xff000000,0xffffffff};
	if (c4 == null) c4 = new int[]{0xffffffff,0xffff0000,0xff00ff00,0xff0000ff};
	if (c16 == null) c16 = 
	new int[]{
		0xff000000, 0xff0000ff, 0xff00ff00, 0xff00ffff,
		0xffff0000, 0xffff00ff, 0xffffff00, 0xffffffff,
		0xff800000, 0xff008000,	0xff000080,
		0xfffff0f0, 0xfff0fff0, 0xfff0f0ff,
		0xff808080, 0xa0a0a0};
	
	if (c256 == null){
		c256 = new int[256];
		int idx = 0;
		for (int r = 0; r<6; r++){
			int rm = (r*0x33) << 16;
			for (int g = 0; g<6; g++){
				int gm = (g*0x33) << 8;
				for (int b = 0; b<6; b++)
					c256[idx++] = 0xff000000|rm|gm|(b*0x33);
			}
		}
		for (int b = 6; b < 256 && idx < 256; b += 6){
			if (b % 0x33 == 0) continue;
			c256[idx++] = 0xff000000|(b << 16)|(b << 8)|b;
		}
	}
	if (imageType == ImageData.TYPE_INDEXED_256) return (int[])c256.clone();
	else if (imageType == ImageData.TYPE_INDEXED_16) return (int[])c16.clone();
	else if (imageType == ImageData.TYPE_INDEXED_4) return (int[])c4.clone();
	else if (imageType == ImageData.TYPE_INDEXED_2) return (int[])c2.clone();
	else return null;
}
/**
Create an int[] or byte[] buffer to read/write scan lines from the specified ImageData,
re-using a previous buffer object if possible.
* @param imageData The imageData to read/write scan lines.
* @param numScanLines The number of scan lines to read/write.
* @param oldBuffer An object to be re-used if possible.
* @return An int[] or byte[] big enough to hold the scan line data.
*/
//===================================================================
public static  Object getScanLineBuffer(ImageData imageData, int numScanLines, Object oldBuffer)
//===================================================================
{
	Object buffer = oldBuffer;
	int ty = imageData.getImageScanLineType();
	int len = numScanLines*imageData.getImageScanLineLength();
	if (ty == ImageData.SCAN_LINE_INT_ARRAY){
		if (!(buffer instanceof int[])) buffer = null;
		if (buffer != null && ((int[])buffer).length < len) buffer = null;
		if (buffer == null) buffer = new int[len];
	}else{
		if (!(buffer instanceof byte[])) buffer = null;
		if (buffer != null && ((byte[])buffer).length < len) buffer = null;
		if (buffer == null) buffer = new byte[len];
	}
	return buffer;
}
private static int[] argbMasks = {0x80,0xc0,0,0xf0,0,0,0,0xff};

//-------------------------------------------------------------------
private static boolean hasNative = true;
private static native void argbConvert(boolean isTo,ImageData image,Object imageData, int imageOffset, int[] argbData, int argbOffset, int argbScanLineLength, int numScanLines);
//-------------------------------------------------------------------
private static ImageAdapter imageAdapter;
//===================================================================
/**
 * Get a rectangular section of an ImageData as ARGB pixel information in an int array. If the
 * ImageData is of type IImage, then the getPixels() method is called directly.
 * @param source the source ImageData.
 * @param dest the destination for the pixels. If it is null a new one will be created.
 * @param offset the offset for the first pixel in the destination array.
 * @param x the x location within the source. 
 * @param y the y location within the source.
 * @param width the number of pixels wide.
 * @param height the number of pixels high.
 * @param rowStride the number of int values between successive rows in the 
 * destination array. If this is 0 it will default to the width value.
 * @return the pixels in the destination or new int array.
 */
/*
public synchronized static int[] getPixels(ImageData source,int[] dest,int offset,int x,int y,int width,int height,int rowStride)
//===================================================================
{
	if (source instanceof IImage){
		return ((IImage)source).getPixels(dest,offset,x,y,width,height,rowStride);
	}
	if (imageAdapter == null) imageAdapter = new ImageAdapter();
	imageAdapter.set(source);
	return imageAdapter.getPixels(dest,offset,x,y,width,height,rowStride);
}
*/
/**
 * Set a rectangular section of an ImageData as ARGB pixel information in an int array. If the
 * ImageData is of type IImage, then the getPixels() method is called directly.
 * @param source the source ImageData.
 * @param dest the destination for the pixels. If it is null a new one will be created.
 * @param offset the offset for the first pixel in the destination array.
 * @param x the x location within the source. 
 * @param y the y location within the source.
 * @param width the number of pixels wide.
 * @param height the number of pixels high.
 * @param rowStride the number of int values between successive rows in the 
 * destination array. If this is 0 it will default to the width value.
 * @return true if successful, false if not.
 */
/*
public static boolean setPixels(ImageData dest,int[] source,int offset,int x,int y,int width,int height,int rowStride)
//===================================================================
{
	if (dest instanceof IImage){
		return ((IImage)dest).setPixels(source,offset,x,y,width,height,rowStride);
	}
	if (imageAdapter == null) imageAdapter = new ImageAdapter();
	imageAdapter.set(dest);
	return imageAdapter.setPixels(source,offset,x,y,width,height,rowStride);
}
*/
//===================================================================
//public static void toARGB(int sourceImageDataType, int sourceWidth, int[] sourceColorTable, Object sourceScanLines, int sourceOffset, int sourceScanLineLength, int[] argbData, int argbOffset, int argbScanLineLength, int numScanLines)
public static void toARGB(ImageData sourceInfo, Object sourceScanLines, int sourceOffset, int[] argbData, int argbOffset, int argbScanLineLength, int numScanLines)
//===================================================================
{
	int it = sourceInfo.getImageType();
	int[] sourceColorTable = sourceInfo.getImageColorTable();
	//
	if (isAGrayScaleImage(it)) sourceColorTable = getGrayScaleColorTable(it);
	if (isAnIndexedImage(it) && sourceColorTable == null) throw new NullPointerException();
	//	

	if (hasNative)try{
		//if (sourceScanLines == null || argbData == null) throw new NullPointerException();
		//argbConvert(true, sourceImageDataType,  sourceWidth,  sourceColorTable, sourceScanLines, sourceOffset, sourceScanLineLength, argbData, argbOffset, argbScanLineLength, numScanLines);
		validateRGBLine(argbData,argbOffset,argbScanLineLength,argbScanLineLength,numScanLines);
		validateScanLine(sourceInfo,sourceScanLines,sourceOffset,0,numScanLines,sourceInfo.getImageScanLineLength());
		argbConvert(true,sourceInfo,sourceScanLines,sourceOffset,argbData,argbOffset,argbScanLineLength,numScanLines);
		return;
	}catch(UnsatisfiedLinkError er){
		hasNative = false;
	}catch(SecurityException ex){
		hasNative = false;
	}

	int bpp = 8;
	if (it == ImageData.TYPE_GRAY_SCALE_2 || it == ImageData.TYPE_INDEXED_2) bpp = 1;
	else if (it == ImageData.TYPE_GRAY_SCALE_4 || it == ImageData.TYPE_INDEXED_4) bpp = 2;
	else if (it == ImageData.TYPE_GRAY_SCALE_16 || it == ImageData.TYPE_INDEXED_16) bpp = 4;
	//
	int sourceScanLineLength = sourceInfo.getImageScanLineLength();
	int sourceWidth = sourceInfo.getImageWidth();
	
	if (it != ImageData.TYPE_RGB && it != ImageData.TYPE_ARGB){
		byte[] data = (byte[])sourceScanLines;
		int startMask = argbMasks[bpp-1];
		int startShift = 8-bpp;
		for (int y = 0; y<numScanLines; y++){
			int si = sourceOffset+sourceScanLineLength*y;
			int di = argbOffset+argbScanLineLength*y;
			int mask = startMask;
			int shift = startShift;
			for (int x = 0; x<sourceWidth; x++){
				int index = (((int)data[si]&0xff) & mask)>>shift;
				int color = 0xff000000|sourceColorTable[index];
				argbData[di++] = color;
				mask >>= bpp;
				shift -= bpp;
				if (mask == 0){
					mask = startMask;
					shift = startShift;
					si++;
				}
			}
		}
	}else if (sourceScanLines instanceof byte[]){ 
		//
		// Source IS RGB/ARGB but data is in byte form.
		// The data must be in R,G,B(,A) sequence.
		//
		byte[] data = (byte[])sourceScanLines;
		//System.out.println(sourceScanLineLength+", "+data.length+", "+numScanLines);
		for (int y = 0; y<numScanLines; y++){
			int si = sourceOffset+sourceScanLineLength*y;
			int di = argbOffset+argbScanLineLength*y;
			for (int x = 0; x<sourceWidth; x++){
				int r = (int)data[si++] & 0xff;
				int g = (int)data[si++] & 0xff;
				int b = (int)data[si++] & 0xff;
				int a = it == ImageData.TYPE_ARGB ? data[si++] & 0xff : 0xff;
				argbData[di++] = (a<<24)|(r<<16)|(g<<8)|(b);
			}
		}
	}else if (it == ImageData.TYPE_ARGB){ // Just copy the data straight across.
		int[] data = (int[])sourceScanLines;
		for (int y = 0; y<numScanLines; y++){
			int si = sourceOffset+sourceScanLineLength*y;
			int di = argbOffset+argbScanLineLength*y;
			System.arraycopy(data,si,argbData,di,sourceWidth);
		}
	}else{ // it == ImageData.TYPE_RGB - have to make sure that the alpha channel is 0xff
		int[] data = (int[])sourceScanLines;
		for (int y = 0; y<numScanLines; y++){
			int si = sourceOffset+sourceScanLineLength*y;
			int di = argbOffset+argbScanLineLength*y;
			for (int x = 0; x<sourceWidth; x++){
				argbData[di++] = data[si++] | 0xff000000;
			}
		}
	}
}
//===================================================================
//public static void fromARGB(int[] argbData, int argbOffset, int argbScanLineLength, int destImageDataType, int destWidth, int[]destColorTable, Object destScanLines, int destOffset, int destScanLineLength, int numScanLines)
public static void fromARGB(int[] argbData, int argbOffset, int argbScanLineLength, ImageData destinationInfo, Object destScanLines, int destOffset, int numScanLines) 
//===================================================================
{
	int it = destinationInfo.getImageType();//ImageDataType;
	//
	int[] destColorTable = destinationInfo.getImageColorTable();
	if (isAGrayScaleImage(it)) destColorTable = getGrayScaleColorTable(it);
	if (isAnIndexedImage(it) && destColorTable == null) throw new NullPointerException();
	//	
	if (hasNative) try{
		validateRGBLine(argbData,argbOffset,argbScanLineLength,argbScanLineLength,numScanLines);
		validateScanLine(destinationInfo,destScanLines,destOffset,0,numScanLines,destinationInfo.getImageScanLineLength());
		argbConvert(false,destinationInfo,destScanLines,destOffset,argbData,argbOffset,argbScanLineLength,numScanLines);
		//argbConvert(false, destImageDataType,  destWidth,  destColorTable, destScanLines, destOffset, destScanLineLength, argbData, argbOffset, argbScanLineLength, numScanLines);
		return;
	}catch(UnsatisfiedLinkError er){
		hasNative = false;
	}catch(SecurityException ex){
		hasNative = false;
	}
	
	int destWidth = destinationInfo.getImageWidth();
	int destScanLineLength = destinationInfo.getImageScanLineLength();
	int bpp = 8;
	if (it == ImageData.TYPE_GRAY_SCALE_2 || it == ImageData.TYPE_INDEXED_2) bpp = 1;
	else if (it == ImageData.TYPE_GRAY_SCALE_4 || it == ImageData.TYPE_INDEXED_4) bpp = 2;
	else if (it == ImageData.TYPE_GRAY_SCALE_16 || it == ImageData.TYPE_INDEXED_16) bpp = 4;
	//	
	if (it != ImageData.TYPE_RGB && it != ImageData.TYPE_ARGB){
		byte[] data = (byte[])destScanLines;
		int startMask = argbMasks[bpp-1];
		int startShift = 8-bpp;
		int lastIndex = -1;
		int lastColor = 0;
		for (int y = 0; y<numScanLines; y++){
			int si = destOffset+destScanLineLength*y;
			int di = argbOffset+argbScanLineLength*y;
			int mask = startMask;
			int shift = startShift;
			data[si] = 0;
			for (int x = 0; x<destWidth; x++){
				int color = argbData[di++] & 0xffffff;
				int index = -1;
				if (color == lastColor && lastIndex != -1){
					index = lastIndex;
				}else{
					for (int i = 0; i<destColorTable.length; i++){
						if ((destColorTable[i] & 0xffffff) == color){
							index = i;
							break;
						}
					}
					//
					// Didn't find an exact match, so have to find
					// closest match.
					//
					if (index == -1){
						int diff = 0;
						int r = (color >> 16) & 0xff, g = (color >> 8) & 0xff, b = color & 0xff;
						for (int i = 0; i<destColorTable.length; i++){
							int cc = destColorTable[i];
							int rd = ((cc >> 16) & 0xff)-r; if (rd < 0) rd = -rd;
							int gd = ((cc >> 8) & 0xff)-g; if (gd < 0) gd = -gd;
							int bd = ((cc) & 0xff)-b; if (bd < 0) bd = -bd;
							int t = rd+gd+bd;
							if (t < diff || index == -1){
								index = i;
								diff = t;
							}
						}
					}
					lastColor = color;
					lastIndex = index;
				}
				data[si] &= (byte)~mask;
				data[si] |= (byte)(index << shift);
				mask >>= bpp;
				shift -= bpp;
				if (mask == 0){
					mask = startMask;
					shift = startShift;
					si++;
				}
			}
		}
	}else if (destScanLines instanceof byte[]){ 
		//
		// dest IS RGB/ARGB but data is in byte form.
		// The data must be in R,G,B(,A) sequence.
		//
		byte[] data = (byte[])destScanLines;
		//System.out.println(destScanLineLength+", "+data.length+", "+numScanLines);
		for (int y = 0; y<numScanLines; y++){
			int si = destOffset+destScanLineLength*y;
			int di = argbOffset+argbScanLineLength*y;
			for (int x = 0; x<destWidth; x++){
				int color = argbData[di++];
				data[si++] = (byte)(color >> 16);
				data[si++] = (byte)(color >> 8);
				data[si++] = (byte)(color);
				if (it == ImageData.TYPE_ARGB)
					data[si++] = (byte)(color >> 24);
			}
		}
	}else if (it == ImageData.TYPE_ARGB){ // Just copy the data straight across.
		int[] data = (int[])destScanLines;
		for (int y = 0; y<numScanLines; y++){
			int si = destOffset+destScanLineLength*y;
			int di = argbOffset+argbScanLineLength*y;
			System.arraycopy(argbData,di,data,si,destWidth);
		}
	}else{ // it == ImageData.TYPE_RGB - have to make sure that the alpha channel is 0xff
		int[] data = (int[])destScanLines;
		for (int y = 0; y<numScanLines; y++){
			int si = destOffset+destScanLineLength*y;
			int di = argbOffset+argbScanLineLength*y;
			for (int x = 0; x<destWidth; x++){
				data[si++] = argbData[di++] | 0xff000000;
			}
		}
	}
}
public static void validateRGBLine(int[] rgb, int offset, int width, int rowStride, int numLines)
{
	// This will also throw a null pointer if rgb is null.
	if (offset+(rowStride*(numLines-1))+width > rgb.length || numLines < 0 || offset < 0)
		throw new ArrayIndexOutOfBoundsException();
}
/**
 * This checks that the Object holding scan line data is of the correct type to hold
 * scan lines for the specified source or destination ImageData, and that the array
 * is big enough to hold all the specified scan lines.
 * @param dest the destination or source ImageData.
 * @param data the byte or int array holding scan line data.
 * @param offset the start of the scan line data in the array.
 * @param startScanLines the first scan line to be scanned.
 * @param numScanLines the number of scan lines.
 * @param rowStride the number of array elements for the destination data. If this
 * is zero it is assumed to be the same as the scan line length of the image data.
 * @throws IllegalArgumentException if the scan line is the wrong type.
 * @throws IndexOutOfBoundsException if any of the data is out of bounds for the image
 * or for the destination array.
 */
public static void validateScanLine(ImageData dest, Object data, int offset, int startScanLine, int numScanLines, int rowStride)
throws IllegalArgumentException, IndexOutOfBoundsException
{
	int sll = dest.getImageScanLineLength();
	if (rowStride <= 0) rowStride = sll;
	if (rowStride < sll) throw new ArrayIndexOutOfBoundsException();
	if (numScanLines < 0 || startScanLine < 0 || startScanLine+numScanLines > dest.getImageHeight())
		throw new IndexOutOfBoundsException();
	if (data instanceof byte[]){
		if (dest.getImageScanLineType() != ImageData.SCAN_LINE_BYTE_ARRAY)
			throw new IllegalArgumentException();
		if (offset < 0) throw new ArrayIndexOutOfBoundsException();
		if (offset + numScanLines*rowStride > ((byte[])data).length)
			throw new ArrayIndexOutOfBoundsException();
	}else if (data instanceof int[]){
		if (dest.getImageScanLineType() != ImageData.SCAN_LINE_INT_ARRAY)
			throw new IllegalArgumentException();
		if (offset < 0) throw new ArrayIndexOutOfBoundsException();
		if (offset + numScanLines*rowStride > ((int[])data).length)
			throw new ArrayIndexOutOfBoundsException();
	}else
		throw new IllegalArgumentException();
}
/**
 * Checks the buffer to be used for getPixels() or setPixels() and throws any appropriate
 * exceptions.
 * @param isGetBuffer
 * @param image
 * @param buffer
 * @param offset
 * @param width
 * @param height
 * @return the buffer or new buffer if ok, null if the image is not readable/writeable
 * depending on isGetBuffer. 
 */
public static int[] validatePixelBuffer(boolean isGetBuffer,ImageData image,int[] buffer, int offset, int width, int height,int rowStride)
{
	if (isGetBuffer && !image.isReadableImage()) return null;
	if (!isGetBuffer && !image.isWriteableImage()) return null;
	if (rowStride < width) rowStride = width;
	if (offset < 0) throw new ArrayIndexOutOfBoundsException();
	if (isGetBuffer){
		if (buffer != null && width+(rowStride*(height-1))+offset > buffer.length) buffer = null;
		if (buffer == null) buffer = new int[rowStride*height+offset];
	}else{
		if (rowStride*height+offset > buffer.length) throw new ArrayIndexOutOfBoundsException();
	}
	return buffer;
}
/**
 * This clips the requested area for a getPixels(), setPixels() operation.
 * @param data The ImageData the pixel area is being read from or set.
 * @param requestedArea The requested area. This will be modified as necessary if it must
 * be clipped.
 * @param rgbOffset the offset into the rgbArray.
 * @return the new offset into the rgbArray or -1 if the area is completely out of bounds.
 */
static int clipPixelArea(ImageData data, Rect requestedArea, int rgbArrayOffset, int rgbRowStride)
{
	Rect myArea = new Rect(0,0,data.getImageWidth(),data.getImageHeight());
	int rx = requestedArea.x, ry = requestedArea.y;
	myArea.getIntersection(requestedArea,requestedArea);
	if (requestedArea.width <= 0 || requestedArea.height <= 0) return -1;
	int moved = (requestedArea.y-ry)*rgbRowStride + (requestedArea.x-rx);
	return rgbArrayOffset+moved;
}
private static Rect sr = new Rect(), dr = new Rect();

public static void drawScaled(ImageData d, Graphics g, int x, int y, int width, int height, int options)
{
	synchronized(sr){
		sr.set(0,0,d.getImageWidth(),d.getImageHeight());
		dr.set(x,y,width,height);
		g.drawImageData(d,sr,dr,options);
	}
}
public static Picture changeColor(IImage src, int from, int to)
{
	PixelBuffer pb = new PixelBuffer(src);
	int w = src.getWidth();
	int h = src.getHeight();
	int total = w*h;
	int[] p = pb.getBuffer();
	for (int i = 0; i<total; i++)
		if (p[i] == from) p[i] = to;
	Picture ret = pb.toPicture();
	pb.free();
	return ret;
}
/**
 * Create a picture that is an ImageData drawn over a background. 
 * @param d
 * @param background
 * @return a new Picture.
 */
public static Picture fillBackground(Drawable d, Color background)
{
	Image im = new Image(d.getWidth(),d.getHeight());
	Graphics g = new Graphics(im);
	g.setColor(background);
	g.fillRect(0,0,d.getWidth(),d.getHeight());
	d.draw(g, 0, 0, 0);
	g.free();
	Picture ret = im.toPicture();
	im.free();
	return ret;
}
//##################################################################
}
//##################################################################

