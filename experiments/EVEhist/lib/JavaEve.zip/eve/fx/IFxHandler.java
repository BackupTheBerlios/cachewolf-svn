/*
 * Created on Aug 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.Handle;
import eve.sys.IConsole;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface IFxHandler {

	public Font getDefaultFont();
	public ISurface getDefaultSurface();
	public String getDefaultWindowTitle();
	public IConsole getConsole(String title, int options, int maxLines);
	/**
	 * Yield to user interface events if possible.
	 * @param maxTime the maximum time to yield for.
	 * @return true if it does know how to yield to events, false
	 * if it cannot which means this call has no effect.
	 */
	public boolean yieldToEvents(int maxTime);
	/**
	 * Create and run a non-native printer dialog if available.
	 * @param PrinterProperties this should be a PrinterProperties object.
	 * @return the Handle indicating the progress of the printer dialog.
	 */
	public Handle printerDialog(Object PrinterProperties);
}
//####################################################
