/*
 * Created on Dec 7, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import java.awt.image.ImageObserver;

/**
 * @author Michael L Brereton
 *
 */
//##################################################################
class ImagePreparer{
//##################################################################

java.awt.Image image;
boolean succeeded = false;
boolean infoOnly;

//===================================================================
public boolean prepare(java.awt.Image image,boolean infoOnly)
//===================================================================
{
	this.image = image;
	this.infoOnly = infoOnly;
	Thread t = new Thread(new imageObserver());
	t.start();
	try{
		t.join();
	}catch(Exception e){
	}
	return succeeded;
}
//===================================================================
public boolean prepare(java.awt.Image image)
//===================================================================
{
	return prepare(image,false);
}


	//##################################################################
	private class imageObserver implements Runnable,ImageObserver{
	//##################################################################
	int soFar = 0;
	//===================================================================
	public synchronized void run()
	//===================================================================
	{
		//sleep(2000);
		
		if (java.awt.Toolkit.getDefaultToolkit().prepareImage(image,-1,-1,this)){
			succeeded = true;
			return;
		}
		try{
			wait();
		}catch(Exception e){
		}
		if (!didAll) try{
			wait(1000);
		}catch(Exception e){
		}
	}
	//int lines = 0;
	boolean didAll = false;
	
	//-------------------------------------------------------------------
	boolean success()
	//-------------------------------------------------------------------
	{
		didAll = true;
		succeeded = true;
		notify();
		return false;
	}
//==============================================================
	public synchronized boolean 
	imageUpdate(java.awt.Image im,int flags,int x,int y,int width,int height)
//==============================================================
{
	//System.out.println("II: "+flags);
	soFar |= flags;
	if (infoOnly && ((soFar & (ImageObserver.WIDTH|ImageObserver.HEIGHT)) == (ImageObserver.WIDTH|ImageObserver.HEIGHT))) {
		return success();
	}
	if ((flags & ImageObserver.ALLBITS) != 0) {
		return success();
	}
	/*
	 * This was wrong!
	if ((flags & ImageObserver.SOMEBITS) != 0) {
		//lines += height;
		if (lines >= im.getHeight(null)) {
			succeeded = true;
			notify();
		}
	}
	*/
	if ((flags & ImageObserver.ERROR) != 0) {
		succeeded = false;
		notify();
		return false;
	}
	return(true);
}
	//##################################################################
	}
	//##################################################################



//##################################################################
}
//##################################################################

