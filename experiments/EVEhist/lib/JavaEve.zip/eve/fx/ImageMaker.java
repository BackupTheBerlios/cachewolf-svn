/*
 * Created on Jan 2, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.ImageData;
import eve.sys.ImageDataInfo;

/**
 * An ImageMaker is used to decode an Image stored in a decodeable image
 * format (JPEG, BMP, PNG, GIF). Instead of the entire image being decoded
 * the individual scan lines are sent to this class as they are decoded.
 * Note that the scan lines do not always come in incremental order, and
 * they are not always presented as a complete line or as a set of 
 * contiguous pixels. The scan lines are presented as they are decoded
 * so as to minimize memory usage. It is up to the ImageMaker to keep
 * the pixels it is interested in and to place them in the correct locations
 * within its own internal buffer.<p>
 * An ImageDecoder Object is used to decode an Image via an ImageMaker
 * using the 
 * @author Michael L Brereton
 *
 */
//####################################################
public interface ImageMaker {

/**
 * This is called at the start of decoding - to let the ImageMaker know the parameters
 * of the image to be created. The minimum this will provide is the width and height
 * of the image - but other information may not be available. No matter what type of
 * image is being decoded the pixels are always provided in ARGB int format using
 * setScanLinePixels.
 * @param imageInfo information on the image to be decoded.
 * @param interestedArea when the method is called this is set to be the
 * full area of the image (0,0,imageWidth,imageHeight). This method
 * can alter this Rect to be a sub-area within the image. In that case
 * the object that is providing pixel data will know that it need
 * not provide pixel data outside that area. However you should not 
 * assume that this will strictly be adhered to. It is possible
 * that all pixels for the entire image may still be provided to
 * setScanLinePixels().
 * 
 * @throws IllegalArgumentException if the ImageMaker decides it cannot create the image.
 */
public void createImageFor(ImageDataInfo imageInfo, Rect interestedArea) throws IllegalArgumentException;
/**
 * This is used when decoding images. 
 * For certain interlaced images the pixels on a scan line are not
 * available as a single sequence of pixels, but rather as pixels that
 * are spaced at fixed distances apart on the scan line.<p>
 * Also scan lines may be presented in a random sequence and multiple
 * times.
 * @param scanLine the scan line index relative to the area in the image the image maker
 * is interested in.
 * @param pixels an array containing the scan line ARGB pixel values.
 * @param offset the start of the pixel within the pixels array.
 * @param destX the x location where the first pixel should be placed.
 * @param destFrequency the distance between the pixels being provided. If this
 * value is 1, then the pixels are actually right next to each other. A value of
 * 2 means that every other pixel is being done.
 * @param numPixels the number of pixels being set. 
 * @param srcFrequency the distance between the pixels in the <b>pixels</b> array.
 * This will usually be 1 but may be any other distance.
 * @return true if the pixels were successfully set.
 */
public boolean setScanLinePixels(int scanLine, int[] pixels, int offset,int destX, int destFrequency, int numPixels, int srcFrequency);
/**
 * This is called once all scan lines are complete.
 */
public void scanLinesComplete();
/**
 * After decoding is done this is used to retrieve the fully decoded image.
 * The ImageDecoder does not call this method.
 * @return the fully decoded image.
 */
public ImageData getImageData(); 
}
//####################################################
