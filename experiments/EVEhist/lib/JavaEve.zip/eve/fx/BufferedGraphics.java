package eve.fx;

import eve.sys.Cache;
import eve.sys.SystemResourceException;
import eve.sys.Vm;

/**
* A BufferedGraphics object provides a temporary off-screen Image for a Control
* to draw on, before being transferred to the on-screen Graphics.<p>
* This facility is necessary because some platforms (e.g. Qtopia on the Sharp Zaurus)
* do not support reading bits from a Window surface. This makes certain drawing operations
* impossible directly on this surface. e.g. XOR'ing of images and the drawing of transparent
* images. However all platforms support reading bits from an Image and therefore
* these operations are possible using images.<p>
* You will generally create a BufferedGraphics in the doPaint() method of your control. 
* You then call getGraphics() to get the Graphics object that you should use for your drawing
* and when you are done 
* call release() on the BufferedGraphics to transfer what has been drawn to the original Graphics.<p>
* Note that you can construct the BufferedGraphics conditionally, which means that if the original
* Graphics was already drawing on an Image, that same graphics will be used and no temporary image
* will be created. In fact, when created conditionally, the canCopyFrom() method is called on the original
* Graphics, and if it returns true, then that original Graphics is used.<p>
**/
//##################################################################
public class BufferedGraphics{
//##################################################################

public static final int OPTION_DONT_COPY_FROM_ORIGINAL = 0x1;
public static final int OPTION_DONT_ACCEPT_UNBUFFERED = 0x2;
public static final int OPTION_DONT_BUFFER = 0x4;
public static final int OPTION_ALWAYS_BUFFER = 0x8;
public static final int OPTION_EXACT_SIZE = 0x10;

private Graphics original;
private ISurface surface;
private int cx, cy, cw, ch;
private int offx, offy;
private Graphics useGraphics;
private Image image;
private PixelBuffer layeredImage;
private Graphics imageGraphics;
//private Rect area;
private int targetX, targetY, targetWidth, targetHeight;
private Rect oc = new Rect(); 
private Rect restoreClip;
private boolean translated;
/**
 * Set this true if you want the BufferedGraphics to free the original Graphics
 * when done.
 */
public boolean freeOriginal;
/**
 * Set this true if you want the BufferedGraphics to not free itself on completion.
 */
public boolean dontFree;
/**
 * Set this true if you want the BufferedGraphics to cache itself on flush.
 */
public boolean cacheWhenDone;

protected Image createNewImage(int width, int height) throws SystemResourceException, OutOfMemoryError
{
	if (surface != null) return surface.getCompatibleImage(width,height);
	else return new Image(width,height);
}
/*
public Graphics setFor(Graphics original, int x, int y, int width, int height, int options)
{
	return setFor(null,original,x,y,width,height,options);
}
public Graphics setFor(ISurface surface, int x, int y, int width, int height, int options)
{
	return setFor(surface,null,x,y,width,height,options);
}
*/

public Graphics setFor(ISurface surf, int xoffset, int yoffset, int targetX, int targetY, int width, int height, int options)
{
	return setFor(surf,xoffset,yoffset,null,targetX,targetY,width,height,options);
}
public Graphics setFor(Graphics g, int targetX, int targetY, int width, int height, int options)
{
	return setFor(null,0,0,g,targetX,targetY,width,height,options);
}
//private static int fromCache = 0;

//synchronized
public static BufferedGraphics getCached()
{
//	fromCache++;
	return (BufferedGraphics)Cache.get(BufferedGraphics.class);
}
public void cache()
{
	//synchronized(BufferedGraphics.class){
		Cache.put(this);
		//System.out.println("Cached: "+(--fromCache));
	//}
}
/**
 * 
 * @param surf This is optional, it can be null if original is not null. 
 * @param original if this is null then surf must not be null.
 * @param x the x co-ordinate within the original or surface for drawing.
 * @param y the y co-ordinate within the original or surface for drawing.
 * @param width the width of the area within the original or surface for drawing.
 * @param height the height of the area within the original or surface for drawing.
 * @param options
 * @return
 */
Graphics setFor(ISurface surf, int xoffset, int yoffset, Graphics original, int x, int y, int width, int height, int options)
{
	boolean hasOriginal = original != null;
	this.original = original;
	this.surface = original == null ? surf : null;
	if (original == null && surface == null) throw new NullPointerException();
	if (surf != null){
		this.offx = xoffset;
		this.offy = yoffset;
	}
	translated = false;
	restoreClip = !hasOriginal ? null : original.reduceClip(x,y,width,height,oc);
	targetX = x; targetY = y;
	targetWidth = width; targetHeight = height;
	useGraphics = null;
	//options |= OPTION_EXACT_SIZE;
	if (((options & OPTION_DONT_BUFFER) == 0) || !hasOriginal)
		if (!hasOriginal || ((options & OPTION_ALWAYS_BUFFER) != 0) || (original.getSurfaceType() != ISurface.IMAGE_SURFACE)){
			int minWidth = width, minHeight = height;
			if (((options & OPTION_EXACT_SIZE) != 0) && (image != null))
				if (image.getWidth() != width || image.getHeight() != height)
					free();
			if (image != null && (image.getWidth() < width || image.getHeight() < height)){
				if (width < image.getWidth()) minWidth = image.getWidth();
				if (height < image.getHeight()) minHeight = image.getHeight();
				free();
			}
			if (image == null){
				try{
					try{
						image = createNewImage(minWidth,minHeight);
						imageGraphics = new Graphics(image);
					}catch(OutOfMemoryError e){
						throw (SystemResourceException)Vm.setCause(new SystemResourceException("Out of memory"),e);
					}
				}catch(SystemResourceException e){
					image = null;
					imageGraphics = null;
				}
			}
			if (imageGraphics != null){
				imageGraphics.reset();
				imageGraphics.translate(-x,-y);
			}
			useGraphics = imageGraphics;
		}
	if (useGraphics != null){
		useGraphics.setColor(0,255,0);
		useGraphics.fillRect(targetX,targetY,width,height);
		if ((options & OPTION_DONT_COPY_FROM_ORIGINAL) == 0)
			copyFromOriginal();
	}
	return useGraphics == null ? original : useGraphics;
}
public void clipSurface(int x, int y, int width, int height)
{
	cx = x;
	cy = y;
	cw = width;
	ch = height;
}
/**
 * Create an empty BufferedGraphics. Call setFor() to set it for a graphics
 * context.
 */
public BufferedGraphics(){}

/**
 * This returns true if the BufferedGraphics is buffering directly onto
 * an ISurface instead of to another Graphics. 
 * @return
 */
public boolean bufferedToSurface()
{
	return surface != null;
}
/**
 * Create a new BufferedGraphics from the original.
 * @param original The original graphics.
 * @param drawingAreaNeeded A non-null rectangle specifying the area needed.
 * @param unconditionally If this is true then a temporary image will always be created. If it
	is false, then a temporary image will only be created if original.canCopyFrom() returns false.
 */
//===================================================================
public BufferedGraphics(Graphics original,Rect drawingAreaNeeded,boolean unconditionally)
//===================================================================
{
	setFor(null,0,0,original,drawingAreaNeeded.x,drawingAreaNeeded.y,drawingAreaNeeded.width,drawingAreaNeeded.height,OPTION_ALWAYS_BUFFER);
}
/**
 * Create a new BufferedGraphics from the original if the original does not support copying.
 * @param original The original graphics.
 * @param drawingAreaNeeded A non-null rectangle specifying the area needed.
*/
//===================================================================
public BufferedGraphics(Graphics original,Rect drawingAreaNeeded)
//===================================================================
{
	this(original,drawingAreaNeeded,false);
}
public Graphics getOriginal()
{
	return original;
}
/**
 * This translates the graphics so that the co-ordinates (0,0)
 * now refer to targetX and targetY.
 */
public void translateToZero()
{
	if (translated) return;
	getGraphics().translate(targetX,targetY);
	translated = true;
}
/**
 * Returns if the Graphics returned by getGraphics() is drawing to an Image. 
 */
public boolean drawingToImage()
{
	Graphics g = useGraphics == null ? original : useGraphics;
	return g.getSurfaceType() == ISurface.IMAGE_SURFACE;
}
/**
 * Returns if the Graphics returned by getGraphics() can be copied from. 
 */
public boolean canCopyFrom()
{
	Graphics g = useGraphics == null ? original : useGraphics;
	return g.canCopyFrom();
}
public boolean canCopyFromOriginal()
{
	return original != null && original.canCopyFrom();
}
/**
 * This attempts to copy the data from the original graphics. 
 * @return true
 * if the Graphics is unbuffered or if copying is possible from the original.
 */
public boolean copyFromOriginal()
{
	if (useGraphics == null) return true;
	if (original == null || !original.canCopyFrom()) return false;
	useGraphics.copyRect(original,targetX,targetY,
			//image.getWidth(),image.getHeight(),
			targetWidth, targetHeight,
			targetX,targetY);
	return true;
}
/**
 * Create a new BufferedGraphics from the original if the original does not support copying.
 * @param original The original graphics.
 * @param control The control that the original graphics was set up for. This will use a drawing
	area equal to the size of the control.
 */
/*
//===================================================================
public BufferedGraphics(Graphics original,ewe.ui.Control control)
//===================================================================
{
	this(original,control.getDim(new Rect()),false);
}
*/
/**
 * Get the graphics that you should use to draw on. This <b>may</b> be the same as the original Graphics
 * object, if that original Graphics already supported copying.
 * @return The Graphics that you should use to draw on.
 */
//===================================================================
public Graphics getGraphics()
//===================================================================
{
	return useGraphics == null ? original : useGraphics;
}
/**
 * Copy the data already drawn on this surface, to the destination surface. You can continue
 * using the buffered graphics after if you need to. This does not call flush on the original graphics.
 * If you want to flush() the original Graphics as well, then you can call:
 * <pre>
 * 	 bufferedGraphics.flushOriginal();
 * <pre>
 */
//===================================================================
public void flush()
//===================================================================
{
	if (useGraphics != null){
		//new Exception().printStackTrace();
		if (layeredImage != null){
			layeredImage.putDrawingBuffer(PixelBuffer.PUT_SET);
			Graphics g = new Graphics(image);
			layeredImage.draw(g,0,0,0);
			g.free();
		}
		if (original != null)
			original.drawImage(image,targetX,targetY);
		else
			surface.drawImage(image,cx,cy,cw,ch,targetX+offx,targetY+offy,targetWidth,targetHeight);
	}
}
public void createAlphaLayer(double layerAlpha)
{
	layeredImage = new PixelBuffer(targetWidth,targetHeight);
	useGraphics = layeredImage.getDrawingBuffer(null,null,layerAlpha);
	useGraphics.translate(-targetX,-targetY);
}
public void flushOriginal()
{
	if (original != null) original.flush(); 
}
/**
 * Copy the drawn image to the original graphics and free all temporary resources. You
	should not attempt to use this after calling this method.
 */
//===================================================================
public void release()
//===================================================================
{
	flush();
	cancel();
}
protected void free()
{
	if (image != null) image.free();
	if (imageGraphics != null) imageGraphics.free();
	imageGraphics = null;
	image = null;
	useGraphics = null;
}
/**
 * Cancel drawing, free resources and do not update the original graphics.
 */
//===================================================================
public void cancel()
//===================================================================
{
	if (translated){
		translated = false;
		getGraphics().translate(-targetX,-targetY);
	}
	if (original != null){
		original.restoreClip(restoreClip);
		if (freeOriginal){
			original.flush();
			original.free();
		}
	}
	if (layeredImage != null){
		layeredImage.free();
		layeredImage = null;
	}
	if (!dontFree && !cacheWhenDone) free();
	Graphics ret = original;
	if (cacheWhenDone) cache();
}

public void cached()
{
	if (image != null && (image.getWidth()*image.getHeight() > ImageBuffer.maxCachedSize)){
		free();
	}
		
}
public void finalize()
{
	free();
}

//##################################################################
}
//##################################################################

