package eve.fx.points;

import eve.data.DataObject;

/**
* A PageFormat class is used to describe the layout of a page that is drawn to
* using a PrintGraphics. This is mainly used during printing but may also be used
* during a print preview, where an image substitutes for an actual printer page.
**/
//##################################################################
public class PageFormat extends DataObject{
//##################################################################
//
// Don't move the next 11 fields. They are used by the native method.
//
public double fullPageWidth = 8.5*72;
public double fullPageHeight = 11.0*72;
public double imageableWidth = 6.5*72;
public double imageableHeight = 9*72;
private double pointsPerInch = 72;
public double xScreenScale = 1.0;
public double yScreenScale = 1.0;
public double imageableX = 72;
public double imageableY = 72;
/** This is the output X-DPI and it may not be know, and if so, it will be 0. **/
public double xDPI = 0;
/** This is the output Y-DPI and it may not be know, and if so, it will be 0. **/
public double yDPI = 0;

public double requestedX = -1, requestedY = -1, requestedWidth = -1, requestedHeight = -1;
public double requestedFullWidth = -1, requestedFullHeight = -1;
public double requestedXDpi = 0.0, requestedYDpi = 0.0;

public static final int TRANSFORM_ROTATE_90 = AffineTransform.TRANSFORM_ROTATE_90;
public static final int TRANSFORM_ROTATE_180 = AffineTransform.TRANSFORM_ROTATE_180;
public static final int TRANSFORM_ROTATE_270 = AffineTransform.TRANSFORM_ROTATE_270;
public static final int TRANSFORM_NONE = AffineTransform.TRANSFORM_NONE;
public static final int TRANSFORM_ROTATE_NOT_RIGHT = AffineTransform.TRANSFORM_ROTATE_NOT_RIGHT;

private int transform = TRANSFORM_NONE;

public AffineTransform getTransform()
{
	AffineTransform at = new AffineTransform();
	try {
		at.rotateRightAngle(transform);
		return at;
	}catch(Exception e){
		return at;
	}
}
public int getTransformation()
{
	return transform;
}
public void matchTransform(PageFormat other)
{
	transform(other.transform);
}
/**
 * Apply a transform to the page thereby altering its layout.
 * @param transformation one of the TRANSFORM_XXX values.
 */
public void transform(int transformation)
{
	this.transform = transformation;
	double t;
	switch(transformation){
		case TRANSFORM_ROTATE_90:
			t = imageableX;
			imageableX = imageableY;
			imageableY = fullPageWidth-imageableWidth-t;
			t = fullPageWidth; fullPageWidth = fullPageHeight; fullPageHeight = t;
			t = imageableWidth; imageableWidth = imageableHeight; imageableHeight = t;
			t = xDPI; xDPI = yDPI; yDPI = xDPI;
			break;
		case TRANSFORM_ROTATE_270:
			t = imageableX;
			imageableX = fullPageHeight-imageableHeight-imageableY;
			imageableY = t;
			t = fullPageWidth; fullPageWidth = fullPageHeight; fullPageHeight = t;
			t = imageableWidth; imageableWidth = imageableHeight; imageableHeight = t;
			t = xDPI; xDPI = yDPI; yDPI = xDPI;
			break;
		case TRANSFORM_ROTATE_180:
			imageableX = fullPageWidth-imageableWidth-imageableX;
			imageableY = fullPageHeight-imageableHeight-imageableY;
			break;
	}
}
/**
* This returns the full width of the page in Points (printer dots - 72 per inch).
* This value will not be valid until printing begins.
**/
//===================================================================
//public double getWidth() {return fullPageWidth;}
//===================================================================
/**
* This returns the full height of the page in Points (printer dots - 72 per inch).
* This value will not be valid until printing begins.
**/
//===================================================================
//public double getHeight() {return fullPageHeight;}
//===================================================================
/**
* This returns the width of the printable area of the page in Points (printer dots - 72 per inch).
* This value will not be valid until printing begins.
* <p>
* Note that the graphics which is passed to the Printable object during printing
* will have its origin set to the 0,0 position of the printable area of the
* page.
**/
//===================================================================
//public double getImageableWidth() {return imageableWidth;}
//===================================================================
/**
* This returns the height of the printable area of the page in Points (printer dots - 72 per inch).
* This value will not be valid until printing begins.
* <p>
* Note that the graphics which is passed to the Printable object during printing
* will have its origin set to the 0,0 position of the printable area of the
* page.
**/
//===================================================================
//public double getImageableHeight() {return imageableHeight;}
//===================================================================
/**
* This is currently always 72. However, using Transforms on the PrinterJob Graphics, you can
* draw an Image of arbitrary size and resolution.
**/
//===================================================================
//public double getPointsPerInch(){return pointsPerInch;}
//===================================================================
/**
* This is the ratio of screen dpi to printer dpi horizontally. Multiply this by
* pixel values in user space to calculate the number of pixels in printer space
* equal to the same size in user space.
**/
//public float getXScreenScale() {return xScreenScale;}
/**
* This is the ratio of screen dpi to printer dpi vertically. Multiply this by
* pixel values in user space to calculate the number of pixels in printer space
* equal to the same size in user space.
**/
//public float getYScreenScale() {return yScreenScale;}
/**
* This returns the number of Points (printer dots - 72 per inch) 
* horizontally between the left edge of the paper and
* the start of the printable area of the paper.
**/
//===================================================================
//public double getImageableX(){return imageableX;}
//===================================================================
/**
* This returns the number of Points (printer dots - 72 per inch) 
* vertically between the top edge of the paper and
* the start of the printable area of the paper.
**/
//===================================================================
//public double getImageableY(){return imageableY;}
//===================================================================

/**
This returns the actual DPI of the output device horizontally if it is known. If it is not
known this will return 0;
**/
//===================================================================
//public double getXDPI(){return xDPI;}
//===================================================================
/**
This returns the actual DPI of the output device vertically if it is known. If it is not
known this will return 0;
**/
//===================================================================
//public double getYDPI(){return yDPI;}
//===================================================================
/**
This requests that the output DPI be set to the specified values. Note that this is just
a request and the device may not provide the requested DPIs. The getXDPI() and getYDPI() values
will return the actual DPIs (if available) at print time. They may not be available immediately
after this call.
**/
//===================================================================
public void requestDPI(double xDPI, double yDPI)
//===================================================================
{
	requestedXDpi = xDPI;
	requestedYDpi = yDPI;
}
/**
* This will scale a pixel value from user pixels into print pixels so that the value will
* appear roughly the same size. e.g. if 100 pixels on the screen equals 1 inch, this will
* convert 100 to the appropriate number of pixels on the printer which also equals 1 inch.
* This is not 100% reliable however since it depends on the underlying OS providing accurate
* screen DPIs which it does not always do.
**/
//===================================================================
//public double xScale(double value) {return (double)(value*xScreenScale);}
//===================================================================
/**
* This will scale a pixel value from user pixels into print pixels so that the value will
* appear roughly the same size. e.g. if 100 pixels on the screen equals 1 inch, this will
* convert 100 to the appropriate number of pixels on the printer which also equals 1 inch.
* This is not 100% reliable however since it depends on the underlying OS providing accurate
* screen DPIs which it does not always do.
**/
//===================================================================
//public double yScale(double value) {return (double)(value*yScreenScale);}
//===================================================================
/**
* This requests that the imageable area of the paper to be set to the specified values, which
* are given in units of Points (printer dots - 1/72 of an inch). Therefore this can be used regardless of the eventual
* printer resolution.
* @param x the x offset of the imageable area.
* @param y the y offset of the imageable area.
* @param width the width of the imageable area.
* @param height the height of the imageable area.
*/
//===================================================================
public void requestImageableArea(double x, double y, double width, double height)
//===================================================================
{
	requestedX = x;
	requestedY = y;
	requestedWidth = width;
	requestedHeight = height;
}
/**
 * This requests that the size of the paper be set to specified values, which
* are given in units of Points (printer dots - 1/72 of an inch). Therefore this can be used regardless of the eventual
* printer resolution.
 * @param width the requested size of the paper.
 * @param height the requested height of the paper.
 */
//===================================================================
public void requestPageSize(double width, double height)
//===================================================================
{
	requestedFullWidth = width;
	requestedFullHeight = height;
}

//===================================================================
public String toString()
//===================================================================
{
	return new PointRect(imageableX,imageableY,imageableWidth,imageableHeight)+" inside ("+fullPageWidth+", "+fullPageHeight+")"; 
}

/**
Return the Requested Imageable area for the PageFormat - if one was requested, otherwise null
will be returned.
**/
/*
//===================================================================
public PointRect getRequestedImageableArea()
//===================================================================
{
	if (requestedX == -1)	return null;
	return new PointRect().set(requestedX,requestedY,requestedWidth,requestedHeight);
}
*/
/**
Return the Requested Imageable area for the PageFormat - if one was requested, otherwise null
will be returned.
**/
/*
//===================================================================
public PointRect getRequestedPageSize()
//===================================================================
{
	if (requestedFullWidth == -1)	return null;
	return new PointRect().set(0,0,requestedFullWidth,requestedFullHeight);
}

//===================================================================
public double getRequestedXDPI() {return requestedXDpi;}
//===================================================================
public double getRequestedYDPI() {return requestedYDpi;}
//===================================================================
*/
/**
 * This is used to tell the PageFormat that the physical device has accepted its requests
 * and it can alter its values to match the requests.
 */
//===================================================================
public void acceptRequests()
//===================================================================
{
	if (requestedFullWidth != -1){
		fullPageWidth = requestedFullWidth;
		fullPageHeight = requestedFullHeight;
	}
	if (requestedX != -1){
		imageableX = requestedX;
		imageableY = requestedY;
		imageableHeight = requestedHeight;
		imageableWidth = requestedWidth;
	}
	if (requestedXDpi <= 0){
		xDPI = requestedXDpi;
		yDPI = requestedYDpi;
	}
}
/**
 * Get the co-ordinates into the printer Page for the specified margins. This ignores
 * the visibleRect parameters.
 * @param top the top margin.
 * @param left the left margin.
 * @param bottom the bottom margin.
 * @param right the right margin.
 * @param dest an optional destination PointRect.
 * @return the dest PointRect or a new one if dest is null.
 */
public PointRect getMargined(double top, double left, double bottom, double right, PointRect dest)
{
	if (dest == null) dest = new PointRect();
	dest.x = left;
	dest.y = top;
	dest.width = fullPageWidth-left-right;
	dest.height = fullPageHeight-bottom-top;
	return dest;
}
/**
 * A convenience method to get a PageFormat for a specfic size. This creates a new PageFormat,
 * calls requestPageSize() followed by acceptRequests(). 
 * @param widthInPoints the width in points.
 * @param heightInPoints the height in points.
 * @return a new PageFormat with the size as specified.
 */
public static PageFormat getForSize(double widthInPoints, double heightInPoints)
{
	PageFormat pf = new PageFormat();
	pf.requestPageSize(widthInPoints,heightInPoints);
	pf.acceptRequests();
	return pf;
}

//##################################################################
}
//##################################################################

