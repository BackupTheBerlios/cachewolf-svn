/*
 * Created on May 6, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

import java.util.Hashtable;

import eve.fx.AlignmentConstants;
import eve.fx.Brush;
import eve.fx.Color;
import eve.fx.Font;
import eve.fx.FontMetrics;
import eve.fx.GeneralPath;
import eve.fx.Graphics;
import eve.fx.GraphicsImageData;
import eve.fx.IPath;
import eve.fx.Image;
import eve.fx.ImageTool;
import eve.fx.Metrics;
import eve.fx.PathMaker;
import eve.fx.Pen;
import eve.fx.PixelBuffer;
import eve.fx.Rect;
import eve.fx.RotatedImageData;
import eve.sys.Cache;
import eve.sys.ImageData;
import eve.sys.Vm;
import eve.util.StringList;
import eve.util.SubString;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class PointGraphics implements AlignmentConstants, IPath{

	private IPointCanvas canvas;
	
	/**
	 * Set the current font for text operations for the PointGraphics.
	 * @param f the PointFont for the PointGraphics.
	 */
	public void setFont(PointFont f)
	{
		font = getFontMetrics(f); //Must always be done.
		if (canvas != null){
			canvas.setFont(f);
			return;
		}
	}
	/**
	 * Get a PointFontMetrics for a PointFont on the current PointGraphics.
	 * @param f the PointFont.
	 * @return a PointFontMetrics for a PointFont on the current PointGraphics.
	 */
	public PointFontMetrics getFontMetrics(PointFont f)
	{
		if (canvas != null){
			return canvas.getPointFontMetrics(f);
		}
		synchronized(this){
			if (fms == null) fms = new Hashtable();
			PointFontMetrics got = (PointFontMetrics)fms.get(f);
			if (got != null) return got;
			got = new PointFontMetrics(f,this);
			fms.put(f,got);
			return got;
		}
	}

	
	protected double xscale, yscale;
	
	//private int transformType;
	//private double tx, ty;
	//private int gtx, gty;
	protected double xdpi, ydpi;
	//
	private double gwidth, gheight;
	private int ogw, ogh;
	private Graphics g;
	private Rect originalClip;
	private PointFontMetrics font;
	
	private Color penColor = new Color();
	private int penStyle = 0;
	private double penXThickness = 0;
	private double penYThickness = 0;
	private double penMiter = 1;
	private Color brushColor = new Color();
	private Color backgroundColor = new Color();
	private int brushStyle = 0;
	
	/**
	 * If this is set true then a free() on this PointGraphics will not
	 * free the underlying Graphics.
	 */
	public boolean dontFreeGraphics = false;
	/**
	 * Set the background color of the Graphics.
	 * @param c the new background color.
	 */
	public void setBackground(Color c)
	{
		if (!Color.isNull(c)) backgroundColor.set(c);
		else backgroundColor.set(255,255,255);
	}
	/**
	 * Get the width of an individual pixel in points, but if this
	 * PointGraphics is based on an IPointCanvas, this will return 0.
	 */
	public double pixelWidth()
	{
		if (canvas != null) return 0;
		return 72/xdpi;
	}
	/**
	 * Get the height of an individual pixel in points, but if this
	 * PointGraphics is based on an IPointCanvas, this will return 0.
	 */
	public double pixelHeight()
	{
		if (canvas != null) return 0;
		return 72/ydpi;
	}
	/**
	 * Get the X dpi, but if this is based on an IPointCanvas, this will be zero.
	 */
	public double getXdpi()
	{
		return xdpi;
	}
	/**
	 * Get the X dpi, but if this is based on an IPointCanvas, this will be zero.
	 */
	public double getYdpi()
	{
		return ydpi;
	}
	/**
	 * Reset the PointGraphics and underlying Graphics to the original state.
	 */
	public void reset()
	{
		if (g != null){
			g.restoreClip(originalClip);
		}
	}
	/**
	 * Free all resources associated with this PointGraphics. If dontFreeGraphics is true
	 * then the underlying Graphics will not be freed.
	 */
	public void free()
	{
		if (canvas != null)
			canvas.freePointCanvas();
		else
			if (g != null && !dontFreeGraphics)
				g.free();
	}
	
	public static final int TRANSFORM_ROTATE_90 = AffineTransform.TRANSFORM_ROTATE_90;
	public static final int TRANSFORM_ROTATE_180 = AffineTransform.TRANSFORM_ROTATE_180;
	public static final int TRANSFORM_ROTATE_270 = AffineTransform.TRANSFORM_ROTATE_270;
	public static final int TRANSFORM_NONE = AffineTransform.TRANSFORM_NONE;
	public static final int TRANSFORM_ROTATE_NONE = AffineTransform.TRANSFORM_ROTATE_NONE;
	public static final int TRANSFORM_ROTATE_NOT_RIGHT = AffineTransform.TRANSFORM_ROTATE_NOT_RIGHT;
	
	private boolean transformsDisabled = false;
	/*
	private void setUnityTransform()
	{
		if (g.canTransform()){
			g.setTransform(1,0,0,1,0,0);
		}
	}
	*/
	//public 
	void disableTransforms()
	{
		transformsDisabled = true;
		//setUnityTransform();
	}
	//public 
	void enableTransforms()
	{
		transformsDisabled = false;
		//set(tf);
	}
	private boolean canTransform()
	{
		//if (true) return false;
		return !transformsDisabled && surfaceCanTransform();
	}
	
	protected boolean surfaceCanTransform()
	{
		if (canvas != null) return true;
		return g.canTransform();
	}
	protected Object surfaceSetTransform(double[] buffer)
	{
		// This method should not be called if this is based on an IPointCanvas.
		if (canvas != null) {
			canvas.setTransform(new AffineTransform(buffer));
			return null;
		}
		if (g.canTransform()){
			//g.setTransform(buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5]);
			return g.transform(buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5]);
		}
		return null;
	}
	
	protected void setDPI(double xDPI, double yDPI)
	{
		xdpi = xDPI;
		ydpi = yDPI;
		xscale = xdpi/72.0;
		yscale = ydpi/72.0;
	}
	/**
	 * If this default constructor is used, you must, at a minimum,
	 * call setDPI() before doing any drawing.
	 */
	protected PointGraphics()
	{
		
	}
	public PointGraphics(IPointCanvas canvas)
	{
		this.canvas = canvas;
		canvas.getUnityTransform(tf);
	}
	/**
	 * Create a PointGraphics to draw on an image using a specific DPI value.
	 * @param im the Image to draw on.
	 * @param dpi the DPI to use for the PointGraphics.
	 */
	public PointGraphics(Image im, double dpi)
	{
		this(new Graphics(im),im.getWidth(),im.getHeight(),dpi,dpi);
	}
	/**
	 * Create a PointGraphics to draw on an image where the x and y dpi are
	 * chosen such that the specified point width and height fit the image
	 * exactly.
	 * @param im the image.
	 * @param pointWidth the width in points represented by the width of the image.
	 * @param pointHeight the height in points represented by the height of the image.
	 */
	public PointGraphics(Image im, double pointWidth, double pointHeight)
	{
		this(new Graphics(im),im.getWidth(),im.getHeight(),im.getWidth()*72.0/pointWidth,im.getHeight()*72.0/pointHeight);
	}
	/**
	 * Create a PointGraphics from a Graphics object, specifying the number of pixels
	 * that the Graphics covers horizontally and vertically and specifying the x and y DPI
	 * values that you attribute to the Graphics.
	 * @param g The target Graphics object.
	 * @param graphicsWidth the number of horizontal pixels covered by the Graphics object.
	 * @param graphicsHeight the number of vertical pixels covered by the Graphics object.
	 * @param xDPI the horizontal DPI being attributed to the Graphics.
	 * @param yDPI the vertical DPI being attributed to the Graphics.
	 */
	public PointGraphics(Graphics g, int graphicsWidth, int graphicsHeight, double xDPI, double yDPI)
	{
		setDPI(xDPI, yDPI);
		ogw = graphicsWidth;
		ogh = graphicsHeight;
		//System.out.println(new Dimension(ogw,ogh));
		gwidth = (double)graphicsWidth/xscale;
		gheight = (double)graphicsHeight/yscale;
		this.g = g;
		originalClip = g.getClip(new Rect());
		//setUnityTransform();
	}
	/**
	 * Set the current transform of the PointGraphics to one of the TRANSFORM_XXX values. Note that this
	 * is not cumulative; calling setTransform(TRANSFORM_ROTATE_90) twice will NOT result in a rotation
	 * of 180 degrees. 
	 * @param transformType one of the TRANSFORM_XXXX values.
	 */
	/*
	public void setTransform(int transformType)
	{
		int old = this.transformType;
		this.transformType = transformType;
		if (canTransform()){
			switch(transformType){
			case TRANSFORM_NONE:
				g.setTransform(1,0,0,1,0,0); break;
			case TRANSFORM_ROTATE_90:
				g.setTransform(0,1,-1,0,ogw,0); break;
			case TRANSFORM_ROTATE_270:
				g.setTransform(0,-1,1,0,0,ogh); break;
			case TRANSFORM_ROTATE_180:
				g.setTransform(-1,0,0,-1,ogw,ogh); break;
			}
		}
		int doRot = 0;
		switch(old){
			case TRANSFORM_NONE:
				doRot = transformType;
				break;
			case TRANSFORM_ROTATE_90:
				if (transformType == TRANSFORM_NONE)
					doRot = TRANSFORM_ROTATE_270;
				else if (transformType == TRANSFORM_ROTATE_90)
					doRot = TRANSFORM_NONE;
				else if (transformType == TRANSFORM_ROTATE_180)
					doRot = TRANSFORM_ROTATE_90;
				else
					doRot = TRANSFORM_ROTATE_180;
				break;
			case TRANSFORM_ROTATE_180:
				if (transformType == TRANSFORM_NONE)
					doRot = TRANSFORM_ROTATE_180;
				else if (transformType == TRANSFORM_ROTATE_90)
					doRot = TRANSFORM_ROTATE_270;
				else if (transformType == TRANSFORM_ROTATE_180)
					doRot = TRANSFORM_NONE;
				else
					doRot = TRANSFORM_ROTATE_90;
				break;
			case TRANSFORM_ROTATE_270:
				if (transformType == TRANSFORM_NONE)
					doRot = TRANSFORM_ROTATE_90;
				else if (transformType == TRANSFORM_ROTATE_90)
					doRot = TRANSFORM_ROTATE_180;
				else if (transformType == TRANSFORM_ROTATE_180)
					doRot = TRANSFORM_ROTATE_270;
				else
					doRot = TRANSFORM_NONE;
				break;
		}
		//System.out.print("("+tx+","+ty+") ");
		//System.out.print(old+", "+transformType+" = "+doRot);
		double nx = tx, ny = ty, t = 0;
		double gw = gwidth, gh = gheight;
		if (old == TRANSFORM_ROTATE_90 || old == TRANSFORM_ROTATE_270){
			t = gw; gw = gh; gh = t;
		}
		switch(doRot){
			case TRANSFORM_ROTATE_90:
				t = nx; nx = gw-ny; ny = t; break;
			case TRANSFORM_ROTATE_270:
				t = ny; ny = gh-nx; nx = t; break;
			case TRANSFORM_ROTATE_180:
				nx = gw-nx; ny = gh-ny; break;
		}
		tx = nx; ty = ny;
		//System.out.print(" ("+tx+","+ty+") ");
		//System.out.println();
	}*/
	/*
	private void _restoreTranslate(double x, double y)
	{
		tx = x;
		ty = y;
	}
	private void _translate(double x, double y, PointRect old)
	{
		if (old != null){
			old.x = tx;
			old.y = ty;
		}
		tx += x;
		ty += y;
	}
	*/
	private static double[] xv = new double[1], yv = new double[1];
	private static int[] xi = new int[1], yi = new int[1];
	private static final double xline[] = new double[2], yline[] = new double[2];
	
	private static Rect rect = new Rect();
	
	private void _needPoints(int numPoints)
	{
		if (xv.length < numPoints){
			xv = new double[numPoints];
			yv = new double[numPoints];
			xi = new int[numPoints];
			yi = new int[numPoints];
		}
	}
	private void _transform(int numPoints)
	{
		_transform(xv,0,yv,0,numPoints);
	}
	//
	// FIXME
	//
	private void _transform(double[] x, int xoffset, double[] y, int yoffset, int length)
	{
		//if (!canTransform())
		//System.out.println(tf);
		tf.transform(x,xoffset,y,yoffset,length);
		/*
		for (int i = 0; i<length; i++){
			double nx = x[xoffset]+tx;
			double ny = y[yoffset]+ty;
			double t;
			if (transformType != TRANSFORM_NONE && !canTransform())
				switch(transformType){
					case TRANSFORM_ROTATE_90:
						t = nx; nx = gwidth-ny; ny = t; break;
					case TRANSFORM_ROTATE_270:
						t = ny; ny = gheight-nx; nx = t; break;
					case TRANSFORM_ROTATE_180:
						nx = gwidth-nx; ny = gheight-ny; break;
				}
			x[xoffset++] = nx;
			y[yoffset++] = ny;
		}
		*/
	}
	private double _transform(double angle)
	{
		int transformType = tf.getRightAngleRotation();
		if (transformType != TRANSFORM_NONE && !canTransform())
			switch(transformType){
				case TRANSFORM_ROTATE_270: angle += 90; break;
				case TRANSFORM_ROTATE_90: angle += 270; break;
				case TRANSFORM_ROTATE_180: angle += 180; break;
			}
		while(angle >= 360) angle -= 360;
		return angle;
	}
	ImageData _transform(ImageData src, Rect srcArea, Rect dsrcArea)
	{
		dsrcArea.set(srcArea);
		int transformType = tf.getRightAngleRotation();
		if (transformType != TRANSFORM_NONE && canTransform()) return src;
		int w = src.getImageWidth(), h = src.getImageHeight();
		int t;
		switch(transformType){
			case TRANSFORM_ROTATE_90:
				t = dsrcArea.width; dsrcArea.width = dsrcArea.height; dsrcArea.height = t;
				t = dsrcArea.x; dsrcArea.x = h-dsrcArea.y-srcArea.height; dsrcArea.y = t;
				return new RotatedImageData(src,RotatedImageData.ROTATE_270);
			case TRANSFORM_ROTATE_270: 
				t = dsrcArea.width; dsrcArea.width = dsrcArea.height; dsrcArea.height = t;
				t = dsrcArea.y; dsrcArea.y = w-dsrcArea.x-srcArea.width; dsrcArea.x = t;
				return new RotatedImageData(src,RotatedImageData.ROTATE_90);
			case TRANSFORM_ROTATE_180: 
				dsrcArea.y = h-srcArea.y-srcArea.height; 
				dsrcArea.x = w-srcArea.x-srcArea.width;
				return new RotatedImageData(src,RotatedImageData.ROTATE_180);
		}
		return src;
	}
	
	private void _transformPoints(double[] x, double[] y, int xoffset,int yoffset,int count,boolean calculateInts)
	{
		_needPoints(count);
		
		if (y == null) y = x;
		int step = 1;
		if (y == x){
			if (yoffset == xoffset) yoffset = xoffset+1;
			if (yoffset == xoffset+1) step = 2;
		}
		if (step == 1){
			System.arraycopy(x,xoffset,xv,0,count);
			System.arraycopy(y,yoffset,yv,0,count);
		}else{
			for (int i = 0; i<count; i++){
				xv[i] = x[xoffset];
				yv[i] = y[yoffset];
				xoffset += step;
				yoffset += step;
			}
		}
		_transform(count);
		if (calculateInts){
			for (int i = 0; i<count; i++){
				xi[i] = (int)(xv[i]*xscale);
				yi[i] = (int)(yv[i]*yscale);
			}
		}
	}
	/**
	 * @deprecated - use translate(double x, double y, PointRect old) instead.
	 * Move the drawing origin a certain distance in points. Note that, due to rounding
	 * errors, reversing a PointGraphics graphics by passing negative values is not
	 * reliable. The other translate() method provides a reliable way of restoring
	 * the PointGraphics translation state.
	 * @param x the x distance to translate the origin.
	 * @param y the y distance to translate the origin.
	 */
	/*
	public void translate(double x, double y)
	{
		_translate(x,y,null);
	}
	*/
	/**
	 * Move the drawing origin a certain distance in points and save
	 * the translation state so that it can be accurately restored later.
	 * @param x the x distance to translate the origin.
	 * @param y the y distance to translate the origin.
	 * @param old a non-null PointRect object to hold the current translation
	 * state.
	 */
	/*
	public void translate(double x, double y, PointRect old)
	{
		_translate(x,y,old);
	}
	*/
	/**
	 * Restore the translation state of the PointGraphics using the stored state
	 * saved in the translate(double x, double y, PointRect old) method call.
	 * @param old the PointRect passed to the translate() method.
	 */
	/*
	public void restoreTranslation(PointRect old)
	{
		_restoreTranslate(old.x,old.y);
	}
	*/
	private Pen tempPen;
	/**
	 * Set the current Pen for the PointGraphics.
	 * @param c the Color of the Pen.
	 * @param style the style of the Pen which should be one of the eve.fx.Pen style values.
	 * @param xWidth the horizontal width of the Pen in points.
	 * @param yWidth the vertical width of the Pen in points.
	 * @param miterLimit the miter limit for the Pen. A miter limit of less than 1 is illegal
	 * and will cause the miter limit to default to the default miter limit of 10.
	 */
	public void setPen(Color c, int style, double xWidth, double yWidth, float miterLimit)
	{
		if (canvas != null){
			canvas.setPen(c,style, xWidth, yWidth, miterLimit);
			return;
		}
		penColor.set(c);
		penStyle = style;
		penXThickness = xWidth;
		penYThickness = yWidth;
		penMiter = miterLimit;
		if (penMiter < 1) penMiter = 10;
		int xt = (int)(xWidth*xscale);
		if (xt == 0 && xWidth != 0) xt = 1;
		int yt = (int)(yWidth*yscale);
		if (yt == 0 && yWidth != 0) yt = 1;
		int thick = (xt+yt)/2;
		g.changePen(c,style,thick,(float)penMiter);
	}
	/**
	 * Set the current Brush (used in filling).
	 * @param c the Color of the Brush.
	 * @param style the style of the Brush, which should be one of the eve.fx.Brush
	 * style values.
	 */
	public void setBrush(Color c, int style)
	{
		setBrush(c,style,Brush.defaultRule);
	}
	public void setBrush(Color c, int style, int rule)
	{
		if (canvas != null){
			canvas.setBrush(c, style, rule);
			return;
		}
		brushColor.set(c);
		brushStyle = style;
		g.changeBrush(c,style);
	}
	
	/**
	 * Set the Pen to be a solid pen of point width 1 and the brush to be a solid brush,
	 * both with the specified color.
	 * @param c the Color for the current pen and brush.
	 */
	public void setColor(Color c)
	{
		setPen(c,Pen.SOLID,1,1,10);
		setBrush(c,Brush.SOLID);
	}
	/**
	 * This method is used when an object being drawn on a PointGraphics
	 * is being mapped to some area on the screen (or some other pixel oriented device)
	 * where each pixel represents a dot.
	 * <p>
	 * The area on the screen will usually cover some area within the object
	 * being drawn and therefore its upper left corner is usually offset a certain 
	 * number of pixels horizontally or vertically.
	 * <p>
	 * When you are about to redraw the object or part of the object to the screen
	 * call this method first to set the correct translation in points. Then
	 * you can call getScreenUpdateRect() any number of times to get a PointRect
	 * which indicates the area on the object (in points) which needs to be
	 * drawn to this PointGraphics.
	 * @param screenAreaPixelOffsetX the X-offset of the screen area into the 
	 * drawn object.
	 * @param screenAreaPixelOffsetY the Y-offset of the screen area into the
	 * drawn object.
	 */
	public void startScreenUpdate(int screenAreaPixelOffsetX, int screenAreaPixelOffsetY)
	{
		getTransformState().translate(-screenAreaPixelOffsetX/xscale,-screenAreaPixelOffsetY/yscale);
	}
	/**
	 * This method is used when an object being drawn on a PointGraphics
	 * is being mapped to some area on the screen (or some other pixel oriented device)
	 * where each pixel represents a dot.
	 * <p>
	 * The area on the screen will usually cover some area within the object
	 * being drawn and therefore its upper left corner is usually offset a certain 
	 * number of pixels horizontally or vertically.
	 * <p>
	 * When you are about to redraw the object or part of the object to the screen
	 * call the startScreenUpdate() method first to set the correct translation in points. Then
	 * you can call getScreenUpdateRect() any number of times to get a PointRect
	 * which indicates the area on the object (in points) which needs to be
	 * drawn to this PointGraphics.
	 * @param px the x-coordinate (in pixels) of the screen area being updated
	 * relative to its own origin, not relative to the drawn object.
	 * @param py the y-coordinate (in pixels) of the screen area being updated
	 * relative to its own origin, not relative to the drawn object.
	 * @param pwidth the width in pixels of the screen area being updated.
	 * @param pheight the height in pixels of the screen area being updated.
	 * @param dest a non-null PointRect to hold the area that should be re-drawn
	 * in points in the drawn object.
	 * @param screenAreaPixelOffsetX the X-offset of the screen area into the 
	 * drawn object.
	 * @param screenAreaPixelOffsetY the Y-offset of the screen area into the
	 * drawn object.
	 */
	public void getScreenUpdateRect(int px, int py, int pwidth, int pheight,PointRect dest,int screenAreaPixelOffsetX, int screenAreaPixelOffsetY)
	{
		if (pwidth != 0 && pheight != 0){
			if (px > 0) px--;
			if (py > 0) py--;
			pwidth += 2;
			pheight += 2;
		}
		double tx = -screenAreaPixelOffsetX/xscale;
		double ty = -screenAreaPixelOffsetY/yscale;
		int ex = px+pwidth, ey = py+pheight;
		double xx = (px/xscale)-tx;
		while(px > 0){
			if ((int)((xx+tx)*xscale) > px) 
				xx -= (1/xscale);
			else
				break;
		}
		int npx = (int)((xx+tx)*xscale);
		pwidth += px-npx;
		double yy = (py/yscale)-ty;
		while(py > 0){
			if ((int)((yy+ty)*yscale) > py)
				yy -= (1/yscale);
			else
				break;
		}
		int npy = (int)((yy+ty)*yscale);
		pheight += py-npy;
		double ww = pwidth/xscale;
		while(pwidth > 0){
			int ewx = (int)((xx+tx+ww)*xscale);
			if ((ewx-npx) < pwidth) ww += (1/xscale);
			else break;
		}
		double hh = pheight/yscale;
		while(pheight > 0){
			int ehy = (int)((yy+ty+hh)*yscale);
			if ((ehy-npy) < pheight) hh += (1/yscale);
			else {
				break;
			}
		}
		dest.set(xx,yy,ww,hh);
	}
	private Rect _transformRect(double x, double  y, double width, double height)
	{
		_needPoints(2);
		xv[0] = x; xv[1] = x+width;
		yv[0] = y; yv[1] = y+height;
		_transform(2);
		int xx = (int)(xv[0]*xscale), yy = (int)(yv[0]*yscale);
		int x2 = (int)(xv[1]*xscale), y2 = (int)(yv[1]*yscale);
		int t;
		if (x2 < xx){
			t = x2; x2 = xx; xx = t;
		}
		if (y2 < yy){
			t = y2; y2 = yy; yy = t;
		}
		int w = x2-xx, h = y2-yy;
		rect.set(xx,yy,w,h);
		/*
		if (!tf.isUnity()){
			System.out.println(new PointRect(x,y,width,height));
			System.out.println(tf);
			System.out.println(rect+" @ "+xscale);
		}
		*/
		return rect;
	}
	/*
	public static void pixelsToPoints(double xdpi, double ydpi, int px, int py, int pwidth, int pheight, PointRect dest,double tx,double ty)
	{
		double xscale = xdpi/72.0, yscale = ydpi/72.0;
	}
	public void pixelsToPoints(int px, int py, int pwidth, int pheight, PointRect dest,double tx,double ty)
	{
		pixelsToPoints(xdpi,ydpi,px,py,pwidth,pheight,dest,tx,ty);
	}
	*/
	//public static PointRect check = new PointRect();
	
	private Object centerRotate(double xx, double yy)
	{
		double[] buff = new double[6];
		tf.getMatrix(buff);
		AffineTransform at = (AffineTransform)Cache.get(AffineTransform.class);
		try{
			at.translate(xx,yy);
			double a = Math.PI/2;
			//double c = Math.cos(a), s = Math.sin(a);
			//at.concatenate(new AffineTransform(c,s,-s,c,0,0));
			at.concatenate(new AffineTransform(buff[0],buff[1],buff[2],buff[3],0,0));
			//at.rotateRightAngle(TRANSFORM_ROTATE_90);
			at.translate(-xx,-yy);
			//at.rotateRightAngle(transformType,xx,yy);
			at.getMatrix(buff);
		}finally{
			Cache.put(at);
		}
		return surfaceSetTransform(buff);
		//System.out.println(xx+" , "+yy);
		//System.out.println(at+" = "+(check.x*xscale+xx)+", "+(check.y*yscale+yy));
	}
	private void arcFunc(double x,double y,double width,double height,double sa,double angle,boolean useBrush,boolean usePen,int which)
	{
		if (canvas != null){
			return;//
		}
		synchronized(PointGraphics.class){
			int transformType = tf.getRightAngleRotation();
			Rect r = (transformType != TRANSFORM_NONE && canTransform()) ? new Rect(0,0,0,0) : _transformRect(x,y,width,height);
			double startAngle = (double)_transform(sa);
			Object didTransform = null;
			//if (r.width <= 0 || r.height <= 0)
			if (transformType != TRANSFORM_NONE && canTransform()){
				_needPoints(1);
				xv[0] = x; 
				yv[0] = y;
				_transform(1);
				r.x = (int)(xv[0]*xscale);
				r.y = (int)(yv[0]*yscale);
				r.width = (int)(width*xscale);
				r.height = (int)(height*yscale);
				startAngle = sa;
				didTransform = centerRotate(r.x,r.y);
				//System.out.println("TXX");
			}
			//System.out.println(startAngle);
			//System.out.println("G: "+new PointRect(x,y,width,height)+"=>"+r);
			switch(which){
				case 0: g.paintPie(r.x,r.y,r.width,r.height,(float)startAngle,(float)angle,useBrush,usePen); break;
				case 1: g.paintClosedArc(r.x,r.y,r.width,r.height,(float)startAngle,(float)angle,useBrush,usePen); break;
				case 2: g.drawArc(r.x,r.y,r.width,r.height,(float)startAngle,(float)angle); break;
				case 3: g.paintEllipse(r.x,r.y,r.width,r.height,useBrush,usePen); break;
				case 4: g.paintRect(r.x,r.y,r.width,r.height,useBrush,usePen); break;
				case 5: {
					int rad = (int)(angle*xscale);
					g.paintRoundRect(r.x,r.y,r.width,r.height,rad,useBrush,usePen); 
					break;
				}
			}
			restoreTransform(didTransform);
		}
	}
	private PathMaker pathMaker;
	/**
	 * Paint a closed pie section of an ellipse. This consists of an arc with the two ends of the
	 * arc joined by two straight lines to the center of the ellipse. 
	 * The complete ellipse is contained in the x, y, width and height
	 * values specified.
	 * @param x the x co-ordinate of the bounding box of the complete ellipse.
	 * @param y the y co-ordinate of the bounding box of the complete ellipse.
	 * @param width the width  of the bounding box of the complete ellipse.
	 * @param height the height  of the bounding box of the complete ellipse.
	 * @param startAngle the start angle of the pie section, measured in degrees anti-clockwise where
	 * 0 degrees is the 3 O'clock position.
	 * @param angle the number of degrees in the pie section.
	 * @param useBrush if this is true the pie section will be filled in the current brush before the
	 * outline is drawn. If it is false the pie section is not filled.
	 * @param usePen if this is true then the outline of the section will be drawn in the current pen after
	 * any filling is done (if any). if this is false then the outline is not drawn.
	 */
//	===================================================================
	public void paintPie(double x,double y,double width,double height,float startAngle,float angle,boolean useBrush,boolean usePen)
//	===================================================================
	{
		if (canvas != null){
			if (pathMaker == null) pathMaker = new PathMaker(canvas);
			pathMaker.pie(x, y, width, height,startAngle,angle);
			canvas.paintPath(useBrush, usePen);
			return;
		}
		arcFunc(x,y,width,height,startAngle,angle,useBrush,usePen,0);
	}
	/**
	 * Paint a closed arc section of an ellipse. This consists of an arc with the two ends of the
	 * arc joined by a single straight lines from one end to the other (a chord). 
	 * The complete ellipse is contained in the x, y, width and height
	 * values specified.
	 * @param x the x co-ordinate of the bounding box of the complete ellipse.
	 * @param y the y co-ordinate of the bounding box of the complete ellipse.
	 * @param width the width  of the bounding box of the complete ellipse.
	 * @param height the height  of the bounding box of the complete ellipse.
	 * @param startAngle the start angle of the arc section, measured in degrees anti-clockwise where
	 * 0 degrees is the 3 O'clock position.
	 * @param angle the number of degrees in the arc section.
	 * @param useBrush if this is true the arc section will be filled in the current brush before the
	 * outline is drawn. If it is false the arc section is not filled.
	 * @param usePen if this is true then the outline of the section will be drawn in the current pen after
	 * any filling is done (if any). if this is false then the outline is not drawn.
	 */
//	===================================================================
	public void paintClosedArc(double x,double y,double width,double height,float startAngle,float angle,boolean useBrush,boolean usePen)
//	===================================================================
	{
		if (canvas != null){
			if (pathMaker == null) pathMaker = new PathMaker(canvas);
			pathMaker.closedArc(x, y, width, height,startAngle,angle);
			canvas.paintPath(useBrush, usePen);
			return;
		}
		arcFunc(x,y,width,height,startAngle,angle,useBrush,usePen,1);
	}	
	/**
	 * Draw an open arc section of an ellipse using the current pen. 
	 * The complete ellipse is contained in the x, y, width and height
	 * values specified.
	 * @param x the x co-ordinate of the bounding box of the complete ellipse.
	 * @param y the y co-ordinate of the bounding box of the complete ellipse.
	 * @param width the width  of the bounding box of the complete ellipse.
	 * @param height the height  of the bounding box of the complete ellipse.
	 * @param startAngle the start angle of the arc section, measured in degrees anti-clockwise where
	 * 0 degrees is the 3 O'clock position.
	 * @param angle the number of degrees in the arc section.
	 */
//	===================================================================
	public void drawArc(double x,double y,double width,double height,float startAngle,float angle)
//	===================================================================
	{
		if (canvas != null){
			if (pathMaker == null) pathMaker = new PathMaker(canvas);
			pathMaker.arc(0,x, y, width, height,startAngle,angle);
			canvas.paintPath(false, true);
			return;
		}
		arcFunc(x,y,width,height,startAngle,angle,false,true,2);
	}	
	/**
	 * Paint a complete ellipse contained in the x, y, width and height
	 * values specified.
	 * @param x the x co-ordinate of the bounding box of the complete ellipse.
	 * @param y the y co-ordinate of the bounding box of the complete ellipse.
	 * @param width the width  of the bounding box of the complete ellipse.
	 * @param height the height  of the bounding box of the complete ellipse.
	 * @param useBrush if this is true the ellipse will be filled in the current brush before the
	 * outline is drawn. If it is false the ellipse is not filled.
	 * @param usePen if this is true then the outline of the ellipse will be drawn in the current pen after
	 * any filling is done (if any). if this is false then the outline is not drawn.
	 */
//	===================================================================
	public void paintEllipse(double x, double y, double width, double height, boolean useBrush, boolean usePen)
//	===================================================================
	{
		if (canvas != null){
			if (pathMaker == null) pathMaker = new PathMaker(canvas);
			pathMaker.ellipse(x, y, width, height);
			canvas.paintPath(useBrush, usePen);
			return;
		}
		arcFunc(x,y,width,height,0,0,useBrush,usePen,3);
	}
	/**
	 * Paint a complete Rectangle contained in the x, y, width and height
	 * values specified.
	 * @param x the x co-ordinate of the rectangle.
	 * @param y the y co-ordinate of the rectangle.
	 * @param width the width  of the rectangle.
	 * @param height the height  of the rectangle.
	 * @param useBrush if this is true the rectangle will be filled in the current brush before the
	 * outline is drawn. If it is false the rectangle is not filled.
	 * @param usePen if this is true then the outline of the rectangle will be drawn in the current pen after
	 * any filling is done (if any). if this is false then the outline is not drawn.
	 */
//	===================================================================
	public void paintRect(double x, double y, double width, double height, boolean useBrush, boolean usePen)
//	===================================================================
	{
		if (canvas != null){
			canvas.paintRect(x, y, width, height, useBrush, usePen);
			return;
		}
		arcFunc(x,y,width,height,0,0,useBrush,usePen,4);
	}
	/**
	 * Paint a closed polygon. The PointGraphics will close the polygon so the first co-ordinates should
	 * NOT be repeated as the last co-ordinates.
	 * @param x an array holding the x co-ordinates for the corners of the polygon.
	 * @param y an array holding the y co-ordinates for the corners of the polygon.
	 * @param xoffset the start location in the x array for the co-ordinates.
	 * @param yoffset the start location in the y array for the co-ordinates.
	 * @param count the number of corners in the polygon, which should be a minimum of three.
	 * @param useBrush if this is true the polygon will be filled in the current brush before the
	 * outline is drawn. If it is false the polygon is not filled.
	 * @param usePen if this is true then the outline of the polygon will be drawn in the current pen after
	 * any filling is done (if any). if this is false then the outline is not drawn.
	 */
//	===================================================================
	public void paintPolygon(double[] x, double[] y, int xoffset, int yoffset, int count, boolean useBrush, boolean usePen)
//	===================================================================
	{
		if (canvas != null){
			canvas.paintPolygon(x, y, xoffset, yoffset, count, useBrush, usePen);
			return;
		}
		synchronized(PointGraphics.class){
			_transformPoints(x,y,xoffset,yoffset,count,true);
			g.paintPolygon(xi,yi,0,0,count,useBrush,usePen);
		}
	}
	/**
	 * Paint a complete Rectangle with rounded corners contained in the x, y, width and height
	 * values specified.
	 * @param x the x co-ordinate of the rectangle.
	 * @param y the y co-ordinate of the rectangle.
	 * @param width the width  of the rectangle.
	 * @param height the height  of the rectangle.
	 * @param radius the radius of the ellipse segment used for drawing the corners.
	 * @param useBrush if this is true the rectangle will be filled in the current brush before the
	 * outline is drawn. If it is false the rectangle is not filled.
	 * @param usePen if this is true then the outline of the rectangle will be drawn in the current pen after
	 * any filling is done (if any). if this is false then the outline is not drawn.
	 */
//	===================================================================
	public void paintRoundRect(double x, double y, double width, double height, double radius, boolean useBrush, boolean usePen)
//	===================================================================
	{
		if (canvas != null){
			if (pathMaker == null) pathMaker = new PathMaker(canvas);
			pathMaker.roundRect(x, y, width, height,radius);
			canvas.paintPath(useBrush, usePen);
			return;
		}
		arcFunc(x,y,width,height,0,radius,useBrush,usePen,5);
	}
	/**
	 * Draw a set of lines joined to the next forming a single unbroken path.
	 * @param x the array holding the X co-ordinate points. If y is null then this
	 * also holds the Y co-ordinate points,
	 * either in a separate area or interleaved with the x values.
	 * @param y the Y co-ordinate points or null if the Y co-ordinates are in the 
	 * x array.
	 * @param xoffset the offset into the x array containing the first X point.
	 * @param yoffset the offset into the y array containing the first Y point.
	 * If the y array is null then the y points are in the x array. If the yoffset
	 * is equal to xoffset or to xoffset+1, it is assumed that the x and y
	 * co-ordinates are interleaved (first x, then y, then x, then y), 
	 * otherwise it is assumed that the x and y co-ordinates
	 * are in non-overlapping contiguous sections within the array.
	 * @param count the number of points in the array.
	 */
//	===================================================================
	public void drawLines(double x[], double y[], int xoffset, int yoffset, int count)
//	===================================================================
	{
		drawLines(x,y,xoffset,yoffset,count,false);
	}
	/**
	 * Draw a set of lines either by joining one to the next forming a single unbroken path,
	 * or by drawing sets of separate lines.  
	 * @param x the array holding the X co-ordinate points. If y is null then this
	 * also holds the Y co-ordinate points,
	 * either in a separate area or interleaved with the x values.
	 * @param y the Y co-ordinate points or null if the Y co-ordinates are in the 
	 * x array.
	 * @param xoffset the offset into the x array containing the first X point.
	 * @param yoffset the offset into the y array containing the first Y point.
	 * If the y array is null then the y points are in the x array. If the yoffset
	 * is equal to xoffset or to xoffset+1, it is assumed that the x and y
	 * co-ordinates are interleaved (first x, then y, then x, then y), 
	 * otherwise it is assumed that the x and y co-ordinates
	 * are in non-overlapping contiguous sections within the array.
	 * @param count the number of points in the array.
	 * @param separateLines
	 * true to draw as separate lines (i.e from x0,y0 to x1,y1 and then x2,y2 to x3,y3) 
	 * false to draw as a single path (i.e. from x0,y0 to x1,y1 to x2,y2 to x3,y3).
	 */
//	===================================================================
	public void drawLines(double x[], double y[], int xoffset, int yoffset, int count, boolean separateLines)
//	===================================================================
	{
		if (canvas != null){
			canvas.drawLines(x,y,xoffset,yoffset,count,separateLines);
			return;
		}
		synchronized(PointGraphics.class){
			_transformPoints(x,y,xoffset,yoffset,count,true);
			g.drawLines(xi,yi,0,0,count,separateLines);
		}
	}
	/**
	 * Draw a single line segment.
	 * @param x1 the start x co-ordinate.
	 * @param y1 the start y co-ordinate.
	 * @param x2 the end x co-ordinate.
	 * @param y2 the end y co-ordinate.
	 */
//	===================================================================
	public void drawLine(double x1, double y1, double x2, double y2)
//	===================================================================
	{
		if (canvas != null){
			canvas.drawLine(x1, y1, x2, y2);
			return;
		}
		synchronized(PointGraphics.class){
			xline[0] = x1; xline[1] = x2;
			yline[0] = y1; yline[1] = y2;
			_transformPoints(xline,yline,0,0,2,true);
			g.drawLine(xi[0],yi[0],xi[1],yi[1]);
		}		
	}
	private Hashtable fms;
	
	double getSize(PointFont pf)
	{
		if (pf.size >= 0) return pf.size;
		if (canvas != null){
			return canvas.getPointFontMetrics(pf).getHeight();
		}
		return getIntFontMetrics(pf).getFont().getSize()/yscale;
	}
	/**
	 * If this PointGraphics is implemented on a PointCanvas then return it,
	 * otherwise this will return null.
	 */
	public IPointCanvas getPointCanvas()
	{
		return canvas;
	}
	/**
	 * If this PointGraphics is implemented on a PointCanvas then return the
	 * IPointDocument it is associated with if any.
	 */
	public IPointDocument getPointDocument()
	{
		if (canvas == null) return null;
		return canvas.getDocument();
	}
	FontMetrics getIntFontMetrics(PointFont font)
	{
		FontMetrics fm = g.getFontMetrics(new Font(font.name,font.style,20));
		if (font.size < 0){
			int h = (int)(font.fitHeight*yscale);
			if (h == 0 && font.fitHeight != 0) h = 1;
			int w = (int)(font.fitWidth*xscale);
			if (w == 0 && font.fitWidth != 0) w = 1;
			if (font.fitWidth < 0) {
				Font got = Metrics.getFontForMetric(h,Metrics.METRIC_HEIGHT_OF_TEXT,font.fitData,fm);
				return g.getFontMetrics(got);
			}else if (font.fitHeight < 0){
				return g.getFontMetrics(Metrics.getFontForMetric(w,Metrics.METRIC_WIDTH_OF_TEXT,font.fitData,fm));
			}else
				return g.getFontMetrics(Metrics.fitInto(w,h,font.fitData,fm));
		}else{
			int h = (int)(font.size*yscale);
			if (h == 0 && font.size != 0) h = 1;
			return g.getFontMetrics(Metrics.getFontForHeight(h,fm));
		}
		//return getIntFontMetrics(font.getName(), font.getStyle(), font.getSize());
	}
	/*
	public FontMetrics getIntFontMetrics(String fontName, int style, double size)
	{
		FontMetrics fm = g.getFontMetrics(new Font(fontName,style,20));
		int h = (int)(size*yscale);
		if (h == 0) h = 1;
		return g.getFontMetrics(Metrics.getFontForHeight(h,fm));
	}
	*/
	/*
	public Font getFont(String fontName, int fontStyle, double heightInPoints)
	{
		return getFontForHeight(heightInPoints,new Font(fontName,fontStyle,20));
	}
	public Font getFont(Font baseFont, double newHeightInPoints)
	{
		return getFont(baseFont.getName(), baseFont.getStyle(), newHeightInPoints);
	}
	public Font getFont(Font baseFont, int newStyle, double newHeightInPoints)
	{
		return getFont(baseFont.getName(), newStyle, newHeightInPoints);
	}
	*/
	/**
	 * Scale and draw an ImageData to the PointGraphics, specifying the destination area
	 * that is to be drawn on the PointGraphics - all other sections of the image will
	 * be clipped.
	 * @param src the source ImageData
	 * @param x the x location where the top left corner of the ImageData would be
	 * if the entire image was drawn.
	 * @param y the y location where the top left corner of the ImageData would be
	 * if the entire image was drawn.
	 * @param width the full width of the scaled image.
	 * @param height the full heigh of the scaled image.
	 * @param destArea the destination area being updated on the PointGraphics.
	 * If this is null then the full x, y, width and height values are used. 
	 * @param options scale options, none of which are currently defined.
	 */
	public void drawImageData(ImageData src, double x, double y, double width, double height, PointRect destArea, int options)
	{
		if (canvas != null){
			canvas.drawImageData(src, x, y, width, height, destArea, options);
			return;
		}
		PointRect pr2 = PointRect.getCached(x,y,width,height);
		try{
			disableTransforms();
			if (destArea != null) destArea.getIntersection(pr2,pr2);
			if (pr2.width == 0 || pr2.height == 0) return;
			destArea = pr2;
			synchronized(PointGraphics.class){
				Rect srcArea = Rect.getCached(0,0,src.getImageWidth(),src.getImageHeight());
				Rect s = Rect.getCached();
				Rect d = Rect.getCached();
				Rect full = Rect.getCached();
				PointRect pr = PointRect.getCached(x,y,width,height);
				GraphicsImageData gid = (GraphicsImageData)Cache.get(GraphicsImageData.class);
				try{
					_transformRect(pr.x,pr.y,pr.width,pr.height);
					full.set(rect);
					_transformRect(destArea.x,destArea.y,destArea.width,destArea.height);
					d.set(rect);
					/* 
					 * The possibility of a single pixel resolution problem exists.
					 * Therefore we will paint to one pixel greater top, bottom, left and right.
					 */
					if (true){
						d.x -= 1; d.y -= 1;
						d.width += 2; d.height += 2;
						_transformRect(x,y,width,height);
						if (d.x < rect.x) d.x++;
						if (d.y < rect.y) d.y++;
						if (d.x+d.width > rect.x+rect.width) d.width = rect.x+rect.width-d.x;
						if (d.y+d.height > rect.y+rect.height) d.height = rect.y+rect.height-d.y;
					}
					src = _transform(src,srcArea,s);
					//if (d.width <= 0 || d.height <= 0 || full.width <= 0 || full.height <= 0) return;
					ImageData dest = gid.setFor(g,d.x,d.y,d.width,d.height,true);
					ImageTool.scaleSection(src,full.width,full.height,dest,d.x-full.x,d.y-full.y,options);
				}finally{
					s.cache(); d.cache(); srcArea.cache(); full.cache();
					Cache.put(gid);
					pr.cache();
				}
			}
		}finally{
			pr2.cache();
			enableTransforms();
		}
	}
	/**
	 * Draw text in the PointGraphics. 
	 * @param data the characters to draw.
	 * @param offset the offset into character array for the first character.
	 * @param length the number of characters to draw.
	 * @param x the x co-ordinate of the left side of the first character.
	 * @param y the y co-ordinate of the top of first character. The text base line
	 * will be lower than this value equal to the ascent of the font.
	 */
	public void drawText(char[] data, int offset, int length, double x, double y)
	{
		if (canvas != null){
			canvas.drawText(data, offset, length, x, y);
			return;
		}
		int transformType = tf.getRightAngleRotation();
		synchronized(PointGraphics.class){
			g.setFont(font.getIntFontMetrics().getFont());
			_needPoints(1);
			xv[0] = x; yv[0] = y;
			_transform(1);
			int xx = (int)(xv[0]*xscale);
			int yy = (int)(yv[0]*yscale);
			if (transformType == TRANSFORM_NONE){
				g.drawText(data,offset,length,xx,yy);
			}else if (canTransform()){
				Object obj = centerRotate(xx,yy);
				g.drawText(data,offset,length,xx,yy);
				restoreTransform(obj);
			}else{
				PointFontMetrics pfm = font;
				double height = pfm.getHeight();
				double width = pfm.getTextWidth(data,offset,length);
				PixelBuffer pb = _getPixelBuffer(width,height,0);
				Color t = Color.White;
				if (penColor.equals(t)) t = Color.Black;
				Graphics g = pb.getDrawingBuffer(null,t,1.0);
				g.setFont(font.getIntFontMetrics().getFont());
				g.setColor(penColor);
				g.drawText(data,offset,length,0,0);
				pb.putDrawingBuffer(pb.PUT_SET);
				drawImageData(pb,x,y,width,height,0);
			}
		}
	}
//	####################################################
//  These are all derived from lower level methods.
//	####################################################
	
	/**
	 * Return if the underlying surface can convert from points to pixels.
	 * If the underlying surface is an IPointCanvas this will return false.
	 */
	public boolean canConvertToPixels()
	{
		return canvas != null;
	}
	/**
	 * Given a width in points, calculate the width in pixels for the PointGraphics,
	 * but this will only work if canConvertToPixels() returns true.
	 * @param width a width in points.
	 * @return the corresponding width in pixels, not less than 1.
	 */
	public int scaleWidth(double width)
	{
		int v = (int)(width*xscale);
		if (v == 0 && width != 0) v = 1;
		return v;
	}
	/**
	 * Given a heidhg in points, calculate the height in pixels for the PointGraphics,
	 * but this will only work if canConvertToPixels() returns true.
	 * @param height a height in points.
	 * @return the corresponding height in pixels, not less than 1.
	 */
	public int scaleHeight(double height)
	{
		int v = (int)(height*yscale);
		if (v == 0 && height != 0) v = 1;
		return v;
	}
	/**
	 * Given a PointRect convert to the corresponding pixel Rect,
	 * but this will only work if canConvertToPixels() returns true.
	 * @param pr the area in points.
	 * @param dest an optional destination Rect.
	 * @return the corresponding area in pixels in the dest Rect or a new Rect.
	 */
//	===================================================================
	public Rect scaleToPixels(PointRect pr, Rect dest)
//	===================================================================
	{
		if (dest == null) dest = new Rect();
		dest.set((int)(pr.x*xscale),(int)(pr.y*yscale),(int)(pr.width*xscale),(int)(pr.height*yscale));
		if (dest.width == 0 && pr.width != 0) dest.width = 1;
		if (dest.height == 0 && pr.height != 0) dest.height = 1;
		return dest;
	}
	
	static PixelBuffer pb;
	private PixelBuffer _getPixelBuffer(double width, double height, int options)
	{
		int w = (int)(width*xscale);
		int h = (int)(height*yscale);
		if (w == 0) w = 1;
		if (h == 0) h = 1;
		if (pb == null) pb = new PixelBuffer(w,h);
		else pb.resizeTo(w,h,null);
		return pb;
	}
	/**
	 * Set the current Pen for the PointGraphics.
	 * @param c the Color of the Pen.
	 * @param style the style of the Pen which should be one of the eve.fx.Pen style values.
	 * @param thickness the horizontal and vertical width of the pen in points.
	 */
	public void setPen(Color c, int style, double thickness)
	{
		setPen(c,style,thickness,thickness,(float)10);
	}
	/**
	 * Draw a full ImageData object scaled to a particular size.
	 * @param src the source ImageData.
	 * @param x the x co-ordinate for the top left corner of the image.
	 * @param y the y co-ordinate for the top left corner of the image.
	 * @param width the scaled full width of the image.
	 * @param height the scaled full height of the image.
	 * @param scaleOptions scale options - none are currently defined.
	 */
	public void drawImageData(ImageData src, double x, double y, double width, double height, int scaleOptions)
	{
		drawImageData(src,x,y,width,height,null,scaleOptions);
	}
	/**
	 * Draw text at a particular location.
	 * @param x the x co-ordinate of the left side of the first character.
	 * @param y the y co-ordinate of the top of first character. The text base line
	 * will be lower than this value equal to the ascent of the font.
	 */
	public void drawText(String text, double x, double y)
	{
		drawText(Vm.getStringChars(text),0,text.length(),x,y);
	}
//	-------------------------------------------------------------------
	private void drawTextIn(StringList lines,PointRect where,int alignment,int start,int count)
//	-------------------------------------------------------------------
	{
		PointFontMetrics fm = font;
		double h = fm.getHeight(), leading = fm.getLeading();
		double y = where.y;
		SubString ss = (SubString)Cache.get(SubString.class);
		try{
			for (int i = 0; i<count; i++){
				lines.get(i+start,ss);
				if (i != 0) y += leading;
				/*
				if (true){
					String check = ss.toString();
					if (check.equals("Registration")){
						System.out.println("Fm: "+fm.getFont());
						System.out.println(fm.getTextWidth(ss.data,ss.start,ss.length));
					}
				}
				*/
				double w = fm.getTextWidth(ss.data,ss.start,ss.length);
				double xp = where.x;
				if (alignment == RIGHT) xp += where.width-w;
				else if (alignment == CENTER) xp += (where.width-w)/2;
				drawText(ss.data,ss.start,ss.length,xp,y);
				y += h;
			}
		}finally{
			Cache.put(ss);
		}
	}
	/**
	* Modify subArea so that it is anchored appropriately in largeArea.
	* anchor should be NORTH, SOUTH, etc.
	**/
//	===================================================================
	public static void anchor(PointRect subArea,PointRect largeArea,int anchor)
//	===================================================================
	{
		subArea.x = ((largeArea.width-subArea.width)/2);
		subArea.y = ((largeArea.height-subArea.height)/2);
		if ((anchor & WEST) != 0) subArea.x = 0;
		else if ((anchor & EAST) != 0) subArea.x = largeArea.width-subArea.width;
		if ((anchor & NORTH) != 0) subArea.y = 0;
		else if ((anchor & SOUTH) != 0) subArea.y = largeArea.height-subArea.height;
		subArea.x += largeArea.x;
		subArea.y += largeArea.y;
	}
	/**
	 * Draw text in a certain area, aligned and anchored appropriately.
	 * @param lines the text to draw.
	 * @param where the bounding rectangle of the text.
	 * @param alignment the alignment of the text relative to each other. This
	 * should be LEFT, RIGHT, CENTER
	 * @param anchor the anchor of the text within the rectangle. This should be NORTH, SOUTH, etc.
	 * @param startLine the first line to draw.
	 * @param count the number of lines to draw.
	 */
//	===================================================================
	public void drawText(StringList lines,PointRect where,int alignment,int anchor,int startLine,int count)
//	===================================================================
	{
		PointFontMetrics fm = font;
		PointRect pr = PointRect.getCached();
		try{
			fm.getTextSize(lines,startLine,count,pr);
			anchor(pr,where,anchor);
			drawTextIn(lines,pr,alignment,startLine,count);
		}finally{
			pr.cache();
		}
	}
	/**
	 * Draw text in a certain area, aligned and anchored appropriately.
	 * @param lines the text to draw.
	 * @param x the x co-ordinate of the bounding rectangle.
	 * @param y the y co-ordinate of the bounding rectangle.
	 * @param width the width of the bounding rectangle.
	 * @param height the height of the bounding rectangle.
	 * @param alignment the alignment of the text relative to each other. This
	 * should be LEFT, RIGHT, CENTER
	 * @param anchor the anchor of the text within the rectangle. This should be NORTH, SOUTH, etc.
	 */
//	===================================================================
	public void drawText(StringList lines,double x, double y, double width, double height, int alignment,int anchor)
//	===================================================================
	{
		PointRect pr = PointRect.getCached(x,y,width,height);
		try{
			drawText(lines,pr,alignment,anchor,0,lines.size());
		}finally{
			pr.cache();
		}
	}
	
	private AffineTransform tf = new AffineTransform();
	
	private double [] tfBuffer = new double[6];
	
	private void restoreTransform(Object saved)
	{
		if (g.canTransform() && saved != null)
			g.restoreTransform(saved);
	}
	/*
	private boolean set(AffineTransform tf)
	{
		synchronized(tfBuffer){
			tf.getMatrix(tfBuffer);
			return setTransform(tfBuffer);
		}
	}
	*/
	/**
	 * Don't use this directly. Instead use a TransformState Object to
	 * manipulate the transformations of a PointGraphics.
	 */
	public AffineTransform getTransform(AffineTransform dest)
	{
		if (dest == null) dest = new AffineTransform();
		dest.set(tf);
		return dest;
	}
	/**
	 * Don't use this directly. Instead use a TransformState Object to
	 * manipulate the transformations of a PointGraphics.
	 */
	public AffineTransform getTransform()
	{
		return getTransform(null);
	}
	/**
	 * Don't use this directly. Instead use a TransformState Object to
	 * manipulate the transformations of a PointGraphics.
	 */
	public AffineTransform setTransform(AffineTransform at, AffineTransform old)
	{
		old = getTransform(old);
		tf.set(at);
		if (canvas != null){
			canvas.setTransform(tf);
		}
		return old;
	}
	void restoreTransform(AffineTransform at)
	{
		tf.set(at);
		if (canvas != null){
			canvas.setTransform(tf);
		}
		//set(tf);
	}
	/**
	 * Don't use this directly. Instead use a TransformState Object to
	 * manipulate the transformations of a PointGraphics.
	 */
	public AffineTransform setTransform(AffineTransform at)
	{
		return setTransform(at,null);
	}
	/*
	public AffineTransform translate(double tx, double ty, AffineTransform old)
	{
		if (old == null) old = new AffineTransform();
		old.set(tf);
		tf.translate(tx,ty);
		set(tf);
		return old;
	}
	*/
	/**
	 * Get a TransformState for this PointGraphics to manipulate
	 * the transformations. If you make any changes
	 * make sure you call restore() on the Transform state when done.
	 */
	public TransformState getTransformState(TransformState dest)
	{
		if (dest == null) dest = new TransformState();
		dest.getFrom(this);
		return dest;
	}
	/**
	 * Get a TransformState for this PointGraphics to manipulate
	 * the transformations. If you make any changes
	 * make sure you call restore() on the Transform state when done.
	 */
	public TransformState getTransformState()
	{
		return getTransformState(null);
	}
	
	private GeneralPath myPath;
	
	public void addToPath(double x, double y) {
		if (canvas != null){
			canvas.addToPath(x,y);
			return;
		}
		if (myPath == null) myPath = new GeneralPath();
		myPath.addToPath(x, y);
	}
	public void addToPath(double x1, double y1, double x2, double y2,
			double x3, double y3) {
		if (canvas != null){
			canvas.addToPath(x1,y1,x2,y2,x3,y3);
			return;
		}
		if (myPath == null) myPath = new GeneralPath();
		myPath.addToPath(x1,y1,x2,y2,x3,y3);
	}
	public void closePath() {
		if (canvas != null){
			canvas.closePath();
			return;
		}
		if (myPath == null) myPath = new GeneralPath();
		myPath.closePath();
	}
	public void startPath(double x, double y) {
		if (canvas != null){
			canvas.startPath(x,y);
			return;
		}
		myPath = new GeneralPath();
		myPath.startPath(x, y);
	}
	private double[] toDoubles(Object floats)
	{
		float[] xf = (float[])floats;
		double[] x = new double[xf.length];
		for (int i = 0; i<x.length; i++) x[i] = (double)xf[i];
		return x;
	}
	public void paintPath(boolean useBrush, boolean usePen)
	{
		if (!usePen && !useBrush) return;
		if (canvas != null){
			canvas.paintPath(useBrush, usePen);
			return;
		}
		if (myPath == null) return;
		boolean usePolygon = useBrush || myPath.isClosed();
		Object[] both = myPath.getLines(!usePolygon, 0);
		double[] x = toDoubles(both[0]);
		double[] y = toDoubles(both[1]);
		if (usePolygon) paintPolygon(x, y, 0, 0, x.length, useBrush, usePen);
		else if (usePen) drawLines(x, y, 0, 0, x.length, false);
	}
}
//####################################################
