/*
 * Created on Apr 28, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class TableCell extends DataCell{

{
	setSpacing(72.0/36);
	borderThickness = 0.5;
}

}

//####################################################
