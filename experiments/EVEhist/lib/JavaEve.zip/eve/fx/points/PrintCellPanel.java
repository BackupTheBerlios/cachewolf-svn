/*
 * Created on Mar 12, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

import java.util.Iterator;

import eve.fx.Dimension;
import eve.util.Grid;
import eve.util.IteratorEnumerator;
import eve.util.ObjectIterator;
import eve.util.TagList;
import eve.util.mVector;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class PrintCellPanel extends PrintCell{
	
	PrintCell tail;
	/**
	 * Adds a child control to this container - you should not generally use
	 * this method. Instead you would use the addNext()/addLast() of a Panel.
	 */
//	===================================================================
	protected void add(PrintCell control)
//	===================================================================
	{
		if (control.alreadyAdded) throw new RuntimeException("Cell already added: "+control.getClass());
		control.alreadyAdded = true;
		// set children, next, prev, tail and parent
		control.next = null;
		if (children == null)
			children = control;
		else
			tail.next = control;
		control.prev = tail;
		tail = control;
		//if (tail == null) new Exception().printStackTrace();
		control.parent = this;
	}

	/** Returns the child located at the given x and y coordinates. */
	public PrintCell findChild(double x, double y)
	{
		PrintCellPanel container;
		PrintCell child;

		container = this;
		while (true){
			child = container.tail;
			while (child != null && !child.contains(x, y))
				child = child.prev;
			if (child == null) return container;
			if (!(child instanceof PrintCellPanel)) return child;
			x -= child.x;
			y -= child.y;
			container = (PrintCellPanel)child;
		}
	}
	

//	===================================================================
	public boolean isEmpty()
//	===================================================================
	{
		return grid == null;
	}

//	===================================================================
	public PrintCell add(PrintCell c,double x,double y,double width,double height)
//	===================================================================
	{
		return addNext(c).setTag(TAG_RECT,new PointRect(x,y,width,height));
	}
//	===================================================================
	public PrintCell addNext(PrintCell c,boolean last)
//	===================================================================
	{
		if (grid == null) grid = new Grid();
		grid.add(c,last);
		lastAdded = c;
		if (c != null) {
			if ((defaultAddToMeCellConstraints & DONTCHANGE) == 0)
				c.setCell(defaultAddToMeCellConstraints);
			all = mVector.add(all,c);
		}
		return c;
	}
//	===================================================================
	public PrintCell addLast(PrintCell c) {return addNext(c,true);}
	public PrintCell addNext(PrintCell c) {return addNext(c,false);}
	public PrintCell endRow() {if (grid != null) grid.endRow(); return this;}
//	===================================================================
//	===================================================================
	public PrintCell addNext(PrintCell c,int cellConstraints)
//	===================================================================
	{
		return addNext(c).setCell(cellConstraints);
	}
//	===================================================================
	public PrintCell addLast(PrintCell c,int cellConstraints)
//	===================================================================
	{
		return addLast(c).setCell(cellConstraints);
	}
//	===================================================================
	public PrintCell addNext(PrintCell c,int cellConstraints,int controlConstraints)
//	===================================================================
	{
		return addNext(c).setCell(cellConstraints).setControl(controlConstraints);
	}
//	===================================================================
	public PrintCell addLast(PrintCell c,int cellConstraints,int controlConstraints)
//	===================================================================
	{
		return addLast(c).setCell(cellConstraints).setControl(controlConstraints);
	}
	protected java.util.Vector all;
	/**
	* Use this to add a control directly to the Panel. It makes it a child control
	* immediately.
	**/
//	===================================================================
	public void addDirectly(PrintCell c)
//	===================================================================
	{
		add(c);
		all = mVector.add(all,c);//all.add(c);
	}
//	===================================================================
	public Iterator getSubControls() {return all == null ? new ObjectIterator(null) : all.iterator();}
//	==================================================================
	public Iterator getChildren() {return new CellIterator(children,false);}
	public Iterator getChildrenBackwards() {return new CellIterator(tail,true);}
//	##################################################################
	class CellIterator extends IteratorEnumerator{
//	##################################################################

	PrintCell current;
	boolean back;
	public CellIterator(PrintCell first,boolean backwards)
	{
		current = first;	
		back = backwards;
	}
	public boolean hasNext() {return current != null;}
	public Object next() {PrintCell c = current; if (c != null) current = back ? c.prev:c.next; return c;}

//	##################################################################
	}
//	##################################################################
	/**
	The default cell constraints when controls are added to the Panel. The default value
	is STRETCH
	**/
	public int defaultAddToMeCellConstraints = STRETCH;

	protected PrintCell lastAdded = null;
//	-------------------------------------------------------------------
	protected boolean made = false;
	protected boolean calculated = false;
	protected double titleGap = 0;
	/**
	 * This is not a drawn border, this is the gap between the boundaries of this
	 * Cell and the contained cells.
	 */
	public double borderWidth = 0;
//	-------------------------------------------------------------------
	
protected Grid grid;// = new Grid();
	
	
public boolean equalWidths = false;
public boolean equalHeights = false;

static PointInsets noInsets = new PointInsets(0,0,0,0);
static Dimension autoSpan = new Dimension(-1,-1);

TagList defaultTags = null;

public void setDefaultTag(int id, Object value)
{
	if (defaultTags == null) defaultTags = new TagList();
	defaultTags.set(id,value);
}
//===================================================================
public Object getControlTag(int tag,PrintCell c,Object defaultValue)
//===================================================================
{
	if (c.hasTag(tag)) return c.getTag(tag,defaultValue);
	if (defaultTags == null) return defaultValue;
	return defaultTags.getValue(tag,defaultValue);
}

	//##################################################################
	class Layout extends Grid implements PrintCellConstants{
	//##################################################################
	public double preferredWidth, preferredHeight, minWidth, minHeight;
	double [] widths, heights, minWidths, minHeights;
	boolean [] growColumns, shrinkColumns, growRows, shrinkRows;
	PrintCellPanel panel;
	//===================================================================
	public Layout(PrintCellPanel panel){this.panel = panel;}
	//===================================================================
	//===================================================================
	public PointRect getPreferredSize(PointRect d)
	//===================================================================
	{
		if (d == null) d = new PointRect();
		d.width = preferredWidth;
		d.height = preferredHeight;
		return d;
	}	
	//===================================================================
	public void calculate()
	//===================================================================
	{
	//..................................................................
		widths = new double [columns];
		minWidths = new double[columns];
		growColumns = new boolean[columns];
		shrinkColumns = new boolean[columns];
		heights = new double [rows];
		minHeights = new double[rows];
		growRows = new boolean[rows];
		shrinkRows = new boolean[rows];
		double maxW = 0, maxH = 0;
		for (int i = 0; i<rows; i++) {
			growRows[i] = shrinkRows[i] = false;
			minHeights[i] = heights[i] = 0;
		}
		for (int i = 0; i<columns; i++) {
			growColumns[i] = shrinkColumns[i] = false;
			minWidths[i] = widths[i] = 0;
		}
		PointRect d = new PointRect();
		double [] sizes = new double[6];
	//..................................................................
		for (int r = 0; r<rows; r++)
			for (int c = 0; c<columns; c++){
				LayoutEntry le = (LayoutEntry)objectAt(r,c);
				if (le == null) continue;
				PrintCell cn = le.control;
				/*
				if ((le.control instanceof Panel) && !(le.control instanceof PrintCellPanel))
						new Exception().printStackTrace();
				*/
				cn.getSizes(sizes);
				d.width = sizes[0]; d.height = sizes[1];
				boolean closed = /*cn.hasModifier(cn.AddToPanelClosed,false) || */((cn.constraints & INITIALLY_CLOSED) != 0);
				if (closed) d.width = d.height = 0;
				else if ((cn.constraints & INITIALLY_MINIMIZED) != 0){
					d.width = sizes[2]; d.height = sizes[3];
					closed = true;
				}else if ((cn.constraints & INITIALLY_PREFERRED_SIZE) != 0){
					closed = true;
				}
				PointInsets in = (PointInsets)panel.getControlTag(TAG_INSETS,cn,panel.noInsets);
				boolean empty = d.width <= 0 || d.height <= 0;
				if (!empty) {
					d.width += in.left+in.right;
					d.height += in.top+in.bottom;
				}else{
					d.width = d.height = 0;
				}
				double w = d.width/le.width;
				if (w <= 0 && !empty) w = 1;
				double h = d.height/le.height;
				if (h <= 0 && !empty) h = 1;
				//......................................................
				// A preferred width or height of 0 will result in the control occupying NO space
				// even if it has insets.
				//......................................................
				if (widths[c] < w) {
					widths[c] = w;
					if (maxW < w) maxW = w;
				}
				if (heights[r] < h) {
					heights[r] = h;
					if (maxH < h) maxH = h;
				}
				if ((w != 0 && h != 0) || closed){
					if ((cn.constraints & HGROW) != 0) growColumns[c] = true;
					if ((cn.constraints & HSHRINK) != 0) shrinkColumns[c] = true;
					if ((cn.constraints & VGROW) != 0) growRows[r] = true;
					if ((cn.constraints & VSHRINK) != 0) shrinkRows[r] = true;
				}
				double mw = sizes[2], mh = sizes[3];
				if (!shrinkColumns[c]) mw = w;
				if (!shrinkRows[r]) mh = h;
				if (minWidths[c] < mw) minWidths[c] = mw;
				if (minHeights[r] < mh) minHeights[r] = mh;
			}
		//..................................................................
		if (panel.equalWidths) for (int i = 0; i<columns; i++) widths[i] = maxW;
		if (panel.equalHeights) for (int i = 0; i<rows; i++) heights[i] = maxH;
		preferredWidth = sum(widths);
		preferredHeight = sum(heights);
		minWidth = sum(minWidths);
		minHeight = sum(minHeights);
	}	
	//===================================================================
	public void autospan(boolean horizontally)
	//===================================================================
	{
		for (int r = 0; r<rows; r++){
			for (int c = 0; c<columns; c++){
				LayoutEntry le = (LayoutEntry)objectAt(r,c);
				if (le == null) continue;
				if (le.topLeft != le) continue;
				PrintCell cn = le.control;
				Dimension d = (Dimension)panel.getControlTag(TAG_SPAN,cn,PrintCellPanel.autoSpan);
				if (d.width < 0 && horizontally){
					while(true){
						if ((c+le.width) >= columns) break; //Already extends to the end.
						boolean all = true;
						for (int i = 0; i<le.height; i++)
							if (objectAt(r+i,c+le.width) != null) all = false;
						if (!all) break; // All of the cells to the right are not unoccupied.
						//......................................................
						// Expand it now.					
						//......................................................
						le.width++;
						for (int rr = 0; rr<le.height; rr++)
							for (int cc = 0; cc<le.width; cc++)
								if (cc != 0 || rr != 0)
									set(r+rr,c+cc,le.getSubEntry());
					}
				}
				if (d.height < 0 && !horizontally){
					while(true){
						if ((r+le.height) >= rows) break; //Already extends to the end.
						boolean all = true;
						for (int i = 0; i<le.width; i++)
							if (objectAt(r+le.height,c+i) != null) all = false;
						if (!all) break; // All of the cells to the right are not unoccupied.
						//......................................................
						// Expand it now.					
						//......................................................
						le.height++;
						for (int rr = 0; rr<le.height; rr++)
							for (int cc = 0; cc<le.width; cc++)
								if (cc != 0 || rr != 0)
									set(r+rr,c+cc,le.getSubEntry());
					}
				}
			}

		}
	}	
	//-------------------------------------------------------------------
	protected int howMany(boolean [] use)
	//-------------------------------------------------------------------
	{
		int total = 0;
		for (int i = 0; i<use.length; i++)
			if (use[i]) total++;
		return total;
	}	
	//-------------------------------------------------------------------
	protected double sum(double [] values,boolean [] use)
	//-------------------------------------------------------------------
	{
		double total = 0;
		for (int i = 0; i<values.length && i<use.length; i++)
			if (use[i]) total += values[i];
		return total;
	}
	//-------------------------------------------------------------------
	protected double sum(double [] values)
	//-------------------------------------------------------------------
	{
		double total = 0;
		for (int i = 0; i<values.length; i++) total += values[i];
		return total;
	}
	//-------------------------------------------------------------------
	protected double [] scaleAcross(double [] values,boolean [] use,double newValue)
	//-------------------------------------------------------------------
	{
		double original = sum(values);
		double diff = newValue-original;
		double [] scaled = new double[values.length];
		int num = howMany(use);
		double total = sum(values,use);
		if (total == 0) total = num;
		double left = diff;
		int did = 0;
		for (int i = 0; i<scaled.length; i++){
			scaled[i] = values[i];
			if (use[i]) {
				double ch = (diff*values[i])/total;
				if (did == num-1) ch = left;
				scaled[i] += ch;
				left -= ch;
				did++;
			}
		}
		return scaled;
	}
	boolean firstTime = true;
	/*
	//===================================================================
	void splitterSetTo(PanelSplitter sp,int x,int y,int dx,int dy,int width,int height)
	//===================================================================
	{
		Dimension d = new Dimension();
		int idx = panel.all != null ? panel.all.indexOf(sp) : -1;
		if (idx < 1 || idx >= panel.all.size()-1) return;
		PrintCell one = sp.before, two = sp.after;
		if (sp.type == sp.VERTICAL){
			if (firstTime){
				if (widths[idx-1] == 0) widths[idx-1] = one.getPreferredSize(d).width;
				if (widths[idx+1] == 0) widths[idx+1] = two.getPreferredSize(d).width;
			}
			int left = x;
			int right = width-(x+sp.width);
			if (curWidths != null){
				curWidths[0] = left;
				curWidths[1] = sp.width;
				curWidths[2] = right;
			}
			fitInto(one,dx,dy,left,height,one.getPreferredSize(d));
			fitInto(sp,dx+x,dy+y,sp.width,height,sp.getPreferredSize(d));
			fitInto(two,dx+(width-right),dy,right,height,two.getPreferredSize(d));
			int nt = right+left;
			if (nt == 0) return;
			int before = widths[idx-1]+widths[idx+1];
			widths[idx-1] = (before*left)/nt;
			widths[idx+1] = before-widths[idx-1];
		}else{
			if (firstTime){
				if (heights[idx-1] == 0) heights[idx-1] = one.getPreferredSize(d).height;
				if (heights[idx+1] == 0) heights[idx+1] = two.getPreferredSize(d).height;
			}
			int top = y;
			int bottom = height-(y+sp.height);
			if (curHeights != null){
				curHeights[0] = top;
				curHeights[1] = sp.height;
				curHeights[2] = bottom;
			}
			fitInto(one,dx,dy,width,top,one.getPreferredSize(d));
			fitInto(sp,dx+x,dy+y,width,sp.height,sp.getPreferredSize(d));
			fitInto(two,dx,dy+(height-bottom),width,bottom,two.getPreferredSize(d));
			int nt = top+bottom;
			if (nt == 0) return;
			int before = heights[idx-1]+heights[idx+1];
			heights[idx-1] = (before*top)/nt;
			heights[idx+1] = before-heights[idx-1];
		}
		firstTime = false;
		panel.repaintNow();
	}	
	*/
	double curWidths [], curHeights [];
	/*
	String toString(double[] d)
	{
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		for (int i = 0; i<d.length; i++){
			if (i != 0) sb.append(",");
			sb.append(d[i]);
		}
		sb.append("]");
		return sb.toString();
	}
	*/
	//===================================================================
	public void setRect(double dx,double dy,double width,double height)
	//===================================================================
	{
		double [] scaledWidths = widths;
		double [] scaledHeights = heights;
		double pw = preferredWidth;
		double ph = preferredHeight;
		boolean fixedWidth = false, fixedHeight = false;
		/*
		if (curWidths != null && splitter != null){
			if (splitter.state != 0){
				if (splitter.type == splitter.HORIZONTAL){
					fixedHeight = true;
					scaledHeights = curHeights;
					boolean fixBefore = false;
					if (splitter.state == splitter.OPENED)
						fixBefore = ((splitter.openType & splitter.BEFORE) != 0);
					else if (splitter.state == splitter.CLOSED)
						fixBefore = ((splitter.closeType & splitter.BEFORE) != 0);
					if (fixBefore) curHeights[2] = height-curHeights[0]-curHeights[1];
					else curHeights[0] = height-curHeights[2]-curHeights[1];
				}	
				else if (splitter.type == splitter.VERTICAL){
					fixedWidth = true;
					scaledWidths = curWidths;
					boolean fixBefore = false;
					if (splitter.state == splitter.OPENED)
						fixBefore = ((splitter.openType & splitter.BEFORE) != 0);
					else if (splitter.state == splitter.CLOSED)
						fixBefore = ((splitter.closeType & splitter.BEFORE) != 0);
					if (fixBefore) curWidths[2] = width-curWidths[0]-curWidths[1];
					else curWidths[0] = width-curWidths[2]-curWidths[1];
				}	
			}else{
				if (splitter.type == splitter.HORIZONTAL){
					fixedHeight = true;
					scaledHeights = curHeights;
					int t = curHeights[0]+curHeights[2];
					//curHeights[1] is the height of the splitter itself.
					if (t > 0){
						int left = height;
						curHeights[0] = (curHeights[0]*(height-curHeights[1]))/t;
						curHeights[2] = height-curHeights[1]-curHeights[0];
					}
				}else{
					fixedWidth = true;
					scaledWidths = curWidths;
					int t = curWidths[0]+curWidths[2];
					//curWidths[1] is the width of the splitter itself.
					if (t > 0){
						int left = width;
						curWidths[0] = (curWidths[0]*(width-curWidths[1]))/t;
						curWidths[2] = width-curWidths[1]-curWidths[0];
					}
				}
			}
		}
		*/
		if (!fixedWidth){
			if (pw > width) 
				scaledWidths = scaleAcross(widths,shrinkColumns,width);
			else if (pw < width)
				scaledWidths = scaleAcross(widths,growColumns,width);
		}
		if (!fixedHeight){
			if (ph > height)
				scaledHeights = scaleAcross(heights,shrinkRows,height);
			else if (ph < height)
				scaledHeights = scaleAcross(heights,growRows,height);
		}
//..................................................................
		PointRect d = new PointRect();
		for (int r = 0; r<rows; r++)
			for (int c = 0; c<columns; c++){
				LayoutEntry le = (LayoutEntry)objectAt(r,c);
				if (le == null) continue;
				if (le.topLeft == le){
					double x = 0, y = 0;
					for (int xx = 0; xx<c; xx++) x+=scaledWidths[xx];
					for (int yy = 0; yy<r; yy++) y+=scaledHeights[yy];
					double w = 0, h = 0;
					for (int xx = c; xx<c+le.width; xx++) w += scaledWidths[xx];
					for (int yy = r; yy<r+le.height; yy++) h += scaledHeights[yy];
					if (le.control != null) fitInto(le.control,dx+x,dy+y,w,h,le.control.getPreferredSize(d));
				}
			}
//..................................................................
		curWidths = scaledWidths;
		curHeights = scaledHeights;
//..................................................................
	}	

	//-------------------------------------------------------------------
	protected void fitInto(PrintCell c,double x,double y,double w,double h,PointRect p)
	//-------------------------------------------------------------------
	{
		//System.out.println(p);
		//if (panel instanceof mTabbedPanel && panel.debugFlag && c instanceof CardPanel) ((Object)null).toString();
		PointInsets in = (PointInsets)panel.getControlTag(TAG_INSETS,c,panel.noInsets);
		x += in.left; y += in.top;
		w -= (in.left+in.right); 
		h -= (in.top+in.bottom);
		int con = c.constraints;
		if (w > 0 && h > 0){
			double myW = p.width, myH = p.height;
			if (myW > w && ((con & HCONTRACT) != 0)) myW = w;
			if (myW < w && ((con & HEXPAND) != 0)) myW = w;
			if (myH > h && ((con & VCONTRACT) != 0)) myH = h;
			if (myH < h && ((con & VEXPAND) != 0)) myH = h;
		
			if ((con & RIGHT) != 0) x += (w-myW);
			else if ((con & LEFT) != 0);
			else x += (w-myW)/2;
			
			if ((con & BOTTOM) != 0) y += (h-myH);
			else if ((con & TOP) != 0);
			else y += (h-myH)/2;
			
			w = myW;
			h = myH;
		}
		PointRect pr = (PointRect)c.getTag(TAG_RECT,null);
		if (pr == null){
			//System.out.println(new PointRect().set(x,y,w,h));
			c.setRect(x,y,w,h);
		}else
			c.setRect(pr.x,pr.y,pr.width,pr.height);
		//c.setLocation(x,y);
		//c.requestResizeTo(w,h);
	}	
	}
	
//	===================================================================
	public void make(PointGraphics ps)
//	===================================================================
	{
		super.make(ps);
		/*
		if (font == null && parent != null) font = parent.font;
		if (font == null) font = getFont();
		font = null;// I don't actually want to setup the font now.
		*/
		
		if (all != null)
			for (int i = 0;i<all.size();i++) {
				PrintCell c = (PrintCell)all.get(i);
				add(c);
				//if (c.font == null) c.font = font; 
				c.make(ps);
			}
		makeLayoutGrid();
		if (defaultTags != null)
			if (defaultTags.size() == 0) 
				defaultTags = null;
		getPreferredSize(null);
		//if (backgroundImage != null) modifyAll(Transparent,0,false);
		made = true;
	}
//	===================================================================
	protected void calculateSizes()
//	===================================================================
	{
		preferredWidth = preferredHeight = 0;
		if (layout != null) {
			if (!calculated) {
				layout.calculate();
				PointRect d = layout.getPreferredSize(new PointRect());
				preferredWidth = d.width+borderWidth*2;
				preferredHeight = d.height+borderWidth*2;
				minWidth = layout.minWidth+borderWidth*2;
				minHeight = layout.minHeight+borderWidth*2;
			}else {
				//Dimension d = layout.getPreferredSize(new Dimension());
				PointRect d = new PointRect();
				//int [] hs = new int[grid.rows];
				if (grid != null)
					for (int r = 0; r<grid.rows; r++){
						double w = 0;
						double h = 0;
						for (int c = 0; c<grid.columns; c++){
							PrintCell ct = (PrintCell)grid.objectAt(r,c);
							if (ct == null) continue;
							ct.getPreferredSize(d);
							w += d.width;
							if (d.height > h) h = d.height;
						}
						if (w > preferredWidth) preferredWidth = w;
						preferredHeight += h;
					}
			}
			/*
			if (text != null)
				if (text.length() != 0) {
					FontMetrics fm = getFontMetrics();
					preferredHeight += (titleGap = fm.getHeight()+4);
					int wd = fm.getTextWidth(text);
					if ((wd+14) > preferredWidth) preferredWidth = wd+14;
				}
				*/
			calculated = true;
		}
	}

//	===================================================================
	public void resizeTo(double width, double height) 
//	===================================================================
	{
		this.width = width;
		this.height = height;
		/* This does not work - was trying to temporarily remove the layout.
		if (made && layout == null) {
			makeLayoutGrid();
			if (layout != null) {
				layout.calculate();
				layout.getPreferredSize(null);
				getPreferredSize(null);
			}
		}
		*/
		if (layout != null) {
			layout.setRect(borderWidth,borderWidth+titleGap,this.width-borderWidth*2,this.height-titleGap-borderWidth*2);
			//Find a good way 
		}
	}

	Layout layout;
//	-------------------------------------------------------------------
	protected Grid makeLayoutGrid()
//	-------------------------------------------------------------------
	{
		if (grid == null) return null;
		layout = new Layout(this);
		calculated = false;
		modify(0,CalculatedSizes);
		int dr = 0, dc = 0;
//	..................................................................
		if (grid != null)
			for (int r = 0; r<grid.rows; r++){
				dc = 0;
				for (int c = 0; c<grid.columns; c++){
					while(layout.objectAt(dr,dc) != null) dc++;
					PrintCell tc = (PrintCell)grid.objectAt(r,c);
					if (tc == null) continue;
					Dimension d = (Dimension)getControlTag(TAG_SPAN,tc,autoSpan);
					LayoutEntry first = null;
					int sw = d.width; if (sw < 1) sw = 1;
					int sh = d.height; if (sh < 1) sh = 1;
					for (int w = 0; w<sw; w++){
						for (int h = 0; h<sh; h++){
							if (first == null) {
								first = new LayoutEntry();
								first.topLeft = first;
								first.row = dr; first.column = dc;
								first.width = sw; first.height = sh;
								first.control = tc;
								layout.set(dr+h,dc+w,first);
							}else
								layout.set(dr+h,dc+w,first.getSubEntry());
						}
					}
					dc++;
				}
				dr++;
			}
		layout.autospan(true);
		layout.autospan(false);
		return layout;
	}

	
}
//####################################################
