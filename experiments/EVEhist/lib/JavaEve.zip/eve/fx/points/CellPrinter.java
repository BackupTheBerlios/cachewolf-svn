/*
 * Created on May 7, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;


/**
 * @author Michael L Brereton
 *
 */
//####################################################
public abstract class CellPrinter implements PrintCellConstants, PointDrawable{

	private PrintCellPanel currentCell;
	protected PageFormat page = new PageFormat();
	private boolean setupComplete = false;
	/**
	 * Normally after a the print() method is called the free() method is
	 * called. If this is true, then it will not be called.
	 */
	public boolean dontFreeAfterPrint = false;
	//
	public PrintCell getCurrentCell()
	{
		return currentCell;
	}
	public void setPageFormat(PageFormat pf)
	{
		if (pf != null) page = (PageFormat)pf.getCopy();
	}
	protected PageFormat getCurrentPage()
	{
		return page;
	}
	protected void completeSetup(PointGraphics pg)
	{
		if (setupComplete) return;
		if (currentCell != null){
			currentCell.make(pg);
			currentCell.setRect(0,0,page.fullPageWidth,page.fullPageHeight);
		}
		setupComplete = true;
	}
	//
	/**
	 * Setup the PrintCells within the CellPrinter.
	 * Use getCurrentPage() to get the current page format. Do not alter
	 * that PageFormat. After you complete the setup you can either return
	 * or you can call completeSetup() after which the absolute positions
	 * of all the cells would be set. You can then make any changes as may be
	 * necessary before returning. 
	 */
	protected abstract void setupForPage(PointGraphics pg);
	
	private double xdpi = -1, ydpi = -1;
	
	public final void setup(PointGraphics pg, PageFormat format)
	{
		xdpi = pg.getXdpi();
		ydpi = pg.getYdpi();
		reset(format);
		setupForPage(pg);
		completeSetup(pg);
	}
	//
	protected void addCell(PrintCell cell, PointRect location)
	{
		if (currentCell == null){
			currentCell = new PrintCellPanel();
		}
		currentCell.add(cell,location.x,location.y,location.width,location.height);
	}
	protected PrintCellPanel addFullImageablePanel()
	{
		PrintCellPanel pcp = new PrintCellPanel();
		addCell(pcp,new PointRect(page.imageableX,page.imageableY,page.imageableWidth,page.imageableHeight));
		return pcp;
	}
	protected PrintCellPanel addMarginedPanel(double top, double left, double bottom, double right)
	{
		PrintCellPanel pcp = new PrintCellPanel();
		addCell(pcp,new PointRect(left,top,page.fullPageWidth-left-right,page.fullPageHeight-top-bottom));
		return pcp;
	}
	
	protected void reset(PageFormat format)
	{
		free();
		page = (PageFormat)format.getCopy();
	}
	public void free()
	{
		setupComplete = false;
		currentCell = null;
	}
	public final void doPrint(PointGraphics pg)
	{
		doPrint(pg,new PointRect(0,0,page.fullPageWidth,page.fullPageHeight));
	}
	
	public boolean isSetupFor(double xdpi, double ydpi)
	{
		return this.xdpi == xdpi && this.ydpi == ydpi;
	}
	/**
	 * This will call setup() if the PointGraphics is a different DPI to
	 * that when previously called, or if setup() has not been called at all.
	 * @param pg the PointGraphics to draw on.
	 */
	public void checkSetup(PointGraphics pg)
	{
		if (currentCell == null || !isSetupFor(pg.getXdpi(),pg.getYdpi())){
			setup(pg,getCurrentPage());
		}
	}
	public synchronized void doPrint(PointGraphics pg,PointRect area)
	{
		checkSetup(pg);
		if (currentCell != null) {
			currentCell.doPaint(pg,area);
			currentCell.doPaintChildren(pg,area);
		}
		if (!dontFreeAfterPrint) free();
	}
	public void print(PointGraphics pg, PageFormat pf)
	{
		setup(pg,pf);
		doPrint(pg);
	}
	public void draw(PointGraphics pg, PointRect area)
	{
		boolean was = dontFreeAfterPrint;
		dontFreeAfterPrint = true;
		doPrint(pg,area);
		dontFreeAfterPrint = was;
	}
}
//####################################################
