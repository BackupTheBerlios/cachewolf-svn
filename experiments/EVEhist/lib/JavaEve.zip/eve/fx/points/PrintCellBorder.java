/*
 * Created on Apr 25, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class PrintCellBorder 
{
	public PointPen top, left, bottom, right;
 
	public PrintCellBorder(PointPen top, PointPen left, PointPen bottom, PointPen right)
	{
		this.top = top;
		this.left = left;
		this.bottom = bottom;
		this.right = right;
	}
}
//####################################################
