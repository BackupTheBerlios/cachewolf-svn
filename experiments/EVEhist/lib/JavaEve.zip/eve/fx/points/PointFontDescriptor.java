package eve.fx.points;

import java.io.BufferedReader;
import java.io.IOException;

import eve.data.PropertyList;
import eve.fx.Color;
import eve.fx.Font;
import eve.fx.FontMetrics;
import eve.fx.Fx;
import eve.fx.Graphics;
import eve.fx.Image;
import eve.fx.Metrics;
import eve.sys.Convert;
import eve.sys.Vm;
import eve.util.IntArray;
import eve.util.mString;

public class PointFontDescriptor extends PropertyList{

	public static final int FLAG_FIXED_PITCH = 0x1;
	public static final int FLAG_SERIF = 0x2;
	public static final int FLAG_SYMBOLIC = 0x4;
	public static final int FLAG_SCRIPT = 0x8;
	//0x10 is undefined.
	public static final int FLAG_NON_SYMBOLIC = 0x20;
	public static final int FLAG_ITALIC = 0x40;
	//
	public static final int FLAG_ALL_CAP = 0x10000;
	public static final int FLAG_SMALL_CAP =  0x20000;
	public static final int FLAG_FORCE_BOLD = 0x40000;
	public static final int FLAG_PDF_FLAGS_MASK = 0x7ffff;
	//
	/**
	 * If this flag value is not specified, the font is specified as a TrueType
	 * font.
	 */
	public static final int FLAG_TYPE_1 = 0x80000000;
	/**
	 * Set this true to disable Type1 fonts completely.
	 */
	public static boolean disableType1 = false;
	public PointFont font;
	//Font bigFont;
	//FontMetrics bigFontMetrics;
	int ascent;
	int descent;
	int leading;
	int firstChar;
	int lastChar;
	int[] widths;
	int missingWidth;
	boolean fixedWidth;
	
	protected boolean resolved = false;
	/**
	 * When calculating the widths of characters a standard FontMetrics is
	 * used and the value returned is multiplied by this value and then
	 * fontCorrectionConstant is added to that. By default this value is 1.
	 */
	public static double defaultFontCorrectionFactor = 1;
	/**
	 * When calculating the widths of characters a standard FontMetrics is
	 * used and the value returned is multiplied by fontCorrectionFactor and then
	 * this is added to that. By default this value is 0.
	 */
	public static double defaultFontCorrectionConstant = 0;
	
	/**
	 * When calculating the widths of characters a standard FontMetrics is
	 * used and the value returned is multiplied by this value and then
	 * fontCorrectionConstant is added to that. By default this value is 
	 * defaultFontCorrectionFactor.
	 */
	public double fontCorrectionFactor = defaultFontCorrectionFactor;
	/**
	 * When calculating the widths of characters a standard FontMetrics is
	 * used and the value returned is multiplied by fontCorrectionFactor and then
	 * this is added to that. By default this value is
	 * defaultFontCorrectionConstant.
	 */
	public double fontCorrectionConstant = defaultFontCorrectionConstant;
	
	/**
	 * Call this before calling setWidths().
	 * @param factor the new fontCorrectionFactor.
	 * @param constant thenew fontCorrectionConstant.
	 */
	public void setFontWidthCorrection(double factor, double constant)
	{
		fontCorrectionFactor = factor;
		fontCorrectionConstant = constant;
	}
	public static String getUnspacedName(String name)
	{
		char[] s = Vm.getStringChars(name);
		char[] d = new char[s.length];
		int dd = 0;
		for (int i = 0; i<s.length; i++)
			if (s[i] != ' ') d[dd++] = s[i];
		return new String(d,0,dd);
	}
	public PointFontDescriptor(String name, int fontStyle, int firstChar, int lastChar)
	{
		this(new PointFont(name,fontStyle,10));
		setWidths(firstChar, lastChar, null, -1);
	}
	public PointFontDescriptor(PointFont baseFont)
	{
		this(baseFont,0,null);
	}
	public double getAscent(double forSize)
	{
		return (ascent*forSize)/1000;
	}
	public double getDescent(double forSize)
	{
		return (descent*forSize)/1000;
	}
	public double getLeading(double forSize)
	{
		return (leading*forSize)/1000;
	}
	public double getTextWidth(String s,double forSize)
	{
		return getTextWidth(Vm.getStringChars(s),0,s.length(),forSize);
	}
	public double getTextWidth(char[] data, int offset, int length, double forSize)
	{
		boolean db = false;//new String(data,offset,length).equals("Registration");
		double tot = 0;
		for (int i = 0; i<length; i++){
			char c = data[offset++];
			if (c < firstChar || c > lastChar) {
				if (c >= 32) tot += missingWidth;
			}
			else tot += widths[c-firstChar];
			if (db) System.out.print(" "+tot);
		}
		if (db) System.out.println();
		return (tot*forSize)/1000;
	}
	public double getCharWidth(char c, double forSize)
	{
		if (c < firstChar || c > lastChar){
			if (c < 32) return 0;
			return (missingWidth*forSize)/1000;
		}
		else return (widths[c-firstChar]*forSize)/1000;
	}
	
	private PointFont resolveFont;
	private int resolveFlags;
	private String resolveBaseName;
	/**
	 * Create a PointFontDescriptor from a PointFont and setup the initial
	 * values of Ascent, Descent, Leading, CapHeight, ItalicAngle etc.
	 * After calling this then call setWidths() to set additional metrics.
	 * Then you can explicitly set values as need be.
	 * @param baseFont the PointFont specifying the name and style of the Font.
	 * @param flags additional Flags.
	 * @param optionalBaseName Normally the name is taken from the baseFont name
	 * (with spaces removed)
	 * with "Bold"/"Italic"/"BoldItalic" added as necessary, (preceded by a comma). 
	 * However if this is not null it will be used instead as is, with no modifications
	 * for Bold/Italic. 
	 */
	public PointFontDescriptor(PointFont baseFont, int flags, String optionalBaseName)
	{
		resolveFont = baseFont;
		resolveFlags = flags;
		resolveBaseName = optionalBaseName;
	}
	
	protected void resolve(PointFont baseFont, int flags, String optionalBaseName)
	{
		font = baseFont;
		int s = font.getStyle();
		boolean bold = (s & Font.BOLD) != 0;
		boolean italic = (s & Font.ITALIC) != 0;
		if (italic) flags |= FLAG_ITALIC;
		try{
			Font bigFont = Metrics.getFontForHeight(1000,Fx.getFontMetrics(new Font(baseFont.getName(),baseFont.getStyle(),10)));
			FontMetrics bigFontMetrics = Fx.getFontMetrics(bigFont);
			if (Fx.isMonospaced(bigFont)) flags |= FLAG_FIXED_PITCH;
			setInt("Ascent",ascent = bigFontMetrics.getAscent());
			setInt("Descent",-1*(descent = bigFontMetrics.getDescent()));
			setInt("Leading",leading = bigFontMetrics.getLeading());
			setInt("CapHeight",bigFontMetrics.getAscent());
		}catch(Throwable t){}
		//
		if ((flags & FLAG_SYMBOLIC) == 0) flags |= FLAG_NON_SYMBOLIC;
		setInt("Flags",flags & FLAG_PDF_FLAGS_MASK);
		if ((flags & FLAG_ITALIC) != 0)
			setInt("ItalicAngle",-11);
		else
			setInt("ItalicAngle",0);
		set("Encoding", "/WinAnsiEncoding");
		String fn = optionalBaseName;
		if (fn == null) {
			fn = getUnspacedName(baseFont.getName());
			if (bold && italic) fn += ",BoldItalic";
			else if (bold) fn += ",Bold";
			else if (italic) fn += ",Italic";
		}
		set("FontName","/"+fn);
		set("BaseFont","/"+fn);
		set("Subtype",((flags & FLAG_TYPE_1) != 0) ? "/Type1" : "/TrueType");
	}
	private static Image imageBuffer;
	/**
	 * Tell the PointFontDescriptor to calculate and set the widths for
	 * the specified character range.
	 * @param first the first character in the range inclusive.
	 * @param last the last character in the range inclusive.
	 */
	public void setWidths(int first, int last)
	{
		setWidths(first,last,null,-1);
	}
	private static String widthsToString(int[] v)
	{
		StringBuffer sb = new StringBuffer();
		int max = v.length;
		sb.append("[ ");
		for (int i = 0; i<max; i++){
			sb.append(v[i]);
			sb.append(" ");
		}
		sb.append("] ");
		return sb.toString();
	}
	/**
	 * Set or calculate the values for the character widths of the specified
	 * range of characters. The width values must be that if the height of
	 * the font was 1000 points.
	 * @param first the first character in the range inclusive.
	 * @param last the last character in the range inclusive.
	 * @param values an int array with an entry for each item, or null
	 * to calculate the widths.  
	 * @param missingWidth the value to assign to missing widths. If it is -1
	 * then a default value will be used.
	 */
	public void setWidths(int first, int last, int[] values, int missingWidth)
	{
		int[] v = null;
		if (values == null) {
			synchronized(PointFontDescriptor.class){
				v = new int[last+1-first];
				if (true){
					Font bigFont = Metrics.getFontForHeight(1000,Fx.getFontMetrics(new Font(font.getName(),font.getStyle(),10)));
					FontMetrics bigFontMetrics = Fx.getFontMetrics(bigFont);
					int w = 100, h = 100;
					if (imageBuffer == null) imageBuffer = new Image(w,h);
					Graphics g = new Graphics(imageBuffer);
					int xo = w/4, yo = h/4;
					Font f = Metrics.getFontForHeight(h/2, bigFontMetrics);
					g.setColor(Color.White);
					g.fillRect(0, 0, w, h);
					g.setColor(Color.Black);
					g.setFont(f);
					for (int i = first; i<=last; i++){
						int cw = bigFontMetrics.getCharWidth((char)i);
						cw = (int)(cw*fontCorrectionFactor + fontCorrectionConstant);
						if (v != null) v[i-first] = cw; 
						//g.drawChar((char)i, xo, yo, 0);
					}
					g.setColor(Color.LighterBlue);
					g.drawRect(xo,yo,w/2,h/2);
					if (missingWidth == -1) missingWidth = bigFontMetrics.getCharWidth(' ');
				}
			}
			values = v;
		}
		setInt("FirstChar",this.firstChar = first);
		setInt("LastChar",this.lastChar = last);
		if (values == null) values = v;
		widths = (int[])values.clone();
		set("Widths",widthsToString(widths));
		if (missingWidth != -1) {		
			setInt("MissingWidth",this.missingWidth = missingWidth);
		}
		set("FontBBox","[ -250 -212 1217 1000 ]");
		setInt("StemV",80);
		setInt("StemH",80);
	}
	/*
	 *These MUST start and end with a '|' 
	 */
	private static final String textValues =
		"|FontName|FamilyName=FontFamily|CharacterSet=CharSet|";
	private static final String numberValues = 
		"|ItalicAngle|CapHeight|XHeight|Ascender=Ascent|Descender=Descent"+
		"|StdVW=StemV|";
	private static final String arrayValues = 
		"|FontBBox|";
	private static final int TYPE_PLAIN = 0;
	private static final int TYPE_ARRAY = 1;
	private static final int TYPE_STRING = 2;
	boolean checkKeywords(String key, String lookIn, String fullLine, int type)
	{
		for (int s = 0;;s++){
			int idx = lookIn.indexOf(key,s);
			if (idx == -1) return false;
			if (lookIn.charAt(idx-1) == '|'){
				int end = idx+key.length();
				char c = lookIn.charAt(end);
				if (c == '='){
					idx = end+1;
					end = lookIn.indexOf('|',idx);
				}
				if (lookIn.charAt(end) != '|') continue;
				String data = fullLine.substring(key.length()).trim();
				if (type == TYPE_STRING) data = "/"+data;
				else if (type == TYPE_ARRAY) data = "[ "+data+" ]";
				set(lookIn.substring(idx,end),data);
				return true;
			}
		}
	}
	private void doCharMetrics(BufferedReader afmFile,AfmFileSpecs specs) throws IOException
	{
		missingWidth = specs == null ? 0 : specs.missingWidth;
		FontMetrics bigFontMetrics = null;
		if (specs != null && specs.localFont != null){
			Font bigFont = Metrics.getFontForHeight(1000,Fx.getFontMetrics(new Font(specs.localFont.getName(),specs.localFont.getStyle(),10)));
			bigFontMetrics = Fx.getFontMetrics(bigFont);
		}
		firstChar = -1;
		int prevChar = -1, prevWidth = 0;
		IntArray ia = new IntArray(256,20);
		while(true){
			String line = afmFile.readLine();
			if (line == null) break; 
			if (line.startsWith("EndCharMetrics")) break;
			String [] all = mString.split(line,';');
			int wx = 0;
			int ci = -1;
			for (int av = 0; av < all.length; av++){
				String v = all[av].trim();
				if (v.startsWith("C ")){
					ci = Convert.parseInt(v.substring(2).trim());
				}else if (v.startsWith("CH ")){
					v = v.substring(3).trim();
					int end = v.indexOf('>');
					v = v.substring(1,end);
					ci = Convert.parseInt(v,16);
				}else if (v.startsWith("WX ")){
					v = v.substring(3).trim();
					wx = Convert.parseInt(v);
				}
			}
			if (ci < 0) break;
			if (firstChar < 0) firstChar = ci;
			else {
				for (int cc = prevChar+1; cc < ci; cc++){
					int cw = missingWidth;
					if (fixedWidth && prevWidth != 0)
						cw = prevWidth;
					else if (bigFontMetrics != null)
						cw = bigFontMetrics.getCharWidth((char)cc);
					ia.append(cw);
				}
			}
			prevChar = ci;
			prevWidth = wx;
			ia.append(wx);
		}
		lastChar = firstChar+ia.length-1;
		widths = ia.toIntArray();
		setInt("FirstChar",firstChar);
		setInt("LastChar",lastChar);
		set("Widths",widthsToString(widths));
		if (missingWidth >= 0) {		
			setInt("MissingWidth",missingWidth);
		}
		if (bigFontMetrics != null) setInt("Leading",bigFontMetrics.getLeading());
	}
	
	public static class AfmFileSpecs{
		/**
		 * If not null this will be used to determine missing
		 * character widths.
		 */
		public PointFont localFont;
		/**
		 * If this is not negative this will be used as the
		 * missingWidth value.
		 */
		public int missingWidth;
	}
	/**
	 * Create a PointFontDescriptor from an afmFile.
	 * @param afmFile the afmFile.
	 * @param specs an optional AfmFileSpecs used to fill in data
	 * that may be missing in the afmFile.
	 * @throws IOException
	 */
	public PointFontDescriptor(BufferedReader afmFile,AfmFileSpecs specs) throws IOException
	{
		resolve(afmFile,specs);
	}
	
	
	protected void resolve(BufferedReader afmFile,AfmFileSpecs specs) throws IOException
	{
		int flags = 0;
		boolean started = false;
		while(true){
			String line = afmFile.readLine();
			if (line == null) break; 
			if (!started) started = line.startsWith("StartFontMetrics");
			if (!started) continue;
			String[] all = mString.split(line,' ');
			if (all.length < 2) continue;
			String key = all[0];
			if (checkKeywords(key, textValues, line, TYPE_STRING)) continue;
			if (checkKeywords(key, arrayValues, line, TYPE_ARRAY)) continue;
			if (checkKeywords(key, numberValues, line, TYPE_PLAIN)) continue;
			if (key.equalsIgnoreCase("StartCharMetrics")){
				doCharMetrics(afmFile,specs);
				break;
			}
			if (key.equals("IsFixedPitch")){
				if (all[1].equalsIgnoreCase("true"))
					fixedWidth = true;
				continue;
			}
		}
		set("BaseFont",getString("FontName", ""));
		set("Subtype","/Type1");
		if (getInt("ItalicAngle",0) != 0) flags |= FLAG_ITALIC;
		if (getString("CharSet","").equals("/Special"))
			flags |= FLAG_SYMBOLIC;
		else
			flags |= FLAG_NON_SYMBOLIC;
		if (fixedWidth) flags |= FLAG_FIXED_PITCH;
		setInt("Flags",flags);
		ascent = getInt("Ascent", 0);
		descent = -getInt("Descent", 0);
		ascent = 1000-descent;
		leading = getInt("Leading", 0);
	}
	/**
	 * Resolve the PointFontDescriptor before actual use. This may be called
	 * multiple times, the resolution will only occur once.
	 * @param firstChar the first character to calculate widths for if necessary.
	 * @param lastChar the last character to calculate widths for if necessary.
	 * @throws IOException
	 */
	public synchronized void resolve(int firstChar, int lastChar)
	{
		if (!resolved) try{
			if (!disableType1 && (resolveFlags & FLAG_TYPE_1) != 0){
				AfmFileSpecs specs = new AfmFileSpecs();
				specs.localFont = resolveFont;
				try{
					BufferedReader br = FontManager.openAFMFile(resolveBaseName);
					resolve(br,specs);
					br.close();
					return;
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			resolve(resolveFont,resolveFlags,resolveBaseName);
			setWidths(firstChar, lastChar);
		}finally{
			resolved = true;
		}
	}
	/**
	 * Resolve the PointFontDescriptor before actual use. This may be called
	 * multiple times, the resolution will only occur once.
	 * @throws IOException
	 */
	public synchronized void resolve()
	{
		resolve(firstChar,lastChar);
	}
}
