/*
 * Created on May 6, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

import eve.fx.Font;
import eve.util.StringList;

/**
 * This class represents a Font where the size of the Font is specified as a fractional number of
 * points (1/72 of an inch). Or where the size of the Font is determined given a fixed set of text
 * that must fit within a fixed area specified in points.
 *
 */
//####################################################
public class PointFont {

	String name;
	int style;
	double size;
	double fitWidth;
	double fitHeight;
	String[] fitData;
	private double pointSize = -1;
	
	/** A plain font style. */
	public static final int PLAIN  = Font.PLAIN;
	/** A bold font style. */
	public static final int BOLD   = Font.BOLD;
	/** An italic font style. */
	public static final int ITALIC = Font.ITALIC;
	/** An underlined font style. */
	public static final int UNDERLINE = Font.UNDERLINE;
	/** An outlined font style. */
	public static final int OUTLINE = Font.OUTLINE;
	/** A strikethrough font style. */
	public static final int STRIKETHROUGH = Font.STRIKETHROUGH;
	/** A superscript font style. */
	public static final int SUPERSCRIPT = Font.SUPERSCRIPT;
	/** A subscript font style. */
	public static final int SUBSCRIPT = Font.SUBSCRIPT;
	/**
	 * Create a new Font.
	 * @param name the name of the Font.
	 * @param style any of the font styles ORed together. 
	 * @param size the size (height) of the Font in points.
	 */
	public PointFont(String name, int style, double size)
	{
		if (size < 0) throw new IllegalArgumentException();
		this.name = name;
		this.style = style;
		this.size = size;
	}
	private PointFont(double size,String name,int style)
	{
		this.name = name;
		this.style = style;
		this.size = size;
	}
	/**
	 * Specify a Font such that the size of the Font will be determined at runtime when applied to a
	 * PointGraphics object using setFont(). The size of the Font will be determined such that the
	 * text provided (which may be multilined text) must fit within a specified width and height.
	 * @param name the name of the Font.
	 * @param style any of the font styles ORed together. 
	 * @param text the Text that must fit within the specified area.
	 * @param width the width of the text area in points. 
	 * Set this to a negative value if you are only interested in the height of the data.
	 * @param height the height of the text area in points.
	 * Set this to a negative value if you are only interested in the width of the data.
	 */
	public PointFont(String name, int style, StringList text, double width, double height)
	{
		size = -1;
		this.name = name;
		this.style = style;
		fitWidth = width;
		fitHeight = height;
		fitData = text.toStringArray();
	}
	/**
	 * Return the name of the Font.
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * Return the style of the Font.
	 */
	public int getStyle()
	{
		return style;
	}
	/**
	 * Return the size of the font as rendered on a specific PointGraphics. If the constructor
	 * was used that specified explicitly the size of the font, then that explicit value will
	 * be returned. Otherwise the size of the font required for the text specified on creation
	 * to fit into the dimensions as specified during creation will be determined and returned. 
	 * @param pg The destination PointGraphics.
	 * @return the point size of the Font.
	 */
	public double getSize(PointGraphics pg)
	{
		return pg.getSize(this);
	}
	/**
	 * Return the size of the font only if it was explicitly set. If it was not explicitly
	 * set then this will throw an IllegalStateException. To get the size if it was not
	 * explicitly set use getSize(PointGraphics pg);
	 * @return the explicit size set in the contstructor if any.
	 */
	public double getSize()
	{
		//if (size == 0) throw new IllegalStateException("The size was not explicitly set.");
		if (size > 0) return size;
		throw new IllegalStateException("The size was not explicitly set.");
	}
	/**
	 * Return the size of the font as if it would be rendered on an ideal device.
	 * If the size was originally specified in the constructor then it is returned,
	 * otherwise if the size is calculated based on fitting the specified text
	 * in the specified space. 
	 */
	public double getPointSize(PointFontDescriptor pd)
	{
		if (size > 0) return pointSize = size;
		if (pointSize < 0){
			int fh = 1000;
			int fl = pd.leading;
			double lp = (double)fl/fh; // Leading as fraction of height.
			double maxHeight = -1;  
			int n = fitData.length;
			if (fitHeight >= 0){
				maxHeight = fitHeight/(n+lp*(n-1));
			}
			if (fitWidth > 0){
				double biggest = 0;
				for (int i = 0; i<n; i++){
					double sz = pd.getTextWidth(fitData[i],1000);
					if (sz > biggest) biggest = sz;
				}
				if (biggest != 0){
					double hh = (fitWidth*fh)/biggest;
					if (maxHeight < 0 || hh < maxHeight) maxHeight = hh;
				}
				//System.out.println(maxHeight);
			}
			pointSize = maxHeight;
		}
		return pointSize;
	}
	/**
	 * Return a new PointFont with the same size as this PointFont, but with a different style.
	 * @param newStyle the style for the new font.
	 * @return a new PointFont with a different style.
	 */
	public PointFont changeStyle(int newStyle)
	{
		PointFont pf = new PointFont(size,name,newStyle);
		if (pf.size < 0){
			pf.fitData = fitData;
			pf.fitHeight = fitHeight;
			pf.fitWidth = fitWidth;
		}
		return pf;
	}
	/**
	 * Return a new PointFont with the same name and style as this PointFont, but with a different size.
	 * @param newSize the size for the new font in points.
	 * @return a new PointFont with a different size.
	 */
	public PointFont changeSize(double newSize)
	{
		return new PointFont(name,style,newSize);
	}
	/**
	 * Return a new PointFont with the same name as this PointFont, but with a different size and style.
	 * @param newStyle the style for the new font.
	 * @param newSize the size for the new font in points.
	 * @return a new PointFont with a different size and style.
	 */
	public PointFont change(int newStyle,double newSize)
	{
		return new PointFont(name,newStyle,newSize);
	}
	/**
	 * Return a new PointFont with the same name and style as this PointFont, but with a different size 
	 * as specified by the text which must fit into the specified dimensions.
	 * @param newText the new text.
	 * @param fitWidth the width of the area in points that the text must fit in.
	 * @param fitHeight the height of the area in points that the text must fit in.
	 * @return a new PointFont with a different size and style.
	 */
	public PointFont changeSize(StringList newText, double fitWidth, double fitHeight)
	{
		return new PointFont(name,style,newText,fitWidth,fitHeight);
	}
	/**
	 * Return a new PointFont with the same name and style as this PointFont, but with a different size 
	 * as specified by the text which must fit into the specified dimensions.
	 * @param newStyle the style for the new font.
	 * @param newText the new text.
	 * @param fitWidth the width of the area in points that the text must fit in.
	 * @param fitHeight the height of the area in points that the text must fit in.
	 * @return a new PointFont with a different size and style.
	 */
	public PointFont change(int newStyle,StringList newText, double fitWidth, double fitHeight)
	{
		return new PointFont(name,newStyle,newText,fitWidth,fitHeight);
	}
	public String toString()
	{
		return name+":"+size;
	}
	public int hashCode()
	{
		if (size < 0) return (int)(name.hashCode()*fitWidth*fitHeight*style);
		else return (int)(name.hashCode()*size*style);
	}
	/**
	 * Return if this Font is the same as another. This is quicker than equals()
	 * since no class cast is involved.
	 * @param f another Font.
	 * @return true if its name, size and style are the same as this one, false if not.
	 */
	public boolean isSame(PointFont f)
	{
		if (f == null) return false;
		if (f == this) return true;
		if (!name.equals(f.name) || style != f.style || size != f.size) return false;
		if (size >= 0) return true;
		if (fitWidth != f.fitWidth || fitHeight != f.fitHeight) return false;
		try{
			if (fitData.length != f.fitData.length) return false;
			for (int i = 0; i<fitData.length; i++)
				if (!fitData[i].equals(f.fitData[i])) return false;
			return true;
		}catch(Exception e){
			return false;
		}
	}
	public boolean equals(Object obj)
	{
		if (obj instanceof PointFont) return isSame((PointFont)obj);
		return super.equals(obj);
	}
}

//####################################################
