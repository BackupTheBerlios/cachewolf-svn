package eve.fx.points;

import eve.fx.Dimension;

	//##################################################################
	class LayoutEntry {
	//##################################################################
	
	public int row,column;
	public int width,height;
	public LayoutEntry topLeft;
	public PrintCell control;
	//===================================================================
	public Dimension getPreferredSize(Dimension d)
	//===================================================================
	{
		return d.set(50,20);//control.getPreferredSize(d);
	}	
	//===================================================================
	public LayoutEntry getSubEntry()
	//===================================================================
	{
		LayoutEntry le = new LayoutEntry();
		le.row = row; le.column = column;
		le.width = width; le.height = height;
		le.control = control;
		le.topLeft = this;
		return le;
	}	
	//##################################################################
	}
	//##################################################################

