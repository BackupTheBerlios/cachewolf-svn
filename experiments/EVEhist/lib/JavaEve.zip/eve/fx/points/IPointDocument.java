package eve.fx.points;

public interface IPointDocument {

	/**
	 * Prepare a font for possible use in the document - the font need not correspond to any local
	 * font since the descriptor is provided.
	 * @param font
	 * @param descriptor
	 */
	public void prepareFont(PointFont font, PointFontDescriptor descriptor);
}
