package eve.fx.points;

import eve.fx.Font;
/**
 * Used for hashing Fonts based on name and (BOLD/ITALIC) styles only.
 */
public class FontEntry {
	private String name;
	private int style;
	
	public String getName() {return name;}
	public int getBoldItalicStyle() {return style;}
	
	public FontEntry set(PointFont f)
	{
		name = PointFontDescriptor.getUnspacedName(f.getName());
		style = f.getStyle() & (Font.BOLD|Font.ITALIC);
		return this;
	}
	public FontEntry set(Font f)
	{
		name = PointFontDescriptor.getUnspacedName(f.getName());
		style = f.getStyle() & (Font.BOLD|Font.ITALIC);
		return this;
	}
	public FontEntry set(String name, int boldItalicStyle)
	{
		this.name = PointFontDescriptor.getUnspacedName(name);
		style = boldItalicStyle & (Font.BOLD|Font.ITALIC);
		return this;
	}
	public int hashCode()
	{
		return name.hashCode()+style*1234377;
	}
	public boolean equals(Object other)
	{
		FontEntry fe = (FontEntry)other;
		if (!fe.name.equals(name)) return false;
		return style == fe.style;
	}

}
