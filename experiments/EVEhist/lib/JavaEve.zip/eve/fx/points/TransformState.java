/*
 * Created on Jan 15, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class TransformState {

private AffineTransform original = new AffineTransform();
private AffineTransform at = new AffineTransform();
//private AffineTransform buff = new AffineTransform();
private PointGraphics pg;

	public TransformState()
	{
		
	}
	public TransformState(PointGraphics g)
	{
		getFrom(g);
	}
	public TransformState getFrom(PointGraphics g)
	{
		pg = g;
		g.getTransform(original);
		at.set(original);
		return this;
	}
	public TransformState restore()
	{
		pg.restoreTransform(original);
		at.set(original);
		return this;
	}
	/**
	 * Get the current transform for this TransformState.
	 * @param dest a destination AffineTransform. If it is null a new one
	 * will be created and returned.
	 * @return the destination AffineTransform or a new created one if it was null.
	 */
	public AffineTransform getTransform(AffineTransform dest)
	{
		if (dest == null) dest = new AffineTransform();
		dest.set(at);
		return dest;
	}
	/*
	public TransformState getCurrentState(TransformState dest)
	{
		if (dest == null) dest = new TransformState();
		dest.getFrom(pg);
		return dest;
	}
	*/
	private TransformState update()
	{
		pg.setTransform(at);
		return this;
	}
	/**
	 * Translate the PointGraphics associated with this TransformState.
	 * @param tx the change in x-coordinate.
	 * @param ty the change in y-coordinate.
	 * @return this TransformState
	 */
	public TransformState translate(double tx, double ty)
	{
		at.translate(tx,ty);
		return update();
	}
	/**
	 * Rotate about 0,0 by an angle of theta radians clockwise.
	 * @param theta the angle to rotate in radians clockwise.
	 * @return this TransformState.
	 */
	public TransformState rotate(double theta)
	{
		at.rotate(theta);
		return update();
	}
	/**
	 * Rotate about cx,cy by an angle of theta radians clockwise.
	 * @param theta the angle to rotate in radians clockwise.
	 * @return this TransformState.
	 */
	public TransformState rotate(double theta, double cx, double cy)
	{
		at.rotate(theta,cx,cy);
		return update();
	}
	public TransformState rotatePageRightAngle(int rotateType,double pageWidth,double pageHeight)
	{
		at.rotatePageRightAngle(rotateType,pageWidth,pageHeight);
		return update();
	}
	public TransformState rotateRightAngle(int rotateType,double cx,double cy)
	{
		at.rotateRightAngle(rotateType,cx,cy);
		return update();
	}
	public TransformState rotateRightAngle(int rotateType)
	{
		at.rotateRightAngle(rotateType);
		return update();
	}
}
//####################################################
