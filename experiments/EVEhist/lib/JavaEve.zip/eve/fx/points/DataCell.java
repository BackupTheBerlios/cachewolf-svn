/*
 * Created on Apr 28, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

import eve.sys.ImageData;
import eve.util.StringList;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class DataCell extends PrintCell{

public String text = "";
public PointImage image = null;
public int alignment;
public int anchor = WEST;
public int rotation = 0;

public static final int ROTATE_NONE = AffineTransform.TRANSFORM_ROTATE_NONE;
public static final int ROTATE_90 = AffineTransform.TRANSFORM_ROTATE_90;
public static final int ROTATE_180 = AffineTransform.TRANSFORM_ROTATE_180;
public static final int ROTATE_270 = AffineTransform.TRANSFORM_ROTATE_270;

{
	//setSpacing(72.0/16);
}
public DataCell(){}
public DataCell(String text)
{
	setText(text);
}
public DataCell(PointImage image)
{
	this.image = image;
}
public DataCell(ImageData im, double width, double height)
{
	setImage(im,width,height);
}
/**
 * Set the image using a source ImageData. You should set either width or height
 * or both to a valid point value. If one of these is zero or less, then its value
 * will be calculated from the other so as to keep the original aspect ratio.
 * @param im the ImageData.
 * @param width the width in points for the Image. 
 * @param height the height in points for the Image.
 */
public void setImage(ImageData im, double width, double height)
{
	image = new PointImageAdapter(im,width,height);
}
protected void calculateSizes()
{
	if (pointGraphics != null){
		if (image == null){
			PointRect pr = getTextSize(getFont(),pointGraphics,PointRect.getCached());
			preferredHeight = pr.height+topSpace+bottomSpace;
			preferredWidth = pr.width+leftSpace+rightSpace;
			pr.cache();
		}else{
			preferredHeight = image.getPointHeight()+topSpace+bottomSpace;
			preferredWidth = image.getPointWidth()+topSpace+bottomSpace;
		}
		if (rotation == ROTATE_270 || rotation == ROTATE_90){
			double t = preferredHeight;
			preferredHeight = preferredWidth;
			preferredWidth = t;
		}
			
	}
}
public void getText(StringList destination)
{
	destination.split(text,'\n');
}
/*
public FontMetrics shrinkInto(FontMetrics baseFont, FontMetrics biggestSoFar, PointMetrics scaler)
{
	StringList sl = getCachedText();
	try{
		FontMetrics fm =  
			scaler.shrinkInto(width-leftSpace-rightSpace,height-topSpace-bottomSpace,
					sl.toBestText(), baseFont,biggestSoFar);
		return fm;
	}finally{
		sl.cache();
	}
}
*/
public DataCell setText(String text)
{
	this.text = text;
	return this;
}
public DataCell setTextPosition(int alignment, int anchor)
{
	this.alignment = alignment;
	this.anchor = anchor;
	return this;
}
//==================================================================
public void doPaint(PointGraphics g,PointRect r)
//==================================================================
{
	super.doPaint(g,r);
	PointRect me = getDim(PointRect.getCached());
	TransformState ts = null;
	if (rotation != ROTATE_NONE){
		ts = g.getTransformState();
		ts.rotateRightAngle(rotation,me.width/2,me.height/2);
	}
	try{
		me.width -= leftSpace+rightSpace;
		me.height -= topSpace+bottomSpace;
		me.x += leftSpace;
		me.y += topSpace;
		try{
			if (image == null) {
				g.setFont(getFont());
				StringList sl = getCachedText();
				try{
					g.setColor(getForeground());
					g.drawText(sl,me.x,me.y,me.width,me.height,alignment,anchor);
					//System.out.println(text);
					//PointFont f = getFont();
					//pm.drawText(g,f,sl,me,alignment,anchor);
				}finally{
					sl.cache();
				}
			}else{
				double iw = image.getPointWidth(), ih = image.getPointHeight();
				double x = (me.width-iw)/2, y = (me.height-ih)/2;
				if ((anchor & NORTH) != 0) y = 0;
				else if ((anchor & SOUTH) != 0) y = me.height-ih; 
				if ((anchor & WEST) != 0) x = 0;
				else if ((anchor & EAST) != 0) x = me.width-ih;
				image.draw(g,me.x+x,me.y+y,r,0);
			}
		}finally{
			me.cache();
		}
	}finally{
		if (ts != null) ts.restore();
	}
	//double penSize = 72.0/36;
	//doBorder(g,penSize,Color.DarkBlue,Pen.SOLID,po,false,RECT_SIDE_FULL);
}

}
//####################################################
