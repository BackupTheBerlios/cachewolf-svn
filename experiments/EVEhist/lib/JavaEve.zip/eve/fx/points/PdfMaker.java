package eve.fx.points;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import eve.data.Property;
import eve.data.PropertyList;
import eve.fx.Brush;
import eve.fx.Color;
import eve.fx.Pen;
import eve.fx.Picture;
import eve.fx.Rect;
import eve.io.AsciiCodec;
import eve.io.DeflaterOutputStream;
import eve.io.Io;
import eve.io.TextCodec;
import eve.sys.Cache;
import eve.sys.Convert;
import eve.sys.ImageData;
import eve.sys.Vm;
import eve.util.ByteArray;
import eve.util.IntArray;
import eve.util.mString;


public class PdfMaker implements IPointDocument{

	static final char[] eol = "\r\n".toCharArray();
	public String version = "1.3";
	PdfOutputStream myStream;
	
	public PdfOutputStream getStream()
	{
		return myStream;
	}
	
	PdfObject addObject(PdfObject obj)
	{
		obj.sequenceNumber = ++curObject;
		xref.ensureCapacity(curObject+1);
		xref.length = curObject+1;
		return obj;
	}
	public static abstract class PdfObject {
		int sequenceNumber;
		int generation = 0;
		public PdfObject parent;
		public String getReference()
		{
			return sequenceNumber+" "+generation+" R";
		}
		protected void prepareForWrite()
		{
		}
		public void writeAsObject(PdfMaker maker) throws IOException
		{
			maker.write(this);
		}
		public abstract void writeContents(PdfOutputStream out) throws IOException;
	}
	
	public static class Stream extends PdfObject
	{
		protected byte[] outputData;
		protected boolean doDeflate = true;
		public Stream(byte[] data, int offset, int length, PdfMaker maker)
		{
			maker.addObject(this);
			if (!doDeflate){
				outputData = new byte[length];
				System.arraycopy(data, offset, outputData, 0, length);
			}else{
				ByteArray ba = (ByteArray)Cache.get(ByteArray.class);
				try{
					ba.clear();
					Io.deflate(data, offset, length, ba);
					outputData = ba.toBytes();
				}catch(IOException e){}
				Cache.put(ba);
			}
		}
		
		protected Stream() {}
		
		protected void writeExtra(PdfOutputStream out) throws IOException {
			
		}
		
		public void writeContents(PdfOutputStream out) throws IOException {
			out.write("<< ");
			writeExtra(out);
			out.write(" /Length "+outputData.length+" ");
			if (doDeflate) out.write("/Filter /FlateDecode ");
			out.writeln(">>");
			out.writeln("stream");
			out.write(outputData,0,outputData.length);
			out.writeln();
			out.writeln("endstream");
		}
	}
	public static class Image extends Stream
	{
		int width, height;
		public Image(ImageData src, Rect srcArea)
		{
			int w = src.getImageWidth();
			int h = src.getImageHeight();
			if (srcArea == null) srcArea = new Rect(0,0,w,h);
			width = srcArea.width;
			height = srcArea.height;
			try{
				ByteArrayOutputStream os = new ByteArrayOutputStream();
				DeflaterOutputStream dos = new DeflaterOutputStream(os);
				int[] s = new int[width];
				byte[] d = new byte[width*3];
				int x = srcArea.x;
				int y = srcArea.y;
				for (int i = 0; i<height; i++){
					src.getPixels(s, 0, x, y++, width, 1, w);
					int dp = 0;
					for (int p = 0; p<width; p++){
						int pix = s[p];
						d[dp++] = (byte)(pix >> 16);
						d[dp++] = (byte)(pix >> 8);
						d[dp++] = (byte)(pix);
					}
					dos.write(d);
				}
				dos.finish();
				dos.close();
				outputData = os.toByteArray();
				doDeflate = true;
			}catch(IOException e){}			
		}
		protected void writeExtra(PdfOutputStream output) throws IOException
		{
			output.write(" /Type /XObject /Subtype /Image /Width "+width+" /Height "+height);
			output.write(" /ColorSpace /DeviceRGB /BitsPerComponent 8");
		}
	}
	public static class Page extends PdfDictionary
	{
		PdfMaker myMaker;
		Hashtable fonts, images;
		double mediaHeight = 72*11;
		double mediaWidth = 72*8.5;
		PageFormat format;
		
		public PdfMaker getDocument()
		{
			return myMaker;
		}
		Page(PdfMaker m,PageFormat pf)
		{
			super("Page");
			if (pf == null) format = new PageFormat();
			else format = (PageFormat)pf.getCopy();
			m.addObject(this);
			myMaker = m;
			mediaWidth = format.fullPageWidth;
			mediaHeight = format.fullPageHeight;
			put("MediaBox", "[ "+0+" "+0+" "+mediaWidth+" "+mediaHeight+" ]");
		}
		/**
		 * Finish the page and commit it to the PDF file.
		 */
		public void finish() throws IOException
		{
			myMaker.write(myMaker.pages.addKid(this));
		}
		/**
		 * Cancel the page.
		 */
		public void cancel()
		{
			
		}
		public PointRect getFullSize(PointRect dest)
		{
			if (dest == null) dest = new PointRect();
			dest.set(0, 0, mediaWidth, mediaHeight);
			return dest;
		}
		public PageCanvas getCanvas()
		{
			PageCanvas pc = new PageCanvas(this);
			return pc;
		}
		String usingFont(String ref)
		{
			if (fonts == null) fonts = new Hashtable();
			Property p = (Property)fonts.get(ref);
			if (p != null) return p.name;
			p = new Property();
			p.name = "F"+(fonts.size()+1);
			p.value = ref;
			fonts.put(ref,p);
			return p.name;
		}
		String usingImage(String ref)
		{
			if (images == null) images = new Hashtable();
			Property p = (Property)images.get(ref);
			if (p != null) return p.name;
			p = new Property();
			p.name = "IM"+(images.size()+1);
			p.value = ref;
			images.put(ref,p);
			return p.name;
		}
		private IntArray contents = new IntArray();
		
		public void addStream(byte[] data)
		throws IOException
		{
			addStream(data,0,data.length);
		}
		public void addStream(byte[] data, int offset, int length)
		throws IOException
		{
			Stream s = new Stream(data,offset,length,myMaker);
			s.writeAsObject(myMaker);
			contents.add(s.sequenceNumber);
		}
		private static void addToResources(PdfDictionary dest, Hashtable h, String name)
		{
			if (h != null){
				PdfDictionary pd = new PdfDictionary();
				for (Enumeration e = h.elements(); e.hasMoreElements();){
					Property p = (Property)e.nextElement();
					pd.put(p.name, (String)p.value);
				}
				dest.putObject(name, pd);
			}
		}
		protected void prepareForWrite()
		{
			super.prepareForWrite();
			if (contents.length != 0){
				StringBuffer sb = new StringBuffer();
				sb.append("[ ");
				for(int i = 0; i<contents.length; i++)
					sb.append(contents.data[i]+" 0 R ");
				sb.append("]");
				put("Contents", sb.toString());
			}
			PdfDictionary resources = new PdfDictionary();
			addToResources(resources, fonts, "Font");
			addToResources(resources, images, "XObject");
			if (resources.size() != 0) putObject("Resources",resources);
		}
		
	}
	static class Node extends PdfDictionary
	{
		public Vector kids = new Vector();
		public Vector written = new Vector();
		public Node(String type)
		{
			super(type);
		}
		public void addKid(String toAdd)
		{
			kids.add(toAdd);
		}
		public PdfObject addKid(PdfObject toAdd)
		{
			toAdd.parent = this;
			kids.add(toAdd);
			return toAdd;
		}
		protected void prepareForWrite()
		{
			super.prepareForWrite();
			StringBuffer k = new StringBuffer();
			k.append("[ ");
			for (int i = 0; i<kids.size(); i++){
				if (i != 0) k.append(" ");
				Object got = kids.get(i);
				if (got instanceof PdfObject){
					k.append(((PdfObject)got).getReference());
				}else
					k.append(got);
			}
			k.append(" ]");
			put("Kids",k.toString());
			put("Count",Convert.toString(kids.size()));
		}
		
	}
	
	public static class PdfDictionary extends PdfObject{
	
		PropertyList ht = new PropertyList();
		
		public int size()
		{
			return ht.size();
		}
		public PdfDictionary(){}
		public PdfDictionary(String type)
		{
			if (type != null)
				put("Type","/"+type);
		}
		public void put(String key, String value)
		{
			if (value == null) value = "";
			ht.add("/"+key,value);
		}
		public void putObject(String key, PdfObject object)
		{
			ht.add("/"+key,object);
		}
		public void put(String key, int value)
		{
			ht.add("/"+key,Convert.toString(value));
		}
		public void putProperty(String key, PropertyList pl, String name, String defaultValue)
		{
			Property p = pl.get(name);
			if (p == null || p.value == null) {
				if (defaultValue != null) put(key,defaultValue);
			}else put(key,p.value.toString());
		}
		/** 
		 * Here the name of the property in the PropertyList is the same as
		 * the key.
		 */
		public void putProperty(String key, PropertyList pl, String defaultValue)
		{
			putProperty(key,pl,key,defaultValue);
		}
		/** 
		 * Here the name of the property in the PropertyList is the same as
		 * the key.
		 */
		public void putProperties(String keys, PropertyList pl)
		{
			String[] all = mString.split(keys,',');
			for (int i = 0; i<all.length; i++){
				Property p = pl.get(all[i]);
				if (p == null || p.value == null) continue;
				ht.add("/"+all[i],p.value);
			}
		}
		/*
		public void put(String key, PdfObject obj)
		{
			put(key,obj.getReference());
		}
		*/
		public void putReference(String key, PdfObject obj)
		{
			put(key,obj.getReference());
		}
		public void addAll(String list, char separator)
		{
			String[] a = mString.split(list,'|');
			for (int i = 0; i<a.length; i += 2){
				put(a[i],a[i+1]);
			}
		}
		public void writeContents(PdfOutputStream out) throws IOException
		{
			out.writeln("<<");
			for (Enumeration e = ht.elements(); e.hasMoreElements();){
				Property p = (Property)e.nextElement();
				out.write(p.name);
				out.write(" ");
				if (p.value instanceof PdfObject){
					PdfObject pp = (PdfObject)p.value;
					pp.prepareForWrite();
					pp.writeContents(out);
					out.writeln();
				}else
					out.writeln(p.value.toString());
			}
			out.writeln(">>");
		}
		protected void prepareForWrite()
		{
			if (parent != null)
				put("Parent",parent.getReference());
		}		
	}
	//Info is always object 1.
	public PdfDictionary info = new PdfDictionary();
	//Root is always object 2.
	public PdfDictionary root = new PdfDictionary("Catalog");
	//
	public PdfDictionary trailer = new PdfDictionary();
	//
	public Node pages = new Node("Pages");
	
	private int curObject = 0;
	
	public void write(PdfObject obj) throws IOException
	{
		PdfOutputStream out = myStream;
		obj.prepareForWrite();
		xref.data[obj.sequenceNumber] = out.curOffset;
		out.writeln(obj.sequenceNumber+" 0 obj");
		obj.writeContents(out);
		out.writeln("endobj");
	}
	public void startDocument() throws IOException
	{
		PdfOutputStream out = myStream;
		out.writeln("%PDF-"+version);
		write(info);
		write(root);
		trailer.put("Size",Convert.toString(curObject+1));
		trailer.putReference("Root",root);
		//trailer.put("Info",info);
	}
	public Page newPage(PageFormat pf) throws IOException
	{
		if (pf == null) pf = new PageFormat();
		Page p = new Page(this,pf);
		return p;
	}
	
	public PdfMaker()
	{
		addObject(info);
		addObject(root);
		addObject(pages);
		root.putReference("Pages",pages);
	}
	public static class PdfOutputStream{
		OutputStream out;
		TextCodec codec = new AsciiCodec();
		public PdfOutputStream(OutputStream out)
		{
			this.out = out;
		}
		public void write(byte[] data, int offset, int length) throws IOException
		{
			out.write(data,offset,length);
			curOffset += length;
		}
		ByteArray buffer = new ByteArray();
		char[] paddedBuffer = new char[10];
		public void write(String data) throws IOException
		{
			write(Vm.getStringChars(data), 0, data.length());
		}
		public void write(char[] data, int offset, int length) throws IOException
		{
			buffer.length = 0;
			codec.encodeText(data, offset, length, false, buffer);
			if (buffer.length != 0)
				write(buffer.data,0,buffer.length);
		}
		public void writeln() throws IOException 
		{
			write(eol,0,eol.length);
		}
		public void writeln(String data) throws IOException 
		{
			write(data);
			writeln();
		}
		public void writePaddedNumber(int value, int length) throws IOException
		{
			if (paddedBuffer == null || paddedBuffer.length < length)
				paddedBuffer = new char[length];
			for (int i = length; i>0; i--){
				paddedBuffer[i-1] = (char)('0'+(value%10));
				value /= 10;
			}
			write(paddedBuffer,0,length);
		}
		public void close() throws IOException
		{
			out.close();
		}
		public int curOffset;
	}
	
	PdfDictionary addDictionary(String type)
	{
		PdfDictionary pd = new PdfDictionary(type);
		addObject(pd);
		return pd;
	}
	public void open(OutputStream dest) throws IOException
	{
		myStream = new PdfOutputStream(dest);
		startDocument();
	}
	//
	IntArray xref = new IntArray();
	//
	public void writeXref() throws IOException
	{
		PdfOutputStream out = myStream;
		if (curObject == 0) {
			xref.ensureCapacity(1);
			xref.length = 1;
		}
		int now = out.curOffset;
		out.writeln("xref"); 
		out.writeln("0 "+xref.length);
		int[] d = xref.data;
		d[0] = 0;
		for (int i = 0; i<xref.length; i++){
			out.writePaddedNumber(d[i], 10);
			if (i != 0) out.writeln(" 00000 n");
			else out.writeln(" 65535 f");
		}
		out.writeln("trailer");
		trailer.writeContents(out);
		out.writeln("startxref");
		out.writeln(Convert.toString(now));
		out.writeln("%%EOF");
	}
	public static class PdfIOException extends RuntimeException{
		public PdfIOException(IOException e){
			super(e);
		}
	}
	public static class PageCanvas implements IPointCanvas {
		
		public Page getPage() {return myPage;}
		
		ByteArray myData = new ByteArray();
		byte[] buff = new byte[1024];
		double pointScale = 1;
		double [] tx = new double[6];
		StringBuffer s = new StringBuffer();
		PdfMaker myMaker;
		Page myPage;
		double mediaHeight;
		protected double fontAscent;
		protected double fontDescent;
		protected String curFont;
		protected double curFontSize;
		
		protected Color penColor = new Color(0,0,0);
		protected double penWidth = 1;
		protected int penStyle = Pen.SOLID|Pen.CAP_BUTT|Pen.JOIN_MITER;
		protected double penMiter = 2;
		//
		protected Color brushColor = new Color(0,0,0);
		protected int brushStyle = Brush.SOLID;
		protected int brushRule = Brush.RULE_NONZERO_WINDING;
		
		private void writeColor(Color c,String set)
		{
			append(" "+((double)c.getRed()/255)+" "+((double)c.getGreen()/255)+" "+((double)c.getBlue()/255)+" "+set);
		}
		private void writeBrushState()
		{
			writeColor(brushColor,"rg");
		}
		private void writePenState()
		{
			writeColor(penColor,"RG");
			append(" "+penWidth+" w ");
			int cap = penStyle & Pen.CAP_MASK;
			switch(cap){
			case Pen.CAP_ROUND: cap = 1; break;
			case Pen.CAP_SQUARE: cap = 2; break;
			case Pen.CAP_BUTT:
			default:
				cap = 0; break;
			}
			append(cap+" J ");
			int join = penStyle & Pen.JOIN_MASK;
			switch(join){
			case Pen.JOIN_ROUND: join = 1; break;
			case Pen.JOIN_BEVEL: join = 2; break;
			case Pen.JOIN_MITER:
			default:
				join = 0; break;
			}
			append(join+" j ");
			append(penMiter+" M ");
			String line = "[] 0";
			switch(penStyle & Pen.STYLE_MASK){
			case Pen.DASH: line = "[4] 0"; break;
			case Pen.DOT: line = "[2] 0"; break;
			case Pen.DASHDOT: line = "[4 2 2 2] 0"; break;
			case Pen.DASHDOTDOT: line = "[4 2 2 2 2 2] 0"; break;
			}
			append(line+" d");
		}
		public void setFont(PointFont f)
		{
			try{
				PointFontDescriptor pd = myMaker.getFontDescriptor(f, true);
				fontAscent = pd.getAscent(curFontSize = f.getPointSize(pd));
				fontDescent = pd.getDescent(curFontSize);
				curFont = "/"+myPage.usingFont(pd.getString("PdfObjectReference", null));
			}catch(IOException e){
				throw new PdfIOException(e);
			}
		}
		public PointFontMetrics getPointFontMetrics(PointFont f)
		{
			try{
				PointFontDescriptor pd = myMaker.getFontDescriptor(f, true);
				return new PointFontMetrics(pd,f);
			}catch(IOException e){
				throw new PdfIOException(e);
			}
		}
		public void drawText(String data, double x, double y)
		{
			drawText(Vm.getStringChars(data),0,data.length(),x,y);
		}
		public void appendLiteral(char[] data, int offset, int length)
		{
			append(" (");
			byte[] d = myData.data;
			int available = myData.data.length-myData.length;
			int dest = myData.length;
			for (int i = 0; i<length; i++){
				boolean back = false;
				char c = data[offset++];
				if (c < 32) c = 32;
				if (c == '(' || c == ')' || c == '\\') back = true;
				if (available < 2){
					myData.length = dest;
					myData.ensureCapacity(myData.data.length+100);
					d = myData.data;
					available = myData.data.length-myData.length;
				}
				if (back) {
					d[dest++] = '\\';
					available--;
				}
				d[dest++] = (byte)c;
				available--;
			}
			myData.length = dest;
			append(")");
		}
		private void specialTransform(double a, double b, double c, double d, double e, double f)
		{
			fontBase.set(a, b, c, d, e, f);
			tat.set(base);
			tat.concatenate(requested);
			tat.concatenate(fontBase);
			writeTransform(tat,false);
		}
		private void specialTransform(AffineTransform at)
		{
			fontBase.set(at);
			tat.set(base);
			tat.concatenate(requested);
			tat.concatenate(fontBase);
			writeTransform(tat,false);
		}
		public void drawText(char[] data, int offset, int length, double x, double y)
		{
			specialTransform(1,0,0,-1,0,2*y+fontAscent);
			writeColor(penColor,"rg"); //Make the pen the brush.
			append(" BT ");
			append(curFont);
			append(" ");
			appendIntSize((int)curFontSize);
			append(" Tf");
			appendPoint(x,y);//+fontAscent);
			append(" Td");
			appendLiteral(data, offset, length);
			append(" Tj ET");
			setTransform(requested);
			//setTransform() restores the pen and brush state. 
		}
		private AffineTransform base, fontBase = new AffineTransform();
		private AffineTransform tat = new AffineTransform();
		private AffineTransform requested = new AffineTransform();
		private boolean stateLost = true;
		
		PageCanvas(Page page)
		{
			myPage = page;
			myMaker = page.myMaker;
			mediaHeight = page.mediaHeight;
			append(" q");
			base = new AffineTransform(1,0,0,-1,0,mediaHeight);//mediaHeight);
			rawWriteTransform(base);
		}
		/**
		 * Finish the operations of this PageCanvas and commit it to the page.
		 */
		public void finish() throws IOException
		{
			append(" Q");
			myPage.addStream(myData.data,0,myData.length);
		}
		/**
		 * Cancel the operations of this PageCanvas.
		 */
		public void cancel()
		{
		}
		// FIXME make this native.
		private void appendIntSize(int v)
		{
			append(" "+Convert.toString((int)(v*pointScale)));
		}
		private String removeSci(String value)
		{
			int idx = value.indexOf('E');
			if (idx == -1) idx = value.indexOf('e');
			if (idx == -1) return value;
			int eAt = idx;
			idx++;
			if (value.charAt(idx) == '-') return "0";
			else{
				if (value.charAt(idx) == '+') idx++;
				int num = Convert.toInt(value.substring(idx));
				value = value.substring(0,eAt);
				for (int i = 0; i<num; i++) value += "0";
			}
			return value;
		}
		private void append(double x)
		{
			if (true){
				append(" "+removeSci(Convert.toString(x*pointScale)));
				return;
			}
			boolean neg = x<0;
			if (neg) x = -x;
			int v = (int)(x*pointScale);
			if (v == 0) neg = false;
			int i = 0;
			for (; v != 0 || i == 0; i++){
				buff[i] = (byte)('0'+v%10);
				v /= 10;
			}
			if (neg) buff[i++] = (byte)'-';
			buff[i++] = ' ';
			myData.ensureCapacity(myData.length+i);
			int d = myData.length;
			myData.length += i;
			byte[] dd = myData.data;
			while(i > 0)
				dd[d++] = buff[--i];
		}
		private void appendPoint(double x, double y)
		{
			append(x);
			append(y);//mediaHeight-y);
		}
		private void appendSize(double x, double y)
		{
			append(x);
			append(y);
		}
		private void appendRect(double x, double y, double width, double height)
		{
			appendPoint(x,y); appendSize(width,height);
		}
		public void append(String data)
		{
			char[] all = Vm.getStringChars(data);
			myData.ensureCapacity(myData.length+all.length);
			byte[] dd = myData.data;
			int d = myData.length;
			for (int i = 0; i<all.length; i++)
				dd[d++] = (byte)all[i];
			myData.length += all.length;
		}
		public void drawLine(double x, double y, double x2, double y2)
		{
			appendPoint(x,y);
			append(" m");
			appendPoint(x2,y2);
			append(" l S");
		}
		private void fillStroke(boolean useBrush, boolean usePen)
		{
			boolean nonzero = brushRule == Brush.RULE_NONZERO_WINDING; 
			if (useBrush && usePen) append(nonzero ? " B" : " B*");
			else if (usePen) append(" S");
			else if (useBrush) append(nonzero ? " f": " f*");
		}
		public void paintRect(double x, double y, double width, double height, boolean useBrush, boolean usePen)
		{
			appendRect(x,y,width,height);
			append(" re");
			fillStroke(useBrush,usePen);
		}
		private void rawWriteTransform(AffineTransform at)
		{
			writeTransform(at,false);
		}
		private void writeTransformCM(AffineTransform at)
		{
			at.getMatrix(tx);
			for (int i = 0; i<tx.length; i++) append(tx[i]);
			append(" cm");
		}
		private void writeTransform(AffineTransform at, boolean isFirst)
		{
			if (!isFirst) append(" Q q");
			stateLost = true;
			writeTransformCM(at);
			writePenState();
			writeBrushState();
		}
		
		public void setTransform(AffineTransform at)
		{
			requested.set(at);
			tat.set(base);
			tat.concatenate(at);
			writeTransform(tat,false);
		}
		
		public void addToPath(double x, double y) {
			appendPoint(x, y);
			append(" l");
		}
		public void addToPath(double x1, double y1, double x2, double y2,
				double x3, double y3) {
			appendPoint(x1, y1);
			appendPoint(x2, y2);
			appendPoint(x3, y3);
			append(" c");
		}
		public void closePath() {
			append(" h");
		}
		public void freePointCanvas() {
			// TODO Auto-generated method stub
			
		}
		public void getUnityTransform(AffineTransform at) {
			at.set(new AffineTransform());
		}
		public void paintPath(boolean useBrush, boolean usePen) {
			fillStroke(useBrush, usePen);
		}
		public void setBrush(Color c, int style, int rule) {
			brushStyle = style;
			brushColor.set(c);
			brushRule = rule;
			writeBrushState();
		}
		public void setPen(Color c, int style, double width, double width2,
				float miterLimit) {
			penStyle = style;
			penWidth = width;
			penMiter = miterLimit;
			penColor.set(c);
			writePenState();
		}
		public void startPath(double x, double y) {
			appendPoint(x,y);
			append(" m");
		}
		public void drawLines(double[] x, double[] y, int xoffset, int yoffset,
				int numberOfPoints, boolean separateLines) {
			if (y == null) y = x;
			int step = 1;
			if (y == x){
				if (yoffset == xoffset) yoffset = xoffset+1;
				if (yoffset == xoffset+1) step = 2;
			}
			if (separateLines){
				for (int i = 0; i<numberOfPoints; i+=2){
					drawLine(x[xoffset],y[yoffset],x[xoffset+step],y[yoffset+step]);
					xoffset += step*2;
					yoffset += step*2;
				}
			}else{
				for (int i = 0; i<numberOfPoints; i++){
					appendPoint(x[xoffset],y[yoffset]);
					if (i == 0) append(" m");
					else append(" l");
					xoffset += step;
					yoffset += step;
				}
				append(" S");
			}
		}
		public void drawImageData(ImageData src, double x, double y,
				double width, double height, PointRect destArea, int options) {
			try{
				String got = myMaker.getImage(src);
				got = myPage.usingImage(got);
				AffineTransform at = (AffineTransform)Cache.get(AffineTransform.class);
				try{
					//y = mediaHeight/2;
					at.set(width,0,0,-height,x,y+height);
					specialTransform(at);
					if (destArea != null){
						PointRect d = destArea;
						appendRect((d.x-x)/width,(height-(d.y-y)-d.height)/height,d.width/width,d.height/height);
						append(" re W n");
					}
					//paintRect(0,0,0.5,0.5,true,false);
					
					//append(" Q ");
					//writeTransformCM(at);
					append(" /"+got+" Do");
					//append(" q ");
					setTransform(requested);
				}finally{
					Cache.put(at);
				}
			}catch(IOException e){
				throw new PdfIOException(e);
			}
		}
		public void paintPolygon(double[] x, double[] y, int xoffset,
				int yoffset, int count, boolean useBrush, boolean usePen) {
			if (y == null) y = x;
			int step = 1;
			if (y == x){
				if (yoffset == xoffset) yoffset = xoffset+1;
				if (yoffset == xoffset+1) step = 2;
			}
			for (int i = 0; i<count; i++){
				appendPoint(x[xoffset],y[yoffset]);
				if (i == 0) append(" m");
				else append(" l");
				xoffset += step;
				yoffset += step;
			}
			append(" h");
			fillStroke(useBrush, usePen);
		}
		public IPointDocument getDocument() {
			return myMaker;
		}
	}
	
	public void finish(boolean closeOutput) throws IOException
	{
		write(pages);
		writeXref();
		if (closeOutput) myStream.close();
	}
	/**
	 * Add a full font descriptor and return a reference to it.
	 * @param d the non-null PointFontDescriptor. This will be
	 * resolved before being added.
	 * @return the reference to it.
	 * @throws IOException
	 */
	public String addFontDirectly(PointFontDescriptor d) throws IOException
	{
		d.resolve();
		PdfDictionary dc = new PdfDictionary("FontDescriptor");
		addObject(dc);
		dc.putProperties("FontName,Flags,FontBBox,MissingWidth,StemV,StemH,ItalicAngle,CapHeight,XHeight,Ascent,Descent,Leading",d);
		write(dc);
		String ref = dc.getReference();
		dc = new PdfDictionary("Font");
		addObject(dc);
		dc.putProperties("Subtype,Name,BaseFont,FirstChar,LastChar,Widths,Encoding",d);
		//dc.put("Name", refName);
		dc.put("FontDescriptor",ref);
		write(dc);
		return dc.getReference();
	}
	/**
	 * Add a full font descriptor and return a reference to it.
	 * @param d
	 * @return the reference to it.
	 * @throws IOException
	 */
	public String addImageDirectly(ImageData id) throws IOException
	{
		Image im = new Image(id,null);
		addObject(im);
		write(im);
		return im.getReference();
	}
	private int firstChar = 32, lastChar = 255;
	/**
	 * Set the character range that documents will be using. This
	 * is used for getFont() which will use this to find the widths
	 * of the characters to add.
	 * @param firstChar the first character in the range.
	 * @param lastChar the last character in the range.
	 */
	public void setCharacterRange(int firstChar, int lastChar)
	{
		if (firstChar < this.firstChar) this.firstChar = firstChar;
		if (lastChar > this.lastChar) this.lastChar = lastChar;
	}
	

	private Hashtable preparedFonts = new Hashtable();
	private Hashtable fonts = new Hashtable();
	private Hashtable images = new Hashtable();
	private FontEntry check = new FontEntry();
	
	public synchronized String getImage(ImageData im) throws IOException
	{
		if (im instanceof Picture){
			String nm = (String)images.get(im);
			if (nm != null) return nm;
		}
		String ret = addImageDirectly(im);
		if (im instanceof Picture){
			images.put(im, ret);
		}
		return ret;
	}
	/**
	 * Get the reference to the specified Font if it has been added.
	 * @param f the Font.
	 * @return the reference to the specified Font if it has been added,
	 * or null if it has not been added.
	 */
	public synchronized String getFont(PointFont f)
	{
		check.set(f);
		PointFontDescriptor pf = (PointFontDescriptor)fonts.get(check);
		if (pf == null) return null;
		return pf.getString("PdfObjectReference", null);
	}
	/**
	 * Get or create the PointFontDescriptor for the specified font.
	 * @param f the Font to look up.
	 * @param create true to create and add one if not yet added.
	 * @return the PointFontDescriptor. The "PdfObjectReference" property
	 * is the reference to the font in the Pdf file.
	 */
	public synchronized PointFontDescriptor getFontDescriptor(PointFont f, boolean create)
	throws IOException
	{
		check.set(f);
		PointFontDescriptor pf = (PointFontDescriptor)fonts.get(check);
		if (pf != null || !create) return pf;
		addFont(f,null);
		check.set(f);
		return (PointFontDescriptor)fonts.get(check);
	}
	/**
	 * Create a PointFontDescriptor for the specified font.
 	 * A new one is created
	 * by using the simple PointFontDescriptor() and then calling
	 * setWidths(firstChar, lastChar, null, -1) on the new descriptor.
	 * @param f the Font to create the descriptor for.
	 * @return the created PointFontDescriptor.
	 */
	protected synchronized PointFontDescriptor createFontDescriptor(PointFont f)
	{
		PointFontDescriptor fd = new PointFontDescriptor(f);
		fd.resolve(firstChar,lastChar);
		return fd;
	}
	/**
	 * This prepares a PointFont for use with a specific PointFontDescriptor, 
	 * but does not write it to
	 * the file unless it is actually used.
	 * @param f the PointFont.
	 * @param fd a non-null PointFontDescriptor. This must NOT be null
	 * because there is no point in doing this. If there is no special
	 * PointFontDescriptor then when addFont() is used later it will simply
	 * create one.
	 */
	public void prepareFont(PointFont f, PointFontDescriptor fd)
	{
		if (f == null || fd == null) throw new NullPointerException();
		FontEntry fe = new FontEntry();
		fe.set(f);
		preparedFonts.put(fe,fd);
	}
	/**
	 * Add a Font if it was not yet added.
	 * @param f the Font to add.
	 * @param fd an optional PointFontDescriptor for the Font. If it is null
	 * the one specified, if any, by prepareFont() is used. If that is still null
	 * a new one will be created according to the parameters of this PdfMaker.
	 * @return the reference to the Font.
	 * @throws IOException
	 */
	public synchronized String addFont(PointFont f, PointFontDescriptor fd) throws IOException
	{
		check.set(f);
		PointFontDescriptor ret = (PointFontDescriptor)fonts.get(check);
		if (ret != null) return ret.getString("PdfObjectReference", null);
		if (fd == null) {
			fd = (PointFontDescriptor)preparedFonts.get(check);
			if (fd == null) fd = createFontDescriptor(f);
		}
		String rs = addFontDirectly(fd);
		fd.set("PdfObjectReference",rs);
		fonts.put(check, fd);
		check = new FontEntry();
		return rs;
	}
	/**
	 * Add a Font if it was not yet added. A new PointFontDescriptor will
	 * be created for the font.
	 * @param f the Font to add.
	 * @return the reference to the Font.
	 * @throws IOException
	 */
	public String addFont(PointFont f) throws IOException
	{
		return addFont(f,null);
	}
/*	
	public static void main(String[] args) throws IOException
	{
		Vm.startEve(args);
		FontMetrics fm = Fx.getFontMetrics(new Font("Arial",Font.PLAIN,10));
		Font f = Metrics.getFontForHeight(1000, fm);
		fm = Fx.getFontMetrics(f);
		System.out.println(f+" - "+fm.getCharWidth((char)37));
		PointFont pf = new PointFont("Arial",Font.PLAIN,100);
		//System.out.println(fm.)
		PdfMaker pm = new PdfMaker();
		pm.open(new FileOutputStream("Created.pdf"));
		Page p = pm.newPage(null);
		PageCanvas pc = p.getCanvas();
		AffineTransform at = new AffineTransform();
		at.rotate(Math.PI/16, 300, 300);
		//pc.setTransform(at);
		
		pc.paintRect(200,100, 50,150, false, true);
		pc.drawLine(200, 100, 250, 250);
		//pc.drawLine(200, 250, 250, 100);
		
		PointFontDescriptor fd = new PointFontDescriptor("Times New Roman",Font.ITALIC,32,255);
		
		String fr = null;
		if (true){
			//fd.set("Name","/F1");
			fr = pm.addFont(new PointFont("Times New Roman",Font.ITALIC,10));
		}else{
			String all = 
				"FontName|/TimesNewRoman|Flags|32|FontBBox|[ -250 -212 1217 1000 ]"+
				"|MissingWidth|211|StemV|153|StemH|153|CapHeight|766"+
				"|Ascent|766|Descent|-168|Leading|25";
			PdfDictionary pd = pm.addDictionary("FontDescriptor");
			pd.addAll(all,'|');
			pm.write(pd);
			String fdRef = pd.getReference();
			pd = pm.addDictionary("Font");
			
			String goodWidths = 					"[ 250 333 408 500 500 833 778 180 333 333 500 564 250 333 250 278 500 " +
			" 500 500 500 500 500 500 500 500 500 278 278 564 564 564 444 921"+ 
	        " 722 667 667 722 611 556 722 722 333 389 722 611 889 722 722 556"+ 
	        " 722 667 556 611 722 722 944 722 722 611 333 278 333 469 500 333"+ 
	        " 444 500 444 500 444 333 500 500 278 278 500 278 778 500 500 500"+ 
	        " 500 333 389 278 500 500 722 500 500 444 480 200 480 541 778 500"+ 
	        " 778 333 500 444 1000 500 500 333 1000 556 333 889 778 611 778 778"+ 
	        " 333 333 444 444 350 500 1000 333 980 389 333 722 778 444 722 250"+ 
	        " 333 500 500 500 500 200 500 333 760 276 500 564 333 760 500 400"+ 
	        " 549 300 300 333 576 453 250 333 300 310 500 750 750 750 444 722"+ 
	        " 722 722 722 722 722 889 667 611 611 611 611 333 333 333 333 722"+ 
	        " 722 722 722 722 722 722 564 722 722 722 722 722 722 556 500 444"+ 
	        " 444 444 444 444 444 667 444 444 444 444 444 278 278 278 278 500"+ 
	        " 500 500 500 500 500 500 549 500 500 500 500 500 500 500 500 ]"; 
			String badWidths = "[ 211 211 270 423 423 677 508 145 253 253 296 444 211 253 211 211 423 423 423 423 423 423 423 423 423 423 211 211 444 444 444 423 773 508 508 550 550 508 465 592 550 211 381 508 423 633 550 592 508 592 550 508 464 550 508 719 507 507 465 211 211 211 357 423 253 423 423 381 423 423 211 423 423 169 169 381 169 634 423 423 423 423 253 381 211 423 381 551 379 381 381 254 196 254 444 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 381 211 254 423 423 423 423 196 423 253 561 282 423 444 253 561 420 304 418 253 253 253 438 409 211 253 253 278 423 635 635 635 465 508 508 508 508 508 508 761 550 508 508 508 508 211 211 211 211 550 550 592 592 592 592 592 444 592 550 550 550 550 507 508 465 423 423 423 423 423 423 677 381 423 423 423 423 211 211 211 211 423 423 423 423 423 423 423 418 465 423 423 423 423 381 423 381 ]"; 

			all = 
				"Subtype|/TrueType|Name|/F1|BaseFont|/TimesNewRoman|FirstChar|32|LastChar|255"+
				"|Widths|"+badWidths+"|Encoding|/WinAnsiEncoding|FontDescriptor|"+fdRef;
			pd.addAll(all,'|');
			pm.write(pd);
			fr = pd.getReference();
		}
		PointFont fnt = new PointFont("Arial",Font.PLAIN,72); 
		pc.setFont(fnt);
		String text = "LOnly One";// Inch But will it be bad?";
		int ox = 0, oy = 0;
		pc.drawText(text,ox,oy);
		PointFontMetrics fmf = pc.getPointFontMetrics(fnt);
		double width = fmf.getTextWidth(text);
		pc.paintRect(ox, oy, width, fmf.getHeight(), false, true);
		//String fn = p.usingFont(fr);
		//pc.append(" BT /"+fn+" 20 Tf 200 200 Td (The Quick Brown Fox) Tj ET");
		//pc.append(" BT /F1 12 Tf 200 200 Td ET");
		pc.finish();
		p.finish();
		pm.newPage(null).finish();
		pm.finish(true);
		Vm.exit(0);
	}
	*/
}
