package eve.fx.points;

public interface PageGraphics {

}
