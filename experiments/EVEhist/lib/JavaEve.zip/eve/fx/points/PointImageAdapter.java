/*
 * Created on May 4, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

import eve.sys.ImageData;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class PointImageAdapter implements PointImage{

	private double width, height;
	private ImageData im;
	
	public PointImageAdapter(ImageData id, double width, double height)
	{
		this.im = id;
		if (height <= 0 && width <= 0){
			this.width = id.getImageWidth();
			this.height = id.getImageHeight();
		}else if (width <= 0){
			this.height = height;
			this.width = (double)(height*im.getImageWidth())/im.getImageHeight();
		}else if (height <= 0){
			this.width = width;
			this.height = (double)(width*im.getImageHeight())/im.getImageWidth();
		}else{
			this.width = width;
			this.height = height;
		}
	}
	/* (non-Javadoc)
	 * @see eve.fx.PointImage#getPointWidth()
	 */
	public double getPointWidth() {
		return width;
	}

	/* (non-Javadoc)
	 * @see eve.fx.PointImage#getPointHeight()
	 */
	public double getPointHeight() {
		return height;
	}
	/* (non-Javadoc)
	 * @see eve.fx.points.PointImage#draw(eve.fx.points.PointGraphics, double, double, int)
	 */
	public void draw(PointGraphics g, double x, double y, PointRect destArea, int options) {
		g.drawImageData(im,x,y,width,height,destArea,options);
		/*
		if (destArea == null) g.drawImageData(im,x,y,width,height,options);
		else{
			PointRect pr = PointRect.getCached(x,y,width,height);
			destArea.getIntersection(pr,pr);
			try{
				if (pr.width == 0 || pr.height == 0) return;
				if (pr.width == width && pr.height == height){
					g.drawImageData(im,x,y,width,height,options);
				}else
					g.drawImageData(im,x,y,width,height,pr,options);
			}finally{
				pr.cache();
			}
		}
		*/
	}
	
	
}
//####################################################
