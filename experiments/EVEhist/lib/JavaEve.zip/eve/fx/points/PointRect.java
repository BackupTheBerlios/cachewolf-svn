package eve.fx.points;

import eve.sys.Cache;

//##################################################################
public class PointRect{
//##################################################################

public double x;
public double y;
public double width;
public double height;

//-------------------------------------------------------------------
private static int roundUp(double value)
//-------------------------------------------------------------------
{
	int v = (int)value;
	if ((double)v != value) v++;
	return v;
}
/*
//===================================================================
public Rect scaleToRect(Rect destination, double pointsToPixelsX, double pointsToPixelsY)
//===================================================================
{
	if (destination == null) destination = new Rect();
	destination.x = (int)(x*pointsToPixelsX);
	destination.y = (int)(y*pointsToPixelsY);
	destination.width = width == 0 ? 0 : roundUp(width*pointsToPixelsX);
	destination.height = height == 0 ? 0 : roundUp(height*pointsToPixelsY);
	return destination;
}
*/
/**
Sets the dimensions of this PointRect and returns itself.
**/
//===================================================================
public PointRect set(double x, double y, double width, double height)
//===================================================================
{
	this.x = x; this.y = y; this.width = width; this.height = height;
	return this;
}
/**
Sets the x and y of this PointRect, the others are set to zero and returns itself.
**/
//===================================================================
public PointRect set(double x, double y)
//===================================================================
{
	this.x = x; this.y = y; this.width = 0; this.height = 0;
	return this;
}
public PointRect() {}
public PointRect(double x, double y) {this.x = x; this.y = y;}
public PointRect(double x, double y,double width, double height) {this.x = x; this.y = y; this.width = width; this.height = height;}
/**
Returns true if the specified rectangle in Points intersects with this PageRect.
* @param x the x co-ordinate in Points (1/72 of an inch).
* @param y the y co-ordinate in Points (1/72 of an inch).
* @param width the width in Points (1/72 of an inch).
* @param height the height in Points (1/72 of an inch).
* @return true if the specified rectangle in Points intersects with this PageRect.
*/
//===================================================================
public boolean isWithin(double x, double y, double width, double height)
//===================================================================
{
	double left = this.x, right = this.x+this.width, top = this.y, bottom = this.y+this.height;
	double tleft = x, tright = x+width, ttop = y, tbottom = y+height;
	
	if (right < tleft) return false;
	if (left > tright) return false;
	if (bottom < ttop) return false;
	if (top > tbottom) return false;
	return true;
}
//==================================================================
public PointRect getIntersection(PointRect r,PointRect dest)
//==================================================================
{
	if (dest == null) dest = new PointRect();
	double x = 0,y = 0,width = 0,height = 0;
	PointRect r1 = this, r2 = r;
	PointRect left = r1,right = r2;
	if (r2.x < r1.x) {
		left = r2;
		right = r1;
	}
	x = right.x;
	width = left.x+left.width-right.x;
	if (width > 0){
		if (width > right.width) width = right.width;
		PointRect above = r1,below = r2;
		if (r2.y < r1.y){
			above = r2;
			below = r1;
		}
		y = below.y;
		height = above.y+above.height-below.y;
		if (height > 0) {
			if (height > below.height) height = below.height;
			return dest.set(x,y,width,height);
		}
	}
	return dest.set(0,0,0,0);
}
//==================================================================
public PointRect getAddition(PointRect r2,PointRect dest)
//==================================================================
{
	PointRect r1 = this;
	if (dest == null) dest = new PointRect();
	double sx = r1.x;
	if (r2.x < sx) sx = r2.x;
	double sy = r1.y;
	if (r2.y < sy) sy = r2.y;
	double ex = r1.x+r1.width;
	if (r2.x+r2.width > ex) ex = r2.x+r2.width;
	double ey = r1.y+r1.height;
	if (r2.y+r2.height > ey) ey = r2.y+r2.height;
	dest.x = sx; dest.y = sy; dest.width = ex-sx; dest.height=ey-sy;
	return dest;
}

public String toString(){return "("+x+","+y+","+width+","+height+")";}

public static PointRect getCached()
{
	return (PointRect)Cache.get(PointRect.class);
}
public static PointRect getCached(double x, double y, double width, double height)
{
	PointRect pr = (PointRect)Cache.get(PointRect.class);
	pr.set(x,y,width,height);
	return pr;
}
public PointRect cache()
{
	Cache.put(this);
	return null;
}
//##################################################################
}
//##################################################################

