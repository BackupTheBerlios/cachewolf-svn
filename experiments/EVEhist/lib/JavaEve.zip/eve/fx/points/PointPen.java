/*
 * Created on Apr 25, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

import eve.fx.Color;

/**
 * This is not used during drawing but is used for PrintCells 
 * for specifying advanced borders.
 */
//####################################################
public class PointPen {

	public double thickness;
	/*
	 * Use eve.fx.Pen.XXX for style.
	 */
	public int style;
	public Color color = new Color(0,0,0);
	
	public PointPen(Color color, int style, double thickness)
	{
		this.color.set(color);
		this.style = style;
		this.thickness = thickness;
	}
}

//####################################################
