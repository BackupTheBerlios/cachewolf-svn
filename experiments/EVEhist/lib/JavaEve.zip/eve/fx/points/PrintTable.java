/*
 * Created on May 3, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;
import eve.fx.Color;
import eve.sys.ImageData;
import eve.util.mString;


//####################################################
public class PrintTable extends PrintCellPanel{
	public PointFont headerFont;
	public PointFont textFont;
	public Color headerBackground;
	/**
	 * Set this to be negative for no border.
	 */
	public double borderSize = 0.5;
	private boolean firstCol = true;
	private boolean firstRow = true;
	/**
	 * This is used to create a new TableCell. Override it if necessary
	 * to return a different TableCell.
	 * @return a new TableCell.
	 */
	protected TableCell newTableCell()
	{
		return new TableCell();
	}
	private TableCell add(boolean isHeader, double percent)
	{
		TableCell tc = newTableCell();
		if (borderSize < 0){
			tc.borderThickness = 0;
			tc.borderRect = 0;
		}else{
			tc.borderThickness = borderSize;
			tc.borderRect = tc.RECT_SIDE_BOTTOM|tc.RECT_SIDE_RIGHT;
			if (firstCol || true) tc.borderRect |= tc.RECT_SIDE_LEFT;
			if (firstRow || true) tc.borderRect |= tc.RECT_SIDE_TOP;
		}
		tc.font = isHeader ? headerFont : textFont;
		if (isHeader) tc.backGround = headerBackground;
		if (percent != 0) tc.setPreferredSize(percent,-1);
		firstCol = false;
		addNext(tc);
		return tc;
	}
	public TableCell add(PointImage data,boolean isHeader,double percent)
	{
		TableCell tc = add(isHeader,percent);
		tc.image = data;
		tc.anchor = CENTER;
		return tc;
	}
	public TableCell add(ImageData data,double width,double height,boolean isHeader,double percent)
	{
		return add(new PointImageAdapter(data,width,height),isHeader,percent);
	}
	public TableCell add(String data, boolean isHeader,double percent)
	{
		TableCell tc = add(isHeader,percent);
		tc.setText(data);
		tc.setTextPosition(CENTER,CENTER);
		return tc;
	}
	public PrintCell add(PrintCell cell, boolean isHeader, double percent)
	{
		PrintCell tc = cell;
		cell.borderThickness = borderSize;
		tc.borderRect = tc.RECT_SIDE_BOTTOM|tc.RECT_SIDE_RIGHT;
		if (firstCol || true) tc.borderRect |= tc.RECT_SIDE_LEFT;
		if (firstRow || true) tc.borderRect |= tc.RECT_SIDE_TOP;
		tc.font = isHeader ? headerFont : textFont;
		if (percent != 0) tc.setPreferredSize(percent,-1);
		firstCol = false;
		addNext(cell);
		return tc;
		
	}
	public TableCell[] addHeaders(String text, char separator)
	{
		return add(mString.split(text,separator),true);
	}
	public TableCell[] addCells(String text, char separator)
	{
		return add(mString.split(text,separator),false);
	}
	public TableCell[] add(String[] str,boolean headers)
	{
		TableCell[] ret = new TableCell[str.length];
		for (int i = 0; i<str.length; i++)
			ret[i] = add(str[i],headers,0);
		return ret;
	}
	public TableCell add(String text)
	{
		return add(text,false,0);
	}
	public void skip(int numToSkip)
	{
		for (int i = 0; i<numToSkip; i++){
			add(" ",false,0);
		}
	}
	public PrintCell endRow()
	{
		firstRow = false;
		firstCol = true;
		return super.endRow();
	}
}
//####################################################
