/*
 * Created on Jan 15, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

import eve.fx.Graphics;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class AffineTransform {

	public static final int TRANSFORM_ROTATE_90 = 1;
	public static final int TRANSFORM_ROTATE_180 = 2;
	public static final int TRANSFORM_ROTATE_270 = 3;
	public static final int TRANSFORM_ROTATE_NONE = 0;
	public static final int TRANSFORM_NONE = 0;
	public static final int TRANSFORM_ROTATE_NOT_RIGHT = -1;
	
	private static final double [] unity = {1,0,0,1,0,0};
	private static final double [] rotate_90 = {0,1,-1,0,0,0};
	private static final double [] rotate_180 = {-1,0,0,-1,0,0};
	private static final double [] rotate_270 = {0,-1,1,0,0,0};
	private double [] tx = (double[])unity.clone();
	
	/**
	 * See if this transform equals the specified transform. If the specified
	 * transform is only 4 elements long then only the first four values are
	 * compared.
	 * @param flatMatrix a matrix of either 4 or 6 elements.
	 * @param count either a value of 4 or 6. 
	 * @return true if the matrix equals the matrix of this AffineTransform.
	 */
	public boolean equals(double[] flatMatrix,int count)
	{
		if (count != 4 && count != 6) return false;
		if (
				flatMatrix[0] != tx[0] || flatMatrix[1] != tx[1] 
				|| flatMatrix[2] != tx[2] || flatMatrix[3] != tx[3]
														  ) return false;
		if (count != 6) return true;
		return (flatMatrix[4] == tx[4] && flatMatrix[5] == tx[5]);
	}
	public boolean equals(double[] flatMatrix)
	{
		return equals(flatMatrix,flatMatrix.length);
	}
	public boolean isUnity()
	{
		return equals(unity,4);
	}
	public void setToUnity()
	{
		set(unity);
	}
	public boolean equals(Object obj)
	{
		if (obj instanceof AffineTransform)
			return equals(tx,6);
		else if (obj instanceof double[])
			return equals((double[])obj);
		return false;
	}
	public AffineTransform(){}
	public AffineTransform(double m00,double m10,double m01,double m11,double m20,double m21)
	{
		set(m00,m10,m01,m11,m20,m21);
	}
	public AffineTransform(float m00,float m10,float m01,float m11,float m20,float m21)
	{
		set(m00,m10,m01,m11,m20,m21);
	}
	public AffineTransform(double[] flatmatrix)
	{
		if (flatmatrix.length == 4){
			System.arraycopy(flatmatrix,0,tx,0,4);
			tx[4] = tx[5] = 0;
		}else if (flatmatrix.length == 6)
			System.arraycopy(flatmatrix,0,tx,0,6);
		else
			throw new IllegalArgumentException();
	}
	public void set(double m00,double m10,double m01,double m11,double m02,double m12)
	{
		tx[0] = m00;
		tx[1] = m10;
		tx[2] = m01;
		tx[3] = m11;
		tx[4] = m02;
		tx[5] = m12;
	}
	public void getMatrix(double[] destMatrix)
	{
		System.arraycopy(tx,0,destMatrix,0,6);
	}
	/**
	 * Set this AffineTransform to be equal to another one.
	 * @param other the other AffineTransform to make this one equivalent to.
	 */
	public void set(AffineTransform other)
	{
		set(other.tx);
	}
	public void set(double[] flatmatrix)
	{
		System.arraycopy(flatmatrix,0,tx,0,6);
	}
	/**
	 * Return a copy of this AffineTransform.
	 */
	public AffineTransform getCopy()
	{
		AffineTransform at = new AffineTransform();
		at.set(this);
		return at;
	}
	public String toString()
	{
		return "["+tx[0]+","+tx[1]+","+tx[2]+","+tx[3]+","+tx[4]+","+tx[5]+"]";
	}
	public void concatenate(AffineTransform Tx)
	{
		double 
			m00 = tx[0], m10 = tx[1], m01 = tx[2], m11 = tx[3], m02 = tx[4], m12 = tx[5];
		double[] v = Tx.tx;
		tx[0] = m00*v[0]+m01*v[1];
		tx[1] = m10*v[0]+m11*v[1];
		tx[2] = m00*v[2]+m01*v[3];
		tx[3] = m10*v[2]+m11*v[3];
		tx[4] = m00*v[4]+m01*v[5]+m02;
		tx[5] = m10*v[4]+m11*v[5]+m12;
	}
	public Object clone()
	{
		return getCopy();
	}
	//
	private static AffineTransform buff = new AffineTransform();
	//
	public void translate(double tx, double ty)
	{
		synchronized(buff){
			buff.set(1,0,0,1,tx,ty);
			concatenate(buff);
		}
	}
	/**
	 * Rotate the transform through an angle in radians.
	 * @param theta the angle to rotate. Rotating through a positive angle
	 * rotates points on the positive x-axis towards the positive y-axis. 
	 */
	public void rotate(double theta)
	{
		synchronized(buff){
			double c = Math.cos(theta), s = Math.sin(theta);
			buff.set(c,s,-s,c,0,0);
			concatenate(buff);
		}
	}
	public void scale(double xScale, double yScale)
	{
		synchronized(buff){
			buff.set(xScale,0,0,yScale,0,0);
			concatenate(buff);
		}
	}
	/**
	 * Rotate the transform through an angle in radians around an anchor point.
	 * @param theta the angle to rotate. Rotating through a positive angle
	 * @param cx the x-coordinate of the anchor point for rotation.
	 * @param cy the y-coordinate of the anchor point for rotation.
	 * rotates points on the positive x-axis towards the positive y-axis. 
	 */
	public void rotate(double theta, double cx, double cy)
	{
		translate(cx,cy);
		rotate(theta);
		translate(-cx,-cy);
	}
	public void rotateRightAngle(int rotateType)
	{
		rotateRightAngle(rotateType,0,0);
	}
	public void rotatePageRightAngle(int rotateType, double pageWidth, double pageHeight)
	{
		switch(rotateType){
			case TRANSFORM_ROTATE_NONE: break;
			case TRANSFORM_ROTATE_90: translate(pageWidth,0); break;
			case TRANSFORM_ROTATE_180: translate(pageWidth,pageHeight); break;
			case TRANSFORM_ROTATE_270: translate(0,pageHeight); break;
		}
		rotateRightAngle(rotateType);
	}
	public void rotateRightAngle(int rotateType,double cx,double cy)
	{
		translate(cx,cy);
		try{
			synchronized(buff){
				switch(rotateType){
					case TRANSFORM_ROTATE_NONE: return;
					case TRANSFORM_ROTATE_90: buff.set(rotate_90); break;
					case TRANSFORM_ROTATE_180: buff.set(rotate_180); break;
					case TRANSFORM_ROTATE_270: buff.set(rotate_270); break;
					default:
						throw new IllegalArgumentException();
				}
				concatenate(buff);
			}
		}finally{
			translate(-cx,-cy);
		}
	}
	public int getRightAngleRotation()
	{
		if (tx[0] == 1 && tx[1] == 0 && tx[2] == 0 && tx[3] == 1) return TRANSFORM_ROTATE_NONE;
		if (equals(rotate_90,4)) return TRANSFORM_ROTATE_90;
		if (equals(rotate_180,4)) return TRANSFORM_ROTATE_180;
		if (equals(rotate_270,4)) return TRANSFORM_ROTATE_270;
		return TRANSFORM_ROTATE_NOT_RIGHT;
	}
	private static void transform(double[] tx, double[] xpoints,int xoffset,double[] ypoints,int yoffset,int count)
	{
		for (int i = 0; i<count; i++){
			double x = xpoints[xoffset], y = ypoints[yoffset];
			xpoints[xoffset++] = x*tx[0]+y*tx[2]+tx[4];
			ypoints[yoffset++] = x*tx[1]+y*tx[3]+tx[5];
		}
	}
	public void transform(double[] xpoints,int xoffset,double[] ypoints,int yoffset,int count)
	{
		transform(tx,xpoints,xoffset,ypoints,yoffset,count);
	}
	public Object concatenate(Graphics g)
	{
		return g.transform(tx[0],tx[1],tx[2],tx[3],tx[4],tx[5]);
	}
	public Object set(Graphics g)
	{
		return g.setTransform(tx[0],tx[1],tx[2],tx[3],tx[4],tx[5]);
	}
	public void cached()
	{
		setToUnity();
	}
}

//####################################################
