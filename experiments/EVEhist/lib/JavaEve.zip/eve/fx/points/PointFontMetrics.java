/*
 * Created on May 6, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

import eve.fx.FontMetrics;
import eve.fx.FormattedTextSpecs;
import eve.sys.Cache;
import eve.util.StringList;
import eve.util.SubString;

/**
 * This class implements a FontMetrics for the PointFont class.
 *
 */
//####################################################
public class PointFontMetrics {

	private FontMetrics fm;
	private PointFont font;
	private PointGraphics g;
	private double xscale, yscale;
	private PointFontDescriptor fd;
	private double fontPointSize;
	/**
	 * Return the PointFont the metrics represents.
	 */
	public PointFont getFont()
	{
		return font;
	}
	

	protected PointFontMetrics(){}

	/**
	 * Setup the PointFontMetrics to use the specified PointFontDescriptor.
	 * The resolve() method is called on the descriptor.
	 * @param fd the non-null PointFontDescriptor.
	 * @param f the PointFont.
	 */
	protected void setFor(PointFontDescriptor fd,PointFont f)
	{
		if (f == null) new Exception().printStackTrace();
		font = f;
		this.fd = fd;
		fd.resolve();
		fontPointSize = f.getPointSize(fd);
	}
	public PointFontMetrics(PointFontDescriptor fd, PointFont f)
	{
		setFor(fd,f);
	}
/**
 * Create a PointFontMetrics for the specified font as rendered on the specified PointGraphics.
 * @param pg the PointGraphics using the Font.
 * @param f the Font.
 * @deprecated use PointGraphics.getPointFontMetrics() instead.
 */
	public PointFontMetrics(PointGraphics pg, PointFont f)
	{
		font = f;
		fm = pg.getIntFontMetrics(f);
		xscale = pg.xscale;
		yscale = pg.yscale;
	}
	
	PointFontMetrics(PointFont f, PointGraphics pg)
	{
		this(pg,f);
	}
	/**
	 * This PointFontMetrics MAY be based on an standard integer based FontMetrics
	 * or it may be based on a PointFontDescriptor.
	 * If it is based on a FontMetrics this will return it.
	 * Get the integer based FontMetrics object that corresponds to this PointFontMetrics. From that
	 * FontMetrics you can also retrieve the integer based Font that is used.
	 * @return the integer based FontMetrics used by this PointFontMetrics
	 */
	public FontMetrics getIntFontMetrics()
	{
		return fm;
	}
	/**
	 * Return the maximum ascent (height above the baseline) of the Font in points.
	 */
	public double getAscent()
	{
		if (fd != null) return fd.getAscent(fontPointSize);
		return (fm.getAscent())/yscale;
	}
	/**
	 * Return the maximum descent (height below the baseline) of the Font in points.
	 */
	public double getDescent()
	{
		if (fd != null) return fd.getDescent(fontPointSize);
		return (fm.getDescent())/yscale;
	}
	/**
	 * Return the extra space between font baselines which is normally used. This is added to the height
	 * of the Font to layout lines of text.
	 */
	public double getLeading()
	{
		if (fd != null) return fd.getLeading(fontPointSize);
		return (fm.getLeading())/yscale;
	}
	/**
	 * Return the height from the lowest descent to the highest ascent for the Font.
	 */
	public double getHeight()
	{
		if (fd != null) return fontPointSize;
		return (fm.getHeight())/yscale;
	}
	/**
	 * Return the width of a specific character in points.
	 */
	public double getCharWidth(char c)
	{
		if (fd != null) return fd.getCharWidth(c,fontPointSize);
		return (fm.getCharWidth(c))/xscale;
	}
	
	/**
	 * Return the width of the specified text.
	 * @param ch the characters of the text
	 * @param start the start of the characters in the array.
	 * @param length the number of characters.
	 * @return the width in points of the text.
	 */
	public double getTextWidth(char[] ch, int start, int length)
	{
		if (fd != null) return fd.getTextWidth(ch,start,length,fontPointSize);
		return (fm.getTextWidth(ch,start,length))/xscale;
	}
	/**
	 * Return the width of the specified text.
	 * @param s the text
	 * @return the width in points of the text.
	 */
	public double getTextWidth(String s)
	{
		if (fd != null) return fd.getTextWidth(s,fontPointSize);
		return (fm.getTextWidth(s))/xscale;
	}
	public double [] getFormattedTextPositions(char[] chars,int start,int count,FormattedTextSpecs fts,double positions[])
	{
		int[] ret = fm.getFormattedTextPositions(chars,start,count,fts,null);
		if (positions == null || positions.length < ret.length) positions = new double[ret.length];
		for (int i = 0; i<ret.length; i++)
			positions[i] = ret[i]*xscale;
		return positions;
	}
	/**
	 * Return if this Font is the same as another. This is quicker than equals()
	 * since no class cast is involved.
	 * @param f another FontMetrics.
	 * @return true if its name, size and style are the same as this one, false if not.
	 */
	public boolean isSame(PointFontMetrics f)
	{
		if (f == null) return false;
		if (f == this) return true;
		return f.fm.getFont().isSame(fm.getFont());// && surface == f.surface;
	}
	/*
	public boolean isSame( ISurface surface)
	{
		if (f == null) return false;
		return f.isSame(font) && surface == surface; 
	}
	*/
	public boolean equals(Object obj)
	{
		if (obj instanceof PointFontMetrics) return isSame((PointFontMetrics)obj);
		return super.equals(obj);
	}
/**
 * Free the resources used by the PointFontMetrics.
 */
	public synchronized void free()
	{
		if (fm != null) fm.free();
		fm = null;
	}
	/**
	 * Return the smallest rectangle that the specified text will fit into. 
	 * @param sl the text to fit.
	 * @param dest a destination PointRect or null for a new one to be created and returned.
	 * @return the destination PointRect or a new one if dest was null.
	 */
	public PointRect getTextSize(StringList sl, PointRect dest)
	{
		return getTextSize(sl,0,sl.size(),dest);
	}
	/**
	 * Return the smallest rectangle that the specified text will fit into. 
	 * @param sl the text to fit.
	 * @param start the first index in the StringList of the text to use.
	 * @param count the number of lines in the StringList to use.
	 * @param dest a destination PointRect or null for a new one to be created and returned.
	 * @return the destination PointRect or a new one if dest was null.
	 */
	public PointRect getTextSize(StringList sl, int start, int count, PointRect dest)
	{
		if (dest == null) dest = new PointRect();
		dest.set(0,0,0,0);
		SubString ss = (SubString)Cache.get(SubString.class);
		try{
			for (int i = 0; i<count; i++){
				Object got = sl.get(i+start,ss);
				double w = getTextWidth(ss.data,ss.start,ss.length);
				if (w > dest.width) dest.width = w;
			}
			dest.height = count*getHeight()+getLeading()*(count-1);
			return dest;
		}finally{
			Cache.put(ss);
		}
	}
}
//####################################################
