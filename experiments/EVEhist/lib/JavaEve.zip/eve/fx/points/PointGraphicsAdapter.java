package eve.fx.points;

public abstract class PointGraphicsAdapter extends PointGraphics{

}
