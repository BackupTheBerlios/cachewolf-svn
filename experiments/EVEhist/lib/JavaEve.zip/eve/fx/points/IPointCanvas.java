package eve.fx.points;

import eve.fx.Color;
import eve.fx.IPath;
import eve.sys.ImageData;

/**
 * This is a drawing interface that allows point (1/72 of an inch) drawing 
 * operations. A PointGraphics Object can be implemented over an IPointCanvas
 * as well as over a normal Graphics. 
 */
public interface IPointCanvas extends IPath{

	public IPointDocument getDocument();
	
	public void freePointCanvas();
	/**
	 * Get the default transform for the canvas. You would use this to 
	 * reset the canvas as necessary. 
	 * @param at a non-null destination AffineTransform.
	 */
	public void getUnityTransform(AffineTransform at);
	/**
	 * Set the transform. 
	 */
	public void setTransform(AffineTransform at);
	
	public void setPen(Color c, int style, double xWidth, double yWidth, float miterLimit);
	
	public void setBrush(Color c,int style,int rule);
	
	/**
	 * Stroke/fill the path.
	 * @param useBrush true to fill the path (assuming it is closed).
	 * @param usePen true to stroke the path (which is done after filling).
	 */
	public void paintPath(boolean useBrush, boolean usePen);
	/**
	 * Draw text at a particular location.
	 * @param x the x location for the start of the base line.
	 * @param y the y location for the start of the base line.
	 * @param data the chars to draw.
	 * @param offset the start of the characters.
	 * @param length the number of characters.
	 */
	public void drawText(char[] data, int offset, int length,double x, double y);
	public void paintRect(double x, double y, double width, double height, boolean useBrush, boolean usePen);
	
	/**
	 * Paint a closed polygon. The IPointCanvas will close the polygon so the first co-ordinates should
	 * NOT be repeated as the last co-ordinates.
	 * @param x the array holding the X co-ordinate points. If y is null then this
	 * also holds the Y co-ordinate points,
	 * either in a separate area or interleaved with the x values.
	 * @param y the Y co-ordinate points or null if the Y co-ordinates are in the 
	 * x array.
	 * @param xoffset the offset into the x array containing the first X point.
	 * @param yoffset the offset into the y array containing the first Y point.
	 * If the y array is null then the y points are in the x array. If the yoffset
	 * is equal to xoffset or to xoffset+1, it is assumed that the x and y
	 * co-ordinates are interleaved (first x, then y, then x, then y), 
	 * otherwise it is assumed that the x and y co-ordinates
	 * are in non-overlapping contiguous sections within the array.
	 * @param count the number of points in the array.
	 */
	public void paintPolygon(double[] x, double[] y, int xoffset, int yoffset, int count, boolean useBrush, boolean usePen);
	
	public void drawLine(double x1, double y1, double x2, double y2);
	/**
	 * Draw a set of lines either by joining one to the next forming a single unbroken path,
	 * or by drawing sets of separate lines.  
	 * @param x the array holding the X co-ordinate points. If y is null then this
	 * also holds the Y co-ordinate points,
	 * either in a separate area or interleaved with the x values.
	 * @param y the Y co-ordinate points or null if the Y co-ordinates are in the 
	 * x array.
	 * @param xoffset the offset into the x array containing the first X point.
	 * @param yoffset the offset into the y array containing the first Y point.
	 * If the y array is null then the y points are in the x array. If the yoffset
	 * is equal to xoffset or to xoffset+1, it is assumed that the x and y
	 * co-ordinates are interleaved (first x, then y, then x, then y), 
	 * otherwise it is assumed that the x and y co-ordinates
	 * are in non-overlapping contiguous sections within the array.
	 * @param numberOfPoints the number of points in the array.
	 * @param separateLines
	 * true to draw as separate lines (i.e from x0,y0 to x1,y1 and then x2,y2 to x3,y3) 
	 * false to draw as a single path (i.e. from x0,y0 to x1,y1 to x2,y2 to x3,y3).
	 */
	public void drawLines(double x[], double y[], int xoffset, int yoffset, int numberOfPoints, boolean separateLines);
	
	public void setFont(PointFont f);
	
	public PointFontMetrics getPointFontMetrics(PointFont f);
	
	/**
	 * Scale and draw an ImageData to the PointGraphics, specifying the destination area
	 * that is to be drawn on the PointGraphics - all other sections of the image will
	 * be clipped.
	 * @param src the source ImageData
	 * @param x the x location where the top left corner of the ImageData would be
	 * if the entire image was drawn.
	 * @param y the y location where the top left corner of the ImageData would be
	 * if the entire image was drawn.
	 * @param width the full width of the scaled image.
	 * @param height the full heigh of the scaled image.
	 * @param destArea the destination area being updated on the PointGraphics.
	 * If this is null then the full x, y, width and height values are used. 
	 * @param options scale options, none of which are currently defined.
	 */
	public void drawImageData(ImageData src, double x, double y, double width, double height, PointRect destArea, int options);
	
}
