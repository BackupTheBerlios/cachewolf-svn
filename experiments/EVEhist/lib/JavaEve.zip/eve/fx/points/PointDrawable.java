/*
 * Created on May 16, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

/**
 * This interface represents an object that knows how to draw itself onto a PointGraphics surface.
 *
 */
//####################################################
public interface PointDrawable {

	/**
	 * Draw this PointDrawable on to a PointGraphics.
	 * @param pg the destination PointGraphics.
	 * @param area the area on the PointGraphics that needs updating.
	 */
	public void draw(PointGraphics pg, PointRect area);
	//public void setup(PointGraphics pg, PageFormat pf);
}
//####################################################
