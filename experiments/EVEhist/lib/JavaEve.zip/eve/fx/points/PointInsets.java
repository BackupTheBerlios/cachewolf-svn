/*
 * Created on May 7, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class PointInsets {

	public double top, left, bottom, right;
	
	public PointInsets()
	{
	}
	public PointInsets(double top, double left, double bottom, double right)
	{
		this.top = top;
		this.left = left;
		this.right = right;
		this.bottom = bottom;
	}
}

//####################################################
