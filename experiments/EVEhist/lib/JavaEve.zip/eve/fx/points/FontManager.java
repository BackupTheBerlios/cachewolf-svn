package eve.fx.points;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Hashtable;

import eve.fx.Font;
import eve.fx.Fx;
import eve.sys.Cache;
import eve.sys.Vm;
import eve.util.StringList;
import eve.zipfile.ZipEntry;
import eve.zipfile.ZipInputStream;

public class FontManager {

	private Hashtable trueTypes = new Hashtable();
	private Hashtable type1s = new Hashtable();
	
	public int firstChar = 32;
	public int lastChar = 255;
	
	public static BufferedReader openAFMFile(String name) throws IOException
	{
		name += ".afm";
		InputStream s = Vm.openResource(null, "EveData-Font14.zip");
		ZipInputStream zis = new ZipInputStream(s);
		while(true){
			ZipEntry ze = zis.getNextEntry();
			if (ze == null){
				zis.close();
				throw new FileNotFoundException(name);
			}
			if (ze.getName().equalsIgnoreCase(name)){
				return new BufferedReader(new InputStreamReader(zis));
			}
		}
	}
	public PointFontDescriptor addTrueType(String keyName, int style, String trueTypeName, int fontDescriptorFlags, String localFontName)
	{
		return add(keyName, style, trueTypeName, fontDescriptorFlags & ~PointFontDescriptor.FLAG_TYPE_1, localFontName);
	}
	public PointFontDescriptor addType1(String keyName, int style, String type1Name, int fontDescriptorFlags, String localFontName)
	{
		return add(keyName, style, type1Name, fontDescriptorFlags|PointFontDescriptor.FLAG_TYPE_1, localFontName);
	}
	private PointFontDescriptor add(String keyName, int style, String name, int fontDescriptorFlags, String localFontName)
	{
		boolean isType1 = (fontDescriptorFlags & PointFontDescriptor.FLAG_TYPE_1) != 0;
		/*
		PointFontDescriptor pfd = null;
		if (isType1){
			AfmFileSpecs specs = new AfmFileSpecs();
			if (localFontName != null) specs.localFont = new Font(localFontName,style,10);
			try{
				BufferedReader br = openAFMFile(name);
				pfd = new PointFontDescriptor(br,specs);
				br.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		if (pfd == null){
			if (localFontName == null) localFontName = name;
			pfd = new PointFontDescriptor(new PointFont(localFontName,style,10),fontDescriptorFlags,name);
			pfd.setWidths(firstChar, lastChar);
		}
		*/
		if (localFontName == null) localFontName = name;
		PointFontDescriptor pfd = new PointFontDescriptor(new PointFont(localFontName,style,10),fontDescriptorFlags,name);
		FontEntry fe = new FontEntry().set(keyName,style);
		Object[] both = new Object[2];
		both[0] = new PointFont(localFontName,style,10);
		both[1] = pfd;
		if (isType1) type1s.put(fe,both);
		else trueTypes.put(fe,both);
		return pfd;
	}
	public void addAllStylesTrueType(String keyName,String name,String[] stylePostFixes, int fontDescriptorFlags, String localName)
	{
		addTrueType(keyName, Font.PLAIN, name+stylePostFixes[0], fontDescriptorFlags, localName);
		addTrueType(keyName, Font.BOLD, name+stylePostFixes[1], fontDescriptorFlags, localName);
		addTrueType(keyName, Font.ITALIC, name+stylePostFixes[2], fontDescriptorFlags, localName);
		addTrueType(keyName, Font.BOLD|Font.ITALIC, name+stylePostFixes[3], fontDescriptorFlags, localName);
	}
	public void addAllStylesType1(String keyName,String name,String[] stylePostFixes, int fontDescriptorFlags, String localName)
	{
		addType1(keyName, Font.PLAIN, name+stylePostFixes[0], fontDescriptorFlags, localName);
		addType1(keyName, Font.BOLD, name+stylePostFixes[1], fontDescriptorFlags, localName);
		addType1(keyName, Font.ITALIC, name+stylePostFixes[2], fontDescriptorFlags, localName);
		addType1(keyName, Font.BOLD|Font.ITALIC, name+stylePostFixes[3], fontDescriptorFlags, localName);
	}
	private static String[] ttStyles;
	/**
	 * Add all Times Roman font styles with the specified keyName.
	 * @param keyName the key name to use.
	 */
	public void addTimes(String keyName)
	{
		String times = Fx.getTimesRoman();
		if (ttStyles == null) ttStyles = new String[]{"",",Bold",",Italic",",BoldItalic"};
		addAllStylesTrueType(keyName, "TimesNewRoman", ttStyles,PointFontDescriptor.FLAG_SERIF, times);
		addAllStylesType1(keyName, "Times", new String[]{"-Roman","-Bold","-Italic","-BoldItalic"},PointFontDescriptor.FLAG_SERIF, times);
	}
	/**
	 * Add all Helvetica font styles with the specified keyName.
	 * @param keyName the key name to use.
	 */
	public void addSansSerif(String keyName)
	{
		String sans = Fx.getArialHelvetica();
		if (sans == null) {
			addTimes(keyName);
			return;
		}
		if (ttStyles == null) ttStyles = new String[]{"",",Bold",",Italic",",BoldItalic"};
		addAllStylesTrueType(keyName, "Arial", ttStyles,0, sans);
		addAllStylesType1(keyName, "Helvetica", new String[]{"","-Bold","-Oblique","-BoldOblique"},0, sans);
	}
	/**
	 * Add all Courier (monospaced) font styles with the specified keyName.
	 * @param keyName the key name to use.
	 */
	public void addCourier(String keyName)
	{
		String courier = Fx.getMonospacedCourierFont();
		if (courier == null){
			addSansSerif(keyName);
			return;
		}
		if (ttStyles == null) ttStyles = new String[]{"",",Bold",",Italic",",BoldItalic"};
		addAllStylesTrueType(keyName, "Courier", ttStyles,0, courier);
		addAllStylesType1(keyName, "Courier", new String[]{"","-Bold","-Oblique","-BoldOblique"},0, courier);
	}
	/**
	 * Use this to assign the FontManager to an IPointDocument, which may be
	 * null. If IPointDocument is null then the returned ActiveFonts only
	 * uses TrueType fonts and not Type1 fonts.
	 * @param pd the IPointDocument being used.
	 * @return an ActiveFonts object that you can use to get correct fonts
	 * from.
	 */
	public ActiveFonts assignTo(IPointDocument pd)
	{
		return new ActiveFonts(pd);
	}
	/**
	 * Use this to assign the FontManager to a PointGraphics, which may not be
	 * null. If PointGraphics is not implemented over an IPointDocument then the returned ActiveFonts only
	 * uses TrueType fonts and not Type1 fonts.
	 * @param pd the IPointDocument being used.
	 * @return an ActiveFonts object that you can use to get correct fonts
	 * from.
	 */
	public ActiveFonts assignTo(PointGraphics pg)
	{
		return new ActiveFonts(pg.getPointDocument());
	}
	
	private static void add(IPointDocument pd, Hashtable src, Hashtable exclude)
	{
		for (Enumeration e = src.keys(); e.hasMoreElements();){
			Object got = e.nextElement();
			if (exclude != null && exclude.get(got) != null) continue;
			Object[] both = (Object[])src.get(got);
			pd.prepareFont((PointFont)both[0],(PointFontDescriptor)both[1]);
		}
	}
	private static void alias(Hashtable ht, String old, String newName)
	{
		Hashtable toAdd = new Hashtable();
		for (Enumeration e = ht.keys(); e.hasMoreElements();){
			FontEntry fe = (FontEntry)e.nextElement();
			if (fe.getName().equals(old)){
				int oldStyle = fe.getBoldItalicStyle();
				Object saved = ht.get(fe);
				fe = new FontEntry();
				fe.set(newName,oldStyle);
				toAdd.put(fe,saved);
			}
		}
		ht.putAll(toAdd);
	}
	/**
	 * Make newKey refer to the same entries as new key.
	 * @param oldKey the original key.
	 * @param newKey the new key that will refer to the same entries as the
	 * original key.
	 */
	public void makeAlias(String oldKey, String newKey)
	{
		alias(type1s,oldKey,newKey);
		alias(trueTypes,oldKey,newKey);
	}
	/**
	 * Specify the default font for use if fonts aren't found.
	 * @param key the original key.
	 */
	public void makeDefault(String key)
	{
		makeAlias(key,"default");
	}
	/**
	 * This is used for fetching managed fonts for the active document.
	 */
	public final class ActiveFonts {
		boolean useType1 = false;
		
		protected ActiveFonts(IPointDocument pd)
		{
			if (pd != null){
				useType1 = true;
				add(pd,type1s,null);
				add(pd,trueTypes,type1s);
			}
		}
		private PointFont getFirst(Hashtable hash,int style)
		{
			PointFont found = null;
			for (Enumeration e = hash.keys(); e.hasMoreElements();){
				FontEntry fe = (FontEntry)e.nextElement();
				if (found == null || fe.getBoldItalicStyle() == style){ 
					Object[] both = (Object[])hash.get(fe);
					if (both == null) continue;
					found = (PointFont)both[0];
					if (fe.getBoldItalicStyle() == style)
						return found;
				}
			}
			return found;
		}
		private PointFont get(Hashtable hash, String name, int style)
		{
			FontEntry fe = ((FontEntry)Cache.get(FontEntry.class)).set(name,style);
			try{
				Object[] both = (Object[])hash.get(fe);
				if (both == null) return null;
				return (PointFont)both[0];
			}finally{
				Cache.put(fe);
			}
		}
		private PointFont defaultFont(int style)
		{
			PointFont ret = null;
			if (useType1) ret = get(type1s,"default",style);
			if (ret == null) ret = get(trueTypes,"default",style);
			if (ret == null) {
				if (useType1) ret = getFirst(type1s,style);
				if (ret == null) ret = getFirst(trueTypes,style);
				if (ret == null) throw new NullPointerException("No Fonts were defined.");
			}
			return ret;
		}
		private PointFont get(String name, int style)
		{
			PointFont ret = null;
			if (useType1) ret = get(type1s,name,style);
			if (ret == null) ret = get(trueTypes,name,style);
			if (ret == null) ret = defaultFont(style);
			return ret;
		}
		public PointFont get(String keyName, int style, double size)
		{
			PointFont ret = get(keyName,style);
			return ret.changeSize(size);
		}
		public PointFont get(String keyName, int style, StringList newText, int fitWidth, int fitHeight)
		{
			PointFont ret = get(keyName,style);
			return ret.changeSize(newText, fitWidth, fitHeight);
		}
		public PointFont get(FontEntry key, double size)
		{
			PointFont ret = get(key.getName(),key.getBoldItalicStyle());
			return ret.changeSize(size);
		}
		public PointFont get(FontEntry key, StringList newText, int fitWidth, int fitHeight)
		{
			PointFont ret = get(key.getName(),key.getBoldItalicStyle());
			return ret.changeSize(newText, fitWidth, fitHeight);
		}
	}
}
