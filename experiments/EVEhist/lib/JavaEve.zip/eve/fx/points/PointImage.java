/*
 * Created on May 4, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

/**
 * This interface is used for some kind of 2D image that can draw itself to a PointGraphics.
 */
//####################################################
public interface PointImage {
/**
 * Return the width of the PointImage in points.
 */
	public double getPointWidth();
	/**
	 * Return the height of the PointImage in points.
	 */
	public double getPointHeight();
	//public ImageData toImageData(PointMetrics metrics);
	/**
	/**
	 * Draw the PointImage to the PointGraphics, specifying the destination area
	 * that is to be drawn on the PointGraphics - all other sections of the image will
	 * be clipped.
	 * @param g the destination PointGraphics.
	 * @param x the x location where the top left corner of the PointImage would be
	 * if the entire image was drawn.
	 * @param y the y location where the top left corner of the PointImage would be
	 * if the entire image was drawn.
	 * @param destArea the destination area being updated on the PointGraphics. Only this
	 * area will be drawn.
	 * @param options draw options - none are currently defined. 
	 */
	public void draw(PointGraphics g, double x, double y, PointRect destArea, int options);
}

//####################################################
