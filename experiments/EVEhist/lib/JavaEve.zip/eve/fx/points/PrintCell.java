/*
 * Created on Mar 12, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.points;

import java.util.Iterator;
import java.util.Stack;
import java.util.Vector;

import eve.fx.Brush;
import eve.fx.Color;
import eve.fx.Pen;
import eve.util.ObjectIterator;
import eve.util.StringList;
import eve.util.TagList;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class PrintCell implements PrintCellConstants, PointDrawable{

static final int CalculatedSizes = 0x1;
public static final int AlwaysRecalculateSizes = 0x2;

public int modifiers;
public String name;
public int constraints = STRETCH|FILL|CENTER;
TagList tags;
boolean alreadyAdded = false;

public double x, y, width, height;
public double topSpace = 0;//72.0/16;
public double bottomSpace = 0;//72.0/16;
public double leftSpace = 0;//72.0/16;
public double rightSpace = 0;//72.0/16;
public PointFont font;
public Color foreGround;// = Color.Black;
public Color backGround;
//public Graphics curSurface;

public PrintCell setSpacing(double top, double left, double bottom, double right)
{
	topSpace = top;
	bottomSpace = bottom;
	leftSpace = left;
	rightSpace = right;
	return this;
}
public PrintCell setSpacing(double spacing)
{
	topSpace = bottomSpace = leftSpace = rightSpace = spacing;
	return this;
}
/*
public void startDrawing(Graphics surface)
{
	curSurface = surface; 
}
public void endDrawing()
{
	curSurface = null;
}
*/
/*
public ISurface getSurface()
{
	for (PrintCell p = this; p != null; p = p.parent)
		if (p.curSurface != null) return p.curSurface;
	return Fx.getDefaultSurface();
}
*/
/*
public FontMetrics getFontMetrics()
{
	return getFontMetrics(getFont());
}
public FontMetrics getFontMetrics(Font f)
{
	if (curSurface == null)
		return Fx.getDefaultSurface().getFontMetrics(f);
	return curSurface.getFontMetrics(f);
}
*/
public PointFont getFont()
{
	for (PrintCell p = this; p != null; p = p.parent)
		if (p.font != null) return p.font;
	return null;//Fx.getDefaultFont();
}
public Color getBackground()
{
	for (PrintCell p = this; p != null; p = p.parent)
		if (p.backGround != null) return p.backGround;
	return Color.Null;//White;
}
public Color getForeground()
{
	for (PrintCell p = this; p != null; p = p.parent)
		if (p.foreGround != null) return p.foreGround;
	return Color.Black;
}
PrintCell parent; 
PrintCell next, prev, children;

public void modify(int switchOn, int switchOff)
{
	modifiers |= switchOn;
	modifiers &= ~switchOff;
}
protected void resizeTo(double w, double h)
{
	width = w; height = h;
}
public void setRect(double xx, double yy, double w, double h)
{
	x = xx; y = yy;
	resizeTo(w,h);
	//System.out.println(getClass().getName()+", "+new PointRect(xx,yy,w,h));
}

public boolean hasTag(int id)
{
	if (tags == null) return false;
	return tags.hasTag(id);
}
public Object getTag(int id,Object defaultValue)
{
	if (tags == null) return null;
	return tags.getValue(id,defaultValue);
}
public PrintCell setTag(int id, Object value)
{
	if (tags == null) tags = new TagList();
	tags.set(id,value);
	return this;
}
//===================================================================
public PrintCell setControl(int val) {
	if ((val & (HEXPAND|HCONTRACT|VEXPAND|VCONTRACT)) == 0){
		if ((val & (LEFT|RIGHT)) == (LEFT|RIGHT)) val |= HFILL;
		if ((val & (TOP|BOTTOM)) == (TOP|BOTTOM)) val |= VFILL;
	}
	constraints = (constraints & ~CONTROLMASK)|(val & CONTROLMASK); return this;
}
public PrintCell setCell(int val) {constraints = (constraints & ~CELLMASK)|(val & CELLMASK); return this;}

//......................................................
//These are values which will be calculated. Do not use
//them to set the preferred or minimum values.
//......................................................
/** Do not set this directly - use setPrefferedSize() instead. */
protected double preferredWidth = 10;
/** Do not set this directly - use setPrefferedSize() instead. */
protected double preferredHeight = 10;
/** Do not set this directly - use setMinimumSize() instead. */
protected double minWidth = 0;
/** Do not set this directly - use setMinimumSize() instead. */
protected double minHeight = 0;
/** Do not set this directly - use setMaximumSize() instead. */
protected double maxWidth = -1;
/** Do not set this directly - use setMaximumSize() instead. */
protected double maxHeight = -1;

//==================================================================
public PrintCell setFixedSize(double width,double height) {return setTag(TAG_FIXEDSIZE,new PointRect(0,0,width,height));}
public PrintCell setPreferredSize(double width,double height) {return setTag(TAG_PREFERREDSIZE,new PointRect(0,0,width,height));}
public PrintCell setTextSize(double width,double height) {return setTag(TAG_TEXTSIZE,new PointRect(0,0,width,height));}
public PrintCell setMinimumSize(double width,double height){return setTag(TAG_MINIMUMSIZE,new PointRect(0,0,width,height));}
public PrintCell setMaximumSize(double width,double height){return setTag(TAG_MAXIMUMSIZE,new PointRect(0,0,width,height));}
//==================================================================
//-------------------------------------------------------------------
private void doCalculateSizes()
//-------------------------------------------------------------------
{
	modify(CalculatedSizes,0);
	calculateSizes();
	/*
	PointRect d = (PointRect)getTag(TEXTSIZE,null);
	if (d != null) {
		calculateTextSize(d.width,d.height,tempD);
		preferredWidth = java.lang.Math.max(tempD.width,preferredWidth); 
		preferredHeight = java.lang.Math.max(tempD.height,preferredHeight);
	}
	*/
}
//-------------------------------------------------------------------
private PointRect checkStandardSizes(PointRect d)
//-------------------------------------------------------------------
{
	int myFlags = modifiers;
	if (((myFlags & CalculatedSizes) == 0) ||((myFlags & AlwaysRecalculateSizes) != 0))
		doCalculateSizes();
//------------------------------------------------------------------
	for (PrintCell c = parent; c != null; c = c.parent)
		myFlags |= c.modifiers;
	//if ((myFlags & ShrinkToNothing) != 0) return d.set(0,0);
	PointRect d2 = (PointRect)getTag(TAG_FIXEDSIZE,null);
	if (d2 != null) return d.set(d2.width,d2.height);
	return null;
}
//-------------------------------------------------------------------
private PointRect getASize(PointRect dest,int tag)
//-------------------------------------------------------------------
{
	if (dest == null) dest = new PointRect();
//------------------------------------------------------------------
	if (checkStandardSizes(dest) != null) return dest; 
//------------------------------------------------------------------
	PointRect d = (PointRect)getTag(tag,null);
//------------------------------------------------------------------
	if (tag == TAG_PREFERREDSIZE) dest.set(0,0,preferredWidth,preferredHeight);
	else if (tag == TAG_MINIMUMSIZE) dest.set(0,0,minWidth,minHeight);
	else if (tag == TAG_MAXIMUMSIZE) dest.set(0,0,maxWidth,maxHeight);
	if (d != null) {
		if (d.width >= 0) dest.width = d.width;
		if (d.height >= 0) dest.height = d.height;
		//return dest.set(d.width,d.height);
	}
	return dest;
}
static PointRect tempD = new PointRect();
/**
* This gets all of the control sizes. Currently it returns the
* preferredSize, minimumSize and maximumSize. They fit into the array
* as follows:
* 
* preferredWidth,preferredHeight,minWidth,minHeight,maxWidth,maxHeight
* 
**/
//===================================================================
public double [] getSizes(double [] values)
//===================================================================
{
	int myFlags = modifiers;
	if (values == null) values = new double[6];
	if (values.length < 6) values = new double[6];
//..................................................................
	if (((myFlags & CalculatedSizes) == 0) ||((myFlags & AlwaysRecalculateSizes) != 0))
		doCalculateSizes();
//..................................................................
	/*
	if ((flags & ShrinkToNothing) != 0){
		values[0] = values[2] = values[4] = 
		values[1] = values[3] = values[5] = 0;
		return values;
	}
	*/
//..................................................................
	PointRect d2 = (PointRect)getTag(TAG_FIXEDSIZE,null);
	if (d2 != null) {
		values[0] = values[2] = values[4] = d2.width;
		values[1] = values[3] = values[5] = d2.height;

		return values;
	}
//..................................................................
	PointRect dest = getPreferredSize(tempD);
	values[0] = dest.width; values[1] = dest.height;
	dest = getMinimumSize(dest);
	values[2] = dest.width; values[3] = dest.height;
	dest = getMaximumSize(dest);
	values[4] = dest.width; values[5] = dest.height;
	return values;
}
//==================================================================
public PointRect getPreferredSize(PointRect dest)
//==================================================================
{
	return getASize(dest,TAG_PREFERREDSIZE);
}
//==================================================================
public PointRect getMinimumSize(PointRect dest)
//==================================================================
{
	return getASize(dest,TAG_MINIMUMSIZE);
}
//==================================================================
public PointRect getMaximumSize(PointRect dest)
//==================================================================
{
	return getASize(dest,TAG_MAXIMUMSIZE);
}
/**
* Override this to calculate the preferred, minimum and maximum size of your control. This is only
* called once unless the modifier flag AlwaysRecalculateSizes is true.
* During the calculation you will set the variables preferredWidth, preferredHeight, etc. directly.
**/
//-------------------------------------------------------------------
protected void calculateSizes() 
//-------------------------------------------------------------------
{
	preferredWidth = preferredHeight = 72;
}
/**
 * Place the text in a StringList.
 * @param dest the destination StringList which must not be null.
 */
public void getText(StringList dest)
{
}
public StringList getCachedText()
{
	StringList sl = StringList.getCached();
	getText(sl.clear());
	return sl;
}
/*
public Dimension getTextSize(FontMetrics fm,Dimension dest)
{
	if (dest == null) dest = new Dimension();
	StringList sl = getCachedText();
	Metrics.getSize(fm,sl.toSubStringArray(),0,0,dest); 
	sl.cache();
	return dest;
}
*/
public PointRect getTextSize(PointFont f, PointGraphics pm, PointRect dest)
{
	StringList sl = getCachedText();
	PointFontMetrics pfm = pm.getFontMetrics(f); 
	PointRect ret = pfm.getTextSize(sl, dest);
	sl.cache();
	return ret;
}
/**
 * Returns true if the given x and y coordinate in the parent's
 * coordinate system is contained within this control.
 */
public boolean contains(double x, double y)
{
	double rx = this.x;
	double ry = this.y;
	if (x < rx || x >= rx + this.width || y < ry || y > ry + this.height)
		return false;
	return true;
}
/**
 * See if this PrintCell contains the specified PrintCell.
 * @param who the possible child or anscestor control.
 * @return true if this PrintCell contains the specified PrintCell.
 */
//==================================================================
public boolean contains(PrintCell who)
//==================================================================
{
	if (who == null) return false;
	for (PrintCell c = who.parent; c != null; c = c.parent)
		if (c == this) return true;
	return false;
}

//===================================================================
public final boolean isChildOf(PrintCell who)
//===================================================================
{
	if (who == null) return false;
	for (PrintCell c = this; c != null; c = c.parent)
		if (c == who) return true;
	return false;
}
private static final Iterator noChildren = new ObjectIterator(null);
/**
* This returns an Iterator that goes forwards through the components which are physically
* added to this Control - i.e. may be displayed within the Control.
* <p>Note that a sub-control may not be a "child" of the control -
* i.e. it may not have been added into the Control heirarchy.
**/
public Iterator getChildren() {return noChildren;}
/**
* This returns an Iterator that goes backwards through the components which are physically
* added to this Control - i.e. may be displayed within the Control.
* <p>Note that a sub-control may not be a "child" of the control -
* i.e. it may not have been added into the Control heirarchy.
**/
public Iterator getChildrenBackwards() {return noChildren;}
//===================================================================
/**
* Get all the children for this Control and their children.
**/
//===================================================================
public Iterator getAllDescendants(boolean backwards)
//===================================================================
{
	Stack s = new Stack();
	Vector v = new Vector();
	Iterator it = backwards ? getChildrenBackwards() : getChildren();
	while(true){
		if (it.hasNext()){
			PrintCell c = (PrintCell)it.next();
			v.add(c);
			s.push(it);
			it = backwards ? c.getChildrenBackwards() : c.getChildren();
		}else if (s.size() == 0) break;
		else it = (Iterator)s.pop();
	}
	return v.iterator();
}
/**
* Get all the sub-controls for this Control and their sub-controls.
**/
//===================================================================
public Iterator getAllSubControls()
//===================================================================
{
	Stack s = new Stack();
	Vector v = new Vector();
	Iterator it = getSubControls();
	while(true){
		if (it.hasNext()){
			PrintCell c = (PrintCell)it.next();
			v.add(c);
			s.push(it);
			it = c.getSubControls();
		}else if (s.size() == 0) break;
		else it = (Iterator)s.pop();
	}
	return v.iterator();
}
/**
* This returns an Iterator that goes forwards through the components
* which are considered a sub-control of this Control, even though they
* may not be a "child" of the control -
* i.e. it may not have been added into the Control heirarchy.
**/
//===================================================================
public Iterator getSubControls() {return getChildren();}
//===================================================================
/*
//-------------------------------------------------------------------
protected PointRect calculateTextSize(int width,int height,PointRect dest)
//-------------------------------------------------------------------
{
	dest = PointRect.unNull(dest);
	FontMetrics fm = getFontMetrics();
	Rect sz = Graphics.getAverageSize(fm,height < 0 ? 10 : height,width < 0 ? 10 : width,2,2);
	if (width >= 0) 
	dest.width = width >= 0 ? sz.width : width;
	dest.height = height >= 0 ? sz.height : height;
	return dest;
}
*/

public PointGraphics pointGraphics;

public void make(PointGraphics ps)
{
	pointGraphics = ps;
}
public PointRect getDim(PointRect pr)
{
	if (pr == null) pr = new PointRect();
	pr.set(0,0,width,height);
	return  pr;
}
public PointRect getExtent(PointRect pr)
{
	if (pr == null) pr = new PointRect();
	//pr.set(x-36,y-36,width+72,height+72);
	pr.set(x,y,width,height);
	return  pr;
}
public PointRect getRect(PointRect pr)
{
	if (pr == null) pr = new PointRect();
	pr.set(x,y,width,height);
	return  pr;
}
private void doBorder(PointGraphics g, PointPen p, int side)
{
	if (p == null) return;
	doBorder(g,p.thickness,p.color,p.style,true,side);
}
/**
 * This is the main method to override when doing custom Control painting.
 * It is called when the Control needs refreshing or when repaintNow() is called.
 * @param g the graphics to paint to.
 * @param r the area within the Control to paint. This can be ignored and the entire
 * area can be painted if so desired. 
 */
//==================================================================
public void doPaint(PointGraphics g,PointRect r)
//==================================================================
{
	doBackground(g);
	if ((borderRect & RECT_SIDE_FULL) != 0) 
		doBorder(g,borderThickness,borderColor,borderStyle,false,borderRect);
	PrintCellBorder pcb = (PrintCellBorder)getTag(TAG_BORDER,null);
	if (pcb != null){
		doBorder(g,pcb.top,RECT_SIDE_TOP);
		doBorder(g,pcb.bottom,RECT_SIDE_BOTTOM);
		doBorder(g,pcb.left,RECT_SIDE_LEFT);
		doBorder(g,pcb.right,RECT_SIDE_RIGHT);
	}
}
public static final int RECT_SIDE_TOP = 0x1;
public static final int RECT_SIDE_BOTTOM = 0x2;
public static final int RECT_SIDE_LEFT = 0x4;
public static final int RECT_SIDE_RIGHT = 0x8;
public static final int RECT_SIDE_FULL = 0xf;
public static final int RECT_INSET_BORDER = 0x100;

public PointRect getCachedDim()
{
	return getDim(PointRect.getCached());
}
/*
public Rect getCachedPixelRect(PointGraphics pm)
{
	PointRect pr = getRect(PointRect.getCached());
	try{
		return pm.scaleToPixels(pr,Rect.getCached()); 
	}finally{
		pr.cache();
	}
}
*/
public void doBackground(PointGraphics g)
{
	Color c = getBackground();
	if (!Color.isNull(c)){
		g.setBrush(c,Brush.SOLID);
		g.paintRect(0,0,width,height,true,false);
		g.setBackground(c);
	}
}
public int borderRect;
public double borderThickness = 1;
public int borderStyle = Pen.SOLID|Pen.JOIN_MITER;
public Color borderColor = Color.Black;

public void doBorder(PointGraphics g, double penSize, Color c, int style, boolean insetInCell, int rectSides)
{
	double mx = 0, my = 0, mwidth = width, mheight = height;
	if (true && (insetInCell || ((rectSides & RECT_INSET_BORDER) != 0))) 
	{
		mx += penSize/2; my += penSize/2;
		mwidth -= penSize; mheight -= penSize;
	}
	g.setPen(c,style|Pen.CAP_SQUARE,penSize);
	if ((rectSides & RECT_SIDE_FULL) == RECT_SIDE_FULL){
		//System.out.println(new PointRect(x,y,mwidth,mheight));
		g.paintRect(mx,my,mwidth,mheight,false,true);
	}else{
		if ((rectSides & RECT_SIDE_TOP) != 0)
			g.drawLine(mx,my,mx+mwidth,my);
		if ((rectSides & RECT_SIDE_BOTTOM) != 0)
			g.drawLine(mx,my+mheight,mx+mwidth,my+mheight);
		if ((rectSides & RECT_SIDE_LEFT) != 0)
			g.drawLine(mx,my,mx,my+mheight);
		if ((rectSides & RECT_SIDE_RIGHT) != 0)
			g.drawLine(mx+mwidth,my,mx+mwidth,my+mheight);
		/*
		if ((rectSides & RECT_SIDE_TOP) != 0)
			g.drawLine(mx,my,mx+mwidth-1,my);
		if ((rectSides & RECT_SIDE_BOTTOM) != 0)
			g.drawLine(mx,my+mheight-1,mx+mwidth-1,my+mheight-1);
		if ((rectSides & RECT_SIDE_LEFT) != 0)
			g.drawLine(mx,my,mx,my+mheight-1);
		if ((rectSides & RECT_SIDE_RIGHT) != 0)
			g.drawLine(mx+mwidth-1,my,mx+mwidth-1,my+mheight-1);
		*/
	}
}
//==================================================================
public void doPaintChildren(PointGraphics g, PointRect where)
//==================================================================
{
	doPaintChildren(this,modifiers,g,where);//g.getClip(new Rect()));
}
/*
//==================================================================
public static void notNative_doPaintChildren(Control who,int flags,Graphics g, Rect area)
//==================================================================
{
	doPaintChildren(who,flags,g,area,g.getClip(new Rect()));
}
*/
//-------------------------------------------------------------------
private static void doPaintChildren(PrintCell who,int flags,PointGraphics g,PointRect area)//Rect clip)
//-------------------------------------------------------------------
{
	double ax = area.x, ay = area.y, aw = area.width, ah = area.height;
	//PointRect curClip = PointRect.getCached();
	PointRect r = PointRect.getCached();
	TransformState t = new TransformState();
	//Rect dest = Rect.getCached();
	try{
		//curClip.set(area.x,area.y,area.width,area.height);
		PrintCell child;
		if (who.children == null) return;
		//if (clip == null) curClip.set(area);
		//else area.getIntersection(clip,curClip);
		for (child = who.children; child != null; child = child.next){
			child.getExtent(r);
			//r.x = child.x; r.y = child.y; r.width = child.width; r.height = child.height;
			//System.out.println("Child at: "+r);
			//curClip.getIntersection(r,area);
			r.getIntersection(area,area);
			try{
				if (area.width <= 0 || area.height <= 0) {
					//System.out.println("No: "+curClip+", "+r);
					continue;
				}
				r.x = child.x; r.y = child.y; r.width = child.width; r.height = child.height;
				area.x -= r.x; area.y -= r.y;
				//pm.scaleToPixels(r,dest);
				t = g.getTransformState(t).translate(r.x,r.y);
				//g.setClip(area.x,area.y,area.width,area.height);
				//child.paintBackground(g);
				child.doPaint(g,area);
				//Vm.sleep(200);
				doPaintChildren(child,flags|child.modifiers,g,area);//inter.x,inter.y,inter.width,inter.height);
				//if (clip != null) g.setClip(clip.x,clip.y,clip.width,clip.height);
				t.restore();
			}finally{
				area.set(ax,ay,aw,ah);
			}
		}
	}finally{
		//curClip.cache();
		//t.cache();
		r.cache();
		//dest.cache();
	}
}
/**
 * Shrink the FontMetrics provided by baseFont or smallestSoFar so that the text in
 * this PrintCell fits within itself. 
 * @param baseFont a non-null FontMetrics for the base font (of any starting size).
 * @param biggestSoFar currently the biggest Font that should be used. If this is null
 * then baseFont should be used.
 * @param scaler a DimensionScaler object to scale points into pixels. 
 * @return the FontMetrics representing the biggest Font that should be used for this
 * text to fit. If biggestSoFar is not null, then this must be the same size or smaller
 * than biggestSoFar.
 */
/*
public FontMetrics shrinkInto(FontMetrics baseFont, FontMetrics biggestSoFar, PointGraphics ps)
{
	Iterator it = getChildren();
	while(it.hasNext()){
		PrintCell pc = (PrintCell)it.next();
		biggestSoFar = pc.shrinkInto(baseFont,biggestSoFar,ps);
	}
	return biggestSoFar;
}
*/
/**
 * Calculate the best size Font so that this cell's text and all its children's text will
 * fit correctly into its space. This method uses shrinkInto() to calculate the font that
 * should be used and then sets this "font" field to be that value.
 * @param fontName the name of the Font to use.
 * @param fontStyle the style of the Font to use.
 * @param pm the PontMetrics to use for calculating.
 * @return the Font actually calculated and used.
 */
/*
public final PointFont fitFont(String fontName, int fontStyle,PointGraphics pm)
{
	FontMetrics min = pm.getFontMetrics(new Font(fontName,fontStyle,20));
	FontMetrics got = shrinkInto(min,null,pm);
	if (got == null) got = min;
	font = got.getFont();
	return font;
}
*/
/* (non-Javadoc)
 * @see eve.fx.points.PointDrawable#draw(eve.fx.points.PointGraphics, eve.fx.points.PointRect)
 */
public void draw(PointGraphics pg, PointRect area) 
{
	doPaint(pg,area);
	doPaintChildren(pg,area);
}
public void setup(PointGraphics pg, PageFormat pf)
{
	make(pg);
}
}
//####################################################
