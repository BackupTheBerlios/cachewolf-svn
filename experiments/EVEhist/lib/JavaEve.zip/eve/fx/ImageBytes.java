package eve.fx;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import eve.io.PNGEncoder;
import eve.util.ByteArray;
import eve.util.FormattedDataSource;
/**
* This provides no more functionality than a ByteArray. Its sole purpose
* is to allow for automatic creation of an ImageControl UI component
* when creating Editors for objects. Any variable of type ImageBytes gets
* an ImageControl created for it.
**/
//##################################################################
public class ImageBytes extends ByteArray{
//##################################################################
//===================================================================
public ImageBytes(){super();}
//===================================================================
public ImageBytes(byte [] data) {super(data);}
//===================================================================
public ImageBytes(IImage image) {pngEncode(image);}
//===================================================================

/**
* This version of getCopy() returns a new ImageBytes object.
**/
//===================================================================
public Object getCopy()
//===================================================================
{
	ImageBytes ib = new ImageBytes();
	ByteArray ba = (ByteArray)super.getCopy();
	ib.data = ba.data;
	ib.length = ba.length;
	return ib;
}
/**
This method will save the Image as a PNG image into this ImageBytes object, erasing
any data that may have been in it.
**/
//===================================================================
public void pngEncode(IImage image)
//===================================================================
{
	clear();
	ByteArrayOutputStream mf = new ByteArrayOutputStream();
	PNGEncoder pe = new PNGEncoder();
	try{
		pe.writeImage(mf,image);
		mf.close();
	}catch(IOException e){}
	data = mf.toByteArray();
	length = data.length;
}

/**
This method will decode the Image that was perviously saved via pngEnocde().
**/
//===================================================================
public Picture pngDecode()
//===================================================================
{
	return new Picture(new FormattedDataSource().set(this),0);
}
//##################################################################
}
//##################################################################

