package eve.fx;
import java.awt.BasicStroke;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import eve.fx.gui.NativeWindowSurface;
import eve.fx.gui.WindowSurface;
import eve.sys.Cache;
import eve.sys.ImageData;
import eve.sys.Vm;
import eve.util.IntArray;
//##################################################################
public class Graphics implements GraphicsConstants, AlignmentConstants{
//##################################################################
	
	
	//
	public static final int OPTION_ANTI_ALIAS_TEXT = 0x1;
	public static final int OPTION_ANTI_ALIAS_DRAWING = 0x2;
	
	public static final int OPTION_TYPE_ANTI_ALIAS = 1;
	//
	public static int defaultAntiAliasOptions = 0;//OPTION_ANTI_ALIAS_TEXT;
	protected int antiAliasOptions;
	
	private static int bitChange(int whichBit, int newBits, int oldBits)
	{
		if (((newBits ^ oldBits) & whichBit) == 0) return 0;
		return ((newBits & whichBit) != 0) ? 1 : -1;
	}
	/**
	 * This is called when option bits have changed.
	 * @param optionType one of the OPTION_TYPE_XXX values.
	 * @param newOptionBits the new option bits.
	 * @param oldOptionBits the old option bits.
	 */
	protected void optionsChanged(int optionType, int newOptionBits, int oldOptionBits)
	{
		if (g == null) return;
		if (optionType == OPTION_TYPE_ANTI_ALIAS){
			int text = bitChange(OPTION_ANTI_ALIAS_TEXT, newOptionBits, oldOptionBits);
			if (text != 0)
				((Graphics2D)g).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
		                text > 0 ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
			int drawing = bitChange(OPTION_ANTI_ALIAS_DRAWING, newOptionBits, oldOptionBits);
			if (drawing != 0)
				((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		                drawing > 0 ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
		}
	}
	private int getSetOptionValue(int optionType, int value, boolean isGet)
	{
		switch(optionType){
		case OPTION_TYPE_ANTI_ALIAS:
			if (isGet) return antiAliasOptions;
			else return antiAliasOptions = value;
		}
		return 0;
	}
	/**
	 * Modify Graphics options.
	 * @param optionType one of the OPTION_TYPE_XXX values.
	 * @param optionsToSet option bits to set.
	 * @param optionsToClear option bits to clear.
	 * @return a value that can be used with restoreOptions.
	 */
	public long modifyOptions(int optionType, int optionsToSet, int optionsToClear)
	{
		int val = getSetOptionValue(optionType, 0, true);
		int oldVal = val;
		long mask = (optionsToSet|optionsToClear)&0xffffffff;
		long ret = (mask << 32) | ((long)val & 0xffffffffL);
		val |= optionsToSet;
		val &= ~optionsToClear;
		getSetOptionValue(optionType, val, false);
		optionsChanged(optionType,val,oldVal);
		return ret;
	}
	/**
	 * Restore Graphics options from a call to modifyOptions.
	 * @param optionType one of the OPTION_TYPE_XXX values.
	 * @param fromModifyOptions the value returned by modifyOptions().
	 */
	public void restoreOptions(int optionType, long fromModifyOptions)
	{
		int val = getSetOptionValue(optionType, 0, true);
		int oldVal = val;
		long mask = (fromModifyOptions >> 32) & 0xffffffffL;
		long cf = fromModifyOptions & 0xffffffffL;
		long got = val & 0xffffffffL;
		got &= ~mask;
		got |= cf;
		val = (int)got;
		getSetOptionValue(optionType, val, false);
		optionsChanged(optionType,val,oldVal);
	}
	private static boolean debugGraphics = false;
	java.awt.Graphics g;
	java.awt.Shape originalClip;
	private int tx, ty;
	private Rect clip = null;
	private String where;
	{
		if (debugGraphics) where = Vm.getStackTrace(new Exception());
	}
	public static boolean canAlphaBlend = true;//false;
	public static boolean canCopy = false;
	public static boolean canMove = true;
	public ISurface getSurface()
	{
		return surface;
	}
	private boolean cantReadFrom;
	
//	===================================================================
	public boolean isValid()
//	===================================================================
	{
		return g != null;
	}
	AffineTransform originalTransform;

private static Component last = null;

private Image faked;
/**
 * Do not use this constructor. It is to be removed soon.
 */
public Graphics(int options, Object nativeSurface)
{
	this((ISurface)nativeSurface);
}

	public Graphics(Image image)
	{
		this(image,false);
	}
	public Graphics(Image image, boolean forCopying)
	{
		this((ISurface)image,forCopying);
	}
	public Graphics(WindowSurface s, java.awt.Graphics gr)
	{
		g = gr;
		surface = s;
		setup2();
	}
//	public static final int DRAW_ALPHA = 5;
//	===================================================================
	Graphics(ISurface surface)
//	===================================================================
	{
		this(surface,false);
	}
//	-------------------------------------------------------------------
	Graphics(ISurface surface,boolean forCopying)
//	-------------------------------------------------------------------
	{
		if (surface == null) throw new NullPointerException();
		this.surface = surface;
		nativeSetup(forCopying);
		/*
		if (!forCopying)
			if (surface instanceof Image)
				if (((Image)surface).wasLoaded)
					throw new IllegalArgumentException("Cannot draw to a loaded image.");
		_nativeCreate();
		*/
	}
	
	
	void setup2()
	{
		if (g == null) return;
		originalTransform = ((Graphics2D)g).getTransform(); 
		originalClip = g.getClip();
		antiAliasOptions = defaultAntiAliasOptions;
		optionsChanged(OPTION_TYPE_ANTI_ALIAS, antiAliasOptions, ~antiAliasOptions);
		/*
		((Graphics2D)g).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        */
	}
//	-------------------------------------------------------------------
	void nativeSetup(boolean forCopying)
//	-------------------------------------------------------------------
	{
		/*
		if (surface instanceof eve.ui.Window){
			g = (java.awt.Graphics)((eve.ui.Window)surface).getNativeGraphics();
		}else
			*/
		Graphics gr = (Graphics)this;
		if (gr.surface instanceof eve.fx.Image){
			Image im = (eve.fx.Image)gr.surface;
			//if (im.wasDecoded()) throw new IllegalArgumentException("Cannot draw to a loaded image.");
			g = ((eve.fx.Image)gr.surface).bufferedImage.bi.getGraphics();
		}else if (gr.surface instanceof NativeWindowSurface){
			//new Exception("Don't get it!").printStackTrace();
			g = (java.awt.Graphics)((NativeWindowSurface)gr.surface).getNativeGraphics();
		}else {
			g = ((java.awt.Graphics)gr.surface.getNativeDrawable());
			cantReadFrom = true;
		}
		/*
		if (!forCopying)
			if (gr.surface instanceof Image)
				if (((Image)gr.surface).wasLoaded)
					throw new IllegalArgumentException("Cannot draw to a loaded image.");
					*/
		setup2();
	}

//	-------------------------------------------------------------------
	private void nativeFree()
//	-------------------------------------------------------------------
	{
		if (g != null){
			if (surface instanceof NativeWindowSurface){
				((NativeWindowSurface)surface).freeNativeGraphics(g);
			}else
				g.dispose();
		}
		if (faked != null) faked.free();
		faked = null;
		if (clip != null) clip.cache();
		clip = null;
	}
	private boolean _xorDrawMode = false;
//	-------------------------------------------------------------------
	void nativeSetDrawOp(int drawOp)
//	-------------------------------------------------------------------
	{
		if (drawOp != DRAW_XOR)
			{
			g.setPaintMode();
			_xorDrawMode = false;
			}
		else
			{
			g.setXORMode(java.awt.Color.white);
			_xorDrawMode = true;
			}
		/*
		if (drawOp != DRAW_XOR && drawOp != DRAW_OVER && !drawErrDisplayed)
			{
			System.out.println("NOTICE: DRAW_AND and DRAW_OR aren't supported under Java");
			drawErrDisplayed = true;
			}
			*/
	}

//	===================================================================
	public void flush(){}
//	===================================================================

	
//	===================================================================
	public synchronized void setClip(int x, int y, int width, int height)
//	===================================================================
	{
		if (clip == null) clip = Rect.getCached();
		clip.set(x+tx,y+ty,width,height);
		g.setClip(x+tx, y+ty, width, height);
	}
	/**
	 * Sets the x, y, width and height coordinates in the rectangle passed
	 * to the current clip coordinates. To reduce the use of temporary objects
	 * during drawing, this method does not allocate its own rectangle
	 * object. If there is no current clip, null will be returned and
	 * the rectangle passed will remain unchanged. Upon success, the
	 * rectangle passed to the method will be returned.
	 */
//	===================================================================
	public synchronized Rect getClip(Rect r)
//	===================================================================
	{
		/*
		if (r == null) return null;
		java.awt.Rectangle awtRect = g.getClipBounds();
		if (awtRect == null) return null;
		r.x = awtRect.x;
		r.y = awtRect.y;
		r.width = awtRect.width;
		r.height = awtRect.height;
		return r;
		*/
		if (clip == null) return null;
		r.set(clip);
		r.x -= tx; r.y -= ty;
		return r;
	}
//	===================================================================
	public synchronized void clearClip()
//	===================================================================
	{
		g.setClip(originalClip);
		if (clip != null) clip.cache();
		clip = null;
	}
	/**
	 * Returns if this Graphics can do Affine Transforms.
	 */
	public boolean canTransform()
	{
		return g != null;
	}
	/**
	 * This is only valid if canTransform() is true.
	 * @param em11
	 * @param em12
	 * @param em21
	 * @param em22
	 * @param edx
	 * @param edy
	 * @return true if the transform could be set, false if not.
	 */
	/*
	private synchronized boolean setTheTransform(double em11, double em12, double em21, double em22, double edx, double edy)
	{
		((Graphics2D)g).setTransform(originalTransform);
		((Graphics2D)g).transform(new AffineTransform(em11,em12,em21,em22,edx,edy));
		//System.out.println("TF: "+((Graphics2D)g).getTransform()+", from: "+edx+", "+edy);
		return true;
	}
*/
	class savedState{
		AffineTransform at;
		int tx, ty;
	}

	public synchronized Object setTransform(double em11, double em12, double em21, double em22, double edx, double edy)
	{
		savedState ss = new savedState();
		Graphics2D g2 = (Graphics2D)g;
		ss.at = g2.getTransform();
		ss.tx = tx;
		ss.ty = ty;
		tx = ty = 0;
		AffineTransform at2 = new AffineTransform(em11,em12,em21,em22,edx,edy);
		g2.setTransform(at2);
		return ss;
	}
	public Object transform(double em11, double em12, double em21, double em22, double edx, double edy)
	{
		savedState ss = new savedState();
		Graphics2D g2 = (Graphics2D)g;
		ss.at = g2.getTransform();
		ss.tx = tx;
		ss.ty = ty;
		AffineTransform at2 = new AffineTransform();
		at2.concatenate(ss.at);
		at2.translate(tx,ty);
		at2.concatenate(new AffineTransform(em11,em12,em21,em22,edx,edy));
		g2.setTransform(at2);
		tx = ty = 0;
		return ss;
	}
	public void restoreTransform(Object savedTxState)
	{
		savedState ss = (savedState)savedTxState;
		if (ss == null) return;
		Graphics2D g2 = (Graphics2D)g;
		g2.setTransform(ss.at);
		tx = ss.tx;
		ty = ss.ty;
	}
//	-------------------------------------------------------------------
	void nativeSetPen(Pen p)
//	-------------------------------------------------------------------
	{
		try{
			int j = BasicStroke.JOIN_MITER;
			int cp = BasicStroke.CAP_SQUARE;
			float ml = 1;
			if (p != null){
				ml = p.miterLimit;
				//ml = p.thickness;
				if ((p.style & p.JOIN_MASK) == p.JOIN_BEVEL) j = BasicStroke.JOIN_BEVEL;
				if ((p.style & p.JOIN_MASK) == p.JOIN_ROUND) j = BasicStroke.JOIN_ROUND;
				if ((p.style & p.CAP_MASK) == p.CAP_BUTT) cp = BasicStroke.CAP_BUTT;
				if ((p.style & p.CAP_MASK) == p.CAP_ROUND) cp = BasicStroke.CAP_ROUND;
			}
			java.awt.Stroke s = null;
			float[] dashes = null;
			if (p != null) switch(p.style){
				case Pen.DASH:
					dashes = new float[]{4.0f,4.0f};
					break;
				case Pen.DOT:
					dashes = new float[]{2.0f,2.0f};
					break;
				case Pen.DASHDOT:
					dashes = new float[]{4.0f,2.0f,2.0f,2.0f};
					break;
				case Pen.DASHDOTDOT:
					dashes = new float[]{4.0f,2.0f,2.0f,2.0f,2.0f,2.0f};
					break;
					
				default:
					s = new java.awt.BasicStroke(p.thickness,cp,j,ml);
			}
			if (dashes != null)
				s = new java.awt.BasicStroke(p.thickness,cp,j,ml,dashes,0);
			if (s == null) s = new java.awt.BasicStroke(1);
			((Graphics2D)g).setStroke(s);
		}catch(Error e){
			//if (p != null) setColor(p.color);
		}finally{
			if (p != null) g.setColor(new java.awt.Color(p.color.red,p.color.green,p.color.blue));
		}
	}

//	-------------------------------------------------------------------
	void nativeSetBrush(Brush b)
//	-------------------------------------------------------------------
	{
		Graphics gr = (Graphics)this;
		try{
			if (gr.brush == null) 
				((Graphics2D)g).setPaint(null);
			else {
				Color c = gr.brush.color;
				Color cp = gr.pen.color;
				//g.setColor(new java.awt.Color(cp.red,cp.green,cp.blue));
				Stroke st = ((Graphics2D)g).getStroke();
				((Graphics2D)g).setPaint(new java.awt.Color(c.getRed(),c.getGreen(),c.getBlue()));
				((Graphics2D)g).setStroke(st);
				//((Graphics2D)g).setPaint(new java.awt.Color(250,0,0));
			}
		}catch(Error e){}
	}

//	-------------------------------------------------------------------
	private void paint(java.awt.Shape shape,boolean useBrush,boolean usePen)
//	-------------------------------------------------------------------
	{
		Graphics gr = (Graphics)this;
		java.awt.Graphics2D g2 = (java.awt.Graphics2D)g;
		if (useBrush && gr.brush != null){
			nativeSetBrush(gr.brush);
			g2.fill(shape);
		}
		if (usePen && gr.pen != null){
			nativeSetPen(gr.pen);
			g2.draw(shape);		
		}
	}

	private static int [] rx, ry;

//	===================================================================
	public void paintRect(int x, int y, int width, int height, boolean useBrush, boolean usePen)
//	===================================================================
	{
		synchronized(((Graphics)this).glock){
			Graphics2D g2 = (Graphics2D)g;
			/*
			if (usePen && useBrush){//true||!g2.getTransform().isIdentity())
				AffineTransform at = g2.getTransform();
				if (!at.isIdentity()){
					AffineTransform at2 = new AffineTransform();
					at2.translate(tx,ty);
					at2.concatenate(at);
					g2.setTransform(at2);
					System.out.println("PR: "+g2.getTransform()+" for: "+new Rect(x,y,width,height));
					if (rx == null) {
						rx = new int[4];
						ry = new int[4];
					}
					int extra = usePen ? -1 : 0;
					rx[0] = x; ry[0] = y;
					rx[1] = x+width+extra;  ry[1] = y;
					rx[2] = x+width+extra; ry[2] = y+height+extra;
					rx[3] = x; ry[3] = y+height+extra;
					paint(new java.awt.Polygon(rx,ry,4),useBrush,usePen);
					return;
				}
					
			}
			*/
			if (rx == null) {
				rx = new int[4];
				ry = new int[4];
			}
			int extra = usePen ? -1 : 0;
			rx[0] = x+tx; ry[0] = y+ty;
			rx[1] = x+width+extra+tx;  ry[1] = y+ty;
			rx[2] = x+width+extra+tx; ry[2] = y+ty+height+extra;
			rx[3] = x+tx; ry[3] = y+ty+height+extra;
			paint(new java.awt.Polygon(rx,ry,4),useBrush,usePen);
		}
	}
//	===================================================================
	public void paintPolygon(int[] x, int[] y, int xoffset, int yoffset, int count, boolean useBrush, boolean usePen)
//	===================================================================
	{
		int dxy = 1;
		if (y == x || y == null){
			y = x;
			if (yoffset == xoffset || yoffset == xoffset+1){
				yoffset = xoffset+1;
				dxy = 2;
			}
		}
		int xo = xoffset, yo = yoffset;
		for (int i = 0; i<count; i++){
			x[xo] += tx;
			y[yo] += ty;
			xo += dxy;
			yo += dxy;
		}
		xo = xoffset; yo = yoffset;
		if (xoffset == 0 && yoffset == 0)
			paint(new java.awt.Polygon(x,y,count),useBrush,usePen);
		else{
			java.awt.Polygon p = new java.awt.Polygon();
			for (int i = 0; i<count; i++){
				p.addPoint(x[xo],y[yo]);
				xo += dxy;
				yo += dxy;
			}
			paint(p,useBrush,usePen);
		}
		xo = xoffset; yo = yoffset;
		for (int i = 0; i<count; i++){
			x[xo] -= tx;
			y[yo] -= ty;
			xo += dxy;
			yo += dxy;
		}
		
	}
	/**
	Draw a line between two points in the current pen.
	@param x1 The starting x-coordinate.
	@param y1 The starting y-coordinate.
	@param x2 The ending x-coordinate.
	@param y2 The ending y-coordinate.
	*/
//	===================================================================
	public void drawLine(int x1, int y1, int x2, int y2)
//	===================================================================
	{
		if (pen != null) nativeSetPen(pen);
		g.drawLine(x1+tx, y1+ty, x2+tx, y2+ty);
	}
	/**
	 * Translates the origin of the current coordinate system by the given
	 * x and y values.
	 */
//	===================================================================
	public void translate(int x, int y)
//	===================================================================
	{
		tx += x;
		ty += y;
	}
	private int _fontAscent;
	private Font curFont;
//	-------------------------------------------------------------------
	void nativeSetFont(Font f)
//	-------------------------------------------------------------------
	{
		curFont = f;
		Font font = ((Graphics)this).font;
		java.awt.Font awtFont = font._getAWTFont();
		g.setFont(awtFont);
		java.awt.FontMetrics fm;
		fm = java.awt.Toolkit.getDefaultToolkit().getFontMetrics(font._getAWTFont());
		_fontAscent = fm.getAscent();
	}
//	===================================================================
	public void old_drawText(char chars[], int start, int count, int x, int y)
//	===================================================================
	{
		String s = new String(chars,start,count);
		g.drawString(Graphics.getDisplayable(s), x+tx, y+ty + _fontAscent);
		int which = Graphics.getUnderlined(s);
		if (curFont != null && which != -1)
			underline(curFont,eve.sys.Vm.getStringChars(s),0,s.length()-2,which,x,y);	
	}
	/**
	 * Draws text at the given coordinates. The x and y coordinates specify
	 * the upper left hand corner of the text.
	 */
//	public native void drawText(String s, int x, int y);
	public void drawText(char chars[], int start, int count, int x, int y)
		{
		String s = new String(chars,start,count);
		int cs = curFont.getStyle();
		if((cs & Font.UNDERLINE) == Font.UNDERLINE){
			String t = getDisplayable(s);
			if (t.length() == 0) return;
		     java.text.AttributedString aString= new java.text.AttributedString(t);
		     int style = 0;
		     if ((cs & Font.BOLD) != 0) style |= java.awt.Font.BOLD;
		     if ((cs & Font.ITALIC) != 0) style |= java.awt.Font.ITALIC;
		     if (style == 0) style = java.awt.Font.PLAIN;
		     java.awt.Font font = new java.awt.Font(curFont.getName(), style, (curFont.getSize()*8)/10);
		     aString.addAttribute(java.awt.font.TextAttribute.FONT, font);
		     aString.addAttribute(java.awt.font.TextAttribute.UNDERLINE, java.awt.font.TextAttribute.UNDERLINE_ON);
		     g.drawString(aString.getIterator(), x+tx, y+ty + _fontAscent);
		}
		else{
			g.drawString(Graphics.getDisplayable(s), x+tx, y+ty + _fontAscent);
			int which = Graphics.getUnderlined(s);
			if (curFont != null && which != -1)
				underline(curFont,eve.sys.Vm.getStringChars(s),0,s.length()-2,which,x,y);
		}
		}
//	===================================================================
	public void copyRect(Graphics source,int x,int y,int width,int height,int destX, int destY)
//	===================================================================
	{
		if (source.surface instanceof Image){
			g.drawImage(((Image)source.surface).bufferedImage.bi,destX+tx,destY+ty,destX+tx+width,destY+ty+height,x+source.tx,y+source.ty,x+source.tx+width,y+source.ty+height,null);
		}
	}
//	-------------------------------------------------------------------
	public void drawImage(Image image,int x,int y)//,int width,int height)
//	-------------------------------------------------------------------
	{
		g.drawImage(image.bufferedImage.bi,x+tx,y+ty,null);
	}
//	-------------------------------------------------------------------
	public void drawPicture(Picture image,int x,int y)//,int width,int height)
//	-------------------------------------------------------------------
	{
		g.drawImage(image.bufferedImage.bi,x+tx,y+ty,null);
	}
	/*
	public void drawImage(
//	-------------------------------------------------------------------
	Image image,
	Rect sourceImageArea,
	Rect destArea,
	int scaleOptions)
	{
		//TODO
	}
*/
	private static GraphicsImageData gid = new GraphicsImageData();
	private static ImageSubSection sec = new ImageSubSection();
	public void draw(ImageData im, int x, int y)
	{
		if (im instanceof Drawable)
			((Drawable)im).draw(this,x,y,0);
		else{
			Rect s = Rect.getCached(0,0,im.getImageWidth(),im.getImageHeight());
			Rect d = Rect.getCached(x,y,s.width,s.height);
			drawImageData(im,s,d,0);
			s.cache();
			d.cache();
		}
	}
	public void drawImageData(ImageData im, Rect sourceImageArea, Rect destArea, int scaleOptions)
	{
		synchronized(gid){
			gid.setFor(this,destArea,true);
			sec.setFor(im,sourceImageArea.x, sourceImageArea.y, sourceImageArea.width, sourceImageArea.height);
			ImageTool.scaleSection(sec,destArea.width,destArea.height,gid,0,0,scaleOptions);
		}
	}
	/**
	 * Scale and draw an ImageData to the Graphics, specifying the destination area
	 * that is to be drawn on the Graphics - all other sections of the image will
	 * be clipped.
	 * @param src the source ImageData
	 * @param drawX the x location where the top left location of the ImageData would be
	 * if the entire image was drawn.
	 * @param drawY the y location where the top left location of the ImageData would be
	 * if the entire image was drawn.
	 * @param drawWidth the full width of the scaled image.
	 * @param drawHeight the full heigh of the scaled image.
	 * @param visibleArea the destination area being updated on the Graphics.
	 * @param scaleOptions scale options.
	 */
	public void drawImageData(ImageData source, int drawX, int drawY, int drawWidth, int drawHeight, Rect visibleArea, int scaleOptions)
	{
		Rect r = Rect.getCached(drawX,drawY,drawWidth,drawHeight);
		try{
			if (visibleArea != null) visibleArea.getIntersection(r,r);
			if (r.width < 1 || r.height < 1) return;
			GraphicsImageData gid = (GraphicsImageData)Cache.get(GraphicsImageData.class);
			try{
				ImageData dest = gid.setFor(this,r.x,r.y,r.width,r.height,true);
				ImageTool.scaleSection(source,drawWidth,drawHeight,dest,r.x-drawX,r.y-drawY,scaleOptions);
			}finally{
				gid.free();
				Cache.put(gid);
			}
		}finally{
			r.cache();
		}
	}
	
	IntArray ia;
	public synchronized void drawRGB(int[] rgbData,int offset,int x,int y,int width,int height,int rowStride,boolean useAlpha)
	{
		if (rowStride <= 0) rowStride = width;
		if (cantReadFrom){
			GraphicsConfiguration gc = ((Graphics2D)g).getDeviceConfiguration();
			BufferedImage bi = gc.createCompatibleImage(width,1);
			if (useAlpha){
				for (int h = 0; h<height; h++){
					int i = 0;
					int start = 0;
					while(true){
						while(i<width && ((rgbData[offset+i] & 0xff000000) == 0))
							i++;
						if (i >= width) break;
						start = i;
						while(i<width && ((rgbData[offset+i] & 0xff000000) != 0))
							i++;
						int count = i-start;
						if (bi.getWidth() != count){
							bi.flush();
							bi = gc.createCompatibleImage(count,1);
						}
						bi.setRGB(0,0,count,1,rgbData,start+offset,count);
						g.drawImage(bi,x+tx+start,y+ty+h,null);
					}
					offset += rowStride;
					//g.drawImage(bi,x+tx,y+ty,x+tx+width,y+ty+1,0,0,width,1,null);
					/*
					g.drawImage(bi,
							x+tx,y+ty+h,x+tx+width-1,y+ty+h,
							0,0,width-1,0,null);
					*/
				}
			}else{
				bi =  gc.createCompatibleImage(width,height);
				bi.setRGB(0,0,width,height,rgbData,offset,rowStride);
				g.drawImage(bi,x+tx,y+ty,null);
				bi.flush();
			}
		}else{
			BufferedImage bi = Image.createBI(width,height,useAlpha);
			bi.setRGB(0,0,width,height,rgbData,offset,rowStride);
			g.drawImage(bi,x+tx,y+ty,null);
		}
	}

	static ImageBuffer rgbBuff = new ImageBuffer();
	public boolean getRGB(int[] destRgbData,int offset,int x, int y,int width,int height,int rowStride)
	{
		if (!canCopyFrom()) return false;
		synchronized(rgbBuff){
			Graphics g = rgbBuff.get(width,height,false);
			g.copyRect(this,x,y,width,height,0,0);
			rgbBuff.image.getPixels(destRgbData,offset,0,0,width,height,rowStride);
			return true;
		}
	}
	
//	===================================================================
	public static int mapColor(int oldColor) {return oldColor;}
//	===================================================================

//	===================================================================
	public void paintEllipse(int x, int y, int width, int height, boolean useBrush, boolean usePen)
//	===================================================================
	{
		paint(new java.awt.geom.Ellipse2D.Float(x+tx,y+ty,width,height),useBrush,usePen);
		/*
		if (useBrush && brush != null){
			g.fillOval(x,y,width,height);
		}
		if (usePen && pen != null){
			g.drawOval(x,y,width,height);
		}
		*/
	}
//	===================================================================
	public void moveRect(int sx, int sy, int swidth, int sheight, int destX, int destY)
//	===================================================================
	{
		g.copyArea(sx+tx,sy+ty,swidth,sheight,destX-sx,destY-sy);
	}
	
static Object glock = new Object();
int nativeGraphics;
ISurface surface;
Pen pen = new Pen(Color.Black,Pen.SOLID,1);
Brush brush = new Brush(Color.Black,Brush.SOLID);
Color color = new Color(0,0,0);
Color background = new Color(255,255,255);
Color foreground = new Color(0,0,0);
Font font;
int drawOp;

/**
Get the surface type of the Graphics.
@return one of the XXX_SURFACE values.
*/
//===================================================================
public int getSurfaceType()
//===================================================================
{
	if (surface instanceof WindowSurface) return ISurface.WINDOW_SURFACE;
	else if (surface instanceof Image) return ISurface.IMAGE_SURFACE;
	//else if (surface instanceof eve.fx.PrinterJob) return ISurface.PRINTERJOB_SURFACE;
	else return 0;
}
/**
* This returns true if you can do a bitBlt() using this Graphics object as a source.
*/
//===================================================================
public boolean canCopyFrom()
//===================================================================
{
	int t = getSurfaceType();
	if (t == ISurface.IMAGE_SURFACE) return true;
	if (t != ISurface.WINDOW_SURFACE) return false;
	return canCopy;
}

/**
 * The constant for a draw operation that draws the source over
 * the destination.
 */
public static final int DRAW_OVER = 1;

/**
 * The constant for a draw operation that AND's the source with the
 * destination. Commonly used to create image masks.
 */
public static final int DRAW_AND = 2;

/**
 * The constant for a draw operation that OR's the source with the
 * destination. Commonly used with image masks.
 */
public static final int DRAW_OR = 3;

/**
 * The constant for a draw operation that XOR's the source with the
 * destination.
 */
public static final int DRAW_XOR = 4;


//===================================================================
public void setDrawOp(int drawOp)
//===================================================================
{
	this.drawOp = drawOp;
	nativeSetDrawOp(drawOp);
}
private void penChanged()
{
	if (pen.style == pen.NULL) nativeSetPen((Pen)null);
	else nativeSetPen(pen);
}
private void brushChanged()
{
	if (brush.style == brush.NULL) nativeSetBrush((Brush)null);
	else nativeSetBrush(brush);
}
//===================================================================
public Pen getPen()
//===================================================================
{
	return pen.style == Pen.NULL ? null : pen.getCopy();
}
//===================================================================
public Brush getBrush()
//===================================================================
{
	return brush.style == Brush.NULL ? null : brush.getCopy();
}
//===================================================================
public Pen setPen(Pen p)
//===================================================================
{
	Pen ret = getPen();
	pen.set(p);
	penChanged();
	return ret;
}
//===================================================================
public Brush setBrush(Brush b)
//===================================================================
{
	Brush ret = getBrush();
	brush.set(b);
	brushChanged();
	return ret;
}
/**
 * Set the pen without creating or returning a new Pen object.
 * @param p the new value of the pen. This can be null.
 */
public void set(Pen p)
{
	pen.set(p);
	penChanged();
}
/**
 * Set the brush without creating or returning a new Brush object.
 * @param b the new value of the brush. This can be null.
 */
public void set(Brush b)
{
	brush.set(b);
	brushChanged();
}
public Pen getPen(Pen dest)
{
	if (dest == null) dest = new Pen();
	dest.set(pen);
	return dest;
}
public Brush getBrush(Brush dest)
{
	if (dest == null) dest = new Brush();
	dest.set(brush);
	return dest;
}
public Pen setPen(Pen p, Pen oldPen)
{
	if (oldPen == null) oldPen = new Pen();
	oldPen.set(pen);
	pen.set(p);
	penChanged();
	return oldPen;
}
public Brush setBrush(Brush b, Brush oldBrush)
{
	if (oldBrush == null) oldBrush = new Brush();
	oldBrush.set(brush);
	brush.set(b);
	brushChanged();
	return oldBrush;
}
public Color setColor(Color c, Color oldColor)
{
	if (oldColor == null) oldColor = new Color();
	oldColor.set(color);
	setColor(c);
	return oldColor;
}
public Color setBackground(Color bk, Color oldBk)
{
	if (oldBk == null) oldBk = new Color();
	oldBk.set(background);
	background.set(bk);
	return oldBk;
}

//===================================================================
public void setColor(int r, int g, int b)
//===================================================================
{
	color.set(r,g,b);
	pen.color.set(r,g,b);
	pen.style = Pen.SOLID;
	pen.thickness = 1;
	brush.color.set(r,g,b);
	brush.style = Brush.SOLID;
	penChanged();
	brushChanged();
}
//===================================================================
public void setColor(Color c)
//===================================================================
{
	setColor(c.getRed(),c.getGreen(),c.getBlue());
}
/**
The Foreground color is <b>not</b> the current drawing color, but
merely an indication on what the preferred foreground color currently
is for this Graphics.
*/
//===================================================================
public void setForeground(Color c)
//===================================================================
{
	//setForeground(c.getRed(),c.getGreen(),c.getBlue());
	foreground.set(c);
}
/**
The Foreground color is <b>not</b> the current drawing color, but
merely an indication on what the preferred foreground color currently
is for this Graphics.
*/
//===================================================================
public void setForeground(int r, int g, int b)
//===================================================================
{
	foreground.set(r,g,b);	
}
//===================================================================
public void setBackground(Color c)
//===================================================================
{
	//setBackground(c.getRed(),c.getGreen(),c.getBlue());
	background.set(c);
}
//===================================================================
public void setBackground(int r, int g, int b)
//===================================================================
{
	background.set(r,g,b);	
}
//===================================================================
public Color getColor(Color dest)
//===================================================================
{
	if (dest == null) dest = new Color(0,0,0);
	dest.set(color);
	return dest;
}
//===================================================================
public Color getBackground(Color dest)
//===================================================================
{
	if (dest == null) dest = new Color(0,0,0);
	dest.set(background);
	return dest;
}

//===================================================================
public Color getColor()
//===================================================================
{
	return new Color(color.getRed(),color.getGreen(),color.getBlue());
}
//===================================================================
public Color getBackground()
//===================================================================
{
	return new Color(background.getRed(),background.getGreen(),background.getBlue());
}

//-------------------------------------------------------------------
private boolean freed = false;
//-------------------------------------------------------------------
/**
Free resources used by this Graphics. Although this will be done when the
Graphics is garbage collected you may wish to do it earlier.
*/
//===================================================================
public synchronized void free()
//===================================================================
{
	if (freed) return;
	nativeFree();
	freed = true;
}
//-------------------------------------------------------------------
protected void finalize() throws Throwable
//-------------------------------------------------------------------
{
	if (debugGraphics){
		if (!freed) Vm.debug("Unfreed graphics: "+where);
		//else Vm.debug("Freed graphics!");
	}
	free();
}

/**
Set the current Font of the Graphics.
@param f the Font to set.
*/
//===================================================================
public void setFont(Font f)
//===================================================================
{
	font = f;	
	nativeSetFont(f);
}
/**
Get the current Font for the Graphics.
@return the current Font for the Graphics.
*/
//===================================================================
public Font getFont()
//===================================================================
{
	return font;
}
/**
 * Draws a dotted line at the given coordinates. Dotted lines must
 * be either horizontal or vertical, they can't be drawn at arbitrary angles.
 */
//public native void drawDots(int x1, int y1, int x2, int y2);
//===================================================================
public void drawDots(int x1, int y1, int x2, int y2)
//===================================================================
	{
	if (x1 == x2) // vertical
		{
		if (y1 > y2)
			{
			int y = y1;
			y1 = y2;
			y2 = y;
			}
		for (; y1 < y2; y1 += 2)
			drawLine(x1, y1, x1, y1);
		}
	else if (y1 == y2) // horizontal
		{
		if (x1 > x2)
			{
			int x = x1;
			x1 = x2;
			x2 = x;
			}
		for (; x1 < x2; x1 += 2)
			drawLine(x1, y1, x1, y1);
		}
	}
/**
Draw a 3D styled rectangle.
@param r 
@param style 
@param flat 
@param fill 
@param outlineColor 
@param labelWidth 
*/
//===================================================================
//public native void draw3DRect(Rect r,int style,boolean flat,Color fill,Color outlineColor,int labelWidth);
//===================================================================
/*
//===================================================================
public void draw3DRect(Rect r,int style,boolean flat,Color fill,Color outlineColor)
//===================================================================
{
	draw3DRect(r,style,flat,fill,outlineColor,0);
}
*/
/**
Draw a rectangle in the current Pen, but do not fill the inside.
@param x The x position of the rectangle.
@param y The y position of the rectangle.
@param width The width of the rectangle.
@param height The height of the rectangle.
*/
//===================================================================
public void drawRect(int x, int y, int width, int height)
//===================================================================
{
	paintRect(x,y,width,height,false,true);
}
/**
Fill a rectangle in the current Brush but do not draw around it using the pen.
@param x The x position of the rectangle.
@param y The y position of the rectangle.
@param width The width of the rectangle.
@param height The height of the rectangle.
*/
//===================================================================
public void fillRect(int x, int y, int width, int height)
//===================================================================
{
	paintRect(x,y,width,height,true,false);
}
/**
Draw a rectangle in the current Pen and fill with the current Brush.
@param x The x position of the rectangle.
@param y The y position of the rectangle.
@param width The width of the rectangle.
@param height The height of the rectangle.
*/
//===================================================================
public void paintRect(int x, int y, int width, int height)
//===================================================================
{
	paintRect(x,y,width,height,true,true);
}
/**
Draw a polygon in the current Pen, but do not fill the inside.
@param x The x positions of the polygon. Do not repeat the first point.
@param y The y positions of the polygon. Do not repeat the first point.
@param count The number of points in the polygon.
*/
//===================================================================
public void drawPolygon(int []x, int []y, int count)
//===================================================================
{
	paintPolygon(x,y,0,0,count,false,true);
}
/**
Fill a polygon in the current Brush, but do not draw the outside.
@param x The x positions of the polygon. Do not repeat the first point.
@param y The y positions of the polygon. Do not repeat the first point.
@param count The number of points in the polygon.
*/
//===================================================================
public void fillPolygon(int []x, int []y, int count)
//===================================================================
{
	paintPolygon(x,y,0,0,count,true,false);
}
/**
Fill a polygon in the current Brush, and draw the outside in the current Pen.
@param x The x positions of the polygon. Do not repeat the first point.
@param y The y positions of the polygon. Do not repeat the first point.
@param count The number of points in the polygon.
*/
//===================================================================
public void paintPolygon(int []x, int []y, int count)
//===================================================================
{
	paintPolygon(x,y,0,0,count,true,true);
}
/**
Draw an ellipse in the current Pen, but do not fill the inside.
@param x The x position of the rectangle.
@param y The y position of the rectangle.
@param width The width of the rectangle.
@param height The height of the rectangle.
*/
//===================================================================
public void drawEllipse(int x, int y, int width, int height)
//===================================================================
{
	paintEllipse(x,y,width,height,false,true);
}
/**
Fill an ellipse in the current Brush but do not draw around it using the pen.
@param x The x position of the rectangle.
@param y The y position of the rectangle.
@param width The width of the rectangle.
@param height The height of the rectangle.
*/
//===================================================================
public void fillEllipse(int x, int y, int width, int height)
//===================================================================
{
	paintEllipse(x,y,width,height,true,false);
}
/**
Draw an ellipse in the current Pen and fill with the current Brush.
@param x The x position of the rectangle.
@param y The y position of the rectangle.
@param width The width of the rectangle.
@param height The height of the rectangle.
*/
//===================================================================
public void paintEllipse(int x, int y, int width, int height)
//===================================================================
{
	paintEllipse(x,y,width,height,true,true);
}

/**
Fill in a rectangle with the current Brush, and optionally draw around it
with the current pen.
@param x The x position of the rectangle.
@param y The y position of the rectangle.
@param width The width of the rectangle.
@param height The height of the rectangle.
@param usePen If this is false the pen will not be applied to the outline of the rectangle.
*/
/*
//===================================================================
public void fillRect(int x, int y, int width, int height,boolean usePen)
//===================================================================
{
	drawRect(x,y,width,height,true,usePen);
}
*/
//===================================================================
public void drawText(String s,int x,int y)
//===================================================================
{
	char[] toDraw = Vm.getStringChars(s);
	drawText(toDraw,0,toDraw.length,x,y);	
}
public static Color LighterGray = Color.LighterGray;
//===================================================================
public void drawEdge(Rect r,int edge,int flags,int labelWidth)
//===================================================================
{
		
		int x = r.x, y = r.y, w = r.width, h = r.height;
		int rec = 0;
		if (((edge|BF_RECT) & EDGE_SUNKEN) == EDGE_SUNKEN){
			if ((flags & BF_TOP) != 0) {
				if (labelWidth == 0){
					setColor(Color.DarkGray);
					drawLine(x,y,x+w-1,y);
					setColor(Color.Black);
					drawLine(x+1,y+1,x+w-2,y+1);
				}else{
					setColor(Color.DarkGray);
					drawLine(x,y,x+4,y);
					setColor(Color.Black);
					drawLine(x+1,y+1,x+4,y+1);
					setColor(Color.DarkGray);
					drawLine(x+4+labelWidth,y,x+w-1,y);
					setColor(Color.Black);
					drawLine(x+4+labelWidth,y+1,x+w-2,y+1);
				}
			}				
			if ((flags & BF_LEFT) != 0) {
				setColor(Color.DarkGray);
				drawLine(x,y,x,y+h-1);
				setColor(Color.Black);
				drawLine(x+1,y+1,x+1,y+h-2);
			}				
			if ((flags & BF_BOTTOM) != 0) {
				setColor(Color.White);
				drawLine(x,y+h-1,x+w-1,y+h-1);
				setColor(LighterGray);
				drawLine(x+1,y+h-2,x+w-2,y+h-2);
			}				
			if ((flags & BF_RIGHT) != 0) {
				setColor(Color.White);
				drawLine(x+w-1,y,x+w-1,y+h-1);
				setColor(LighterGray);
				drawLine(x+w-2,y+1,x+w-2,y+h-2);
			}				
		}else if (((edge|BF_RECT) & EDGE_ETCHED) == EDGE_ETCHED){
			if ((flags & BF_TOP) != 0) {
				if (labelWidth == 0){
					setColor(Color.DarkGray);
					drawLine(x,y,x+w-1,y);
					setColor(Color.White);
					drawLine(x+1,y+1,x+w-2,y+1);
				}else{
					setColor(Color.DarkGray);
					drawLine(x,y,x+4,y);
					setColor(Color.White);
					drawLine(x+1,y+1,x+4,y+1);
					setColor(Color.DarkGray);
					drawLine(x+4+labelWidth,y,x+w-1,y);
					setColor(Color.White);
					drawLine(x+4+labelWidth,y+1,x+w-2,y+1);
				}
			}				
			if ((flags & BF_LEFT) != 0) {
				setColor(Color.DarkGray);
				drawLine(x,y,x,y+h-1);
				setColor(Color.White);
				rec = ((flags & BF_BOTTOM) != 0) ? 1 : 0;
				drawLine(x+1,y+1,x+1,y+h-1-rec);
			}				
			if ((flags & BF_BOTTOM) != 0) {
				setColor(Color.White);
				drawLine(x,y+h-1,x+w-1,y+h-1);
				setColor(Color.DarkGray);
				drawLine(x+1,y+h-2,x+w-2,y+h-2);
			}				
			if ((flags & BF_RIGHT) != 0) {

				setColor(Color.White);
				drawLine(x+w-1,y,x+w-1,y+h-1);
				setColor(Color.DarkGray);
				rec = ((flags & BF_BOTTOM) != 0) ? 1 : 0;
				drawLine(x+w-2,y+1,x+w-2,y+h-1-rec);
				
			}				
		}else if (((edge|BF_RECT) & EDGE_BUMP) == EDGE_BUMP){
			if ((flags & BF_TOP) != 0) {
				if (labelWidth == 0){
					setColor(LighterGray);
					drawLine(x,y,x+w-1,y);
					setColor(Color.Black);
					drawLine(x+1,y+1,x+w-2,y+1);
				}else{
					setColor(LighterGray);
					drawLine(x,y,x+4,y);
					setColor(Color.Black);
					drawLine(x+1,y+1,x+4,y+1);
					setColor(LighterGray);
					drawLine(x+4+labelWidth,y,x+w-1,y);
					setColor(Color.Black);
					drawLine(x+4+labelWidth,y+1,x+w-2,y+1);
				}
			}				
			if ((flags & BF_LEFT) != 0) {
				setColor(LighterGray);
				drawLine(x,y,x,y+h-1);
				setColor(Color.Black);
				drawLine(x+1,y+1,x+1,y+h-2);
			}				
			if ((flags & BF_BOTTOM) != 0) {
				setColor(Color.Black);
				drawLine(x,y+h-1,x+w-1,y+h-1);
				setColor(LighterGray);
				drawLine(x+1,y+h-2,x+w-2,y+h-2);
			}				
			if ((flags & BF_RIGHT) != 0) {
				setColor(Color.Black);
				drawLine(x+w-1,y,x+w-1,y+h-1);
				setColor(LighterGray);
				drawLine(x+w-2,y+1,x+w-2,y+h-2);
			}				
		}else{
			if ((flags & BF_TOP) != 0) {
				if (labelWidth == 0){
					setColor(LighterGray);
					drawLine(x,y,x+w-1,y);
					setColor(Color.White);
					drawLine(x+1,y+1,x+w-2,y+1);
				}else{
					setColor(LighterGray);
					drawLine(x,y,x+4,y);
					setColor(Color.White);
					drawLine(x+1,y+1,x+4,y+1);
					setColor(LighterGray);
					drawLine(x+4+labelWidth,y,x+w-1,y);
					setColor(Color.White);
					drawLine(x+4+labelWidth,y+1,x+w-2,y+1);
				}
			}				
			if ((flags & BF_LEFT) != 0) {
				setColor(LighterGray);
				drawLine(x,y,x,y+h-1);
				rec = ((flags & BF_BOTTOM) != 0) ? 1 : 0;
				setColor(Color.White);
				drawLine(x+1,y+1,x+1,y+h-1-rec);
			}				
			if ((flags & BF_BOTTOM) != 0) {
				setColor(Color.Black);
				drawLine(x,y+h-1,x+w-1,y+h-1);
				setColor(Color.DarkGray);
				drawLine(x+1,y+h-2,x+w-2,y+h-2);
			}				
			if ((flags & BF_RIGHT) != 0) {
				setColor(Color.Black);
				drawLine(x+w-1,y,x+w-1,y+h-1);
				rec = ((flags & BF_BOTTOM) != 0) ? 1 : 0;
				setColor(Color.DarkGray);
				drawLine(x+w-2,y+1,x+w-2,y+h-1-rec);
			}				
		}
}

//===================================================================
public void changePen(Color c,int style,int thickness)
//===================================================================
{
	changePen(c,style,thickness,(float)thickness);
}
//===================================================================
public void changePen(Color c,int style,int thickness,float miterLimit)
//===================================================================
{
	if (pen == null) pen = new Pen(c,style,thickness);
	else {
		pen.color.set(c);
		pen.style = style;
		pen.thickness = thickness;
	}
	pen.miterLimit = miterLimit;
	nativeSetPen(pen);
}
//===================================================================
public void changeBrush(Color c,int style)
//===================================================================
{
	if (c == null) brush = null;
	else if (brush == null) brush = new Brush(c,style);
	else{
		brush.color.set(c);
		brush.style = style;
	}
	nativeSetBrush(brush);
}

/**
* This alters the clipping region of the current graphics to be the intersection
* of the original clipping region and the newly specified region. It returns a Rect
* which you can then use to call restoreClip() to return the clipping region to its
* original value. This works even if there was no original clipping region since null
* will be returned in that case.
@param x The x coordinate of the new clipping region.
@param y The y coordinate of the new clipping region.
@param width The width of the new clipping region.
@param height The height of the new clipping region.
@param oldClip An optional Rect to hold the old clip region.
@return A Rect holding the old clip region or null if there was no old
clip region.
*/
//===================================================================
public synchronized Rect reduceClip(int x,int y,int width,int height,Rect oldClip)
//===================================================================
{
	Rect reducedClip = Rect.getCached();
	try{
		if (oldClip == null) oldClip = new Rect();
		Rect r = getClip(oldClip);
		if (r == null) {
			setClip(x,y,width,height);
			return null;
		}else{
			Rect r2 = reducedClip.set(x,y,width,height);
			r.getIntersection(r2,r2);
			setClip(r2.x,r2.y,r2.width,r2.height);
			return r;
		}
	}finally{
		reducedClip.cache();
	}
}
/**
* This alters the clipping region of the current graphics to be the intersection
* of the original clipping region and the newly specified region. It returns a Rect
* which you can then use to call restoreClip() to return the clipping region to its
* original value. This works even if there was no original clipping region.
**/
//===================================================================
public Rect reduceClip(Rect newRect)
//===================================================================
{
	return reduceClip(newRect.x,newRect.y,newRect.width,newRect.height,new Rect());
}
/**
* Use this with a Rect value returned from reduceClip()
**/
//===================================================================
public void restoreClip(Rect r)
//===================================================================
{
	if (r == null) clearClip();
	else setClip(r.x,r.y,r.width,r.height);
}
//-------------------------------------------------------------------
private void doPolygon(Object [] points,boolean fill)
//-------------------------------------------------------------------
{
	int [] xp = (int [])points[0], yp = (int [])points[1];
	if (fill) fillPolygon(xp,yp,yp.length);
	else drawPolygon(xp,yp,yp.length);
}
//-------------------------------------------------------------------
private void doLines(Object [] points)
//-------------------------------------------------------------------
{
	int [] xp = (int [])points[0], yp = (int [])points[1];
	drawLines(xp,yp,yp.length);
}
public void drawLines(int x[], int y[], int xoffset, int yoffset, int numberOfPoints, boolean separateLines)
{
	int dxy = 1;
	if (y == null || y == x) {
		y = x;
		if (yoffset == xoffset || yoffset == xoffset+1){
			yoffset = xoffset+1;
			dxy = 2;
		}
	}
	for (int i = 0; i<numberOfPoints-1; i++){
		drawLine(x[xoffset],y[yoffset],x[xoffset+dxy],y[yoffset+dxy]);
		xoffset += dxy;
		yoffset += dxy;
		if (separateLines){
			i++;
			xoffset += dxy;
			yoffset += dxy;
		}
	}
}

private static Color roundOutline = Color.DarkGray;//new Color(0,0,50);
private static Color innerFill = new Color(0,0,0), innerLine = new Color(0,0,0);
private static final int fillChange = 20;
//-------------------------------------------------------------------
private void draw3DRoundRect(Rect r,int style,boolean flat,Color fill,Color outlineColor,int labelWidth)
//-------------------------------------------------------------------
{
	changePen(outlineColor,Pen.SOLID,1);
	Curve.curve.drawRoundRectOutline(this, style, r.x, r.y, r.width, r.height, 3, labelWidth);
	
	int edge = style|BF_RECT;
	boolean down = ((edge & EDGE_SUNKEN) == EDGE_SUNKEN);
	if ((style & BF_FLAT) == BF_FLAT) flat = true;
	boolean button = ((style & BF_BUTTON) != 0);
	boolean outline = ((style & BDR_OUTLINE) != 0);
	innerLine.set(Color.LighterGray);
	if (fill != null && button){
		if (down)
			innerFill.set(
				fill.red-fillChange < 0 ? 0 : fill.red-fillChange,
				fill.green-fillChange < 0 ? 0 : fill.green-fillChange,
				fill.blue-fillChange < 0 ? 0 : fill.blue-fillChange);
		else{
			int fc = fillChange*2;
			innerLine.set(
				fill.red+fc > 255 ? 255 : fill.red+fc,
				fill.green+fc > 255 ? 255 : fill.green+fc,
				fill.blue+fc > 255 ? 255 : fill.blue+fc);
			innerFill.set(
				fill.red+fillChange > 255 ? 255 : fill.red+fillChange,
				fill.green+fillChange > 255 ? 255 : fill.green+fillChange,
				fill.blue+fillChange > 255 ? 255 : fill.blue+fillChange);
		}
		fill = innerFill;
	}
	if ((style & BDR_OUTLINE) == 0 || outlineColor == null) outlineColor = roundOutline;
	//Object [] got = getRoundRectPoints(style,r.x,r.y,r.width,r.height,3,labelWidth);
	boolean willDoInner = !flat && !down;
	if ((style & BF_RECT) == BF_RECT) {
		changePen(outlineColor,Pen.SOLID,1);
		if (fill != null){
			changeBrush(willDoInner ? innerLine : fill,Brush.SOLID);
			paintRoundRect(r.x, r.y, r.width, r.height, 3, true, true);
			//doPolygon(got,true);
			//doPolygon(got,false);
		}else{
			Curve.curve.drawRoundRectOutline(this, style, r.x, r.y, r.width, r.height, 3, labelWidth);
			//if (labelWidth == 0) doPolygon(got,false);
			//else doLines(got);
		}				
		if (!flat && !down){
			//got = getRoundRectPoints(style,r.x+1,r.y+1,r.width-2,r.height-2,3,labelWidth);
			changePen(innerLine,Pen.SOLID,1);
			if (fill != null){
				changeBrush(fill,Brush.SOLID);
				paintRoundRect(r.x+1, r.y+1, r.width-2, r.height-2, 3, true, false);
				//doPolygon(got,true);
			}else{
				Curve.curve.drawRoundRectOutline(this, style, r.x+1, r.y+1, r.width-2, r.height-2, 3, labelWidth);
				//if (labelWidth == 0) doPolygon(got,false);
				//else doLines(got);
			}				
		}
	}else{
		//setPen(null);
		changePen(outlineColor,Pen.SOLID,1);
		changeBrush(fill,Brush.SOLID);
		if (fill != null)
			paintRoundRect(r.x, r.y, r.width, r.height, 3, true, false);
		Curve.curve.drawRoundRectOutline(this, style,  r.x, r.y, r.width, r.height, 3, labelWidth);
		//doPolygon(got,fill != null);
		//changePen(outlineColor,Pen.SOLID,1);
		//doLines(got);
		if (!flat){
			//got = getRoundRectPoints(style,r.x+1,r.y+1,r.width-2,r.height-2,3,labelWidth);
			changePen(innerLine,Pen.SOLID,1);
			Curve.curve.drawRoundRectOutline(this, style,  r.x+1, r.y+1, r.width-2, r.height-2, 3, labelWidth);
			//doLines(got);
		}
	}

}

//-------------------------------------------------------------------
private void old_draw3DRoundRect(Rect r,int style,boolean flat,Color fill,Color outlineColor,int labelWidth)
//-------------------------------------------------------------------
{
	//style = (style & ~BF_BOTTOM); //FIXME
	int edge = style|BF_RECT;
	boolean down = ((edge & EDGE_SUNKEN) == EDGE_SUNKEN);
	if ((style & BF_FLAT) == BF_FLAT) flat = true;
	boolean button = ((style & BF_BUTTON) != 0);
	boolean outline = ((style & BDR_OUTLINE) != 0);
	innerLine.set(Color.LighterGray);
	if (fill != null && button){
		if (down)
			innerFill.set(
				fill.red-fillChange < 0 ? 0 : fill.red-fillChange,
				fill.green-fillChange < 0 ? 0 : fill.green-fillChange,
				fill.blue-fillChange < 0 ? 0 : fill.blue-fillChange);
		else{
			int fc = fillChange*2;
			innerLine.set(
				fill.red+fc > 255 ? 255 : fill.red+fc,
				fill.green+fc > 255 ? 255 : fill.green+fc,
				fill.blue+fc > 255 ? 255 : fill.blue+fc);
			innerFill.set(
				fill.red+fillChange > 255 ? 255 : fill.red+fillChange,
				fill.green+fillChange > 255 ? 255 : fill.green+fillChange,
				fill.blue+fillChange > 255 ? 255 : fill.blue+fillChange);
		}
		fill = innerFill;
	}
	if ((style & BDR_OUTLINE) == 0 || outlineColor == null) outlineColor = roundOutline;
	Object [] got = getRoundRectPoints(style,r.x,r.y,r.width,r.height,3,labelWidth);
	boolean willDoInner = !flat && !down;
	if ((style & BF_RECT) == BF_RECT) {
		changePen(outlineColor,Pen.SOLID,1);
		if (fill != null){
			changeBrush(willDoInner ? innerLine : fill,Brush.SOLID);
			doPolygon(got,true);
			doPolygon(got,false);
		}else{
			if (labelWidth == 0) doPolygon(got,false);
			else doLines(got);
		}				
		if (!flat && !down){
			got = getRoundRectPoints(style,r.x+1,r.y+1,r.width-2,r.height-2,3,labelWidth);
			changePen(innerLine,Pen.SOLID,1);
			if (fill != null){
				changeBrush(fill,Brush.SOLID);
				doPolygon(got,true);
			}else{
				if (labelWidth == 0) doPolygon(got,false);
				else doLines(got);
			}				
		}
	}else{
		setPen(null);
		changeBrush(fill,Brush.SOLID);
		doPolygon(got,fill != null);
		changePen(outlineColor,Pen.SOLID,1);
		doLines(got);
		if (!flat){
			got = getRoundRectPoints(style,r.x+1,r.y+1,r.width-2,r.height-2,3,labelWidth);
			changePen(innerLine,Pen.SOLID,1);
			doLines(got);
		}
	}
}
//===================================================================
public void draw3DRect(Rect r,int style,boolean flat,Color fill,Color outlineColor)
//===================================================================
{
	notNativedraw3DRect(r,style,flat,fill,outlineColor,0);
}
//===================================================================
public void draw3DRect(Rect r,int style,boolean flat,Color fill,Color outlineColor,int labelWidth)
//===================================================================
{
	notNativedraw3DRect(r,style,flat,fill,outlineColor,labelWidth);
}


static Object [] curves3 = new Object[]
{
	new int[]{3,3,1,0},
	new int[]{0,-1,-3,-3}
};
static Object [] curves3Ret = new Object[2];
static Object [] curves;
static int lastCurves = -1;

//-------------------------------------------------------------------
Object [] getRoundRectPoints(int style,int x, int y, int width, int height, int radius,int labelWidth)
//-------------------------------------------------------------------
{
	synchronized(curves3){
		int r = radius;
		boolean all = (style & BF_RECT) == BF_RECT;
		boolean hasHLine = width > radius*2;
		boolean hasVLine = height > radius*2;
		//eve.sys.Vm.debug("Radius: "+radius);
		Object [] curve;
		if (radius == 3){
			curve = curves3Ret;
			curve[0] = curves3[0];
			curve[1] = curves3[1];
	 	}else if (radius == lastCurves) curve = (Object[])curves.clone();
		else {
			curve = getArcPoints(0,0,radius,radius,0,90,0);
			Object obj = curve.clone();
			curves = (Object[])obj;
			int [] cx = (int []) curve[0], cy = (int [])curve[1];
		}
		lastCurves = radius;
		int [] cx = (int []) curve[0], cy = (int [])curve[1];
		int cl = cx.length;
		int total = cl*4;
		int xp[] = new int[total+(labelWidth != 0 ? 1 : 0)], yp[] = new int[total+(labelWidth != 0 ? 1 : 0)];
		curve[0] = xp; curve[1] = yp;
		int dx, dy, j = 0;
		dx = r+x; dy = r+y;
		for (int i = 0; i<cl; i++){
			xp[j] = dx-cx[cl-1-i];
			yp[j++] = cy[cl-1-i]+dy;
		}
		dx = r+x; dy = height-1-r+y;
		for (int i = 0; i<cl; i++){
			xp[j] = dx-cx[i];
			yp[j++] = dy-cy[i];
		}
		dx = width-1-r+x; dy = height-1-r+y;
		for (int i = 0; i<cl; i++){
			xp[j] = cx[cl-1-i]+dx;
			yp[j++] = dy-cy[cl-1-i];
		}
		dx = width-1-r+x; dy = r+y;
		for (int i = 0; i<cl; i++){
			xp[j] = cx[i]+dx;
			yp[j++] = cy[i]+dy;
		}
		if (labelWidth != 0){
			xp[j] = x+4+labelWidth;
			yp[j++] = y;
		}
		if (all) return curve;
		int x2[] = new int[cl*2+2], y2[] = new int[cl*2+2];
		int end = cl*2+2-1;
		int s = 0;
		j = 0;
		if ((style & BF_TOP) == 0){ // Top one is missing, must start from top left.
			x2[j] = x; y2[j++] = y; s = cl*1;
			x2[end] = x+width-1; y2[end] = y;
		}else if ((style & BF_LEFT) == 0) { // Left one is missing, must start from bottom left.
			x2[j] = x; y2[j++] = y+height-1; s = cl*2;
			x2[end] = x; y2[end] = y;
		}else if ((style & BF_BOTTOM) == 0) { // Bottom one is missing, must start from bottom right.
			x2[j] = x+width-1; y2[j++] = y+height; s = cl*3;
			x2[end] = x; y2[end] = y+height;
		}else if ((style & BF_RIGHT) == 0) { // Right one is missing, must start from top right.
			x2[j] = x+width-1; y2[j++] = y; s = 0;
			x2[end] = x+width-1; y2[end] = y+height;
		}
		for (int i = 0; i<cl; i++){
			x2[j] = xp[i+s];
			y2[j++] = yp[i+s];
		}
	 	s = (s+cl)%(cl*4);
		for (int i = 0; i<cl; i++){
			x2[j] = xp[i+s];
			y2[j++] = yp[i+s];
		}
		curve[0] = x2; curve[1] = y2;
		return curve;
	}
}
//-------------------------------------------------------------------
private void notNativedraw3DRect(Rect r,int style,boolean flat,Color fill,Color outlineColor,int labelWidth)
//-------------------------------------------------------------------
{

	if ((style & (BF_SOFT|BDR_DOTTED|BDR_NOBORDER|BF_SQUARE)) == BF_SOFT) {
		draw3DRoundRect(r,style,flat,fill,outlineColor,labelWidth);
		return;
	}
	
	Pen oldPen = setPen(null);
	try{
	Graphics g = this;
	if (fill != null){
		setColor(fill);
		fillRect(r.x,r.y,r.width,r.height);
	}
	int edge = style & 0xffff;
	int flags = style & 0xffff0000;
	if ((edge & BDR_DOTTED) != 0) {
		edge = BDR_DOTTED|BDR_OUTLINE;
		flags = BF_RECT;
	}
	if ((edge & BDR_NOBORDER) == 0) {
		if (flat && ((edge & BDR_DOTTED) == 0)) edge = BDR_OUTLINE;
		if ((edge & 0xf) != 0) drawEdge(r,edge,flags,labelWidth);
		if ((edge & BDR_OUTLINE) != 0) {
			if ((outlineColor != null) || ((edge & BDR_DOTTED) != 0)){
				if (outlineColor == null) outlineColor = Color.Black;
			}
			g.setColor(outlineColor);
			if ((edge & BDR_DOTTED) == 0){
			if ((flags & BF_TOP) != 0)
				if (labelWidth == 0) drawLine(r.x,r.y,r.x+r.width-1,r.y);
				else {
					drawLine(r.x,r.y,r.x+4,r.y);
					drawLine(r.x+4+labelWidth,r.y,r.x+r.width-1,r.y);
				}
				//if ((flags & BF_TOP) != 0) drawLine(r.x,r.y,r.x+r.width-1,r.y);
				if ((flags & BF_RIGHT) != 0) drawLine(r.x+r.width-1,r.y,r.x+r.width-1,r.y+r.height-1);
				if ((flags & BF_BOTTOM) != 0) drawLine(r.x+r.width-1,r.y+r.height-1,r.x,r.y+r.height-1);
				if ((flags & BF_LEFT) != 0) drawLine(r.x,r.y+r.height-1,r.x,r.y);
			}else{
				if ((flags & BF_TOP) != 0) drawDots(r.x,r.y,r.x+r.width-1,r.y);
				if ((flags & BF_RIGHT) != 0) drawDots(r.x+r.width-1,r.y,r.x+r.width-1,r.y+r.height-1);
				if ((flags & BF_BOTTOM) != 0) drawDots(r.x+r.width-1,r.y+r.height-1,r.x,r.y+r.height-1);
				if ((flags & BF_LEFT) != 0) drawDots(r.x,r.y+r.height-1,r.x,r.y);
			}
		}
	}
	}finally{
		setPen(oldPen);
	}
}
////////////////////////////////////////////////////////////////////////////
// draw an elliptical arc from startAngle to endAngle. c is the fill color and c2 is the outline color (if in fill mode - otherwise, c = outline color)
	
static int [] xPoints = new int[0], yPoints = new int[0];
static int nPoints = 0;
static int startIndex,endIndex;
static int lastRX=-1,lastRY=-1,lastXC = -1, lastYC = -1,lastSize=0;
static float lastPPD=0;

//-------------------------------------------------------------------
static void arcPiePointDrawAndFill(int xc, int yc, int rx, int ry, float startAngle, float endAngle, boolean append)
//-------------------------------------------------------------------
{
   // this algorithm was created by Guilherme Campos Hazan
   float ppd;
   int index,i;
   int nq,size=0;

   //System.out.println(startAngle+"-"+endAngle);
   //int oldX,oldY;
   // step 0: correct angle values
   /*
   if (startAngle < 0.1 && endAngle > 359.9) // full circle? use the fastest routine instead
   {
      if (fill)
         fillEllipse(xc,yc,rx,ry,c);
      drawEllipse(xc,yc,rx,ry,fill?c2:c);
      return;
   }
   */
   // step 0: if possible, use cached results
   if (xc != lastXC || yc != lastYC || rx != lastRX || ry != lastRY)
   {
       // step 1: computes how many points the circle has (computes only 45 degrees and mirrors the rest)
       // intermediate terms to speed up loop
        long t1 = rx*rx, t2 = t1<<1, t3 = t2<<1;
        long t4 = ry*ry, t5 = t4<<1, t6 = t5<<1;
        long t7 = rx*t5, t8 = t7<<1, t9 = 0L;
        long d1 = t2 - t7 + (t4>>1);    // error terms
        long d2 = (t1>>1) - t8 + t5;

        int x = rx, y = 0; // ellipse points

        while (d2 < 0)          // til slope = -1
        {
            y++;        // always move up here
            t9 += t3;
            if (d1 < 0) // move straight up
            {
                d1 += t9 + t2;
                d2 += t9;
            }
            else        // move up and left
            {
                x--;
                t8 -= t6;
                d1 += t9 + t2 - t8;
                d2 += t9 + t5 - t8;
            }
            size++;
        }

        do              // rest of top right quadrant
        {
            x--;        // always move left here
            t8 -= t6;
            if (d2 < 0) // move up and left
            {
                y++;
                t9 += t3;
                d2 += t9 + t5 - t8;
            }
            else        // move straight left
                d2 += t5 - t8;
          size++;

        } while (x >= 0);
       nq = size;
       size *= 4;
       // step 2: computes how many points per degree
       ppd = (float)size / 360.0f;
       // step 3: create space in the buffer so it can save all the circle
       size+=2;
       if (nPoints < size)
       {
				/*
          if (xPoints)
          {
             xfree(xPoints);
             xfree(yPoints);
          }
				*/
          xPoints = new int[size];//xmalloc(sizeof(int32)*size);
          yPoints = new int[size];//xmalloc(sizeof(int32)*size);
       }
       nPoints = size;
       // step 4: stores all the circle in the array. the odd arcs are drawn in reverse order
        // intermediate terms to speed up loop
        t2 = t1<<1; t3 = t2<<1;
        t8 = t7<<1; t9 = 0L;
        d1 = t2 - t7 + (t4>>1); // error terms
        d2 = (t1>>1) - t8 + t5;

        x = rx;
        y = 0;  // ellipse points

        i=0;
        while (d2 < 0)          // til slope = -1
        {
            // save 4 points using symmetry
            index = nq*0+i;   xPoints[index]=xc+x; yPoints[index]=yc-y; // 0/3
            index = nq*2-i-1; xPoints[index]=xc-x; yPoints[index]=yc-y; // 1/3
            index = nq*2+i;   xPoints[index]=xc-x; yPoints[index]=yc+y; // 2/3
            index = nq*4-i-1; xPoints[index]=xc+x; yPoints[index]=yc+y; // 3/3
            i++;

            y++;        // always move up here
            t9 += t3;
            if (d1 < 0) // move straight up
            {
                d1 += t9 + t2;
                d2 += t9;
            }
            else        // move up and left
            {
                x--;
                t8 -= t6;
                d1 += t9 + t2 - t8;
                d2 += t9 + t5 - t8;
            }
        }

        do              // rest of top right quadrant
        {
            // save 4 points using symmetry
            index = nq*0+i;   xPoints[index]=xc+x; yPoints[index]=yc-y; // 0/3
            index = nq*2-i-1; xPoints[index]=xc-x; yPoints[index]=yc-y; // 1/3
            index = nq*2+i;   xPoints[index]=xc-x; yPoints[index]=yc+y; // 2/3
            index = nq*4-i-1; xPoints[index]=xc+x; yPoints[index]=yc+y; // 3/3
            i++;

            x--;        // always move left here
            t8 -= t6;
            if (d2 < 0) // move up and left
            {
                y++;
                t9 += t3;
                d2 += t9 + t5 - t8;
            }
            else        // move straight left
                d2 += t5 - t8;
        } while (x >= 0);
       // save last arguments
       lastXC = xc;
       lastYC = yc;
       lastRX = rx;
       lastRY = ry;
       lastPPD = ppd;
       lastSize = size;
   }
   else ppd = lastPPD;
   // step 5: computes the start and end indexes that will become part of the arc
   if (!append) startIndex = (int)(ppd * startAngle);
    endIndex = (int)(ppd * endAngle);
   // step 5 1/2: if only computing the point, return it
   /*
   if (startAnglePoint)
   {
      startAnglePoint[0] = xPoints[startIndex];
      startAnglePoint[1] = yPoints[startIndex];
      return;
   }*/
    // FIXME - for when end angle is 360 - what to correctly do?
   if (endIndex == (lastSize-2)) // 360?
   		endIndex--;
   else
   	 ;//endIndex++; 
   /*
   if (pie)
   {
      oldX = xPoints[endIndex];
      oldY = yPoints[endIndex];
      xPoints[endIndex] = xc;
      yPoints[endIndex] = yc;
      endIndex++;
   }
   if (fill)
      fillPolygon(xPoints+startIndex,yPoints+startIndex,endIndex-startIndex,c);
//   if (!fill || c != c2) always draw border
      drawPolygon(xPoints+startIndex,yPoints+startIndex,endIndex-startIndex,fill?c2:c,fill);
   if (pie) // restore saved points
   {
      xPoints[endIndex-1] = oldX;
      yPoints[endIndex-1] = oldY;
   }
	*/
}
////////////////////////////////////////////////////////////////////////////
// calls arcPiePointDrawAndFill twice if the angles cross the 0
static void preArcPiePointDrawAndFill(int xc, int yc, int rx, int ry, float startAngle, float endAngle)
{
   // make sure the values are -359 <= x <= 359
   while (startAngle <= -360) startAngle += 360;
   while (endAngle   <= -360) endAngle   += 360;
   while (startAngle >   360) startAngle -= 360;
   while (endAngle   >   360) endAngle   -= 360;

   if (startAngle > endAngle) // eg 235 to 45
      startAngle -= 360; // set to -45 to 45 so we can handle it correctly
   if (startAngle >= 0 && endAngle <= 0) // eg 135 to -135
      endAngle += 360; // set to 135 to 225

   if (startAngle >= 0 && endAngle >= 0)
      arcPiePointDrawAndFill(xc, yc, rx, ry, startAngle, endAngle,false);
   else
   if (startAngle <= 0 && endAngle >= 0) // eg -45 to 45
   {
      startAngle += 360;
      arcPiePointDrawAndFill(xc, yc, rx, ry, startAngle, 360, false);
      arcPiePointDrawAndFill(xc, yc, rx, ry, 0, endAngle,  true);
   } //else debug("arc/pie/point could not be filled with given angles");
}
//-------------------------------------------------------------------
protected static Object [] getArcPoints(int xc,int yc,int rx,int ry,float startAngle,float endAngle,int flags)
//-------------------------------------------------------------------
{
	int extra = 0;
	preArcPiePointDrawAndFill(xc,yc,rx,ry,startAngle,endAngle);
	int len = endIndex-startIndex+1;
	if ((flags & 0x1) != 0) extra = 1;
	int [] x, y;
	if (len >= 0){
		x = new int[len+extra];
		y = new int[len+extra];
		System.arraycopy(xPoints,startIndex,x,extra,len);
		System.arraycopy(yPoints,startIndex,y,extra,len);
	}else{
		len = nPoints-startIndex-2;
		x = new int[len+extra+1+endIndex];
		y = new int[len+extra+1+endIndex];
		System.arraycopy(xPoints,startIndex,x,extra,len);
		System.arraycopy(yPoints,startIndex,y,extra,len);
		System.arraycopy(xPoints,0,x,extra+len,endIndex+1);
		System.arraycopy(yPoints,0,y,extra+len,endIndex+1);
		/*
		memcpy((int32 *)WOBJ_arrayStart(x)+extra,xPoints+startIndex,len*sizeof(int32));
		memcpy((int32 *)WOBJ_arrayStart(y)+extra,yPoints+startIndex,len*sizeof(int32));
		memcpy((int32 *)WOBJ_arrayStart(x)+len+extra,xPoints,(endIndex+1)*sizeof(int32));
		memcpy((int32 *)WOBJ_arrayStart(y)+len+extra,yPoints,(endIndex+1)*sizeof(int32));
		*/
	}
	Object [] ret = new Object[2];
	ret[0] = x;
	ret[1] = y;
	return ret;
}	
//===================================================================
public void drawLines(int x[], int y[], int count)
//===================================================================
{
	for (int i = 0; i < count - 1; i++)
		drawLine(x[i], y[i], x[i + 1], y[i + 1]);
}


//===================================================================
public void drawArc(int x,int y,int width,int height,float startAngle,float angle)
//===================================================================
{
	Object [] both = getArcPoints(x+width/2-1,y+height/2-1,width/2,height/2,startAngle,startAngle+angle,0);
	int [] xp = (int [])both[0];
	int [] yp = (int [])both[1];
	drawLines(xp,yp,xp.length);
}
//===================================================================
public void paintClosedArc(int x,int y,int width,int height,float startAngle,float angle,boolean useBrush,boolean usePen)
//===================================================================
{
	if (true){
		Curve.curve.paintClosedArc(this, x, y, width, height, startAngle, angle, useBrush, usePen);
	}else{
		Object [] both = getArcPoints(x+width/2-1,y+height/2-1,width/2,height/2,startAngle,startAngle+angle,0);
		int [] xp = (int [])both[0];
		int [] yp = (int [])both[1];
		paintPolygon(xp,yp,0,0,xp.length,useBrush,usePen);
	}
}
//===================================================================
public void paintPie(int x,int y,int width,int height,float startAngle,float angle,boolean useBrush,boolean usePen)
//===================================================================
{
	if (true){
		Curve.curve.paintPie(this, x, y, width, height, startAngle, angle, useBrush, usePen);
	}else{
		Object [] both = getArcPoints(x+width/2-1,y+height/2-1,width/2,height/2,startAngle,startAngle+angle,1);
		int [] xp = (int [])both[0];
		int [] yp = (int [])both[1];
		xp[0] = x+width/2-1; yp[0] = y+height/2-1;
		paintPolygon(xp,yp,0,0,xp.length,useBrush,usePen);
	}
}
public synchronized FontMetrics getFontMetrics(Font f)
{
	return surface.getFontMetrics(f);
}
//===================================================================
public static String getDisplayable(String s)
//===================================================================
{
	int len;
	if (s != null)
		if ((len = s.length()) >= 2)
			if (s.charAt(len-1) == '\0')
				return s.substring(0,len-2);
	return s;
}

//===================================================================
public static int getUnderlined(String s)
//===================================================================
{
	int len;
	if (s == null) return -1;
	if ((len = s.length()) < 3) return -1;
  if (s.charAt(len-1) != '\0') return -1;
	char ch = s.charAt(len-2);
	int where = s.indexOf(ch);
	if (where == len-2) where = -1;
	char lc = eve.sys.Vm.getLocale().changeCase(ch,false);
	if (lc == ch) lc = eve.sys.Vm.getLocale().changeCase(ch,true);
	if (lc == ch) return -1;
	int where2 = s.indexOf(lc);
	if (where == -1) return where2;
	if (where2 == -1) return where;
	if (where < where2) return where;
	return where2;
}
/**
* Call this after you have called drawText().
**/
//===================================================================
public void underline(Object fontOrFontMetrics,char [] text,int start,int length,int underlineStartIndex,int x,int y)
//===================================================================
{
	FontMetrics fm = (fontOrFontMetrics instanceof FontMetrics) ? (FontMetrics)fontOrFontMetrics : getFontMetrics((Font)fontOrFontMetrics);
	int oldWidth = 0, oldStyle = 0;
	Color oldColor = null;
	if (pen != null) {
		oldWidth = pen.thickness;
		pen.thickness = 1;
		oldStyle = pen.style;
		pen.style = pen.SOLID;
		oldColor = pen.color;
		pen.color.set(color);
		nativeSetPen(pen);
	}
	int before = fm.getTextWidth(text,start,underlineStartIndex-start);
	int after = fm.getCharWidth(text[underlineStartIndex]);
	int height = fm.getHeight()-1;
	drawLine(x+before-1,y+height,x+before+after-1,y+height);
	if (pen != null){
		pen.thickness = oldWidth;
		pen.style = oldStyle;
		pen.color.set(oldColor);
		nativeSetPen(pen);
	}
}
//===================================================================
public void drawText(FontMetrics fm,String [] lines,Rect where,int alignment)
//===================================================================
{
	drawText(fm,lines,where,alignment,CENTER);
}

private static String [] strings = new String[1];
//===================================================================
public static Rect getSize(FontMetrics fm,String st,int xGap,int yGap)
//===================================================================
{
	Rect r = new Rect(0,0,0,0);
	r.width = fm.getTextWidth(st)+xGap*2;
	r.height = fm.getHeight()+yGap*2;
	return r;
}
//===================================================================
public static Rect getSize(FontMetrics fm,String [] lines,int xGap,int yGap)
//===================================================================
{
	int w = 0, h = 0;
	int fh = fm.getHeight(), leading = fm.getLeading();
	for (int i = 0; i<lines.length; i++){
		int wd = fm.getTextWidth(lines[i]);
		if (wd > w) w = wd;
		if (i != 0) h += leading;
		h += fh;
	}
	h += yGap*2;
	w += xGap*2;
	return new Rect(0,0,w,h);
}
//===================================================================
public static Rect getAverageSize(FontMetrics fm,int rows,int columns,int xGap,int yGap)
//===================================================================
{
	Rect r = new Rect(0,0,0,0);
	r.width = fm.getCharWidth('0')*columns+xGap*2;
	r.height = fm.getHeight()*rows;
	if (rows != 1) r.height += fm.getLeading()*(rows-1);
	r.height += yGap*2;
	return r;
}
//===================================================================
public static Point centerText(FontMetrics fm,String st,int width,int height)
//===================================================================
{
	Rect r = getSize(fm,st,0,0);
	return new Point((width-r.width)/2,(height-r.height)/2);
}

//===================================================================
public static void getSize(FontMetrics fm,String line,Dimension d)
//===================================================================
{
	getSize(fm,line,d,null);	
}
//===================================================================
public static void getSize(FontMetrics fm,String line,Dimension d,FormattedTextSpecs fts)
//===================================================================
{
	strings[0] = line;
	getSize(fm,strings,0,1,d,fts);
}
//===================================================================
public static void getSize(FontMetrics fm,String [] lines,int start,int end,Dimension d)
//===================================================================
{
	getSize(fm,lines,start,end,d,null);
}
//===================================================================
public static void getSize(FontMetrics fm,String [] lines,int start,int end,Dimension d,FormattedTextSpecs fts)
//===================================================================
{
	int w = 0, h = 0;
	int fh = fm.getHeight(), leading = fm.getLeading();
	if (start < 0) start = 0;
	if (end > lines.length) end = lines.length;
	for (int i = start; i<end; i++){
		int wd = FormattedTextSpecs.getWidthAndPositions(lines[i],fts,fm,false);
		if (wd > w) w = wd;
		if (i != 0) h += leading;
		h += fh;
	}
	d.width = w;
	d.height = h;
}

/**
* Modify subArea so that it is anchored appropriately in largeArea.
* anchor should be NORTH, SOUTH, etc.
**/
//===================================================================
public static void anchor(Rect subArea,Rect largeArea,int anchor)
//===================================================================
{
	subArea.x = ((largeArea.width-subArea.width)/2);
	subArea.y = ((largeArea.height-subArea.height)/2);
	if ((anchor & WEST) != 0) subArea.x = 0;
	else if ((anchor & EAST) != 0) subArea.x = largeArea.width-subArea.width;
	if ((anchor & NORTH) != 0) subArea.y = 0;
	else if ((anchor & SOUTH) != 0) subArea.y = largeArea.height-subArea.height;
	subArea.x += largeArea.x;
	subArea.y += largeArea.y;
}

private static Rect anchored = new Rect();
//===================================================================
public void drawImage(IImage image,int imageDrawOptions,Rect dest,int anchor)
//===================================================================
{
	if (image == null) return;
	anchor(anchored.set(0,0,image.getWidth(),image.getHeight()),dest,anchor);
	image.draw(this,anchored.x,anchored.y,imageDrawOptions);
}
//===================================================================
public void drawText(FontMetrics fm,String [] lines,Rect where,int alignment,int anchor)
//===================================================================
{
	if (lines == null) lines = new String[0];
	drawText(fm,lines,where,alignment,anchor,0,lines.length);
}
//===================================================================
public void drawText(FontMetrics fm,String [] lines,Rect where,int alignment,int anchor,
int startLine,int endLine)
//===================================================================
{
	drawText(fm,lines,where,alignment,anchor,startLine,endLine,null);
}

private static Rect buff;
private static Dimension dbuff;
//===================================================================
public void drawText(FontMetrics fm,String [] lines,Rect where,int alignment,int anchor,
int startLine,int endLine,FormattedTextSpecs fts)
//===================================================================
{
	synchronized(glock){
		if (dbuff == null) dbuff = new Dimension();
		getSize(fm,lines,startLine,endLine,dbuff,fts);
		if (buff == null) buff = new Rect();
		Rect tr = buff; tr.width = dbuff.width; tr.height = dbuff.height; tr.x = tr.y = 0;
		anchor(tr,where,anchor);
		//drawText(lines[startLine],tr.x,tr.y);
		//if (true) return;
		drawTextIn(fm,lines,tr,alignment,startLine,endLine,fts);
	}
}
private static FormattedTextSpecs ftsBuff;
//-------------------------------------------------------------------
protected void drawTextIn(FontMetrics fm,String [] lines,Rect where,int alignment,int start,int end,FormattedTextSpecs fts)
//-------------------------------------------------------------------
{
	synchronized(glock){
		if (ftsBuff == null) ftsBuff = new FormattedTextSpecs();
		if (fts == null) fts = ftsBuff;
		fts.metrics = fm;
		if (start >= lines.length || end <= start) return;
		if (end > lines.length) end = lines.length;
		int num = end-start;
		int h = fm.getHeight(), leading = fm.getLeading();
		int y = where.y;
		setFont(fm.getFont());
		//if (lines.length == 9) System.out.println("\n");
		//for (int i = 0; i<start; i++) y += h+leading;
		for (int i = 0; i<num; i++){
			String l = lines[i+start];
			if (i != 0) y += leading;
			int w = FormattedTextSpecs.getWidthAndPositions(l,fts,fm,false);
			int xp = where.x;
			if (alignment == Right) {
				//l = where.toString();
				xp += where.width-w;
				//eve.ui.Control.np.x = 0;
			}
			else if (alignment == CENTER) xp += (where.width-w)/2;
			if (fts.isFormatted) drawFormattedText(l,xp+tx,y+ty,fts);
			else drawText(l,xp,y);
			//if (lines.length == 9) System.out.println(l+" @ "+xp+","+y);
			y += h;
		}
	}
}
//===================================================================
public void drawVerticalTriangle(Rect bounds,boolean up)
//===================================================================
{
	Rect r = bounds;
	int w = bounds.width;
	if ((w & 1) == 0) w--;
	if (w < 0) return;
	int n = w/2;
	int h = w+1; //(n+1)*2
	int f = up ? -1 : 1;
	int px = 0;
	int st = 2;
	if (h > r.height){
		px = 1; h = w; // (n*2)+1
		if (h > r.height){
			h = w-1; // (n*2)
			if (h > r.height){
				px = 0; h = n+1; st = 1;
			}
		}
	}
	
	setPen(null);
	setBrush(null);
	
	int sx = r.x, ex = r.x+w-1;
	int yy = up ? r.y+h-1 : r.y+r.height-h;
	int min = r.y, max = r.y+r.height-1;
	for (int y = 0; y<h; y++){
		if (yy >= min && yy <= max)
			drawLine(sx,yy,ex,yy);
		if ((px+1)%st == 0) {
			sx++;
			ex--;
		}
		px++;
		yy += f;
	}
}
//===================================================================
public void drawHorizontalTriangle(Rect bounds,boolean left)
//===================================================================
{
	Rect r = bounds;
	int w = bounds.height;
	if ((w & 1) == 0) w--;
	if (w < 0) return;
	int n = w/2;
	int h = w+1; //(n+1)*2
	int f = left ? -1 : 1;
	int px = 0;
	int st = 2;
	if (h > r.width){
		px = 1; h = w; // (n*2)+1
		if (h > r.width){
			h = w-1; // (n*2)
			if (h > r.width){
				px = 0; h = n+1; st = 1;
			}
		}
	}
	
	setPen(null);
	setBrush(null);
	
	int sx = r.y, ex = r.y+w-1;
	int yy = left ? r.x+h-1 : r.x+r.width-h;
	int min = r.x, max = r.x+r.width-1;
	for (int y = 0; y<h; y++){
		if (yy >= min && yy <= max)
		drawLine(yy,sx,yy,ex);
		if ((px+1)%st == 0) {
			sx++;
			ex--;
		}
		px++;
		yy += f;
	}
}

//===================================================================
public void draw3DDiamond(Rect rect,boolean pressed,Color back) {draw3DDiamond(rect,pressed,back,false);}
//===================================================================
public void draw3DDiamond(Rect rect,boolean pressed,Color back,boolean amFlat)
//==================================================================
{
	Rect r = new Rect(); r.set(rect);
	if (pressed || amFlat){
		setColor(Color.Black);
		drawDiamond(r,Up);
		if (!amFlat)setColor(Color.DarkGray);
		drawDiamond(r,Down);
		r.x++; r.y++; r.width -= 2; r.height -=2;
		setColor(Color.White);
		drawDiamond(r,Down);
		if (!amFlat) setColor(Color.DarkGray);
		drawDiamond(r,Up);
		r.x++; r.y++; r.width -= 2; r.height -=2;
	}else {
		setColor(Color.Black);
		drawDiamond(r,Down);
		setColor(Color.DarkGray);
		drawDiamond(r,Up);
		r.x++; r.y++; r.width -= 2; r.height -=2;
		setColor(Color.DarkGray);
		drawDiamond(r,Down);
		setColor(Color.White);
		drawDiamond(r,Up);
		r.x++; r.y++; r.width -= 2; r.height -=2;
	}
	setColor(back);
	drawDiamond(r,All);
}

public static final int SPECIAL_TICK = 1;
public static final int SPECIAL_X = 2;

//===================================================================
public void drawSpecial(int what,Rect where,Pen p,Brush b)
//===================================================================
{
	Pen old = getPen();
	Brush oldb = getBrush();
	switch(what){
		case SPECIAL_TICK:
			setPen(p); //setBrush(b);
			drawLine(where.x+where.width-1,where.y,where.x,where.y+where.height-1);
			drawLine(where.x,where.y+where.height-1,where.x,where.y+(where.height*2)/3);
		case SPECIAL_X:
			setPen(p); //setBrush(b);
			drawLine(where.x+where.width-1,where.y,where.x,where.y+where.height-1);
			drawLine(where.x,where.y,where.x+where.width-1,where.y+where.height-1);
			break;
	}	
	setPen(old);
	setBrush(oldb);
}
//==================================================================
public void drawDiamond(Rect r,int which)
//==================================================================
{
	int x = r.x, y = r.y, w = r.width, h = r.height;
//..................................................................
	if (w % 2 == 1) w--;
	if (h % 2 == 1) h--;
	if (w > h) w = h;
	if (h > w) h = w;
	int half = h/2;
	int [] xx = new int[4], yy = new int[4];
	x += r.width/2-1; y += r.height/2-1;
	int num = 3;
	switch(which){
		case Up: 
			xx[0] = x-half+1; xx[1] = x+1; xx[2] = x+half+1;
			yy[0] = y; yy[1] = y-half; yy[2] = y;
			break;
		case Down: 
			xx[0] = x-half; xx[1] = x; xx[2] = x+half;
			yy[0] = y; yy[1] = y+half; yy[2] = y;
			break;
		case Left:
			yy[0] = y-half; yy[1] = y; yy[2] = y+half;
			xx[0] = x; xx[1] = x-half; xx[2] = x;
			break;
		case Right:
			yy[0] = y-half; yy[1] = y; yy[2] = y+half;
			xx[0] = x; xx[1] = x+half; xx[2] = x;
			break;
		case All:
			xx[0] = x-half; xx[1] = x; xx[2] = x+half; xx[3] = x; 
			yy[0] = y; yy[1] = y-half; yy[2] = y; yy[3] = y+half;
			num = 4;
			break;
	}
	fillPolygon(xx,yy,num);
//..................................................................
	//int p = w/2;
/*
		for (int i = 0; i<=p; i++){
			if (which == Left || which == All) drawLine(x+i,y+p-i,x+i,y+p+i);
			if (which == Right || which == All) drawLine(x+w-1-i,y+p-i,x+w-1-i,y+p+i);
		}
	if (which == Up || which == Down)
		for (int i = 0; i<=p; i++){
			if (which == Up) drawLine(x+p-i,y+i,x+p+i,y+i);
			if (which == Down) drawLine(x+p-i,y+w-1-i,x+p+i,y+w-1-i);
		}
	*/
}
//===================================================================
public void drawFormattedText(String s,int x,int y,FormattedTextSpecs fts)
//===================================================================
{
	drawFormattedText(eve.sys.Vm.getStringChars(s),0,s.length(),x,y,fts);
}
//===================================================================
public void drawFormattedText(String s,int start,int length,int x,int y,FormattedTextSpecs fts)
//===================================================================
{
	drawFormattedText(eve.sys.Vm.getStringChars(s),start,length,x,y,fts);
}
//===================================================================
public void drawFormattedText(char [] s,int start,int length,int x,int y,FormattedTextSpecs fts)
//===================================================================
{
	char [] all = s;
	int [] positions = null;
	if (fts != null)
		positions = fts.calculatedPositions;
	if (positions == null){
		return;
	}
	int max = start+length;
	if (max > all.length) max = all.length;
	int p = start <= 0 ? 0 : positions[start-1];
	for (int i = start; i<max; i++){
		char c = all[i];
		if (c != '\t') drawChar(c,x+p,y,0);
		p = positions[i];
	}
}

private static char [] charBuff = new char[1];

//===================================================================
public void drawChar(char which,int x,int y,int options)
//===================================================================
{
	synchronized(glock){
		charBuff[0] = which;
		drawText(charBuff,0,1,x,y);
	}
}
//===================================================================
public void reset()
//===================================================================
{
	clearClip();
	setDrawOp(DRAW_OVER);
	tx = ty = 0;
}
//===================================================================
public void copyRect(ISurface surface, int x, int y,
//===================================================================
	int width, int height, int dstX, int dstY)
{
	Graphics g = new Graphics(surface,true);
	copyRect(g,x,y,width,height,dstX,dstY);
	g.free();
}
/**
 * Draw a rectangle with rounded corners.
 * @param radius the radius of the arcs that are at the corners.
 * @return 
 */
//===================================================================
public void paintRoundRect(int x,int y,int width,int height,int radius,boolean useBrush, boolean usePen)
//===================================================================
{
	synchronized(glock){
		Object[] points = getRoundRectPoints(BF_RECT,x,y,width,height,radius,0);
		int [] xp = (int [])points[0], yp = (int [])points[1];
		paintPolygon(xp,yp,0,0,xp.length,useBrush,usePen);
	}
}
/**
Draw a rounded rectangle in the current Pen, but do not fill the inside.
@param x The x position of the rectangle.
@param y The y position of the rectangle.
@param width The width of the rectangle.
@param height The height of the rectangle.
 * @param radius the radius of the arcs that are at the corners.
*/
//===================================================================
public void drawRoundRect(int x, int y, int width, int height,int radius)
//===================================================================
{
	paintRoundRect(x,y,width,height,radius,false,true);
}
/**
Fill a rounded rectangle in the current Brush but do not draw around it using the pen.
@param x The x position of the rectangle.
@param y The y position of the rectangle.
@param width The width of the rectangle.
@param height The height of the rectangle.
 * @param radius the radius of the arcs that are at the corners.
*/
//===================================================================
public void fillRoundRect(int x, int y, int width, int height,int radius)
//===================================================================
{
	paintRoundRect(x,y,width,height,radius,true,false);
}
/*
private AffineTransform buffer = new AffineTransform();

private Object useTransform(double[] t)
{
	if (t == null) return null;
	AffineTransform at = ((Graphics2D)g).getTransform();
	AffineTransform old = (AffineTransform)at.clone();
	at.concatenate(new AffineTransform(t));
	((Graphics2D)g).setTransform(at);
	System.out.println("TX: "+at);
	return old;
}
private void restoreTransform(Object old)
{
	if (old != null) ((Graphics2D)g).setTransform((AffineTransform)old);
}
//-------------------------------------------------------------------
boolean nativeSetBrush(Paint2D b)
//-------------------------------------------------------------------
{
	if (b.brushColor == null || b.brushStyle == Brush.NULL)
		return false;
	Stroke st = ((Graphics2D)g).getStroke();
	Color c = b.brushColor;
	((Graphics2D)g).setPaint(new java.awt.Color(c.getRed(),c.getGreen(),c.getBlue()));
	((Graphics2D)g).setStroke(st);
	return true;
}
//-------------------------------------------------------------------
boolean nativeSetPen(Paint2D p)
//-------------------------------------------------------------------
{
	if (p.penColor == null || ((p.penStyle & Pen.STYLE_MASK) == Pen.NULL))
		return false;
	
	int j = BasicStroke.JOIN_MITER;
	int cp = BasicStroke.CAP_SQUARE;
	float ml = p.penMiterLimit;
	if ((p.penStyle & Pen.JOIN_MASK) == Pen.JOIN_BEVEL) j = BasicStroke.JOIN_BEVEL;
	if ((p.penStyle & Pen.JOIN_MASK) == Pen.JOIN_ROUND) j = BasicStroke.JOIN_ROUND;
	if ((p.penStyle & Pen.CAP_MASK) == Pen.CAP_BUTT) cp = BasicStroke.CAP_BUTT;
	if ((p.penStyle & Pen.CAP_MASK) == Pen.CAP_ROUND) cp = BasicStroke.CAP_ROUND;
	java.awt.Stroke s = null;
	float[] dashes = null;
	if (p != null) switch(p.penStyle & Pen.STYLE_MASK){
		case Pen.DASH:
			dashes = new float[]{4.0f,4.0f};
			break;
		case Pen.DOT:
			dashes = new float[]{2.0f,2.0f};
			break;
		case Pen.DASHDOT:
			dashes = new float[]{4.0f,2.0f,2.0f,2.0f};
			break;
		case Pen.DASHDOTDOT:
			dashes = new float[]{4.0f,2.0f,2.0f,2.0f,2.0f,2.0f};
			break;
			
		default:
			s = new java.awt.BasicStroke((float)p.getPenThickness(),cp,j,ml);
	}
	if (dashes != null)
		s = new java.awt.BasicStroke((float)p.getPenThickness(),cp,j,ml,dashes,0);
	if (s == null) s = new java.awt.BasicStroke(1);
	((Graphics2D)g).setStroke(s);
	g.setColor(new java.awt.Color(p.penColor.red,p.penColor.green,p.penColor.blue));
	return true;
}

public FontMetrics getFontMetrics(String name, int style, double size)
{
	Font f = new Font(name,style,(int)(size/Font.fontScale));
	return getFontMetrics(f);
}
*/
double nativeSetFont(Paint2D p)
{
	return 1;
	/*
	int style = 0;
	if (p.fontStyle == Font.PLAIN)
		style = java.awt.Font.PLAIN;
	if ((p.fontStyle & Font.BOLD) != 0) style |= java.awt.Font.BOLD;
	if ((p.fontStyle & Font.ITALIC) != 0) style |= java.awt.Font.ITALIC;
	//if ((this.style & UNDERLINE) != 0) style |= java.awt.Font.UNDERLINE;
	FontMetrics fm = getFontMetrics(name,style,size);
	setFont(fm.getFont());
	//java.awt.Font awtFont = new java.awt.Font(p.fontName,style,(int)p.fontSize);//this.size - 3);
	g.setFont(awtFont);
	java.awt.FontMetrics fm;
	fm = java.awt.Toolkit.getDefaultToolkit().getFontMetrics(awtFont);
	//((Graphics2D)g).setPaint(new java.awt.Color(c.getRed(),c.getGreen(),c.getBlue()));
	//((Graphics2D)g).setStroke(st);
	System.out.println(fm.getStringBounds())
	String str = "Hey There";
	return fm.getAscent();
	*/
	/*
	FontMetrics fm = getFontMetrics(p.fontName,p.fontStyle,p.fontSize);
	setFont(fm.getFont());
	g.setColor(new java.awt.Color(p.fontColor.red,p.fontColor.green,p.fontColor.blue));
	return fm.getAscent();
	*/
}
/*
public void paintPolygon(Paint2D pd, double[] x, double[] y, int xoffset, int yoffset,int count)
{
	Object obj = useTransform(pd.transform);
	try{
		GeneralPath gp = new GeneralPath();
		for (int i = 0; i<count; i++){
			if (i == 0) gp.moveTo((float)x[xoffset++],(float)y[yoffset++]);
			else gp.lineTo((float)x[xoffset++],(float)y[yoffset++]);
		}
		gp.closePath();
		if (nativeSetBrush(pd)){
			((Graphics2D)g).fill(gp);
		}
		if (nativeSetPen(pd)){
			((Graphics2D)g).draw(gp);
		}
	}finally{
		restoreTransform(obj);
	}
}
public void drawText(Paint2D pd,char[] data, int offset, int length, double x, double y)
{
	Object obj = useTransform(pd.transform);
	try{
		double ascent = nativeSetFont(pd);
		((Graphics2D)g).drawString(new String(data,offset,length),(float)x,(float)(y+ascent));
	}finally{
		restoreTransform(obj);
	}
}
*/
//##################################################################
}
//##################################################################

