/*
 * Created on Apr 11, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;
import java.io.IOException;

import eve.sys.SystemResourceException;
import eve.util.FormattedDataSource;

//
// FIXME - currently I enable ALPHA all the time.
//
/**
 * @author Michael L Brereton
 *
 */
//####################################################
/**
 * @author Michael L Brereton
 *
 */
public class Image extends ImageObject implements ISurface{
	//int width;
	//int height;
	//public Color background;
	//public Color transparent;
	//public boolean hasAlpha;
	//boolean wasLoaded;
	public static final int OPTION_FOR_DISPLAY = 0x100;
	public static final int OPTION_WITH_ALPHA_CHANNEL = 0x200;
	private static int numImages;
	private static int maxImages; 
	private boolean freed = false;
	public int getSurfaceType(){return IMAGE_SURFACE;}
	BufferedImageData bufferedImage;
	private FontMetricsCache fms;
	public synchronized FontMetrics getFontMetrics(Font f)
	{
		if (fms == null) fms = new FontMetricsCache();
		return fms.get(f,this);
	}
	public Graphics newGraphics()
	{
		return new Graphics(this);
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#free()
	 */
	public synchronized void free() {
		if (freed) return;
		freed = true;
		synchronized(Image.class){
			if (numImages > maxImages){
				maxImages = numImages;
				//System.out.println("Max: "+maxImages);
			}
			numImages--;
			//System.out.println(numImages);
		}
		if (bufferedImage != null) bufferedImage.free();
		bufferedImage = null;
	}
	protected void finalize()
	{
		//Vm.debug("Unfreed Image!");
		free();
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#getPixels(int[], int, int, int, int, int, int)
	 */
	public int[] getPixels(int[] dest, int offset, int x, int y, int width,
			int height, int rowStride) {
		if (rowStride <= 0) rowStride = width;
		if (x < 0 || x+width > this.width || y < 0 || y+height > this.height){
			Rect r = new Rect(x,y,width,height);
			offset = ImageTool.clipPixelArea(this,r,offset,rowStride);
			if (offset < 0) return null;
			x = r.x; y = r.y; width = r.width; height = r.height;
		}
		return bufferedImage.getPixels(dest,offset,x,y,width,height,rowStride);
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#usesAlpha()
	 */
	public boolean usesAlpha() {
		//return hasAlpha;
		return bufferedImage.usesAlpha();
	}


	/* (non-Javadoc)
	 * @see eve.fx.ImageData#isWriteableImage()
	 */
	public boolean isWriteableImage() {
		return true;
	}

	//public void freeze(){wasLoaded = true;}
	//public void makeGray(){}
	//public void enableAlpha(){}
	
	/**
	 * Assign a Mask to the Image specifying fully opaque and fully transparent areas. 
	 * This operation will modify this image if possible
	 * but if not it will create and return a new image that is masked.
	 * The returned image will be considered
	 * to have an alpha channel and the image will not be modifyable. 
	 * @param m a Mask to use. All bits in the Mask with a '1' will be considered to be fully opaque,
	 * all bits with a '0' will be considered to be transparent.
	 * @return either this Image or a new Image that is masked.
	 */
	public Image setMask(Mask m) throws IllegalArgumentException
	{
		if (m.width != width || m.height != height)
			throw new IllegalArgumentException("Mask size does not match image size.");
		bufferedImage = toAlphaBufferedImage(bufferedImage,true);
		byte[] bits = m.getBitmap();
		int[] line = new int[width];
		for (int y = 0; y<height; y++){
			getPixels(line,0,0,y,width,1,width);
			int xx = y*((width+7)/8); byte mm = (byte)0x80;
			for (int x = 0; x<width; x++){
				if ((bits[xx] & mm) == 0)
					line[x] &= 0x00ffffff;
				else
					line[x] |= 0xff000000;
				mm = (byte)((mm >> 1) & 0x7f);
				if (mm == 0) {
					mm = (byte)0x80;
					xx++;
				}
			}
			setPixels(line,0,0,y,width,1,width);
		}
		//freeze();
		return (Image)this;
	}
	/**
	 * Returns if the Image was decoded.
	 */
	/*
	public boolean wasDecoded()
	{
		return wasLoaded;
	}
	*/
	/**
	 * Set a block of pixels within the Image with specified RGB/ARGB 
	 * pixel data provided as int values (one int value per pixel)
	 * @param sourcePixels the array containing the pixel values.
	 * @param offset the start of the pixel data in the source array.
	 * @param x the x position of the block in the image.
	 * @param y the y position of the block in the image.
	 * @param width the width of the block in the image.
	 * @param height the height of the block in the image.
	 * @param rowStride the number of int values between scan lines
	 * in the sourcePixels array. If this is zero it is assumed to
	 * be the same as the width parameter.
	 * @throws IllegalStateException if data cannot be written to
	 * the image.
	 */
	public boolean setPixels(int[] sourcePixels,int offset,int x,int y,int width,int height,int rowStride)
	throws IllegalStateException
	{
		if (rowStride <= 0) rowStride = width;
		if (x < 0 || x+width > this.width || y < 0 || y+height > this.height){
			Rect r = new Rect(x,y,width,height);
			offset = ImageTool.clipPixelArea(this,r,offset,rowStride);
			if (offset < 0) return true;
			x = r.x; y = r.y; width = r.width; height = r.height;
		}
		return bufferedImage.setPixels(sourcePixels,offset,x,y,width,height,rowStride);
	}
	/* (non-Javadoc)
	 * @see eve.fx.IImage#draw(eve.fx.Graphics, int, int, int)
	 */
	public void draw(Graphics g, int x, int y, int options) {
		g.drawImage(this,x,y);
	}

	public Image(int width, int height, int typeAndOptions)
	throws SystemResourceException
	{
		this(width,height,typeAndOptions, null,0,0,null);
	}
	public Image(int width, int height, int typeAndOptions, Object data, int offset, int length, int[] colorTable)
	throws SystemResourceException
	{
		synchronized(Image.class){numImages++;}
		//System.out.println(width+"x"+height);
		//if (width == 2) new Exception().printStackTrace();
		if (data != null) throw new RuntimeException("Not implemented yet.");
		bufferedImage = new BufferedImageData(createBI(width,height,((typeAndOptions & OPTION_WITH_ALPHA_CHANNEL) != 0) || ((typeAndOptions & TYPE_MASK) == TYPE_ARGB)));
		/*
		bufferedImage = new java.awt.image.BufferedImage(width,height,
				(typeAndOptions & OPTION_WITH_ALPHA_CHANNEL) != 0 ? java.awt.image.BufferedImage.TYPE_INT_ARGB : java.awt.image.BufferedImage.TYPE_INT_RGB);
				*/
		this.width = width;
		this.height = height;
	}
	public Image(int width,int height)
	{
		this(width,height,0);
	}
	public Image(Image other, int options)
	{
		synchronized(Image.class){numImages++;}
		fromBufferedImage(other.bufferedImage,options,true);
		background = other.background;
	}
	public Picture toPicture(Object maskObject) throws IllegalArgumentException
	{
		return new Picture(this,maskObject,0);
	}
	public Picture toPicture()
	{
		return new Picture(this,0);
	}
	
	static java.awt.image.BufferedImage createBI(int width,int height,boolean alpha)
	{
		return new java.awt.image.BufferedImage(width,height,
				alpha
				? java.awt.image.BufferedImage.TYPE_INT_ARGB : java.awt.image.BufferedImage.TYPE_INT_RGB);
	}
	static BufferedImageData toAlphaBufferedImage(BufferedImageData bi, boolean freeOriginal)
	{
		if (bi.usesAlpha()) return bi;
		java.awt.image.BufferedImage other = createBI(bi.getWidth(),bi.getHeight(),true);
		java.awt.Graphics g = other.getGraphics();
		g.drawImage(bi.bi,0,0,null);
		g.dispose();
		if (freeOriginal) bi.free();
		return new BufferedImageData(other);
	}
	static BufferedImageData toBufferedImage(java.awt.Image im)
	{
		java.awt.image.BufferedImage bi = createBI(im.getWidth(null),im.getHeight(null),true);
		java.awt.Graphics g = bi.getGraphics();
		g.drawImage(im,0,0,null);
		g.dispose();
		return new BufferedImageData(bi);
	}
	static BufferedImageData fromBufferedImage(BufferedImageData ji,boolean doCopy)
	{
		BufferedImageData bImage;
		if (doCopy){
			int w = ji.getWidth(), h = ji.getHeight();
			bImage = new BufferedImageData(createBI(w,h,true));
			int[] line = new int[w];
			for (int i = 0; i<h; i++){
				ji.bi.getRGB(0,i,w,1,line,0,w);
				bImage.bi.setRGB(0,i,w,1,line,0,w);
			}
		}else
			bImage = ji;
		return bImage;
	}
	void fromBufferedImage(BufferedImageData ji,int options,boolean doCopy)
	{
		bufferedImage = fromBufferedImage(ji,doCopy);
		this.width = bufferedImage.getWidth();
		this.height = bufferedImage.getHeight();
	}
	
	public Image(int options,Object nativeObject)
	{
		synchronized(Image.class){numImages++;}
		if (!(nativeObject instanceof java.awt.Image))
			throw new IllegalArgumentException("The nativeObject must be a java.awt.Image object.");
		if (nativeObject instanceof java.awt.image.BufferedImage)
			fromBufferedImage(new BufferedImageData((java.awt.image.BufferedImage)nativeObject),options,false);
		else {
			fromBufferedImage(toBufferedImage((java.awt.Image)nativeObject),options,false);
		}
	}
	public Object getNativeDrawable()
	{
		return bufferedImage.bi;
	}
	
	/*
//	-------------------------------------------------------------------
	public static ImageInfo getImageInfo(InputStream source,ImageInfo destination) throws IllegalArgumentException, IOException
//	-------------------------------------------------------------------
	{
		RandomStream ras = RewindableStream.toRewindableStream(source);
		ImageCodec ic = new ImageCodec();
		if (!ic.decode(ras)) throw new IllegalArgumentException();
		if (destination == null) destination = new ImageInfo();
		if (ic.isGIFFile || ic.isJPEGFile){
			if (image == null) {
				RewindableStream.rewind(ras);
				image = getBytes(ras);
			}
			java.awt.Image im = Toolkit.getDefaultToolkit().createImage(image.data,0,image.length);
			if (!new ImagePreparer().prepare(im,true)) ;//throw new IllegalArgumentException();
			ic.width = im.getWidth(null);
			ic.height = im.getHeight(null);
			im.flush();
		}
		destination.width = ic.width;
		destination.height = ic.height;
		destination.canScale = false;
		if (ic.isJPEGFile) destination.format = destination.FORMAT_JPEG;
		else if (ic.isGIFFile) destination.format = destination.FORMAT_GIF;
		else if (ic.isBMPFile) destination.format = destination.FORMAT_BMP;
		else destination.format = destination.FORMAT_PNG;
		
		destination.size = ic.width*ic.height*4;
		
		return destination;
	}
	*/
	/**
	 * This optimizes an Image for fast display if possible without losing color quality.
	 * @return an optimized image which may or may not be this image.
	 */
	/*
	public Image optimizeForDisplay()
	{
		return this;
	}
	*/
	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength) throws IllegalStateException {
		bufferedImage.getImageScanLines(startLine,numLines,destArray,offset,destScanLineLength);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength) throws IllegalStateException {
		bufferedImage.setImageScanLines(startLine,numLines,sourceArray,offset,sourceScanLineLength);
	}
	public Graphics getGraphics()
	{
		return new Graphics(this);
	}
	/* (non-Javadoc)
	 * @see eve.fx.ISurface#drawImage(eve.fx.Image, int, int, int, int, int, int, int, int)
	 */
	public void drawImage(Image src, int clipX, int clipY, int clipWidth, int clipHeight, int destX, int destY, int width, int height) {
		Graphics g = new Graphics(this);
		try{
			Rect r = Rect.getCached(clipX,clipY,clipWidth,clipHeight);
			Rect d = Rect.getCached(destX,destY,width,height);
			r.getIntersection(d,r);
			g.setClip(r.x,r.y,r.width,r.height);
			g.drawImage(src,destX,destY);
			r.cache();
			d.cache();
		}finally{
			g.free();
		}
	}
	public boolean captureImage(Image dest, int x, int y, int width, int height) {
		Graphics g = new Graphics(dest);
		try{
			g.copyRect(this,x,y,width,height,0,0);
			return true;
		}finally{
			g.free();
		}
	}
	/* (non-Javadoc)
	 * @see eve.fx.ISurface#moveImage(int, int, int, int, int, int)
	 */
	public boolean moveImage(int srcX, int srcY, int srcWidth, int srcHeight, int destX, int destY) {
		Graphics g = new Graphics(this);
		try{
			g.moveRect(srcX,srcY,srcWidth,srcHeight,destX,destY);
			return true;
		}finally{
			g.free();
		}
	}
	/* (non-Javadoc)
	 * @see eve.fx.ISurface#canCapture()
	 */
	public boolean canCapture() {
		return true;
	}
	/* (non-Javadoc)
	 * @see eve.fx.ISurface#canMove()
	 */
	public boolean canMove() {
		return true;
	}
	/* (non-Javadoc)
	 * @see eve.fx.ISurface#getCompatibleImage(int, int)
	 */
	public Image getCompatibleImage(int width, int height) throws IllegalArgumentException {
		return new Image(width,height);
	}
	public static ImageInfo getImageInfo(FormattedDataSource source,ImageInfo destination)
	throws IOException
	{
		if (destination == null) destination = new ImageInfo();
		ImageDecoder id = new ImageDecoder();
		if (!id.analyze(source, destination))
			throw new ImageDecodingException(source,null);
		return destination;
	}
	
}
//####################################################
	
