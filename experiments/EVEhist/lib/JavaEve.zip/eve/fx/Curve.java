package eve.fx;

import java.lang.ref.SoftReference;
import java.util.Hashtable;
import java.util.Map;

import eve.sys.Device;
import eve.util.IntArray;

/**
* This class provides methods for calculating points and bounds for
* linear, quadratic and cubic curves.<p>
A Curve object is stateless but the methods are not static so that a
better implementation can be created and substituted for the static variable
"curve" if necessary.
**/
//##################################################################
public class Curve{
//##################################################################


public static Curve curve = new Curve();

static double [] quads, cubes;

public static final int MAX_POINTS = 100;

private static boolean hasNative = true;

//-------------------------------------------------------------------
private static native void nativeCalculatePoints(double [] quads, double [] cubes, int maxPoints);
private static native int nativeCalculateCurves(double [] factors, float [] points, Object destX, Object destY, int offset, int options, int numPoints);
private static native int nativeToLineSegments(int[] x,int[] y, int xoffset, int yoffset, int count);
private static native int nativeRightTransform(int[] x,int[] y, int xoffset, int yoffset, int count, int m00, int m10, int m01, int m11, int m02, int m12);
//-------------------------------------------------------------------

//-------------------------------------------------------------------
private static void calculatePoints()
//-------------------------------------------------------------------
{
	quads = new double[3*MAX_POINTS];
	cubes = new double[4*MAX_POINTS];
	if (hasNative) try{
		nativeCalculatePoints(quads,cubes,MAX_POINTS);
		return;
	}catch(UnsatisfiedLinkError e){
		hasNative = false;
	}catch(SecurityException se){
		hasNative = false;
	}
	double dp = (double)1.0/(double)MAX_POINTS;
	double t = 0.0;
	for (int i = 0; i<MAX_POINTS; i++){
		quads[i*3] = Math.pow(1.0-t,2);
		quads[i*3+1] = 2*t*(1.0-t);
		quads[i*3+2] = t*t;
		t += dp;
	}
	dp = (double)1.0/(double)MAX_POINTS;
	t = 0.0;
	for (int i = 0; i<MAX_POINTS; i++){
		cubes[i*4] = 	(1.0-t)*(1.0-t)*(1.0-t);
		cubes[i*4+1] = 3*t*(1.0-t)*(1.0-t);
		cubes[i*4+2] = 3*(1.0-t)*t*t;
		cubes[i*4+3] = t*t*t;
		t += dp;
	}
}
/**
* This calculates the points on a quad curve, for either the x or y co-ordinate. This is called
* by the other calculateQuads method. If the destination object is null this should return the
* number of points in the curve.<p>
* This method does NOT include the last point on the curve, but DOES include the first one.
**/
//-------------------------------------------------------------------
protected int calculateLines(float startx,float starty,float endx,float endy,Object destx,Object desty,int offset,int options)
//-------------------------------------------------------------------
{
	int [] dxi = destx instanceof int [] ? (int [])destx : null;
	float [] dxf = destx instanceof float [] ? (float [])destx : null;
	int [] dyi = desty instanceof int [] ? (int [])desty : null;
	float [] dyf = desty instanceof float [] ? (float [])desty : null;
	
	int numPoints = 1;
	
	if (dxi == null && dxf == null) return numPoints;
	
	if (dxi != null) dxi[offset] = (int)startx;
	else dxf[offset] = (float)startx;

	if (dyi != null) dyi[offset] = (int)starty;
	else dyf[offset] = (float)starty;
	offset++;
	return numPoints;
}

private float [] pars = new float[8];
/**
* This calculates the points on a quad curve, for either the x or y co-ordinate. This is called
* by the other calculateQuads method. If the destination object is null this should return the
* number of points in the curve.<p>
* This method does NOT include the last point on the curve, but DOES include the first one.
**/
//-------------------------------------------------------------------
protected synchronized int calculateQuads(float startx,float starty,float controlx,float controly,float endx,float endy,Object destx,Object desty,int offset,int options)
//-------------------------------------------------------------------
{
	if (quads == null) calculatePoints();
	int numPoints = 20;
	
	if (hasNative) try{
		pars[0] = startx; pars[1] = starty;
		pars[2] = controlx; pars[3] = controly;
		pars[4] = endx; pars[5] = endy;
		if (destx instanceof int []) options |= 0x80000000;
		return nativeCalculateCurves(quads,pars,destx,desty,offset,options,numPoints);
	}catch(UnsatisfiedLinkError e){
		hasNative = false;
	}catch(SecurityException se){
		hasNative = false;
	}
	
	int [] dxi = destx instanceof int [] ? (int [])destx : null;
	float [] dxf = destx instanceof float [] ? (float [])destx : null;
	int [] dyi = desty instanceof int [] ? (int [])desty : null;
	float [] dyf = desty instanceof float [] ? (float [])desty : null;
	
	
	if (dxi == null && dxf == null) return numPoints;
	
	int t = 0;
	int dt = ((quads.length/3)/numPoints)*3;
	int skipped = 0;
	double sx = startx, ex = endx, c1x = controlx;
	double sy = starty, ey = endy, c1y = controly;
	
	for (int i = 0; i<numPoints; i++){
		double x = (quads[t]*sx+quads[t+1]*c1x+quads[t+2]*ex);
		if (dxi != null) dxi[offset] = (int)x;
		else dxf[offset] = (float)x;
		
		double y = (quads[t]*sy+quads[t+1]*c1y+quads[t+2]*ey);
		if (dyi != null) dyi[offset] = (int)y;
		else dyf[offset] = (float)y;
		
		
		if (offset != 0 && dxi != null){
			if (dxi[offset-1] == dxi[offset] && dyi[offset-1] == dyi[offset]){
				offset--;
				skipped++;
			}else{
				if (offset > 1){
					if (dxi[offset-1] == dxi[offset] && dxi[offset-2] == dxi[offset]){
						offset--;
						skipped++;
						dyi[offset] = dyi[offset+1];
					}
					else if (dyi[offset-1] == dyi[offset] && dyi[offset-2] == dyi[offset]){
						offset--;
						skipped++;
						dxi[offset] = dxi[offset+1];
						/*
					}else if ((dxi[offset]-dxi[offset-1] == dxi[offset-1]-dxi[offset-2])
					 && (dyi[offset]-dyi[offset-1] == dyi[offset-1]-dyi[offset-2]))
						{
						offset--;
						skipped++;
						dyi[offset] = dyi[offset+1];
						*/
					}
				}
			}
		}
		
		offset++;
		t += dt;

	}
	return numPoints-skipped;
}
//-------------------------------------------------------------------
protected synchronized int calculateCubes(float startx,float starty,float control1x,float control1y,float control2x,float control2y,float endx,float endy,Object destx,Object desty,int offset,int options)
//-------------------------------------------------------------------
{
	if (quads == null) calculatePoints();
	int numPoints = 20;
	if (hasNative) try{
		pars[0] = startx; pars[1] = starty;
		pars[2] = control1x; pars[3] = control1y;
		pars[4] = control2x; pars[5] = control2y;
		pars[6] = endx; pars[7] = endy;
		if (destx instanceof int []) options |= 0x80000000;
		options |= 0x40000000;
		return nativeCalculateCurves(cubes,pars,destx,desty,offset,options,numPoints);
	}catch(UnsatisfiedLinkError e){
		hasNative = false;
	}catch(SecurityException se){
		hasNative = false;
	}
	
	
	int [] dxi = destx instanceof int [] ? (int [])destx : null;
	float [] dxf = destx instanceof float [] ? (float [])destx : null;
	int [] dyi = desty instanceof int [] ? (int [])desty : null;
	float [] dyf = desty instanceof float [] ? (float [])desty : null;
	
	if (dxi == null && dxf == null) return numPoints;
	
	int t = 0;
	int dt = ((cubes.length/4)/numPoints)*4;
	double sx = startx, ex = endx, c1x = control1x, c2x = control2x;
	double sy = starty, ey = endy, c1y = control1y, c2y = control2y;
	int skipped = 0;
	for (int i = 0; i<numPoints; i++){
		double x = (cubes[t]*sx+cubes[t+1]*c1x+cubes[t+2]*c2x+cubes[t+3]*ex);
		if (dxi != null) dxi[offset] = (int)x;
		else dxf[offset] = (float)x;
		double y = (cubes[t]*sy+cubes[t+1]*c1y+cubes[t+2]*c2y+cubes[t+3]*ey);
		if (dyi != null) dyi[offset] = (int)y;
		else dyf[offset] = (float)y;
		
		if (offset > 0 && dxi != null){
			if (dxi[offset-1] == dxi[offset] && dyi[offset-1] == dyi[offset]){
				offset--;
				skipped++;
			}else{
				if (offset > 1){
					if (dxi[offset-1] == dxi[offset] && dxi[offset-2] == dxi[offset]){
						offset--;
						skipped++;
						dyi[offset] = dyi[offset+1];
					}
					else if (dyi[offset-1] == dyi[offset] && dyi[offset-2] == dyi[offset]){
						offset--;
						skipped++;
						dxi[offset] = dxi[offset+1];
						/*
					}else if ((dxi[offset]-dxi[offset-1] == dxi[offset-1]-dxi[offset-2])
					 && (dyi[offset]-dyi[offset-1] == dyi[offset-1]-dyi[offset-2]))
						{
						offset--;
						skipped++;
						dyi[offset] = dyi[offset+1];
						*/
					}
				
				}
			}
		}
		offset++;
		t += dt;
	}
	return numPoints-skipped;
}
/**
 * Calculate the line points for the line. This is trivial, since it is only the first point
 * that is ever stored.
 * @param xpoints The X coordinates for the curve. 
	The first one should be the start point, the second should be the end point.
 * @param ypoints The Y coordinates for the curve. 
	The first one should be the start point, the second should be the end point.
	one should be the end point.
 * @param pointsOffset The offset of the points in the xpoints and ypoints array.
 * @param destX Either an int[] or float[] object to hold the destination X points. Can be
 * null if you only are interested in the number of points that will be calculated.
 * @param destY Either an int[] or float[] object to hold the destination Y points. Can be
 * null if you only are interested in the number of points that will be calculated.
 * @param offset The offset into the destX and destY arrays for the points to go.
 * @param options No options are currently defined.
 * @return The number of points that were, or will be put in the destinations.
 */
//===================================================================
public synchronized int calculateLines(float[] xpoints, float[] ypoints, int pointsOffset, Object destX, Object destY, int offset, int options)
//===================================================================
{
	return calculateLines(xpoints[pointsOffset], ypoints[pointsOffset], xpoints[pointsOffset+1], ypoints[pointsOffset+1],  destX, destY, offset, options);
}
/**
 * Calculate the curve points for the curve.
 * @param xpoints The X coordinates for the curve. 
	The first one should be the start point, the second should be the control point and the third
	one should be the end point.
 * @param ypoints The Y coordinates for the curve. 
	The first one should be the start point, the second should be the control point and the third
	one should be the end point.
 * @param pointsOffset The offset of the points in the xpoints and ypoints array.
 * @param destX Either an int[] or float[] object to hold the destination X points. Can be
 * null if you only are interested in the number of points that will be calculated.
 * @param destY Either an int[] or float[] object to hold the destination Y points. Can be
 * null if you only are interested in the number of points that will be calculated.
 * @param offset The offset into the destX and destY arrays for the points to go.
 * @param options No options are currently defined.
 * @return The number of points that were, or will be put in the destinations.
 */
//===================================================================
public synchronized int calculateQuads(float[] xpoints, float[] ypoints, int pointsOffset, Object destX, Object destY, int offset, int options)
//===================================================================
{
	return calculateQuads(xpoints[pointsOffset],ypoints[pointsOffset], xpoints[pointsOffset+1],ypoints[pointsOffset+1], xpoints[pointsOffset+2], ypoints[pointsOffset+2], destX, destY, offset, options);
}
/**
 * Calculate the curve points for the curve.
 * @param xpoints The X coordinates for the curve. 
	The first one should be the start point, the second should be the control point and the third
	one should be the end point.
 * @param ypoints The Y coordinates for the curve. 
	The first one should be the start point, the second should be the control point and the third
	one should be the end point.
 * @param pointsOffset The offset of the points in the xpoints and ypoints array.
 * @param destX Either an int[] or float[] object to hold the destination X points. Can be
 * null if you only are interested in the number of points that will be calculated.
 * @param destY Either an int[] or float[] object to hold the destination Y points. Can be
 * null if you only are interested in the number of points that will be calculated.
 * @param offset The offset into the destX and destY arrays for the points to go.
 * @param options No options are currently defined.
 * @return The number of points that were, or will be put in the destinations.
 */
//===================================================================
public synchronized int calculateCubes(float[] xpoints, float[] ypoints, int pointsOffset, Object destX, Object destY, int offset, int options)
//===================================================================
{
	return calculateCubes(xpoints[pointsOffset],ypoints[pointsOffset],xpoints[pointsOffset+1],ypoints[pointsOffset+1], xpoints[pointsOffset+2],ypoints[pointsOffset+2], xpoints[pointsOffset+3],ypoints[pointsOffset+3], destX, destY, offset, options);
}
/**
 * Transform a set of x and y co-ordinates but only with integer precision.
 * The method is only suitable for transforms and right angled rotations.<p>
 * The transform is done as follows:<br>
 * <pre>
 * x = x*m00+y*m01+m02
 * y = x*m10+y*m11+m12
 * </pre>
 * <p>
 * @param x The
 * @param y
 * @param xoffset
 * @param yoffset
 * @param count
 * @param m00
 * @param m10
 * @param m01
 * @param m11
 * @param m02
 * @param m12
 */
public void rightTransform(int[] xpoints,int[] ypoints, int xoffset, int yoffset, int count, int m00, int m10, int m01, int m11, int m02, int m12)
{
	if (hasNative)try{
		nativeRightTransform(xpoints, ypoints, xoffset, yoffset, count, m00, m10, m01, m11, m02, m12);
		return;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	if (ypoints == null) ypoints = xpoints;
	int step = 1;
	if (ypoints == xpoints)
		if (xoffset == yoffset || yoffset == xoffset+1){
			yoffset = xoffset+1;
			step = 2;
		}
	for (int i = 0; i<count; i++){
		int x = xpoints[xoffset], y = ypoints[yoffset];
		xpoints[xoffset] = x*m00+y*m01+m02;
		ypoints[yoffset] = x*m10+y*m11+m12;
		xoffset += step;
		yoffset += step;
	}
}
public final void rightTransform(int[] xyPoints, int offset, int count, int m00, int m10, int m01, int m11, int m02, int m12)
{
	rightTransform(xyPoints, xyPoints, offset, offset+1, count, m00, m10, m01, m11, m02, m12);
}

protected int getQuadrantPoints(int rx, int ry, int destX[], int destY[], int xOffset, int yOffset)
{
	if (rx <= 0 || ry <= 0) return 0;
	if (destY == null) destY = destX;
	int xStep = 1, yStep = 1;
	if (destX == destY)
		if (yOffset == xOffset || yOffset == xOffset+1){
			yOffset = xOffset+1;
			xStep = yStep = 2;
		}
	int rxs = rx*rx, rys = ry*ry, rbs = rx*rx*ry*ry;
	double ryx = (double)rys/(double)rxs;
	double rxy = (double)rxs/(double)rys;
	int did = 0;
	if (rx >= ry || true){
		int x = 1, y = ry-1;
		while(x <= rx){
			int yy = 0;
			if (x == 1) yy = ry-1;
			else if (x != rx) yy = (int)(Math.sqrt(rys-(x*x*ryx))+0.5)-1;
			if (yy < 0) yy = 0;
			while(y-1 > yy){
				y--;
				destX[xOffset] = x-1; xOffset += xStep;
				destY[yOffset] = y; yOffset += yStep;
				did++;
			}
			y = yy;
			destX[xOffset] = x-1; xOffset += xStep;
			destY[yOffset] = y; yOffset += yStep;
			did++;
			x++;
		}
	}else{
		int x = rx-1, y = 1;
		while(y <= ry){
			int xx = (int)(Math.sqrt(rxs-(y*y*rxy))+0.5)-1;
			if (xx < 0) xx = 0;
			while(x-1 > xx){
				x--;
				destX[xOffset] = x; xOffset += xStep;
				destY[yOffset] = y-1; yOffset += yStep;
				did++;
			}
			destX[xOffset] = xx; xOffset += xStep;
			destY[yOffset] = y-1; yOffset += yStep;
			x = xx;
			did++;
			y++;
		}
	}
	return did;
}
public QuadrantPoints getQuadrantPoints(int rx, int ry, QuadrantPoints dest)
{
	if (dest == null) dest = new QuadrantPoints();
	if (dest.xyPoints == null || dest.xyPoints.length < (rx+ry)*2)
		dest.xyPoints = new int[(rx+ry)*2];
	dest.width = rx;
	dest.height = ry;
	dest.numPoints = getQuadrantPoints(rx, ry, dest.xyPoints, dest.xyPoints, 0, 1);
	return dest;
}
/*
public IntArray getQuadrantPoints(int rx, int ry,IntArray dest)
{
	if (dest == null) dest = new IntArray();
	dest.ensureCapacity(dest.length+(rx+ry)*2);
	int got = getQuadrantPoints(rx, ry, dest.data, dest.data, dest.length, dest.length+1);
	dest.length += got*2;
	return dest;
}
*/

class quadEntry {
	int rx, ry;
	quadEntry()
	{
		
	}
	quadEntry set(int rx, int ry)
	{
		this.rx = rx;
		this.ry = ry;
		return this;
	}
	public int hashCode()
	{
		//FIXME get a real hash code.
		return (rx * 1231) ^ ry;
	}
	public boolean equals(Object other)
	{
		quadEntry o =(quadEntry)other;
		return o.rx == rx && o.ry == ry;
	}
}

private static Map quadTable;
private static quadEntry qe;
/**
 * This returns a reused version of a QuadrantPoints for the specified
 * x and y radii. The returned quadrant represents the south-east quadrant
 * using standard screen co-ordinates where x goes from left to right
 * and y goes from top to bottom.
 * @param rx the x-radius.
 * @param ry the y-radius.
 * @return a reused version of a QuadrantPoints for the specified x and y radii.
 */
public QuadrantPoints getCachedQuadrantPoints(int rx, int ry)
{
	synchronized(Curve.class){
		if (quadTable == null) quadTable = new Hashtable();
		if (qe == null) qe = new quadEntry();
		qe.set(rx, ry);
		SoftReference sr = (SoftReference)quadTable.get(qe);
		QuadrantPoints q = sr != null ? (QuadrantPoints)sr.get():null;
		if (q == null){
			q = getQuadrantPoints(rx, ry, null);
			quadTable.put(qe,new SoftReference(q));
			qe = null;
		}
		return q;
	}
}
/**
 * Convert points to straight line segments as best as possible. The
 * original array is modified.
 * @param x the x co-ordinates.
 * @param y the y co-ordinates. If it is null it is assumed equal to x.
 * @param xoffset the x offset for the start of the x co-ordinates.
 * @param yoffset the y offset for the start of the y co-ordinates.
 * If y is equal to x (or null) AND the y offset is equal to the x offset
 * or the x offset+1 then it assumed that the x and y co-ordinates
 * are interleaved within the array (first x, then y).
 * @param numPoints the number of points in the original data.
 * @return the numer of points that make up the line segments.
 */
public int pointsToLines(int[] x, int[] y, int xoffset, int yoffset, int numPoints)
{
	if (hasNative) try{
		return nativeToLineSegments(x,y,xoffset,yoffset,numPoints);
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	} 
	int dxy = 1;
	int np = 0;
	if (y == null || y == x){
		y = x;
		if (yoffset == xoffset || yoffset == xoffset+1){
			yoffset = xoffset+1;
			dxy = 2;
		}
	}
	int lastX = -1, lastY = -1;
	int ix = xoffset, iy = yoffset;
	int sx = xoffset, sy = yoffset;
	int ddy = 0, ddx = 0;
	boolean newPoint = true;
	for (int i = 0; i<numPoints; i++){
		boolean lastPoint = i == numPoints-1;
		if (lastX == -1 || (newPoint && lastPoint)){
			lastX = ix;
			lastY = iy;
			x[ix] = x[sx];
			y[iy] = y[sy];
			ix += dxy; iy += dxy;
			sx += dxy; sy += dxy;
			np++;
			newPoint = true;
		}else if (newPoint){
			newPoint = false;
			ddx = x[sx]-x[lastX];
			ddy = y[sy]-y[lastY];
			sx += dxy;
			sy += dxy;
		}else{
			if ((x[sx]-x[sx-dxy] != ddx) || (y[sy]-y[sy-dxy] != ddy)){
				//
				// Not on the same line.
				//
				x[ix] = x[sx-dxy];
				y[iy] = y[sy-dxy];
				ix += dxy; iy += dxy;
				np++;
				i--;
				lastX = -1;
				continue;
			}else if (lastPoint){
				//
				// On the same line, but it's the last point.
				//
				x[ix] = x[sx];
				y[iy] = y[sy];
				ix += dxy; iy += dxy;
				np++;
			}else{
				sx += dxy;
				sy += dxy;
			}
		}
	}
	return np;
}
/**
 * Given a bounding box for an ellipse, this method finds the points
 * along the specified arc such that there are no gaps in the arc.<p>
 * The points are placed in the destination IntArray with the x and y
 * co-ordinates interleaved - i.e. X1, Y1, X2, Y2, ...
 * <p>
 * The number of co-ordinate points will be equal to the returned IntArray
 * length field divided by 2. 
 * @param x the x co-ordinate of the ellipse bounding box.
 * @param y the y co-ordinate of the ellipse bounding box.
 * @param width the width of the ellipse bounding box.
 * @param height the height of the ellipse bounding box.
 * @param start the start angle in degrees, where 0 is at the 3 O' clock
 * position (due East), 90 is at the 12 O' clock position (due North), etc..
 * @param angle the number of degrees of the arc anti-clockwise.
 * @param dest - a destination IntArray <b>which will be cleared</b>
 * before having the x,y co-ordinates added.
 * @return the destination IntArray or a new one if dest was null.
 */
public IntArray getArcPoints(int x, int y, int width, int height, float start, float angle,IntArray dest)
{
	QuadrantPoints qp = getCachedQuadrantPoints((width+1)/2,(height+1)/2);
	return getArc(x,y,width,height,start,angle,qp,dest);
}
/**
 * Given a bounding box for an ellipse, this method finds the line segments
 * along the specified arc such that there are no gaps in the arc.<p>
 * The points are placed in the destination IntArray with the x and y
 * co-ordinates interleaved - i.e. X1, Y1, X2, Y2, ...
 * <p>
 * The number of co-ordinate points will be equal to the returned IntArray
 * length field divided by 2. 
 * @param x the x co-ordinate of the ellipse bounding box.
 * @param y the y co-ordinate of the ellipse bounding box.
 * @param width the width of the ellipse bounding box.
 * @param height the height of the ellipse bounding box.
 * @param start the start angle in degrees, where 0 is at the 3 O' clock
 * position (due East), 90 is at the 12 O' clock position (due North), etc..
 * @param angle the number of degrees of the arc anti-clockwise.
 * @param dest - a destination IntArray <b>which will be cleared</b>
 * before having the x,y co-ordinates added.
 * @return the destination IntArray or a new one if dest was null.
 */
public IntArray getArcLines(int x, int y, int width, int height, float start, float angle,IntArray dest)
{
	QuadrantPoints qp = getCachedQuadrantPoints((width+1)/2,(height+1)/2);
	dest = getArc(x,y,width,height,start,angle,qp,dest);
	dest.length = pointsToLines(dest.data, null, 0, 0, dest.length/2)*2;
	return dest;
}

private IntArray arc;
/**
 * Draw an arc of an ellipse on the Graphics context using the current pen.
 * A start angle of 0 and an arc angle of 360 will give a full ellipse. 
 * @param g The destination graphics.
 * @param x the x co-ordinate of the ellipse bounding box.
 * @param y the y co-ordinate of the ellipse bounding box.
 * @param width the width of the ellipse bounding box.
 * @param height the height of the ellipse bounding box.
 * @param start the start angle in degrees, where 0 is at the 3 O' clock
 * position (due East), 90 is at the 12 O' clock position (due North), etc..
 * @param angle the number of degrees of the arc anti-clockwise.
 */
public void drawArc(Graphics g,int x,int y,int width,int height,float startAngle,float angle)
{
	synchronized(this){
		arc = getArcPoints(x,y,width,height,startAngle,angle,arc);
		int count = arc.length/2;
		//System.out.println(arc.data[0]+", "+arc.data[1]+", "+arc.data[(count-1)*2]+", "+arc.data[(count-1)*2+1]);
		arc.length = pointsToLines(arc.data, null, 0, 0, arc.length/2)*2;
		count = arc.length/2;
		//System.out.println(arc.data[0]+", "+arc.data[1]+", "+arc.data[(count-1)*2]+", "+arc.data[(count-1)*2+1]);
		g.drawLines(arc.data, arc.data, 0, 1, arc.length/2, false);
	}
}
/**
 * Draw and/or fill a closed arc of an ellipse on the Graphics context.<p>
 * A start angle of 0 and an arc angle of 360 will give a full ellipse. 
 * @param g The destination graphics.
 * @param x the x co-ordinate of the ellipse bounding box.
 * @param y the y co-ordinate of the ellipse bounding box.
 * @param width the width of the ellipse bounding box.
 * @param height the height of the ellipse bounding box.
 * @param start the start angle in degrees, where 0 is at the 3 O' clock
 * position (due East), 90 is at the 12 O' clock position (due North), etc..
 * @param angle the number of degrees of the arc anti-clockwise.
 * @param useBrush true to fill the closed arc with the current brush.
 * @param usePen true to outline the closed arc with the current pen.
 */
public void paintClosedArc(Graphics g,int x,int y,int width,int height,float startAngle,float angle,boolean useBrush,boolean usePen)
{
	synchronized(this){
		arc = getArcPoints(x,y,width,height,startAngle,angle,arc);
		arc.length = pointsToLines(arc.data, null, 0, 0, arc.length/2)*2;
		int count = arc.length/2;
		g.paintPolygon(arc.data, arc.data, 0, 1, count, useBrush, usePen);
	}
}
/**
 * Draw and/or fill a pie section of an ellipse on the Graphics context. 
 * An arc angle of 360 will give a full ellipse with a single line from
 * the center to the start angle. 
 * @param g The destination graphics.
 * @param x the x co-ordinate of the ellipse bounding box.
 * @param y the y co-ordinate of the ellipse bounding box.
 * @param width the width of the ellipse bounding box.
 * @param height the height of the ellipse bounding box.
 * @param start the start angle in degrees, where 0 is at the 3 O' clock
 * position (due East), 90 is at the 12 O' clock position (due North), etc..
 * @param angle the number of degrees of the arc anti-clockwise.
 * @param useBrush true to fill the pie section with the current brush.
 * @param usePen true to outline the pie section with the current pen.
 */
public void paintPie(Graphics g,int x,int y,int width,int height,float startAngle,float angle,boolean useBrush,boolean usePen)
{
	synchronized(this){
		arc = getArcPoints(x,y,width,height,startAngle,angle,arc);
		int count = arc.length/2;
		//System.out.println(arc.data[0]+", "+arc.data[1]+", "+arc.data[(count-1)*2]+", "+arc.data[(count-1)*2+1]);
		arc.length = pointsToLines(arc.data, null, 0, 0, arc.length/2)*2;
		count = arc.length/2;
		//System.out.println(arc.data[0]+", "+arc.data[1]+", "+arc.data[(count-1)*2]+", "+arc.data[(count-1)*2+1]);
		arc.append((width+1)/2+x-1); arc.append((height+1)/2+y-1);
		count++;
		g.paintPolygon(arc.data, arc.data, 0, 1, count, useBrush, usePen);
	}
}
public void copyTransformedQuadrant(int[] srcXYPoints, int srcOffset, int numPoints, int[] destXYPoints, int destOffset, int quadrant, int x, int y, int width, int height, int xradius, int yradius)
{
	System.arraycopy(srcXYPoints, srcOffset, destXYPoints, destOffset, numPoints*2);
	switch(quadrant){
	case 0:
		rightTransform(destXYPoints, destOffset, numPoints, 1, 0, 0, 1, x+width-xradius, y+height-yradius);
		break;
	case 1:
		rightTransform(destXYPoints, destOffset, numPoints, 0, -1, 1, 0, x+width-yradius, y+xradius-1);
		break;
	case 2:
		rightTransform(destXYPoints, destOffset, numPoints, -1, 0, 0, -1, x+xradius-1, y+yradius-1);
		break;
	case 3:
		rightTransform(destXYPoints, destOffset, numPoints, 0, 1, -1, 0, x+yradius-1, y+height-xradius);
		break;
	}
}
static String print(int[] xy, int offset, int points)
{
	StringBuffer sb = new StringBuffer();
	for (int i = 0; i<points; i++){
		sb.append("("+xy[offset++]+","+xy[offset++]+")");
	}
	return sb.toString();
}
public void drawRoundRectOutline(Graphics g, int style, int x,int y,int width,int height,int radius, int labelWidth)
{
	synchronized(this){
		QuadrantPoints qp = getCachedQuadrantPoints(radius,radius);
		if (arc == null) arc = new IntArray();
		arc.ensureCapacity(qp.numPoints*4);
		// Get original 0 quadrant points.
		System.arraycopy(qp.xyPoints, 0, arc.data, 0, qp.numPoints*2);
		int cp = pointsToLines(arc.data, arc.data, 0, 1, qp.numPoints);
		arc.length = cp*2;
		//
		if ((style & Graphics.BF_BOTTOM) == 0){
			arc.ensureCapacity(cp*2*5+4);
			int off = cp*2, len = cp*2;
			arc.data[off++] = x+width-1;
			arc.data[off++] = y+height;
			copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 1, x, y, width, height, radius, radius);
			off += cp*2;
			copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 2, x, y, width, height, radius, radius);
			off += cp*2;
			arc.data[off++] = x;
			arc.data[off++] = y+height;
			int numPoints = (off-cp*2)/2;
			off = cp*2;
			g.drawLines(arc.data, arc.data, off, off+1, numPoints, false);
			
		}else if (labelWidth != 0){
			arc.ensureCapacity(cp*2*5+4);
			int off = cp*2, len = cp*2;
			arc.data[off++] = x+4;
			arc.data[off++] = y;
			copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 2, x, y, width, height, radius, radius);
			off += cp*2;
			copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 3, x, y, width, height, radius, radius);
			off += cp*2;
			copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 0, x, y, width, height, radius, radius);
			off += cp*2;
			copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 1, x, y, width, height, radius, radius);
			off += cp*2;
			arc.data[off++] = x+labelWidth+3;
			arc.data[off++] = y;
			int numPoints = (off-cp*2)/2;
			off = cp*2;
			g.drawLines(arc.data, arc.data, off, off+1, numPoints, false);
			
		}else{
			paintRoundRect(g, x, y, width, height, radius, false, true);
		}
	}
}
/*
public IntArray getRoundRectPoints(int style, int x,int y,int width,int height,int radius, int labelWidth, IntArray dest)
{
	if (dest == null) dest = new IntArray();
	synchronized(this){
		QuadrantPoints qp = getCachedQuadrantPoints(radius,radius);
		if (arc == null) arc = new IntArray();
		arc.ensureCapacity(qp.numPoints*2);
		// Get original 0 quadrant points.
		System.arraycopy(qp.xyPoints, 0, arc.data, 0, qp.numPoints*2);
		int cp = pointsToLines(arc.data, arc.data, 0, 1, qp.numPoints);
		arc.length = cp*2;
		dest.ensureCapacity(dest.length+cp*2*4+4);
		//
		if ((style & (Graphics.BF_TOP|Graphics.BF_LEFT)) != (Graphics.BF_TOP|Graphics.BF_LEFT)){
			copyTransformedQuadrant(arc.data, 0, cp, dest.data, dest.length, 2, x, y, width, height, radius, radius);
		}else{
			dest.append(x); dest.append(y);
		}
		if ((style & (Graphics.BF_LEFT|Graphics.BF_BOTTOM)) != (Graphics.BF_TOP|Graphics.BF_LEFT)){
			copyTransformedQuadrant(arc.data, 0, cp, dest.data, dest.length, 3, x, y, width, height, radius, radius);
		}else{
			dest.append(x); dest.append(y+height-1);
		}
		if ((style & (Graphics.BF_BOTTOM|Graphics.BF_RIGHT)) != (Graphics.BF_TOP|Graphics.BF_LEFT)){
			copyTransformedQuadrant(arc.data, 0, cp, dest.data, dest.length, 3, x, y, width, height, radius, radius);
		}else{
			dest.append(x); dest.append(y+height-1);
		}
	}	
}
*/
public void paintRoundRect(Graphics g,int x,int y,int width,int height,int radius,boolean useBrush, boolean usePen)
{
	synchronized(this){
		QuadrantPoints qp = getCachedQuadrantPoints(radius,radius);
		if (arc == null) arc = new IntArray();
		arc.ensureCapacity(qp.numPoints*2);
		// Get original 0 quadrant points.
		System.arraycopy(qp.xyPoints, 0, arc.data, 0, qp.numPoints*2);
		// Convert to line segments.
		int cp = pointsToLines(arc.data, arc.data, 0, 1, qp.numPoints);
		arc.length = cp*2;
		// Now copy into new area.
		arc.ensureCapacity(cp*2*5);
		int off = cp*2, len = cp*2;
		copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 0, x, y, width, height, radius, radius);
		off += cp*2;
		copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 1, x, y, width, height, radius, radius);
		off += cp*2;
		copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 2, x, y, width, height, radius, radius);
		off += cp*2;
		copyTransformedQuadrant(arc.data, 0, cp, arc.data, off, 3, x, y, width, height, radius, radius);
		off = cp*2;
		g.paintPolygon(arc.data, arc.data, off, off+1, cp*4, useBrush, usePen);
	}
}
private int startOfQuadrant(int which, QuadrantPoints points, boolean hSkip, boolean vSkip)
{
	int was = which;
	int total = points.numPoints;
	int idx = 0;
	if (which != 0){
		idx += total;
		if (hSkip) idx--;
		which--;
	}
	if (which != 0){
		idx += total;
		if (vSkip) idx--;
		which--;
	}
	if (which != 0){
		idx += total;
		if (hSkip) idx--;
		which--;
	}
	if (was == 2 && !vSkip) idx--;
	else if (was == 3 && !hSkip) idx--;
	return idx;
}
private int endOfQuadrant(int which, QuadrantPoints points, boolean hSkip, boolean vSkip)
{
	int was = which;
	int total = points.numPoints;
	int idx = 0;
	which++;
	if (which != 0){
		idx += total;
		if (hSkip) idx--;
		which--;
	}
	if (which != 0){
		idx += total;
		if (vSkip) idx--;
		which--;
	}
	if (which != 0){
		idx += total;
		if (hSkip) idx--;
		which--;
	}
	if (which != 0){
		idx += total;
		if (vSkip) idx--;
		which--;
	}
	if (was == 1 && !vSkip) idx--;
	else if (was == 2 && !hSkip) idx--;
	return idx;
}
private int checkStarting(float st, QuadrantPoints points, boolean hSkip, boolean vSkip)
{
	while(st > 360) st -= 360;
	while(st < 0) st += 360;
	if ((st/90) == (float)((int)(st/90))){
		int q = 0;
		while(st > 0) {
			q++;
			st -= 90;
		}
		return startOfQuadrant(q, points, hSkip, vSkip);
	}
	return -1;
}
private int checkEnding(float st, QuadrantPoints points, boolean hSkip, boolean vSkip)
{
	while(st > 360) st -= 360;
	while(st < 0) st += 360;
	if ((st/90) == (float)((int)(st/90))){
		int q = 0;
		if (st <= 0){
			q = 3;
		}else{
			st -= 90;
			while(st > 0) {
				q++;
				st -= 90;
			}
		}
		return endOfQuadrant(q, points, hSkip, vSkip);
	}
	return -1;
}
private IntArray getArc(int x, int y,int width, int height, float start, float size, QuadrantPoints points, IntArray dest)
{
	if (dest == null) dest = new IntArray();
	dest.clear();
	int numPoints = points.numPoints*4;
	boolean vSkip = (height & 1) != 0;
	boolean hSkip = (width & 1) != 0;
	if (vSkip) numPoints -= 2;
	if (hSkip) numPoints -= 2;
	int totalPoints = numPoints; 
	if (numPoints <= 0) return dest;
	float ppd = (float)numPoints/360;
	while (start < 0) start += 360;
	while (start >= 360) start -= 360;
	//
	float tsp = start;
	//
	if (size < 0) {
		start += size;
		size = -size;
	}
	while (start < 0) start += 360;
	while (start >= 360) start -= 360;
	int sp = (int)(ppd*start);
	//
	if (size < 360) {
		int sh = checkStarting(start, points, hSkip, vSkip);
		if (sh != -1) sp = sh;
		int ep = checkEnding(start+size,points,hSkip,vSkip);
		if (ep != -1) {
			numPoints = (ep-sp)+1;
			while (numPoints <= 0) numPoints += totalPoints;
		}
		else numPoints = (int)(size*ppd);
	}
	else numPoints = totalPoints+1; //Include the first point again.
	//
	if (numPoints <= 0) numPoints = 1;
	// numPoints now holds how many points we need.
	if (size < 360 && tsp != start){
		int ttsp = (int)(ppd*tsp);
		int end = sp+numPoints;
		while(end > totalPoints) end -= totalPoints;
		if (end != ttsp){
			int diff = ttsp-end;
			while(diff > totalPoints) diff -= totalPoints;
			while(diff < 0) diff += totalPoints;
		}
	}
	dest.ensureCapacity(numPoints*2);
	dest.length = numPoints*2;
	int[] pt = points.xyPoints;
	int[] data = dest.data;
	int d = 0;
	int qs = 0x1111;
	boolean started = false;
	while(numPoints != 0){
		// Top Right
		if ((qs & 0x0100) != 0){
			int max = points.numPoints*2;
			if (hSkip) max -= 2;
			int dy = (height+1)/2, dx = (width+1)/2;
			if (hSkip) dx--;
			int idx = points.numPoints*2-2;
			if (!started && sp >= max/2){
				sp -= max/2;
			}else{
				int i = 0;
				if (!started){
					i += sp*2;
					idx -= sp*2;
					sp = 0;
					started = true;
				}
				for (; numPoints > 0 && i < max ; i += 2){
					data[d++] = x+pt[idx]+dx; 
					data[d++] = y+dy-1-pt[idx+1];
					idx -= 2;
					numPoints--;
				}
			}
		}
		if (numPoints <= 0) break;
		// Top Left
		if ((qs & 0x0010) != 0){
			int max = points.numPoints*2;
			if (vSkip) max -= 2;
			int dy = (height+1)/2, dx = (width+1)/2;
			//if (vSkip) dy--;
			int idx = 0;
			if (!started && sp >= max/2){
				sp -= max/2;
			}else{
				int i = 0;
				if (!started){
					i += sp*2;
					idx += sp*2;
					sp = 0;
					started = true;
				}
				for (; numPoints > 0 && i < max ; i += 2){
					data[d++] = x+dx-1-pt[idx]; 
					data[d++] = y+dy-1-pt[idx+1];
					idx += 2;
					numPoints--;
				}
			}
		}
		if (numPoints <= 0) break;
		// Bottom Left
		if ((qs & 0x0001) != 0){
			int max = points.numPoints*2;
			if (hSkip) max -= 2;
			int dy = (height+1)/2, dx = (width+1)/2;
			if (vSkip) dy--;
			//if (hSkip) dx--;
			int idx = points.numPoints*2-2;
			if (!started && sp >= max/2){
				sp -= max/2;
			}else{
				int i = 0;
				if (!started){
					i += sp*2;
					idx -= sp*2;
					sp = 0;
					started = true;
				}
				for (; numPoints > 0 && i < max ; i += 2){
					data[d++] = x+dx-1-pt[idx]; 
					data[d++] = y+pt[idx+1]+dy;
					idx -= 2;
					numPoints--;
				}
			}
		}
		if (numPoints <= 0) break;
		if ((qs & 0x1000) != 0){
			int max = points.numPoints*2;
			if (vSkip) max -= 2;
			int dy = (height+1)/2, dx = (width+1)/2;
			if (vSkip) dy--;
			if (hSkip) dx--;
			//dx = dy = 0;
			int idx = 0;
			if (!started && sp >= max/2){
				sp -= max/2;
			}else{
				int i = 0;
				if (!started){
					i += sp*2;
					idx += sp*2;
					sp = 0;
					started = true;
				}
				for (; numPoints > 0 && i < max ; i += 2){
					data[d++] = x+pt[idx++]+dx; 
					data[d++] = y+pt[idx++]+dy; 
					numPoints--;
				}
			}
		}
	}
	return dest;
}
/*
public IntArray getFullEllipse(int x, int y, int width, int height, QuadrantPoints points, IntArray dest)
{
	if (dest == null) dest = new IntArray();
	dest.clear();
	dest.ensureCapacity(points.numPoints*4*2);
	int[] pt = points.xyPoints;
	int[] data = dest.data;
	int d = 0;
	boolean vSkip = (height & 1) != 0;
	boolean hSkip = (width & 1) != 0;
	// Bottom Right.
	int qs = 0x1111;
	if (true || points.width >= points.height){
		if ((qs & 0x1000) != 0){
			int max = points.numPoints*2;
			if (vSkip) max -= 2;
			int dy = (height+1)/2, dx = (width+1)/2;
			if (vSkip) dy--;
			if (hSkip) dx--;
			//dx = dy = 0;
			int idx = 0;
			for (int i = 0; i<max; i += 2){
				data[d++] = pt[idx++]+dx; 
				data[d++] = pt[idx++]+dy; 
			}
			dest.length += max;
		}
		// Top Right
		if ((qs & 0x0100) != 0){
			int max = points.numPoints*2;
			if (hSkip) max -= 2;
			int dy = (height+1)/2, dx = (width+1)/2;
			if (hSkip) dx--;
			//if (vSkip) dy--;
			int idx = points.numPoints*2-2;
			//dx = dy = 0;
			for (int i = 0; i < max ; i += 2){
				data[d++] = pt[idx]+dx; 
				data[d++] = dy-1-pt[idx+1];
				idx -= 2;
			}
			dest.length += max;
		}
		// Top Left
		if ((qs & 0x0010) != 0){
			int max = points.numPoints*2;
			if (vSkip) max -= 2;
			int dy = (height+1)/2, dx = (width+1)/2;
			//if (vSkip) dy--;
			int idx = 0;
			for (int i = 0; i < max ; i += 2){
				data[d++] = dx-1-pt[idx]; 
				data[d++] = dy-1-pt[idx+1];
				idx += 2;
			}
			dest.length += max;
		}
		// Bottom Left
		if ((qs & 0x0001) != 0){
			int max = points.numPoints*2;
			if (hSkip) max -= 2;
			int dy = (height+1)/2, dx = (width+1)/2;
			if (vSkip) dy--;
			//if (hSkip) dx--;
			int idx = points.numPoints*2-2;
			for (int i = 0; i < max ; i += 2){
				data[d++] = dx-1-pt[idx]; 
				data[d++] = pt[idx+1]+dy;
				idx -= 2;
			}
			dest.length += max;
		}
	}
	return dest;
}
*/
/*
//===================================================================
static void drawQuads(Graphics g,Point start, Point end, Point control, int [] x, int [] y, int options)
//===================================================================
{
	if (x == null) x = new int[100];
	if (y == null) y = new int[100];
	int num = calculateQuads(start,end,control,x,y,0,options);
	g.drawLines(x,y,num);
}
//-------------------------------------------------------------------
static int calculateCubes(int start,int end,int control1,int control2,int [] dest,int offset,int options)
//-------------------------------------------------------------------
{
	if (quads == null) calculatePoints();
	int numPoints = 20;
	int t = 0;
	int dt = ((cubes.length/4)/numPoints)*4;
	double s = start, e = end, c1 = control1, c2 = control2;
	for (int i = 0; i<numPoints; i++){
		dest[offset++] = (int)(cubes[t]*s+cubes[t+1]*c1+cubes[t+2]*c2+cubes[t+3]*e);
		t += dt;
	}
	dest[offset++] = end;
	return numPoints+1;
}

//===================================================================
static int calculateCubes(Point start, Point end, Point control1, Point control2, int [] x, int [] y,int offset, int options)
//===================================================================
{
	calculateCubes(start.x, end.x, control1.x, control2.x, x, offset, options);
	return calculateCubes(start.y, end.y, control1.y, control2.y, y, offset, options);
}
*/

public Curve(){}

//##################################################################
}
//##################################################################

