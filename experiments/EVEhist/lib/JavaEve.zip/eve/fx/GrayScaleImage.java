/*
 * Created on Feb 9, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.Device;
import eve.sys.ImageData;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class GrayScaleImage extends ImageObject {

private ImageData source;
private Rect mr;

	public GrayScaleImage(ImageData source)
	{
		this.source = source;
		this.width = source.getImageWidth();
		this.height = source.getImageHeight();
		mr = new Rect(0,0,width,height);
	}
	/* (non-Javadoc)
	 * @see eve.fx.IImage#usesAlpha()
	 */
	public boolean usesAlpha() {
		return source.getImageType() == TYPE_ARGB;
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void getImageScanLines(int startLine, int numLines,
			Object destArray, int offset, int destScanLineLength)
			throws IllegalStateException {
		getScanLinesUsingPixels(startLine,numLines,destArray,offset,destScanLineLength);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void setImageScanLines(int startLine, int numLines,
			Object sourceArray, int offset, int sourceScanLineLength)
			throws IllegalStateException {
		setScanLinesUsingPixels(startLine,numLines,sourceArray,offset,sourceScanLineLength);

	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#isWriteableImage()
	 */
	public boolean isWriteableImage() {
		return false;
	}

	private static boolean hasNative = true;
	private static native void makeGray(int[] dest, int offset, int lineWidth, int numLines, int rowStride);
	
	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getPixels(int[], int, int, int, int, int, int)
	 */
	public int[] getPixels(int[] dest, int offset, int x, int y, int width,
			int height, int rowStride) {
		if (rowStride <= 0) rowStride = width; 
		dest = source.getPixels(dest,offset,x,y,width,height,rowStride);
		if (dest == null) return dest;
		if (hasNative) try{
			makeGray(dest,offset,width,height,rowStride);
			return dest;
		}catch(Throwable t){
			Device.checkNoNativeMethod(t);
			hasNative = false;
		}
		for (int i = 0; i<height; i++){
			for (int xx = 0; xx < width; xx++){
				int v = dest[offset];
				int a = v & 0xff000000;
				int r = (v >> 16) & 0xff, g = (v >> 8) & 0xff, b = v & 0xff;
				int tot = r+g+b;
				if (tot < 3*128) tot = 3*128;
				int nv = tot/3;
				v = a | (nv << 16) | (nv << 8) | nv;
				dest[offset] = v;
				offset++;
			}
			offset += rowStride-width;
		}
		return dest;
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setPixels(int[], int, int, int, int, int, int)
	 */
	public boolean setPixels(int[] src, int offset, int x, int y, int width,
			int height, int rowStride) {
		return false;
	}

	/* (non-Javadoc)
	 * @see eve.fx.Drawable#draw(eve.fx.Graphics, int, int, int)
	 */
	public void draw(Graphics g, int x, int y, int options) {
		g.drawImageData(this,mr,mr,0);
	}

}

//####################################################
