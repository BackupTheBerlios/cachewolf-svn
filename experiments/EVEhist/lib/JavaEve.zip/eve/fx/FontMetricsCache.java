/*
 * Created on Feb 17, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import java.util.Hashtable;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class FontMetricsCache{

	private Hashtable ht = new Hashtable();
	
	public synchronized FontMetrics get(Font font, ISurface surface)
	{
		if (ht == null) ht = new Hashtable();
		FontMetrics fm = (FontMetrics)ht.get(font);
		if (fm != null) return fm;
		fm = new FontMetrics(font,surface);
		ht.put(font,fm);
		return fm;
	}
	public synchronized FontMetrics get(Font font, Graphics surface)
	{
		if (ht == null) ht = new Hashtable();
		FontMetrics fm = (FontMetrics)ht.get(font);
		if (fm != null) return fm;
		fm = surface.getFontMetrics(font);
		ht.put(font,fm);
		return fm;
	}
}
//####################################################
