/*
 * Created on Oct 28, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.nativeaccess.NativeAccess;
import eve.sys.ImageData;
import eve.sys.ImageDataInfo;

/**
 * This is a base class for a number of other IImage classes. It assumes that the
 * image type is TYPE_ARGB or TYPE_RGB, depending on whether you override usesAlpha()
 * to return true or false.<p>
 * It also implements getImageScanLines() and setImageScanLines() using
 * 
 */
//####################################################
public 
abstract 
class ImageObject implements IImage, ImageMaker{
	// This value should probably be determined using name search.
int nativeImage;
//
// This class should have these 3 variables only!
//
protected int width;
protected int height;
protected Color background;
private Object lineBuffer;
private int[] intBuffer;
private ImageDataInfo dataInfo;

public Object getNativeDrawable()
{
	return new Integer(nativeImage);
}
/* (non-Javadoc)
 * @see eve.fx.IImage#getBackground()
 */
	public Color getBackground() {
		return background;
	}
	/* (non-Javadoc)
	 * @see eve.fx.IImage#getWidth()
	 */
	public int getWidth() {
		return width;
	}
	
	/* (non-Javadoc)
	 * @see eve.fx.IImage#getHeight()
	 */
	public int getHeight() {
		return height;
	}

	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageType()
	 */
	public int getImageType() {
		return usesAlpha() ? TYPE_ARGB : TYPE_RGB;
	}
	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageScanLineType()
	 */
	public int getImageScanLineType() {
		return SCAN_LINE_INT_ARRAY;
	}

	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageScanLineLength()
	 */
	public int getImageScanLineLength() {
		return width;
	}
	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageWidth()
	 */
	public int getImageWidth() {
		return width;
	}

	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageHeight()
	 */
	public int getImageHeight() {
		return height;
	}
	/**
	 * This is a way to implement the ImageData.setImageScanLines() method using the IImage.setPixels()
	 * method. Use this in setImageScanLines() if you have implemented setPixels() correctly.
	 * @param startLine
	 * @param numLines
	 * @param sourceArray
	 * @param offset
	 * @param sourceScanLineLength
	 * @throws IllegalStateException
	 */
	protected synchronized void setScanLinesUsingPixels(int startLine, int numLines,
			Object sourceArray, int offset, int sourceScanLineLength)
	throws IllegalStateException 
	{
		if (!isWriteableImage()) throw new IllegalStateException("Cannot write pixels.");
		int st = getImageScanLineType();
		if (st == SCAN_LINE_INT_ARRAY){
			//
			// Don't need to convert.
			//
			setPixels((int[])sourceArray,offset,0,startLine,width,numLines,sourceScanLineLength);
		}else{
			ImageDataInfo info = getInfo(sourceScanLineLength);
			if (!(lineBuffer instanceof int[]) || ((int[])lineBuffer).length < width)
				lineBuffer = new int[width];
			int[] buffer = (int[])lineBuffer;
			int it = getImageType();
			int[] ct = getImageColorTable();
			for (int i = 0; i<numLines; i++){
				//ImageTool.toARGB(it,width,ct,sourceArray,offset,sourceScanLineLength,buffer,0,width,1);
				ImageTool.toARGB(info,sourceArray,offset,buffer,0,width,1);
				setPixels(buffer,0,0,startLine,this.width,1,width);
				offset += sourceScanLineLength;
				startLine++;
			}
			
		}
	}
	
	private ImageDataInfo getInfo(int forScanLength)
	{
		if (dataInfo == null) {
			dataInfo = new ImageDataInfo();
			dataInfo.fromImageData(this);
		}
		if (forScanLength > 0) dataInfo.scanLineLength = forScanLength;
		else dataInfo.scanLineLength = getImageScanLineLength();
		return dataInfo;
	}
	private ImageDataInfo getInfo()
	{
		return getInfo(-1);
	}
	
	/**
	 * This is a way to implement the ImageData.getImageScanLines() method using the IImage.getPixels()
	 * method. Use this in getImageScanLines() if you have implemented getPixels() correctly.
	 * @param startLine
	 * @param numLines
	 * @param sourceArray
	 * @param offset
	 * @param sourceScanLineLength
	 * @throws IllegalStateException
	 */
	protected synchronized void getScanLinesUsingPixels(int startLine, int numLines,
			Object destArray, int offset, int destScanLineLength) throws IllegalStateException{
		if (!isReadableImage()) throw new IllegalStateException("Cannot read pixels.");
		int st = getImageScanLineType();
		if (st == SCAN_LINE_INT_ARRAY){
			//
			// Don't need to convert.
			//
			getPixels((int[])destArray,offset,0,startLine,this.width,numLines,destScanLineLength);
			return;
		}else{
			if (!(lineBuffer instanceof int[]) || ((int[])lineBuffer).length < width)
				lineBuffer = new int[width];
			int[] buffer = (int[])lineBuffer;
			ImageDataInfo info = getInfo(destScanLineLength);
			for (int i = 0; i<numLines; i++){
				getPixels(buffer,0,0,startLine,this.width,1,width);
				ImageTool.fromARGB(buffer,0,width,info,destArray,offset,1);
				offset += destScanLineLength;
				startLine++;
			}
			return;
		}
	}
	protected synchronized boolean setPixelsUsingScanLines(int[] source, int offset, int x, int y, int width, int height,int rowStride)
	{
		if (rowStride <= 0) rowStride = width;
		if (source == null) throw new NullPointerException();
		int st = getImageScanLineType();
		if (x < 0 || x+width > this.width || y < 0 || y+height > this.height){
			Rect r = new Rect(x,y,width,height);
			offset = ImageTool.clipPixelArea(this,r,offset,rowStride);
			if (offset < 0) return true;
			x = r.x; y = r.y; width = r.width; height = r.height;
		}
		try{
			if (st == SCAN_LINE_INT_ARRAY && width == this.width && x == 0){
				setImageScanLines(y,height,source,offset,rowStride);
				return true;
			}else{
				lineBuffer = ImageTool.getScanLineBuffer(this,1,lineBuffer);
				int it = getImageType();
				int lineLen = getImageScanLineLength();
				int[] ct = getImageColorTable();
				boolean fullWidth = (x == 0 && width == this.width); 
				if (!fullWidth){
					if (intBuffer == null || intBuffer.length < this.width)
						intBuffer = new int[this.width];
				}
				ImageDataInfo info = getInfo();
				for (int i = 0; i<height; i++){
					if (!fullWidth){
						getImageScanLines(y,1,lineBuffer,0,lineLen); // Have complete native line.
						ImageTool.toARGB(info,lineBuffer,0,intBuffer,0,width,1);
						System.arraycopy(source,offset,intBuffer,x,width);
						ImageTool.fromARGB(intBuffer,0,this.width,info,lineBuffer,0,1);
						setImageScanLines(y,1,lineBuffer,0,lineLen);
					}else{
						ImageTool.fromARGB(source,offset,rowStride,info,lineBuffer,0,1);
						//if ((source[offset] & 0x00ffffff) == 0) System.out.println("Black: "+y);
						setImageScanLines(y,1,lineBuffer,0,lineLen);
					}
					offset += rowStride;
					y++;
				}
				return true;
			}
		}catch(IllegalStateException e){
			return false;
		}
	}
	protected synchronized int[] getPixelsUsingScanLines(int[] dest, int offset, int x, int y, int width, int height,int rowStride)
	{
		if (rowStride <= 0) rowStride = width; //NOT this.width
		if (dest == null || offset+(height*rowStride) > dest.length)
			dest = new int[offset+(height*rowStride)];
		int st = getImageScanLineType();
		if (x < 0 || x+width > this.width || y < 0 || y+height > this.height){
			Rect r = new Rect(x,y,width,height);
			offset = ImageTool.clipPixelArea(this,r,offset,rowStride);
			if (offset < 0) return dest;
			x = r.x; y = r.y; width = r.width; height = r.height;
		}
		try{
			if (st == SCAN_LINE_INT_ARRAY && width == this.width && x == 0){
				getImageScanLines(y,height,dest,offset,rowStride);
				return dest;
			}else{
				lineBuffer = ImageTool.getScanLineBuffer(this,1,lineBuffer);
				int lineLen = getImageScanLineLength();
				boolean fullWidth = (x == 0 && width == this.width); 
				if (!fullWidth){
					if (intBuffer == null || intBuffer.length < this.width)
						intBuffer = new int[this.width];
				}
				ImageDataInfo info = getInfo();
				for (int i = 0; i<height; i++){
					getImageScanLines(y,1,lineBuffer,0,lineLen); // Have complete native line.
					if (fullWidth)
						ImageTool.toARGB(info,lineBuffer,0,dest,offset,rowStride,1);
					else{
						ImageTool.toARGB(info,lineBuffer,0,intBuffer,0,this.width,1);
						System.arraycopy(intBuffer,x,dest,offset,width);
					}
					offset += rowStride;
					y++;
				}
				return dest;
			}
		}catch(IllegalStateException e){
			return null;
		}
	}
	/* (non-Javadoc)
	 * @see eve.fx.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
	 */
	/*
	public void setImageScanLines(int startLine, int numLines,
			Object sourceArray, int offset, int sourceScanLineLength)
			throws IllegalStateException {
		setPixels((int[])sourceArray,offset,0,startLine,width,numLines,sourceScanLineLength);
	}
	*/
	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
	 */
	/*
	public void getImageScanLines(int startLine, int numLines,
			Object destArray, int offset, int destScanLineLength) {
		getPixels((int[])destArray,offset,0,startLine,width,numLines,destScanLineLength);
	}
*/

	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageColorTable()
	 */
	public int[] getImageColorTable() {
		return null;
	}
	/**
	 * By  default this returns true.
	 */
	public boolean isReadableImage()
	{
		return true;
	}
	public void freeImage()
	{
		free();
	}
	/* This is done by an Object destroy func.
	protected void finalize()
	{
		free();
	}
	*/
	/**
	 * This is used when decoding images. 
	 * For certain interlaced images the pixels on a scan line are not
	 * available as a single sequence of pixels, but rather as pixels that
	 * are spaced at fixed distances apart on the scan line.<p>
	 * Also scan lines may be presented in a random sequence and multiple
	 * times.
	 * @param interestedArea the area specified in createImageFor() that
	 * the ImageMaker indicated it was interested in.
	 * @param scanLine the scan line index (starting at 0) of the full original image being set.
	 * @param pixels an array containing the scan line ARGB pixel values.
	 * @param offset the start of the pixel within the pixels array.
	 * @param destX the x location where the first pixel should be placed.
	 * @param destFrequency the distance between the pixels being provided. If this
	 * value is 1, then the pixels are actually right next to each other. A value of
	 * 2 means that every other pixel is being done.
	 * @param numPixels the number of pixels being set. 
	 * @param srcFrequency the distance between the pixels in the <b>pixels</b> array.
	 * This will usually be 1 but may be any other distance.
	 * @return true if the pixels were successfully set.
	 */
	public boolean setScanLinePixels(int scanLine,int[] pixels, int offset,int destX, int destFrequency, int numPixels, int srcFrequency)
	{
		if (destFrequency == 1  && srcFrequency == 1)
			return setPixels(pixels,offset,destX,scanLine,numPixels,1,width);
		int [] src = getPixels(null,0,0,scanLine,width,1,width); 
		if (src == null) return false;
		for (int x = destX, i = 0; i < numPixels; i++){
			src[x] = pixels[offset];
			x += destFrequency;
			offset += srcFrequency;
		}
		return setPixels(src,0,0,scanLine,width,1,width);
	}
	/* (non-Javadoc)
	 * @see eve.sys.ImageMaker#createImageFor(eve.sys.ImageDataInfo)
	 */
	public void createImageFor(ImageDataInfo imageInfo,Rect interestedArea) throws IllegalArgumentException {
	}
	/**
	 * This is called once all scan lines are complete.
	 */
	public void scanLinesComplete(){}
	
	/* (non-Javadoc)
	 * @see eve.sys.ImageMaker#getImageData()
	 */
	public ImageData getImageData() {
		return this;
	}
	public synchronized void free()
	{
		if (nativeImage != 0) NativeAccess.unref(nativeImage);
		nativeImage = 0;
	}
	public void draw(Graphics g, int x, int y, int width, int height, int options)
	{
		ImageTool.drawScaled(this,g,x,y,width,height,options);
	}
}
//####################################################
