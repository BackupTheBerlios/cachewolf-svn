/*
 * Created on Mar 25, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;


import eve.sys.Cache;
import eve.util.StringList;
import eve.util.SubString;
import eve.util.mString;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Metrics implements GraphicsConstants, AlignmentConstants{
	private static Rect buff = new Rect();
	private static Dimension dbuff = new Dimension();
	private static Point pbuff = new Point();
	private static String[] strings = new String[1];
	private static Rect anchored = new Rect();
	private static FormattedTextSpecs ftsBuff = new FormattedTextSpecs();
	
	/**
	 * Get the width of the given text in pixels - where the text can be a SubString, a CharArray
	 * a String or a char[]
	 * @param fm the FontMetrics to use. 
	 * @param obj the text to measure the width of. 
	 * @return the width of the text, or zero if it is not a valid object.
	 */
	/*
	public static int getTextWidth(FontMetrics fm,Object obj)
	{
		if (obj instanceof String) return fm.getTextWidth((String)obj);
		else if (obj instanceof SubString){
			SubString ss = (SubString)obj;
			return fm.getTextWidth(ss.data,ss.start,ss.length);
		}else if (obj instanceof CharArray){
			CharArray ca = (CharArray)obj;
			return fm.getTextWidth(ca.data,0,ca.length);
		}else if (obj instanceof char[]){
			char[] ca = (char[])obj;
			return fm.getTextWidth(ca,0,ca.length);
		}else
			return 0;
	}
	*/
	/*
//	===================================================================
	public static void drawText(Graphics g, FontMetrics fm,String [] lines,Rect where,int alignment)
//	===================================================================
	{
		drawText(g, fm,mVector.newVector(lines),where,alignment,CENTER);
	}
//	===================================================================
	public static void drawText(Graphics g, FontMetrics fm,Vector lines,Rect where,int alignment)
//	===================================================================
	{
		drawText(g, fm,lines,where,alignment,CENTER);
	}
	*/
	/**
	 * Get the size of the text if placed within an imaginary box.
	 * @param fm the FontMetrics to use to measure. 
	 * @param text a single line of text as a String, SubString, CharArray or char[]
	 * @param xGap the width at the left and right of the text.
	 * @param yGap the width at the top and bottom of the text.
	 * @param destination a destination rectangle.
	 * @return the destination Dimension.
	 */

//	===================================================================
	public static Dimension getSize(FontMetrics fm,String text,int xGap,int yGap,Dimension destination)
//	===================================================================
	{
		Dimension r = destination;
		if (r == null) r = Dimension.getCached(0,0);
		r.width = fm.getTextWidth(text)+xGap*2;
		r.height = fm.getHeight()+yGap*2;
		return r;
	}
	/**
	 * Get the size of the text if placed within an imaginary box.
	 * @param fm the FontMetrics to use to measure. 
	 * @param text a single line of text as a String, SubString, CharArray or char[]
	 * @param xGap the width at the left and right of the text.
	 * @param yGap the width at the top and bottom of the text.
	 * @param destination a destination rectangle.
	 * @return the destination Dimension.
	 */

//	===================================================================
	public static Dimension getSize(FontMetrics fm,SubString text,int xGap,int yGap,Dimension destination)
//	===================================================================
	{
		Dimension r = destination;
		if (r == null) r = Dimension.getCached(0,0);
		r.width = fm.getTextWidth(text.data,0,text.length)+xGap*2;
		r.height = fm.getHeight()+yGap*2;
		return r;
	}
//	===================================================================
	public static Dimension getSize(FontMetrics fm,String[] lines,int xGap,int yGap,Dimension destination)
//	===================================================================
	{
		return getSize(fm,(Object[])lines,xGap,yGap,destination);
	}
//	===================================================================
	public static Dimension getSize(FontMetrics fm,SubString[] lines,int xGap,int yGap,Dimension destination)
//	===================================================================
	{
		return getSize(fm,(Object[])lines,xGap,yGap,destination);
	}
//	===================================================================
	private static Dimension getSize(FontMetrics fm,Object[] lines,int xGap,int yGap,Dimension destination)
//	===================================================================
	{
		Dimension r = destination;
		if (r == null) r = Dimension.getCached(0,0);
		int w = 0, h = 0;
		int fh = fm.getHeight(), leading = fm.getLeading();
		for (int i = 0; i<lines.length; i++){
			SubString ss = null;
			String str = null;
			Object obj = lines[i];
			if (obj instanceof SubString) ss = (SubString)obj;
			else if (obj == null) str = "";
			else str = obj.toString();
			int wd = ss == null ? 
				fm.getTextWidth(str) : fm.getTextWidth(ss.data,ss.start,ss.length); 
			if (wd > w) w = wd;
			if (i != 0) h += leading;
			h += fh;
		}
		h += yGap*2;
		w += xGap*2;
		return r.set(w,h);
	}
	
//	===================================================================
	public static Dimension getAverageSize(FontMetrics fm,int rows,int columns,int xGap,int yGap,Dimension destination)
//	===================================================================
	{
		Dimension r = destination;
		if (r == null) r = Dimension.getCached(0,0);
		r.width = fm.getCharWidth('0')*columns+xGap*2;
		r.height = fm.getHeight()*rows;
		if (rows != 1) r.height += fm.getLeading()*(rows-1);
		r.height += yGap*2;
		return r;
	}
//	===================================================================
	public static Point centerText(FontMetrics fm,String st,int width,int height,Point destination)
//	===================================================================
	{
		synchronized(buff){
			Dimension r = getSize(fm, st,0,0,dbuff);
			Point p = destination;
			if (p == null) p = Point.getCached(0,0);
			return p.set((width-r.width)/2,(height-r.height)/2);
		}
	}
//	===================================================================
	public static Point centerText(FontMetrics fm,SubString st,int width,int height,Point destination)
//	===================================================================
	{
		synchronized(buff){
			Dimension r = getSize(fm, st,0,0,dbuff);
			Point p = destination;
			if (p == null) p = Point.getCached(0,0);
			return p.set((width-r.width)/2,(height-r.height)/2);
		}
	}
//	===================================================================
	public static void getSize(FontMetrics fm,String line,Dimension d)
//	===================================================================
	{
		getSize(fm,line,d,null);	
	}

//	===================================================================
	public static void getSize(FontMetrics fm,String line,Dimension d,FormattedTextSpecs fts)
//	===================================================================
	{
		synchronized(buff){
				strings[0] = line;
				getSize(fm,strings,0,1,d,fts);
		}
	}
	/*
	private static int getWidthAndPositions(Object line, FormattedTextSpecs fts, FontMetrics fm, boolean alwaysFormatted)
	{
		if (line instanceof String) return FormattedTextSpecs.getWidthAndPositions((String)line,fts,fm,false);
		else if (line instanceof CharArray){
			CharArray ca = (CharArray)
		}
	}
//	===================================================================
	public static void getSizeOfLines(FontMetrics fm,Object [] lines,int start,int end,Dimension d,FormattedTextSpecs fts)
//	===================================================================
	{
		int w = 0, h = 0;
		int fh = fm.getHeight(), leading = fm.getLeading();
		if (start < 0) start = 0;
		if (end > lines.length) end = lines.length;
		for (int i = start; i<end; i++){
			int wd = FormattedTextSpecs.getWidthAndPositions(lines[i],fts,fm,false);
			if (wd > w) w = wd;
			if (i != 0) h += leading;
			h += fh;
		}
		d.width = w;
		d.height = h;
	}
*/
//	===================================================================
	public static void getSize(FontMetrics fm,String[] lines,int start,int end,Dimension d,FormattedTextSpecs fts)
//	===================================================================
	{
		getSize(fm,(Object[]) lines,start,end,d,fts);
	}
//	===================================================================
	public static void getSize(FontMetrics fm,SubString[] lines,int start,int end,Dimension d,FormattedTextSpecs fts)
//	===================================================================
	{
		getSize(fm,(Object[]) lines,start,end,d,fts);
	}
//	===================================================================
	public static void getSize(FontMetrics fm,StringList lines,int start,int end,Dimension d,FormattedTextSpecs fts)
//	===================================================================
	{
		int w = 0, h = 0;
		int fh = fm.getHeight(), leading = fm.getLeading();
		int max = lines.size();
		if (start < 0) start = 0;
		if (end > max) end = max;
		SubString sub = (SubString)Cache.get(SubString.class);
		try{
			for (int i = start; i<end; i++){
				SubString got = lines.get(i,sub);
				int wd = 0;
				if (got != null)
					wd = FormattedTextSpecs.getWidthAndPositions(sub.data,sub.start,sub.length,fts,fm,false);
				if (wd > w) w = wd;
				if (i != 0) h += leading;
				h += fh;
			}
			d.width = w;
			d.height = h;
		}finally{
			Cache.put(sub);
		}
	}
	
//	===================================================================
	private static void getSize(FontMetrics fm,Object[] lines,int start,int end,Dimension d,FormattedTextSpecs fts)
//	===================================================================
	{
		int w = 0, h = 0;
		int fh = fm.getHeight(), leading = fm.getLeading();
		if (start < 0) start = 0;
		if (end > lines.length) end = lines.length;
		for (int i = start; i<end; i++){
			Object got = lines[i];
			int wd = 0;
			if (got instanceof String)
				wd = FormattedTextSpecs.getWidthAndPositions((String)got,fts,fm,false);
			else if (got instanceof SubString){
				SubString ss = (SubString)got;
				wd = FormattedTextSpecs.getWidthAndPositions(ss.data,ss.start,ss.length,fts,fm,false);
			}
			if (wd > w) w = wd;
			if (i != 0) h += leading;
			h += fh;
		}
		d.width = w;
		d.height = h;
		//System.out.println("Leading: "+leading+" h: "+h);
	}
	/**
	* Modify subArea so that it is anchored appropriately in largeArea.
	* anchor should be NORTH, SOUTH, etc.
	**/
//	===================================================================
	public static void anchor(Rect subArea,Rect largeArea,int anchor)
//	===================================================================
	{
		subArea.x = ((largeArea.width-subArea.width)/2);
		subArea.y = ((largeArea.height-subArea.height)/2);
		if ((anchor & WEST) != 0) subArea.x = 0;
		else if ((anchor & EAST) != 0) subArea.x = largeArea.width-subArea.width;
		if ((anchor & NORTH) != 0) subArea.y = 0;
		else if ((anchor & SOUTH) != 0) subArea.y = largeArea.height-subArea.height;
		subArea.x += largeArea.x;
		subArea.y += largeArea.y;
	}

//	===================================================================
	public static void drawImage(Graphics g, IImage image,int imageDrawOptions,Rect dest,int anchor)
//	===================================================================
	{
		if (image == null) return;
		synchronized(anchored){
			anchor(anchored.set(0,0,image.getWidth(),image.getHeight()),dest,anchor);
			image.draw(g,anchored.x,anchored.y,imageDrawOptions);
		}
	}
	
//	===================================================================
	public static void drawText(Graphics g,FontMetrics fm,Object [] lines,Rect where,int alignment,int anchor)
//	===================================================================
	{
		drawText(g,fm,lines,where,alignment,anchor,0,lines.length);
	}
//	===================================================================
	public static void drawText(Graphics g,FontMetrics fm,Object [] lines,Rect where,int alignment,int anchor,
	int startLine,int endLine)
//	===================================================================
	{
		drawText(g,fm,lines,where,alignment,anchor,startLine,endLine,null);
	}
/**
 * Find where the text would be given the full destination Rect. The destination
 * Rect itself is modified to be the rect that would hold the text exactly.
 * @param fm The font metrics.
 * @param lines the text.
 * @param destination the destination area to hold the text which will be modified
 * to be the area that would hold the text exactly.
 * @param anchor an anchor specifier (such as NORTH, SOUTH, etc).
 * @param fts optional FormattedTextSpecs.
 */
	public static void anchorTextIn(FontMetrics fm,Object[] lines, Rect destination, int anchor, FormattedTextSpecs fts)
	{
		synchronized(dbuff){
			getSize(fm,lines,0,lines.length,dbuff,fts);
			Rect tr = buff; tr.width = dbuff.width; tr.height = dbuff.height; tr.x = tr.y = 0;
			anchor(buff,destination,anchor);
			destination.set(buff);
		}		
	}
//	===================================================================
	public static void drawText(Graphics g,FontMetrics fm,Object [] lines,Rect where,int alignment,int anchor,
	int startLine,int endLine,FormattedTextSpecs fts)
//	===================================================================
	{
		synchronized(dbuff){
			getSize(fm,lines,startLine,endLine,dbuff,fts);
			if (buff == null) buff = new Rect();
			Rect tr = buff; tr.width = dbuff.width; tr.height = dbuff.height; tr.x = tr.y = 0;
			anchor(tr,where,anchor);
			drawTextIn(g,fm,lines,tr,alignment,startLine,endLine,fts);
		}
	}
//	-------------------------------------------------------------------
	protected static void drawTextIn(Graphics g,FontMetrics fm,Object [] lines,Rect where,int alignment,int start,int end,FormattedTextSpecs fts)
//	-------------------------------------------------------------------
	{
		synchronized(dbuff){
			if (fts == null) fts = ftsBuff;
			fts.metrics = fm;
			if (start >= lines.length || end <= start) return;
			if (end > lines.length) end = lines.length;
			int num = end-start;
			int h = fm.getHeight(), leading = fm.getLeading();
			int y = where.y;
			g.setFont(fm.getFont());
			//if (lines.length == 9) System.out.println("\n");
			//for (int i = 0; i<start; i++) y += h+leading;
			//System.out.println("+DrawTextIn");
			for (int i = 0; i<num; i++){
				SubString ss = null;
				String str = null;
				Object obj = lines[i+start];
				if (obj == null) continue;
				if (obj instanceof SubString) ss = (SubString)obj;
				else str = mString.toString(obj);
				if (i != 0) y += leading;
				int w =
					ss == null ?
							FormattedTextSpecs.getWidthAndPositions(str,fts,fm,false):
							FormattedTextSpecs.getWidthAndPositions(ss.data,ss.start,ss.length,fts,fm,false);
				int xp = where.x;
				if (alignment == Right) {
					//l = where.toString();
					xp += where.width-w;
					//eve.ui.Control.np.x = 0;
				}
				else if (alignment == CENTER) xp += (where.width-w)/2;
				if (ss == null){
					if (fts.isFormatted) g.drawFormattedText(str,xp,y,fts);
					else g.drawText(str,xp,y);
				}else{
					//System.out.println("-"+ss);
					if (fts.isFormatted) g.drawFormattedText(ss.data,ss.start,ss.length,xp,y,fts);
					else g.drawText(ss.data,ss.start,ss.length,xp,y);
				}
				//if (lines.length == 3 || true) System.out.println(l+" @ "+xp+","+y);
				y += h;
			}
		}
	}

	/** A Metric value for getFontForMetric(). **/
	public final static int METRIC_HEIGHT = 1;
	/** A Metric value for getFontForMetric(). **/
	public final static int METRIC_ASCENT = 2;
	/** A Metric value for getFontForMetric(). **/
	public final static int METRIC_DESCENT = 3;
	/** A Metric value for getFontForMetric(). **/
	public final static int METRIC_WIDTH_OF_TEXT = 4;
	/** A Metric value for getFontForMetric(). **/
	public final static int METRIC_HEIGHT_OF_TEXT = 5;

	private final static int METRIC_MASK = 0x7fffffff;
	
	public final static int METRIC_OPTION_MAKE_SMALLER_ONLY = 0x80000000;
//	private static Dimension dim;
//	private static String[] strings;
	/**
	 * Get the value of a particular Metric for a FontMetrics for a set of data.
	 * @param whichMetric one of the METRIC_XXX values
	 * @param data This is only needed for METRIC_WIDTH_OF_TEXT or METRIC_HEIGHT_OF_TEXT. 
	 * The data must be a String, a SubString or an array of Strings (which is assumed will be placed one above the other)
	 * or a Character (for a single character).
	 * @param fm The FontMetrics to use.
	 * @return the value of the specified Metric.
	 */
//	===================================================================
	public static int getMetricValue(int whichMetric, Object data, FontMetrics fm)
//	===================================================================
	{
		whichMetric &= METRIC_MASK;
		switch(whichMetric){
			case METRIC_HEIGHT: return fm.getHeight();
			case METRIC_ASCENT: return fm.getAscent();
			case METRIC_DESCENT: return fm.getDescent();
			case METRIC_WIDTH_OF_TEXT:
			case METRIC_HEIGHT_OF_TEXT:
				{
					synchronized(buff){
						if (data instanceof String[] || data instanceof SubString[])
							getSize(fm,(Object[])data,0,((Object[])data).length,dbuff,null);
						else if (data instanceof StringList){
							return getMetricValue(whichMetric,((StringList)data).toBestText(),fm);
						}else
							getSize(fm,data.toString(),0,0,dbuff);
						return whichMetric == METRIC_WIDTH_OF_TEXT ? dbuff.width : dbuff.height;
					}
				}
			default:
				throw new IllegalArgumentException();
		}
	}
	/**
	 * Retrieve the Font which is of the correct size, such that its metric is equal to, 
	 * or just smaller than the specified metric in pixels, or for which the metrics of
	 * the supplied data is equal to or just smaller than the specified metric in pixels.
	 * @param valueOfMetricInPixels The value of the metrics in Pixels.
	 * @param whichMetric one of the METRIC_XXX values
	 * @param data This is only needed for METRIC_WIDTH_OF_TEXT or METRIC_HEIGHT_OF_TEXT. 
	 * The data must be a String, an array of Strings (which is assumed will be placed one above the other)
	 * or a Character (for a single character).
	 * @param baseFont The FontMetrics representing the base font to use. The returned Font will have the
	 * same name and style as the baseFont.
	 * @return the Font of the correct size so that it fits within the specified metric.
	 */
//	===================================================================
	public static Font getFontForMetric(int valueOfMetricInPixels,int whichMetric,Object data,FontMetrics baseFont)
//	===================================================================
	{
		try{
		int num = valueOfMetricInPixels;
		int start = 20;
		FontMetrics fm = baseFont;
		Font f = baseFont.getFont();
		boolean smallerOnly = (whichMetric & METRIC_OPTION_MAKE_SMALLER_ONLY) != 0;
		if (!smallerOnly){
			f = f.changeNameAndSize(null,start);
			fm = baseFont.getNewFor(f);
		}
		//
		int sz = getMetricValue(whichMetric, data, fm);
		//
		if (smallerOnly && sz <= num) return f;
		//
		// 
		start = (start*num)/sz;
		f = f.changeNameAndSize(null,start);
		fm = fm.getNewFor(f);
		sz = getMetricValue(whichMetric, data, fm);
		if (sz == num) return f;
		int ul = -1;
		int ll = 1;
		int fs = start;
		boolean db = false;//true;
		int i = 0;
		int lastSize = -1;
		boolean firstTime = true;
		while(true){
			if (db && ++i > 30) throw new RuntimeException("Had to give up!");
			if (ul-ll <= 1 && ul != -1) {
				return f;
			}
			if (ul == -1) fs *= 2;
			else fs = ((ul-ll)/2)+ll;
			//
			f = f.changeNameAndSize(null,fs);
			fm = fm.getNewFor(f);
			sz = getMetricValue(whichMetric, data, fm);
			if (!firstTime && ul == -1 && lastSize >= sz){
				if (false) throw new RuntimeException("Font is not scaling!");
				return f; // The Font is not scaling.
			}
			firstTime = false;
			lastSize = sz;
			//
			if (db) System.out.println("ul:"+ul+" ll:"+ll+" fs:"+fs+" sz:"+sz+" num:"+num);
			if (sz == num ) return f;
			else if (sz > num) ul = fs;
			else if (sz < num) ll = fs;
		}
		}finally{
			//System.out.println("Leaving gffm");
		}
	}

	/**
	 * Find the biggest Font such that the data provided fits within the size provided.
	 * @param size The size in pixels.
	 * @param data This can be a Character or a String or an Array of Strings.
	 * @param baseFont The FontMetrics representing the base font to use. The returned Font will have the
	 * same name and style as the baseFont.
	 * @return the biggest Font such that the data provided fits within the size provided.
	 */
//	===================================================================
	public static Font fitInto(Dimension size, Object data, FontMetrics baseFont)
//	===================================================================
	{
		return fitInto(size.width,size.height,data,baseFont);
	}
	/**
	 * Find the biggest Font such that the data provided fits within the size provided.
	 * @param width The width in pixels.
	 * @param height The height in pixels.
	 * @param data This can be a Character or a String or an Array of Strings.
	 * @param baseFont The FontMetrics representing the base font to use. The returned Font will have the
	 * same name and style as the baseFont.
	 * @return the biggest Font such that the data provided fits within the size provided.
	 */
//	===================================================================
	public static Font fitInto(int width, int height, Object data, FontMetrics baseFont)
//	===================================================================
	{
		Font fw = getFontForMetric(width,METRIC_WIDTH_OF_TEXT,data,baseFont);
		Font fh = getFontForMetric(height,METRIC_HEIGHT_OF_TEXT,data,baseFont);
		return fw.getSize() < fh.getSize() ? fw : fh;
	}
	public static FontMetrics shrinkInto(int width, int height, Object data, FontMetrics baseFont, FontMetrics biggestSoFar)
	{
		Font f = biggestSoFar == null ? null : biggestSoFar.getFont();
		int opt = biggestSoFar == null ? 0 : METRIC_OPTION_MAKE_SMALLER_ONLY;
		if (biggestSoFar == null) biggestSoFar = baseFont;
		Font nf = null;
		if (true){
			nf = getFontForMetric(width,opt|METRIC_WIDTH_OF_TEXT,data,biggestSoFar);
			if (nf != f) biggestSoFar = baseFont.getNewFor(nf);
			f = nf;
		}
		opt = METRIC_OPTION_MAKE_SMALLER_ONLY;
		if (true){
			nf = getFontForMetric(height,opt|METRIC_HEIGHT_OF_TEXT,data,biggestSoFar);
			if (nf != f) biggestSoFar = baseFont.getNewFor(nf);
			f = nf;
		}
		return biggestSoFar;
	}
	/**
	 * Find the biggest Font such that its height is less than or equal to the requiredHeight.
	 * @param requiredHeight The required height for the Font.
	 * @param baseFont The FontMetrics representing the base font to use. The returned Font will have the
	 * same name and style as the baseFont.
	 * @return the biggest Font such that its height is less than or equal to the requiredHeight.
	 */
//	===================================================================
	public static Font getFontForHeight(int requiredHeight, FontMetrics baseFont)
//	===================================================================
	{
		return getFontForMetric(requiredHeight,METRIC_HEIGHT,null,baseFont);
	}
	
}
//####################################################
