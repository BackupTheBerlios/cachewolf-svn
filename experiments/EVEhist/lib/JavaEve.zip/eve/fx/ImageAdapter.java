/*
 * Created on Dec 7, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.ImageData;

/**
 * This class is used to provide an IImage interface to an ImageData object.
 * It does not change the type of the ImageData image or its scan line type.
 */
//####################################################
public class ImageAdapter extends ImageObject {
	
	protected ImageData imageData;
	private static int[] drawBuffer;
	
	public static IImage toIImage(ImageData id,ImageAdapter reuseWrapper)
	{
		if (id instanceof IImage) return (IImage)id;
		else {
			if (reuseWrapper == null) reuseWrapper = new ImageAdapter();
			reuseWrapper.set(id);
			return reuseWrapper;
		}
	}
	
	/**
	 * You must call the set() method after calling this. 
	 */
	public ImageAdapter()
	{
		
	}
	public ImageAdapter(ImageData id)
	{
		set(id);
	}
	public void set(ImageData newImageData)
	{
		imageData = newImageData;
		width = newImageData.getImageWidth();
		height = newImageData.getImageHeight();
	}
	/* (non-Javadoc)
	 * @see eve.fx.IImage#draw(eve.fx.Graphics, int, int, int)
	 */
	public synchronized static void drawRGB(ImageData image,Graphics g, int x, int y, boolean useAlpha) 
	{
		int max = 10*1024;
		int width = image.getImageWidth(),height = image.getImageHeight();
		int numLines = max/width;
		if (numLines > height) numLines = height;
		if (numLines < 1) numLines = 1;
		if (drawBuffer == null || drawBuffer.length < numLines*width)
			drawBuffer = new int[numLines*width];
		for (int yy = 0; yy < height; yy += numLines){
			if (yy+numLines > height) numLines = height-yy;
			image.getPixels(drawBuffer,0,0,yy,width,numLines,width);
			g.drawRGB(drawBuffer,0,x,y,width,numLines,width,useAlpha);
			y += numLines;
		}
	}
	
	/* (non-Javadoc)
	 * @see eve.fx.IImage#draw(eve.fx.Graphics, int, int, int)
	 */
	public void draw(Graphics g, int x, int y, int options) {
		drawRGB(this,g,x,y,usesAlpha());
	}

	/**
	 * This frees resources associated with this ImageAdapter only, not the
	 * original ImageData.
	 * @see eve.fx.IImage#free()
	 */
	public void free() {
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#getPixels(int[], int, int, int, int, int, int)
	 */
	public int[] getPixels(int[] dest, int offset, int x, int y, int width,
			int height, int rowStride) {
		return imageData.getPixels(dest,offset,x,y,width,height,rowStride); 
		//getPixelsUsingScanLines(dest,offset,x,y,width,height,rowStride);
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#usesAlpha()
	 */
	public boolean usesAlpha() {
		return imageData.getImageType() == TYPE_ARGB;
	}
	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageType()
	 */
	public int getImageType() {
		return imageData.getImageType();
	}
	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageScanLineType()
	 */
	public int getImageScanLineType() {
		return imageData.getImageScanLineType();
	}

	/* (non-Javadoc)
	 * @see eve.fx.ImageData#getImageScanLineLength()
	 */
	public int getImageScanLineLength() {
		return imageData.getImageScanLineLength();
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void getImageScanLines(int startLine, int numLines,
			Object destArray, int offset, int destScanLineLength)
			throws IllegalStateException {
		imageData.getImageScanLines(startLine,numLines,destArray,offset,destScanLineLength);

	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void setImageScanLines(int startLine, int numLines,
			Object sourceArray, int offset, int sourceScanLineLength)
			throws IllegalStateException {
		imageData.setImageScanLines(startLine,numLines,sourceArray,offset,sourceScanLineLength);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#isWriteableImage()
	 */
	public boolean isWriteableImage() {
		return imageData.isWriteableImage();
	}
	public boolean isReadableImage() {
		return imageData.isReadableImage();
	}
	public int[] getImageColorTable()
	{
		return imageData.getImageColorTable();
	}
	/* (non-Javadoc)
	 * @see eve.fx.IImage#setPixels(int[], int, int, int, int, int, int)
	 */
	public boolean setPixels(int[] src, int offset, int x, int y, int width, int height, int rowStride) {
		return imageData.setPixels(src,offset,x,y,width,height,rowStride); 
		//setPixelsUsingScanLines(src,offset,x,y,width,height,rowStride);
	}

}

//####################################################
