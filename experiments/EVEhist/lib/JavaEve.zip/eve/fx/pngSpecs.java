package eve.fx;

//##################################################################
class pngSpecs{
//##################################################################

int width; //Must be first.
int height; //Must be second.
int type; //Must be third.
int bitDepth; //Must be fourth.
int compression; //Must be fifth.
int filter; //Must be sixth.
int interlace; //Must be 7th.
byte [] paletteBytes; //Must be 8th.
byte [] transparencyBytes; //Must be 9th.
int transparentColor; //Must be 10th.
int transparentColorLow; //Must be 11th.
boolean isBMPFile; //Must be 12th.
Rect sourceArea;  //Must be 13th.
int pause;
int x;
int y;

pngSpecs(ImageDecoder codec)
{
	width = codec.width;
	height = codec.height;
	type = codec.type;
	bitDepth = codec.bitDepth;
	compression= codec.compression;
	filter= codec.filter;
	interlace= codec.interlace;
	paletteBytes= codec.paletteBytes;
	transparencyBytes= codec.transparencyBytes;
	transparentColor= codec.transparentColor;
	transparentColorLow= codec.transparentColorLow;
	isBMPFile = codec.isBMPFile;
	sourceArea = codec.sourceArea;
}
//##################################################################
}
//##################################################################

