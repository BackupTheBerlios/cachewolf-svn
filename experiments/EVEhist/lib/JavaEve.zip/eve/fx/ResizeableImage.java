/*
 * Created on May 4, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface ResizeableImage extends IImage {

	public void draw(Graphics g, int x, int y, int width, int height, int options);
	
}
//####################################################
