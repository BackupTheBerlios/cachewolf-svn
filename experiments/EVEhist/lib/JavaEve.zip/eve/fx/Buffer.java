package eve.fx;

import eve.sys.Device;

/**
* A Buffer is a type of Image used specifically for fast and frequent drawing of
* Images. 
**/
//##################################################################
public class Buffer extends Image{
//##################################################################

static boolean useNativeClear = true;

//===================================================================
public Buffer(int width, int height, int options)
//===================================================================
{
	super(width,height,options);
}

//===================================================================
public Graphics clear(int x,int y,int width,int height,Color c)
//===================================================================
{
	if (useNativeClear){
		try{
			useNativeClear = nativeClear(x,y,width,height,c.toInt());
			if (useNativeClear){
				return new Graphics(this);
			}
		}catch(Throwable t){
			Device.checkNoNativeMethod(t);
			useNativeClear = false;
		}
	}
	Graphics g = new Graphics(this);
	g.setColor(c);
	g.fillRect(x,y,width,height);
	return g;
}

//===================================================================
public native boolean nativeClear(int x,int y,int width,int height,int value);
//===================================================================


//##################################################################
}
//##################################################################

