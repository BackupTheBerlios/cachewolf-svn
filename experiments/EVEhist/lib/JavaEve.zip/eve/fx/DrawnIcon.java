package eve.fx;

import eve.sys.Cache;

/**
* A DrawnIcon represents a number of Images which are "drawn" using Graphics primitives
* rather than from a Image.
**/
//##################################################################
public class DrawnIcon extends Drawing{
//##################################################################
/**
* This is a 'X' cross.
**/
public static final int CROSS = 1;
/**
* This is a tick mark.
**/
public static final int TICK = 2;

Pen pen;
Brush brush;
int type;


/**
 * Create a new DrawnIcon
 * @param type either CROSS or TICK.
 * @param width The width of the icon.
 * @param height The height of the icon.
 * @param c The color of the icon.
 */
//===================================================================
public DrawnIcon(int type,int width,int height,Color c)
//===================================================================
{
	this(type,width,height,new Pen(c,Pen.SOLID|Pen.CAP_ROUND|Pen.JOIN_ROUND,width > 10 ? 4 : 2),null);	
}
/**
 * Create a new DrawnIcon
 * @param type either CROSS or TICK.
 * @param width The width of the icon.
 * @param height The height of the icon.
 * @param p The Pen to use for drawing.
 * @param b The Brush to use for drawing.
 */
//===================================================================
public DrawnIcon(int type,int width,int height,Pen p,Brush b)
//===================================================================
{
	setRect(0,0,width,height);
	this.type = type;
	pen = p;
	brush = b;
}

//==============================================================
public void	doDraw(Graphics g,int options)
//==============================================================
{
	Color oldC = g.getColor(Color.getCached());
	Color 	opc = pen != null ? Color.getCached(pen.color) : null, 
			obc = brush != null ? Color.getCached(brush.color) : null;
	if ((options & DISABLED) != 0){
		if (pen != null) pen.set(Color.DarkGray); 
		if (brush != null) brush.set(Color.DarkGray);
	}
	Pen oldPen = g.setPen(pen,Pen.getCached());
	Brush oldBrush = g.setBrush(brush,Brush.getCached());
	Rect r = Rect.getCached(location);
	try{
	int xt = pen.thickness-1;
	r.x += xt; r.width -= xt*2;
	r.y += xt; r.height -= xt*2;
	switch(type){
		case TICK:
			g.drawLine(r.x+r.width-1,r.y,r.x,r.y+r.height-1);
			g.drawLine(r.x,r.y+r.height-1,r.x,r.y+(r.height)/3);
			break;
		case CROSS:
			g.drawLine(r.x+r.width-1,r.y,r.x,r.y+r.height-1);
			g.drawLine(r.x,r.y,r.x+r.width-1,r.y+r.height-1);
			break;
	}	
	if (pen != null) pen.set(opc);
	if (brush != null) brush.set(obc);
	g.set(oldBrush);
	g.set(oldPen);
	g.setColor(oldC);
	}finally{
		Cache.put(r);
		oldPen.cache();
		oldBrush.cache();
		oldC.cache();
		if (opc != null) opc.cache();
		if (obc != null) obc.cache();
	}
}
//==============================================================
public void	draw(Graphics g,int dx, int dy, int dw, int dh,int options)
//==============================================================
{
	Color oldC = g.getColor(Color.getCached());
	Color 	opc = pen != null ? Color.getCached(pen.color) : null, 
			obc = brush != null ? Color.getCached(brush.color) : null;
	if ((options & DISABLED) != 0){
		if (pen != null) pen.set(Color.DarkGray); 
		if (brush != null) brush.set(Color.DarkGray);
	}
	Pen pp = Pen.getCached(pen.color,pen.style|pen.CAP_ROUND,(pen.thickness*dw)/location.width);
	Pen oldPen = g.setPen(pp,Pen.getCached());
	Brush oldBrush = g.setBrush(brush,Brush.getCached());
	Rect r = Rect.getCached(dx,dy,dw,dh);
	try{
	int xt = pp.thickness/2;
	r.x += xt; r.width -= xt*2;
	r.y += xt; r.height -= xt*2;
	switch(type){
		case TICK:
			g.drawLine(r.x+r.width-1,r.y,r.x,r.y+r.height-1);
			g.drawLine(r.x,r.y+r.height-1,r.x,r.y+(r.height)/3);
			break;
		case CROSS:
			g.drawLine(r.x+r.width-1,r.y,r.x,r.y+r.height-1);
			g.drawLine(r.x,r.y,r.x+r.width-1,r.y+r.height-1);
			break;
	}	
	if (pen != null) pen.set(opc);
	if (brush != null) brush.set(obc);
	g.set(oldBrush);
	g.set(oldPen);
	g.setColor(oldC);
	}finally{
		Cache.put(r);
		pp.cache();
		oldPen.cache();
		oldBrush.cache();
		oldC.cache();
		if (opc != null) opc.cache();
		if (obc != null) obc.cache();
	}
}
public boolean usesAlpha()
{
	return true;
}
//##################################################################
}
//##################################################################

