package eve.fx;

import eve.sys.ImageData;
import eve.sys.ImageDataInfo;
/*
 */
final class imageScaler implements ImageMaker{
// Don't move these next 5 fields.
	ImageMaker dest;
	int[] dimensions;
	int[] mainPixels;
	int[] auxillaryPixels;
	int options;
// ------------------------------------
	int[] buffers;
	int newWidth, newHeight;
	int srcWidth, srcHeight;
	
	imageScaler(ImageMaker dest, int srcWidth, int srcHeight, int destWidth, int destHeight, int imageDataCreateOptions)
	{
		this.dest = dest;
		dimensions = new int[]{srcWidth,srcHeight,destWidth,destHeight};
		this.options = imageDataCreateOptions;
		int need = destWidth*destHeight;
		mainPixels = new int[need];
		try{
			int extra = 2;
			if ((options & ImageData.CREATE_OPTION_IGNORE_ALPHA) == 0)
				extra = 3;
			auxillaryPixels = new int[need*extra];
		}catch(OutOfMemoryError e){
			
		}
		this.newWidth = destWidth;
		this.newHeight = destHeight;
		this.srcWidth = srcWidth;
		this.srcHeight = srcHeight;
	}
	
	/**
	 * This does nothing - it assumes the destination maker is already
	 * setup.
	 */
	public void createImageFor(ImageDataInfo imageInfo, Rect interestedArea)
			throws IllegalArgumentException {
	}

	public ImageData getImageData() {
		return dest.getImageData();
	}

	public void scanLinesComplete() {
		if (auxillaryPixels == null) return;
		if (buffers == null) return;
		boolean ignoreAlpha = (options & ImageData.CREATE_OPTION_IGNORE_ALPHA) != 0;
		int total = newWidth*newHeight;
		int hz = srcWidth+srcHeight;
		int vt = hz+newWidth;
		int []rp = mainPixels; int ro = 0;
		int []gp = auxillaryPixels; int go = 0;
		int []bp = auxillaryPixels; int bo = total;
		int []ap = auxillaryPixels; int ao = total*2;
		int off = 0;
		for (int y = 0; y<newHeight; y++){
			int vs = buffers[vt+y];
			for (int x = 0; x<newWidth; x++){
				int scale = buffers[hz+x]*vs;
				int r = rp[ro+off]/scale;
				int g = gp[go+off]/scale;
				int b = bp[bo+off]/scale;
				int a = 255;
				if (!ignoreAlpha) a = ap[ao+off]/scale;
				rp[ro+off] = (a << 24) | (r << 16) | (g << 8) | b;
				off++;
			}
			dest.setScanLinePixels(y, rp, ro+off-newWidth, 0, 1, newWidth, 1);
		}
	}
	static void doLines(int [] dest, int destOffset, int fullWidth, int newWidth, int [] scales, int scalesOffset)
	{
		if (newWidth < fullWidth){
			int d = fullWidth/newWidth;
			int q = fullWidth%newWidth;
			//
			int qq = 0;
			int ss = 0;
			for (int i = 0; i<newWidth; i++){
				scales[scalesOffset+i] = 0;
				int f = d;
				qq += q;
				if (qq >= newWidth){
					f++;
					qq -= newWidth;
				}
				int p = 65536|(i&0xffff);
				for (int ff = 0; ff<f; ff++){
					dest[destOffset++] = p;
					scales[scalesOffset+i]++;
				}
			}
		}else{
			int d = newWidth/fullWidth;
			int q = newWidth%fullWidth;
			//
			int qq = 0;
			int ss = 0;
			int dd = 0;
			for (int i = 0; i<fullWidth; i++){
				int f = d;
				qq += q;
				if (qq >= fullWidth){
					f++;
					qq -= fullWidth;
				}
				dest[destOffset+i] = (f << 16)|dd;
				for (int ff = 0; ff<f; ff++){
					scales[scalesOffset+dd+ff] = 1;
				}
				dd += f;
			}
		}
	}

	public boolean setScanLinePixels(int scanLine, int[] pixels, int offset,
			int destX, int destFrequency, int numPixels, int srcFrequency) {
		int total = newWidth*newHeight;
		int hz, vt, hs, vs;
		if (buffers == null){
			buffers = new int[srcWidth+srcHeight+newWidth+newHeight];
			hz = 0;
			vt = hz+srcWidth;
			doLines(buffers,hz,srcWidth,newWidth,buffers,vt+srcHeight);
			doLines(buffers,vt,srcHeight,newHeight,buffers,vt+srcHeight+newWidth);
		}
		hz = 0;
		vt = hz+srcWidth;
		hs = hz+srcWidth+srcHeight;
		vs = hs+newWidth;
		int []rp = mainPixels; int ro = 0;
		int []gp = auxillaryPixels; int go = 0;
		int []bp = auxillaryPixels; int bo = total;
		int []ap = auxillaryPixels; int ao = total*2;
		boolean ignoreAlpha = (options & ImageData.CREATE_OPTION_IGNORE_ALPHA) != 0;
		//
		//
		int yf = buffers[vt+scanLine];
		int ny = (yf >> 16) & 0xffff; // How many lines does this line contribute to.
		int fy = yf & 0xffff; // What is the first dest line this contributes to.
		for (int yy = fy; yy < fy+ny; yy++){
			int off = newWidth*yy;
			int sp = offset;
			int yscale = buffers[vs+yy];
			for (int i = 0, x = destX, sx = 0; i<numPixels; i++, x += destFrequency){
				int v = pixels[sp]; sp += srcFrequency;
				int a = (v >> 24) & 0xff;
				int r = (v >> 16) & 0xff;
				int g = (v >> 8) & 0xff;
				int b = (v) & 0xff;
				int xf = buffers[hz+x];
				int nx = (xf >> 16) & 0xffff;
				int fx = xf & 0xffff;
				int oo = off+fx;
				for (int xx = fx; xx < fx+nx; xx++){
					if (auxillaryPixels != null){
						rp[ro+oo] += r;
						gp[go+oo] += g;
						bp[bo+oo] += b;
						if (!ignoreAlpha) ap[ao+oo] += a;
					}else{
						int scale = yscale*buffers[hs+xx];
						int full = rp[oo];
						r = (r/scale)+((full >> 16) & 0xff);
						g = (g/scale)+((full >> 8) & 0xff);
						b = (b/scale)+((full) & 0xff);
						a = ignoreAlpha ? 255 : (a/scale)+((full >> 24) & 0xff);
						rp[ro+oo] = (a << 24)|(r << 16)|(g << 8)|(b);
					}
					oo++;
				}
			}
		}
		
		return true;
	}

}
