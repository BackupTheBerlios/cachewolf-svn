package eve.fx;

public interface IPath {
	/**
	 * Start a new sub path at x and y.
	 */
	public void startPath(double x, double y);
	/**
	 * Add a straight line segment to the path.
	 */
	public void addToPath(double x, double y);
	/**
	 * Add a Cubic Bezier curve segment from the current point to (x3,y3) using
	 * (x1, y1) and (x2, y2) as the control points.
	 */
	public void addToPath(double x1, double y1, double x2, double y2, double x3, double y3);
	/**
	 * Close the path by making a straight line segment back to the original point.
	 */
	public void closePath();

}
