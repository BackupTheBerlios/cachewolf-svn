/*
 * Created on May 9, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.ImageData;



/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Drawing extends ImageObject implements ImageData{

//public Image image;
public int properties;
protected IImage image;

public boolean isWriteableImage()
{
	return false;
}
/**
 * If this is true then a call to free() will also free the image.
 */
public boolean freeImageWithDrawing;
/**
* A property bit - The image is being prepared.
*/
static public final int IsPreparing = 0x1;
/**
* A property bit - The image is fully prepared.
*/
static public final int IsPrepared = 0x2;
/**
* A property bit - The image is invisible
*/
static public final int IsInvisible = 0x4;
/**
* A property bit - The image has a border.
*/
static public final int HasBorder = 0x8;
/**
* A property bit - The image is empty.
*/
static public final int IsEmpty = 0x10;
/**
* A property bit - The image is always on top.
*/
static public final int AlwaysOnTop = 0x20;
/**
* A property bit - Used by MosaicPanel
*/
static public final int InUse = 0x40;
/**
* A property bit - The image has no hot area.
*/
static public final int IsNotHot = 0x100;
/**
* A property bit - The image is moveable (draggable).
*/
static public final int IsMoveable = 0x200;
/**
* A property bit - The image is locked - not used yet.
*/
static public final int IsLocked = 0x400;
/**
* A property bit - Another image must be completely within this image to be considered "within"
* this image.
*/
static public final int CompletelyIn = 0x800;
/**
* A property bit - The image has moved, this is normally set and cleared automatically.
*/
static public final int HasMoved = 0x1000;
/**
* A property bit - The image has changed, this is normally set and cleared automatically.
*/
static public final int HasChanged = 0x2000;
/**
* A property bit - The image is not still, it is animated.
*/
static public final int IsNotStill = 0x4000;
/**
* A property bit - The image stays on the same spot on the screen, even if the mosaic scrolls.
*/
static public final int RelativeToOrigin = 0x8000;
/**
* A property bit - In order for a "drag over" event to be recognized, the mouse pointer must be over the image.
* That is to say, if you are dragging another image over this one, the mouse pointer itself must be over this image
* for it to be considered dragged over.
*/
static public final int MouseMustBeOver = 0x10000;
/**
* A property bit - When refreshing this image, the associated Mosaic will scroll itself to keep the image fully visible (if possible).
* In order for this to work the virtualSize of the Mosaic must be set.
*/
static public final int KeepOnScreen = 0x20000;
/**
* A property bit - indicates that this image will be animated and so the ImageRefresher
* should be set if it is being placed into a Control.
*/
static public final int IsAnimated = 0x40000;

//==================================================================
public Rect location = new Rect(0,0,0,0);
public Rect lastDrawn = new Rect(0,0,-1,-1);

/**
* Get the X,Y location of the Drawing.
* @param dest An optional destination Point object.
* @return The dest object or a new Point if dest is null.
**/
//===================================================================
public Point getLocation(Point dest)
//===================================================================
{
	dest = Point.unNull(dest);
	dest.x = location.x;
	dest.y = location.y;
	return dest;
}
/**
* Get the width and height of the Drawing.
* @param dest An optional destination Dimension object.
* @return The dest object or a new Dimension if dest is null.
*/
//===================================================================
public Dimension getSize(Dimension dest)
//===================================================================
{
	dest = Dimension.unNull(dest);
	dest.width = location.width;
	dest.height = location.height;
	return dest;
}

//public int getHeight() {return location.height;}
//public int getWidth() {return location.width;}
/* (non-Javadoc)
 * @see eve.fx.IImage#getBackground()
 */
public Color getBackground() {
	if (image != null) return image.getBackground();
	return null;
}
/* (non-Javadoc)
 * @see eve.fx.IImage#free()
 */
public void free() {
	if (image != null && freeImageWithDrawing)
		image.free();
}
protected Color getUnusedColor()
{
	return null;
}
private static PixelBuffer gpb;
/* (non-Javadoc)
 * @see eve.fx.IImage#getPixels(int[], int, int, int, int, int, int)
 */
public int[] getPixels(int[] dest, int offset, int x, int y, int width, int height, int rowStride) {
	if (image != null) return image.getPixels(dest,offset,x,y,width,height,rowStride);
	else {
		if (gpb == null) gpb = new PixelBuffer(width,height);
		synchronized(gpb){
			gpb.resizeTo(width,height,null);
			gpb.setTo(this,x,y,getUnusedColor());
			return gpb.getPixels(dest,offset,0,0,width,height,rowStride);
		}
	}
}
/* (non-Javadoc)
 * @see eve.fx.IImage#usesAlpha()
 */
public boolean usesAlpha() {
	if (image != null) return image.usesAlpha();
	else return false;
}

/**
* Draws the border of the image.
* If the image has a border it will be drawn.
*/
public synchronized void
//==============================================================
	drawBorder(Graphics g,int x,int y,int options)
//==============================================================
{
	Graphics clipped = g;//.create();
	//clipped.clipRect(x,y,dim.width,dim.height);
	if ((properties & HasBorder) != 0) {
		clipped.setColor(0,0,0);
		clipped.setDrawOp(Graphics.DRAW_XOR);
		clipped.drawLine(x,y,x+location.width-1,y);
		clipped.drawLine(x,y,x,y+location.height-1);
		clipped.drawLine(x+location.width-1,y,x+location.width-1,y+location.height-1);
		clipped.drawLine(x,y+location.height-1,x+location.width-1,y+location.height-1);
		clipped.setDrawOp(Graphics.DRAW_OVER);
		//clipped.drawRect(x,y,dim.width-1,dim.height-1);
	}
	//clipped.dispose();
}
/**
* Bottom level draw. Override to change how the image is drawn. Will still
* allow borders to be drawn and allow invisible to have effect.
*/
public void
//==============================================================
	doDraw(Graphics g,int options)
//==============================================================
{
	Image img = null;
	if (!(image instanceof Image)){
		image.draw(g,0,0,options);
		return;
	}
	//
	// image is an Image;
	// 
	if ((options & DISABLED) != 0){
		img = new Image((Image)image,Image.TYPE_RGB); 
		//TODO make gray.
		//img.makeGray();//transparentColor);
		g.drawImage(img,0,0);
		img.free();
		return;
	}else
		image.draw(g,0,0,options);
}
/**
* Draws itself on the graphic g at a specfied co-ordinate.
* If the image has a border it will be drawn.
*/
public synchronized void
//==============================================================
	draw(Graphics g,int x,int y,int options)
//==============================================================
{
	if ((properties & IsInvisible) != 0) return;
	Graphics clipped = g;
	if ((properties & IsEmpty) == 0) {
		clipped.translate(x,y);
		doDraw(clipped,options);
		clipped.translate(-x,-y);
	}
	drawBorder(clipped,x,y,options);
}
/**
* Draws itself on the graphic g at the point specified by the variable "location".
* If the image has a border it will be drawn.
*/
public synchronized void
//==============================================================
	draw(Graphics g)
//==============================================================
{
	draw(g,location.x,location.y,0);
}
//
/**
* This Area must update itself as the image moves.
**/
public Area hotArea;
//
/**
* This polygon must be relative to the top-left of the image. It will be automatically
* updated as the image moves so you can set it to be a static polygon.
**/
public Polygon hotPolygon;

//===================================================================
public void setHotAreaInImage(Area inImage)
//===================================================================
{
	hotArea = new imageHotArea(inImage,this,this);
}
/*
 * Create a Drawing optimized for display from the name of an Image resource and the name of
 * an image mask. An image mask has black pixels for opaque pixels in the image and
 * white pixels for transparent pixels in the image.
 * @param imageName the name of the image resource.
 * @param maskImageName the name of the image mask.
 */
public Drawing(String imageName, Object maskObject)
{
	setImage(new Picture(imageName,maskObject,0));
}
/*
 * Create a Drawing optimized for display from an IImage resource.
 * If the image provided is not used because
 * a new masked version of the image is created, then free() will be called
 * one the original image. * @param image the image resource.
 * @param maskImageName the name of the image mask.
 */
public Drawing(ImageData image, Object maskObject)
{
	if (image instanceof Picture && maskObject == null)
		setImage((Picture)image);
	else
		setImage(new Picture(image,maskObject,0));
}
public void setImage(ImageData image)
{
	this.image = ImageAdapter.toIImage(image,null);
	width = location.width = this.image.getWidth();
	height = location.height = this.image.getHeight();
}
public void setRect(int x, int y, int width, int height)
{
	location.set(x,y,width,height);
	this.width = width;
	this.height = height;
}
public void setSize(int width, int height)
{
	location.width = this.width = width;
	location.height = this.height = height;
}
public void setLocation(int x, int y)
{
	location.x = x;
	location.y = y;
}
public Drawing()
{
}
/**
* This sets the hot area to be within the image and include only the
* opaque portions of the image. 
**/
/*
//===================================================================
public Area makeOpaqueHotArea(Drawing template)
//===================================================================
{
	if (template == null) template = this;
	if (transparentColor != null)
		return new imageHotArea(transparentColor.toInt(),template,this);
	else
		return new imageHotArea(new Rect(0,0,template.location.width,template.location.height),this,this);
}
*/
private Polygon movedPolygon;
/**
* The area returned here is not relative to the top left of the image. It
* is an absolute area, regardless of the location of the image. If you have an area that is
* hard to translate (e.g. a Polygon) then call convertRelativeArea()
**/
//==================================================================
public Area getHotArea()
//==================================================================
{
	if (hotArea != null) return hotArea;
	else if (hotPolygon != null){
		if (movedPolygon == null) movedPolygon = new Polygon(hotPolygon,location.x,location.y);
		else movedPolygon.translate(hotPolygon,location.x,location.y);
		return movedPolygon;
	}else
		return location;
}
/**
* Returns if the point is on the hot area of the image.
*/
public boolean
//==============================================================
	onHotArea(int x,int y)
//==============================================================
{
	if ((properties & IsNotHot) != 0) return false;
	if (!location.isIn(x,y)) return false;
	return getHotArea().isIn(x,y);
}
//===================================================================
public Rect getDim(Rect dest)
//===================================================================
{
	return Rect.unNull(dest).set(0,0,location.width,location.height);
}
public int compareTo(Object other)
{
	if (this == other) return 0;
	return 1;
}
//==================================================================
public Object getNew() {return new Drawing();}
//==================================================================
//==================================================================
public void copyFrom(Object other)
//==================================================================
{
	Drawing from = (Drawing)other;
	setImage(from.image);
	location.set(from.location);
	properties = from.properties;
}

//===================================================================
public Object getCopy()
//===================================================================
{
	Drawing mi = (Drawing)getNew();
	mi.copyFrom(this);
	return mi;
}
//===================================================================
public void drawn(Rect where)
//===================================================================
{
	if (where == null) lastDrawn.set(0,0,-1,-1);
	else lastDrawn.set(where);
}
/* (non-Javadoc)
 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
 */
public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength) throws IllegalStateException {
	getScanLinesUsingPixels(startLine,numLines,destArray,offset,destScanLineLength);
	/*
	if (image != null){
		image.getImageScanLines(startLine,numLines,destArray,offset,destScanLineLength);
	}else{
		getScanLinesUsingPixels(startLine,numLines,destArray,offset,destScanLineLength);
	}
	*/
}
/* (non-Javadoc)
 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
 */
public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength) throws IllegalStateException {
	throw new IllegalStateException("Cannot write to this drawing.");
}
/* (non-Javadoc)
 * @see eve.fx.IImage#setPixels(int[], int, int, int, int, int, int)
 */

public boolean setPixels(int[] src, int offset, int x, int y, int width, int height, int rowStride) {
	return false;
}

public IImage getImage()
{
	return image;
}
}
//####################################################
