package eve.fx.gui;


/**
This is used to indicate that the WindowSurface has been resized.
*/
//##################################################################
public class SurfaceResizeEvent extends SurfaceEvent{
//##################################################################
public int newWidth;
public int newHeight;
//##################################################################
}
//##################################################################

