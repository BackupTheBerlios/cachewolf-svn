/*
 * Created on Nov 27, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class SurfaceInterprocessEvent extends SurfaceEvent {

}
//####################################################
