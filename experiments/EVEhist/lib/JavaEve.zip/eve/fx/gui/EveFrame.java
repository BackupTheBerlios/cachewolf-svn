/*
 * Created on Aug 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class EveFrame extends java.awt.Frame implements JavaSurface{
private NativeWindowSurface win;
private void dispatchEvent(RawEvent ev)
{
	win.dispatchEvent(ev);
}
private RawEvent getRawEvent(int type, int surfaceType)
{
	RawEvent re = new RawEvent();
	re.rawEventType = type;
	re.surfaceEventType = surfaceType;
	return re;
}

	/**
	 * 
	 */
	public EveFrame(NativeWindowSurface parent) {
		this.win = parent;
		addWindowListener(new WindowAdapter(){
			private void handle(WindowEvent we, int type)
			{
				SurfaceWindowEvent swe = new SurfaceWindowEvent();
				RawEvent re = getRawEvent(RawEvent.WINDOW_EVENT,type);
				win.dispatchEvent(re);
			}
			public void windowClosing(WindowEvent we){
				handle(we,SurfaceWindowEvent.CLOSE);
			}
			public void windowActivated(WindowEvent we){
				//System.out.println("Activated: "+System.identityHashCode(EveFrame.this));
				//win._canvas.requestFocus(); Causes race conditions!
				handle(we,SurfaceWindowEvent.ACTIVATE);
			}
			public void windowDeactivated(WindowEvent we){
				handle(we,SurfaceWindowEvent.DEACTIVATE);
			}
			public void windowOpened(WindowEvent we){
				//System.out.println("Opened!");
			}
			
		});
		/*
		int sz = 8;
		Color tx = Color.LightGreen;
		Image im = new Image(sz,sz);
		Graphics g = new Graphics(im);
		g.setColor(tx);
		g.fillRect(0,0,sz,sz);
		g.setColor(255,0,0);
		g.drawLine(0,0,sz,sz);
		g.free();
		PixelBuffer pb = new PixelBuffer(im);
		pb.setAlpha(tx,1);
		BufferedImageData bid = new BufferedImageData(new Picture("f:\\projects\\eclipse\\workspace\\eveapps\\com\\eve\\evemaker\\buildeve64.png"));
		setIconImage(bid.bi);
		*/
	}

	private boolean wasShown;
	public boolean wasShown()
	{
		return wasShown;
	}
}

//####################################################
