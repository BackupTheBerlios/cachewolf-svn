/*
 * Created on Nov 27, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import eve.data.DataObject;
import eve.sys.Event;
import eve.util.mString;


/**
 * This is an Event returned by a WindowSurface by WindowSurface.getEvent(). It is an
 * untranslated - reused event. You should immediately convert the RawEvent into one
 * of the SurfaceXXXXEvent objects using one of the convertToSurfaceEvent() methods.  
 * @author Michael L Brereton
 *
 */
//####################################################
public class RawEvent extends DataObject{

public static final int PAINT_EVENT = 1;
public static final int RESIZE_EVENT = 2;
public static final int KEY_EVENT = 3;
public static final int POINTER_EVENT = 4;
public static final int WINDOW_EVENT = 5;
public static final int INTERPROCESS_EVENT = 6;
public static final int SIP_EVENT = 7;
public static final int TEXT_EVENT = 8;
public static final int CUSTOM_EVENT = 9;
public static final int TASKBAR_ICON_EVENT = 10;
static final int LAST_EVENT = 10;
// Do not move these next 9
public int rawEventType;
public int surfaceEventType;
public int x;
public int y;
public int width;
public int height;
public int key;
public int modifiers;
protected Object data;
// Do not move those above here.
public WindowSurface surface;
public boolean inUse;
public Object context;

public void copyFrom(Object other)
{
	if (other instanceof RawEvent){
		super.copyFrom(other);
		data = ((RawEvent)other).data;
		context = ((RawEvent)other).context;
	}
}
public String toString()
{
	return rawEventType+", "+surfaceEventType;
}
public static Object createReusableEvents()
{
	SurfaceEvent[] reusedEvents = new SurfaceEvent[RawEvent.LAST_EVENT+1];
	reusedEvents[KEY_EVENT] = new SurfaceKeyEvent();
	reusedEvents[POINTER_EVENT] = new SurfacePointerEvent();
	reusedEvents[RESIZE_EVENT] = new SurfaceResizeEvent();
	reusedEvents[PAINT_EVENT] = new SurfacePaintEvent();
	reusedEvents[WINDOW_EVENT] = new SurfaceWindowEvent();
	reusedEvents[INTERPROCESS_EVENT] = new SurfaceInterprocessEvent();
	reusedEvents[SIP_EVENT] = new SurfaceSIPEvent();
	reusedEvents[TEXT_EVENT] = new SurfaceTextEvent();
	reusedEvents[CUSTOM_EVENT] = new SurfaceCustomEvent();
	reusedEvents[TASKBAR_ICON_EVENT] = new SurfaceTaskbarIconEvent();
	for (int i = 0; i<reusedEvents.length; i++)
		if (reusedEvents[i] != null)
			reusedEvents[i].setReused(true);
	return reusedEvents;
}
/**
 * Returns if the provided SurfaceEvent is one of the re-usable events
 * in the reusableEvents Object which was created by createReusableEvents().
 * @param event the event to test.
 * @param reusableEvents the Object created by createReusableEvents().
 * @return true if the event is one of the reusable events, false if not.
 */
/*
public boolean isResuedEvent(SurfaceEvent event, Object reusableEvents)
{
	SurfaceEvent[] all = (SurfaceEvent[])reusableEvents;
	if (all == null) return false;
	for (int i = 0; i<all.length; i++)
		if (all[i] == event) return true;
	return false;
}
*/
public RawEvent zero()
{
	rawEventType = surfaceEventType = x = y = width = height = key = modifiers = 0;
	data = null;
	return this;
}
public SurfaceEvent convertToReusableSurfaceEvent(Object reusableEvents)
{
	return convertToSurfaceEvent(((SurfaceEvent[])reusableEvents)[rawEventType]);
}
public SurfaceEvent convertToSurfaceEvent(SurfaceEvent destination)
{
	SurfaceEvent ret = destination;
	if (destination == null){
		switch(rawEventType){
			case PAINT_EVENT: ret = new SurfacePaintEvent(); break;
			case RESIZE_EVENT: ret = new SurfaceResizeEvent(); break;
			case KEY_EVENT: ret = new SurfaceKeyEvent(); break;
			case POINTER_EVENT: ret = new SurfacePointerEvent(); break;
			case WINDOW_EVENT: ret = new SurfaceWindowEvent(); break;
			case INTERPROCESS_EVENT: ret = new SurfaceInterprocessEvent(); break;
			case SIP_EVENT: ret = new SurfaceSIPEvent(); break;
			case TEXT_EVENT: ret = new SurfaceTextEvent(); break;
			case CUSTOM_EVENT: ret = new SurfaceCustomEvent(); break;
			case TASKBAR_ICON_EVENT: ret = new SurfaceTaskbarIconEvent(); break;
			default: 
				//throw new Error("Unexpected WindowSurface event type.");
				return null;
		}
	}
	//
	// Do conversion here.
	//
	ret.target = surface;
	ret.cause = null;
	ret.flags = 0;
	ret.timeStamp = System.currentTimeMillis();
	ret.type = surfaceEventType;
	switch(rawEventType){
	case PAINT_EVENT:
		SurfacePaintEvent pe = (SurfacePaintEvent)ret;
		pe.x = x; pe.y = y; pe.width = width; pe.height = height;
		break;
	case POINTER_EVENT:
		SurfacePointerEvent pt = (SurfacePointerEvent)ret;
		pt.x = x; pt.y = y; pt.modifiers = modifiers;
		break;
	case RESIZE_EVENT:
		SurfaceResizeEvent re = (SurfaceResizeEvent)ret;
		re.newWidth = width; re.newHeight = height;
		break;
	case WINDOW_EVENT:
		SurfaceWindowEvent we = (SurfaceWindowEvent)ret;
		we.x = x; we.y = y; we.window = surface;
		if (data != null){
			if (surfaceEventType == SurfaceWindowEvent.DATA_DROPPED){
				String got = (String)data;
				if (got == null) got = "";
				if (got.indexOf('|') == -1) we.data = got;
				else we.data = mString.split(got,'|');
			}
		}
		break;
	case SIP_EVENT:
		SurfaceSIPEvent sp = (SurfaceSIPEvent)ret;
		sp.visibleHeight = height; sp.visibleWidth = width;
		//sp.desktopHeight = y;
		sp.forwarded = false;
		break;
	case KEY_EVENT:
		SurfaceKeyEvent ke = (SurfaceKeyEvent)ret;
		ke.key = key; ke.modifiers = modifiers;
		break;
	case INTERPROCESS_EVENT:
		SurfaceInterprocessEvent ip = (SurfaceInterprocessEvent)ret;
		break;
	case TEXT_EVENT:
		SurfaceTextEvent tx = (SurfaceTextEvent)ret;
		tx.flags = modifiers;
		tx.entered = (String)data;
		tx.inputParameters = (NativeInputParameters)context;
		break;
	case CUSTOM_EVENT:
		SurfaceCustomEvent ce = (SurfaceCustomEvent)ret;
		try{
			ce.event = (Event)data;
		}catch(Exception e){}
		break;
	case TASKBAR_ICON_EVENT:
		SurfaceTaskbarIconEvent ti = (SurfaceTaskbarIconEvent)ret;
		ti.taskbarID = key;
		break;
	}
	return ret;
}
public SurfaceEvent convertToSurfaceEvent()
{
	return convertToSurfaceEvent(null);
}
public void cached()
{
	zero();
}
}

//####################################################
