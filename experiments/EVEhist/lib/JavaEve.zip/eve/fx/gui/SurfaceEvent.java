/*
 * Created on Nov 27, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import eve.sys.Event;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class SurfaceEvent extends Event {
	
	public WindowSurface getSurface()
	{
		return (WindowSurface)target;
	}
}
//####################################################
