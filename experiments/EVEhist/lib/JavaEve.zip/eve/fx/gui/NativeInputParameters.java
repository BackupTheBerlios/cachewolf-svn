/*
 * Created on Jun 21, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import eve.fx.Font;
import eve.fx.Rect;
import eve.nativeaccess.NativeAccess;
import eve.sys.Vm;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class NativeInputParameters {
	//
//	 Do not move any of these values - they are used by the native VM.
	//
	int nativeInputController;
	/**
	This can be a combination of any of the FLAG_XXX values.
	**/
	public int flags = 0;
	/**
	This is the initial text to be entered - use setInitialText() to set it - this
	will convert LF characters to CR/LF characters if necessary.
	**/
	public String initialText;
	/**
	This is the text that was entered. It will be null
	if the input was cancelled.
	**/
	public String enteredText = "Changed Text";
	/**
	If a dialog box must be used by the underlying system, then this prompt will be
	displayed in its title.
	**/
	public String prompt = "Please enter:";
	/**
	This is the number of rows of text input.
	**/
	public int textRows = 1;
	/**
	This is the number of columns of text input.
	**/
	public int textColumns = 40;
	/**
	This is the Control which will own the input.
	**/
	public Object control;
	/** 
	This can be set to be the Rect of the host control in its parent window.
	If possible, the system will try to place the input box over this control.
	**/
	public Rect controlRect;
	/** 
	This will be the font of the control.
	**/
	public Font controlFont;
	/** 
	If possible, this will be used as the password character. It defaults to '*'
	**/
	public char passwordCharacter = '*';
	/**
	This is set if the native input text cancelled the input.
	**/
	public static final int FLAG_CANCELLED = 0x1;
	public static final int FLAG_PASSWORD = 0x2;
	public static final int FLAG_UPPER_CASE = 0x4;
	public static final int FLAG_SENTENCE_CASE = 0x8;
	public static final int FLAG_NUMBERS_ONLY = 0x10;
	public static final int FLAG_AUTO_WRAP = 0x20;
	public static final int FLAG_MULTILINE = 0x40;
	public static final int FLAG_WANT_RETURN = 0x80;
	public static final int FLAG_SELECT_ALL = 0x100;
	public static final int FLAG_LOWER_CASE = 0x200;

	/**
	If this is true, then a TEXT_CHANGED event is sent for each key press. This
	only applies to native inputs associated with single line mInput controls.
	**/
	public static final int FLAG_EVENT_ON_EACH_KEY = 0x20;

//	===================================================================
	public void setInitialText(String text)
//	===================================================================
	{
		if (text.indexOf('\n') == -1) initialText = text;
		else if ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_NO_CR) != 0) initialText = text;
		else{
			char[] source = Vm.getStringChars(text);
			char[] dest = new char[source.length*2];
			int d = 0;
			for (int s = 0; s<source.length; s++){
				if (source[s] == '\n') dest[d++] = '\r';
				dest[d++] = source[s];
			}
			initialText = new String(dest,0,d);
		}
	}
//	===================================================================
	public static String fixEditedText(String text)
//	===================================================================
	{
		if (text.indexOf('\r') == -1) return text;
		else if ((Vm.getParameter(Vm.VM_FLAGS) & Vm.VM_FLAG_NO_CR) != 0) return text;
		else{
			char[] source = Vm.getStringChars(text);
			char[] dest = new char[source.length];
			int d = 0;
			for (int s = 0; s<source.length; s++){
				if (source[s] != '\r') dest[d++] = source[s];
			}
			return new String(dest,0,d);
		}
	}

	private native boolean doOp(int op, Object data);
	
	public void repaint(Rect area)
	{
		doOp(1,area);
	}
	
	protected void finalize()
	{
		NativeAccess.unref(nativeInputController);
	}
}
//####################################################
