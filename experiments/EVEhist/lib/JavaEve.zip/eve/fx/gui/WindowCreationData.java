package eve.fx.gui;

import java.util.Hashtable;

import eve.fx.Rect;
import eve.sys.DeviceIcon;


//##################################################################
public class WindowCreationData implements WindowConstants{
//##################################################################
//The next 5 variables must come first.
private boolean doRegisterClass = false;
/**
* Under Win32 this must be a unique name for this class of window. Windows of the same class will share
* the same icon. If this is not set, the icon will not be changed.
**/
public String nativeWindowClassName = null;
/**
* Used by WindowContainer only.
**/
public Object parentWindow = null;
/**
 * The ID of the screen it is being displayed on (for multi-displays).
 */
public int screenId = 0;
//-------------------------------------

static Hashtable classes = new Hashtable();

//-------------------------------------------------------------------
void setup()
//-------------------------------------------------------------------
{
	if (nativeWindowClassName == null) return;
	if (classes.get(nativeWindowClassName) != null) return;
	classes.put(nativeWindowClassName,new Object());
	doRegisterClass = true;
}
/**
 * This is the default value for the x, y, width or height for the bounds
 * of the created window. These are set by default when WindowCreationData
 * is created.
 */
public final static int DEFAULT_VALUE = 0x80000000; 
/**
 * This should be one of the STATE_XXX values.
 */
public int state; 
/**
 * The title for the window.
 */
public String title; 
/**
 * The location for the window. If any of x, y, width or height are DEFAULT_VALUE, then default
 * values will be used.
 */
public Rect bounds = new Rect(DEFAULT_VALUE, DEFAULT_VALUE,DEFAULT_VALUE,DEFAULT_VALUE);
/**
 * An optional icon for the Window.
 */
public DeviceIcon icon;
/**
This is a combination of any of the IWindowConstants that are not STATE_XXX constants.
**/
//public int options;
public int flagsToSet;
public int flagsToClear;
/**
 * This is a convenience method - it calls getNew() on WindowSurface and then
 * calls create on that surface with this WindowCreationData. 
 * @return the created WindowSurface.
 */
public WindowSurface create()
{
	WindowSurface ws = WindowSurface.getNew();
	if (ws != null) ws.create(this);
	return ws;
}
/**
 * Setup the WindowCreationData flags as it would be used as the default Window Surface.
 * @param extraFlagsToSet - extra flags that should also be set.
 * @param extraFlagsToClear - extra flags that should also be cleared.
 * @return this WindowCreationData after the changes are made.
 */
public WindowCreationData setForDefaultSurface(int extraFlagsToSet, int extraFlagsToClear)
{
	flagsToSet |= FLAG_IS_DEFAULT_SURFACE|extraFlagsToSet;
	flagsToClear |= FLAG_IS_VISIBLE|extraFlagsToClear;
	flagsToSet &= ~extraFlagsToClear;
	flagsToClear &= ~extraFlagsToSet;
	return this;
}
//##################################################################
}
//##################################################################

