/*
 * Created on Apr 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;


/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class SurfacePaintEvent extends SurfaceEvent {

public int x;
public int y;
public int width;
public int height;

}
//####################################################
