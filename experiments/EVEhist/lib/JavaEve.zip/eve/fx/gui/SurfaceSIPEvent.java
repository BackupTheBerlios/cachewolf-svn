package eve.fx.gui;


//##################################################################
public class SurfaceSIPEvent extends SurfaceEvent{
//##################################################################
/** The event type for when the SIP is shown. */
public static final int SIP_SHOWN = 900;
/** The event type for when the SIP is hidden. */
public static final int SIP_HIDDEN = 901;

/**
* The width of the area of the screen still visible after the SIP is shown. It
* is assumed that the SIP is at the bottom of the screen.
**/
public int visibleWidth;
/**
* The height of the area of the screen still visible after the SIP is shown. It
* is assumed that the SIP is at the bottom of the screen.
**/
public int visibleHeight;
/**
* This is the visible desktop (i.e. the visibleHeight - taskbarHeight) if the taskbar is on top.
**/
//public int desktopHeight;

public boolean forwarded;

public static boolean handlingSipOn;
//##################################################################
}
//##################################################################

