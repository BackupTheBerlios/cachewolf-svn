/*
 * Created on Feb 26, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import eve.nativeaccess.NativeAccess;
import eve.sys.DeviceIcon;
import eve.sys.EventDispatcher;
import eve.sys.ITaskbarEntry;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
class TaskbarEntry implements ITaskbarEntry {
	//Don't move this.
	int myID;
	WindowSurface surface;
	
	public int hashCode()
	{
		return myID;
	}
	
	EventDispatcher ed = new EventDispatcher();
	/* (non-Javadoc)
	 * @see eve.sys.ITaskbarEntry#getEventDispatcher()
	 */
	public EventDispatcher getEventDispatcher() {
		return ed;
	}
	/* (non-Javadoc)
	 * @see eve.sys.ITaskbarEntry#setIconAndTip(eve.sys.DeviceIcon, java.lang.String, int)
	 */
	public synchronized boolean setIconAndTip(DeviceIcon icon, String tip, int validItems) {
		if (myID == 0) return false; 
		return ((NativeWindowSurface)surface).taskbarOp(1,myID,icon,tip,validItems) != 0;
	}

	public synchronized boolean removeIcon()
	{
		return setIconAndTip(null,null,SET_ICON_IS_VALID|SET_TIP_IS_VALID);
	}
	/* (non-Javadoc)
	 * @see eve.sys.ITaskbarEntry#close()
	 */
	public synchronized void close() {
		if (myID == 0) return;
		WindowSurface.taskbarEntries.remove(new Integer(myID));
		try{
			((NativeWindowSurface)surface).taskbarOp(-1,myID,null,null,0);
			NativeAccess.unref(myID);
		}catch(Throwable t){}
		myID = 0;
	}

	public void finalize(){
		close();
	}
}

//####################################################
