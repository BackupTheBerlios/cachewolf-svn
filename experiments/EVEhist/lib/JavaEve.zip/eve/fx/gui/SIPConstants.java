/*
 * Created on Jul 31, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface SIPConstants {
	/**
	* See documentation of SetSIP()
	**/
	public final static int SIP_ON = 0x1;
	/**
	* See documentation of SetSIP()
	**/
	public final static int SIP_LEAVE_BUTTON = 0x2;
	/**
	* See documentation of SetSIP()
	**/
	public final static int SIP_LOCK = 0x4;
	public final static int SIP_FREEZE = 0x8;
	public final static int SIP_UNFREEZE = 0x10;
	/** If VmOptions.useSIP is false, this will override it so that a setSIP() with this
	 * option will activate the SIP.
	 */
	public final static int SIP_OVERRIDE_USE_SIP = 0x20;
	public final static int SIP_REMOVE_BUTTON = 0x40;
	public static final int SIP_IS_ON = 0x1;
	public final static int SIP_CURRENT = -1;
	

}
//####################################################
