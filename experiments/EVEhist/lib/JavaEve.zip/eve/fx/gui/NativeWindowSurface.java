/*
 * Created on Apr 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import java.awt.Container;
import java.awt.Cursor;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.Vector;

import eve.applet.EveApplet;
import eve.fx.BufferedImageData;
import eve.fx.Dimension;
import eve.fx.Font;
import eve.fx.Graphics;
import eve.fx.Image;
import eve.fx.Rect;
import eve.nativeaccess.nativeIcon;
import eve.sys.Countdown;
import eve.sys.Device;
import eve.sys.DeviceIcon;
import eve.sys.Gate;
import eve.sys.ITaskbarEntry;
import eve.sys.ImageData;
import eve.sys.Vm;

/**
 * This class represents the platforms display object - for example a Window in Windows/Win32
 * or the entire screen on smaller devices.
 * <p>
 * The WindowSurface also is responsible for generating UI events like keyboard and pen/mouse
 * events as well as paint and resize events.
 * 
 * @author Michael L Brereton
 *
 */
//####################################################
public class NativeWindowSurface extends WindowSurface{
//
// This is made public so the Graphics class can get it.
//
public EveWindow _window;
public EveFrame _frame;
public EveCanvas _canvas;

Object gotGraphics = null;
AffineTransform tx = null;
int last = 0;
private static final boolean useNew = true;
private boolean amClosed;
private String lastGot;
Gate graphicsGate = new Gate();
int graphicsCount = 0;

public static final int ROTATION_NONE = Device.ROTATION_NONE;
public static final int ROTATION_90 = Device.ROTATION_90;
public static final int ROTATION_180 = Device.ROTATION_180;
public static final int ROTATION_270 = Device.ROTATION_270;

private Object _waitForGraphics()
{
	graphicsGate.synchronize();
	if (gotGraphics == null) gotGraphics = _canvas.getGraphics();
	final Graphics2D g = (Graphics2D)gotGraphics;
	tx = g.getTransform();
	lastGot = Vm.getStackTrace(new Exception());
	graphicsCount++;
	return gotGraphics;
}
public Object getNativeGraphics()
{
	if (amClosed) return null;
	if (useNew) return _canvas.getGraphics();
	return _waitForGraphics();
}
public void freeNativeGraphics(Object g)
{
	if (true) return;
	if (useNew){
		((Graphics2D)g).dispose();
		return;
	}
	try{
		((Graphics2D)g).setClip(null);
		((Graphics2D)g).setTransform(tx);
		if (gotGraphics != g){
			((java.awt.Graphics)g).dispose();
		}
	}finally{
		graphicsCount--;
		graphicsGate.unlock();
	}
	//if (graphicsCount != 0) graphicsCount--;
	//else System.out.println("Graphics Error!");
}
public Graphics getGraphics()
{
	if (rotation != 0) throw new UnsupportedOperationException();
	if (true) throw new UnsupportedOperationException();
	return new Graphics(0,this);
}
public void clearCursorRegions()
{
	_canvas.clearCursorAreas();
}
int setCursorArea(int id, int x, int y, int width, int height, Object cursor)
{
	return _canvas.addCursorArea(id,x,y,width,height,(java.awt.Cursor)cursor);
}
/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#removeCursorRegion(int)
 */
public void removeCursorRegion(int regionID) {
	_canvas.removeCursorArea(regionID);
}

private static Object getCursorHandle(int which)
{
	Object ret = null;
	switch(which){
		case eve.fx.gui.Cursor.DEFAULT_CURSOR: return Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR);
		case eve.fx.gui.Cursor.WAIT_CURSOR: return Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
		case eve.fx.gui.Cursor.HAND_CURSOR: return Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);
		case eve.fx.gui.Cursor.CROSS_CURSOR: return Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR);
		case eve.fx.gui.Cursor.IBEAM_CURSOR: return Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR);
		//case UP_DOWN_CURSOR: 
		//case LEFT_RIGHT_CURSOR: 
		case eve.fx.gui.Cursor.MOVE_CURSOR:
			return Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR);
		case eve.fx.gui.Cursor.RESIZE_CURSOR: return Cursor.getPredefinedCursor(Cursor.SE_RESIZE_CURSOR);
	}
	return ret;
}
	
static Object loadCursor(int which)
{
	return getCursorHandle(which);
}
static Object createACursor(ImageData id, int x, int y)
{
	BufferedImageData bid = new BufferedImageData(id);
	return Toolkit.getDefaultToolkit().createCustomCursor(bid.bi,new java.awt.Point(x,y),"NewCursor");
}
boolean setCursor(Object cursor)
{
	_canvas.setCursor((java.awt.Cursor)cursor);
	return true;
}

public Object getJavaSurface()
{
	if (_frame != null) return _frame;
	if (_window != null) return _window;
	return EveApplet.getApplet();
}
class javaWindow extends Thread{
	java.awt.Window w;
	boolean runThread = false;
	public javaWindow(java.awt.Window win)
	{
		w = win;
		if (runThread) start();
	}
	
	String command = null;
	boolean done = false;
	
	private synchronized void runCommand(String comm)
	{
		while(command != null){
			try{
				wait();
			}catch(Exception e){}
		}
		command = comm;
		done = false;
		notifyAll();
		while(!done){
			try{
				wait();
			}catch(Exception e){}
		}
		command = null;
		done = false;
		notifyAll();
	}
	public void pack()
	{
		if (!runThread)w.pack();
		else 
			runCommand("pack");
	}
	public void setVisible(boolean vis)
	{
		if (!runThread)w.setVisible(vis);
		else 
		runCommand(vis ? "show" : "hide");
	}
	public void close()
	{
		if (!runThread){
			w.setVisible(false);
			w.dispose();
		}
		else 
		runCommand("close");
	}
	
	public void run(){
		synchronized(this){
			while(true){
				while (command == null)
					try{
						wait();
					}catch(InterruptedException e){}
				try{
					System.out.println("C: "+command);
					boolean quit = false;
					if (command.equals("pack")){
						w.pack();
					}
					else if (command.equals("close")){
						quit = true;
						w.setVisible(false);
						//w.dispose();
					}
					else if (command.equals("show")){
						w.setVisible(true);
					}else if (command.equals("hid")){
						w.setVisible(false);
					}
					done = true;
					notifyAll();
					if (quit) return;
					while (done)
						try{
							wait();
						}catch(InterruptedException e){}
				}catch(Throwable t){}				
			}
		}
	}
	
};

private javaWindow myWindow;
public synchronized javaWindow getJavaWindow()
{
	if (myWindow == null){
		java.awt.Window w = _frame == null ? _window : (Window)_frame;
		if (w == null) return null;
		myWindow = new javaWindow(w);
	}
	//return _frame == null ? _window : (Window)_frame;
	return myWindow;
}
public Frame getJavaFrame()
{
	return _frame;
}

/**
 * Returns if the underlying system supports multiple windows for an application.
 */
public static boolean supportsMultiple()
{
	return true;
}

/**
 * Returns if it is possible to copy pixel data <b>from</b> a window.
 */
public static boolean canCopyFrom()
{
	return false;
}

int sizeState = 0;

public synchronized void setState(int newState)
{
	if (amClosed) return;
	javaWindow w = getJavaWindow();
	if (w == null) return;
	if ((newState & STATE_TO_FRONT) != 0){
		w.w.toFront();
	}
	if (((newState & STATE_MAXIMIZED) != 0) && (_frame != null)){
		sizeState = STATE_MAXIMIZED;
		Rect dest = new Rect();
		getScreenRect(dest,true);
		setBounds(dest.x,dest.y,dest.width,dest.height);
	}
}

public void requestRepaint(int x, int y, int width, int height, boolean dontMerge)
{
	Rect r = Rect.getCached(x,y,width,height);
	rotateInClient(rotation,r,false);
	RawEvent re = new RawEvent();
	re.rawEventType = RawEvent.PAINT_EVENT;
	re.surfaceEventType = 0;
	re.x = r.x;
	re.y = r.y;
	re.width = r.width;
	re.height = r.height;
	re.surface = this;
	dispatchEvent(re);
	r.cache();
}

public int getState()
{
	if (amClosed) return 0;
	//TODO
	return STATE_UNKNOWN;
}
public void doClose()
{
	Object got = null;
	synchronized(this){
		if (amClosed) return;
		got = getNativeGraphics(); 
		amClosed = true;
		notifyAll();
	}
	synchronized(waitingEvents){
		noMoreEvents = true;
		waitingEvents.notify();
	}
	if (got != null) ((java.awt.Graphics)got).dispose();
	javaWindow w = getJavaWindow();
	if (w != null){
		w.close();
		/*
		w.setVisible(false);
		w.dispose();
		*/
	}
}
public void setVisible(boolean visible)
{
	javaWindow w = getJavaWindow();
	synchronized(this){
		if (amClosed) return;
		if (w != null){
			w.setVisible(visible);
		}
	}
	if (w != null) _canvas.waitForPaint();
}
public synchronized boolean isVisible()
{
	if (amClosed) return false;
	javaWindow w = getJavaWindow();
	if (w != null) return w.w.isVisible();
	return true;
}
static boolean rotate(int rotation, Rect subArea, Rect trueFullArea, boolean fromScreen)
{
	if (rotation == ROTATION_NONE) return true;
	//System.out.println("{"+trueFullArea+"}");
	int x = subArea.x, y = subArea.y, width = subArea.width, height = subArea.height;
	switch(rotation){
	case ROTATION_90:
		subArea.width = height; subArea.height = width;
		if (trueFullArea != null){
			if (fromScreen){
				subArea.y = trueFullArea.width-x-width;
				subArea.x = y;
			}else{
				subArea.x = trueFullArea.width-y-height;
				subArea.y = x;
			}
		}
		break;
	case ROTATION_270:
		subArea.width = height; subArea.height = width;
		if (trueFullArea != null){
			if (fromScreen){
				subArea.x = trueFullArea.height-y-height;
				subArea.y = x;
			}else{
				subArea.y = trueFullArea.height-x-width;
				subArea.x = y;
			}
		}
		break;
	case ROTATION_180:
		if (trueFullArea != null){
			subArea.x = trueFullArea.width-x-width;
			subArea.y = trueFullArea.height-y-height;
		}
	}
	return true;
}


boolean rotateInWindow(int rotation, Rect subArea, boolean fromScreen)
{
	Rect rotateMe = new Rect();
	if (rotation == ROTATION_NONE) return true;
	if (!doGetBounds(rotateMe)) return false;
	rotateMe.x = rotateMe.y = 0;
	return rotate(rotation,subArea,rotateMe,fromScreen);
}
boolean rotateInClient(int rotation, Rect subArea, boolean fromScreen)
{
	Rect rotateMe = new Rect();
	if (rotation == ROTATION_NONE) return true;
	if (!doGetClientRect(rotateMe)) return false;
	rotateMe.x = rotateMe.y = 0;
	return rotate(rotation,subArea,rotateMe,fromScreen);
}
boolean rotateOnScreen(int rotation, int id, Rect subArea, boolean fromScreen)
{
	Rect rotateMe = new Rect();
	if (rotation == ROTATION_NONE) return true;
	if (!doGetScreenRect(id,rotateMe,
			true//false
			)) return false;
	rotateMe.x = rotateMe.y = 0;
	return rotate(rotation,subArea,rotateMe,fromScreen);
}
/**
 * Get the size of a particular screen.
 * @param screenId the id of the screen. 0 is the default screen.
 * @param dest a non-null destination Rect.
 * @param desktopOnly true to get the Rect representing the desktop area of the screen.
 * @return true if successful, false if not.
 */
public final boolean getScreenRect(int screenId,Rect dest,boolean desktopOnly)
{
	if (!doGetScreenRect(screenId,dest,desktopOnly)) return false;
	return rotate(rotation,dest,null,true);
}

public final boolean getBounds(Rect dest)
{
	if (!doGetBounds(dest)) return false;
	return rotateOnScreen(rotation,screenId,dest,true);
}
public final boolean setBounds(int x, int y, int width, int height)
{
	Rect r = new Rect(x,y,width,height);
	rotateOnScreen(rotation,screenId,r,false);
	return doSetBounds(r.x,r.y,r.width,r.height);
}
public final boolean getClientRect(Rect dest)
{
	if (!doGetClientRect(dest)) return false;
	return rotateInWindow(rotation,dest,true);
}
public final boolean setClientRect(int x, int y, int width, int height)
{
	Rect r = new Rect(x,y,width,height);
	rotateOnScreen(rotation,screenId,r,false);
	return doSetClientRect(r.x,r.y,r.width,r.height);
}

public boolean doGetBounds(Rect dest)
{
	Container c = null;
	synchronized(this){
		if (amClosed) return false;
		c = (Container)getJavaSurface();
	}
	if (c == null) return false;
	java.awt.Rectangle r = c.getBounds();
	dest.set(r.x,r.y,r.width,r.height);
	return true;
}

public boolean doSetBounds(int x, int y, int width, int height)
{
	javaWindow w = null;
	synchronized(this){
		if (amClosed) return false;
		w = getJavaWindow();
	}
	if (w == null) return false;
	if (width >= 0 && height >= 0) w.w.setSize(width,height);
	if (x >= 0 && y >= 0) w.w.setLocation(x,y);
	return true;
}

public NativeWindowSurface(){}

protected void doCreate(WindowCreationData wco)
{
	NativeWindowSurface ws = this;
	//ws._window = new EveWindow(false,wco.title,this);
	if (EveApplet.shouldUseFrame) ws._frame = new EveFrame(this);
	ws._canvas = new EveCanvas(this);
	//
	Container main = (Container)getJavaSurface(); 
	main.add(ws._canvas);
	if (wco == null) wco = new WindowCreationData();
	int fl = wco.flagsToSet & ~wco.flagsToClear;
	Rect r = wco.bounds;
	if (r == null) r = new Rect(wco.DEFAULT_VALUE,wco.DEFAULT_VALUE,240,320);
	int w = r.width, h = r.height, x = r.x, y = r.y;
	boolean wasDefaultSize = (w == wco.DEFAULT_VALUE || h == wco.DEFAULT_VALUE);
	Rect sr = new Rect(0,0,640,480);
	getScreenRect(wco.screenId,sr,true);
	if (w == wco.DEFAULT_VALUE) w = sr.width;
	if (h == wco.DEFAULT_VALUE) h = sr.height;
	if (w > sr.width) w = sr.width;
	if (h > sr.height) h = sr.height;
	if (x == wco.DEFAULT_VALUE) x = (sr.width-w)/2;
	if (y == wco.DEFAULT_VALUE) y = (sr.height-h)/2;
	sizeState = 0;
	if ((_frame != null) && (fl & FLAG_MAXIMIZE) != 0) {
		x = y = 0;
		w = sr.width;
		h = sr.height;
		sizeState = STATE_MAXIMIZED;
	}
	javaWindow jwin = getJavaWindow();
	if (jwin != null) jwin.pack();
	else {
		EveApplet.getApplet().validate();
		_canvas.repaint();
	}
	//main.setPreferredSize(new java.awt.Dimension(w,h));
	if (sizeState == STATE_MAXIMIZED)
		ws.setBounds(x,y,w,h);
	else
		ws.setClientRect(x,y,w,h);
	if ((wco.flagsToClear & FLAG_IS_VISIBLE) == 0) ws.setVisible(true);
	if (wco.title != null && ws._frame != null) ws._frame.setTitle(wco.title);
	int extras = FLAG_ALWAYS_ENABLED;
	setFlags(wco.flagsToSet & extras, wco.flagsToClear & extras);
}


public int getAsyncKeyState(int keyCode)
{
	if (amClosed) return 0;
	if (keyCode == IKeys.PEN){
		if (_canvas.getMouseState() != 0)
			return 0x8000;
		else
			return 0;
	}
	/*
	else{
		if (!showedKeyError) 
			System.out.println("Warning: getAsyncKeyState() not supported under Java.");
		showedKeyError = true;
	}
	*/
	return 0;
}
public Object getInfo(int infoCode, Object parameters, Object dest, int options)
{
	if (amClosed) return null;
	return null;
}
public boolean setInfo(int infoCode, Object parameters, int options)
{
	if (amClosed) return false;
	return false;
}


/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getClientRect(eve.fx.Rect)
 */
public boolean doGetClientRect(Rect dest) {
	if (amClosed) return false;
	javaWindow w = getJavaWindow();
	if (w == null) return getBounds(dest);
	Insets in = w.w.getInsets();
	Rectangle r = new Rectangle();
	w.w.getBounds(r);
	dest.set(in.left,in.top,r.width-in.left-in.right,r.height-in.top-in.bottom);
	return true;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#setClientRect(int, int, int, int)
 */
public boolean doSetClientRect(int x, int y, int width, int height) 
{
	boolean move = (x == 0 && y == 0); 
	if (amClosed) return false;
	javaWindow w = getJavaWindow();
	if (w == null) return false;
	Insets in = w.w.getInsets();
	width += in.left+in.right;
	height += in.top+in.bottom;
	x -= in.left;
	y -= in.top;
	if (move) {
		x += 8;
		y += 25;
	}
	
	w.w.setBounds(x,y,width,height);
	//if (width >= 0 && height >= 0) w.setSize(width,height);
	//if (x >= 0 && y >= 0) w.setLocation(x,y);
	return true;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getParentSize(eve.fx.Dimension)
 */
public boolean getParentSize(Dimension dest) {
	// TODO Auto-generated method stub
	if (amClosed) return false;
	return false;
}
int extraFlags = 0;
/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#setFlags(int, int)
 */
public int setFlags(int flagsToSet, int flagsToClear) {
	// TODO Auto-generated method stub
	int extras = FLAG_ALWAYS_ENABLED;
	if (amClosed) return 0;
	extraFlags |= (flagsToSet & extras);
	extraFlags &= ~ (flagsToClear & extras);
	int ret = 0;
	if (isVisible()) ret |= FLAG_IS_VISIBLE;
	if (_frame != null) ret |= FLAG_HAS_CLOSE_BUTTON|FLAG_HAS_TITLE;
	ret |= extraFlags;
	return ret;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getFlagsForSize(int, int, int, int)
 */
public int getFlagsForSize(int requestedWidth, int requestedHeight, int requestedSetFlags, int requestedClearFlags) {
	// TODO Auto-generated method stub
	//return 0;
	if (amClosed) return 0;
	int ret = 0;
	//if ((requestedClearFlags & FLAG_HAS_TITLE) == 0) ret |= FLAG_HAS_CLOSE_BUTTON|FLAG_HAS_TITLE;
	return ret;
	
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#setIcon(eve.fx.IImage)
 */
public boolean setIcon(DeviceIcon icon) 
{
	if (amClosed) return false;
	if (icon == null) return false;
	if (_frame != null) _frame.setIconImage((BufferedImage)((nativeIcon)icon).getNativeIcon());
	return true;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#setTaskbarIcon(eve.fx.IImage)
 */
public boolean setTaskbarIcon(DeviceIcon icon) {
	if (amClosed) return false;
	return false;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getDroppedData(int)
 */
public Object getDroppedData(int dataID) {
	// TODO Auto-generated method stub
	if (amClosed) return null;
	return null;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getFont()
 */
public Font getFont() {
	// TODO Auto-generated method stub
	if (amClosed) return null;
	return null;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#setFont(eve.fx.Font)
 */
public boolean setFont(Font font) {
	// TODO Auto-generated method stub
	if (amClosed) return false;
	return false;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#setGuiFlags(int, int)
 */
public int setGuiFlags(int flagsToset, int flagsToClear) {
	// TODO Auto-generated method stub
	if (amClosed) return 0;
	return GUI_FLAG_DONT_REPAINT_ON_RESIZE;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getTitle()
 */
public String getTitle() {
	if (amClosed) return null;
	if (_frame != null) return _frame.getTitle();
	return null;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#setTitle(java.lang.String)
 */
public void setTitle(String title) {
	// TODO Auto-generated method stub
	if (amClosed) return;
	if (title == null) title = "";
	if (_frame != null) _frame.setTitle(title);
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getScreenRect(eve.fx.Dimension)
 */
public boolean doGetScreenRect(int screenId,Rect dest,boolean desktopOnly) {
	if (amClosed) return false;
	java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
	dest.set(0,0,d.width,d.height);
	if (desktopOnly)
		try{
			java.awt.Graphics g = (java.awt.Graphics)((NativeWindowSurface)mainSurface).getNativeGraphics();
			GraphicsConfiguration gc = ((Graphics2D)g).getDeviceConfiguration();
			Insets in = java.awt.Toolkit.getDefaultToolkit().getScreenInsets(gc);
			dest.x += in.left; dest.y += in.top;
			dest.height -= in.top+in.bottom; dest.width -= in.left+in.right;
		}catch(Throwable e){}
	EveApplet a = EveApplet.getApplet();
	if (a.mainHeight != 0) dest.height = a.mainHeight;
	if (a.mainWidth != 0) dest.width = a.mainWidth;
	return true;
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#captureAppKeys(int)
 */
public synchronized int captureAppKeys(int options) {
	if (amClosed) return 0;
	// TODO Auto-generated method stub
	return 0;
}
public Vector waitingEvents = new Vector();
private boolean noMoreEvents = false;

protected Countdown cd = new Countdown();

protected synchronized void takeKeyFocus()
{
	if (amClosed) return;
	_canvas.requestFocus();
}
void dispatchEvent(RawEvent re)
{
	if (amClosed) return;
	dispatchEvent(re,false);
}
Rect dr1 = new Rect(), dr2 = new Rect();

void rotate(RawEvent re)
{
	int rot = rotation;
	if (rot == ROTATION_NONE) return;
	boolean show = false && re.rawEventType == re.POINTER_EVENT;
	Rect r = Rect.getCached(re.x,re.y,re.width,re.height);
	if (show) System.out.println("Before: "+r);
	try{
		switch(re.rawEventType){
			case RawEvent.RESIZE_EVENT:
			case RawEvent.POINTER_EVENT:
			case RawEvent.PAINT_EVENT:
				rotateInClient(rot,r,true);
				re.x = r.x; re.y = r.y;
				re.width = r.width; re.height = r.height;
				if (rot == ROTATION_180){
					if (re.surfaceEventType == SurfacePointerEvent.SCROLL_DOWN)
						re.surfaceEventType = SurfacePointerEvent.SCROLL_UP;
					else if (re.surfaceEventType == SurfacePointerEvent.SCROLL_UP)
						re.surfaceEventType = SurfacePointerEvent.SCROLL_DOWN;
				}
				break;
			case RawEvent.KEY_EVENT:
				if (re.key == IKeys.DOWN){
					if (rot == ROTATION_90) re.key = IKeys.RIGHT;
					else if (rot == ROTATION_180) re.key = IKeys.UP;
					else if (rot == ROTATION_270) re.key = IKeys.LEFT;
				}
				else if (re.key == IKeys.UP){
					if (rot == ROTATION_90) re.key = IKeys.LEFT;
					else if (rot == ROTATION_180) re.key = IKeys.DOWN;
					else if (rot == ROTATION_270) re.key = IKeys.RIGHT;
				}
				else if (re.key == IKeys.LEFT){
					if (rot == ROTATION_90) re.key = IKeys.DOWN;
					else if (rot == ROTATION_180) re.key = IKeys.RIGHT;
					else if (rot == ROTATION_270) re.key = IKeys.UP;
				}
				else if (re.key == IKeys.RIGHT){
					if (rot == ROTATION_90) re.key = IKeys.UP;
					else if (rot == ROTATION_180) re.key = IKeys.LEFT;
					else if (rot == ROTATION_270) re.key = IKeys.DOWN;
				}
				break;
		}
	}catch(Throwable t){
		t.printStackTrace();
	}finally{
		if (show) System.out.println("After: "+r.set(re.x,re.y,re.width,re.height));
		r.cache();
	}
}

void dispatchEvent(RawEvent re,boolean toFront)
{
	if (rotation != ROTATION_NONE){
		rotate(re);
	}
	synchronized(waitingEvents){
		//if (re.rawEventType == re.RESIZE_EVENT) System.out.println("Raw Resize!");
		try{
			int t = re.rawEventType;
			if (t == RawEvent.PAINT_EVENT){
				for (int i = 0; i<waitingEvents.size(); i++){
					RawEvent r = (RawEvent)waitingEvents.get(i);
					if (r.rawEventType == t){
						dr1.set(r.x,r.y,r.width,r.height);
						dr2.set(re.x,re.y,re.width,re.height);
						dr1.unionWith(dr2);
						r.x = dr1.x; r.y = dr1.y;
						r.width = dr1.width; r.height = dr1.height;
						return;
					}
				}
			}else if (t == RawEvent.POINTER_EVENT && re.surfaceEventType == SurfacePointerEvent.MOUSE_MOVE){
				int last = waitingEvents.size()-1;
				if (last > 0){
					RawEvent r = (RawEvent)waitingEvents.get(last);
					if (r.rawEventType == t && r.surfaceEventType == re.surfaceEventType){
						r.x = re.x;
						r.y = re.y;
						return;
					}
				}
			}
			if (!toFront) waitingEvents.add(re);
			else waitingEvents.insertElementAt(re,0);
		}finally{
			waitingEvents.notify();
		}
	}
}
/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getRawEvent(long, eve.fx.gui.RawEvent)
 */
protected boolean getRawEvent(long howLongToWait, RawEvent destination) throws InterruptedException {
	cd.start(howLongToWait);
	synchronized(waitingEvents){
		while(!noMoreEvents){
			if (waitingEvents.size() != 0){
				RawEvent re = (RawEvent) waitingEvents.elementAt(0);
				if (re.rawEventType == re.RESIZE_EVENT) {
					synchronized(graphicsGate){
						if (graphicsCount == 0 && gotGraphics != null){
							((java.awt.Graphics)gotGraphics).dispose();
						}
						gotGraphics = null;
					}
					/*
					synchronized(this){
					}
					*/
					//System.out.println("Raw Resize!");
				}
				waitingEvents.removeElementAt(0);
				waitingEvents.notify();
				destination.copyFrom(re);
				return true;
			}
			if (!cd.waitOn(waitingEvents)) return false;
		}
		return false;
	}
}
/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#doCaptureMouse(boolean)
 */
protected synchronized boolean doCaptureMouse(boolean doGrab) {
	// TODO Auto-generated method stub
	if (amClosed) return false;
	return false;
}
/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getAsyncPointerState(eve.fx.gui.SurfacePointerEvent)
 */
/*
public boolean getAsyncPointerState(SurfacePointerEvent destination) {
	// TODO Auto-generated method stub
	return false;
}
*/
/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#postRawEvent(eve.fx.gui.RawEvent)
 */
public void postRawEvent(RawEvent event) {
	boolean tf = (event.modifiers & IEventModifiers.POST_TO_BACK) == 0;
	event.modifiers &= ~IEventModifiers.POST_TO_BACK;
	dispatchEvent((RawEvent)event.getCopy(),tf);
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#hasPendingEvents()
 */
public boolean hasPendingEvents() {
	synchronized (waitingEvents){
		return waitingEvents.size() != 0;
	}
}
public synchronized ITaskbarEntry doCreateTaskbarEntry() {
	// TODO Auto-generated method stub
	if (amClosed) return null;
	return null;
}

/* (non-Javadoc)
 * @see eve.fx.ISurface#drawImage(eve.fx.Image, int, int, int, int, int, int, int, int)
 */
public void drawImage(Image src, int clipX, int clipY, int clipWidth, int clipHeight, int destX, int destY, int width, int height) {
	EveCanvas c = _canvas;
	if (c == null) return;
	c.drawImage(src,clipX,clipY,clipWidth,clipHeight,destX,destY,width,height);
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#captureImage(eve.fx.Image, int, int, int, int)
 */
public boolean captureImage(Image dest, int x, int y, int width, int height) {
	return false;
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#moveImage(int, int, int, int, int, int)
 */
public boolean moveImage(int srcX, int srcY, int srcWidth, int srcHeight, int destX, int destY) {
	EveCanvas c = _canvas;
	if (c == null) return false;
	return c.moveImage(srcX, srcY, srcWidth, srcHeight, destX,  destY);
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#canCapture()
 */
public boolean canCapture() {
	return false;
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#canMove()
 */
public boolean canMove() {
	return true;
}
/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#specialOperation(int, java.lang.Object)
 */
public boolean specialOperation(int which, Object data) {
	// TODO Auto-generated method stub
	return false;
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#getCompatibleImage(int, int)
 */
public Image getCompatibleImage(int width, int height) throws IllegalArgumentException {
	return new Image(width,height);
}

}
//####################################################
