/*
 * Created on Feb 15, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import eve.sys.Event;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class SurfaceCustomEvent extends SurfaceEvent {

	public Event event;
}
//####################################################
