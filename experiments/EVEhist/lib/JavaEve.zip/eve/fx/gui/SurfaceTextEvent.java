package eve.fx.gui;


/**
 A SurfaceTextEvent is sent to an EditControl usually during or upon completion
 of a <b>native</b> text input.
 */
public class SurfaceTextEvent extends SurfaceEvent
{

/** 
	The event type for a text entered event.
*/
public static final int TEXT_ENTERED = 150;
/** 
	The event type for a text changed event.
*/
public static final int TEXT_CHANGED = 151;
/** 
	This is sent to the Window indicating that the input box has closed.
*/
//public static final int INPUT_CLOSED = 151;

public static final int TEXT_EVENT_FIRST = TEXT_ENTERED;
public static final int TEXT_EVENT_LAST = TEXT_CHANGED;//INPUT_CLOSED;
/**
	The text that was entered for a TEXT_ENTERED message.
*/
public String entered;

/**
	Extra flags for the entered data.
*/
public int flags;

/** 
This is used with the TEXT_ENTERED event and indicates that the input was not cancelled.
**/
public static final int FLAG_TEXT_WAS_ENTERED = 0x1;
/** 
This is used with the TEXT_ENTERED event and indicates that the input ended by the UP cursor key.
**/
public static final int FLAG_CLOSED_BY_UP_KEY = 0x2;
/** 
This is used with the TEXT_ENTERED event and indicates that the input ended by the DOWN cursor key.
**/
public static final int FLAG_CLOSED_BY_DOWN_KEY = 0x4;
/** 
This is used with the TEXT_ENTERED event and indicates that the input ended by the ENTER key.
**/
public static final int FLAG_CLOSED_BY_ENTER_KEY = 0x8;
/** 
This is used with the TEXT_ENTERED event and indicates that the input ended by the ENTER key.
**/
public static final int FLAG_CLOSED_BY_SOFT_KEY = 0x10;
/** 
This is used with the TEXT_ENTERED event and indicates that the input ended by the ENTER key.
**/
//public static final int FLAG_CLOSED = 0x20;
public NativeInputParameters inputParameters;

}

