/*
 * Created on Apr 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import java.util.Hashtable;
import java.util.Vector;

import eve.fx.Color;
import eve.fx.Dimension;
import eve.fx.Font;
import eve.fx.FontMetrics;
import eve.fx.FontMetricsCache;
import eve.fx.Fx;
import eve.fx.Graphics;
import eve.fx.ISurface;
import eve.fx.Image;
import eve.fx.Metrics;
import eve.fx.Picture;
import eve.fx.PixelBuffer;
import eve.fx.Rect;
import eve.sys.Cache;
import eve.sys.Device;
import eve.sys.DeviceIcon;
import eve.sys.Event;
import eve.sys.Gate;
import eve.sys.ITaskbarEntry;
import eve.sys.ImageData;
import eve.sys.TimeOut;
import eve.sys.Vm;
import eve.util.mString;

/**
 * This class represents the platforms display object - for example a Window in Windows/Win32
 * or the entire screen on smaller devices.
 * <p>
 * The WindowSurface also is responsible for generating UI events like keyboard and pen/mouse
 * events as well as paint and resize events.
 * 
 * @author Michael L Brereton
 *
 */
//####################################################
public abstract class WindowSurface implements ISurface, WindowConstants, SIPConstants {
	
int nativeWindow;
private Object reusedEvents;
private RawEvent rawEvent;
protected int screenId;
//private EventDispatcher dispatcher;// = new EventDispatcher();
protected boolean amClosed, amCreated;

private static Vector openWindows = new Vector();
private static Vector modalWindows = new Vector();
private static WindowSurface modalWindow;

int rotation = 0;// ROTATION_180;//ROTATION_270;

public static boolean noCloseButtons = false;
public static boolean invisibleMousePointer = false;

public synchronized static void shutdown()
{
	openWindows.clear();
	modalWindows.clear();
	modalWindow = null;
	mainSurface = null;
}
private static Gate windowsLock = new Gate();

public Object applicationWindow;

public Object getNativeDrawable()
{
	return new Integer(nativeWindow);
}
public int getSurfaceType(){return WINDOW_SURFACE;}
/**
 * MainSurface should be the first surface created.
 */	
protected static WindowSurface mainSurface;
/**
 * This returns the MainSurface to be used by the application. This should be
 * created before any other processing gets done.
 * @return the MainSurface to be used by the application.
 */
public static WindowSurface getMainSurface()
{
	return mainSurface;
}

public static String defaultWindowTitle = "Eve Gui Application";

protected void createDefault()
{
	WindowCreationData wcd = new WindowCreationData();
	wcd.flagsToClear |= FLAG_IS_VISIBLE;
	wcd.flagsToSet |= FLAG_IS_DEFAULT_SURFACE;
	wcd.title = Fx.getDefaultWindowTitle();
	if (wcd.title == null)
		wcd.title = defaultWindowTitle;
	create(wcd);
}

public static WindowSurface createDefaultWindow()
{
	if (mainSurface != null) return mainSurface;
	WindowSurface ws = getNew();
	ws.createDefault();
	return ws;
}
protected WindowSurface()
{
	synchronized(WindowSurface.class){
		if (mainSurface == null){
			mainSurface = this;
		}
	}
}

public static Gate getWindowsLock()
{
	return windowsLock;
}
/**
 * This posts a copy of the data in the RawEvent. After the call you can discard
 * or re-use the RawEvent.
 * @param event the event to post.
 */
public abstract void postRawEvent(RawEvent event);

public abstract void requestRepaint(int x, int y, int width, int height, boolean dontMerge);

public abstract boolean hasPendingEvents();

protected abstract boolean getRawEvent(long howLongToWait,RawEvent destination) throws InterruptedException;

//int num = 0;
//boolean lastWasDown = false;
//int ky = 0;
static int eventNumber;
/**
 * This calls handleWindowEvents(int minTime, int maxTime)
 * with a min time of 100ms an a maxTime of 1 second.
 */
/*
public static void handleWindowEvents()
{
	handleWindowEvents(10,1000);
}
*/
/**
 * Put the current Thread to sleep to allow window events to be handled.
 * @param minTime the minimum time to wait.
 * @param maxTime the maximum time to wait.
 */
/*
public static void handleWindowEvents(int minTime, int maxTime)
{
	long now = System.currentTimeMillis();
	int ev = eventNumber;
	while(true){
		try{
			Thread.sleep(minTime);
		}catch(InterruptedException e){
			return;
		}
		if (ev == eventNumber) return;
		if (System.currentTimeMillis()-now >= maxTime) return;
	}
}
*/
/**
 * This returns a re-used RawEvent.
 * @param howLongToWait how long to wait before returning.
 * @return a re-used RawEvent or null on time out. Copy the event if  you need to keep it - the next call
 * to getRawEvent() will overwrite it.
 * @throws InterruptedException if the thread was interrupted. 
 */
public RawEvent getRawEvent(TimeOut howLongToWait) throws InterruptedException
{
	try{
	if (rawEvent == null) rawEvent = new RawEvent();
	//rawEvent = new RawEvent();
	while(true){
		long toWait = howLongToWait == null ? -1 : howLongToWait.remaining();
		if (!getRawEvent(toWait,rawEvent.zero())) return null;
		rawEvent.surface = this;
		WindowSurface m = modalWindow;
		int nc = nativeDialogCount;
		int revt = rawEvent.rawEventType;
		int surft = rawEvent.surfaceEventType;
		if (revt == RawEvent.WINDOW_EVENT && surft == SurfaceWindowEvent.APP_TO_FRONT){
			return rawEvent;
		}
		if ((getFlags() & FLAG_ALWAYS_ENABLED) != 0){
			nc = 0;
			m = null;
		}
		//System.out.println(revt+" = "+surft);
		try{
			if (revt == RawEvent.TASKBAR_ICON_EVENT){
				ITaskbarEntry it = (ITaskbarEntry)taskbarEntries.get(new Integer(rawEvent.key));
				if (it == null) continue;
				it.getEventDispatcher().dispatch(rawEvent.convertToSurfaceEvent());
				continue;
			}
			if (simulateSIP()){
				if (revt == RawEvent.SIP_EVENT){
					sipChanged(surft);
				}else if (rawEvent.data instanceof SurfaceSIPEvent){
					sipChanged(((SurfaceSIPEvent)rawEvent.data).type);
				}
			}
			/*
			if (revt == RawEvent.KEY_EVENT){
				//System.out.println("RK:"+(++ky));
				continue;
			}
			*/
			if (revt == RawEvent.TEXT_EVENT){
				rawEvent.context = currentNativeInput;
				if (surft == SurfaceTextEvent.TEXT_ENTERED){
					exitNativeDialog();
					currentNativeInput = null;
				}
			}
			
			if (nc != 0 || (m != null && m != this)){
				if (revt == RawEvent.PAINT_EVENT || revt == RawEvent.RESIZE_EVENT || revt == RawEvent.TEXT_EVENT)
					return rawEvent;
				if (revt == RawEvent.POINTER_EVENT && (surft == SurfacePointerEvent.PEN_UP || surft == SurfacePointerEvent.PEN_MOVE)){
					if (nc == 0 && m != null) {
						//System.out.println("To front!");
						m.setState(STATE_TO_FRONT);
					}
					continue;
				}
				if (revt == RawEvent.CUSTOM_EVENT){
					return rawEvent;
				}
				if (revt == RawEvent.WINDOW_EVENT && surft == SurfaceWindowEvent.APP_TO_FRONT){
					return rawEvent;
				}
				continue;
			}else if (revt == RawEvent.WINDOW_EVENT && surft == SurfaceWindowEvent.ACTIVATE){
				takeKeyFocus();
			}
		}catch(Exception e){}
		if (m != null && revt == RawEvent.WINDOW_EVENT && surft == SurfaceWindowEvent.ACTIVATE){
			checkModalActive(this);
		}
		return rawEvent;
	}	
	}finally{
		eventNumber++;
		//System.out.println("EV: "+eventNumber);
	}
}

protected abstract void takeKeyFocus();

public SurfaceEvent getReusedSurfaceEvent(TimeOut howLongToWait) throws InterruptedException 
{
	if (reusedEvents == null) reusedEvents = RawEvent.createReusableEvents();
	if (rawEvent == null) rawEvent = new RawEvent();
	long toWait = howLongToWait == null ? -1 : howLongToWait.remaining();
	if (!getRawEvent(toWait,rawEvent)) return null;
	return rawEvent.convertToReusableSurfaceEvent(reusedEvents);
}

/*

private synchronized EventDispatcher getEventDispatcher(EventListener toAdd)
{
	if (dispatcherThread == null){
		dispatcher = new EventDispatcher();
		if (toAdd != null) dispatcher.addListener(toAdd);
		dispatcher.dontUseSeparateThread = true;
		dispatcherThread = new Thread(){
			public void run(){
				while(true){
					synchronized(WindowSurface.this){
						if (dispatcherThread != this) break;
					}
					try{
						SurfaceEvent se = getReusedSurfaceEvent(TimeOut.Forever);
						if (se == null) break; //Only should be if it is closed.
						
						if (se instanceof SurfaceCustomEvent){
							SurfaceCustomEvent sce = (SurfaceCustomEvent)se;
							if (sce.event == null) eventBuffer.onEvent(se);
							else eventBuffer.onEvent(sce.event);
						}else
							eventBuffer.onEvent(se);
					}catch(InterruptedException e){
						
					}
				}
			}
		};
		dispatcherThread.start();
	}else{
		if (toAdd != null) dispatcher.addListener(toAdd);
	}
	return dispatcher;
}
*/
public void postEvent(Event ev)
{
	if (ev == null) return;
	RawEvent re = (RawEvent)Cache.get(RawEvent.class);
	re.zero();
	re.rawEventType = RawEvent.CUSTOM_EVENT;
	re.data = ev;
	postRawEvent(re);
	re.cache();
}
/*
public void addListener(EventListener ln)
{
	getEventDispatcher(ln);
}
public void removeListener(EventListener ln)
{
	getEventDispatcher(null).removeListener(ln);
}
*/
protected static int nativeDialogCount;

public static int getNativeDialogCount()
{
	return nativeDialogCount;
}
/*
public void postWindowEvent(int type)
{
	SurfaceWindowEvent we = new SurfaceWindowEvent();
	we.target = this;
	we.type = type;
	dispatcher.dispatch(we);
}
*/
/**
 * Call this if you are calling a method that brings up a non-blocking native dialog.
 * This should block all GUI events to the Eve GUI but still allow repaint events to
 * get through. For every call to enterNativeDialog() there must ge a call to exitNativeDialog().
 */
public synchronized static void enterNativeDialog()
{
	nativeDialogCount++;
}
/**
 * Call this when a native dialog box has been closed. 
 * For every call to enterNativeDialog() there must ge a call to exitNativeDialog().
 */
public synchronized static void exitNativeDialog()
{
	if (nativeDialogCount > 0) nativeDialogCount--;
}
/**
 * Returns whether enterNativeDialog() has been called but no matching exitNativeDialog()
 * has been called.
 */
public synchronized static boolean inNativeDialog()
{
	return nativeDialogCount > 0;
}
/**
 * Returns if the underlying system supports multiple windows for an application.
 */
public static boolean supportsMultiple()
{
	return NativeWindowSurface.supportsMultiple();
}

/**
 * Returns if it is possible to copy pixel data <b>from</b> a window.
 */
public static boolean canCopyFrom()
{
	return NativeWindowSurface.canCopyFrom();
}


/**
 * Create a new native WindowSurface.
 * @return a new native WindowSurface.
 */
public static WindowSurface getNew()
{
	return new NativeWindowSurface();
}
/**
 * Returns if this Window has been closed.
 */
public boolean isClosed()
{
	return amClosed;
}

Thread dispatcherThread;

void closed()
{
	windowsLock.synchronize(); try{
		openWindows.remove(this);
		while(true){
			int idx = modalWindows.indexOf(this);
			if (idx == -1) break;
			modalWindows.removeElementAt(idx);
		}
		modalWindow = modalWindows.size() == 0 ? null : (WindowSurface)modalWindows.elementAt(0);
	}finally{
		windowsLock.unlock();
	}
	synchronized(this){
		if (dispatcherThread != null) try{
			dispatcherThread.interrupt();
		}catch(SecurityException e){}
		dispatcherThread = null;
	}
}

public static WindowSurface getModal()
{
	return modalWindow;
}
public static boolean modalWindowHasPendingEvents()
{
	WindowSurface ws = modalWindow;
	if (ws == null) return false;
	return ws.hasPendingEvents();
}
public WindowSurface getModalWindow()
{
	windowsLock.synchronize(); try{
	if (modalWindows.size() == 0) return null;
	return (WindowSurface) modalWindows.elementAt(modalWindows.size()-1);
	}finally{
		windowsLock.unlock();
	}
}
public void setModal(boolean modalOn)
{
	//new Exception("Modal: "+modalOn).printStackTrace();
	windowsLock.synchronize(); try{
		if (amClosed && modalOn) return;
		if (modalOn){
			modalWindows.insertElementAt(this,0);
			modalWindow = this;
		}else{
			int idx = modalWindows.indexOf(this);
			if (idx == -1) return;
			modalWindows.removeElementAt(idx);
			if (modalWindow == this)
				modalWindow = modalWindows.size() == 0 ? null : (WindowSurface)modalWindows.elementAt(0);
		}
		if (modalWindow != null)
			modalWindow.setState(STATE_TO_FRONT);
	}finally{
		windowsLock.unlock();
	}
}
public static void checkModalActive(WindowSurface who)
{
	windowsLock.synchronize(); try{
		if (modalWindow != null && modalWindow != who){
			modalWindow.setState(STATE_TO_FRONT);
		}else{
			
		}
	}finally{
		windowsLock.unlock();
	}
}
protected abstract void doCreate(WindowCreationData wcd);
static DeviceIcon eveIcon = Device.toDeviceIcon("eve/evesmall.png");

/**
 * This will create the actual system Window.
 * @param wco parameters for creation.
 */
public void create(WindowCreationData wco)
{
	rotation = Device.getScreenRotation();
	if (amCreated) return;
	if (noCloseButtons){
		wco.flagsToClear |= FLAG_HAS_CLOSE_BUTTON;
		wco.flagsToSet &= ~FLAG_HAS_CLOSE_BUTTON;
	}
	doCreate(wco);
	amCreated = true;
	if (wco.icon != null)
		setIcon(wco.icon);
	else
		setIcon(eveIcon);
	if ((wco.flagsToSet & FLAG_ACCEPTS_DROPPED_FILES)!=0)
		acceptDroppedFiles(true);
	windowsLock.synchronize(); try{
		openWindows.add(this);
	}finally{
		windowsLock.unlock();
	}
	if (invisibleMousePointer){
		setCursor(Cursor.INVISIBLE_CURSOR);
	}
}

protected abstract void doClose();

public final void close()
{
	windowsLock.synchronize(); try{
		doClose();
		amClosed = true;
		closed();
	}finally{
		windowsLock.unlock();
	}
}
public abstract void setState(int newState);
public abstract int getState();
public void setVisible(boolean visible)
{
	setFlags(0,FLAG_IS_VISIBLE);
}
public boolean isVisible()
{
	return (setFlags(0,0) & FLAG_IS_VISIBLE) != 0;
}
/**
 * Get the bounds of the full window in the screen.
 * @param dest a non-null destination Rect.
 * @return true if succeeded, false if not.
 */
public abstract boolean getBounds(Rect dest);
/**
 * Get the rect of the client area within the full window.
 * @param dest a non-null destination Rect.
 * @return true if succeeded, false if not.
 */
public abstract boolean getClientRect(Rect dest);
public abstract boolean setBounds(int x, int y, int width, int height);
public abstract boolean setClientRect(int x, int y, int width, int height);
public abstract boolean getScreenRect(int screenId,Rect dest,boolean desktopOnly);

/**
 * If the Window is a child window, this returns the size of the
 * parent Window.
 * @param dest a non-null destination Dimension object.
 * @return true if the Window is a child window, false if it is not.
 */
public abstract boolean getParentSize(Dimension dest);
/**
 * Set or get the Flags for a Window.
 * @param flagsToSet Flags to set.
 * @param flagsToClear Flags to clear.
 * @return the new value of the Flags.
 */
public abstract int setFlags(int flagsToSet, int flagsToClear);

/**
 * Get the Flags for a Window.
 * @return the value of the Flags.
 */
public int getFlags()
{
	return setFlags(0,0);
}
/**
 * This is used during Window creation. It asks the underlying Window
 * what flags would be apply to a Window if it were created for the
 * requestedWidth and requestedHeight, with the specified Flags requested
 * to be set and cleared.
 * @param requestedWidth the desired width of the Window.
 * @param requestedHeight the desired height of the Window.
 * @param requestedSetFlags the Flags to be set.
 * @param requestedClearFlags the Flags to be cleared.
 * @return the Flags that would apply (e.g. FLAG_IS_DEFAULT_SIZE, FLAG_HAS_TITLE)
 */
public abstract int getFlagsForSize( int requestedWidth, int requestedHeight,int requestedSetFlags, int requestedClearFlags);
/**
 * Return the current press state of a particular key or mouse button at this instant
 * in time.
* @param keyCode One of the eve.fx.gui.IKeys constants.
* @return If the key is pressed the value will have bit 0x8000 set and if the key has been pressed
* since the last call the 0x0001 bit will be set.
* @see eve.fx.gui.IKeys
 */
public abstract int getAsyncKeyState(int whichKey);
/**
 * Get the mouse pointer state at this point in time. This includes its position
 * and button states.
 * @param destination a destination SurfacePointerEvent to hold the current mouse state.
 * @return true on success, false if the asynchronous state is not available. In this
 * case only the mouse pointer events can be used to track the mouse state.
 */
//public abstract boolean getAsyncPointerState(SurfacePointerEvent destination);

public abstract boolean setIcon(DeviceIcon icon);
public abstract boolean setTaskbarIcon(DeviceIcon icon);

public abstract Object getDroppedData(int dataID);
public abstract Font getFont();
public abstract boolean setFont(Font font);

/**
 * Set or get the GUI Flags for the device.
 * @param flagsToSet flags to set.
 * @param flagsToClear flags to clear.
 * @return the new value of the GUI flags.
 */
public abstract int setGuiFlags(int flagsToset, int flagsToClear);
/**
 * Get the GUI Flags for the device.
 * @return the value of the GUI flags.
 */
public int getGuiFlags() {return setGuiFlags(0,0);}

/**
 * Get the title text of the window.
 */
public abstract String getTitle();
/**
 * Set the title text of the window.
 * @param title the new title for the window.
 */
public abstract void setTitle(String title);

/**
 * Get the size of the screen this Window is displayed in.
 * @param dest a non-null destination Rect.
 * @param desktopOnly true to get the Rect representing the desktop area of the screen.
 * @return true if successful, false if not.
 */
public final boolean getScreenRect(Rect dest,boolean desktopOnly)
{
	return getScreenRect(screenId,dest,desktopOnly);
}
private static Rect srRect = new Rect();
/**
 * Get the size of the screen this Window is displayed in.
 * @param dest a non-null destination Dimension.
 * @return true if successful, false if not.
 */
public final boolean getScreenRect(Dimension dest)
{
	synchronized(srRect){
		if (!getScreenRect(srRect,false)) return false;
		dest.set(srRect.width,srRect.height);
		return true;
	}
}

/**
 * Get the IDs of all the screens supported on the device. At the least this will
 * return an array with a single element of a value 0 in it.
 */
public int[] getScreenIds(){return new int[]{0};}
public abstract Object getInfo(int infoCode, Object parameters, Object destination, int options);
public abstract boolean setInfo(int infoCode, Object parameters, int options);
/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#getSIP()
 */
public int getSIP() {
	return getSIP(this);
}

/* (non-Javadoc)
 * @see eve.fx.gui.WindowSurface#setSIP(int)
 */
public void setSIP(int value) {
	setSIP(value,this);
}
public abstract int captureAppKeys(int options);
protected abstract boolean doCaptureMouse(boolean doGrab);

private int captureDepth = 0;
/**
 * For every call with doGrab is true there must be a matching one with
 * doGrab being false.
 * @param doGrab true to capture the mouse, false to release it.
 * @return true if the capture/release was successful.
 */
public boolean captureMouse(boolean doGrab)
{
	if (doGrab){
		if (captureDepth == 0)
			if (!doCaptureMouse(true)) return false;
		captureDepth++;
		return true;
	}else{
		if (captureDepth == 0) return false;
		captureDepth--;
		if (captureDepth == 0)
			return doCaptureMouse(false);
		return true;
	}
}
private static boolean cursorsLoaded = false;
private static Hashtable cursors = new Hashtable();
private static cursorEntry search = new cursorEntry(0);
private static int numCursors = Cursor.LAST_CURSOR+1;
private static void loadCursors()
{
	Object def = loadCursor(Cursor.DEFAULT_CURSOR);
	if (def != null) cursors.put(new cursorEntry(Cursor.DEFAULT_CURSOR),def);
	for (int i = 0; i <= Cursor.LAST_CURSOR; i++){
		if (i == Cursor.DEFAULT_CURSOR) continue;
		Object got = loadCursor(i);
		try{
			if (got == null) switch(i){
				case Cursor.HAND_CURSOR:
					got = NativeWindowSurface.createACursor(new Picture("eve/HandCursor.png"),8,0); break;
				case Cursor.BUSY_CURSOR:
					got = NativeWindowSurface.createACursor(new Picture("eve/BusyCursor.png"),0,0); break;
				case Cursor.LEFT_RIGHT_CURSOR:
					got = NativeWindowSurface.createACursor(new Picture("eve/LeftRightCursor.png"),10,4); break;
				case Cursor.UP_DOWN_CURSOR:
					got = NativeWindowSurface.createACursor(new Picture("eve/UpDownCursor.png"),4,10); break;
				case Cursor.COPY_MULTIPLE_CURSOR:
					got = NativeWindowSurface.createACursor(new Picture("eve/CopyMultipleCursor.png"),0,0); break;
				case Cursor.COPY_SINGLE_CURSOR:
					got = NativeWindowSurface.createACursor(new Picture("eve/CopySingleCursor.png"),0,0); break;
				case Cursor.DRAG_MULTIPLE_CURSOR:
					got = NativeWindowSurface.createACursor(new Picture("eve/DragMultipleCursor.png"),0,0); break;
				case Cursor.DRAG_SINGLE_CURSOR:
					got = NativeWindowSurface.createACursor(new Picture("eve/DragSingleCursor.png"),0,0); break;
				case Cursor.DONT_DROP_CURSOR:
					got = NativeWindowSurface.createACursor(new Picture("eve/DontDropCursor.png"),0,0); break;
				case Cursor.INVISIBLE_CURSOR:
					PixelBuffer pb = new PixelBuffer(32,32);
					got = NativeWindowSurface.createACursor(pb,0,0); 
					break;
			}
		}catch(Throwable t){}
		if (got == null) got = def;
		if (got != null)
			cursors.put(new cursorEntry(i),got);
	}
}
private static Object loadCursor(int which)
{
	return NativeWindowSurface.loadCursor(which);
}
abstract boolean setCursor(Object cursor);
private static Object lookupCursor(int cursor)
{
	synchronized(cursors){
		if (!cursorsLoaded) {
			cursorsLoaded = true;
			loadCursors();
		}
		return cursors.get(search.set(cursor));
	}
}
/**
 * Set the mouse pointer to be a particular cursor.
 * @param cursor one of the Cursor.XXX_CURSOR values or a value returned by Device.createCursor(). 
 * @return true if successful, false if not.
 */
public boolean setCursor(int cursor)
{
	//new Exception(""+cursor).printStackTrace();
	//System.out.println("SC: "+Cursor.WAIT_CURSOR+", "+cursor);
	//if (cursor == Cursor.WAIT_CURSOR) new Exception().printStackTrace();
	if (invisibleMousePointer && cursor != Cursor.INVISIBLE_CURSOR)
		return true;
	return setCursor(lookupCursor(cursor));
}
/**
 * Create a Cursor that can be used with WindowSurface.setCursor().
 * @param image an image to be used as the cursor.
 * @return
 */
public static int createCursor(ImageData image, int hotspotX, int hotspotY)
{
	if (image == null) throw new NullPointerException();
	synchronized(cursors){
		if (!cursorsLoaded) {
			cursorsLoaded = true;
			loadCursors();
		}
		Object got = NativeWindowSurface.createACursor(image,hotspotX,hotspotY);
		int me = ++numCursors;
		cursors.put(new cursorEntry(me),got);
		return me;
	}
}

abstract int setCursorArea(int id, int x, int y, int width, int height, Object cursor);

/**
 * Modify or create an area in the window that will be assigned a specific cursor
 * (mouse pointer). The window will automatically change the cursor to the specified
 * cursor <b>only if</b> no mouse button is pressed.
 * @param regionID set this to zero to add a new cursor region - the value returned
 * will be the new ID for this region.
 * @param x the x-location in the client area of the Window.
 * @param y the y-location in the client area of the Window.
 * @param width the width of the area.
 * @param height the height of the area.
 * @param cursor the cursor to use for the area.
 * @return the regionID or a new regionID if regionID is zero.
 */
public int setCursorRegion(int regionID,int x, int y, int width, int height, int cursor)
{
	return setCursorArea(0,x,y,width,height,lookupCursor(cursor));
}

/**
 * Remove all set cursor regions. 
 */
public abstract void clearCursorRegions();
/**
 * Remove the specified cursor region.
 * @param regionID the ID of the cursor region as returned by setCursorRegion.
 */
public abstract void removeCursorRegion(int regionID);

//public abstract void setSIP(int SIPValue, WindowSurface target);
//public abstract int getSIP(WindowSurface target);

/**
 * If no SIP is supported this should throw a runtime exception or error.
 * @param win the window to get/set the sip for.
 * @param sipValue a SIP value - if this is -1 it is a getSIP() operation.
 * @return the value of the SIP. the return value is ignored if sipValue is not -1.
 */
protected int nativeGetSetSIP(WindowSurface win,int sipValue)
{
	throw new NoSuchMethodError();
}

static boolean sipOn = false;
static boolean SipLocked = false, SipFrozen = false;

private static boolean simulateSIP()
{
	return Vm.getParameter(Vm.SIMULATE_SIP) != 0;
}
private static void sipChanged(int type)
{
	sipOn = type == SurfaceSIPEvent.SIP_SHOWN;
}
public int getSIP(WindowSurface win)
{
	if (sipCheck != 0) try{
		return nativeGetSetSIP(win,-1);
	}catch(Throwable t){
		sipCheck = 0;
	}
	return sipOn ? SIP_IS_ON : 0;
}
public abstract ITaskbarEntry doCreateTaskbarEntry();

static Hashtable taskbarEntries = new Hashtable();

public ITaskbarEntry createTaskbarEntry()
{
	ITaskbarEntry te = doCreateTaskbarEntry();
	if (te == null) return null;
	taskbarEntries.put(new Integer(te.hashCode()),te);
	return te;
}
private static int sipCheck = -1;
public void setSIP(int mode, WindowSurface win)
{
	boolean db = false;
	if (db) System.out.println("setSIP: "+mode+"->"+sipOn);
	try{
		//if ((mode & SIP_ON) == 0) Vm.debugStackTrace();
		//System.out.println(Integer.toHexString(mode)+", "+SipLocked+", "+SipFrozen);
		if (win == null) win = this;
		int width = 0;
		int type = SurfaceSIPEvent.SIP_HIDDEN;
		int par = mode;
		if ((par & SIP_FREEZE) != 0) {
			SipLocked = false;
			SipFrozen = true;
		}else if ((par & SIP_UNFREEZE) != 0){
			SipFrozen = SipLocked = false;
			return;
		}
		if ((par & (SIP_ON|SIP_LEAVE_BUTTON)) == 0) {
			//
			// Must be requesting to switch it off.
			//
			if (((par & SIP_LOCK) == 0) && SipLocked) return;
			SipLocked = false;
			//Vm.debugStackTrace();
			if (sipCheck != 0) try{
				nativeGetSetSIP(win,(par & SIP_REMOVE_BUTTON));
				return;
			}catch(Throwable t){
				sipCheck = 0;
			}
			if (!sipOn) return;
			sipOn = false;
		}else{ 
			//
			//Must be requesting to switch it on.
			//
			SipLocked = (par & SIP_LOCK) != 0;
			if((par & SIP_ON) != 0){
				if (sipCheck != 0) try{
					nativeGetSetSIP(win,(par & (SIP_ON|SIP_LEAVE_BUTTON)));
					return;
				}catch(Throwable t){
					sipCheck = 0;
				}
				if (sipOn) return;
				sipOn = true;
				Rect r = new Rect();
				win.getClientRect(r);
				//GetClientRect(curHWnd,&r);
				type = SurfaceSIPEvent.SIP_SHOWN;
				width = r.width;
			}else if ((par & SIP_LEAVE_BUTTON) != 0){
				if (sipCheck != 0) try{
					nativeGetSetSIP(win,SIP_LEAVE_BUTTON);
					return;
				}catch(Throwable t){
					sipCheck = 0;
				}
			}else
				return;
		}
		if (!simulateSIP()) return;
		Dimension d = new Dimension();
		win.getScreenRect(d);
		int vh = 214;
		//if (d.height > 500) vh *= 2;
		if (d.height < 320 || d.height > 500) vh = (d.height*2)/3;
		RawEvent re = new RawEvent();
		re.rawEventType = RawEvent.SIP_EVENT;
		re.surfaceEventType = type;
		re.y = vh;
		re.width = width;
		re.height = vh;
		win.postRawEvent(re);
		if (db) System.out.println("SIP: "+mode+"->"+sipOn);
		//Vm.debugStackTrace();
	}finally{
		/*
		if (mode == 0 || mode == 1){
			new Exception().printStackTrace();
		}
		System.out.println("SIP: "+mode+"->"+sipOn);
		 
		 */
	}
}
private FontMetricsCache fms;
public synchronized FontMetrics getFontMetrics(Font f)
{
	if (fms == null) fms = new FontMetricsCache();
	return fms.get(f,this);
}

public static boolean inNativeTextInput()
{
	return currentNativeInput != null;
}
private static NativeInputParameters currentNativeInput;

public abstract boolean specialOperation(int which, Object data);

protected int doStartNativeInput(NativeInputParameters nip) throws Exception
{
	throw new NoSuchMethodError();
}

//public abstract void requestPaint(int x, int y, int width, int height);
public boolean startNativeInput(NativeInputParameters nip)
{
	synchronized(WindowSurface.class){
		if (currentNativeInput != null)
			return false;
		currentNativeInput = nip;
	}
	try{
		enterNativeDialog();
		nip.nativeInputController = doStartNativeInput(nip);
		return true;
	}catch(Throwable t){
		//t.printStackTrace();
		exitNativeDialog();
		currentNativeInput = null;
		return false;
	}
}
/**
 * Use this to enable or disable the accepting of dropped files.
 * @param accept true to enable, false to disable.
 */
public void acceptDroppedFiles(boolean accept)
{
	setState(accept ? STATE_ACCEPT_DROPPED_FILES : STATE_REJECT_DROPPED_FILES);
}
private static boolean bufferedTest = true;
private static void paintTestWindow(Graphics gg, WindowSurface w, Object[] text, FontMetrics fm, Rect paintArea, Rect circle)
{
	Rect r = paintArea;
	if (gg != null){
		gg.setColor(Color.LightBlue);
		gg.fillRect(r.x,r.y,r.width,r.height);
		if (text != null){
			gg.setColor(Color.Black);
			Rect b = Rect.getCached(); 
			w.getClientRect(b);
			b.x = b.y = 0;
			Metrics.drawText(gg, fm, text, b, Graphics.CENTER, Graphics.CENTER);
			b.cache();
		}
		if (circle != null){
			gg.setColor(Color.DarkBlue);
			gg.fillEllipse(circle.x, circle.y, circle.width, circle.height);
		}
		return;
	}
	Graphics wg = null;
	try{
		if (!bufferedTest) 
			wg = w.getGraphics();
	}catch(UnsupportedOperationException e){}
	if (wg == null){
		Image im = w.getCompatibleImage(r.width,r.height);
		Graphics g = new Graphics(im);
		g.translate(-r.x, -r.y);
		paintTestWindow(g,w,text,fm,paintArea,circle);
		g.free();
		w.drawImage(im, r.x, r.y, r.width, r.height, r.x, r.y, r.width, r.height);
		im.free();
	}else{
		paintTestWindow(wg,w,text,fm,paintArea,circle);
		wg.free();
	}
	
}
public static void eveMain(String[] args)
{
	WindowCreationData wcd = new WindowCreationData();
	wcd.setForDefaultSurface(FLAG_IS_VISIBLE, 0);
	wcd.title = "Test Window";
	wcd.bounds = new Rect(0,0,200,200);
	getNew().create(wcd);
}
private static final int NOT_DRAGGING = -1000;

private static void toCircleArea(int x, int y, Rect dest)
{
	dest.set(x-7,y-7,14,14);
}
public static void main(String[] args)
{
	Vm.startEve(args);
	if (args.length != 0){
		if (args[0].equals("-unbuffered"))
			bufferedTest = false;
		else if (args[0].equals("-buffered"))
			bufferedTest = true;
	}
	WindowSurface w = getMainSurface();
	// If this is only emulating a single window system then
	// the main window may be invisible.
	w.setVisible(true);
	int ww = 0, wh = 0;
	Font f = new Font("sans",Font.PLAIN,16);
	FontMetrics fm = w.getFontMetrics(f);
	String [] text = mString.split(
			"Eve Virtual Machine\nVersion "+Vm.getVersion()+"\nwww.ewesoft.com"
			,'\n');
	SurfacePaintEvent spe = new SurfacePaintEvent();
	spe.window = w;
	SurfacePaintEvent repaintNow = null;
	int lastX = NOT_DRAGGING, lastY = NOT_DRAGGING;
	Rect repaintArea = new Rect();
	Rect circleArea = null;
	while(true){
		try{
			SurfaceEvent se = repaintNow;
			repaintNow = null;
			if (se == null) se = w.getReusedSurfaceEvent(TimeOut.Forever);
			if (se instanceof SurfacePaintEvent){
				SurfacePaintEvent sp = (SurfacePaintEvent)se;
				repaintArea.set(sp.x,sp.y,sp.width,sp.height);
				paintTestWindow(null,w, text, fm, repaintArea, circleArea);
			}else if (se instanceof SurfaceResizeEvent){
				SurfaceResizeEvent sr = (SurfaceResizeEvent)se;
				ww = sr.newWidth;
				wh = sr.newHeight;
				if (ww > 0 && wh > 0){
					repaintArea.set(0,0,ww,wh);
					paintTestWindow(null,w, text, fm, repaintArea, circleArea);
				}
			}else if (se instanceof SurfacePointerEvent){
				SurfacePointerEvent sp = (SurfacePointerEvent)se;
				if (sp.type == sp.PEN_DOWN){
					circleArea = new Rect();
					lastX = sp.x;
					lastY = sp.y;
					toCircleArea(lastX,lastY,circleArea);
					repaintArea.set(circleArea);
					paintTestWindow(null,w, text, fm, repaintArea, circleArea);
				}else if (sp.type == sp.PEN_MOVE && circleArea != null){
					toCircleArea(lastX,lastY,repaintArea);
					lastX = sp.x;
					lastY = sp.y;
					toCircleArea(lastX,lastY,circleArea);
					repaintArea.unionWith(circleArea);
					paintTestWindow(null,w, text, fm, repaintArea, circleArea);
				}else if (sp.type == sp.PEN_UP){
					if (circleArea != null){
						toCircleArea(lastX,lastY,repaintArea);
						paintTestWindow(null,w, text, fm, repaintArea, null);
						circleArea = null;
					}
				}
			}else if (se instanceof SurfaceWindowEvent){
				SurfaceWindowEvent sw = (SurfaceWindowEvent)se;
				if (sw.type == sw.CLOSE) break;
			}else if (se instanceof SurfaceKeyEvent){
				SurfaceKeyEvent sk = (SurfaceKeyEvent)se;
				if (sk.type == sk.KEY_PRESS) break;
			}
		}catch(InterruptedException e){
			break;
		}
	}
	Vm.exit(0);
}
}
//####################################################

class cursorEntry {
	public int value;
	public int hashCode() {return value;}
	public cursorEntry(int v) {value = v;}
	public boolean equals(Object other){return ((cursorEntry)other).value == value;}
	public cursorEntry set(int v) {value = v; return this;}
}
