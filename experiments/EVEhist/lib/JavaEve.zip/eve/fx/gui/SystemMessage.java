package eve.fx.gui;

//##################################################################
public class SystemMessage{
//##################################################################
// DO NOT CHANGE OR MOVE THESE VARIABLES.
public int type;
public int wparam;
public int lparam;
public int time;
public int x;
public int y;
public int state;

public static final int REMOVED = 0x1;
public static final int PAINT                        = 0x000F;
public static final int MOUSEFIRST                   = 0x0200;
public static final int MOUSELAST                   = 0x020A;
public static final int KEYFIRST                     = 0x0100;
public static final int KEYLAST                      = 0x0108;
public static final int TIMER                        = 0x0113;
public static final int CALLBACK                     = 0x0401;

public boolean isMouse() {return type >= MOUSEFIRST && type <= MOUSELAST;}
public boolean isKey() {return type >= KEYFIRST && type <= KEYLAST;}
public boolean isPen() {return isMouse();}
public boolean isPaint() {return type == PAINT;}
public boolean isTimer() {return type == TIMER;}

//##################################################################
}
//##################################################################

