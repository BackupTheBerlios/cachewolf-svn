/*
 * Created on Aug 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface JavaSurface {

	public boolean wasShown();
}
//####################################################
