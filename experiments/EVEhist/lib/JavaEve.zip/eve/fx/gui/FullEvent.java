package eve.fx.gui;


//##################################################################
class FullEvent{
//##################################################################
int systemType;
int type;
int key;
int x;
int y;
int modifiers;
int timestamp;
Object who;
Object data;

public FullEvent(int s,Object obj)
{
	systemType = s;
	who = obj;
}
public FullEvent(int s,int t,int k,int xx, int yy,int m,int ts)
{
	systemType = s;
	type = t;
	key = k;
	x = xx;
	y = yy;
	modifiers = m;
	timestamp = ts;
}
//##################################################################
}
//##################################################################

