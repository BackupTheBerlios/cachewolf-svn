/*
 * Created on Aug 13, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface Cursor {

	//private Cursor(){}
	
	/**
	* This is the only one apart from DEFAULT_CURSOR you should use directly with
	* setCursor(). All others should be used with Control.setCursor().
	**/
	public static final int WAIT_CURSOR  = 1;
	public static final int IBEAM_CURSOR  = 2;
	public static final int HAND_CURSOR  = 3;
	public static final int CROSS_CURSOR  = 4;
	public static final int LEFT_RIGHT_CURSOR  = 5;
	public static final int UP_DOWN_CURSOR  = 6;
	/**
	* This cursor is an arrow and an hour glass. Use this when an individual component
	* will not respond because it is busy, but other components will work.
	**/
	public static final int BUSY_CURSOR = 7;
	public static final int DRAG_SINGLE_CURSOR = 8;
	public static final int DRAG_MULTIPLE_CURSOR = 9;
	public static final int COPY_SINGLE_CURSOR = 10;
	public static final int COPY_MULTIPLE_CURSOR = 11;
	public static final int DONT_DROP_CURSOR = 12;
	public static final int MOVE_CURSOR = 13;
	public static final int RESIZE_CURSOR = 14;
	public static final int INVISIBLE_CURSOR = 15;
	static final int LAST_CURSOR = INVISIBLE_CURSOR;
	/**
	* This means no <b>special</b> cursor - the same as DEFAULT_CURSOR;
	**/
	public static final int NO_CURSOR = 0;
	public static final int DEFAULT_CURSOR = 0;
	
}

//####################################################
