/*
 * Created on Aug 8, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseWheelEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.util.Vector;

import eve.fx.Graphics;
import eve.fx.Image;
import eve.fx.PixelBuffer;
import eve.fx.Rect;
import eve.sys.Countdown;
import eve.sys.Vm;
import eve.ui.event.KeyEvent;

//##################################################################
class MouseWheelListener implements java.awt.event.MouseWheelListener{
//##################################################################

EveCanvas wc;
MouseWheelListener(EveCanvas wc)
{
	this.wc = wc;
}
public void mouseWheelMoved(java.awt.event.MouseWheelEvent me)
{
	wc.handleEvent(me);
}

//##################################################################
}
//##################################################################

public class EveCanvas extends Panel implements ImageObserver
{
	/* (non-Javadoc)
	 * @see java.awt.image.ImageObserver#imageUpdate(java.awt.Image, int, int, int, int, int)
	 */
	public boolean imageUpdate(java.awt.Image arg0, int arg1, int arg2, int arg3, int arg4, int arg5) {
		// TODO Auto-generated method stub
		return true;
	}
	
public NativeWindowSurface win;

private void dispatchEvent(RawEvent ev)
{
	win.dispatchEvent(ev);
}
private RawEvent getRawEvent(int type, int surfaceType)
{
	RawEvent re = new RawEvent();
	re.rawEventType = type;
	re.surfaceEventType = surfaceType;
	return re;
}

Vector cursorAreas;
static Object lastSetCursor = null;
int cursorAreaId = 0;

synchronized void clearCursorAreas()
{
	lastSetCursor = null;
	cursorAreas = null;
	cursorAreaId = 0;
}

synchronized void removeCursorArea(int id)
{
	if (cursorAreas == null) return;
	for (int i = 0; i<cursorAreas.size(); i++){
		Object[] t = (Object[])cursorAreas.get(i);
		if (((Integer)t[2]).intValue() == id){
			cursorAreas.removeElementAt(i);
			return;
		}
	}
}
synchronized int addCursorArea(int id, int x, int y, int width, int height, java.awt.Cursor cursor)
{
	lastSetCursor = null;
	if (id == 0){ //Create a new area.
		if (cursorAreas == null) cursorAreas = new Vector();
		Object[] t = new Object[]{cursor,new Rect(x,y,width,height),new Integer(++cursorAreaId)};
		cursorAreas.insertElementAt(t,0);
		return cursorAreaId;
	}else{
		if (cursorAreas == null) return id;
		for (int i = 0; i<cursorAreas.size(); i++){
			Object[] t = (Object[])cursorAreas.get(i);
			if (((Integer)t[2]).intValue() == id){
				((Rect)t[1]).set(x,y,width,height);
				break;
			}
		}
		return id;
	}
}

synchronized void checkCursorAreas(int x, int y)
{
	if (cursorAreas == null) return;
	for (int i = 0; i<cursorAreas.size(); i++){
		Object[] t = (Object[])cursorAreas.get(i);
		Rect r = (Rect)t[1];
		if (r.isIn(x,y)){
			if (t[0] != lastSetCursor){
				lastSetCursor = t[0];
				//win.setCursor(lastSetCursor);
				setCursor((java.awt.Cursor)lastSetCursor);
			}
			break;
		}
	}
}
public boolean hasBeenShown = false;
public boolean hasBeenPainted = false;

{
	setLayout(null);
}
SystemMessage capture;
java.util.Vector queue = new java.util.Vector();

int msg = 0;

public java.awt.Dimension preferredSize;

public static boolean inCallback = true;

/*
public static boolean amInMessageThread()
{
	boolean ret = false;
	synchronized(Applet.uiLock){
		ret = inCallback;
	}
	return ret;
}
*/
/*
public java.awt.Dimension getPreferredSize() 
{
	if (preferredSize == null)
		return new java.awt.Dimension(Applet.currentApplet.width,Applet.currentApplet.height);
	else 
		return preferredSize;
}
*/
/*
		void handleEvent(java.awt.event.MouseWheelEvent event)
		{
			int type = 0;
			int key = 0;
			int x = 0;
			int y = 0;
			int modifiers = 0;
			if ((event.getModifiers() & event.SHIFT_MASK) > 0)
				modifiers |= IKeys.SHIFT;
			if ((event.getModifiers() & event.CTRL_MASK) > 0)
				modifiers |= IKeys.CONTROL;
			boolean isRight = (event.getModifiers() & event.META_MASK) != 0;
			boolean doPostEvent = false;
			int stype = 0;
			x = event.getX();
			y = event.getY();
			if (!checkModal()) return;
			stype = SystemMessage.MOUSEFIRST;
			type = event.getWheelRotation() < 0 ? PenEvent.SCROLL_UP : PenEvent.SCROLL_DOWN;
			doPostEvent = true;
			if (doPostEvent){
				int timestamp = (int)ewe.sys.Vm.getTimeStamp();//(int)event.when;
				addToQueue(new FullEvent(stype,type,key,x,y,modifiers,timestamp));
			}
		}
		void handleEvent(java.awt.event.MouseEvent event)
		{
			int type = 0;
			int key = 0;
			int x = 0;
			int y = 0;
			int modifiers = 0;
			if ((event.getModifiers() & event.SHIFT_MASK) > 0)
				modifiers |= IKeys.SHIFT;
			if ((event.getModifiers() & event.CTRL_MASK) > 0)
				modifiers |= IKeys.CONTROL;
			boolean isRight = (event.getModifiers() & event.META_MASK) != 0;
			boolean doPostEvent = false;
			int stype = 0;
			x = event.getX();
			y = event.getY();
			switch(event.getID()){
				case java.awt.event.MouseEvent.MOUSE_MOVED:
				case java.awt.event.MouseEvent.MOUSE_DRAGGED:
					if (!checkModal()) break;
					stype = SystemMessage.MOUSEFIRST;
					type = PenEvent.PEN_MOVE;
					doPostEvent = true;
					break;
				case java.awt.event.MouseEvent.MOUSE_PRESSED:
					if (!checkModal()) break;
					stype = SystemMessage.MOUSEFIRST;
					type = PenEvent.PEN_DOWN;
					if (isRight) modifiers |= PenEvent.RIGHT_BUTTON;
					setMouseState(isRight ? 0x2 : 0x1,0);
					doPostEvent = true;
					break;
				case java.awt.event.MouseEvent.MOUSE_RELEASED:
					stype = SystemMessage.MOUSEFIRST;
					type = PenEvent.PEN_UP;
					if (isRight) modifiers |= PenEvent.RIGHT_BUTTON;
					setMouseState(0,isRight ? 0x2 : 0x1);
					doPostEvent = true;
					break;
			}
			if (doPostEvent){
				int timestamp = (int)ewe.sys.Vm.getTimeStamp();//(int)event.when;
				addToQueue(new FullEvent(stype,type,key,x,y,modifiers,timestamp));
			}
		}
*/
public EveCanvas(final WindowSurface win)
	{
	this.win = (NativeWindowSurface)win;
	setFocusTraversalKeysEnabled(false);	
	try{
		addMouseWheelListener(new MouseWheelListener(this));
	}catch(Error e){
	}
	
	addComponentListener(new ComponentListener(){

		public void componentHidden(ComponentEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		public void componentMoved(ComponentEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		public void componentResized(ComponentEvent arg0) {
			//System.out.println("Resized!");
			RawEvent re = getRawEvent(RawEvent.RESIZE_EVENT,0);
			re.height = getHeight();
			re.width = getWidth();
			dispatchEvent(re);
		}

		public void componentShown(ComponentEvent arg0) {
			// This does not get called in a Window/Frame
			// TODO Auto-generated method stub
			//System.out.println("Shown!");
			
		}});
	addKeyListener(new java.awt.event.KeyListener(){
		int ky = 0;
		private void handle(java.awt.event.KeyEvent ev,int type)
		{
			SurfaceKeyEvent ke = new SurfaceKeyEvent();
			ke.type = type;
			newkey nk;
			int modifiers = 0;
			if ((ev.getModifiers() & java.awt.Event.SHIFT_MASK) > 0)
				modifiers |= IKeys.SHIFT;
			if ((ev.getModifiers() & java.awt.Event.CTRL_MASK) > 0)
				modifiers |= IKeys.CONTROL;
			
			if (ev.isActionKey())
				actionKeyValue(nk = new newkey(ev.getKeyCode(), modifiers));
			else
				keyValue(nk = new newkey(ev.getKeyChar(), modifiers));
				//keyValue(nk = new newkey(ev.getKeyCode(), ev.getModifiers()));
			ke.key = nk.key; ke.modifiers = nk.modifiers;
			RawEvent re = getRawEvent(RawEvent.KEY_EVENT,ke.type);
			re.key = ke.key;
			re.modifiers = ke.modifiers;
			dispatchEvent(re);
		}
		public void keyPressed(java.awt.event.KeyEvent ev){
			//handle(ev,SurfaceKeyEvent.KEY_PRESS);
			//System.out.println("Press!");
			if (ev.isActionKey()) handle(ev,SurfaceKeyEvent.KEY_PRESS); 
		}
		public void keyReleased(java.awt.event.KeyEvent ev){
			//handleEvent(ev);
			handle(ev,SurfaceKeyEvent.KEY_RELEASE);
		}
		public void keyTyped(java.awt.event.KeyEvent ev){
			handle(ev,SurfaceKeyEvent.KEY_PRESS);
		}
	});
	
	addMouseMotionListener(new java.awt.event.MouseMotionListener(){
		private void handleEvent(java.awt.event.MouseEvent ev,int type)
		{
			SurfacePointerEvent pe = new SurfacePointerEvent();
			pe.type = type;
			pe.x = ev.getX();
			pe.y = ev.getY();
			if ((ev.getModifiers() & ev.SHIFT_MASK) > 0)
				pe.modifiers |= IKeys.SHIFT;
			if ((ev.getModifiers() & ev.CTRL_MASK) > 0)
				pe.modifiers |= IKeys.CONTROL;
			boolean isRight = (ev.getModifiers() & ev.META_MASK) != 0;
			if (isRight) pe.modifiers |= pe.RIGHT_BUTTON;
			RawEvent re = getRawEvent(RawEvent.POINTER_EVENT,pe.type);
			re.x = pe.x; re.y = pe.y; re.modifiers = pe.modifiers;
			if (mouseState == 0 && cursorAreas != null){
				checkCursorAreas(re.x,re.y);
			}
			dispatchEvent(re);
		}
		public void mouseMoved(java.awt.event.MouseEvent ev){
			handleEvent(ev,SurfacePointerEvent.PEN_MOVE);
		}
		public void mouseDragged(java.awt.event.MouseEvent ev){
			handleEvent(ev,SurfacePointerEvent.PEN_MOVE);
		}
	});
	addMouseListener(new java.awt.event.MouseListener(){
		private void handleEvent(java.awt.event.MouseEvent ev,int type)
		{
			SurfacePointerEvent pe = new SurfacePointerEvent();
			pe.type = type;
			pe.x = ev.getX();
			pe.y = ev.getY();
			if ((ev.getModifiers() & ev.SHIFT_MASK) > 0)
				pe.modifiers |= IKeys.SHIFT;
			if ((ev.getModifiers() & ev.CTRL_MASK) > 0)
				pe.modifiers |= IKeys.CONTROL;
			boolean isRight = (ev.getModifiers() & ev.META_MASK) != 0;
			if (isRight) pe.modifiers |= pe.RIGHT_BUTTON;
			if (type == pe.PEN_DOWN) setMouseState(isRight ? 0x2 : 0x1,0);
			else if (type == pe.PEN_UP) setMouseState(0,isRight ? 0x2 : 0x1);
			RawEvent re = getRawEvent(RawEvent.POINTER_EVENT,pe.type);
			re.x = pe.x; re.y = pe.y; re.modifiers = pe.modifiers;
			if (mouseState == 0 && cursorAreas != null){
				checkCursorAreas(re.x,re.y);
			}
			dispatchEvent(re);
		}
		public void mousePressed(java.awt.event.MouseEvent ev){
			handleEvent(ev,SurfacePointerEvent.PEN_DOWN);
		}
		public void mouseReleased(java.awt.event.MouseEvent ev){
			handleEvent(ev,SurfacePointerEvent.PEN_UP);
		}
		public void mouseEntered(java.awt.event.MouseEvent ev){
			handleEvent(ev,SurfacePointerEvent.PEN_MOVED_ON);
		}
		public void mouseExited(java.awt.event.MouseEvent ev){
			handleEvent(ev,SurfacePointerEvent.PEN_MOVED_OFF);
		}
		public void mouseClicked(java.awt.event.MouseEvent ev){
			//handleEvent(ev);
		}
	});

}

// The only way I would be here is if I am in the Dispatch Thread.
/*
public int getMessage(SystemMessage message,boolean peek,boolean remove)
{
	synchronized(Applet.uiLock){
		while (queue.size() == 0){
			if (peek) return 0;
			else try{
				Applet.uiLock.wait();
			}catch(Exception e){
			}
		}
		FullEvent fe = (FullEvent)queue.elementAt(0);
		boolean isPaint = fe.systemType == SystemMessage.PAINT;
		if (message != null){
			message.type = fe.systemType;
			message.wparam = message.lparam = 0;
			message.x = fe.x;
			message.y = fe.y;
			message.time = isPaint ? 0 : fe.timestamp;
			message.state = isPaint ? 0 : (remove ? message.REMOVED : 0);
		}
		if (!isPaint && remove) queue.removeElementAt(0);
		return 1;
	}
}
*/
/*
public int callBackInMessageThread(CallBack who,Object data)
{
	final FullEvent fe = new FullEvent(SystemMessage.CALLBACK,who);
	fe.data = data;
	new Thread(){
		public void run(){
			addToQueue(fe);
		}
	}.start();
	return 1;
}
*/
//===================================================================
public java.awt.Window getParentWindow()
//===================================================================
{
	return (getParent() instanceof java.awt.Window ? (java.awt.Window)getParent():null);
}

/*
//-------------------------------------------------------------------
boolean checkModal()
//-------------------------------------------------------------------
{
	java.awt.Window mw = getParentWindow();
	if (ewe.applet.Frame.curModal != mw) {
		if (ewe.applet.Frame.curModal != null){
			ewe.applet.Frame.curModal.toFront();
			return false;
		}
	}
	return true;
}
*/
class newkey {
	int key;
	int modifiers;
	public newkey(int k,int m){key = k; modifiers = m;}
}

public static int mouseState = 0;

static synchronized void setMouseState(int on,int off)
{
		mouseState &= ~off;
		mouseState |= on;
		if (mouseState != 0) lastSetCursor = null;
}

public static synchronized int getMouseState()
{
	return mouseState;
}

public boolean checkModal()
{
	return false;
}
public boolean handleEvent(MouseWheelEvent ev)
{
	/*
	void handleEvent(java.awt.event.MouseWheelEvent event)
	{
		int type = 0;
		int key = 0;
		int x = 0;
		int y = 0;
		int modifiers = 0;
		if ((event.getModifiers() & event.SHIFT_MASK) > 0)
			modifiers |= IKeys.SHIFT;
		if ((event.getModifiers() & event.CTRL_MASK) > 0)
			modifiers |= IKeys.CONTROL;
		boolean isRight = (event.getModifiers() & event.META_MASK) != 0;
		boolean doPostEvent = false;
		int stype = 0;
		x = event.getX();
		y = event.getY();
		if (!checkModal()) return;
		stype = SystemMessage.MOUSEFIRST;
		type = event.getWheelRotation() < 0 ? PenEvent.SCROLL_UP : PenEvent.SCROLL_DOWN;
		doPostEvent = true;
		if (doPostEvent){
			int timestamp = (int)ewe.sys.Vm.getTimeStamp();//(int)event.when;
			addToQueue(new FullEvent(stype,type,key,x,y,modifiers,timestamp));
		}
	}
*/	
	int type = ev.getWheelRotation() < 0 ? SurfacePointerEvent.SCROLL_UP : SurfacePointerEvent.SCROLL_DOWN;
	RawEvent re = getRawEvent(RawEvent.POINTER_EVENT,type);
	re.x = ev.getX(); re.y =ev.getY();	
	int modifiers = 0;
	if ((ev.getModifiers() & ev.SHIFT_MASK) > 0)
		modifiers |= IKeys.SHIFT;
	if ((ev.getModifiers() & ev.CTRL_MASK) > 0)
		modifiers |= IKeys.CONTROL;
	boolean isRight = (ev.getModifiers() & ev.META_MASK) != 0;
	if (isRight) modifiers |= IEventModifiers.RIGHT_BUTTON;
	re.modifiers = modifiers;
	dispatchEvent(re);
	return true;
}
public boolean handleEvent(java.awt.Event event)
	{
	int type = 0;
	int key = 0;
	int x = 0;
	int y = 0;
	int modifiers = 0;
	if ((event.modifiers & java.awt.Event.SHIFT_MASK) > 0)
		modifiers |= IKeys.SHIFT;
	if ((event.modifiers & java.awt.Event.CTRL_MASK) > 0)
		modifiers |= IKeys.CONTROL;
	boolean isRight = (event.modifiers & event.META_MASK) != 0;
	boolean doPostEvent = false;
	int stype = 0;
	switch (event.id)
		{
		case java.awt.Event.MOUSE_MOVE:
		case java.awt.Event.MOUSE_DRAG:
			if (!checkModal()) break;
			stype = SystemMessage.MOUSEFIRST;
			type = SurfacePointerEvent.PEN_MOVE;
			x = event.x;
			y = event.y;
			doPostEvent = true;
			break;
		case java.awt.Event.MOUSE_DOWN:
			if (!checkModal()) break;
			stype = SystemMessage.MOUSEFIRST;
			type = SurfacePointerEvent.PEN_DOWN;
			if (isRight) modifiers |= IEventModifiers.RIGHT_BUTTON;
			setMouseState(isRight ? 0x2 : 0x1,0);
			x = event.x;
			y = event.y;
			doPostEvent = true;
			break;
		case java.awt.Event.MOUSE_UP:
			stype = SystemMessage.MOUSEFIRST;
			type = SurfacePointerEvent.PEN_UP;
			if (isRight) modifiers |= IEventModifiers.RIGHT_BUTTON;
			setMouseState(0,isRight ? 0x2 : 0x1);
			x = event.x;
			y = event.y;
			doPostEvent = true;
			break;
		case java.awt.Event.KEY_PRESS:
		{
			stype = SystemMessage.KEYFIRST;
			type = KeyEvent.KEY_PRESS;
			newkey nk;
			keyValue(nk = new newkey(event.key, modifiers));
			key = nk.key; modifiers = nk.modifiers;
			doPostEvent = true;
			break;
			}
		case java.awt.Event.KEY_ACTION:
			{
			newkey nk;
			key = actionKeyValue(nk = new newkey(event.key,modifiers));
			key = nk.key; modifiers = nk.modifiers;
			if (key != 0)
				{
				stype = SystemMessage.KEYFIRST;
				type = KeyEvent.KEY_PRESS;
				doPostEvent = true;
				}
			break;
			}
		}
	if (doPostEvent)
		{
		int timestamp = (int)event.when;
		//addToQueue(new FullEvent(stype,type,key,x,y,modifiers,timestamp));
		}
	return super.handleEvent(event);
	}

public static int keyValue(newkey nk)
	{
	int key = nk.key;
	nk.modifiers |= IKeys.SPECIAL;
	switch (key)
		{
		case 8:
			key = IKeys.BACKSPACE;
			break;
		case 10:
			key = IKeys.ENTER;
			break;
		case 127:
			key = IKeys.DELETE;
			break;
		case 27:
			key = IKeys.ESCAPE;
			break;
		case 9:
			key = IKeys.TAB;
			break;
		default:
			nk.modifiers &= ~(IKeys.SPECIAL);
		}
	nk.key = key;
	return key;
	}

public static int actionKeyValue(newkey nk)
	{
	int key = 0;
	nk.modifiers |= IKeys.SPECIAL;
	//System.out.println(nk.key+", "+java.awt.Event.UP+", "+java.awt.event.KeyEvent.VK_UP);
	switch (nk.key)
		{
		case java.awt.event.KeyEvent.VK_NUMPAD0: 
			key = java.awt.event.KeyEvent.VK_0;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD1: 
			key = java.awt.event.KeyEvent.VK_1;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD2: 
			key = java.awt.event.KeyEvent.VK_2;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD3: 
			key = java.awt.event.KeyEvent.VK_3;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD4: 
			key = java.awt.event.KeyEvent.VK_4;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD5: 
			key = java.awt.event.KeyEvent.VK_5;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD6: 
			key = java.awt.event.KeyEvent.VK_6;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD7: 
			key = java.awt.event.KeyEvent.VK_7;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD8: 
			key = java.awt.event.KeyEvent.VK_8;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD9: 
			key = java.awt.event.KeyEvent.VK_8;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_ADD: 
			key = java.awt.event.KeyEvent.VK_PLUS;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
			/*
		case java.awt.event.KeyEvent.VK_NUMPAD9: 
			key = java.awt.event.KeyEvent.VK_8;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD9: 
			key = java.awt.event.KeyEvent.VK_8;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
		case java.awt.event.KeyEvent.VK_NUMPAD9: 
			key = java.awt.event.KeyEvent.VK_8;
			nk.modifiers &= ~IKeys.SPECIAL;
			break;
			*/
		case java.awt.event.KeyEvent.VK_PAGE_UP:       key = IKeys.PAGE_UP; break;
		case java.awt.event.KeyEvent.VK_PAGE_DOWN:       key = IKeys.PAGE_DOWN; break;
		case java.awt.event.KeyEvent.VK_HOME:       key = IKeys.HOME; break;
		case java.awt.event.KeyEvent.VK_END:        key = IKeys.END; break;
		case java.awt.event.KeyEvent.VK_UP:         key = IKeys.UP; break;
		case java.awt.event.KeyEvent.VK_DOWN:       key = IKeys.DOWN; break;
		case java.awt.event.KeyEvent.VK_LEFT:       key = IKeys.LEFT; break;
		case java.awt.event.KeyEvent.VK_RIGHT:      key = IKeys.RIGHT; break;
		case java.awt.event.KeyEvent.VK_INSERT:     key = IKeys.INSERT; break;
		case java.awt.event.KeyEvent.VK_ENTER:      key = IKeys.ENTER; break;
		case java.awt.event.KeyEvent.VK_TAB:        key = IKeys.TAB; break;
		case java.awt.event.KeyEvent.VK_BACK_SPACE: key = IKeys.BACKSPACE; break;
		case java.awt.event.KeyEvent.VK_ESCAPE:     key = IKeys.ESCAPE; break;
		case java.awt.event.KeyEvent.VK_DELETE:     key = IKeys.DELETE; break;
		case java.awt.event.KeyEvent.VK_F1:     key = IKeys.F1; break;
		case java.awt.event.KeyEvent.VK_F2:     key = IKeys.F2; break;
		case java.awt.event.KeyEvent.VK_F3:     key = IKeys.F3; break;
		case java.awt.event.KeyEvent.VK_F4:     key = IKeys.F4; break;
		case java.awt.event.KeyEvent.VK_F5:     key = IKeys.F5; break;
		case java.awt.event.KeyEvent.VK_F6:     key = IKeys.F6; break;
		case java.awt.event.KeyEvent.VK_F7:     key = IKeys.F7; break;
		case java.awt.event.KeyEvent.VK_F8:     key = IKeys.F8; break;
		case java.awt.event.KeyEvent.VK_F9:     key = IKeys.F9; break;
		case java.awt.event.KeyEvent.VK_F10:     key = IKeys.F10; break;
		case java.awt.event.KeyEvent.VK_F11:     key = IKeys.F11; break;
		case java.awt.Event.PGUP:       key = IKeys.PAGE_UP; break;
		case java.awt.Event.PGDN:       key = IKeys.PAGE_DOWN; break;
		case java.awt.Event.HOME:       key = IKeys.HOME; break;
		case java.awt.Event.END:        key = IKeys.END; break;
		case java.awt.Event.UP:         key = IKeys.UP; break;
		case java.awt.Event.DOWN:       key = IKeys.DOWN; break;
		case java.awt.Event.LEFT:       key = IKeys.LEFT; break;
		case java.awt.Event.RIGHT:      key = IKeys.RIGHT; break;
		case java.awt.Event.INSERT:     key = IKeys.INSERT; break;
		//case java.awt.Event.ENTER:      key = IKeys.ENTER; break;
		//case java.awt.Event.TAB:        key = IKeys.TAB; break;
		//case java.awt.Event.BACK_SPACE: key = IKeys.BACKSPACE; break;
		//case java.awt.Event.ESCAPE:     key = IKeys.ESCAPE; break;
		//case java.awt.Event.DELETE:     key = IKeys.DELETE; break;
		case java.awt.Event.F1:     key = IKeys.F1; break;
		case java.awt.Event.F2:     key = IKeys.F2; break;
		case java.awt.Event.F3:     key = IKeys.F3; break;
		case java.awt.Event.F4:     key = IKeys.F4; break;
		case java.awt.Event.F5:     key = IKeys.F5; break;
		case java.awt.Event.F6:     key = IKeys.F6; break;
		case java.awt.Event.F7:     key = IKeys.F7; break;
		case java.awt.Event.F8:     key = IKeys.F8; break;
		case java.awt.Event.F9:     key = IKeys.F9; break;
		case java.awt.Event.F10:     key = IKeys.F10; break;
		case java.awt.Event.F11:     key = IKeys.F11; break;
		case java.awt.event.KeyEvent.VK_F12:     
		case java.awt.Event.F12:     
				key = IKeys.F12; 
				if ((nk.modifiers & IKeys.CONTROL) != 0)
					key = IKeys.PDA_CANCEL;
				break;
		default:
		}
	nk.key = key;
	return key;
	}
int drawCount = 0;

//imageToDraw toDraw;
Object drawLock = new Object();
private boolean flip;
private PixelBuffer rotateSrc, rotateDest;

/*
public void update(java.awt.Graphics g)
{
	synchronized(drawLock){
	//new Exception().printStackTrace();
	//synchronized(this){
	//synchronized(drawLock){
		if (toDraw == null) {
			//System.out.println("Nothing to draw!");
			return;
		}
	//}
	imageToDraw drawNow = toDraw;
	try{
		if (drawNow == null) return;
		int width = drawNow.im.getWidth(), height = drawNow.im.getHeight();
		//g.drawLine(0,0,bi.getWidth(),bi.getHeight());
		if (win.rotation != NativeWindowSurface.ROTATION_NONE){
			if (rotateSrc == null){
				rotateSrc = new PixelBuffer();
				rotateDest = new PixelBuffer();
			}
			rotateSrc.resizeTo(width,height,null);
			rotateSrc.setTo(drawNow.im);
			int rot = PixelBuffer.TRANSFORM_ROTATE_90;
			if (win.rotation == NativeWindowSurface.ROTATION_180)
				rot = PixelBuffer.TRANSFORM_ROTATE_180;
			else if (win.rotation == NativeWindowSurface.ROTATION_270)
				rot = PixelBuffer.TRANSFORM_ROTATE_270;
			rotateDest = rotateSrc.transform(rot,rotateDest);
			drawNow.im.free();
			drawNow.im = rotateDest.toImage();
			int x = drawNow.x, y = drawNow.y;
			int mw = drawNow.im.getWidth(), mh = drawNow.im.getHeight();
			if (rot == PixelBuffer.TRANSFORM_ROTATE_90){
				drawNow.x = getWidth()-y-mw;
				drawNow.y = x;
			}else if (rot == PixelBuffer.TRANSFORM_ROTATE_180){
				drawNow.x = getWidth()-x-mw;
				drawNow.y = getHeight()-y-mh;
			}else{
				drawNow.x = y;
				drawNow.y = getHeight()-x-mh;
			}
		}
		BufferedImage bi = (BufferedImage)drawNow.im.getNativeDrawable();
		g.drawImage(bi,drawNow.x,drawNow.y,null,null);
		Rectangle rr = g.getClipBounds();
		drawNow.im.free();
	}catch(Exception e){
	}finally{
		//synchronized(drawLock){
			toDraw = null;
			drawLock.notifyAll();
		//}
	}
	}
}
*/

public java.awt.Graphics lastPaintGraphics;

public boolean painted = false;

synchronized void waitForPaint()
{
	while(!painted)try{
		wait();
	}catch(InterruptedException e){
		return;
	}
}
public void paint(java.awt.Graphics g)
{
	synchronized(this){
		painted = true;
		notifyAll();
	}

	java.awt.Rectangle r;
	try { r = g.getClipBounds(); }
	catch (NoSuchMethodError e) { r = g.getClipRect(); }
	/*
	WindowSurfaceHandler h = win.getHandler();
	
	if (h != null) {
		eve.fx.Graphics gr = new eve.fx.Graphics(win,g);
		h.paintWindow(gr,r.x,r.y,r.width,r.height);
		gr.free();
	}
	if (true) return;
	*/
	//g.setColor(new Color(255,200,200));
	//g.fillRect(r.x,r.y,r.width,r.height);
	SurfacePaintEvent pe = new SurfacePaintEvent();
	pe.x = r.x; pe.y = r.y;	pe.width = r.width; pe.height = r.height;
	RawEvent re = getRawEvent(RawEvent.PAINT_EVENT,pe.type);
	re.x = pe.x; re.y = pe.y;	re.width = pe.width; re.height = pe.height;
	dispatchEvent(re);
}

Rect clip = new Rect(), dest = new Rect();
imageToDraw myDraw = new imageToDraw();
boolean drawPending;
Countdown drawCountdown = new Countdown();

class imageToDraw{
	//
	// This is the start point in the image.
	//
	int sx, sy;
	//
	// This is the destination Rect.
	//
	int x, y, width, height;
	//
	Image im;
	//
	Image rotated;
	//
	public imageToDraw()
	{
		
	}
	public boolean set(Image i, int cx, int cy, int cw, int ch, int x, int y, int w, int h)
	{
		Rect r = clip.set(cx,cy,cw,ch);
		Rect d = dest.set(x,y,w,h);
		r.getIntersection(d,r);
		if (r.width <= 0 || r.height <= 0){
			return false;
		}
		this.x = r.x; this.y = r.y;
		this.width = r.width; this.height = r.height;
		this.sx = this.x-x; this.sy = this.y-y;
		im = i;
		return true;
	}
}
public void update(java.awt.Graphics g)
{
	synchronized(drawLock){
		if (!drawPending) return;
		try{
			Image im = myDraw.im;
			if (win.rotation != NativeWindowSurface.ROTATION_NONE){
				if (rotateSrc == null){
					rotateSrc = new PixelBuffer();
					rotateDest = new PixelBuffer();
				}
				rotateSrc.resizeTo(myDraw.width,myDraw.height,null);
				myDraw.im.getPixels(rotateSrc.getBuffer(),0,myDraw.sx,myDraw.sy,myDraw.width,myDraw.height,myDraw.width);
				int rot = PixelBuffer.TRANSFORM_ROTATE_90;
				if (win.rotation == NativeWindowSurface.ROTATION_180)
					rot = PixelBuffer.TRANSFORM_ROTATE_180;
				else if (win.rotation == NativeWindowSurface.ROTATION_270)
					rot = PixelBuffer.TRANSFORM_ROTATE_270;
				rotateDest = rotateSrc.transform(rot,rotateDest);
				int nw = rot == PixelBuffer.TRANSFORM_ROTATE_180 ? myDraw.width : myDraw.height;
				int nh = rot == PixelBuffer.TRANSFORM_ROTATE_180 ? myDraw.height : myDraw.width;
				int ow = myDraw.rotated == null ? -1 : myDraw.rotated.getWidth();
				int oh = myDraw.rotated == null ? -1 : myDraw.rotated.getHeight();
				if (myDraw.rotated == null || ow < nw || oh < nh){
					if (myDraw.rotated != null) myDraw.rotated.free();
					if (ow < nw) ow = nw;
					if (oh < nh) oh = nh;
					myDraw.rotated = win.getCompatibleImage(ow,oh);
				}
				myDraw.rotated.setPixels(rotateDest.getBuffer(),0,0,0,nw,nh,nw);
				im = myDraw.rotated; 
				int x = myDraw.x, y = myDraw.y;
				if (rot == PixelBuffer.TRANSFORM_ROTATE_90){
					myDraw.x = getWidth()-y-nw;
					myDraw.y = x;
				}else if (rot == PixelBuffer.TRANSFORM_ROTATE_180){
					myDraw.x = getWidth()-x-nw;
					myDraw.y = getHeight()-y-nh;
				}else{
					myDraw.x = y;
					myDraw.y = getHeight()-x-nh;
				}
				myDraw.width = nw;
				myDraw.height = nh;
			}			
			g.setClip(myDraw.x,myDraw.y,myDraw.width,myDraw.height);
			g.drawImage((BufferedImage)im.getNativeDrawable(),myDraw.x-myDraw.sx,myDraw.y-myDraw.sy,null,null);
		}finally{
			drawPending = false;
			drawLock.notifyAll();
		}
	}
}

public void drawImage(Image im,int clipX, int clipY, int clipWidth,int clipHeight, int destX, int destY, int destWidth, int destHeight)
{
	if (!win.isVisible()) return;
	if (destWidth <= 0 || destHeight <= 0) return;
	synchronized(drawLock){
		while(drawPending){
			try{
				drawLock.wait();
			}catch(InterruptedException e){
			}
		}
		drawPending = myDraw.set(im,clipX,clipY,clipWidth,clipHeight,destX,destY,destWidth,destHeight);
		if (!drawPending) return;
		repaint(myDraw.x,myDraw.y,myDraw.width,myDraw.height);
		try{
			drawCountdown.start(1000);
			drawLock.notifyAll();
			while(drawPending && win.isVisible() && !drawCountdown.hasExpired()){
				try{
					drawCountdown.waitOn(drawLock);
				}catch(InterruptedException e){
				}
			}
		}finally{
			drawPending = false;
			drawLock.notifyAll();
		}
	}	
}
/*
public void olddrawImage(Image im,int clipX, int clipY, int clipWidth,int clipHeight, int destX, int destY, int destWidth, int destHeight)
{
	if (!win.isVisible()) return;
	if (destWidth <= 0 || destHeight <= 0) return;
	synchronized(drawLock){
		while(toDraw != null && win.isVisible()){
			try{
				drawLock.wait();
			}catch(InterruptedException e){
				return;
			}
		}
		if (!win.isVisible()) return;
		imageToDraw drawNow = new imageToDraw(im,clipX,clipY,clipWidth,clipHeight,destX,destY,destWidth,destHeight);
		if (drawNow.im == null) {
			drawNow = null;
			return;
		}
		Rect r = new Rect(destX,destY,destWidth,destHeight);
		win.rotateInClient(win.rotation,r,false);
		//System.out.println("R: "+hashCode()+" = "+r);
		repaint(r.x,r.y,r.width,r.height);
		toDraw = drawNow;
		drawLock.notifyAll();
		while(toDraw != null && win.isVisible()){
			try{
				drawLock.wait();
			}catch(InterruptedException e){
				return;
			}
		}
	}
}
*/
public boolean moveImage(int srcX, int srcY, int srcWidth, int srcHeight, int destX, int destY)
{
	Rect r = new Rect(srcX,srcY,srcWidth,srcHeight);
	Rect r2 = new Rect(destX, destY, srcWidth, srcHeight);
	win.rotateInClient(win.rotation,r,false);
	win.rotateInClient(win.rotation,r2,false);
	java.awt.Graphics g = getGraphics();
	g.copyArea(r.x,r.y,r.width,r.height,r2.x-r.x,r2.y-r.y);
	g.dispose();
	return true;
}

	public void postTimerMessage()
	{
		//addToQueueExclusive(new FullEvent(SystemMessage.TIMER,0,0,0,0,0,0));
	}
	
	public java.awt.Graphics getGraphics()
	{
		return super.getGraphics();
	}
	
	/*
	public static void place(ewe.ui.Window win,java.awt.Component c,ewe.fx.Rect where)
	{
		if (win == null) return;
		java.awt.Container awtWin = win._winCanvas;
		if (awtWin == null) return;
		if (c.getParent() != awtWin) awtWin.add(c);
		if (where != null) c.setBounds(where.x,where.y,where.width,where.height);
	}
	*/
}
