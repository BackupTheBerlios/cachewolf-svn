/*
 * Created on Feb 26, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import eve.sys.ITaskbarEntry;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class SurfaceTaskbarIconEvent extends SurfaceEvent {
	public static final int PEN_PRESSED = ITaskbarEntry.PEN_PRESSED_ON_ICON;
	public int taskbarID;
}
//####################################################
