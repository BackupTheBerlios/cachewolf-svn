/*
 * Created on Aug 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.gui;

import java.awt.event.WindowAdapter;


/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class EveWindow extends java.awt.Window implements JavaSurface{
private boolean isModal;
private WindowSurface surface;

	public EveWindow(boolean modal,String title,eve.fx.gui.WindowSurface parent){
		super(new java.awt.Frame(title));//parent == null ? new java.awt.Frame(title) : parent.jWindow instanceof java.awt.Frame ? (java.awt.Frame)parent.jWindow : new java.awt.Frame(title));
		surface = parent;
		isModal = modal;
		if (isModal){
			//lastModal = ewe.applet.Frame.curModal;
			//ewe.applet.Frame.curModal = this;
		}
		
		addWindowListener(new WindowAdapter(){
			/* This is all incorrect. Look at EveFrame to see what to do.
			 * 
			private void handle(WindowEvent we, int type)
			{
				SurfaceWindowEvent swe = new SurfaceWindowEvent();
				surface.postWindowEvent(type);
			}
			public void windowClosing(WindowEvent we){
				handle(we,SurfaceWindowEvent.CLOSE);
			}
			public void windowActivated(WindowEvent we){
				handle(we,SurfaceWindowEvent.ACTIVATE);
			}
			public void windowDeactivated(WindowEvent we){
				handle(we,SurfaceWindowEvent.DEACTIVATE);
			}
			*/
		});
		/*
		addComponentListener(new ComponentAdapter(){
			public void componentResized(ComponentEvent ce)
			{
				if (window != null) 
					if (isVisible())
					synchronized(Applet.uiLock){
						window.canDisplay = false;
						window.windowBoundsChanged(JWindow.this);
					}
			}
			public void componentShown(ComponentEvent ce)
			{
				wasShown = true;
				if (window != null){
					if (isVisible())
						//new Thread(){
							//public void run(){
								synchronized(Applet.uiLock){
									//window.canDisplay = false;
									window.windowBoundsChanged(JWindow.this);
									synchronized(window._winCanvas){
										window._winCanvas.hasBeenShown = true;
										if (window._winCanvas.hasBeenPainted) 
											window._winCanvas.repaint();
									}
								}
							//}
						//}.start();
				}
			}
		});
		*/
	}

	boolean wasShown = false;
	public boolean wasShown() {return wasShown;}

}

//####################################################
