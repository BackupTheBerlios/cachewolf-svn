package eve.fx.gui;

/**
 * IKeys is an interface containing values for special keys and modifiers.
 */
public interface IKeys extends IFunctionKeys, IKeypadKeys, IEventModifiers
{

/** special key */
public static final int PAGE_UP   = 75000;
/** special key */
public static final int PAGE_DOWN = 75001;
/** special key */
public static final int HOME      = 75002;
/** special key */
public static final int END       = 75003;
/** special key */
public static final int UP        = 75004;
/** special key */
public static final int DOWN      = 75005;
/** special key */
public static final int LEFT      = 75006;
/** special key */
public static final int RIGHT     = 75007;
/** special key */
public static final int INSERT    = 75008;
/** special key */
public static final int ENTER     = 75009;
/** special key */
public static final int TAB       = 75010;
/** special key */
public static final int BACKSPACE = 75011;
/** special key */
public static final int ESCAPE    = 75012;
/** special key */
public static final int DELETE    = 75013;
/** special key */
public static final int MENU      = 75014;
/** special key */
public static final int COMMAND   = 75015;
/** special key */
public static final int HELP = 75016;
/** special key */
public static final int PDA_CANCEL = 75017;
/** special key */
public static final int NEXT_TAB = 75018;
/** special key */
public static final int PREV_TAB = 75019;
/** special key */
public static final int NEXT_CONTROL = 75020;
/** special key */
public static final int PREV_CONTROL = 75021;
/** special key */
public static final int SOFTKEY1 = 75022;
/** special key */
public static final int SOFTKEY2 = 75023;

/** Left Mouse Button or Pen **/
public static final int PEN = 76001;
/** Left Mouse Button or Pen **/
public static final int LEFT_MOUSE = PEN;
/** Right Mouse Button **/
public static final int RIGHT_MOUSE = 76002;
/** Middle Mouse Button **/
public static final int MIDDLE_MOUSE = 76003;

/** Action Button. On my Casio it is 0x86 **/
public static final int ACTION = 76000;

/**
 * This is a bit returned by WindowSurface.getAsyncKeyState(int key). If it is set it indicates
 * that the key is currently being pressed.
 */
public static final int ASYNC_IS_PRESSED = 0x8000;
/**
 * This is a bit returned by WindowSurface.getAsyncKeyState(int key). If it is set it indicates
 * that the key was pressed at least once in between the last call to getAsyncKeyState()
 * and the current call, even though its current state may be not pressed.
 */
public static final int ASYNC_WAS_PRESSED = 0x0001;

}



