/*
 * Created on Dec 5, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import java.io.IOException;

//import eve.sys.DeviceIcon;
import eve.sys.Cache;
import eve.sys.ImageData;
import eve.sys.ImageDataInfo;
import eve.sys.SystemResourceException;
import eve.sys.Vm;
import eve.util.FormattedDataSource;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Picture extends ImageObject {
	BufferedImageData bufferedImage; // This can be moved, it is located by name.
	int myOptions; // This can be moved, it is located by name.
	Image myImage; // This can be moved, it is located by name.
	Image myMask; // This can be moved, it is located by name.
	Picture meGray;
	/**@deprecated use ImageData.CREATE_OPTION_KEEP_ASPECT_RATIO instead. **/
	public static final int OPTION_KEEP_ASPECT_RATIO = 0x1000000;
	
	/**
	 * @param source
	 * @param srcArea
	 * @param newWidth
	 * @param newHeight
	 * @param options
	 * @return
	 * @throws ImageDecodingException
	 * @deprecated use the constructor instead.
	 */
	public static Picture newPicture(FormattedDataSource source, Rect srcArea, int newWidth, int newHeight, int options)
	throws ImageDecodingException
	{
		Dimension ns = Dimension.getCached(newWidth, newHeight);
		try{
			return new Picture(source,srcArea,ns,options);
		}finally{
			ns.cache();
		}
	}
	
	/* (non-Javadoc)
	 * @see eve.fx.IImage#draw(eve.fx.Graphics, int, int, int)
	 */
	public void draw(Graphics g, int x, int y, int options) {
		if ((options & DISABLED) != 0){
			if (meGray == null)
				meGray = new Picture(new GrayScaleImage(this),null,0);
			g.drawPicture(meGray,x,y);
		}else
			g.drawPicture(this,x,y);
	}
	/*
	public DeviceIcon toIcon(){return null;}
	public Object toCursor(Point hotspot){return null;}
	*/
	/* (non-Javadoc)
	 * @see eve.fx.IImage#free()
	 */
	public synchronized void free()
	{
		super.free();
		bufferedImage.free();
		bufferedImage = null;
		if (meGray != null) meGray.free();
		meGray = null;
	}

	/* (non-Javadoc)
	 * @see eve.fx.IImage#getPixels(int[], int, int, int, int, int, int)
	 */
	public int[] getPixels(int[] dest, int offset, int x, int y, int width,
			int height, int rowStride) {
		return bufferedImage.getPixels(dest,offset,x,y,width,height,rowStride);
	}

	public int getImageType()
	{
		return bufferedImage.getImageType();
	}
	public int getImageScanLineType()
	{
		return bufferedImage.getImageScanLineType();
	}
	public int getImageScanLineLength()
	{
		return bufferedImage.getImageScanLineLength();
	}
	/* (non-Javadoc)
	 * @see eve.fx.IImage#usesAlpha()
	 */
	public boolean usesAlpha() {
		return bufferedImage.usesAlpha();
	}
/**
 * This always returns false. You cannot set the pixels of a Picture.
 */
	public boolean isWriteableImage() {
		return false;
	}
	public boolean setPixels(int[] source, int offset, int x, int y, int width, int height,int rowStride)
	{
		return false;
	}
	
	public synchronized Picture makeGray()
	{
		if (meGray == null) {
			// TODO implement this.
			throw new UnsupportedOperationException();
		}
		return meGray;
	}
	/**
	 * A convenience method that creates an image and draws this Picture on it.
	 * @param imageCreationOptions options for creating the image.
	 * @return
	 */
	public Image toImage(int imageCreationOptions)
	{
		Image im = new Image(width,height,imageCreationOptions);
		Graphics g = new Graphics(im);
		g.setColor(Color.White);
		g.fillRect(0,0,width,height);
		g.drawPicture(this,0,0);
		g.free();
		return im;
	}
	protected void finalize() 
	{
		free();
	}
	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength) throws IllegalStateException {
		bufferedImage.getImageScanLines(startLine,numLines,destArray,offset,destScanLineLength);
	}
	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength) throws IllegalStateException {
		throw new IllegalStateException();
	}
	
	public Picture(String name, Object maskObject,int options) throws ImageDecodingException, SystemResourceException 
	{
		try{
			FormattedDataSource fds = new FormattedDataSource().set(Vm.openResource(null,name));
			fds.name = name;
			try{
				decodeFrom(fds,maskObject);
			}finally{
				fds.close();
			}
		}catch(IOException e){
			throw new ImageDecodingException(name,e);
		}
	}
	public Picture(FormattedDataSource source,Rect sourceArea,int options) throws ImageDecodingException
	{
		this(source,sourceArea,null,options);
	}
	public Picture(FormattedDataSource source,Rect sourceArea, Dimension newSize, int options) throws ImageDecodingException
	{
		PixelBuffer pb = (PixelBuffer)Cache.get(PixelBuffer.class);
		try{
			pb.background = null;
			try{
				new ImageDecoder().decode(source,pb,sourceArea,newSize,options);
			}finally{
				if (source != null) source.close();
			}
			fromImage(pb,null,0);
		}finally{
			Cache.put(pb);
		}
	}
	
	/*
	public static ImageInfo getImageInfo(FormattedDataSource source,ImageInfo destination) throws ImageDecodingException
	{
		try{
			if (destination == null) destination = new ImageInfo();
			RandomStream rs = source.getRewindableStream();
			ImageCodec ic = new ImageCodec();
			if (!ic.decode(rs)) throw new ImageDecodingException(source.name);
			if (ic.isGIFFile || ic.isJPEGFile || ic.isPNGFile){
				source.rewind();
				ArraySection as = source.getAllBytes(null);
				Toolkit tk = Toolkit.getDefaultToolkit();
				java.awt.Image im = tk.createImage((byte[])as.data,as.startIndex,as.length);
				if (!(new ImagePreparer().prepare(im,true))) throw new ImageDecodingException(null);
				ic.width = im.getWidth(null);
				ic.height = im.getHeight(null);
				im.flush();
			}
			destination.width = ic.width;
			destination.height = ic.height;
			destination.canScale = false;
			if (ic.isJPEGFile) destination.format = destination.FORMAT_JPEG;
			else if (ic.isGIFFile) destination.format = destination.FORMAT_GIF;
			else if (ic.isBMPFile) destination.format = destination.FORMAT_BMP;
			else destination.format = destination.FORMAT_PNG;
			destination.size = ic.width*ic.height*4;
			//tk.prepareImage(im,im.getWidth(null),im.getHeight(null),null);
			return destination;
		}catch(IOException e){
			throw new ImageDecodingException(source,e);
		}
	}
	*/
	public Picture(FormattedDataSource source, Object maskObject,int options) throws ImageDecodingException, SystemResourceException
	{
		decodeFrom(source,maskObject);
	}
	
	private void fromBufferedImage(BufferedImageData ji,int options,boolean doCopy)
	{
		bufferedImage = Image.fromBufferedImage(ji,doCopy);
		this.width = bufferedImage.getWidth();
		this.height = bufferedImage.getHeight();
	}
	
	private void decodeFrom(FormattedDataSource source,Object maskObject) throws ImageDecodingException, SystemResourceException
	{
		PixelBuffer pb = (PixelBuffer)Cache.get(PixelBuffer.class);
		try{
			pb.setTo(source);
			fromImage(pb,maskObject,0);
		}finally{
			Cache.put(pb);
		}
	}
	
	int[] transferBuffer = new int[0];
	public Picture(String formattedImageResource) throws ImageDecodingException
	{
		this(formattedImageResource,0);
	}
	public Picture(String formattedImageResource,String maskName) throws ImageDecodingException
	{
		this(formattedImageResource,maskName,0);
	}
	private void createFrom(ImageData im, byte[] maskBits, int options)
	{
		ImageData ii = im;//ImageAdapter.toIImage(fromImage,null);
		width = ii.getImageWidth();
		height = ii.getImageHeight();
		bufferedImage = new BufferedImageData(Image.createBI(width,height,ii.getImageType() == TYPE_ARGB || maskBits != null));
		synchronized(transferBuffer){
			transferBuffer = ii.getPixels(transferBuffer,0,0,0,width,height,width);
			bufferedImage.setPixels(transferBuffer,0,0,0,width,height,width);
			if (maskBits != null){
				int bpl = (width+7)/8;
				for (int y = 0; y<height; y++){
					int m = bpl*y, msk = 0x80;
					transferBuffer = bufferedImage.getPixels(transferBuffer,0,0,y,width,1,width);
					for (int x = 0; x<width; x++){
						if ((maskBits[m] & msk) != 0) transferBuffer[x] |= 0xff000000;
						else transferBuffer[x] &= 0x00ffffff;
						msk >>= 1;
						if (msk == 0){
							msk = 0x80;
							m++;
						}
					}
					bufferedImage.setPixels(transferBuffer,0,0,y,width,1,width);
				}
			}
		}
	}
	
	private void fromImage(ImageData im,Object maskObject,int options)
	{
		ImageDataInfo ii = ImageDataInfo.toImageDataInfo(im);
		if (maskObject == null){
			createFrom(im,null,options);
		}else if (maskObject instanceof Mask){
			Mask m = (Mask)maskObject;
			int need = ((ii.width+7)/8)*ii.height;
			if (m.bits.length < need)
				throw new IllegalArgumentException();
			createFrom(im, m.bits,options);
		}else if (maskObject instanceof ImageData){
			ImageData id = (ImageData)maskObject;
			if (id.getImageWidth() != ii.width || id.getImageHeight() != ii.height)
				throw new IllegalArgumentException();
			fromImage(im,new Mask(id),options);
		}else if (maskObject instanceof String){
			fromImage(im, new Mask(new Picture((String)maskObject,0)),options);
		}else if (maskObject instanceof FormattedDataSource){
			fromImage(im, new Mask(new Picture((FormattedDataSource)maskObject,0)),options);
		}else if (maskObject instanceof Color){
			fromImage(im,new Mask(im,(Color)maskObject),options);
		}else{
			throw new IllegalArgumentException();
		}
		
	}
	
	public Picture(ImageData fromImage,Object maskObject,int options)
	{
		fromImage(fromImage,maskObject,options);
	}
	public Picture(FormattedDataSource source,int options)
	{
		this(source,null,options);
	}
	public Picture(String formattedImageResource,int options)
	{
		this(formattedImageResource,null,options);
	}
	public Picture(ImageData fromImage,int options)
	{
		this(fromImage,null,options);
	}

		public Picture(int options,Object nativeObject)
		{
			if (!(nativeObject instanceof java.awt.Image))
				throw new IllegalArgumentException("The nativeObject must be a java.awt.Image object.");
			if (nativeObject instanceof java.awt.image.BufferedImage)
				fromBufferedImage(new BufferedImageData((java.awt.image.BufferedImage)nativeObject),options,false);
			else {
				fromBufferedImage(Image.toBufferedImage((java.awt.Image)nativeObject),options,false);
			}
		}
		
		public Object getNativeObject()
		{
			return bufferedImage;
		}
	
}

//####################################################
