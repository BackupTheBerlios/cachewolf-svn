/*
 * Created on May 1, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.PNGImageTypes;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class ByteArrayImageData extends ImageObject implements PNGImageTypes {

	public int imageType;
	public boolean isWritable = true;
	
	private byte[] bytes;
	private int[] colorTable;
	private int bpl;
	
	/**
	 * This specifies the alignment of byte scan lines. Values must be 1 (for 8-bit alignment)
	 * or 2 (for 16-bit alignment) or 4 (for 32-bit alignment).
	 */
	public int byteAlignment = 1;
	
	public int[] getImageColorTable()
	{
		return colorTable;
	}
	/**
	 * Set the image type and create the byte array to hold the data.
	 * @param type one of the ImageData.TYPE_XXX.
	 */
	public void setImageType(int type)
	{
		imageType = type;
		switch(type){
		case TYPE_ARGB: bpl = 4*width; break;
		case TYPE_RGB: bpl = 3*width; break;
		case TYPE_INDEXED_256: case TYPE_GRAY_SCALE_256:
			bpl = width; break;
		case TYPE_INDEXED_16: case TYPE_GRAY_SCALE_16:
			bpl = (width+1)/2; break;
		case TYPE_INDEXED_4: case TYPE_GRAY_SCALE_4:
			bpl = (width+3)/4; break;
		case TYPE_INDEXED_2: case TYPE_GRAY_SCALE_2:
			bpl = (width+7)/8; break;
		default:
			throw new IllegalArgumentException();
		}
		bpl = ((bpl+byteAlignment-1)/byteAlignment)*byteAlignment;
		bytes = new byte[bpl*width];
	}
	/**
	 * Create the ByteArrayImageData.
	 * Call setType() or setPNGType() or setIndexedType() to set the type
	 * of the image and to allocate the space for the image.
	 * @param width the width of the image.
	 * @param height the height of the image.
	 */
	public ByteArrayImageData(int width, int height)
	{
		this.width = width;
		this.height = height;
	}
	public void free()
	{
		freeImage();
	}
	public void freeImage()
	{
		bytes = null;
	}
	/**
	 * Set the imageType value using a PNG image type and a bitDepth. <b>Note</b> at
	 * this time the bitDepth is currently ignored and the max. bit depth is always
	 * used.
	 * @param typeOfImage a valid PNG_TYPE_XXX value.
	 * @param bitDepth the number of bits per pixel which must be valid for the specified
	 * type. Note that TRUE_COLOR and TRUE_COLOR_ALPHA must use a bit depth of 8.
	 * @return the ImageData image type.
	 */
	public int setPNGType(int typeOfImage, int bitDepth)
	{
		switch(typeOfImage){
			case PNG_TYPE_TRUE_COLOR:
				if (bitDepth != 8) throw new IllegalArgumentException();
				imageType = TYPE_RGB; break;
			case PNG_TYPE_GRAY_SCALE_ALPHA:
			case PNG_TYPE_TRUE_COLOR_ALPHA:
				if (bitDepth != 8) throw new IllegalArgumentException();
				imageType = TYPE_ARGB; break;
			case PNG_TYPE_GRAY_SCALE:
				if (bitDepth == 1)      imageType = TYPE_GRAY_SCALE_2;
				else if (bitDepth == 2) imageType = TYPE_GRAY_SCALE_4;
				else if (bitDepth == 4) imageType = TYPE_GRAY_SCALE_16;
				else if (bitDepth == 8) imageType = TYPE_GRAY_SCALE_256;
				else throw new IllegalArgumentException();
				break;
			case PNG_TYPE_PALETTE:
				if (bitDepth == 1)      imageType = TYPE_INDEXED_2;
				else if (bitDepth == 2) imageType = TYPE_INDEXED_4;
				else if (bitDepth == 4) imageType = TYPE_INDEXED_16;
				else if (bitDepth == 8) imageType = TYPE_INDEXED_256;
				else throw new IllegalArgumentException();
				break;
			default:
				throw new IllegalArgumentException();
		}
		setImageType(imageType);
		return imageType;
	}
	private void toIndexedType(int length)
	{
		switch(length){
		case 2: imageType = TYPE_INDEXED_2; break;
		case 4: imageType = TYPE_INDEXED_4; break;
		case 16: imageType = TYPE_INDEXED_16; break;
		case 256: imageType = TYPE_INDEXED_256; break;
		default:
			throw new IllegalArgumentException();
		}
		setImageType(imageType);
	}
	public int setIndexedType(Color[] colorTable)
	{
		toIndexedType(colorTable.length);
		this.colorTable = new int[colorTable.length];
		for (int i = 0; i<colorTable.length; i++)
			this.colorTable[i] = colorTable[i].toInt();
		return imageType;
	}
	public int setIndexedType(int[] colorTable)
	{
		toIndexedType(colorTable.length);
		this.colorTable = (int[])colorTable.clone();
		return imageType;
	}
	
	public int getImageType()
	{
		return imageType;
	}
	public int getImageScanLineLength()
	{
		return bpl; 
	}
	public int getImageScanLineType()
	{
		return SCAN_LINE_BYTE_ARRAY;
	}
	public boolean usesAlpha() {
		return imageType == TYPE_ARGB;
	}
	/**
	Returns if you can write data to the ImageData.
	**/
//	===================================================================
	public boolean isWriteableImage(){return isWritable;}
//	===================================================================

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void getImageScanLines(int startLine, int numLines,
			Object destArray, int offset, int destScanLineLength)
			throws IllegalStateException {
		if (destScanLineLength == bpl)
			System.arraycopy(bytes,startLine*bpl,destArray,offset,numLines*bpl);
		else for (int i = 0; i<numLines; i++){
			int toCopy = destScanLineLength;
			if (toCopy > bpl) toCopy = bpl;
			System.arraycopy(bytes,(startLine+i)*bpl,destArray,offset+(destScanLineLength*i),toCopy);
		}
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
	 */
	public void setImageScanLines(int startLine, int numLines,
			Object sourceArray, int offset, int sourceScanLineLength)
			throws IllegalStateException {
		if (sourceScanLineLength == bpl)
			System.arraycopy(sourceArray,offset,bytes,startLine*bpl,numLines*bpl);
		else for (int i = 0; i<numLines; i++){
			int toCopy = sourceScanLineLength;
			if (toCopy > bpl) toCopy = bpl;
			System.arraycopy(sourceArray,offset+(sourceScanLineLength*i),bytes,(startLine+i)*bpl,toCopy);
		}
	}


	/* (non-Javadoc)
	 * @see eve.sys.ImageData#getPixels(int[], int, int, int, int, int, int)
	 */
	public int[] getPixels(int[] dest, int offset, int x, int y, int width,
			int height, int rowStride) {
		return getPixelsUsingScanLines(dest,offset,x,y,width,height,rowStride);
	}

	/* (non-Javadoc)
	 * @see eve.sys.ImageData#setPixels(int[], int, int, int, int, int, int)
	 */
	public boolean setPixels(int[] src, int offset, int x, int y, int width,
			int height, int rowStride) {
		return setPixelsUsingScanLines(src,offset,x,y,width,height,rowStride);
	}

	/* (non-Javadoc)
	 * @see eve.fx.Drawable#draw(eve.fx.Graphics, int, int, int)
	 */
	public void draw(Graphics g, int x, int y, int options) {
		// TODO Auto-generated method stub
		Rect src = Rect.getCached(0,0,width,height);
		Rect dest = Rect.getCached(x,y,width,height);
		try{
			g.drawImageData(this,src,dest,0);
		}finally{
			src.cache();
			dest.cache();
		}
	}

}

//####################################################
