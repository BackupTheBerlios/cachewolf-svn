package eve.fx;
/**
* This is used for storing information about an Image retrieved by Image.getImageInfo().
**/
//##################################################################
public class ImageInfo{
//##################################################################

public static final int FORMAT_BMP = 1;
public static final int FORMAT_PNG = 2;
public static final int FORMAT_JPEG = 3;
public static final int FORMAT_GIF = 4;

public int width;
public int height;
public int x;
public int y;
/**
* An estimate on the number of bytes required by the image when decoded.
**/
public int size;
/**
* This will be one of the FORMAT_XXX values.
**/
public int format;
/**
* If this is true it indicates that the image can be scaled while being
* decoded. This may be important if you are decoding very large images on a 
* mobile device. If this is true then you can safely open a Stream to the image bytes and
* then use new Image(stream,0,maxWidth,maxHeight) to create an image that is a scaled
* down version of the original image without having to create a full version first.
**/
public boolean canScale;
/**
* Pause after this image for the specified number of milliseconds.
**/
public int pauseInMillis;
/**
* This is only valid when getting one image out of a set of multiple images.
**/
public Picture image;
//##################################################################
}
//##################################################################

