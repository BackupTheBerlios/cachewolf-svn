package eve.fx;

import java.io.IOException;

import eve.sys.Cache;
import eve.sys.Device;
import eve.sys.ImageData;
import eve.sys.ImageDataInfo;
import eve.util.FormattedDataSource;
import eve.util.IntArray;
import eve.util.StringList;
import eve.util.Utils;


/**
* A PixelBuffer is used to store ARGB pixel information in an integer array.
* This is unlike an Image, which uses a system dependant image implementation.
* However there are some methods, such as draw() which will cause the pixel buffer
* to create an Image from its data for rendering.
* <p>
* PixelBuffers are generally used for composing complex images with alpha (transparency)
* channels. This may be necessary because the normal draw operations done via a Graphics
* object do not support the writing of alpha channel data. For example, you cannot use
* fillRect() to fill an area of a drawing surface with a particular color that has an alpha
* channel. 
* <p>
* Any Images created out of the data from the PixelBuffer will be considered to have
* an alpha (transparency) channel.
**/
//##################################################################
public class PixelBuffer extends ImageObject {
//##################################################################
// This should be discovered by name - do not rename it.
int [] buffer;
//======================
{
	background = Color.White;
}

//-------------------------------------------------------------------
private void checkArea(int x,int y,int w,int h) throws IllegalArgumentException
//-------------------------------------------------------------------
{
	if (x < 0 || y < 0 || w < 0 || h < 0 || x+w > width || y+h > height)
		throw new IllegalArgumentException("The requested area is not within the PixelBuffer: "+(new Rect(x,y,w,h))+" in: "+width+", "+height);
}
//-------------------------------------------------------------------
private void checkArea(IImage im, int x,int y,int w,int h) throws IllegalArgumentException
//-------------------------------------------------------------------
{
	if (x < 0 || y < 0 || w <= 0 || h <= 0 || x+w > im.getWidth() || y+h > im.getHeight()){
		throw new IllegalArgumentException("The requested area is not within the Image");
	}
}
/*
//-------------------------------------------------------------------
private void setup(int width,int height,int [] bufferToUse)
//-------------------------------------------------------------------
{
	//numPixbuffs++;
	//eve.sys.Vm.debug("++PB: "+numPixbuffs);
	if (width < 0 || height < 0) throw new IllegalArgumentException("width or height is unacceptable.");
	this.width = width; 
	this.height = height;
	if (bufferToUse == null) bufferToUse = new int[width*height];
	else if (bufferToUse.length < width*height) throw new IllegalArgumentException("Specified buffer is not big enough.");
	buffer = bufferToUse;
}
*/
/**
 * Resize the PixelBuffer to the specified size and setting it to use the specified
 * int array as its pixel buffer. If the provided buffer is too small or null, 
 * the PixelBuffer will attempt to use its own internal buffer. If this is also too
 * small it will create and use a new one. It will always return the int array that
 * it finally decides to use. It will not clear the PixelBuffer.
 * @param width the new width.
 * @param height the new height.
 * @param bufferToUse the buffer to use, if it is null it will continue using
 * its old buffer.
 * @return the int[] which is now being used.
 */
public int[] resizeTo(int width, int height, int[] bufferToUse)
{
	if (width < 0 || height < 0) throw new IllegalArgumentException("width or height is unacceptable.");
	int need = width*height;
	if (bufferToUse == null || bufferToUse.length < need) bufferToUse = buffer;
	if (bufferToUse == null || bufferToUse.length < need) bufferToUse = new int[need];
	buffer = bufferToUse;
	this.width = width; 
	this.height = height;
	return buffer;
}
/**
 * Create a new PixelBuffer using the IntArray to hold the pixel int array.
 * @param buffer the buffer to use.
 * @param width the width of the PixelBuffer
 * @param height the height of the PixelBuffer.
 */
public PixelBuffer(IntArray buffer,int width,int height)
{
	resizeTo(width,height,buffer == null ? null : buffer.data);
	if (buffer != null && this.buffer != buffer.data)
		buffer.data = this.buffer;
}

public PixelBuffer(IntArray buffer,ImageData src,Rect area)
{
	this(buffer,src.getImageWidth(),src.getImageHeight());
	if (area == null) setTo(src);
	else setTo(src,area);
}
/**
 * Erase the contents but do not resize.
 */
public void clear()
{
	Utils.zeroArrayRegion(buffer,0,width*height);
}
//===================================================================
public PixelBuffer(int width,int height,int [] bufferToUse) throws IllegalArgumentException
//===================================================================
{
	this();
	resizeTo(width,height,bufferToUse);
}
//===================================================================
public PixelBuffer(int width,int height) throws IllegalArgumentException
//===================================================================
{
	this(width,height,null);
}
public void createImageFor(ImageDataInfo imageInfo,Rect interestedArea) throws IllegalArgumentException 
{
	resizeTo(imageInfo.width,imageInfo.height,null);
}

PixelBuffer(FormattedDataSource fds, ImageDecoder decoded)
{
	this();
	background = null;
	ImageDecoder ic = decoded;
	try{
		resizeTo(ic.width,ic.height,null);
		ic.decodeFully(this);
	}catch(IOException e){
		throw new ImageDecodingException(fds,e);
	}finally{
		if (fds != null) fds.close();
	}
}
public PixelBuffer(String name) throws ImageDecodingException
{
	this();
	background = null;
	FormattedDataSource fds = new FormattedDataSource();
	try{
		fds.set(name);
		new ImageDecoder(fds,this);
	}catch(IOException e){
		throw new ImageDecodingException(fds,e);
	}finally{
		fds.close();
	}
}
public PixelBuffer(FormattedDataSource fds) throws ImageDecodingException
{
	setTo(fds);
}
public PixelBuffer(FormattedDataSource fds, Rect sourceArea, Dimension newSize, int createOptions) throws ImageDecodingException
{
	background = null;
	try{
		new ImageDecoder().decode(fds,this,sourceArea,newSize,createOptions);
	}finally{
		if (fds != null) fds.close();
	}
}
public void setTo(FormattedDataSource fds) throws ImageDecodingException
{
	background = null;
	try{
		new ImageDecoder(fds,this);
	}finally{
		if (fds != null) fds.close();
	}
}
//===================================================================
/**
 * Set the PixelBuffer dimensions to match the source IImage and set the pixels
 * in the PixelBuffer from the source.
 * @param source a source IImage.
 * @return this PixelBuffer.
 */
public PixelBuffer setTo(ImageData sourceData)
//===================================================================
{
	IImage source = ImageAdapter.toIImage(sourceData,null);
	resizeTo(source.getWidth(),source.getHeight(),null);
	if (source.getPixels(buffer,0,0,0,width,height,0) == null){
		//if (true) throw new IllegalArgumentException("Cannot get pixel data from supplied IImage");
		Graphics g = getDrawingBuffer(null,null,1);
		source.draw(g,0,0,0);
		putDrawingBuffer(PUT_SET);
	}
	return this;
}
//===================================================================
/**
 * Set the PixelBuffer dimensions to match an area in a source IImage and set the pixels
 * in the PixelBuffer from the area in the source.
 * @param source a source IImage
 * @param area an area within the IImage.
 * @throws IllegalArgumentException
  * @return this PixelBuffer.
*/
public PixelBuffer setTo(ImageData sourceData,Rect area) throws IllegalArgumentException
//===================================================================
{
	IImage source = ImageAdapter.toIImage(sourceData,null);
	checkArea(source,area.x,area.y,area.width,area.height);
	resizeTo(area.width,area.height,null);
	if (source.getPixels(buffer,0,area.x,area.y,area.width,area.height,0) == null){
		Graphics g = getDrawingBuffer(null,null,1);
		source.draw(g,-area.x,-area.y,0);
		putDrawingBuffer(PUT_SET);
	}
	return this;
}
/**
 * Set this PixelBuffer to contain a portion or whole part of a Drawable. The size
 * of this PixelBuffer must be set to the size that you want to capture.
 * @param d the Drawable to capture.
 * @param sx the start x location in the Drawable to capture from.
 * @param sy the start y location in the Drawable to capture from.
 * @param unusedColor an optional color that is definitely unused by the drawable.
 * @return this PixelBuffer.
 */
public PixelBuffer setTo(Drawable d,int sx, int sy,Color unusedColor)
{
	Graphics g = getDrawingBuffer(null,unusedColor,1.0);
	d.draw(g,-sx,-sy,0);
	putDrawingBuffer(PixelBuffer.PUT_SET);
	return this;
}
//===================================================================
public PixelBuffer(ImageData from,Rect area) throws IllegalArgumentException
//===================================================================
{
	this();
	setTo(from,area);
}
//===================================================================
public PixelBuffer(ImageData from)
//===================================================================
{
	this();
	setTo(from);
}

//===================================================================
/**
 * After using this constructor you must call resizeTo() or setTo() before
 * attempting to access the pixels.
 */
public PixelBuffer()
//===================================================================
{
}
//===================================================================
public PixelBuffer(ImageData from,Rect sourceArea,Dimension newSize,Object useBuffer)
//===================================================================
{
	this();
	PixelBuffer pb = sourceArea == null ? new PixelBuffer(from) : new PixelBuffer(from,sourceArea);
	if (newSize != null) pb = pb.scale(newSize.width,newSize.height,useBuffer);
	resizeTo(pb.width,pb.height,pb.buffer);
/*
	if (sourceArea == null) sourceArea = new Rect(0,0,from.getWidth(),from.getHeight());
	if (newSize != null) setup(newSize.width,newSize.height,useBuffer);
	else setup(sourceArea.width,sourceArea.height,useBuffer);
	if (newSize == null){
		if (from.getPixels(buffer,0,sourceArea.x,sourceArea.y,sourceArea.width,sourceArea.height,0) == null){
			//if (true) throw new IllegalArgumentException("Cannot get pixel data from supplied IImage");
			Graphics g = getDrawingBuffer(null,null,1);
			from.draw(g,-sourceArea.x,-sourceArea.y,0);
			putDrawingBuffer(PUT_SET);
		}
	}else{
		
	}
	*/
}
/**
* This exposes the internal buffer that contains the pixel data.
**/
//===================================================================
public int [] getBuffer()
//===================================================================
{
	return buffer;
}
//private Image image, 
private Image drawing;
/**
* If you modify the pixels in the buffer as provided by getBuffer(), then
* call this method to let the buffer know about the changes.
**/
//===================================================================
public void bufferChanged()
//===================================================================
{
	//if (image != null) image.free();
	//image = null;
}
//===================================================================
public int getWidth() {return width;}
public int getHeight() {return height;}
//===================================================================
public void free() 
//===================================================================
{
	super.free();
	if (drawing != null) drawing.free();
	if (drawBufferGraphics != null) drawBufferGraphics.free();
	buffer = null;
	drawBufferGraphics = null;
	drawing = null;
}
/**
* This is the same as put(other,x,y,PUT_BLEND).
**/
//===================================================================
public void blend(PixelBuffer other,int x,int y)
//===================================================================
{
	put(other,x,y,PUT_BLEND);
}
/**
* This is used with put() - it alpha blends in the incoming data with this PixelBuffer's data.
**/
public static final int PUT_BLEND = 1;
/**
* This is used with put() - it overwrites this PixelBuffer's data with in the incoming data.
**/
public static final int PUT_SET = 2;

/**
* This is used with put() and the PUT_SET option - it overwrites this PixelBuffer's data with in the incoming data so
* long as the incoming data is NOT FULLY TRANSPARENT (i.e an alpha value of 0).
**/
public static final int PUT_NONTRANSPARENT_ONLY = 0x80000000;
/**
* This is used with put() and the PUT_SET option - it overwrites this PixelBuffer's data with in the incoming data so
* only if the incoming data is FULLY OPAQUE (i.e an alpha value of 1.0).
**/
//public static final int PUT_FULLYOPAQUE_ONLY = 0x40000000;
/**
 * This merges the pixels from the other PixelBuffer with the pixels in this PixelBuffer at the
	specified location. 
	This will either replace the pixels in this PixelBuffer (if the PUT_SET)
	option is used OR it will blend the incoming pixels with the pixels in this PixelBuffer (if
	the PUT_BLEND) option is used.
 * @param other The other PixelBuffer to merge with this one.
 * @param x The x location where the incoming PixelBuffer should be put.
 * @param y The y location where the incoming PixelBuffer should be put.
 * @param operation This should be either PUT_SET or PUT_BLEND. If PUT_SET is used you can
	also specify PUT_NONTRANSPARENT_ONLY which tells it to replace pixels in this PixelBuffer 
	ONLY if the corresponding incoming pixels are not fully transparent.
 */
//===================================================================
public void put(PixelBuffer other,int x,int y,int operation)
//===================================================================
{
	put(other,x,y,operation,null);
}
/*
or PUT_FULLYOPAQUE_ONLY which tells it to replace pixels in this PixelBuffer 
ONLY if the corresponding incoming pixels are fully opaque.
*/
private Object [] buff = new Object[3];

//-------------------------------------------------------------------
private void checkMask(Mask mask,PixelBuffer pixbuff)
//-------------------------------------------------------------------
{
	if (mask != null)
		if (mask.width != pixbuff.width || mask.height != pixbuff.height)
			throw new IllegalArgumentException("The Mask is not the same size as the PixelBuffer");
}
/**
 * This merges the pixels from the other PixelBuffer with the pixels in this PixelBuffer at the
	specified location. 
	This will either replace the pixels in this PixelBuffer (if the PUT_SET)
	option is used OR it will blend the incoming pixels with the pixels in this PixelBuffer (if
	the PUT_BLEND) option is used.
 * @param other The other PixelBuffer to merge with this one.
 * @param x The x location where the incoming PixelBuffer should be put.
 * @param y The y location where the incoming PixelBuffer should be put.
 * @param operation This should be either PUT_SET or PUT_BLEND. 
 * @param mask A mask specifying which incoming pixels should be merged with the Pixels in 
 * this PixelBuffer.
 */
//===================================================================
public void put(PixelBuffer other,int x,int y,int operation,Mask mask)
//===================================================================
{
	checkMask(mask,other);
	buff[0] = new Rect(x,y,operation,0);
	buff[1] = mask == null ? null : mask.bits;
	pixbufOperation(other,buff,PUT);
	bufferChanged();
}
/**
 * This method will go through the pixel buffer data and set the alpha value of each
 * pixel to the specified value (between 0.0 and 1.0).
* @param alpha The alpha value between 0.0 and 1.0
**/
//===================================================================
public PixelBuffer setAlpha(double alpha)
//===================================================================
{
	setAlpha((Color)null,alpha);
	return this;
}
/**
 * This method will go through the pixel buffer data and set the alpha value of each
 * pixel to the specified value (between 0.0 and 1.0), EXCEPT for any pixels that is equal
 * to the transparent Color - those pixels will be set to have an alpha value of 0. If this is
 * null, then all pixels will have the alpha value set to the same.
 * @param transparent the transparent Color.
* @param alpha The alpha value between 0.0 and 1.0
*/
//===================================================================
public PixelBuffer setAlpha(Color transparent,double alpha)
//===================================================================
{
	int[] buff = new int[3];
	buff[0] = (int)(alpha*255);
	buff[1] = transparent == null ? 0xff000000 : (Graphics.mapColor(transparent.toInt() & 0xffffff) & 0xffffff);
	buff[2] = transparent == null ? 0xff000000 : (transparent.toInt() & 0xffffff);
	pixbufOperation(buff,null,SET_ALPHA);
	bufferChanged();
	return this;
}
//===================================================================
public PixelBuffer setAlpha(Color fullyOpaque,Color fullyTransparent,double alpha)
//===================================================================
{
	int[] buff = new int[5];
	buff[0] = (int)(alpha*255);
	buff[1] = (Graphics.mapColor(fullyTransparent.toInt() & 0xffffff) & 0xffffff);
	buff[2] = (fullyTransparent.toInt() & 0xffffff);
	buff[3] = (Graphics.mapColor(fullyOpaque.toInt() & 0xffffff) & 0xffffff);
	buff[4] = (fullyOpaque.toInt() & 0xffffff);
	pixbufOperation(buff,null,SCALE_ALPHA_BETWEEN);
	bufferChanged();
	return this;
}
/**
 * This method will go through the pixel buffer data and set the alpha value of each
 * pixel which is included in the mask. Pixels not in the mask will have their pixel values set to 0.
 * @param mask The pixel mask.
* @param alpha The alpha value between 0.0 and 1.0
*/
//===================================================================
public PixelBuffer setAlpha(Mask mask,double alpha)
//===================================================================
{
	int[] buff = new int[3];
	buff[0] = (int)(alpha*255);
	checkMask(mask,this);
	pixbufOperation(buff,mask.bits,SET_ALPHA);
	bufferChanged();
	return this;
}

/**
 * This method will go through the pixel buffer data and scale the alpha value of
 * each pixel by the specified amount - not allowing any alpha value to go higher than 1.0. Note
 * that totally transparent pixels (alpha value of 0) will always remain fully transparent.
 */
//===================================================================
public PixelBuffer scaleAlpha(double byHowMuch)
//===================================================================
{
	if (byHowMuch < 0) byHowMuch = 0;
	else if (byHowMuch > 256.0) byHowMuch = 256.0;
	int[] buff = new int[1];
	buff[0] = (int)(byHowMuch*0x100);
	pixbufOperation(buff,null,SCALE_ALPHA);
	bufferChanged();
	return this;
}
/**
* This always returns true.
**/
//===================================================================
public boolean usesAlpha() {return true;}
//===================================================================
/* (non-Javadoc)
 * @see eve.fx.ImageData#isWritableImage()
 */
public boolean isWriteableImage() {
	return true;
}

private Rect drawBufferArea;
private Color drawBufferColor;
private Color drawBufferForeground;
private double drawBufferAlpha;
private Graphics drawBufferGraphics;
/**
 * This will create a drawing surface, initially filled with the supplied transparent color.
 * After calling this method, draw on the surface using the supplied Graphics and when complete
 * call putDrawingBuffer(int operation) to put back the drawing buffer pixels into the original 
 PixelBuffer.
 * @param area An area within the pixbuf to use - will default to the entire area if null.
 * @param transparent The initial color to consider the transparent color when putting
	the area back into the PixelBuffer, or Color(80,255,80) if none is supplied.
 * @param alphaValue the alphaValue to set all the non-transparent pixels to (between 0.0 and 1.0).
 * @return a Graphics object that you can use to draw on.
 */
//===================================================================
public Graphics getDrawingBuffer(Rect area,Color transparent,double alphaValue)
//===================================================================
{
	return getDrawingBuffer(area,transparent,alphaValue,null);
}
/**
 * This will create a drawing surface, initially filled with the supplied transparent color.
 * After calling this method, draw on the surface using the supplied Graphics and when complete
 * call putDrawingBuffer(int operation) to put back the drawing buffer pixels into the original 
 PixelBuffer.
 * @param area An area within the pixbuf to use - will default to the entire area if null.
 * @param transparent The initial color to consider the transparent color when putting
	the area back into the PixelBuffer, or Color(80,255,80) if none is supplied.
 * @param alphaValue the alphaValue to set all the non-transparent pixels to (between 0.0 and 1.0).
 * @param drawingColor the color that is to be considered fully opaque. Colors
 * between this color and the transparent color will be scaled in alpha between
 * the alphaValue supplied and a zero alpha color. If this is null then no
 * scaling of the alpha value is done.
 * @return a Graphics object that you can use to draw on.
 */
//===================================================================
public Graphics getDrawingBuffer(Rect area,Color transparent,double alphaValue,Color drawingColor)
//===================================================================
{
	if (drawBufferArea == null) {
		drawBufferArea = new Rect();
		drawBufferColor = new Color(0,0,0);
	}
	if (area == null) drawBufferArea.set(0,0,width,height);
	else drawBufferArea.set(area);
	if (transparent == null) drawBufferColor.set(80,255,80);
	else drawBufferColor.set(transparent);
	drawBufferAlpha = alphaValue;
	//
	if (drawingColor == null) drawBufferForeground = null;
	else {
		drawBufferForeground = drawingColor.getCopy();
		if (transparent == null){
			int dbf = drawingColor.toInt();
			dbf = (((dbf>>0)&0xff)+((dbf>>8)&0xff)+((dbf>>16)&0xff))/3;
			if (dbf >= 128) drawBufferColor.set(0,0,0);
			else drawBufferColor.set(255,255,255);
		}
	}
	//
	if (drawing != null)
 		if (drawing.getWidth() != drawBufferArea.width || drawing.getHeight() != drawBufferArea.height){
			drawing.free();
			drawing = null;
		}
				
	if (drawing == null) drawing = new Image(drawBufferArea.width,drawBufferArea.height,Image.TYPE_RGB);
	drawBufferGraphics = new Graphics(drawing);
	drawBufferGraphics.setColor(drawBufferColor);
	drawBufferGraphics.fillRect(0,0,drawBufferArea.width,drawBufferArea.height);
	drawBufferGraphics.setColor(drawBufferForeground == null ? Color.Black : drawBufferForeground);
	return drawBufferGraphics;
}
/**
 * Return the last Graphics returned by getDrawingBuffer().
 */
public Graphics getCurrentDrawingBuffer()
{
	return drawBufferGraphics;
}
/**
 * Call this after calling getDrawingBuffer() to update this PixelBuffer with the data you
 * have drawn.
 * This will put the data that was drawn onto the Graphics created by getDrawingBuffer(), using
 * one of the PUT_ operations.
 * @param operation One of PUT_BLEND or PUT_SET
 */
//===================================================================
public void putDrawingBuffer(int operation)
//===================================================================
{
	if (drawBufferForeground != null)
		putDrawingBuffer(operation,drawBufferForeground,drawBufferColor);
	else
		putDrawingBuffer(operation,(Mask)null);
}
/**
 * Call this after calling getDrawingBuffer() to update this PixelBuffer with the data you
 * have drawn, in the area specified by the mask.
 * This will put the data that was drawn onto the Graphics created by getDrawingBuffer(), using
 * one of the PUT_ operations.
 * @param operation One of PUT_BLEND or PUT_SET
 * @param mask A mask specifying which pixels should be put. Any pixels not in this area are unchanged.
 */
//===================================================================
public void putDrawingBuffer(int operation,Mask mask)
//===================================================================
{
	if (drawBufferGraphics != null) drawBufferGraphics.free();
	PixelBuffer pb = (PixelBuffer)Cache.get(PixelBuffer.class);
	Rect r = Rect.getCached(0,0,drawBufferArea.width,drawBufferArea.height);
	try{
		pb.setTo(drawing,r);
		if (mask == null) pb.setAlpha(drawBufferColor,drawBufferAlpha);
		else pb.setAlpha(mask,drawBufferAlpha);
		put(pb,drawBufferArea.x,drawBufferArea.y,operation,mask);
	}finally{
		Cache.put(pb);
		r.cache();
	}
}
/**
 * Call this after calling getDrawingBuffer() to update this PixelBuffer with the data you
 * have drawn if you want to alter the alpha value of the pixels in the PixelBuffer depending
 * on the difference in color of the pixels between the fullyOpaque and the fullyTransparent color
 * (which should be as different as possible).<p>
 * The "value" of a pixel bit is determined by averaging the RGB values. Values
 * with an average equal to the fullyOpaque value is set to the full alpha value
 * specified in getDrawingBuffer(). Values with an average equal to the fullyTransparent
 * value is set to a zero alpha value.
 * This will put the data that was drawn onto the Graphics created by getDrawingBuffer(), using
 * one of the PUT_ operations.
 * @param operation One of PUT_BLEND or PUT_SET
 * @param fullyOpaque pixels with this color will be assigned the greatest alpha value (the value
 * specified in getDrawingBuffer()).
 * @param fullyTransparent pixels with this color will be assigned an alpha value
 * of zero.
 */
public void putDrawingBuffer(int operation,Color fullyOpaque,Color fullyTransparent)
{
	if (drawBufferGraphics != null) drawBufferGraphics.free();
	PixelBuffer pb = (PixelBuffer)Cache.get(PixelBuffer.class);
	Rect r = Rect.getCached(0,0,drawBufferArea.width,drawBufferArea.height);
	try{
		pb.setTo(drawing,r,fullyOpaque,fullyTransparent,drawBufferAlpha);
		put(pb,drawBufferArea.x,drawBufferArea.y,operation);
	}finally{
		Cache.put(pb);
		r.cache();
	}
}
/**
 * Set the PixelBuffer dimensions to match an area in a source IImage and set the pixels
 * in the PixelBuffer from the area in the source.
 * @param source a source IImage
 * @param area an area within the IImage.
 * @throws IllegalArgumentException
  * @return this PixelBuffer.
*/
public PixelBuffer setTo(ImageData sourceData,Rect area,Color fullyOpaque,Color fullyTransparent,double opaqueAlpha) throws IllegalArgumentException
//===================================================================
{
	setTo(sourceData, area);
	setAlpha(fullyOpaque, fullyTransparent, opaqueAlpha);
	return this;
}
//-------------------------------------------------------------------
private Image toImage(Image image)
//-------------------------------------------------------------------
{
	if (image == null || image.width != width || image.height != height) {
		image = new Image(width,height,Image.TYPE_ARGB);
	}
	image.setPixels(buffer,0,0,0,width,height,width);
	return image;
}

/**
* This returns a new Image with an alpha channel
* from the pixels within this PixelBuffer. 
**/
//===================================================================
public Image toImage()
//===================================================================
{
	Image im = new Image(width,height,Image.TYPE_ARGB);
	//im.enableAlpha();
	toImage(im);
	return im;
}
/**
* This returns a new Picture with an alpha channel
* from the pixels within this PixelBuffer. 
**/
//===================================================================
public Picture toPicture()
//===================================================================
{
	return new Picture(this,0);
}
//===================================================================
public void draw(Graphics g,int x,int y,int options)
//===================================================================
{
	g.drawRGB(buffer,0,x,y,width,height,width,true);
}

//===================================================================
public PixelBuffer getArea(int x,int y,int width,int height) throws IllegalArgumentException
//===================================================================
{
	return new PixelBuffer(width,height,getPixels(null,0,x,y,width,height,0));
}

//===================================================================
public PixelBuffer scale(int newWidth,int newHeight,Object useBuffer)
//===================================================================
{
	return scale(newWidth,newHeight,null,0,useBuffer);
}

//===================================================================
public PixelBuffer scale(int newWidth,int newHeight)
//===================================================================
{
	return scale(newWidth,newHeight,null,0,null);
}

/**
* An option for scale().
**/
public static final int SCALE_KEEP_ASPECT_RATIO = 0x1;


/**
 * Scale the PixelBuffer to produce a new PixelBuffer - optionally scaling only a portion of
	the original PixelBuffer.
 * @param newWidth The width of the new PixelBuffer.
 * @param newHeight The height of the new PixelBuffer.
 * @param sourceArea An optional rectangle specifying the source area in this PixelBuffer.
	If it is null then entire area is used.
 * @param scaleOptions This can be zero or SCALE_KEEP_ASPECT_RATIO.
 * @param useBuffer An optional re-usable buffer to use for the data calculations. It can
	be a ByteArray or a byte [] object.
 * @return The new scaled PixelBuffer.
 * @exception IllegalArgumentException If there was an error with any of the arguments. 
 */
//===================================================================
public PixelBuffer scale(int newWidth,int newHeight,Rect sourceArea,int scaleOptions,Object useBuffer) throws IllegalArgumentException
//===================================================================
{
	if (sourceArea == null) sourceArea = new Rect(0,0,width,height);
	else checkArea(sourceArea.x,sourceArea.y,sourceArea.width,sourceArea.height);
	if (newWidth < 0 || newHeight < 0) throw new IllegalArgumentException();
	int [] dest; 
	if (useBuffer instanceof int []) dest = (int [])useBuffer;
	else if (useBuffer instanceof eve.util.IntArray) {
		eve.util.IntArray ia = (eve.util.IntArray)useBuffer;
		if (ia.data.length < newWidth * newHeight) ia.data = new int[newWidth * newHeight];
		dest = ia.data;
	}else
		dest = new int[newWidth * newHeight];
	if (dest.length < newWidth * newHeight) throw new IllegalArgumentException();
	if ((scaleOptions & SCALE_KEEP_ASPECT_RATIO) != 0){
		double xscale =(double)newWidth/width;
		double yscale = (double)newHeight/height;
		double scale = Math.min(xscale,yscale);
		newWidth = (int)(scale*width);
		newHeight = (int)(scale*height);
		if (newWidth < 1) newWidth = 1;
		if (newHeight < 1) newHeight = 1;
	}
	if (newWidth > 0 && newHeight > 0){
		Object [] p = new Object[2];
		p[0] = sourceArea;
		p[1] = new Rect(scaleOptions,0,newWidth,newHeight);
		pixbufOperation(dest,p,SCALE);
	}
	return new PixelBuffer(newWidth,newHeight,dest);
}
/**
* This is a transformation for the transform() method.
**/
public static final int TRANSFORM_ROTATE_90 = 1;
/**
* This is a transformation for the transform() method.
**/
public static final int TRANSFORM_ROTATE_180 = 2;
/**
* This is a transformation for the transform() method.
**/
public static final int TRANSFORM_ROTATE_270 = 3;
/**
* This is a transformation for the transform() method.
**/
public static final int TRANSFORM_MIRROR_HORIZONTAL = 4;
/**
* This is a transformation for the transform() method.
**/
public static final int TRANSFORM_MIRROR_VERTICAL = 5;
/**
* This does one of a number of specific transformations on the PixelBuffer.
* @param transformation One of the TRANSFORM_XXX values.
* @param useBuffer An optional int [] or IntArray object to use as the buffer for the
* newly created PixelBuffer, or a PixelBuffer.
* @return A new PixelBuffer holding the transformed image (this may be of different dimensions
* to the original).
*/
//===================================================================
public PixelBuffer transform(int transformation,Object useBuffer)
//===================================================================
{
	int newWidth = width, newHeight = height;
	if (transformation == TRANSFORM_ROTATE_90 || transformation == TRANSFORM_ROTATE_270){
		newWidth = height;
		newHeight = width;
	}
	int [] dest = null; 
	if (useBuffer instanceof int []) dest = (int [])useBuffer;
	else if (useBuffer instanceof eve.util.IntArray) {
		eve.util.IntArray ia = (eve.util.IntArray)useBuffer;
		if (ia.data.length < newWidth * newHeight) ia.data = new int[newWidth * newHeight];
		dest = ia.data;
	}else if (useBuffer instanceof PixelBuffer){
		PixelBuffer pd = (PixelBuffer)useBuffer;
		pd.resizeTo(newWidth,newHeight,null);
		pixbufOperation(pd.buffer,null,TRANSFORM+transformation);
		return pd;
	}else
		dest = new int[newWidth * newHeight];
	if (dest.length < newWidth * newHeight) 
		dest = new int[newWidth*newHeight];//throw new IllegalArgumentException();
	pixbufOperation(dest,null,TRANSFORM+transformation);
	return new PixelBuffer(newWidth,newHeight,dest);
}
//===================================================================
public int [] getPixels(int []dest,int offset,int x,int y,int w,int h,int rowStride) throws IllegalArgumentException
//===================================================================
{
	checkArea(x,y,w,h);
	return getPixelArea(this,buffer,width,height,dest,offset,x,y,w,h,rowStride);
}
//-------------------------------------------------------------------
private static int [] getPixelArea(ImageData id,int [] source,int sourceWidth,int sourceHeight,int [] dest,int destOffset,int x,int y,int w,int h,int rowStride)
//-------------------------------------------------------------------
{
	if (rowStride == 0) rowStride = w;
	//if (x < 0 || y < 0 || w < 0 || h < 0 || x+w > sourceWidth || y+h > sourceHeight) throw new IllegalArgumentException();
	dest = ImageTool.validatePixelBuffer(true,id,dest,destOffset,w,h,rowStride);
	//if (dest == null) dest = new int[w*h+destOffset];
	//else if (dest.length < destOffset+w*h) throw new IllegalArgumentException();
	if (rowStride == sourceWidth && h == sourceHeight && x == 0 && y == 0)
		System.arraycopy(source,0,dest,destOffset,w*h);
	else if (w != 0 && h != 0){
		int so = y*sourceWidth+x;
		int doff = destOffset;
		for (int yy = 0; yy < h; yy++){
			System.arraycopy(source,so,dest,doff,w);	
			so += sourceWidth;
			doff += rowStride;
		}
	}
	return dest;
}
/**
 * Set this PixelBuffer to be text with possible blended edges represented
 * by reduced alpha values. The PixelBuffer is set to the bounding rect
 * for the text and the text is aligned within it as specified.
 * @param f the Font to use.
 * @param text the text. If it contains '\n' characters it is split into
 * separate lines.
 * @param alignment either Graphics.LEFT or Graphics.RIGHT or Graphics.CENTER.
 * @param color the color to draw the text in.
 * @param alphaValue the maximum alpha value for the text.
 * @param fts optional FormattedTextSpecs to format the text.
 * @return this PixelBuffer.
 */
public PixelBuffer setTo(Font f, String text, int alignment, Color color, double alphaValue)
{
	StringList sl = StringList.getCached().split(text, '\n');
	try{
		return setTo(f,sl,alignment,color,alphaValue,null);
	}finally{
		sl.cache();
	}
}
/**
 * Set this PixelBuffer to be text with possible blended edges represented
 * by reduced alpha values. The PixelBuffer is set to the bounding rect
 * for the text and the text is aligned within it as specified.
 * @param f the Font to use.
 * @param text the text.
 * @param alignment either Graphics.LEFT or Graphics.RIGHT or Graphics.CENTER.
 * @param color the color to draw the text in.
 * @param alphaValue the maximum alpha value for the text.
 * @param fts optional FormattedTextSpecs to format the text.
 * @return this PixelBuffer.
 */
public PixelBuffer setTo(Font f, StringList text, int alignment, Color color, double alphaValue, FormattedTextSpecs fts)
{
	Dimension d = Dimension.getCached(0, 0);
	Rect r = Rect.getCached();
	try{
		FontMetrics fm = Fx.getFontMetrics(f);
		Metrics.getSize(fm, text, 0, text.size(), d, fts);
		r.set(0,0,d.width,d.height);
		resizeTo(d.width, d.height, null);
		Graphics g = getDrawingBuffer(r, null, alphaValue, color);
		Metrics.drawText(g, fm, text.toBestText(), r, alignment, 0, 0, text.size(), fts);
		putDrawingBuffer(PUT_SET);
		return this;
	}finally{
		d.cache();
		r.cache();
	}
}
//===================================================================
public boolean setPixels(int []dest,int offset,int x,int y,int w,int h,int rowStride) throws IllegalArgumentException
//===================================================================
{
	checkArea(x,y,w,h);
	setPixelArea(buffer,width,height,dest,offset,x,y,w,h,rowStride);
	return true;
}
//-------------------------------------------------------------------
private static void setPixelArea(int [] dest,int destWidth,int destHeight,int [] src,int srcOffset,int x,int y,int w,int h,int rowStride)
//-------------------------------------------------------------------
{
	if (rowStride == 0) rowStride = w;
	//if (x < 0 || y < 0 || w < 0 || h < 0 || x+w > sourceWidth || y+h > sourceHeight) throw new IllegalArgumentException();
	if (src == null) return;
	else if (src.length < srcOffset+w*h) throw new IllegalArgumentException();
	if (rowStride == destWidth && h == destHeight && x == 0 && y == 0)
		System.arraycopy(src,srcOffset,dest,0,w*h);
	else if (w != 0 && h != 0){
		int destOff = y*destWidth+x;
		int soff = srcOffset;
		for (int yy = 0; yy < h; yy++){
			System.arraycopy(src,soff,dest,destOff,w);	
			destOff += destWidth;
			soff += rowStride;
		}
	}
}

//-------------------------------------------------------------------
private static boolean hasNative = true;
//-------------------------------------------------------------------
private static final int SET_ALPHA = 1;
private static final int SCALE_ALPHA = 2;
private static final int PUT = 3;
private static final int SCALE = 4;
private static final int SCALE_ALPHA_BETWEEN = 5;
private static final int TRANSFORM = 10;
/*
private static Object[] pars;
private static int[] intPars;
//-------------------------------------------------------------------
private static Object[] getPars()
//-------------------------------------------------------------------
{
	if (pars == null) pars = new Object[10];
	if (intPars == null) intPars = new int[10];
	return pars;
}
//-------------------------------------------------------------------
private static int [] getIntPars()
//-------------------------------------------------------------------
{
	getPars();
	return intPars;
}
*/
//-------------------------------------------------------------------
static private final int blend(int as,int ad,int s,int d,int shift)
//-------------------------------------------------------------------
{
	int cs, cd, ascs, adcd;
	ascs = (((s >> shift) & 0xff)*as) >> 8; cd = (d >> shift) & 0xff;
	if (ad == 0xff) ascs += cd-((cd *as) >> 8);
	else if (ad != 0){
		adcd = (cd*ad) >> 8; ascs += adcd; adcd = (adcd*as)>>8; ascs -= adcd;
	}
	if (ascs < 0) ascs = 0;
	else ascs &= 0xff;
	return	ascs << shift;
}
//-------------------------------------------------------------------
private int pixbufOperation(Object par1,Object par2,int operation)
//-------------------------------------------------------------------
{
	if (hasNative)
 	try{
		return nativePixbufOperation(par1,par2,operation,width,height,buffer);
 	}catch(Throwable t){
 		Device.checkNoNativeMethod(t);
	}
	
	if (operation > TRANSFORM){
		int [] src = this.buffer;
		int [] dest = (int [])par1;
		int sx, sy, dx, dy, soff, doff;
		int height = this.height;
		int width = this.width;
		switch(operation-TRANSFORM){
			case 1: // Rotate 90
				soff = 0;
				for (sy = 0; sy<height; sy++){
					doff = height-sy-1;
					for (sx = 0; sx<width; sx++){
						dest[doff] = src[soff++];
						doff += height;
					}
				}
				break;
			case 2: // Rotate 180
				soff = 0;
				for (sy = 0; sy<height; sy++){
					doff = (height-sy)*width;
					for (sx = 0; sx<width; sx++){
						dest[--doff] = src[soff++];
					}
				}
				break;
			case 3: // Rotate 270
				soff = 0;
				for (sy = 0; sy<height; sy++){
					doff = ((width-1)*height)+sy;
					for (sx = 0; sx<width; sx++){
						dest[doff] = src[soff++];
						doff -= height;
					}
				}
				break;
			
			case 4: // HMirror
				soff = 0;
				for (sy = 0; sy<height; sy++){
					doff = soff+width;
					for (sx = 0; sx<width; sx++)
						dest[--doff] = src[soff++];
				}
				break;
			case 5: // VMirror
				soff = 0;
				for (sy = 0; sy<height; sy++){
					doff = (height-1-sy)*width;
					for (sx = 0; sx<width; sx++)
						dest[doff++] = src[soff++];
				}
				break;
				
			default: return 0;
		}
		return 1;
	}
	
	switch(operation){
	
	
	case PUT: {
		PixelBuffer other = (PixelBuffer)par1;
		Object [] pbuff = (Object [])par2;
		Rect p2 = (Rect)pbuff[0];
		byte [] masks = (byte [])pbuff[1];
		int width = this.width, height = this.height;
		int[] dest = this.buffer;
		int[] src = other.buffer;
		int x = p2.x, y = p2.y, op = p2.width & ~PUT_NONTRANSPARENT_ONLY, w = other.width, h = other.height;
		boolean to = (p2.width & PUT_NONTRANSPARENT_ONLY) != 0;
		int so = 0;
		for (int yy = 0; yy < h; yy++){
			int off = (yy+y)*width+x;
			int bpl = (w+7)/8;
			int moff = bpl*yy-1;
			byte by = 0;
			byte mask = (byte)0x01;
			for (int xx = 0; xx < w; xx++){
				if (masks != null){
					mask = (byte)((mask >> 1) & 0x7f);
					if (mask == 0) {
						mask = (byte)0x80;
						moff++;
						by = masks[moff];
					}
					if ((by & mask) == 0) {
						so++;
						off++;
						continue;
					}
				}
				int s = src[so++];
				if (op == PUT_SET){
					if (!to || ((s & 0xff000000) != 0)) dest[off] = s;
				}else if (op == PUT_BLEND){
					int as = (s >> 24) & 0xff;
					if (as == 0xff) dest[off] = s;
					else if (as == 0) 
						;
					else{
						int d = dest[off], ad = (d >> 24) & 0xff;
						int save = 0;
						save |= blend(as,ad,s,d,16);
						save |= blend(as,ad,s,d,8);
						save |= blend(as,ad,s,d,0);
						save |= blend(as,ad,0xff000000,0xff000000,24);
						dest[off] = save;

					}
				}
				off++;
			}
		}
	}
	break;
	case SET_ALPHA:{
		int[] dest = this.buffer;
		int[] p = (int [])par1;
		byte[] masks = (byte [])par2;
		int len = dest.length;
		int alpha = p[0], ashift = 0;
		if (alpha < 0) alpha = 0;
		else if (alpha > 255) alpha = 255;
		ashift = alpha << 24;
		if (masks != null){
			int bpl = (width+7)/8;
			int y = 0, i = 0;
			for (y = 0; y<height; y++){
				int off = bpl*y-1;
				byte by = 0;
				byte mask = (byte)0x01;
				int x;
				for (x = 0; x<width; x++){
					mask = (byte)((mask >> 1) & 0x7f);
					if (mask == 0) {
						mask = (byte)0x80;
						off++;
						by = masks[off];
					}
					if ((by & mask) != 0) 
						dest[i] = (dest[i] & 0xffffff)|ashift;
					i++;
				}
			}
		}else{
			int tc1 = 0, tc2 = 0;
			boolean hasColor = (tc1 & 0xff000000) == 0;
			tc1 = p[1];
			tc2 = p[2];
			for (int i = 0; i<len; i++){
				int d = dest[i];
				int d2 = d & 0xffffff;
				if (hasColor){
					if (d2 != tc1 && d2 != tc2) dest[i] = d2 | ashift;
					else dest[i] = d2;
				}else
					dest[i] = d2 | ashift;
			}
		}
	break;
	}
	case SCALE_ALPHA_BETWEEN:{
		int[] dest = this.buffer;
		int[] p = (int [])par1;
		int len = dest.length;
		int alpha = p[0], ashift = 0;
		if (alpha < 0) alpha = 0;
		else if (alpha > 255) alpha = 255;
		ashift = alpha << 24;
		{
			int tc1 = 0, tc2 = 0, to1, to2;
			boolean hasColor = (tc1 & 0xff000000) == 0;
			tc1 = p[1];
			tc2 = p[2];
			to1 = p[3];
			to2 = p[4];
			int tc = tc1, to = to1; //Only going to use remapped.
			int atc = (((tc>>0)&0xff)+((tc>>8)&0xff)+((tc>>16)&0xff))/3;
			int aoc = (((to>>0)&0xff)+((to>>8)&0xff)+((to>>16)&0xff))/3;
			int range = aoc-atc;
			for (int i = 0; i<len; i++){
				int d = dest[i];
				int d2 = d & 0xffffff;
				int fo = d2 | ashift, ft = d2;
				if (d2 == tc1 || d2 == tc2) dest[i] = ft;
				else if (d2 == to1 || d2 == to2) dest[i] = fo;
				else{
					int adc = (((d2>>0)&0xff)+((d2>>8)&0xff)+((d2>>16)&0xff))/3;
					if (range < 0){//Transparent > Opaque
						if (adc >= atc) dest[i] = ft;
						else if (adc <= aoc) dest[i] = fo;
						else {
							int al = (alpha*(adc-atc))/range;
							if (al > 255) al = 255;
							dest[i] = to2 | (al << 24);
						}
						
					}else{//Transparent < Opaque
						if (adc <= atc) dest[i] = ft;
						else if (adc >= aoc) dest[i] = fo;
						else {
							int al = (alpha*(adc-atc))/range;
							if (al > 255) al = 255;
							dest[i] = to2 | (al << 24);
						}
					}
				}
			}
		}
	break;
	}
	
	case SCALE_ALPHA:{
		int[] dest = this.buffer;
		int[] p = (int [])par1;
		int len = dest.length;
		int alpha = p[0];
		for (int i = 0; i<len; i++){
			int d = dest[i];
			int a = (((d >> 24) & 0xff)*alpha) >> 8;
			if (a > 0xff) a = 0xff;
			dest[i] = (d & 0xffffff) | (a << 24);
		}
	break;
	}
	case SCALE:{
		int [] dest = (int[])par1;
		int [] src = this.buffer;
		Object [] pars = (Object [])par2;
		Rect srcRect = (Rect)pars[0];
		Rect dstRect = (Rect)pars[1];
		int h = dstRect.height, w = dstRect.width;
		int sx = srcRect.x, sy = srcRect.y;
		int sh = srcRect.height, sw = srcRect.width;
		double xsc = (double)sw/(double)w;
		double ysc = (double)sh/(double)h;
		double y = 0;
		int off = 0;
		for (int line = 0; line < h; line++, y += ysc){
			if (y >= sh) y = sh-1;
			int srcOff = ((int)y+sy)*width;
			double x = 0;
			for (int col = 0; col < w; col++, x += xsc){
				if (x >= sw) x = sw-1;
				dest[off++] = src[srcOff+((int)x+sx)];
			}
		}
	break;
	}
	
	}
	return 0;
}

//-------------------------------------------------------------------
private native int nativePixbufOperation(Object par1,Object par2,int operation,int width,int height,int[] buffer);
//-------------------------------------------------------------------
/**
* This will attempt to get pixels for an IImage. If the IImage cannot provide the pixels directly,
* then a PixelBuffer will be created and the IImage drawn on it. Then the pixels from the pixel
* buffer will be returned.
**/
//===================================================================
public static int [] getPixelsFor(IImage image,int [] dest,int offset,Rect area,int options,Color substituteBackground)
//===================================================================
{
	PixelBuffer pb = new PixelBuffer(area.width,area.height);
	Graphics g = pb.getDrawingBuffer(null,substituteBackground,1);
	image.draw(g,-area.x,-area.y,0);
	pb.putDrawingBuffer(PUT_SET);
	int []ret = pb.getPixels(dest,offset,0,0,area.width,area.height,0);
	pb.free();
	return ret;
}
/**
* This gets a section of an Image, starting at a particular point and in a shape represented by Mask.
* @param image The original image.
* @param m The mask representing the bits of the Image that should be taken. This Mask can be
smaller than the full image - the p parameter specifies where in the image the section should
be taken from.
* @param p The point in the Image where the section should be taken from.
* @param alphaValue An alpha value to be applied to all pixels taken from the Image.
* @return A new PixelBuffer that contains the pixels taken from the Image. All pixels which
* were excluded from the Mask will be fuly transparent.
*/
//===================================================================
public static PixelBuffer getImageSection(IImage image,Mask m,Point p,double alphaValue)
//===================================================================
{
	PixelBuffer pb = new PixelBuffer(m.width,m.height);
	Graphics g = pb.getDrawingBuffer(null,null,alphaValue);
	image.draw(g,-p.x,-p.y,0);
	pb.putDrawingBuffer(PUT_SET,m);
	return pb;
}
/* (non-Javadoc)
 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
 */
public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength) throws IllegalStateException {
	getScanLinesUsingPixels(startLine,numLines,destArray,offset,destScanLineLength);
	
}
/* (non-Javadoc)
 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
 */
public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength) throws IllegalStateException {
	setScanLinesUsingPixels(startLine,numLines,sourceArray,offset,sourceScanLineLength);
}
public static PixelBuffer getCached()
{
	return (PixelBuffer)Cache.get(PixelBuffer.class);
}
public void cache()
{
	Cache.put(this);
}
/*
//===================================================================
public static Image openImage(Object streamOrByteArray,Dimension requestedSize,Dimension fullSize,boolean forceScale)
//===================================================================
{
	
}
*/
/*
static int numPixbuffs;
public void finalize()
{
	numPixbuffs--;
	eve.sys.Vm.debug("--PB: "+numPixbuffs);
}
*/
//##################################################################
}
//##################################################################

