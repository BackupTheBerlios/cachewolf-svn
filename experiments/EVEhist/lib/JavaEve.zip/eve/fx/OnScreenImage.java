package eve.fx;
/**
This is an Image that is being displayed on some control surface or other. It allows
you to set the ImageRefresher for the IImage.<p>
The ImageRefresher is <b>weakly</b> referenced by the Image. This allows separate
threads to animate the image but stop when the surface the Image is being displayed on
no longer exists.
*/
//##################################################################
public interface OnScreenImage extends IImage{
//##################################################################
/**
<b>Weakly</b> set the ImageRefresher for the Image.
*/
public void setRefresher(ImageRefresher refresher);
/**
Change the ImageRefresher for the Image only if the old Refresher
is the same as the one specified. The newRefresher can be null, indicating that
the image is no longer on display.
@param newRefresher The new ImageRefresher for the image.
@param oldRefresher What the old ImageRefresher was expected to be.
@return true if the refresher was changed, false if it was not changed because the old
Refresher was not the same as that specified in the parameter.
*/
public boolean changeRefresher(ImageRefresher newRefresher, ImageRefresher oldRefresher);
/**
Retrieve the ImageRefresher for the image which is <b>weakly</b> referenced by
the OnScreenImage.
*/
public ImageRefresher getRefresher();

//##################################################################
}
//##################################################################

