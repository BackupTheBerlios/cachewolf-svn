package eve.fx;
/**
* An Area represents an arbitrarily shaped 2D area.
**/
//##################################################################
public interface Area{
//##################################################################
/**
* Check if the point is in the area.
**/
public boolean isIn(int x,int y);
/**
* See if this Area intersects another. This intersection is not necessarily an intersection
* of the bounding rectangles.
**/
public boolean intersects(Area other);
/**
 * Get the bounding rectangle of the area.
 * @param dest an optional destination Rect.
 * @return The dest Rect or a newly created Rect if dest is null.
 */
public Rect getRect(Rect dest);

//##################################################################
}
//##################################################################

