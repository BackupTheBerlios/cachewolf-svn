/*
 * Created on May 9, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.data.PropertyList;
import eve.sys.Device;
import eve.sys.Handle;
import eve.sys.IConsole;
import eve.sys.ITaskbarEntry;
import eve.sys.ImageData;
import eve.sys.Type;
import eve.util.FormattedDataSource;

/**
 * This class provides static utilities for imaging and drawing.
 * @author Michael L Brereton
 */
//####################################################
public class Fx {
private Fx(){}
private static PixelBuffer pixbuf;
private static boolean hasNative = true;
/**
 * Convert an IImage or portion thereof into an Image optimized for display.
 * @param iimage the source IImage.
 * @param subArea an optional sub-area in the image.
 * @return an Image
 * @throws IllegalArgumentException if the sub-area is not null but not fully within the source image.
 */
public synchronized static Image toImage(IImage iimage,Rect subArea) throws IllegalArgumentException
{
	if (pixbuf == null) pixbuf = new PixelBuffer();
	if (subArea == null) pixbuf.setTo(iimage);
	else pixbuf.setTo(iimage,subArea);
	return pixbuf.toImage();
}

private static native int nativeGetAlphaLevel(int [] values, int offset, int width, int height, int rowStride);

public static boolean isScalable(Font f)
{
	FontMetrics fm = getFontMetrics(f.changeNameAndSize(null, 50));
	FontMetrics fm2 = getFontMetrics(f.changeNameAndSize(null, 100));
	if (fm.getHeight() >= fm2.getHeight()) return false;
	return true;
}
/**
 * For this to return true it must be monospaced AND scalable.
 * @param f the font to test.
 * @return true if it is monospaced AND scalable.
 */
public static boolean isMonospaced(Font f)
{
	if (f == null) return false;
	FontMetrics fm = getFontMetrics(f);
	if (fm.getCharWidth('X') != fm.getCharWidth('.')) return false;
	return isScalable(f);
}
/**
 * Get the name of a valid installed Courier Font that is monospaced.
 * @return the name a valid installed Courier Font that is monospaced or null
 * if none were found.
 */
public static String getMonospacedCourierFont()
{
	String[] all = Font.listFonts(Fx.getDefaultSurface());
	if (all == null) return null;
	for (int i = 0; i<all.length; i++){
		if (all[i].toLowerCase().startsWith("courier")){
			Font f = new Font(all[i],Font.PLAIN,12);
			if (Fx.isMonospaced(f)) return all[i];
		}
	}
	Font f = toMonospacedFont(null, 14);
	if (f != null) return f.getName();
	return null;
}
/**
 * Get the name of a valid installed Arial or Helvetica font.
 */
public static String getArialHelvetica()
{
	String[] all = Font.listFonts(Fx.getDefaultSurface());
	if (all == null) return null;
	for (int p = 1; p <= 2; p++){
		for (int i = 0; i<all.length; i++){
			String c = all[i].toLowerCase();
			boolean matches = c.equals("arial") || c.equals("helvetica");
			if (!matches && p == 2){
				matches = c.startsWith("arial") || c.startsWith("helvetica");
			}
			if (matches) matches = isScalable(new Font(all[i],Font.PLAIN,12)); 
			if (matches) return all[i];
		}
	}
	return "sans";
}
/**
 * Get the name of a valid installed Times font.
 */
public static String getTimesRoman()
{
	String[] all = Font.listFonts(Fx.getDefaultSurface());
	if (all == null) return null;
	for (int p = 1; p <= 2; p++){
		for (int i = 0; i<all.length; i++){
			String c = all[i].toLowerCase();
			boolean matches = c.equals("times new roman") || c.equals("times-roman");
			if (!matches && p == 2){
				matches = c.startsWith("times");
			}
			if (matches) matches = isScalable(new Font(all[i],Font.PLAIN,12)); 
			if (matches) return all[i];
		}
	}
	return "serif";
}

/**
 * Find a monospaced Font.
 * @param possiblyMonospacedFont a Font that may be monospaced or null.
 * @param size if possiblyMonospacedFont is null this should be a size
 * for the returned font. Otherwise the size for possiblyMonospacedFont is used.
 * @return a Font that is monospaced or null if none could be found.
 */
public static Font toMonospacedFont(Font possiblyMonospacedFont,int size)
{
	if (possiblyMonospacedFont != null){
		if (isMonospaced(possiblyMonospacedFont)) return possiblyMonospacedFont;
	}
	if (possiblyMonospacedFont != null) size = possiblyMonospacedFont.getSize();
	Font f;
	f = Font.getSystemFont(Font.SYSTEM_FONT_MONOSPACED); if (isMonospaced(f)) return f;
	f = new Font("Courier",Font.PLAIN,size); if (isMonospaced(f)) return f;
	f = new Font("Courier New",Font.PLAIN,size); if (isMonospaced(f)) return f;
	f = new Font("monospaced",Font.PLAIN,size); if (isMonospaced(f)) return f;
	f = new Font("monospace",Font.PLAIN,size); if (isMonospaced(f)) return f;
	f = new Font("mono",Font.PLAIN,size); if (isMonospaced(f)) return f;
	f = new Font("fixed",Font.PLAIN,size); if (isMonospaced(f)) return f;
	f = new Font("terminal",Font.PLAIN,size); if (isMonospaced(f)) return f;
	return null;
}
/**
 * Checks alpha levels of the pixels.
 * @param values the pixel values.
 * @param offset the start of the first pixel value.
 * @param width the number of values per lines to check.
 * @param height the number of lines to check.
 * @param rowStride the number of values in a line.
 * @return 0 - indicates all pixels are fully opaque (alpha = 255 for all)<br> 
 * 1 - indicates pixels are either fully opaque or fully transparent (alpha = 255 or 0 for all)<br>
 * 2 - indicates pixels exist with mixed alpha values (alpha values exist which are not 255 or 0).
 */
static int getAlphaLevel(int [] values, int offset, int width, int height, int rowStride)
{
	if (rowStride <= 0) rowStride = width;
	if (values == null) throw new NullPointerException();
	if (height <= 0 || width <= 0) throw new IllegalArgumentException();
	if (offset < 0 || width+((height-1)*rowStride)+offset > values.length)
		throw new ArrayIndexOutOfBoundsException();
	if (hasNative) try{
		return nativeGetAlphaLevel(values,offset,width,height,rowStride);
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		hasNative = false;
	}
	int level = 0;
	for (int r = 0; r<height; r++){
		int where = offset+r*rowStride;
		for (int c = 0; c<width; c++){
			int a = values[where++] & 0xff000000;
			if (a == 0) level = 1;
			else if (a != 0xff000000) return 2;
		}
	}
	return level;
}

static IFxHandler fxHandler;

public synchronized static void setFxHandler(IFxHandler handler)
{
	fxHandler = handler;
}
public static Font getDefaultFont()
{
	Font f = fxHandler == null ?  new Font("helvetica",Font.PLAIN,12) : fxHandler.getDefaultFont();
	return f;
}

private static Image fontImage;

private static ISurface getDefaultFontSurface()
{
	if (fontImage == null) fontImage = new Image(10,10);
	return fontImage;
}
public static FontMetrics getDefaultFontMetrics()
{
	return getDefaultFontSurface().getFontMetrics(getDefaultFont());
}
/**
 * Get a FontMetrics for a particular font, using the default surface.
 * @param f the Font.
 * @return a FontMetrics for the font on the specified surface.
 */
public static FontMetrics getFontMetrics(Font f)
{
	if (f == null) throw new NullPointerException();
	return getDefaultFontSurface().getFontMetrics(f);
}
private static ISurface defaultSurface;
public static synchronized ISurface getDefaultSurface()
{
	if (defaultSurface != null) return defaultSurface;
	if (fxHandler != null) defaultSurface = fxHandler.getDefaultSurface();
	if (defaultSurface != null) return defaultSurface;
	Type t = new Type("eve.fx.gui.WindowSurface");
	if (t.exists()) try{
		defaultSurface = (ISurface)t.invoke(null,"getMainSurface()Leve/fx/gui/WindowSurface;",null);
	}catch(Throwable th){
		//th.printStackTrace();
	}
	if (defaultSurface != null) return defaultSurface;
	defaultSurface = new Image(4,4);
	return defaultSurface;
}
public static synchronized String getDefaultWindowTitle()
{
	if (fxHandler != null) return fxHandler.getDefaultWindowTitle();
	return null;
}
public synchronized static ISurface createDefaultWindow()
{
	Type t = new Type("eve.fx.gui.WindowSurface");
	if (t.exists()) try{
		return (ISurface)t.invoke(null,"createDefaultWindow()Leve/fx/gui/WindowSurface;",null);
	}catch(Throwable th){
	}
	return null;
}
/**
 * Load a Picture given a String name or a FormattedDataSource. If it is a String
 * then it is loaded via the ImageCache.
 * @param source the source of the picture, which should be a name or a FormattedDataSource.
 * @return an IImage (usually a Picture) representing the Image. 
 */
public static IImage loadPicture(Object source)
{
	if (source instanceof String){
		IImage got = ImageCache.cache.getImage((String)source);
		if (got instanceof Picture) return (Picture)got;
		else return new Picture(got,0);
	}else if (source instanceof FormattedDataSource){
		return new Picture((FormattedDataSource)source,0);
	}else
		return null;
}
/**
 * Put an image into the ImageCache.
 * @param imageName
 * @param image
 */
public static void postPicture(String imageName, IImage image)
{
	ImageCache.cache.put(imageName,image);
}

static Type winsurface;

public static ITaskbarEntry getTaskbarEntry()
{
	ISurface is = getDefaultSurface();
	if (is == null) return null;
	if (winsurface == null) winsurface = new Type("eve.fx.gui.WindowSurface");
	return (ITaskbarEntry)winsurface.invoke(is,"createTaskbarEntry()Leve/sys/ITaskbarEntry;",null);
}
/*
static Integer miny = new Integer(10), maxy = new Integer(100);
static Object[] mm = new Object[2];

public static void yieldToGUI(int min, int max)
{
	if (true) return;
	if (winsurface == null) winsurface = new Type("eve.fx.gui.WindowSurface");
	if (winsurface.exists()){
		if (miny.intValue() != min) miny = new Integer(min);
		if (maxy.intValue() != max) maxy = new Integer(max);
		mm[0] = miny; mm[1] = maxy;
		winsurface.invoke(null,"handleWindowEvents(II)V",mm);
	}
}
*/
/**
 * Yield to user interface events if possible. This method will call the 
 * yieldToEvents() method in the IFxHandler if any is present. If not it
 * returns false.
 * @param maxTime the maximum time to yield for.
 * @return true if it does know how to yield to events, false
 * if it cannot which means this call has no effect.
 */
public static boolean yieldToEvents(int max)
{
	IFxHandler fx = fxHandler;
	if (fx == null) return false;
	return fx.yieldToEvents(max);
}
public static IConsole getConsole(String title, int buttonsAndOptions, int maxLines)
{
	IFxHandler fx = fxHandler;
	if (fx == null) return null;
	return fx.getConsole(title,buttonsAndOptions,maxLines);
}
public static ImageData scaleImage(ImageData src, int newWidth, int newHeight)
{
	
	PixelBuffer pb = new PixelBuffer(src,new Rect(0,0,src.getImageWidth(),src.getImageHeight()),new Dimension(newWidth,newHeight),null);
	ImageData ret = pb.toPicture();
	pb.free();
	return ret;
}
public static Handle printerDialog(PropertyList printerProperties)
{
	IFxHandler fx = fxHandler;
	if (fx == null) return new Handle(Handle.Failed,null);
	return fx.printerDialog(printerProperties);
}
}
//####################################################
