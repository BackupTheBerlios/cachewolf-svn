/*
 * Created on Jan 12, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface Drawable {
	/**
	* This is an option that tells the image that it should draw itself in a disabled (usually "grayed") state.
	**/
	public static final int DISABLED = 0x8000000;
	/**
	* This is an option that tells the image that it should draw an outline around itself.
	**/
	public static final int OUTLINED = 0x4000000;
	/**
	* This is an option that tells the image that it is drawing itself
	* in an "active" state. This can be used to prompt the Drawable to start animating.
	**/
	public static final int ACTIVE = 0x2000000;
	/**
	* This is an option that tells the image that it is drawing itself
	* in an "inactive" state. This can be used to prompt the Drawable to stop animating
	* if it started animating when drawn Active.
	**/
	public static final int INACTIVE = 0x1000000;
	/**
	* This is an option that tells the image the item should be indented by a number
	* of columns specified as the lower 16 bits of the option value.
	**/
	public static final int INDENT_ITEM_FLAG = 0x80000;

	public int getWidth();
	public int getHeight();
	public void free();
	public void draw(Graphics g, int x, int y, int options);
	/**
	 * 
	 * @param g
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 * @param options
	 */
	public void draw(Graphics g, int x, int y, int width, int height, int options);
	
}
//####################################################
