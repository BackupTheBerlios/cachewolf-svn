package eve.fx;

public class QuadrantPoints {

	public int numPoints;
	public int width;
	public int height;
	public int xyPoints[];
	
}
