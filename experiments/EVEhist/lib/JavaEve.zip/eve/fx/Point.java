package eve.fx;

import eve.sys.Cache;
import eve.util.Encodable;

//MLB July-2000
//##################################################################
public class Point implements Encodable{
//##################################################################
//Dont move these variables.
public int x,y;
//{new Exception().printStackTrace();}
//--------------------------
public Point() {this(0,0);}
public Point(int xx,int yy) {x = xx; y = yy;}
public void move(int toX,int toY) {x = toX; y = toY;}
public void translate(int dx,int dy) {x += dx; y += dy;}
public String toString() {return "("+x+","+y+")";}
//===================================================================
public Point set(int x,int y) {this.x = x; this.y = y; return this;}
public Point set(Point r) {return set(r.x,r.y);}
public Point set(Rect r) {return set(r.x,r.y);}
public static Point unNull(Point r) {return r == null ? new Point():r;}
//===================================================================
public boolean equals(Object other)
//===================================================================
{
	if (!(other instanceof Point)) return false;
	Point p = (Point)other;
	return p.x == x && p.y == y;
}
//===================================================================
public static Point getCached(int x, int  y)
{
	return ((Point)Cache.get(Point.class)).set(x,y);
}
/**
 * Put the Point back in the cache.
 * @return null always.
 */
public Point cache()
{
	Cache.put(this);
	return null;
}
//##################################################################
}
//##################################################################

