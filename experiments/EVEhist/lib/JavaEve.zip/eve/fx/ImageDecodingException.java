package eve.fx;

import eve.sys.Vm;
import eve.util.FormattedDataSource;

/**
 * This exception is thrown if there is a problem decoding an image.
 * @author Michael L Brereton
 **/
//##################################################################
public class ImageDecodingException extends IllegalArgumentException{
//##################################################################

//===================================================================
public ImageDecodingException(String name)
//===================================================================
{
	super("There was an error decoding the image"+(name == null ? "" : (": "+name)) +".");
}

public ImageDecodingException(String name, Throwable cause)
{
	this(name);
	Vm.setCause(this,cause);
}
public ImageDecodingException(FormattedDataSource source, Throwable cause)
{
	this(source.name);
	if (cause != null) Vm.setCause(this,cause);
}

//##################################################################
}
//##################################################################

