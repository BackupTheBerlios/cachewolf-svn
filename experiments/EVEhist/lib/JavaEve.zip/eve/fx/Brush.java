package eve.fx;

import eve.sys.Cache;

/**
* A Brush is used with certain draw operations in eve.fx.Graphics. See the
* Graphics.setBrush(Brush b) method.
**/
//##################################################################
public class Brush{
//##################################################################
/**
* The color for the Brush.
**/
public Color color = new Color(0,0,0);
/**
* The style for the Brush.
**/
public int style;
/**
 * The fill rule.
 */
public int rule = defaultRule;

public static final int RULE_NONZERO_WINDING = 0;
public static final int RULE_EVEN_ODD = 1;

public static int defaultRule = RULE_NONZERO_WINDING;

public Brush()
{
	this(Color.Black,SOLID);
}
/**
 * Create a new Brush Object.
 * @param color The color for the Brush.
 * @param style The style for the Brush. Currently only SOLID is supported.
 */
//===================================================================
public Brush(Color color,int style)
//===================================================================
{
	this.color.set(color); 
	this.style = style;
	if (style == 0) style = SOLID;
}
/**
 * Create a new Brush Object.
 * @param color The color for the Brush.
 * @param style The style for the Brush. Currently only SOLID is supported.
 * @param rule one of the RULE_XXX values.
 */
public Brush(Color color, int style, int rule)
{
	this(color,style);
	this.rule = rule;
}
/**
 * @deprecated - use getCopy().set(Color) to do this.
 * Return a new Brush with a different color.
 * @param differentColor 
 * @return
 */
//===================================================================
public Brush change(Color differentColor)
//===================================================================
{
	return new Brush(differentColor,style);	
}
/**
 * Change the color of this Brush and return itself.
 * @param color the new Color for this brush.
 * @return this Brush.
 */
public Brush set(Color color)
{
	this.color.set(color);
	return this;
}
/**
 * Change the color and style of this Brush and return itself.
 * @param color the new Color for this brush.
 * @param style the new style for this brush.
 * @return this Brush.
 */
public Brush set(Color color, int style)
{
	this.color.set(color);
	this.style = style;
	return this;
	
}
/**
* A Brush style.
**/
public static final int SOLID = 1;
public static final int NULL = -1;

public void set(Brush other)
{
	if (other == null) style = NULL;
	else {
		color.set(other.color);
		style = other.style;
	}
}
public Brush getCopy()
{
	Brush b = new Brush();
	b.set(this);
	return b;
}
public static Brush getCached(int r, int g, int b,int style)
{
	Brush c = (Brush)Cache.get(Brush.class);
	c.color.set(r,g,b);
	c.style = style;
	return c;
}
public static Brush getCached(Color col, int style)
{
	Brush c = (Brush)Cache.get(Brush.class);
	c.color.set(col);
	c.style = style;
	return c;
}
public static Brush getCached(Brush other)
{
	Brush c = (Brush)Cache.get(Brush.class);
	c.set(other);
	return c;
	
}
public static Brush getCached()
{
	return (Brush)Cache.get(Brush.class);
}

public void cache()
{
	Cache.put(this);
}

//##################################################################
}
//##################################################################

