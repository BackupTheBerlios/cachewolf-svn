/*
 * Created on Jan 5, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.Device;

/**
 * This class is used to present an ImageData interface for a portion of a Graphics.
 * This is useful for drawing/scaling directly to a display without having to pass
 * through an Image buffer.
 * 
 * @author Michael L Brereton
 */
//####################################################
public class GraphicsImageData extends ImageObject{

int x, y;
Graphics g;

boolean useAlpha;

private static boolean haveNative = true;  
/**
 * Create a new, unassigned GraphicsImageData. Use setFor() to assign to a
 * Graphics. 
 */
public GraphicsImageData ()
{
	
}
/**
 * Return the Graphics this object is assigned to.
 */
public Graphics getGraphics()
{
	return g;
}

private native void nativeSetFor(Graphics g,int x, int y, int width, int height, boolean useAlpha);
private native void getSetImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength,boolean isGet) throws IllegalStateException ;
private native void getSetPixels(int[] data, int offset, int x, int y, int width, int height, int rowStride,boolean isGet);

private GraphicsImageData reset()
{
	if (haveNative) try{
		nativeSetFor(g,x,y,width,height,useAlpha);
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		haveNative = false;
	}
	return this;
}
/**
 * Set the GraphicsImageData to refer to a specific part of the Graphics.
 * @param g the Graphics.
 * @param x the x co-ordinate of the start of the display.
 * @param y the y co-ordinate of the start of the display.
 * @param width the width to be covered.
 * @param height the height to be covered.
 * @return this GraphicsImageData.
 */
public GraphicsImageData setFor(Graphics g, int x, int y, int width, int height, boolean useAlpha)
{
	this.g = g;
	this.x = x;
	this.y = y;
	this.width = width;
	this.height = height;
	this.useAlpha = useAlpha;
	return reset();
}
/**
 * Set the GraphicsImageData to refer to a specific part of the Graphics.
 * @param g the Graphics.
 * @param area the area to be covered.
 * @return this GraphicsImageData.
 */
public GraphicsImageData setFor(Graphics g, Rect area, boolean useAlpha)
{
	this.g = g;
	this.x = area.x;
	this.y = area.y;
	this.width = area.width;
	this.height = area.height;
	this.useAlpha = useAlpha;
	return reset();
}
/* (non-Javadoc)
 * @see eve.fx.IImage#draw(eve.fx.Graphics, int, int, int)
 */
public void draw(Graphics g, int x, int y, int options) {
	// TODO Auto-generated method stub
	
}

/* (non-Javadoc)
 * @see eve.fx.IImage#free()
 */
public void free() {
	g = null;
	super.free();
}

/* (non-Javadoc)
 * @see eve.fx.IImage#usesAlpha()
 */
public boolean usesAlpha() {
	// TODO Auto-generated method stub
	return useAlpha;
}

/* (non-Javadoc)
 * @see eve.sys.ImageData#isWriteableImage()
 */
public boolean isWriteableImage() {
	return true;
}
/* (non-Javadoc)
 * @see eve.sys.ImageData#setImageScanLines(int, int, java.lang.Object, int, int)
 */
public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength) throws IllegalStateException 
{
	if (g == null) return;
	ImageTool.validateScanLine(this,sourceArray,offset,startLine,numLines,sourceScanLineLength); 
	if (haveNative) try{
		getSetImageScanLines(startLine,numLines,sourceArray,offset,sourceScanLineLength,false);
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		haveNative = false;
	}
	setScanLinesUsingPixels(startLine,numLines,sourceArray,offset,sourceScanLineLength);
}
/* (non-Javadoc)
 * @see eve.sys.ImageData#getImageScanLines(int, int, java.lang.Object, int, int)
 */
public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength) throws IllegalStateException 
{
	if (g == null) return;
	ImageTool.validateScanLine(this,destArray,offset,startLine,numLines,destScanLineLength); 
	if (haveNative) try{
		getSetImageScanLines(startLine,numLines,destArray,offset,destScanLineLength,true);
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		haveNative = false;
	}
	getScanLinesUsingPixels(startLine,numLines,destArray,offset,destScanLineLength);	
}

public int[] getPixels(int[] dest, int offset, int x, int y, int width,int height, int rowStride)
{
	if (g == null) return null;
	if (rowStride < width) rowStride = width;
	dest = ImageTool.validatePixelBuffer(true,this,dest,offset,width,height,rowStride);
	if (dest == null) return null;
	if (haveNative) try{
		getSetPixels(dest,offset,x,y,width,height,rowStride,true);
		return dest;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		haveNative = false;
	}
	g.getRGB(dest,offset,x+this.x,y+this.y,width,height,rowStride);
	return dest;
}
public boolean setPixels(int[] src,int offset,int x,int y,int width,int height,int rowStride)
{
	if (g == null) return false;
	if (rowStride < width) rowStride = width;
	src = ImageTool.validatePixelBuffer(false,this,src,offset,width,height,rowStride);
	if (src == null) return false;
	if (haveNative) try{
		getSetPixels(src,offset,x,y,width,height,rowStride,false);
		return true;
	}catch(Throwable t){
		Device.checkNoNativeMethod(t);
		haveNative = false;
	}
	/*
	if (true){
		System.out.println("Y = "+(y));
		for (int i = 0; i<width; i++){
			System.out.print(Integer.toHexString(src[offset+i])+", ");
			src[offset+i] = 0xff9c9c9c;
		}
		System.out.println();
	}
	*/
	g.drawRGB(src,offset,x+this.x,y+this.y,width,height,rowStride,useAlpha);
	return true;
}
//private native int getImageDataInfo(int which,int[] colorTable);



}
//####################################################
