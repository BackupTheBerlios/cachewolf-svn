package eve.fx.print;

import eve.data.PropertyList;

public class PrinterProperties extends PropertyList{

	/**
	 * This property is a String which is the name of the printer 
	 * that was chosen. It is normally set to
	 * the default printer initially and then defaults to the 
	 * previously selected printer thereafter.
	 */
	public static final String CHOSEN_PRINTER = "chosenPrinter";
	/**
	 * This property is a String which is the name of the printer 
	 * that was chosen. It is normally set to
	 * the default printer initially and then defaults to the 
	 * previously selected printer thereafter.
	 */
	public static final String DEFAULT_PRINTER = "defaultPrinter";
	/**
	 * This property is a comma separated list of printers, each in the form
	 * <Printer Name>=<Descriptive Name> or just <Printer Name>.
	 */
	public static final String AVAILABLE_PRINTERS = "availablePrinters";
	/**
	 * This is a possible value for the AVAILABLE_PRINTERS property and
	 * indicates that the printer dialog should not display or allow
	 * the use to change the available printer.
	 */
	public static final String VALUE_AVAILABLE_PRINTERS_DONT_SHOW_LIST = "!Dont Show!";
	
	/**
	 * This property is a PrinterControl object.
	 */
	public static final String PRINTER_CONTROL = "printerControl";
	
	public static final String PRINT_DIALOG_TITLE = "printDialogTitle";
	
	public String getChosen() {return getString(CHOSEN_PRINTER,null);}
	public String getDefault() {return getString(DEFAULT_PRINTER,null);}
	public PrinterControl getPrinterControl()
	{
		return (PrinterControl)getValue(PRINTER_CONTROL, null);
	}
	public void setPrinterControl(PrinterControl pc)
	{
		if (pc == null) remove(PRINTER_CONTROL);
		else set(PRINTER_CONTROL,pc);
	}
}
