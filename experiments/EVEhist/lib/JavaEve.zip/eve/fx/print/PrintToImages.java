package eve.fx.print;
import eve.fx.Color;
import eve.fx.Graphics;
import eve.fx.Image;
import eve.fx.ImageTool;
import eve.fx.RotatedImageData;
import eve.fx.points.PageFormat;
import eve.fx.points.PointGraphics;
import eve.sys.Handle;
import eve.sys.ImageData;
/**
A PrintPreview is very similar to a PrinterJob except that the output
for each page will be an Image of a resolution that you preset.<p>
**/
//##################################################################
public abstract class PrintToImages extends PrinterJobObject{
//##################################################################
	public PageFormat pageSize;
	
	protected PrintToImages()
	{
		this(null);
	}
	protected PrintToImages(PageFormat standardPage)
	{
		if (standardPage == null) standardPage = new PageFormat();
		pageSize = (PageFormat)standardPage.getCopy();
	}

protected double xDPI = 72, yDPI = 72;

protected double drawXDPI = 300;
protected double drawYDPI = 300;
public ImageTool finalImageCreator;
public ImageTool pageRectImageCreator;
/**
 * The options used when images are being created for the
 * PrintPreview. If finalImageCreator or pageRectImageCreator are not null,
 * then those image creators will be determine the image type created.
 * <p>
 * By default this field is Image.TYPE_RGB  
 */
public int createImageOptions = Image.TYPE_RGB;
/**
If this is set true, then rough scaling is done when producing the
final images for output. Rough scaling is faster than smooth scaling.
**/
public boolean scaleRough;

//===================================================================
public void setDrawDPI(double xDPI, double yDPI)
//===================================================================
{
	this.drawXDPI = xDPI;
	this.drawYDPI = yDPI;
}
//===================================================================
public void setDrawDPI(double dpi)
//===================================================================
{
	this.drawXDPI = dpi;
	this.drawYDPI = dpi;
}

//===================================================================
public void setImageDPI(double xDPI, double yDPI)
//===================================================================
{
	this.xDPI = xDPI;
	this.yDPI = yDPI;
}
//===================================================================
public void setImageDPI(double imageDPI)
//===================================================================
{
	setImageDPI(imageDPI, imageDPI);
}
/**
By default this will return the xDPI value of the PageFormat supplied to the
PrintSurfaceObject.
**/
//===================================================================
public double getOutputXDPI()
//===================================================================
{
	return xDPI;
}
/**
By default this will return the yDPI value of the PageFormat supplied to the
PrintSurfaceObject.
**/
//===================================================================
public double getOutputYDPI()
//===================================================================
{
	return yDPI;
}
/*
//===================================================================
public Control getDisplayFor(Image im)
//===================================================================
{
	ImageControl ic = new ImageControl(im);
	ic.options = 0;
	ScrollBarPanel sp = new ScrollBarPanel(ic);
	ic.setPreferredSize(im.getWidth(),im.getHeight());
	return sp;
}
*/

//-------------------------------------------------------------------
/*
protected abstract void startPrinting(PageCounter pc, PageFormat format);
protected abstract void endPage(int pageIndex);
protected abstract void endPrinting(int pagesPrinted);
protected abstract void abortPrinting();
*/
//-------------------------------------------------------------------
protected Printable printing;
/*
//-------------------------------------------------------------------
protected Task getPrintTask(final Printable toPrint,final PageFormat format,final PrintOptions po)
//-------------------------------------------------------------------
{
	printing = toPrint;
	return new Task(){
		protected void doRun(){
			try{
				Handle handle = this;
				format.acceptRequests();
				Vector v = new Vector();
				handle.returnValue = v;
				try{
					PageCounter pc = new PageCounter(handle,toPrint,format,po);
					startPrinting(pc,format);
					int didPages = 0;
					PageFormat pf;
					while((pf = pc.moveToNextPage()) != null){
						if (!toPrint.print(handle,ps,pf,pc.currentPageIndex)) {
							handle.shouldStop = true;
							break;
						}
						endPage(pc.currentPageIndex,ps);
						didPages++;
					}
					toPrint.printingComplete();
					if (handle.shouldStop){
						abortPrinting();
					}else{
						endPrinting(didPages);
					}
				}catch(Throwable e){
					handle.fail(e);
					abortPrinting();
					return;
				}
				if (handle.error != null) handle.set(handle.Failed);
				else if (handle.shouldStop) handle.set(handle.Aborted);
				else handle.set(handle.Succeeded);
			}finally{
				printingComplete();
			}
		}
	};
}
*/
/**
This is called by default by putPageRect() if the image in the PageRect must
be scaled down to the final image for display. This gives you an opportunity to
override the way that this scaling is done - to perhaps improve on the normal method.
<p>
The dest image is the exact size that the source image should be scaled down into and
will be of the same type as the final image for the current page. The source image
will be from the current PageRect. Do not free() either the source or dest images when
you are done.
* @param source The source image to scale down.
* @param dest The destination image to scale into.
* @return true if the scaling was successful, false if it was not - in which case the
* default scaling method will be used.
*/
/*
//-------------------------------------------------------------------
protected boolean scaleDownToFinal(Image source, Image dest)
//-------------------------------------------------------------------
{
	try{
		ImageTool.scale(source,dest,scaleRough? ImageTool.SCALE_ROUGH : 0);
		return true;
	}catch(Throwable t){
		t.printStackTrace();
	}
	return false;
}
*/
/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#newPage(eve.sys.Handle, eve.fx.points.PageFormat)
 */
private PageFormat lastFormat;

protected PointGraphics newPage(Handle h, PageFormat format) {
	lastFormat = format;
	double xdpi = drawXDPI;
	double ydpi = drawYDPI;
	int width = (int)(pageSize.fullPageWidth*xdpi/72);
	int height = (int)(pageSize.fullPageHeight*ydpi/72);
	try{
	curImage = ImageTool.createImageUsing(finalImageCreator,width,height,createImageOptions);
	curGraphics = new Graphics(curImage);
	curGraphics.setColor(Color.White);
	curGraphics.fillRect(0,0,width,height);
	format.fullPageHeight = pageSize.fullPageHeight;
	format.fullPageWidth = pageSize.fullPageWidth;
	format.imageableX = pageSize.imageableX;
	format.imageableY = pageSize.imageableY;
	return new PointGraphics(curGraphics,width,height,xdpi,ydpi);
	}catch(OutOfMemoryError e){
		System.out.println(width+"x"+height);
		System.out.println(xdpi+"x"+ydpi);
		throw e;
	}
}

/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#printCompletedPage(eve.sys.Handle)
 */
protected boolean printCurrentPage(Handle h) {
	curGraphics.free();
	double xdpi = getOutputXDPI();
	double ydpi = getOutputYDPI();
	int width = (int)(pageSize.fullPageWidth*xdpi/72);
	int height = (int)(pageSize.fullPageHeight*ydpi/72);
	ImageData toScale = curImage;
	int tr = lastFormat.getTransformation();
	if (tr != lastFormat.TRANSFORM_NONE){
		if (tr == lastFormat.TRANSFORM_ROTATE_180)
			toScale = new RotatedImageData(curImage,RotatedImageData.ROTATE_180);
		else{
			int t = width; width = height; height = t;
			toScale = new RotatedImageData(curImage,tr == lastFormat.TRANSFORM_ROTATE_270 ? RotatedImageData.ROTATE_270 : RotatedImageData.ROTATE_90);
		}
	}
	if (toScale != curImage || width != curImage.getImageWidth() || height != curImage.getImageHeight()){
		Image im = ImageTool.createImageUsing(finalImageCreator,width,height,createImageOptions);
		ImageTool.scale(toScale,im);
		curImage.free();
		curImage = im;
	}
	return printFinalImage(h,curImage);
}
/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#cancelCurrentPage(eve.sys.Handle)
 */
protected void cancelCurrentPage(Handle h) {
	// TODO Auto-generated method stub
	curGraphics.free();
}

Image curImage;
Graphics curGraphics;

protected abstract boolean printFinalImage(Handle h, ImageData im);
//##################################################################
}
//##################################################################

