package eve.fx.print;

import eve.data.DataObject;
import eve.util.Encodable;

public class PrinterControl extends DataObject implements Encodable{
	
	private static int indexOf(int value, int[] values)
	{
		for (int i = 0; i<values.length; i++){
			if (values[i] == value) return i;
		}
		return 0;
	}
	
	private static String getPrinterControlValue(int printerControlValue,int [] values,String [] names,String defalt)
	{
		int v = indexOf(printerControlValue, values);
		if (v == -1)  return defalt;
		return names[v];
	}
	public static String getPrinterQuality(int value)
	{
		return getPrinterControlValue(value,qualityValues,qualityNames,"Unknown");
	}
	public static String getColorMode(int value)
	{
		return getPrinterControlValue(value,colorValues,colorNames,"Unknown");
	}
	public static String getDuplexMode(int value)
	{
		return getPrinterControlValue(value,duplexValues,duplexNames,"Unknown");
	}
	public static String getPaperSize(int value)
	{
		return getPrinterControlValue(value,paperValues,paperNames,"Unknown");
	}
	public static int [] qualityValues = {
		PrinterControl.QUALITY_DRAFT, 
		PrinterControl.QUALITY_LOW, 
		PrinterControl.QUALITY_MEDIUM, 
		PrinterControl.QUALITY_HIGH, 
		PrinterControl.QUALITY_BEST, 
	};
	public static String [] qualityNames = {
		"Draft",
		"Low",
		"Medium",
		"High",
		"Best"
	};
	
	public static int [] paperValues = {
		PrinterControl.PAPER_LETTER, 
		PrinterControl.PAPER_LEGAL, 
		PrinterControl.PAPER_A4 
	};
	public static String [] paperNames = {
		"Letter - 8.5\"x11\"",
		"Legal - 8.5\"x14\"",
		"A4"
	};
	
	public static int [] duplexValues = {
		PrinterControl.DUPLEX_SIMPLEX, 
		PrinterControl.DUPLEX_VERTICAL, 
		PrinterControl.DUPLEX_HORIZONTAL 
	};
	public static String [] duplexNames = {
		"Single Sided",
		"Double Sided Vertically",
		"Double Sided Horizontally"
	};
	public static int [] colorValues = {
		PrinterControl.COLOR_STANDARD_COLOR, 
		PrinterControl.COLOR_PHOTO_COLOR, 
		PrinterControl.COLOR_MONO, 
		PrinterControl.COLOR_MONO_BLACK_INK_ONLY 
	};
	public static String [] colorNames = {
		"Color",
		"Best Color",
		"Grayscale",
		"Grayscale with only black ink",
	};

	/**
	 * This contains a single bit for each value represented in this
	 * Object. if the XXX_IS_SET bit is present, it means that field in
	 * the Object has been set and holds valid data.
	 */
	public int valuesFlags; 
	public static final int DUPLEXMODE_IS_SET = 0x1;
	public static final int PRINTQUALITY_IS_SET = 0x2;
	public static final int COLORMODE_IS_SET = 0x4;
	public static final int PAPERSIZE_IS_SET = 0x8;
	
	public static final int DUPLEX_NO_DUPLEX = 0;
	/** The same as DUPLEX_NO_DUPLEX. */
	public static final int DUPLEX_SIMPLEX = DUPLEX_NO_DUPLEX;
	public static final int DUPLEX_HORIZONTAL = 1;
	public static final int DUPLEX_VERTICAL = 2;
	/** The same as DUPLEX_VERTICAL */
	public static final int DUPLEX_LONG_EDGE = DUPLEX_VERTICAL;
	/** The same as DUPLEX_HORIZONTAL */
	public static final int DUPLEX_SHORT_EDGE = DUPLEX_HORIZONTAL;
	
	public int duplexMode = DUPLEX_NO_DUPLEX;
	
	public static final int QUALITY_DRAFT = 0;
	public static final int QUALITY_LOW = 2;
	public static final int QUALITY_MEDIUM = 4;
	public static final int QUALITY_HIGH = 6;
	public static final int QUALITY_BEST = 8;
	
	public int printQuality = QUALITY_MEDIUM;
	
	/** A colorMode value. Indicates no color ink should be used at all. **/
	public static final int COLOR_MONO_BLACK_INK_ONLY = 0;
	/** The same as COLOR_MONO_BEST, allows the use of the color ink for better grayscale. **/
	public static final int COLOR_MONO = 1;
	/** The same as COLOR_MONO, allows the use of the color ink for better grayscale. **/
	public static final int COLOR_MONO_BEST = 1;
	/**
	 * Use the regular color available on the printer.
	 */
	public static final int COLOR_STANDARD_COLOR = 2;
	/**
	 * Use the best color available on the printer.
	 */
	public static final int COLOR_PHOTO_COLOR = 3;
	
	public int colorMode = COLOR_STANDARD_COLOR;
	
	public static final int PAPER_LETTER = 0;
	public static final int PAPER_LEGAL = 1;
	public static final int PAPER_A4 = 2;
	
	public int paperSize = PAPER_LETTER;
	/**
	 * Sets the duplex mode and returns itself.
	 */
	public PrinterControl setDuplexMode(int duplexType)
	{
		duplexMode = duplexType;
		valuesFlags |= DUPLEXMODE_IS_SET;
		return this;
	}
	/**
	 * Sets the print quality and returns itself.
	 */
	public PrinterControl setPrintQuality(int qualityType)
	{
		printQuality = qualityType;
		valuesFlags |= PRINTQUALITY_IS_SET;
		return this;
	}
	/**
	 * Sets the color mode and returns itself.
	 */
	public PrinterControl setColorMode(int color)
	{
		colorMode = color;
		valuesFlags |= COLORMODE_IS_SET;
		return this;
	}
	/**
	 * Sets the paper size and returns itself.
	 */
	public PrinterControl setPaperSize(int paper)
	{
		paperSize = paper;
		valuesFlags |= PAPERSIZE_IS_SET;
		return this;
	}
	
	/**
	 * Create a PrinterControl optionally leaving all values unset.
	 * @param dontChooseDefaultValues if this is true then the valuesFlags
	 * will be set to zero, indicating that no values have been set.
	 */
	public PrinterControl(boolean dontChooseDefaultValues)
	{
		if (!dontChooseDefaultValues)
			valuesFlags = 
				PAPERSIZE_IS_SET|DUPLEXMODE_IS_SET|COLORMODE_IS_SET|PRINTQUALITY_IS_SET; 
	}
	/**
	 * Create a PrinterControl with all values not set.
	 */
	public PrinterControl()
	{
		this(true);
	}
	/**
	 * Add the PrinterControl() to a PrinterProperties. If the provided
	 * properties is null a new one is created and returned.
	 * @param properties the PrinterProperties to add this PrinterControl
	 * to. If it is null a new one is created and returned.
	 * @return the properties parameter or a new PrinterProperties if it was null.
	 */
	public PrinterProperties addToProperties(PrinterProperties properties)
	{
		if (properties == null) properties = new PrinterProperties();
		properties.setPrinterControl(this);
		return properties;
	}
	/**
	 * If there is a PrinterControl set for the PrinterProperties, then
	 * return it, otherwise create, add and return a new one.
	 * @param properties a non-null PrinterProperties object.
	 * @return the PrinterControl now assigned to the PrinterProperties.
	 */
	public static PrinterControl getOrCreatePrinterControl(PrinterProperties properties)
	{
		PrinterControl p = properties.getPrinterControl();
		if (p == null) {
			p = new PrinterControl(true);
			properties.setPrinterControl(p);
		}
		return p;
	}
	/**
	 * Override the PrinterControl value in properties with the
	 * values set in this PrinterControl. If there is none in the properties
	 * a new one is created and added.
	 * @param properties a non-null PrinterProperties.
	 */
	public void overrideInProperties(PrinterProperties properties)
	{
		PrinterControl pc = getOrCreatePrinterControl(properties);
		pc.overrideWith(this);
	}
	/**
	 * Override values in thes PrinterControl with the other PrinterControl.
	 * @param other the other PrinterControl whose set values will
	 * override those in this PrinterControl.
	 * @return this PrinterControl.
	 */
	public PrinterControl overrideWith(PrinterControl other)
	{
		if (other == null) return this;
		int o = other.valuesFlags;
		if ((o & DUPLEXMODE_IS_SET) != 0) setDuplexMode(other.duplexMode);
		if ((o & PRINTQUALITY_IS_SET) != 0) setPrintQuality(other.printQuality);
		if ((o & COLORMODE_IS_SET) != 0) setColorMode(other.colorMode);
		if ((o & PAPERSIZE_IS_SET) != 0) setPaperSize(other.paperSize);
		return this;
	}
	/**
	 * Return a HashMap that maps PrinterControl value names to integer values.
	 * Each key in the HashMap is a unique name mapping to a corresponding
	 * Integer object holding its value. Note that integer values are
	 * not unique. 
	 * @param whichValues one of the XXX_IS_SET values to indicate
	 * which data to retrieve. For example DUPLEXMODE_IS_SET will
	 * retrieve the DUPLEX_XXX values and the corresponding strings.
	 * @return
	 */
	/*
	public static HashMap getValuesAndNames(int whichValues)
	{
		Hashtable ht = new Hashtable();
		switch(whichValues){
		case DUPLEXMODE_IS_SET:
			ht.put("", value)
		}
	}
	*/
}
