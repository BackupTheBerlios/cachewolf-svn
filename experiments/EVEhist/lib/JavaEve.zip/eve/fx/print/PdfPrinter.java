package eve.fx.print;

import java.io.IOException;
import java.io.OutputStream;

import eve.fx.gui.WindowSurface;
import eve.fx.points.IPointDocument;
import eve.fx.points.PageFormat;
import eve.fx.points.PdfMaker;
import eve.fx.points.PointGraphics;
import eve.fx.points.PdfMaker.PageCanvas;
import eve.io.File;
import eve.sys.Handle;

public class PdfPrinter extends PrinterJobObject{
	{
		outputCanChangeMediaOrientation = true;
	}

	public File outputFile;
	public OutputStream outputStream;
	public boolean dontCloseOutputStream;
	PdfMaker maker;
	PageCanvas curPage;
	
	protected void cancelCurrentPage(Handle h) {
		curPage.cancel();
		curPage.getPage().cancel();
	}

	protected boolean endPrinting(Handle h) {
		try{
			if (maker != null) maker.finish(!dontCloseOutputStream);
			return true;
		}catch(IOException e){
			h.error = e;
			return false;
		}
	}

	protected PointGraphics newPage(Handle h, PageFormat format) {
		try{
			curPage = maker.newPage(format).getCanvas();
			return new PointGraphics(curPage);
		}catch(IOException e){
			h.error = e;
			return null;
		}
	}

	protected boolean printCurrentPage(Handle h) {
		try{
			curPage.finish();
			curPage.getPage().finish();
			return true;
		}catch(IOException e){
			h.error = e;
			return false;
		}
	}

	protected boolean startPrinting(Handle h, String documentName) {
		try{
			if (outputFile != null)
				outputStream = outputFile.toWritableStream(false); 
			maker = new PdfMaker();
			maker.open(outputStream);
			return true;
		}catch(IOException e){
			h.error = e;
			return false;
		}
	}
	/**
	 * Return the IPointDocument IF the output is compatible (e.g. a PDF document).
	 */
	public IPointDocument getPointDocument()
	{
		return maker;
	}

	public Handle printDialog(WindowSurface parent) {
		// TODO Auto-generated method stub
		return new Handle(Handle.Succeeded,null);
	}

}
