/*
 * Created on May 15, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.print;

import eve.fx.points.CellPrinter;
import eve.fx.points.PageFormat;
import eve.fx.points.PointGraphics;

/**
 * @author Michael L Brereton
 * This class is meant to be used along with a PrintPages Object. The PrintPages Object
 * holds a list of PrintablePage Objects and prints them one by one when it is printed
 * via a PrinterJob or PrintPreview or other class that implements Printer.
 * <p>
 * The only method that must be overridden is composePage(). In this method you should
 * create and add PrintCells to the page using addCell(). Or use addMarginedPanel() to create and add
 * a PrintCellPanel that you can then add your data PrintCell objects to.
 */
//####################################################
public abstract class PrintablePage extends CellPrinter {
	/**
	 * The page number assigned to the Page, starting from 1.
	 */
	public int pageNumber = 0;
	
	public static final int ROTATE_NONE = PageFormat.TRANSFORM_NONE;
	public static final int ROTATE_90 = PageFormat.TRANSFORM_ROTATE_90;
	public static final int ROTATE_180 = PageFormat.TRANSFORM_ROTATE_180;
	public static final int ROTATE_270 = PageFormat.TRANSFORM_ROTATE_270;
	
	protected PrintablePage()
	{
		this(ROTATE_NONE);
	}
	protected PrintablePage(int rotation)
	{
		this.rotation = rotation;
	}
	public int rotation = 0;
	/**
	 * This is called before setupForPage() is called.
	 */
	public void setPageNumber(int pageNumber)
	{
		this.pageNumber = pageNumber;
	}
	void validatePage(PageFormat format, int pageNumber)
	{
		setPageNumber(pageNumber);
		if (rotation != ROTATE_NONE) format.transform(rotation);
	}
	/**
	 * This is called before the doPrint() method is called. At this point
	 * the pageNumber would also have been set. By default this does nothing.
	 */
	protected final void setupForPage(PointGraphics pg)
	{
		composePage(pg,page,pageNumber);
	}

	protected abstract void composePage(PointGraphics pg, PageFormat format, int pageNumber);
}

//####################################################
