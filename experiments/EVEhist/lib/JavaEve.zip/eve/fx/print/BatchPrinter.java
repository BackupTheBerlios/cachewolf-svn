/*
 * Created on May 8, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.print;

import java.util.Hashtable;
import java.util.Vector;

import eve.fx.points.PageFormat;
import eve.fx.points.PointDrawable;
import eve.fx.points.PointGraphics;
import eve.fx.points.PointRect;
import eve.sys.Handle;
import eve.sys.Wrapper;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class BatchPrinter extends Vector implements RandomPrintable {

	public String documentName;
	public int[] numPages;
	Hashtable toRelease;
	
	protected Printer myPrinter;
	
	/**
	 * A default PrinterControl Object that initially has no values
	 * set. Any set values in this Object is applied to the 
	 * PrinterProperties in adjustPrinterProperties(). 
	 */
	public PrinterControl printerControl = new PrinterControl();
	
	/**
	 * Adjust the PrinterProperties as necessary.
	 * By default this applies any values set in printerControl.
	 */
	public void adjustPrinterProperties(PrinterProperties p)
	{
		printerControl.overrideInProperties(p);
	}

	public void printingStarting(Printer printer)
	{
		myPrinter = printer;
	}
	
	public BatchPrinter(String docName)
	{
		documentName = docName;
	}
	private Printable findPrintableFor(int pageIndex, Wrapper indexToUse)
	{
		int t = 0;
		for (int i = 0; i<numPages.length; i++){
			if (pageIndex < t+numPages[i]) {
				indexToUse.setInt(pageIndex-t);
				//System.out.println("Got: "+i+", for: "+pageIndex+", "+indexToUse.getInt());
				return (Printable)get(i);
			}
			t += numPages[i];
		}
		return null;
	}
	//int curPage = -1;
	//int curOffset = 0;
	int curIndexOfPrintable = 0;
	/* (non-Javadoc)
	 * @see eve.fx.print.Printable#print(eve.sys.Handle, eve.fx.points.PointGraphics, eve.fx.points.PageFormat, int)
	 */
	public boolean print(Handle handle, PointGraphics g, PageFormat page, PointRect areaOnPage, int pageIndex) {
		if (numPages == null) countPages(page);
		Wrapper w = new Wrapper();
		Printable p = findPrintableFor(pageIndex,w);
		if (p == null) return false;
		return p.print(handle,g,page,areaOnPage,w.getInt());
	}

	/* (non-Javadoc)
	 * @see eve.fx.print.Printable#validatePage(eve.fx.points.PageFormat, int)
	 */
	public boolean validatePage(PageFormat page, int pageIndex) {
		if (numPages == null) countPages(page);
		Wrapper w = new Wrapper();
		Printable p = findPrintableFor(pageIndex,w);
		if (p == null) return false;
		return p.validatePage(page,w.getInt());
	}

	/* (non-Javadoc)
	 * @see eve.fx.print.Printable#countPages(eve.fx.points.PageFormat)
	 */
	public int countPages(PageFormat page) {
		if (numPages == null){
			numPages = new int[size()];
			for (int i = 0; i<numPages.length; i++)
				numPages[i] = ((Printable)get(i)).countPages(page);
		}
		int t = 0;
		for (int i = 0; i<numPages.length; i++)
			t += numPages[i];
		return t;
	}

	/* (non-Javadoc)
	 * @see eve.fx.print.Printable#printingComplete()
	 */
	public void printingComplete() {
		//curPage = -1;
		//curOffset = -1;
	}

	/* (non-Javadoc)
	 * @see eve.fx.print.Printable#getDocumentName()
	 */
	public String getDocumentName() {
		return documentName;
	}


	/* (non-Javadoc)
	 * @see eve.fx.print.Printable#getPreferredFormat()
	 */
	public PageFormat getPreferredFormat() {
		return null;
	}

	//private RandomPrintable lastPrintable = null;
	/* (non-Javadoc)
	 * @see eve.fx.print.RandomPrintable#getPage(eve.fx.points.PageFormat, int)
	 */
	public PointDrawable getPage(PageFormat pf, int pageIndex) {
		if (numPages == null) countPages(pf);
		Wrapper w = new Wrapper();
		RandomPrintable p = (RandomPrintable)findPrintableFor(pageIndex,w);
		if (p == null) return null;
		PointDrawable ret = p.getPage(pf,w.getInt());
		if (ret != null) synchronized (this){
			if (toRelease == null) toRelease = new Hashtable();
			toRelease.put(ret,p);
		}
		return ret;
	}

	/* (non-Javadoc)
	 * @see eve.fx.print.RandomPrintable#releasePage(eve.fx.points.PointDrawable)
	 */
	public void releasePage(PointDrawable pd) {
		if (toRelease != null){
			RandomPrintable p = (RandomPrintable)toRelease.get(pd);
			if (p != null){
				p.releasePage(pd);
				toRelease.remove(pd);
			}
		}
	}

}
//####################################################
