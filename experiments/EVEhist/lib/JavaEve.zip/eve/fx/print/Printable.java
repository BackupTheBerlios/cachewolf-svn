package eve.fx.print;
import eve.fx.points.PageFormat;
import eve.fx.points.PointGraphics;
import eve.fx.points.PointRect;
import eve.sys.Handle;
/**
* This is an interface which must be supported by objects which print to the printer.
* During the printing process the validatePage(int pageIndex) is called for each
* page to be printed (starting from 0) and if it returns true, then the print()
* method will be called for that page index. This process continues until validatePage()
* returns false.
**/
//##################################################################
public interface Printable{
//##################################################################
/**
 * This is called for each page as the document is being printed.
 */
public boolean print(Handle handle, PointGraphics g, PageFormat page, PointRect areaOnPage, int pageIndex);
/**
* This should return true if the page with the specified index should be printed. Within
* this method you can call transform() on the page.
**/
//===================================================================
public boolean validatePage(PageFormat page, int pageIndex);
//===================================================================
/**
 * This is called before printing starts and before countPages() is called.
 */
public void printingStarting(Printer printer); 
/**
* This is called when printing is about to start and it requests a count of the number of pages
* that would be necessary to print. If this is unknown then the method should
* return UNKNOWN_NUMBER_OF_PAGES, but even if it returns a valid number of pages, the validatePage()
* method will still be called before each page is printed via print().
**/
//===================================================================
public int countPages(PageFormat page);
//===================================================================

/**
 * This is called after printing is complete and indicates that the Printable object
 * can release resources associated with it.
 */
public void printingComplete();

public static final int UNKNOWN_NUMBER_OF_PAGES = -1;

//===================================================================
public String getDocumentName();
//===================================================================
/**
 * This should return true if the pages of the Printable can be printed in random
 * order and repeatedly.
 */
//public boolean supportsRandomAccess();

/**
 * Return the preferred format for printing, or null if there is no preferred format.
 */
public PageFormat getPreferredFormat();
/**
 * This is used during printing. It requests that the Printable Object provide
 * a valid PointMetrics.
 */
//public PointMetrics getCurrentPointMetrics();
/**
 * Adjust the PrinterProperties as necessary. Do not replace objects
 * that are already in the properties - change them as necessary.
 */
public void adjustPrinterProperties(PrinterProperties p);
//##################################################################
}
//##################################################################

