/*
 * Created on Mar 8, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.print;

import eve.data.DataObject;
import eve.fx.points.PageFormat;
import eve.sys.Handle;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class PrintTask extends DataObject {

public Handle printedHandle;
public Printable printable;
public Printer printer;
public PrintOptions options;
public PageFormat format;

public Handle print(Printer printer)
{
	this.printer = printer;
	printedHandle = printer.print(printable,format,options);
	return printedHandle;
}

}
//####################################################
