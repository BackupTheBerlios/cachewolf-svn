package eve.fx.print;
import eve.fx.points.FontManager;
import eve.fx.points.IPointDocument;
import eve.fx.points.PageFormat;
import eve.fx.points.PointGraphics;
import eve.fx.points.PointRect;
import eve.sys.Gate;
import eve.sys.Handle;
import eve.sys.Task;

//##################################################################
public abstract class PrinterJobObject implements Printer{
//##################################################################
//
//Do not move the next two.
//
int nativeJob;
protected boolean printerSelected;
protected PrinterControl printerControl;
/**
 * If this is not null then this will be assigned to all PointGraphics
 * created by a PrinterJobObject.
 */
public static FontManager globalFontManager;
//
private Gate printLock;
private Handle printingHandle;
/**
 * If the output actually changes the orientation of the media during the 
 * newPage() method then this should be set true.
 */
protected boolean outputCanChangeMediaOrientation = false;
/**
 * Return the IPointDocument IF the output is compatible (e.g. a PDF document).
 */
public IPointDocument getPointDocument()
{
	return null;
}

/**
Return a Lock object for this PrinterJobObject
**/
//-------------------------------------------------------------------
private Gate getPrintLock()
//-------------------------------------------------------------------
{
	if (printLock == null) printLock = new Gate();
	return printLock;
}
/**
Return if the PrintJob is currently printing.
**/
//===================================================================
public boolean isPrinting()
//===================================================================
{
	getPrintLock().synchronize(); try{
		return printingHandle != null;
	}finally{
		getPrintLock().leave();
	}
}
/**
If this returns true, then no printing is currently being done
and the current thread holds the printLock.
**/
//-------------------------------------------------------------------
protected boolean lockIfNotPrinting()
//-------------------------------------------------------------------
{
	getPrintLock().synchronize();
	if (printingHandle != null) {
		getPrintLock().leave();
		return false;
	}
	return true;
}

//-------------------------------------------------------------------
protected final void printingComplete()
//-------------------------------------------------------------------
{
	getPrintLock().synchronize();
	printingHandle = null;
	getPrintLock().leave();
}
/**
Get the Handle for the current printing operation.
If this returns null then there is no current printing.
**/
//===================================================================
public Handle getCurrentPrintingHandle()
//===================================================================
{
	Handle h = null;
	getPrintLock().synchronize();
	h = printingHandle;
	getPrintLock().leave();
	return h;
}
/**
Cancel a print operation if one is underway. This calls stop(0) on the
current print handle if one is present.
**/
//===================================================================
public boolean cancel()
//===================================================================
{
	Handle h = getCurrentPrintingHandle();
	if (h == null) return false;
	h.stop(0);
	return true;
}
/**
* This starts the printing process going. The print() method of the toPrint
* object will be called with a page index starting from 0 and increasing until
* the validatePage method returns false. The format parameter will eventually be used
* to set a particular page format, but at the moment is not used.
**/
//===================================================================
public final Handle print(Printable toPrint,PageFormat format, PrintOptions po)
//===================================================================
{
	if (!lockIfNotPrinting()) return new Handle(new IllegalStateException("Still printing a Job."));
	//
	// Now I hold the lock.
	//
	try{
		if (format == null) format = new PageFormat();
		if (po == null) po = new PrintOptions();
		Task to = getPrintTask(toPrint, format, po);
		printingHandle = to.start();
		return printingHandle;
	}catch(RuntimeException e){
		e.printStackTrace();
		throw e;
	}catch(Error er){
		er.printStackTrace();
		throw er;
	}finally{
		getPrintLock().leave();
	}
}
public void setPrinterProperties(PrinterProperties pp)
{
	PrinterControl pc = pp.getPrinterControl();
	if (pc != null) this.printerControl = pc;
}
protected abstract boolean startPrinting(Handle h, String documentName);
protected abstract PointGraphics newPage(Handle h, PageFormat format);
protected abstract boolean printCurrentPage(Handle h);
protected abstract void cancelCurrentPage(Handle h);
protected abstract boolean endPrinting(Handle h);
/**
Return a Task object that does the printing. Once the task is complete it MUST call
printingComplete() even if the task was cancelled.
**/
//-------------------------------------------------------------------
protected Task getPrintTask(final Printable toPrint,final PageFormat format,final PrintOptions po)
//-------------------------------------------------------------------
{
			return new Task(){
				protected void doRun(){
					//PageFormat pf = format;
					format.acceptRequests();
					PageFormat actual = (PageFormat) format.getCopy();
					if (printerControl == null) printerControl = new PrinterControl();
					PrinterProperties pp = printerControl.addToProperties(null);
					toPrint.adjustPrinterProperties(pp);
					try{
						String s = toPrint.getDocumentName();
						if (s == null) s = "Eve Document";
						if (!startPrinting(this,s)) stop(0);
						toPrint.printingStarting(PrinterJobObject.this);
						if (!shouldStop) try{
							PageCounter pc = new PageCounter(this,toPrint,format,po);
							PageFormat pf;
							PointRect area = new PointRect();
							while (!shouldStop && (pf = pc.moveToNextPage()) != null){
								int i = pc.currentPageIndex;
								actual.copyFrom(pf);
								PointGraphics dpg = newPage(this,actual);
								if (dpg == null) stop(0);
								else{
									if (globalFontManager != null){
										globalFontManager.assignTo(dpg);
									}
									if (!outputCanChangeMediaOrientation){
										dpg.getTransformState().rotatePageRightAngle(pf.getTransformation(),actual.fullPageWidth,actual.fullPageHeight);//.translate(pf.fullPageHeight/2,pf.fullPageWidth/2);
										actual.matchTransform(pf);
									}
									area.set(0,0,actual.fullPageWidth,actual.fullPageHeight);
									try{
										if (!toPrint.print(this,dpg,actual,area,i))
											stop(0);
									}catch(Throwable t){
										//t.printStackTrace();
										fail(t);
										stop(0);
									}
									if (shouldStop) cancelCurrentPage(this);
									else if (!printCurrentPage(this))
										stop(0);
								}
							}
							toPrint.printingComplete();
						}finally{
							if (!endPrinting(this)) stop(0);
						}
						if (shouldStop) set(Aborted);
						else set(Succeeded);
					}catch(Throwable e){
						fail(e);
					}finally{
						printingComplete();
					}
				}
			};
}


//##################################################################
/* (non-Javadoc)
 * @see eve.fx.print.Printer#print(eve.fx.print.PrintTask)
 */
public Handle print(PrintTask pt) {
	pt.printer = this;
	return pt.printedHandle = print(pt.printable,pt.format,pt.options);
}
/**
 * This returns if a Printer has been selected and so this PrinterJob is ready
 * for printing. If this returns false then you should call printDialog() to
 * get the user to select a printer.
 */
public boolean printerWasSelected()
{
	return printerSelected;
}
//##################################################################
}
//##################################################################

