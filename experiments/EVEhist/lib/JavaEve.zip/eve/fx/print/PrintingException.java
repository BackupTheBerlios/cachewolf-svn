package eve.fx.print;

public class PrintingException extends RuntimeException {

	public PrintingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PrintingException() {
		// TODO Auto-generated constructor stub
	}

	public PrintingException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PrintingException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
