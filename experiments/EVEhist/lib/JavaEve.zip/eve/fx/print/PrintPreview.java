package eve.fx.print;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;

import eve.fx.gui.WindowSurface;
import eve.fx.points.PageFormat;
import eve.io.File;
import eve.io.PNGEncoder;
import eve.sys.Convert;
import eve.sys.Handle;
import eve.sys.ImageData;
import eve.sys.Vm;
import eve.zipfile.ZipEntry;
import eve.zipfile.ZipOutputStream;
/**
A PrintPreview is very similar to a PrinterJob except that the output
for each page will be an Image of a resolution that you preset.<p>
**/
//##################################################################
public class PrintPreview extends PrintToImages{
//##################################################################
	
	public boolean previewToFile;
	
	public PrintPreview()
	{
		this(null);
	}
	public PrintPreview(PageFormat standardPage)
	{
		super(standardPage);
	}
	public File outputFile = null;
	public File tempDir = null;
	public void setSavedOutputFile(File outputFile)
	{
		previewToFile = true;
		this.outputFile = outputFile;
	}
	public Handle printDialog(WindowSurface ws)
	{
		//if (!previewToFile || true) 
		return new Handle(Handle.Succeeded,null);
		/*
		return new Task(){
			protected void doRun(){
				
			}
		}.start();
		*/
	}
	protected OutputStream getSavedOutputStream() throws IOException
	{
		if (outputFile == null) outputFile = File.getNewFile().createTempFile("PP","zip",tempDir);
		if (outputFile == null) throw new IOException("Can't create temp file!");
		return outputFile.toWritableStream(false);
	}
	
	protected ZipOutputStream out;
	PNGEncoder pe;
	
	private static RuntimeException throwRuntimeEx(Throwable t)
	{
		if (t instanceof RuntimeException) throw (RuntimeException)t;
		else if (t instanceof Error) throw (Error)t;
		throw (RuntimeException)Vm.setCause(new RuntimeException(),t);
	}
	
	private static String toPageNumber(int number)
	{
		String num = Convert.toString(number);
		while(num.length() < 4) num = "0"+num;
		return num;
	}
	
//===================================================================
public Vector getImages(Handle fromPrint)
//===================================================================
{
	try{
		fromPrint.waitOn(fromPrint.Success);
		return (Vector)fromPrint.returnValue;
	}catch(Exception e){
		return null;
	}
}
//##################################################################
Vector images;
int imageCount;
/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#startPrinting(eve.sys.Handle, java.lang.String)
 */
protected boolean startPrinting(Handle h, String documentName) {
	images = new Vector();
	imageCount = 0;
	if (previewToFile)
		try{
			out = new ZipOutputStream(getSavedOutputStream());
		}catch(Throwable t){
			h.stop(0);
			throwRuntimeEx(t);
			return false;
		}
	return true;
}


/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#endPrinting(eve.sys.Handle)
 */
protected boolean endPrinting(Handle h) {
	if (!previewToFile)
		h.returnValue = images;
	else
		try{
			out.finish();
			out.close();
			h.returnValue = outputFile;
		}catch(Exception e){
		}
	return true;
}

protected boolean printFinalImage(Handle h, ImageData im)
{
	if (!previewToFile)
		images.add(im);
	else
		try{
			String name = "Page-"+toPageNumber(++imageCount);
			out.putNextEntry(new ZipEntry(name+".png"));
			pe = new PNGEncoder();
			pe.writeImage(out,im,false);
			im.freeImage();
			return true;
		}catch(Throwable t){
			h.stop(0);
			throwRuntimeEx(t);
			return false;
		}
	return true;
}


}