/*
 * Created on May 17, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.print;

import eve.fx.points.PageFormat;
import eve.fx.points.PointDrawable;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public interface RandomPrintable extends Printable{

	/**
	 * Get a PointDrawable for a particular page. This method may modify the provided
	 * PageFormat.
	 * @param pg the PointGraphics that the page will print on.
	 * @param pf the PageFormat to be used.
	 * @param pageIndex the index of the page - starting from zero.
	 * @return the PointDrawable or null if the page does not exist.
	 */
	public PointDrawable getPage(PageFormat pf, int pageIndex);
	public void releasePage(PointDrawable pd);
}

//####################################################
