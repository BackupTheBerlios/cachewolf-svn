package eve.fx.print;

import eve.fx.gui.WindowSurface;
import eve.fx.points.IPointDocument;
import eve.fx.points.PageFormat;
import eve.sys.Handle;

/**
 * This represents an object that provides a Printable with pages and a PrintSurface
 * on which to print. 
 */
//####################################################
public interface Printer {

	/**
	 * Return the IPointDocument IF the output is compatible (e.g. a PDF document).
	 */
	public IPointDocument getPointDocument();
	/**
	 * Start the process of printing and return a Handle to monitor or stop the operation.
	 * @param printable the Printable object to print.
	 * @param format An optional PageFormat object.
	 * @param options An optional PrintOptions object.
	 * @return a Handle that can be used to monitor the progress of the print operation
	 * and stop the operation if necessary.
	 */
	public Handle print(Printable printable, PageFormat format, PrintOptions options);
	/**
	 * Start the process of printing and return a Handle to monitor or stop the operation.
	 * After calling this method, the "printer" field in the PrintTask parameter is
	 * set to be this Printer object.
	 * @param pt an PrintTask object.
	 * @return a Handle that can be used to monitor the progress of the print operation
	 * and stop the operation if necessary.
	 */
	public Handle print(PrintTask pt);
	/**
	* This displays the printer select/setup dialog box, which may be a native OS
	* dialog box.
	* @param parent The parent WindowSurface - which can be null.
	* @return a Handle indicating the progress of the dialog. If it succeeds when
	* stopped then the dialog was exited indicating a selected printer, if
	* it fails then the user cancelled the dialog.
	*/
//	===================================================================
	public Handle printDialog(WindowSurface parent);
//	===================================================================
	
	public void setPrinterProperties(PrinterProperties pp);
}
//####################################################
