package eve.fx.print;
import java.awt.Graphics2D;
import java.io.IOException;
import java.util.Vector;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Chromaticity;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.PrintQuality;
import javax.print.attribute.standard.Sides;

//import javax.print.attribute.HashPrintRequestAttributeSet;
//import javax.print.attribute.PrintRequestAttributeSet;

import eve.data.PropertyList;
import eve.fx.Font;
import eve.fx.FontMetrics;
import eve.fx.Fx;
import eve.fx.Graphics;
import eve.fx.ISurface;
import eve.fx.Image;
import eve.fx.Rect;
import eve.fx.gui.WindowSurface;
import eve.fx.points.PageFormat;
import eve.fx.points.PointGraphics;
import eve.fx.points.PointRect;
import eve.sys.Handle;
import eve.sys.Task;
import eve.util.mString;

//##################################################################
public final class PrinterJob extends PrinterJobObject implements ISurface{
//##################################################################
java.awt.print.PrinterJob nativeJob;
private java.awt.Graphics2D currentPage;
boolean dialogBoxShown = false;
/**
 * Returns true if the system supports a native dialog box.
 */
public static boolean hasNativeDialog()
{
	return true;
}

private static PrintRequestAttributeSet fromProperties(PrinterProperties pp,PrintRequestAttributeSet dest)
{
	if (dest == null) dest = new HashPrintRequestAttributeSet();
	if (pp == null) return dest;
	PrinterControl pc = pp.getPrinterControl();
	if (pc != null){
		int o = pc.valuesFlags;
		if ((o & PrinterControl.DUPLEXMODE_IS_SET) != 0) 
			switch(pc.duplexMode){
			case PrinterControl.DUPLEX_VERTICAL: dest.add(Sides.TWO_SIDED_LONG_EDGE); break;
			case PrinterControl.DUPLEX_HORIZONTAL: dest.add(Sides.TWO_SIDED_SHORT_EDGE); break;
			default: dest.add(Sides.ONE_SIDED); break;
			}
		if ((o & PrinterControl.PRINTQUALITY_IS_SET) != 0) 
			switch(pc.printQuality){
			case PrinterControl.QUALITY_DRAFT: 
			case PrinterControl.QUALITY_LOW: 
				dest.add(PrintQuality.DRAFT); break;
			case PrinterControl.QUALITY_HIGH: 
			case PrinterControl.QUALITY_BEST: 
				dest.add(PrintQuality.HIGH); break;
			case PrinterControl.QUALITY_MEDIUM:
			default:
					dest.add(PrintQuality.NORMAL); break;
			}
		if ((o & PrinterControl.COLORMODE_IS_SET) != 0) 
			switch(pc.colorMode){
			case PrinterControl.COLOR_MONO: 
			case PrinterControl.COLOR_MONO_BLACK_INK_ONLY: 
				dest.add(Chromaticity.MONOCHROME); break;
			default:
				dest.add(Chromaticity.COLOR); break;
			}
		if ((o & PrinterControl.PAPERSIZE_IS_SET) != 0) 
			switch(pc.paperSize){
			case PrinterControl.PAPER_A4: 
				dest.add(MediaSizeName.ISO_A4); break;
			case PrinterControl.PAPER_LEGAL: 
				dest.add(MediaSizeName.NA_LEGAL); break;
			case PrinterControl.PAPER_LETTER:
			default:
				dest.add(MediaSizeName.NA_LETTER); break;
			}
	}
	return dest;
}
private static String printerName(String src, StringBuffer descriptive)
{
	if (src == null) return null;
	int idx = src.indexOf('=');
	if (idx == -1){
		if (descriptive != null) descriptive.append(src);
		return src;
	}
	if (descriptive != null) descriptive.append(src.substring(idx+1));
	return src.substring(0,idx);
}
/**
 * Get a list of all available printers which can be used with getPrinterJob()
 * to get a PrinetJob for a specific printer. 
 * @param descriptiveNames if this is not null then a descriptive
 * name for each printer will be placed in the vector in the same
 * order as the names of the printers. If there is no descriptive name
 * then the printer device name is used instead. 
 * @return an array of available printer names. 
 */
public static String [] getPrinterNames(Vector descriptiveNames)
{
	PropertyList pl = getPrinterProperties(null);
	StringBuffer sb = descriptiveNames == null ? null : new StringBuffer();
	String[] all = mString.split(pl.getString(PrinterProperties.AVAILABLE_PRINTERS, ""),',');
	for (int i = 0; i<all.length; i++){
		if (sb != null) sb.setLength(0);
		all[i] = printerName(all[i],sb);
		if (descriptiveNames != null) descriptiveNames.add(sb.toString());
	}
	return all;
}
/**
 * Get the name of the default printer.
 * @param descriptiveName if this is not null then a descriptive
 * name for the printer is appended to the StringBuffer.
 * If no descriptive name exists the printer device name (the same
 * one returned) is used.
 * @return the device name of the default printer.
 */
public static String getDefaultPrinter(StringBuffer descriptiveName)
{
	PropertyList pl = getPrinterProperties(null);
	return printerName(pl.getString(PrinterProperties.DEFAULT_PRINTER, null), descriptiveName);
}
/**
 * Get the PrinterProperties for the local machine. This can
 * be sent to PrinterDialog() for a non-native printer dialog box.
 * @param pl a destination PrinterProperties object, or null to
 * create and return a new one.
 * @return the destination or new PrinterProperties.
 */
public static PrinterProperties getPrinterProperties(PrinterProperties pl)
{
	if (pl == null) pl = new PrinterProperties();
	PrintService [] all = PrintServiceLookup.lookupPrintServices(null, null);
	StringBuffer sb = new StringBuffer();
	if (all != null) for (int i = 0; i<all.length; i++){
		if (i != 0) sb.append(",");
		sb.append(all[i].getName());
	}
	pl.set(PrinterProperties.AVAILABLE_PRINTERS,sb.toString());
	PrintService ps = PrintServiceLookup.lookupDefaultPrintService();
	if (ps != null) pl.set(PrinterProperties.DEFAULT_PRINTER, ps.getName());
	return pl;
}
/**
 * This attempts to create and run a non-native printer dialog.
 * @param pl a PrinterProperties returned by getPrinterProperties().
 * @return a Handle that is used to monitor the dialog.
 */
public static Handle printerDialog(PrinterProperties pl)
{
	return Fx.printerDialog(pl);
}
/**
 * Apply the values specified in the PrinterControl parameter to this
 * PrinterJob.
 * @param control the PrinterControl parameters.
 * @return the set of PrinterControl.XXX_SET bit flags of the values
 * that were successfully set. If a bit that was set in the
 * valuesFlag field of control is not returned, it means that value
 * could not be set in the destination printer.
 */
/*
public int applyPrinterControl(PrinterControl control)
{
	return 0;
}
*/
/**
 * Get the PrinterControl parameters if possible from the current PrinterJob.
 * @param destination an optional destination PrinterControl object. If
 * this is null a new one is created and returned.
 * @return the destination or new PrinterControl object.
 */
/*
public PrinterControl getPrinterControl(PrinterControl destination)
{
	if (destination == null) destination = new PrinterControl();
	destination.valuesFlags = 0;
	return destination;
}
*/
private static PropertyList toPropertyList(String[] props, PropertyList pl)
{
	if (pl == null) pl = new PropertyList();
	String[] all = props;
	if (all != null){
		for (int i = 0; i<all.length; i++){
			int idx = all[i].indexOf('|');
			if (idx == -1) continue;
			pl.set(all[i].substring(0,idx), all[i].substring(idx+1));
		}
	}
	String dflt = pl.getString(PrinterProperties.DEFAULT_PRINTER, null);
	String avail = pl.getString(PrinterProperties.AVAILABLE_PRINTERS, null);
	if ((avail == null || avail.length() == 0) && dflt != null)
		pl.set(PrinterProperties.AVAILABLE_PRINTERS,pl.getString(PrinterProperties.DEFAULT_PRINTER, dflt));
	return pl;
}
//public static final int HINT_DONT_RESIZE_WIDTH = 0x1;
//public static final int HINT_DONT_RESIZE_HEIGHT = 0x2;
/**
This is a "hint" flag for getPageRect. If it is specified and the PageRect of the
requested size and dpi could not be created, then the PrinterJob should not attempt
to create a smaller one.
**/
//public static final int HINT_DONT_RESIZE = HINT_DONT_RESIZE_WIDTH|HINT_DONT_RESIZE_HEIGHT;
//public static final int HINT_MONO_IMAGE = 0x10;
//public static final int HINT_GRAYSCALE_IMAGE = 0x20;
private static PrintService find(String name)
{
	PrintService [] all = PrintServiceLookup.lookupPrintServices(null, null);
	if (all == null) return null;
	int li = -1;
	for (int i = 0; i<all.length; i++){
		String s = all[i].getName();
		if (s.equals(name)) return all[i];
		if (s.equalsIgnoreCase(name))
			li = i;
	}
	if (li != -1) return all[li];
	return null;
}
/**
* Get a new PrinterJob object. Under some Eve environments (e.g.  
* under Win32) this will automatically bring up the PrinterSelect
* dialog box. If the user cancels the dialog box, getPrinterJob() will return
* false.
 * @param printerName an optional printer name. This can be null for the default printer.
 * Note that if printDialog() is called on the PrinterJob then the
 * name of the selected printer may be changed.
 * @return a new PrinterJob object.
 * @throws IOException if the job could not be created.
 */
public static PrinterJob getPrinterJob(String printerName) throws IOException
//===================================================================
{
	return getPrinterJob(printerName,null);
}
/**
* Get a new PrinterJob object. Under some Eve environments (e.g.  
* under Win32) this will automatically bring up the PrinterSelect
* dialog box. If the user cancels the dialog box, getPrinterJob() will return
* false.
 * @param printerName an optional printer name. This can be null for the default printer.
 * Note that if printDialog() is called on the PrinterJob then the
 * name of the selected printer may be changed.
 * @param properties and optional PrinterProperties that holds input and
 * output properties. To set the printer parameters (e.g. duplex printing, print quality, etc.)
 * use setPrinterControl() on the PrinterProperties object to pass these
 * parameters in a PrinterControl object. After the method returns the
 * PrinterControl object will be updated to reflect the actual parameters
 * used by the printer.
 * @return a new PrinterJob object.
 * @throws IOException if the job could not be created.
 */

public static PrinterJob getPrinterJob(String printerName,PrinterProperties properties) throws IOException
//===================================================================
{
	PrinterControl pc = null;
	if (properties != null) pc = properties.getPrinterControl();
	if (pc == null) pc = new PrinterControl(true);
	java.awt.print.PrinterJob nj = java.awt.print.PrinterJob.getPrinterJob();
	if (nj == null) return null;
	PrinterJob pj = new PrinterJob();
	pj.nativeJob = nj;
	if (printerName != null){
		PrintService ps = find(printerName);
		try{
			if (ps != null) {
				nj.setPrintService(ps);
			}
		}catch(Throwable t){
			
		}
	}
	pj.printerControl = pc;
	return pj;
}
/**
* This displays the printer select/setup dialog box. Some ewe environments
* will always bring up the printer dialog box when a PrinterJob is created.
* If alwaysShow is false, the printDialog will only be brought up if it was
* not brought up on creation. If alwaysShow is true, it is always brought up.
* <p>
* Because the box may be brought up on creation on some systems, but not others
* the correct way to ensure that it is brought up once only is:
* <pre>
* PrinterJob pj = PrinterJob.getPrinterJob();
* if (pj != null)
*  if (pj.printDialog(false))
*   pj.print(myPrinter,null);
*
**/
//===================================================================
public Handle printDialog(WindowSurface parent)
//===================================================================
{
	if (parent == null) parent = WindowSurface.getMainSurface();
		final Handle h = new Handle();
		new Thread(){
			public void run(){
				try{
					//WindowSurface.enterNativeDialog();
					//PrintRequestAttributeSet as = new HashPrintRequestAttributeSet();
					//if (nativeJob.printDialog(as))
					if (nativeJob.printDialog())
						h.set(Handle.Succeeded);
					else
						h.set(Handle.Failed);
				}catch(Throwable e){
					e.printStackTrace();
					h.fail(e);
				}finally{
					//WindowSurface.exitNativeDialog();
				}
			}
		}.start();
		return h;
		/*
		try{
			h.waitOn(Handle.Success);
			return true;
		}catch(HandleStoppedException e){
			return false;
		}catch(InterruptedException e){
			return false;
		}
		//return nativeJob.printDialog();
		 
		 */
}

//===================================================================
PageFormat toEwePageFormat(java.awt.print.PageFormat pf,PageFormat pg)
//===================================================================
{
	if (pf == null) return null;
	if (pg == null) pg = new PageFormat();
	//pg.pointsPerInch = 72;
	//int pi = pg.pointsPerInch;
	pg.imageableWidth = pf.getImageableWidth();//(int)(((pf.getImageableWidth()*pi)/72)*xscale)-(int)(20*xscale);
	pg.imageableHeight = pf.getImageableHeight();//(int)(((pf.getImageableHeight()*pi)/72)*yscale)-(int)(20*yscale);
	pg.fullPageWidth = pf.getWidth();//(int)(((pf.getWidth()*pi)/72)*xscale);
	pg.fullPageHeight = pf.getHeight();//(int)(((pf.getHeight()*pi)/72)*yscale);
	pg.imageableX = pf.getImageableX();//(int)(pf.getImageableX()*xscale);
	pg.imageableY = pf.getImageableY();//(int)(pf.getImageableY()*yscale);
	pg.xDPI = 360;
	pg.yDPI = 360;
	//System.out.print(pf.getImageableWidth()+", "+pf.getImageableHeight()+", "+pf.getWidth()+", "+pf.getHeight());
	//System.out.println(", "+pf.getImageableX()+", "+pf.getImageableY());
	//pg.pixelsPerInch = (int)(xscale*72);
	return pg;
}
//===================================================================
java.awt.print.PageFormat toJavaPageFormat(PageFormat pf)
//===================================================================
{
	//if (pf == null) return null;
	java.awt.print.PageFormat jpf = new java.awt.print.PageFormat();
	java.awt.print.Paper p = new java.awt.print.Paper();
	if (pf.requestedFullWidth != -1) p.setSize(pf.requestedFullWidth,pf.requestedFullHeight);
	p.setImageableArea(0,0,p.getWidth(),p.getHeight());
	jpf.setPaper(p);
	/*
	if (false && (pf.requestedX != -1 || pf.requestedFullWidth != -1)){
		if (pf.requestedFullWidth != -1) p.setSize(pf.requestedFullWidth,pf.requestedFullHeight);
		if (pf.requestedX != -1) p.setImageableArea(pf.requestedX,pf.requestedY,pf.requestedWidth,pf.requestedHeight);
		jpf.setPaper(p);
	}else{
		//
		// Get the maximum size.
		//
		java.awt.print.Paper p = new java.awt.print.Paper();
		p.setImageableArea(36,36,p.getWidth()-72,p.getHeight()-72);
		System.out.println(jpf.getImageableX()+", "+jpf.getImageableY());
		jpf.setPaper(p);
	}
	*/
	return jpf;
}
private int gotID;

/**
* This starts the printing process going. The print() method of the toPrint
* object will be called with a page index starting from 0 and increasing until
* the validatePage method returns false. The format parameter will eventually be used
* to set a particular page format, but at the moment is not used.
**/
//===================================================================
protected Task getPrintTask(final Printable toPrint,final PageFormat format,final PrintOptions options)
//===================================================================
{
	final PrinterJob pj = this;
	return new Task(){
		protected void doRun(){
			try{
				final PageFormat actual = new PageFormat();
				gotID = -1;
				startDoing("Starting print job.");
				PrinterProperties pp = printerControl.addToProperties(null);
				toPrint.adjustPrinterProperties(pp);
				PrintRequestAttributeSet as = fromProperties(pp, null);
				final Task me = this;
				java.awt.print.Printable pr = new java.awt.print.Printable(){
					boolean done = false;
					PageCounter pc;
					PageFormat mpf = null;
					PointRect area = new PointRect();
					public int print(java.awt.Graphics pg,java.awt.print.PageFormat pf,int pageIndex){
						try{
							//Vm.debug("Printing: "+pageIndex);
							if (done) return NO_SUCH_PAGE;
							PageFormat epf = toEwePageFormat(pf,format);
							if (pc == null) pc = new PageCounter(me,toPrint,format,options);
							//
							// For some reason, this almost always gets called twice - the first time round
							// with an identity transform.
							//
							currentPage = (Graphics2D)pg;
							//System.out.println(currentPage.getDeviceConfiguration().getNormalizingTransform());
							currentPage.scale(72.0/epf.xDPI,72.0/epf.yDPI);
							//AffineTransform at = currentPage.getDeviceConfiguration().getDefaultTransform();
							//at.scale(72.0/epf.xDPI,72.0/epf.yDPI);
							//currentPage.setTransform(at);
							/*
							if (gotID != pageIndex && currentPage.getTransform().isIdentity()){
								gotID = pageIndex;
								return PAGE_EXISTS;
							}
							*/
							if (gotID != pageIndex){
								if ((mpf = pc.moveToNextPage()) == null) {
									done = true;
									return NO_SUCH_PAGE;
								}
								gotID = pageIndex;
							}
							actual.copyFrom(epf);
							//if (!toPrint.print(me,getPrintSurface(actual),actual,pc.currentPageIndex)){
							PointGraphics dpg = new PointGraphics(new Graphics(0,PrinterJob.this),(int)((actual.fullPageWidth*actual.xDPI)/72),(int)((actual.fullPageHeight*actual.yDPI)/72),actual.xDPI,actual.yDPI);
							if (mpf != null){
								dpg.getTransformState().rotatePageRightAngle(mpf.getTransformation(),actual.fullPageWidth,actual.fullPageHeight);
								actual.matchTransform(mpf);
							}
							area.set(0,0,actual.fullPageWidth,actual.fullPageHeight);
							if (!toPrint.print(me,dpg,actual,area,pc.currentPageIndex)){
								done = true;
								return NO_SUCH_PAGE;
							}
							return PAGE_EXISTS;
						}catch(Exception e){
							//e.printStackTrace();
							fail(e);
							return NO_SUCH_PAGE;
						}
					}
				};
				format.acceptRequests();
				java.awt.print.PageFormat jpf = toJavaPageFormat(format);
				nativeJob.setPrintable(pr,jpf);
				nativeJob.print(as);
				toPrint.printingComplete();
				if (shouldStop) set(Aborted);
				else set(Succeeded);
				//Vm.debug("Succeeded!");
			}catch(Exception e){
				e.printStackTrace();
				fail(e);
			}finally{
				printingComplete();
			}
		}
	};
}
//##################################################################
/* (non-Javadoc)
 * @see eve.fx.ISurface#getSurfaceType()
 */
public int getSurfaceType() {
	return PRINTERJOB_SURFACE;
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#getFontMetrics(eve.fx.Font)
 */
public FontMetrics getFontMetrics(Font f) {
	return new FontMetrics(f,this);
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#newGraphics()
 */
public Graphics getGraphics() {
	return new Graphics(0,this);
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#getNativeDrawable()
 */
public Object getNativeDrawable() {
	return currentPage;
}
/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#startPrinting(eve.sys.Handle, java.lang.String)
 */
protected boolean startPrinting(Handle h, String documentName) {
	// TODO Auto-generated method stub
	return false;
}
/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#newPage(eve.sys.Handle, eve.fx.points.PageFormat)
 */
protected PointGraphics newPage(Handle h, PageFormat format) {
	// TODO Auto-generated method stub
	return null;
}
/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#printCurrentPage(eve.sys.Handle)
 */
protected boolean printCurrentPage(Handle h) {
	// TODO Auto-generated method stub
	return false;
}
/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#cancelCurrentPage(eve.sys.Handle)
 */
protected void cancelCurrentPage(Handle h) {
	// TODO Auto-generated method stub
	
}
/* (non-Javadoc)
 * @see eve.fx.print.PrinterJobObject#endPrinting(eve.sys.Handle)
 */
protected boolean endPrinting(Handle h) {
	// TODO Auto-generated method stub
	return false;
}
public void drawImage(Image src, int clipX, int clipY, int clipWidth, int clipHeight, int destX, int destY, int width, int height) {
	Graphics g = new Graphics(0,this);
	try{
		Rect r = Rect.getCached(clipX,clipY,clipWidth,clipHeight);
		Rect d = Rect.getCached(destX,destY,width,height);
		r.getIntersection(d,r);
		g.setClip(r.x,r.y,r.width,r.height);
		g.drawImage(src,destX,destY);
		r.cache();
		d.cache();
	}finally{
		g.free();
	}
}
public boolean captureImage(Image dest, int x, int y, int width, int height) {
	Graphics g = new Graphics(dest);
	try{
		g.copyRect(this,x,y,width,height,0,0);
		return true;
	}finally{
		g.free();
	}
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#moveImage(int, int, int, int, int, int)
 */
public boolean moveImage(int srcX, int srcY, int srcWidth, int srcHeight, int destX, int destY) {
	Graphics g = new Graphics(0,this);
	try{
		g.moveRect(srcX,srcY,srcWidth,srcHeight,destX,destY);
		return true;
	}finally{
		g.free();
	}
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#canCapture()
 */
public boolean canCapture() {
	return false;
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#canMove()
 */
public boolean canMove() {
	return true;
}
/* (non-Javadoc)
 * @see eve.fx.ISurface#getCompatibleImage(int, int)
 */
public Image getCompatibleImage(int width, int height) throws IllegalArgumentException {
	return new Image(width,height);
}

}
//##################################################################


