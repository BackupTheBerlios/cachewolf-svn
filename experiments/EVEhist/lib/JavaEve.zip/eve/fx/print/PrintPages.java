/*
 * Created on May 15, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.print;

import java.util.Vector;

import eve.fx.points.PageFormat;
import eve.fx.points.PointDrawable;
import eve.fx.points.PointGraphics;
import eve.fx.points.PointRect;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class PrintPages extends PrintableObject implements RandomPrintable {
	protected Vector pages = new Vector();
	PrintablePage nextPage;
	public void addFullPage(PrintablePage page)
	{
		if (pages == null) pages = new Vector();
		pages.add(page);
	}

	protected boolean setupForPage(PointGraphics pg, PageFormat format,
			int pageIndex) {
		nextPage =(PrintablePage)pages.get(pageIndex);
		nextPage.setPageNumber(pageIndex+1);
		nextPage.setup(pg,format);
		return true;
	}
	public void doPrint(PointGraphics pg, PointRect area)
	{
		nextPage.doPrint(pg, area);
	}
	
	public boolean validatePage(PageFormat page, int pageIndex) {
		if (pageIndex >= pages.size()) return false;
		nextPage =(PrintablePage)pages.get(pageIndex);
		nextPage.validatePage(page,pageIndex+1);
		return true;
	}

	public int countPages(PageFormat pf)
	{
		return pages.size();
	}

	/* (non-Javadoc)
	 * @see eve.fx.print.RandomPrintable#getPage(eve.fx.points.PointGraphics, eve.fx.points.PageFormat, int)
	 */
	public final PointDrawable getPage(PageFormat pf, int pageIndex) {
		if (!validatePage(pf,pageIndex)) return null;
		nextPage.setPageNumber(pageIndex+1);
		nextPage.setPageFormat(pf);
		return nextPage;
	}

	/* (non-Javadoc)
	 * @see eve.fx.print.RandomPrintable#releasePage(eve.fx.points.PointDrawable, int)
	 */
	public void releasePage(PointDrawable pd) {
		((PrintablePage)pd).free();
	}
	/**
	 * Return the number of pages added to this PrintPages.
	 */
	public int size()
	{
		return pages.size();
	}
}

//####################################################
