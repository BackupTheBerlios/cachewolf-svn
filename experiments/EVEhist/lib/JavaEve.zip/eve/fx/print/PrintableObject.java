package eve.fx.print;

import eve.fx.points.CellPrinter;
import eve.fx.points.FontManager;
import eve.fx.points.PageFormat;
import eve.fx.points.PointDrawable;
import eve.fx.points.PointGraphics;
import eve.fx.points.PointRect;
import eve.fx.points.PrintCell;
import eve.sys.Handle;
/**
A very useful base class for implementing a Printable object, which can then be
printed via a PrintJob.<p>
**/
//##################################################################
public abstract class PrintableObject extends CellPrinter implements RandomPrintable{
//##################################################################

public String documentName = "Eve Document";

public PageFormat preferredFormat = new PageFormat();
/**
 * A default PrinterControl Object that initially has no values
 * set. Any set values in this Object is applied to the 
 * PrinterProperties in adjustPrinterProperties(). 
 */
public PrinterControl printerControl = new PrinterControl();

protected Printer myPrinter;
protected FontManager myFontManager;

protected static FontManager fontManager;

public void printingStarting(Printer printer)
{
	if (fontManager == null){
		fontManager = new FontManager();
		fontManager.addTimes("serif");
		fontManager.addSansSerif("sans");
		fontManager.addCourier("courier");
		fontManager.makeAlias("serif", "times");
		fontManager.makeDefault("sans");
	}
	if (myFontManager == null) myFontManager = fontManager;
	myPrinter = printer;
}
public PageFormat getPreferredFormat()
{
	return preferredFormat;
}
public String getDocumentName()
{
	return documentName;
}
/**
 * Adjust the PrinterProperties as necessary.
 * By default this applies any values set in printerControl.
 */
public void adjustPrinterProperties(PrinterProperties p)
{
	printerControl.overrideInProperties(p);
}
/**
This is 360 by default, but you can change it to any value you want. It is used
by getXdpiFor() and getYdpiFor().
**/
protected double drawDPI = 360;

//-------------------------------------------------------------------
protected double getXdpiFor(int pageIndex) {return drawDPI;}
//-------------------------------------------------------------------
//-------------------------------------------------------------------
protected double getYdpiFor(int pageIndex) {return drawDPI;}
//-------------------------------------------------------------------

protected abstract boolean setupForPage(PointGraphics pg, PageFormat format, int pageIndex);
/* (non-Javadoc)
 * @see eve.fx.print.Printable#validatePage(eve.fx.points.PageFormat, int)
 */
public abstract boolean validatePage(PageFormat page, int pageIndex); 

private int curPage;
private Handle curHandle;

protected final void setupForPage(PointGraphics pg)
{
	if (!setupForPage(pg,getCurrentPage(),curPage))
		curHandle.stop(0);
}
//===================================================================
public final boolean print(Handle handle,PointGraphics pg,PageFormat page,PointRect areaOnPage,int pageIndex)
//===================================================================
{
	if (handle == null) handle = new Handle();
	try{
		curPage = pageIndex;
		curHandle = handle;
		setup(pg,page);
		if (!handle.shouldStop){
			doPrint(pg,areaOnPage);
			//mThread.sleep(10);
		}
	}catch(Throwable e){
		handle.fail(e);
		e.printStackTrace();
		return false;
	}finally{
		free();
	}
	return true;
}	
/**
By default this returns UNKNOWN_NUMBER_OF_PAGES.
**/
//===================================================================
public int countPages(PageFormat pf){return UNKNOWN_NUMBER_OF_PAGES;}
//===================================================================
/* (non-Javadoc)
 * @see eve.fx.print.Printable#printingComplete()
 */
public void printingComplete() {
	// TODO Auto-generated method stub
}
public PointDrawable getPage(final PageFormat pf,final int pageIndex) {
	if (!validatePage(pf,pageIndex)) return null;
	return new PointDrawable()
	{
		double xdpi = -1, ydpi = -1;
		PrintCell myCell;
		public void draw(PointGraphics pg, PointRect area) {
			if (myCell == null || pg.getXdpi() != xdpi || pg.getYdpi() != ydpi){
				xdpi = pg.getXdpi();
				ydpi = pg.getYdpi();
				curPage = pageIndex;
				curHandle = new Handle();
				setup(pg,pf);
				myCell = getCurrentCell();
			}
			myCell.draw(pg,area);
		}
		
	};
}

//##################################################################
}
//##################################################################

