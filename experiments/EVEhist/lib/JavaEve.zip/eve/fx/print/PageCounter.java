package eve.fx.print;
import eve.fx.points.PageFormat;
import eve.sys.Handle;
import eve.sys.mThread;
/**
You would only use this if you are inheriting from PrinterJobObject. It is used
to iterate through pages that are to be printed.
**/
//##################################################################
public class PageCounter{
//##################################################################

/**
This is the total number of pages in the document as reported by
Printable.countPages()
**/
public int pagesInDocument;
/**
This is the total number of pages that will be printed using the provided
PrinterOptions object.
**/
public int pagesToPrint;
/**
This is only valid after calls to moveToNextPage(). This is sent to the print() method of the Printable.
**/
public int currentPageIndex;
/**
This indicates which of the pagesToPrint is being printed.
**/
private int currentPage;

private PrintOptions po;
private Printable pr;
private PageFormat pf;
public  PageFormat currentPageFormat;
private Handle handle;

//===================================================================
public PageCounter(Handle handle, Printable printable, PageFormat pageFormat, PrintOptions options)
//===================================================================
{
	pr = printable;
	po = options;
	pf = pageFormat;
	pagesInDocument = printable.countPages(pageFormat);
	pagesToPrint = options.countPagesWillPrint(pagesInDocument);
	this.handle = handle;
	if (handle != null) mThread.nap(1*250);
}

//-------------------------------------------------------------------
private PageFormat finished()
//-------------------------------------------------------------------
{
	if (handle != null){
		handle.doing = "Finished Printing.";
		handle.setProgress(1.0f);
		handle.changed();
	}
	return null;
}
/**
Call this to move to the next page - it calls validatePage() on the printable, which
may transform the original PageFormat. When it returns null it indicates that there are no more
pages to print.
@return the PageFormat to use for this page.
**/
//===================================================================
public PageFormat moveToNextPage() throws IllegalStateException
//===================================================================
{
	if (handle != null && handle.shouldStop) return finished();
	currentPage++;
	int toGo = currentPage == 1 ? po.getFirstPage(pagesInDocument) : po.getNextPage();
	if (toGo == po.NO_MORE_PAGES) return finished();
	currentPageIndex = toGo-1;
	currentPageFormat = (PageFormat)pf.getCopy();
	if (!pr.validatePage(currentPageFormat,currentPageIndex)) return finished();
	if (handle == null) return currentPageFormat;
	if (pagesToPrint == Printable.UNKNOWN_NUMBER_OF_PAGES || pagesToPrint == 0){
		handle.doing = "Page "+currentPage+".";
		handle.setProgress(-1f);
	}else{
		handle.doing = "Page "+currentPage+" of "+pagesToPrint+".";
		handle.setProgress((float)(currentPage-1)/pagesToPrint);
	}
	handle.changed();
	return currentPageFormat;
}

//##################################################################
}
//##################################################################

