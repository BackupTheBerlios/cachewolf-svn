/*
 * Created on Jan 17, 2007
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class Paint2D {
public double[] transform;
public Color background = new Color(255,255,255);
public Color brushColor = new Color(255,255,255);
public int brushStyle = Brush.SOLID;
public Color penColor = new Color(0,0,0);
public int penStyle = Pen.SOLID;
public double penWidth = 1;
public double penHeight = 1;
public float penMiterLimit = 10;
public Color fontColor = new Color(0,0,0);
public String fontName = "Helvetica";
public int fontStyle = Font.PLAIN;
public double fontSize = 10;

public double getPenThickness()
{
	return Math.max(penHeight,penWidth);
}

public void setPenThickness(double widthAndHeight)
{
	penHeight = penWidth = widthAndHeight;
}

}
//####################################################
