package eve.fx;
/**

 * 
 * @author Michael L Brereton
 *
 */
//##################################################################
public interface ISurface{
//##################################################################

public static final int WINDOW_SURFACE = 0x1;
public static final int IMAGE_SURFACE = 0x2;
public static final int PRINTERJOB_SURFACE = 0x3;
/**
 * This returns one of the XXX_SURFACE values.
 * @return
 */
public int getSurfaceType();
/**
 * This is used internally and should not be used.
 */
public Object getNativeDrawable();
/**
 * Return a FontMetrics for the surface.
 * @param f the Font to use.
 * @return a FontMetrics for the surface.
 */
public FontMetrics getFontMetrics(Font f);
/**
 * This should always work for any surface and is the minimum functionality
 * expected. The clipXXX parameters specify a clipping area with in the surface,
 * no image data will be drawn outside this area. If you do not want a clipping
 * area, then set this to be the same as destX, destY, width, height.
 * <p>
 * Note that the image is not scaled. If width and height are smaller than the
 * actual image dimensions, then the image is clipped.
 * 
 * @param src The source image.
 * @param clipX The x co-ordinate of the clipping rectangle within the surface.
 * @param clipY The y co-ordinate of the clipping rectangle within the surface.
 * @param clipWidth The width of the clipping rectangle within the surface.
 * @param clipHeight The height of the clipping rectangle within the surface.
 * @param destX The destination x co-ordinate for the image.
 * @param destY The destination y co-ordinate for the image.
 * @param width The number of pixels horizontally to draw from the image.
 * @param height The number of pixels vertically. to draw from the image.
 */
public void    drawImage(Image src, int clipX, int clipY, int clipWidth, int clipHeight, int destX, int destY, int width, int height);
/**
 * Capture pixel data from the surface to an Image. Only call this if canCapture()
 * returns true.
 * @param dest
 * @param x
 * @param y
 * @param width
 * @param height
 * @return
 */
public boolean captureImage(Image dest, int x, int y, int width, int height);
/**
 * Move pixel data within the surface. Only call this if canMove() returns
 * true.
 * @param srcX 
 * @param srcY
 * @param srcWidth
 * @param srcHeight
 * @param destX
 * @param destY
 * @return
 */
public boolean moveImage(int srcX, int srcY, int srcWidth, int srcHeight, int destX, int destY);
/**
 * This returns true if it is possible to read pixel data from the surface
 * into an Image.
 */
public boolean canCapture();
/**
 * This returns true if it is possible to move pixel within the surface.
 */
public boolean canMove();
/**
 * Get an Image that is optimized for display on the surface.
 * @param width the width of the image. This must be greater than or equal to 1.
 * @param height the height of the image. This must be greater than or equal to 1.
 * @return an Image optimized for display on the surface.
 * @throws IllegalArgumentException if the width or height is less than 1.
 */
public Image getCompatibleImage(int width, int height) throws IllegalArgumentException;
/**
 * This returns a new Graphics for use on the surface IF it is supported.
 * Some surfaces do not support direct drawing and you must use the drawImage()
 * method instead to write to the surface.
 * @return a new Graphics for use on the surface IF it is supported, otherwise
 * an UnsupportedOperationException is thrown.
 */
public Graphics getGraphics() throws UnsupportedOperationException;
//public Graphics newGraphics();
//##################################################################
}
//##################################################################

