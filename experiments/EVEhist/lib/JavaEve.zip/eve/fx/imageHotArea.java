package eve.fx;

//##################################################################
class imageHotArea implements Area{
//##################################################################

Area area;
Drawing image,target;
Rect buff;
Rect full;
boolean checkTransparent = false;
int transparentColor = 0;
//===================================================================
public imageHotArea(Area within,Drawing image,Drawing target)
//===================================================================
{
	area = within;
	this.image = image;
	this.target = target;
	full = area.getRect(null);
	buff = new Rect().set(full);
}
//===================================================================
public imageHotArea(int transparent,Drawing image,Drawing target)
//===================================================================
{
	this(new Rect(0,0,target.location.width,target.location.height),image,target);
	transparentColor = transparent & 0xffffff;
	checkTransparent = true;
}
int [] pix;
//===================================================================
public synchronized boolean isIn(int x,int y)
//===================================================================
{
	boolean in = area.isIn(x-target.location.x,y-target.location.y);
	if (!in) return false;
	if (!checkTransparent || image.image == null) return true;
	if (pix == null) pix = new int[1];
	image.getPixels(pix,0,x-target.location.x,y-target.location.y,1,1,0);
	//ewe.sys.Vm.debug(""+pix[0]+", "+transparentColor);
	return ((pix[0] & 0xffffff) != transparentColor);
}
//===================================================================
public boolean intersects(Area other)
//===================================================================
{
	buff.x = full.x+target.location.x;
	buff.y = full.y+target.location.y;
	return buff.intersects(other);
}
public Rect getRect(Rect dest)
{
	dest = Rect.unNull(dest).set(full);
	dest.x += target.location.x;
	dest.y += target.location.y;
	return dest;
}
//##################################################################
}
//##################################################################

