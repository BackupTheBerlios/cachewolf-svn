package eve.fx;

import java.util.Enumeration;
import java.util.Hashtable;
/**
* An ImageCache is used to fetch and keep images so that Images do not have to
* be re-decoded each time they are accessed.
**/
//##################################################################
public class ImageCache extends Hashtable{
//##################################################################

/**
* This is a global ImageCache that you can use. The system also uses it.
**/
public static ImageCache cache = new ImageCache();

/**
 * Put an image into the cache. This simply calls the Hashtable.put() method.
 * @param imageName the name of the image.
 * @param image the image.
 */
public void putIntoCache(String imageName, IImage image)
{
	put(imageName,image);
}
/**
 * Load the image into cache by creating a new Picture.
 * @param imageName the name of the image.
 * @param replaceExisting if this is true then the loaded image replaces any
 * previous one with the same name.
 * @return true if the image was already there, false if it was not there before
 * and could not be loaded. If replaceExisting is true, and an image of that name
 * exists, but the image could not be loaded, the old image is left and this returns
 * false.
 */
public boolean loadIntoCache(String imageName, boolean replaceExisting)
{
	Object old = get(imageName);
	if (!(old instanceof IImage)) old = null;
	if (old != null && !replaceExisting) return true;
	try{
		Picture save = new Picture(imageName);
		put(imageName,save);
		return true;
	}catch(Exception e){
		return false;
	}
}
/**
 * Get an image from the cache only. If it is not in the cache return the defaultImage
 * and do not attempt to load it.
 * @param imageName the name of the image.
 * @param defaultImage a defaultImage to return if it is not in the cache. This may be
 * null.
 * @return the IImage found or the defaultImage if not found.
 */
public IImage getCached(String imageName, IImage defaultImage)
{
	Object got = get(imageName);
	if (!(got instanceof IImage)) return defaultImage;
	return (IImage)got;
}
/**
 * Try to load an image but do not throw an exception on error. Instead, if the
 * image could not be found and could not be loaded then return the defaultImage.
 * @param imageName the name of the image.
 * @param defaultImage the defaultImage to return if the image could not be found or loaded.
 * @return the found image or the defaultImage.
 */
public IImage tryImage(String imageName, IImage defaultImage)
{
	try{
		IImage got = getImage(imageName);
		if (got == null) return defaultImage;
		return got;
	}catch(Exception e){
		return defaultImage;
	}
}
/**
 * Get an Image with an optional mask image or transparent color. If the image name
 * is not in the cache, it will be loaded as a new Picture() - so if this fails, an
 * Exception is thrown.
 * @param imageName The full resource name of the image.
 * @param maskOrColor Either a resource name of a mask image or a Color object.
 * @return The decoded Image - either newly decoded or retrieved from the Cache.
 * @exception IllegalArgumentException If the named image does not exist or is not formatted correctly.
 * @deprecated
 */
//===================================================================
public IImage getImage(String imageName,Object maskOrColor) throws IllegalArgumentException
//===================================================================
{
	Object got = get(imageName);
	if (got instanceof IImage) return (IImage)got;
	IImage im = new Picture(imageName,maskOrColor,0);
	put(imageName,im);
	return im;
}
/**
 * Get an Image.
 * @param imageName The full resource name of the image.
 * @return The decoded Image - either newly decoded or retrieved from the Cache.
 * @exception IllegalArgumentException If the named image does not exist or is not formatted correctly.
 */
//===================================================================
public IImage getImage(String imageName) throws IllegalArgumentException
//===================================================================
{
	return this.getImage(imageName,null);
}
/**
 * Free all images and clear the cache.
 */
//===================================================================
public synchronized void free()
//===================================================================
{
	Enumeration e = elements();
	while(e.hasMoreElements()){
		Object obj = e.nextElement();
		if (obj instanceof IImage)
			((IImage)obj).free();
	}
	clear();
}
//##################################################################
}
//##################################################################

