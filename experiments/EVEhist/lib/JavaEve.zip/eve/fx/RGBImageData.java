package eve.fx;

import eve.sys.ImageData;

/**
This class can be used to wrap up an ImageData of any type to act
as an ImageData of type TYPE_ARGB or TYPE_RGB and which uses int[] scan lines. 
It also provides an IImage interface for the ImageData.<p>
**/
//##################################################################
public class RGBImageData extends ImageAdapter implements  IImage{
//##################################################################
//protected IImage image;
//protected ImageData imageData;
//protected boolean deferToImageData;
//protected boolean usesAlpha;
//protected boolean canWrite;
//protected int width;
//protected int height;
private Object buffer;
private int[] line;
//private Image myImage;
/**
Return true if the specified ImageData acts in the same way that an RGBImageData would
act. That is, its type is TYPE_RGB or TYPE_ARGB, and it uses scan lines of type int[], and
its scan line length is equal to its width.
**/
//===================================================================
public static boolean actsAsRGBImageData(ImageData image)
//===================================================================
{
	int ty = image.getImageType();
	if (
		(ty == TYPE_ARGB || ty == TYPE_RGB) &&
		(image.getImageScanLineType() == SCAN_LINE_INT_ARRAY) &&
		(image.getImageScanLineLength() == image.getImageWidth())
		) return true;
	return false;
}
/**
If the specified Image implements RGBImageData in exactly the same way as
an RGBImageData does, then return the Image itself. Otherwise return the image
wrapped in an RGBImageData object - using the provided wrapper object if it is
not null. 
**/
//===================================================================
public static ImageData toImageData(ImageData image, RGBImageData wrapper)
//===================================================================
{
	if (actsAsRGBImageData(image)) return image;
	if (wrapper == null) wrapper = new RGBImageData();
	wrapper.set(image);
	return wrapper;
}
/**
If you use this constructor, make sure you call the set() method before
using any of the other methods.
**/
//===================================================================
public RGBImageData()
//===================================================================
{
	
}
//===================================================================
public RGBImageData(ImageData image)
//===================================================================
{
	super(image);
}
/*
//===================================================================
public RGBImageData(Object image,boolean useImageDataOverIImage)
//===================================================================
{
	set(image,useImageDataOverIImage);
}
public void set(Object newImage)
{
	set(newImage,false);
}
*/
/**
This can be used to set or change the image the RGBImageData is using.
The type of newImage can be IImage or ImageData.
**/
/*
//===================================================================
public void set(Object newImage,boolean useImageDataOverIImage)
//===================================================================
{
	free();
	imageData = null;
	image = null;
	deferToImageData = false;
	//
	if (!useImageDataOverIImage || !(newImage instanceof ImageData)){
		if (newImage instanceof IImage){
			if (!(newImage instanceof ImageData) || !actsAsRGBImageData((ImageData)newImage)){
				image = (IImage)newImage;
				width = image.getWidth();
				height = image.getHeight();
				usesAlpha = image.usesAlpha();
				canWrite = (image instanceof Image);
				return;
			}
		}
	}
	//
	if (newImage instanceof ImageData){
		imageData = (ImageData)newImage;
		width = imageData.getImageWidth();
		height = imageData.getImageHeight();
		usesAlpha = imageData.getImageType() == TYPE_ARGB;
		canWrite = imageData.isWritableImage();
		deferToImageData = actsAsRGBImageData(imageData);
		return;
	}
	throw new IllegalArgumentException();
}
*/
/**
This returns either TYPE_ARGB or TYPE_RGB.
**/
//===================================================================
public int getImageType()
//===================================================================
{
	return imageData.getImageType() == TYPE_ARGB ? TYPE_ARGB : TYPE_RGB;
}
/**
This always returns SCAN_LINE_INT_ARRAY;
**/
//===================================================================
public int getImageScanLineType()
//===================================================================
{
	return SCAN_LINE_INT_ARRAY;
}
/**
This always returns the width of the original image.
**/
//===================================================================
public int getImageScanLineLength()
//===================================================================
{
	return width;
}
/**
Get the image scan lines, always as ARGB integer values.
**/
//===================================================================
public void getImageScanLines(int startLine, int numLines, Object destArray, int offset, int destScanLineLength)
//===================================================================
{
	if (!isReadableImage()) throw new IllegalStateException();
	if (!(destArray instanceof int[])) throw new IllegalArgumentException();
	int gotLines = numLines;
	try{
		buffer = ImageTool.getScanLineBuffer(imageData,numLines,buffer);
	}catch(OutOfMemoryError om){
		gotLines = 1;
		buffer = ImageTool.getScanLineBuffer(imageData,1,buffer);
	}
	int idsll = imageData.getImageScanLineLength();
	while(numLines != 0){
		int get = gotLines;
		if (get > numLines) get = numLines;
		imageData.getImageScanLines(startLine,get,buffer,0,idsll);
		ImageTool.toARGB(imageData,buffer,0,(int[])destArray,offset,destScanLineLength,get);
		offset += get*destScanLineLength;
		numLines -= get;
	}
}
/**
Set the image scan lines, always as ARGB integer values.
**/
//===================================================================
public void setImageScanLines(int startLine, int numLines, Object sourceArray, int offset, int sourceScanLineLength)
throws IllegalStateException
//===================================================================
{
	if (!isWriteableImage()) throw new IllegalStateException();
	int gotLines = numLines;
	try{
		buffer = ImageTool.getScanLineBuffer(imageData,numLines,buffer);
	}catch(OutOfMemoryError om){
		gotLines = 1;
		buffer = ImageTool.getScanLineBuffer(imageData,1,buffer);
	}
	int idsll = imageData.getImageScanLineLength();
	int[] ct = imageData.getImageColorTable();
	while(numLines != 0){
		int get = gotLines;
		if (get > numLines) get = numLines;
		ImageTool.fromARGB((int[])sourceArray,offset,sourceScanLineLength,imageData,buffer,0,get);
		imageData.setImageScanLines(startLine,get,buffer,0,idsll);
		offset += get*sourceScanLineLength;
		numLines -= get;
	}
}
/**
Open the source to retrieve or optionally set scan lines.
**/
/*
//===================================================================
public boolean openImageData(boolean forWriting)
//===================================================================
{
	if (forWriting && !canWrite) throw new IllegalArgumentException();
	return true;
}
*/
/**
Close the source when you have finished retrieving scan lines.
**/
/*
//===================================================================
public boolean closeImageData(){return true;}
//===================================================================
*/
/**
This always returns null.
**/
//===================================================================
public int[] getImageColorTable()
//===================================================================
{
	return null;
}

/**
 * This only frees this Object's local data - it does not free the Image the RGBImage
 * wraps. 
 */
public void free() 
{
	buffer = null;
	super.free();
}
/*
//===================================================================
public Image toImage()
//===================================================================
{
	if (image instanceof Image) return (Image)image;
	if (imageData instanceof Image) return (Image)imageData;
	if (myImage != null) return myImage;
	myImage = new Image(width,height,usesAlpha ? ImageData.TYPE_ARGB : ImageData.TYPE_RGB);
	line = (int[])ImageTool.getScanLineBuffer(this,1,line);
	for (int i = 0; i<height; i++){
		getImageScanLines(i,1,line,0,width);
		myImage.setImageScanLines(i,1,line,0,width);
	}
	return myImage;
}
*/

//##################################################################
}
//##################################################################

