package eve.fx;
/**
An ImageRefresher is used by an animated image (AniImage) to display it
on the screen. The refresh() method is called by the AniImage if it determines
that it has been changed somehow.<p>
How that refreshing is actually done is up to the refresher.<p>
*/
//##################################################################
public interface ImageRefresher {
//##################################################################

/** An option that tells the ImageRefresher to keep the image on screen, possibly
 * scrolling whatever control is displaying the image so that the image stays on
 * the screen.
 */

public static final int KEEP_VISIBLE = Drawing.KeepOnScreen;

public void refresh(IImage image, int options);

//##################################################################
}
//##################################################################

