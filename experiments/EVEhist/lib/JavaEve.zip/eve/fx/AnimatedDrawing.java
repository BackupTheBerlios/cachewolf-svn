/*
 * Created on Oct 30, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx;

import eve.sys.ImageData;
import eve.sys.WeakRef;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class AnimatedDrawing extends Drawing implements OnScreenImage{

	/**
	 * @param imageName
	 * @param maskImageName
	 */
	public AnimatedDrawing(String imageName, Object maskObject) {
		super(imageName, maskObject);
	}
	/**
	 * @param image
	 * @param transparent
	 */
	public AnimatedDrawing(ImageData image, Object maskObject) {
		super(image, maskObject);
	}

	/**
	 * 
	 */
	public AnimatedDrawing() {
		super();
	}
	private WeakRef refresher;

	protected void startAnimate(){}
	protected void stopAnimate(){}
	/**
	 * This is called when a new ImageRefresher has been assigned as the 
	 * refresher for this AnimatedDrawing - even if the refresher is null.
	 * This can be used to start/stop animation sequences. By default if r is null
	 * then stopAnimate() will be called otherwise startAnimate() will be called.
	 * @param r the new Refresher - which may be null if the refresher is set to null.
	 */
	protected void newRefresher(ImageRefresher r)
	{
		if (r == null) stopAnimate();
		else startAnimate();
	}
//	===================================================================
	public void setRefresher(ImageRefresher refresher)
//	===================================================================
	{
		this.refresher = WeakRef.set(this.refresher, refresher);
		newRefresher(refresher);
	}
//	===================================================================
	public boolean changeRefresher(ImageRefresher newRefresher, ImageRefresher oldRefresher)
//	===================================================================
	{
		if (getRefresher() != oldRefresher) return false;
		setRefresher(newRefresher);
		return true;
	}
//	===================================================================
	public ImageRefresher getRefresher()
//	===================================================================
	{
		return (ImageRefresher)WeakRef.get(refresher);
	}
//	-------------------------------------------------------------------
	protected void refresh(ImageRefresher on)
//	-------------------------------------------------------------------
	{
		int op = 0;
		if ((properties & KeepOnScreen) != 0)
			op |= on.KEEP_VISIBLE;
		on.refresh(this,op);
	}
//	==================================================================
	public void refresh()
//	==================================================================
	{
		ImageRefresher rf = getRefresher();
		if (rf != null) refresh(rf);
	}
}

//####################################################
