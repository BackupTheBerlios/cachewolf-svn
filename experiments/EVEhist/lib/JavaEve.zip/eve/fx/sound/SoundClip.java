/*
 * Created on Jan 14, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.sound;

import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;

import eve.io.ByteArrayRandomStream;
import eve.io.RandomStream;
import eve.io.StreamUtils;
import eve.sys.Handle;
import eve.sys.Task;
import eve.util.ByteArray;
import eve.util.FormattedDataSource;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class SoundClip {

	private InputStream myAudio;
	private long startOfRawData = -1;
	private static Hashtable openWaveOutputs;
	private WaveOutput myOutput;
	
	/**
	 * The format for this SoundClip.
	 */
	public WaveFormat format;
	public int leftVolumePercent = 100;
	public int rightVolumePercent = 100;
	/**
	 * This automatically makes the SoundClip loopable.
	 * @throws IOException if there was an IO error reading the bytes.
	 */
	public void readIntoMemory() throws IOException
	{
		if (!(myAudio instanceof ByteArrayRandomStream)){
			ByteArray ba = StreamUtils.readAllBytes(null,myAudio,null);
			myAudio.close();
			startOfRawData = 0;
			myAudio = new ByteArrayRandomStream(ba,"r");
		}
	}
	private void makeLoopable() throws IOException
	{
		if (!(myAudio instanceof RandomStream)){
			readIntoMemory();
			return;
		}
		if (startOfRawData == -1)
			startOfRawData = ((RandomStream)myAudio).getPosition();
	}
	/**
	 * Return the number of frames in the SoundClip. Divide that
	 * by format.samplesPerSecond to get the length of the clip in
	 * seconds.
	 * @return the number of frames in the SoundClip.
	 */
	public long countFrames() throws IOException
	{
		return ((((RandomStream)myAudio).getLength())-startOfRawData)/format.frameSize();
	}
	/**
	 * This is a Hashtable of WaveOutput objects used for playing
	 * clips via the play() and play(boolean loop) method. Each entry
	 * is a WaveOutput with the key for each entry being a WaveFormat.
	 * You can reserve WaveOutputs ahead of time and place them in this
	 * Hastable. 
	 */
	public synchronized static Hashtable getOpenWaveOutputs()
	{
		if (openWaveOutputs == null) openWaveOutputs = new Hashtable();
		return openWaveOutputs;
	}
	/**
	 * Return the WaveOutput being used or will be used by this SoundClip.
	 * @return the WaveOutput being used or will be used by this SoundClip.
	 */
	public WaveOutput getWaveOutput() throws IOException
	{
		if (myOutput != null) return myOutput;
		return getWaveOutputFor(format);
	}
	public InputStream getRawBytes()
	{
		return myAudio;
	}
	public long resetToFrame(long frame) throws IOException
	{
		if (frame < 0) frame = 0;
		((RandomStream)(myAudio)).setPosition(frame*format.frameSize()+startOfRawData);
		return ((((RandomStream)myAudio).getPosition()-startOfRawData)/format.frameSize());
	}
	
	public void resetToStart() throws IOException
	{
		resetToFrame(0);
	}
	public Handle play(final WaveOutput output,final boolean immediate,final boolean loop)
	{
		return new Task(){
			protected void doRun(){
				int totalWrite = 0;
				try{
					WaveOutput out = output;
					if (out == null) out = getWaveOutput();
					out.reset();
					out.setVolume((0xffff*leftVolumePercent)/100,(0xffff*rightVolumePercent)/100);
					byte[] buff = new byte[format.getBytesPerSecond()/10];
					int len = buff.length;
					int inBuffer = 0;
					long totalFrames = countFrames();
					boolean noMoreData = false;
					while(!shouldStop){
						int got = 0;
						setProgress(loop ? -1 : (float)out.getFramePosition()/totalFrames);
						if (!noMoreData && inBuffer < len) {
							got = myAudio.read(buff,inBuffer,len-inBuffer);
							if (got > 0) inBuffer += got;
						}
						if (shouldStop) break;
						if (got < 0){
							noMoreData = true;
							got = 0;
						}
						if (noMoreData){
							if (loop){
								resetToStart();
								noMoreData = false;
							}else if (inBuffer == 0){
								out.sync();
								while(!out.drained()){
									setProgress(loop ? -1 : (float)out.getFramePosition()/totalFrames);
									sleep(10);
								}
								setProgress(loop ? -1 : (float)out.getFramePosition()/totalFrames);
								set(Success);
								return;
							}
						}
						//
						if (inBuffer == 0) continue;
						//
						int wrote = out.writeBlock(buff,0,inBuffer,false);
						if (wrote == 0 && got == 0){
							sleep(10);
							continue;
						}
						if (wrote != 0 && wrote != inBuffer)
							System.arraycopy(buff,wrote,buff,0,inBuffer-wrote);
						totalWrite += wrote;
						inBuffer -= wrote;
					}
					out.reset();
					set(Aborted);
					return;
				}catch(Exception e){
					//e.printStackTrace();
					fail(e);
				}finally{
					try{resetToStart();}catch(Exception e){}
				}
			}
		}.start();
	}
	public Handle play()
	{
		return play(null,false,false);
	}
	public Handle play(boolean immediately, boolean loop)
	{
		return play(null,immediately,loop);
		/*
		int opts = AudioChannel.SET_STREAM_PLAY_IMMEDIATELY;
		if (loop) opts |= AudioChannel.SET_STREAM_LOOP;
		if (output != null) output.setStream(myAudio,opts);
		*/
	}
	/**
	 * Get the WaveOutput used by the SoundClip class for
	 * output of a particular wave format.
	 * @param format the format for output.
	 * @return the WaveOutput to be used for output. If none can
	 * be created this throws an exception.
	 * @throws IOException if no WaveOutput could be created for
	 * the format.
	 */
	public static WaveOutput getWaveOutputFor(WaveFormat format)
	throws IOException
	{
		Hashtable ht = getOpenWaveOutputs();
		synchronized(ht){
			WaveOutput wo = (WaveOutput)ht.get(format);
			if  (wo != null) return wo;
			wo = new WaveOutput(format);
			ht.put(format,wo);
			return wo;
		}
	}
	/**
	 * Make sure a WaveOutput for this format (to be shared by other SoundClips)
	 * is reserved and ready for use.
	 * @throws IOException if a shared one was not available and a new shared
	 * one could not be created.
	 */
	public void reserveSharedOutput() throws IOException
	{
		getWaveOutputFor(format);
	}
	/**
	 * Create, save and return a new WaveOutput for use by this SoundClip only.
	 * @return a new WaveOutput for use by this SoundClip only.
	 * @throws IOException if one could not be created.
	 */
	public WaveOutput reserveExclusiveOutput() throws IOException
	{
		return myOutput = new WaveOutput(format);
	}
	/**
	 * Set the WaveOutput for use by this SoundClip only.
	 * @param output the WaveOutput for exclusive use by this SoundClip
	 */
	public void setWaveOutput(WaveOutput output)
	{
		myOutput = output;
	}
	
	public SoundClip(String clipName) throws IOException
	{
		this(new FormattedDataSource().set(clipName));
	}
	public SoundClip(FormattedDataSource source) throws IOException
	{
		this.myAudio = source.getInputStream();
		this.format = new WaveFormat();
		format.readFrom(myAudio);
		makeLoopable();
	}
	public SoundClip(WaveFormat format, InputStream rawBytes) throws IOException
	{
		this.format = format;
		this.myAudio = rawBytes;
		makeLoopable();
	}
	public SoundClip(WaveFormat format, byte[] rawWaveData, int offset, int length)
	{
		this.format = format;
		this.myAudio = new ByteArrayRandomStream(rawWaveData,offset,length,"r");
		startOfRawData = 0;
	}

	public void free()
	{
		try{
			myAudio.close();
		}catch(IOException e){}
		try{
			if (myOutput != null)
				myOutput.close();
		}catch(IOException e){}
	}
	protected void finalize()
	{
		free();
	}
}

//####################################################
