/*
 * Created on May 18, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.sound;

import java.io.IOException;
import java.io.InputStream;

import eve.io.StreamUtils;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class WaveFormat{
	/** This should always be 1 for standard PCM format. **/
	public int format = 1; 
	public int numChannels = 2;
	public int samplesPerSecond = 22050;
	private int averageBytesPerSecond = 22050*2;
	public int bitsPerSample = 16;
	public int blockAlignment = 4;
	public boolean signed = true;
	public boolean bigEndian = false;
	/** 
	 * This is the size in frames of the buffer kept by the Eve VM before being
	 * sent to or after being read from the underlying device. Data
	 * is written and read from the underlying device in blocks of
	 * size equal to periodSize.
	 */
	public int bufferSizeInFrames;
	/**
	 * This is the size in frames of the block size used to write
	 * bytes to the underlying device (known as the period). This affects
	 * the latency of the device. 
	 */
	public int periodSizeInFrames;
	/**
	 * Use this to create a WaveFormat that will always be compatible with
	 * .WAV files and with the underlying hardware.
	 * @param stereo - true for stereo audio, false for mono.
	 * @param samplesPerSecond - sample rate ranging from 44100 for CD quality to 8000 for voice.
	 * @param sixteeenBits - true for 16 bit sound, false for 8 bit. 
	 * @return this WaveFormat
	 */
	public WaveFormat setForPCM(boolean stereo, int samplesPerSecond, boolean sixteenBits)
	{
		format = 1;
		numChannels = stereo ? 2 : 1;
		this.samplesPerSecond = samplesPerSecond;
		bitsPerSample = sixteenBits ? 16 : 8;
		signed = sixteenBits ? true : false;
		bigEndian = false;
		blockAlignment = numChannels*(bitsPerSample/8);
		averageBytesPerSecond = samplesPerSecond*blockAlignment;
		return this;
	}
	public boolean equals(Object other)
	{
		if (!(other instanceof WaveFormat)) return false;
		WaveFormat wf = (WaveFormat)other;
		return 
		wf.format == format && 
		wf.numChannels == numChannels &&
		wf.samplesPerSecond == samplesPerSecond &&
		wf.averageBytesPerSecond == averageBytesPerSecond &&
		wf.bitsPerSample == bitsPerSample &&
		wf.blockAlignment == blockAlignment &&
		wf.bigEndian == bigEndian &&
		wf.signed == signed
		;
	}
	public int hashCode()
	{
		return format*numChannels*samplesPerSecond*averageBytesPerSecond*bitsPerSample*blockAlignment;
	}
	private static final int OFFSET_FORMATTAG = 0; 
	private static final int OFFSET_CHANNELS = 2;
	private static final int OFFSET_SAMPLESPERSEC = 4;
	private static final int OFFSET_AVGBYTESPERSEC = 8; 
	private static final int OFFSET_BLOCKALIGN = 12; 
	private static final int OFFSET_BITSPERSAMPLE = 14;
	
	private static final int
//	============================================================
		readInt(byte [] source,int offset,int numBytes)// throws IOException
//	============================================================
	{
		int ret = 0;
		for (int i = offset+numBytes; i > offset;) {
			i--;
			ret = (ret<<8) & 0xffffff00;
			ret |= ((int)source[i])&0xff;
		}
		return ret;
	}
	private int readInt(InputStream in, byte [] buffer, int numBytes) throws IOException
	{
		StreamUtils.readFully(in,buffer,0,numBytes);
		return readInt(buffer,0,numBytes);
	}
	private boolean isTag(byte[] buffer,String tag)
	{
		for (int i = 0; i<4; i++)
			if (buffer[i] != ((byte)tag.charAt(i))) return false;
		return true;
	}
	private void nextTag(InputStream in, byte[] buffer) throws IOException
	{
		StreamUtils.readFully(in,buffer,0,4);
	}
	/**
	 * This decodes the WaveFormat from the input stream and leaves the 
	 * stream at the start of the raw Wave data.
	 * @param in the input stream.
	 * @return the number of frames in the stream.
	 * @throws IOException on error.
	 * @throws IllegalArgumentException if the stream is NOT wave format.
	 */
	public int readFrom(InputStream in) throws IOException, IllegalArgumentException
	{
		byte[] buffer = new byte[4];
		nextTag(in,buffer);
		if (!isTag(buffer,"RIFF")) throw new IllegalArgumentException();
		int total = readInt(in,buffer,4);
		nextTag(in,buffer);
		if (!isTag(buffer,"WAVE")) throw new IllegalArgumentException();
		while(true){
			nextTag(in,buffer);
			if (isTag(buffer,"fmt ")) break;
			if (isTag(buffer,"data")) throw new IllegalArgumentException();
			int len = readInt(in,buffer,4);
			in.skip(len);
		}
		int len = readInt(in,buffer,4);
		byte[] dest = new byte[len];
		StreamUtils.readFully(in, dest);
		format = readInt(dest,OFFSET_FORMATTAG,2);
		numChannels = readInt(dest,OFFSET_CHANNELS,2);
		samplesPerSecond = readInt(dest,OFFSET_SAMPLESPERSEC,4);
		averageBytesPerSecond = readInt(dest,OFFSET_AVGBYTESPERSEC,4);
		bitsPerSample = readInt(dest,OFFSET_BITSPERSAMPLE,2);
		blockAlignment = readInt(dest,OFFSET_BLOCKALIGN,2);
		bigEndian = false;
		signed = bitsPerSample > 8;
		while(true){
			nextTag(in,buffer);
			if (isTag(buffer,"data")) break;
		}
		len = readInt(in,buffer,4);
		int frames = len/(((bitsPerSample+7)/8)*numChannels);
		return frames;
	}
	public String toString()
	{
		return format+", "+numChannels+", "+samplesPerSecond+", "+averageBytesPerSecond+", "+bitsPerSample+", "+blockAlignment;
	}
	public int frameSize()
	{
		return (((bitsPerSample+7)/8)*numChannels);
	}
	/**
	 * Return the number of bytes used for the specified number of frames.
	 */
	public long countBytes(long numFrames)
	{
		return numFrames*(((bitsPerSample+7)/8)*numChannels);
	}
	/**
	 * Return the number of microseconds that elapse for the specified number of frames.
	 */
	public long countMicroseconds(long numFrames)
	{
		return (numFrames*1000000L)/samplesPerSecond;
	}
	/**
	 * Return the number of frames covered by the specified number of bytes.
	 */
	public long countFramesForBytes(long numBytes)
	{
		return numBytes/(((bitsPerSample+7)/8)*numChannels);
	}
	/**
	 * Return the number of frames covered by the specified number of microseconds.
	 */
	public long countFramesForMicroseconds(long microseconds)
	{
		return (microseconds*samplesPerSecond)/1000000L;
	}
	public int getBytesPerSecond()
	{
		return (((bitsPerSample+7)/8)*numChannels)*samplesPerSecond;
	}
}
//####################################################
