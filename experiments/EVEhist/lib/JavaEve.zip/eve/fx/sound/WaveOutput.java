/*
 * Created on May 31, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.fx.sound;

import java.io.IOException;
import java.io.OutputStream;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Control;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

import eve.sys.Vm;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class WaveOutput{
	SourceDataLine sdl;
	DataLine.Info info;
	AudioFormat af;
	int frameSize;
	private boolean closed = false;
	
	private void makeLine() throws LineUnavailableException
	{
		sdl = (SourceDataLine)AudioSystem.getLine(info);
		sdl.open(af);
		sdl.start();
	}
	/**
	 * Create a new WaveOutput to output the specified wave format with the
	 * specified stream parameters.
	 * @param format the format of the Wave output.
	 * @param pars optional parameters for the WaveOutput stream.
	 * @throws IOException if it could not be created.
	 */
	public WaveOutput(final WaveFormat format) throws IOException
	{
		try{
			if (format == null) throw new NullPointerException();
			af = new AudioFormat(format.samplesPerSecond,format.bitsPerSample,format.numChannels,format.signed,format.bigEndian);
			info = new DataLine.Info(SourceDataLine.class,af);
			frameSize = format.frameSize();
			makeLine();
		}catch(LineUnavailableException le){
        	throw (IOException)Vm.setCause(new IOException(),le);
		}
	}
	public synchronized void reset() throws IOException
	{
		sdl.stop();
		sdl.flush();
		// If we don't open a new line the frame position is incorrect.
		sdl.close();
		try{
			makeLine();
		}catch(LineUnavailableException e){
			throw (IOException)Vm.setCause(new IOException("Line Unavailable"),e);
		}
	}
	public void pause() throws IOException
	{
		sdl.stop();
	}
	public void resume() throws IOException
	{
		sdl.start();
	}
	public void setPitch(int pitch) throws IOException
	{
		
	}
	public void setPlaybackRate(int rate) throws IOException
	{
		
	}
	public long getFramePosition() throws IOException
	{
		return sdl.getFramePosition();
	}
	public long getMicrosecondPosition() throws IOException
	{
		return sdl.getMicrosecondPosition();
	}
	public synchronized void close() throws IOException
	{
		sdl.close();
		closed = true;
	}
		/* (non-Javadoc)
	 * @see eve.fx.sound.AudioOutput#writeBlock(byte[], int, int)
	 */
	public int writeBlock(byte[] data, int offset, int length, boolean isLastData) throws IOException {
		if (length < frameSize && isLastData) return length;
		int canSend = available();
		if (canSend <= 0) return 0;
		if (canSend > length) canSend = length;
		canSend = (canSend/frameSize)*frameSize;
		if (canSend == 0) return 0;
		int did = sdl.write(data,offset,canSend);
		synchronized(this){
			amDrained = false;
			notifyAll();
		}
		return did;
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioOutput#getFrameSize()
	 */
	public int getFrameSize() throws IOException {
		return sdl.getFormat().getFrameSize();
	}
	public int available() throws IOException {
		if (!sdl.isOpen()) return -1;
		return sdl.available();
	}
	Thread draining;
	boolean amDrained;
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioInput#drained()
	 */
	public synchronized boolean drained() throws IOException {
		if (draining == null){
			amDrained = false;
			draining = new Thread(){
				public void run(){
					Object sy = WaveOutput.this;
					while(true){
						synchronized(sy){
							while(amDrained && !closed){
								try{
									sy.wait();
								}catch(Exception e){}
							}
							if (closed){
								amDrained = true;
								return;
							}
						}
						sdl.drain();
						synchronized(sy){
							amDrained = true;
						}
					}
				}
			};
			draining.start();
			return false;
		}else{
			return amDrained;
		}
	}
	
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioOutput#drain()
	 */
	public void drain() throws IOException {
		sdl.drain();
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioOutput#sync()
	 */
	public void sync() throws IOException {
		//Do nothing in Java.
	}
	private Control getControl(Control.Type ct)
	{
		try{
			return sdl.getControl(ct);
		}catch(Throwable t){
			return null;
		}
	}
	private FloatControl getVolumeControl()
	{
		FloatControl c = (FloatControl)getControl(FloatControl.Type.VOLUME);
		if (c == null) c = (FloatControl)getControl(FloatControl.Type.MASTER_GAIN);
		return c;
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioOutput#getVolume()
	 */
	public int getVolume() throws IOException 
	{
		FloatControl c = getVolumeControl();
		if (c == null) return 0;
		float min = c.getMinimum(), max = c.getMaximum();
		float range = max-min;
		float val = c.getValue();
		int tv = 0;
		if (val >= max) tv = 0xffff;
		else if (val > min) tv = (int)(((val-min)*0xffff)/range);
		return tv | (tv << 16);
	}
	public void setVolume(int left, int right) throws IOException
	{
		FloatControl c = getVolumeControl();
		if (c == null) return;
		float min = c.getMinimum(), max = c.getMaximum();
		int toUse = left & 0xffff;
		if (left <= 0) c.setValue(min);
		else if (left >= 0xffff) c.setValue(max);
		else{
			float range = max-min;
			float inc = c.getPrecision();
			int num = (int)(((range/inc)*toUse)/0xffff);
			c.setValue(num*inc+min);
		}
	}
}

//####################################################
