/*
 * Created on Jun 16, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package eve.fx.sound;

import java.io.IOException;
import java.io.InputStream;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Control;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;

import eve.sys.Vm;

/**
 * @author Mike
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class WaveInput{

	TargetDataLine sdl;
	DataLine.Info info;
	AudioFormat af;
	private void makeLine() throws LineUnavailableException
	{
		sdl = (TargetDataLine)AudioSystem.getLine(info);
		sdl.open(af);
	}
	/**
	 * Create a new WaveOutput to output the specified wave format with the
	 * specified stream parameters.
	 * @param format the format of the Wave output.
	 * @throws IOException if it could not be created.
	 */
	public WaveInput(final WaveFormat format) throws IOException
	{
		try{
			if (format == null) throw new NullPointerException();
			af = new AudioFormat(format.samplesPerSecond,format.bitsPerSample,format.numChannels,format.signed,format.bigEndian);
			info = new DataLine.Info(TargetDataLine.class,af);
			makeLine();
		}catch(LineUnavailableException le){
        	throw (IOException)Vm.setCause(new IOException(),le);
		}
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioInput#readBlock(byte[], int, int)
	 */
	public int readBlock(byte[] dest, int offset, int length) throws IOException {
		int canSend = available();
		if (canSend <= 0) return 0;
		if (canSend > length) canSend = length;
		int did = sdl.read(dest,offset,canSend);
		return did;
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioOutput#getFrameSize()
	 */
	public int getFrameSize() throws IOException {
		return sdl.getFormat().getFrameSize();
	}
	public int available() throws IOException {
		if (!sdl.isOpen()) return -1;
		return sdl.available();
	}
	Thread draining;
	boolean amDrained;
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioInput#drained()
	 */
	public synchronized boolean drained() throws IOException {
		if (draining == null){
			amDrained = false;
			draining = new Thread(){
				public void run(){
					sdl.drain();
					synchronized(WaveInput.this){
						if (draining == this)
							amDrained = true;
					}
				}
			};
			draining.start();
			return false;
		}else{
			if (amDrained){
				draining = null;
				return true;
			}
			return false;
		}
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioInput#reset()
	 */
	public synchronized void reset() throws IOException
	{
		sdl.stop();
		sdl.flush();
		// If we don't open a new line the frame position is incorrect.
		sdl.close();
		try{
			makeLine();
		}catch(LineUnavailableException e){
			throw (IOException)Vm.setCause(new IOException("Line Unavailable"),e);
		}
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioInput#pause()
	 */
	public void pause() throws IOException {
		sdl.stop();
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioInput#resume()
	 */
	public void resume() throws IOException {
		sdl.start();
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioInput#setPitch(int)
	 */
	public void setPitch(int pitch) throws IOException {
		// TODO Auto-generated method stub
		
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioInput#setPlaybackRate(int)
	 */
	public void setPlaybackRate(int rate) throws IOException {
		// TODO Auto-generated method stub
		
	}
	public long getFramePosition() throws IOException
	{
		return sdl.getFramePosition();
	}
	public long getMicrosecondPosition() throws IOException
	{
		return sdl.getMicrosecondPosition();
	}
	public synchronized void close() throws IOException
	{
		sdl.close();
	}
	private Control getControl(Control.Type ct)
	{
		try{
			return sdl.getControl(ct);
		}catch(Throwable t){
			return null;
		}
	}
	private FloatControl getVolumeControl()
	{
		FloatControl c = (FloatControl)getControl(FloatControl.Type.VOLUME);
		if (c == null) c = (FloatControl)getControl(FloatControl.Type.MASTER_GAIN);
		return c;
	}
	/* (non-Javadoc)
	 * @see eve.fx.sound.AudioOutput#getVolume()
	 */
	public int getVolume() throws IOException 
	{
		FloatControl c = getVolumeControl();
		if (c == null) return 0;
		float min = c.getMinimum(), max = c.getMaximum();
		float range = max-min;
		float val = c.getValue();
		int tv = 0;
		if (val >= max) tv = 0xffff;
		else if (val > min) tv = (int)(((val-min)*0xffff)/range);
		return tv | (tv << 16);
	}
	public void setVolume(int left, int right) throws IOException
	{
		FloatControl c = getVolumeControl();
		if (c == null) return;
		float min = c.getMinimum(), max = c.getMaximum();
		int toUse = left & 0xffff;
		if (left <= 0) c.setValue(min);
		else if (left >= 0xffff) c.setValue(max);
		else{
			float range = max-min;
			float inc = c.getPrecision();
			int num = (int)(((range/inc)*toUse)/0xffff);
			c.setValue(num*inc+min);
		}
	}


}
