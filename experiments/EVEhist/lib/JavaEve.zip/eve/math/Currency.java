package eve.math;

import eve.util.LocaleFormatted;

public class Currency extends Decimal implements LocaleFormatted {
	
	{
		isCurrency = true;
		outputFormat = "#0.00";
	}
	public Currency() {
		// TODO Auto-generated constructor stub
	}

	public Currency(double value) {
		super(value);
		// TODO Auto-generated constructor stub
	}

	public Currency(BigDecimal bd) {
		super(bd);
		// TODO Auto-generated constructor stub
	}

	public Currency(java.math.BigDecimal bd) {
		super(bd);
		// TODO Auto-generated constructor stub
	}

	public Currency(String str) {
		super(str);
		// TODO Auto-generated constructor stub
	}

}
