package eve.math;
import java.text.ParseException;

import eve.sys.LocaleFormat;
import eve.util.ByteArray;
import eve.util.ByteEncodable;
import eve.util.ByteDecodable;
import eve.util.CharArray;
import eve.util.LocaleFormatted;
import eve.data.DataObject;
import eve.data.Value;
/**
* A Decimal is a mutable version of BigDecimal. It contains a BigDecimal within itself which
* you can access and replace with a new value if needed.
**/
//##################################################################
public class Decimal extends DataObject implements Value, ByteEncodable, ByteDecodable, LocaleFormatted{
//##################################################################
private BigDecimal bd;

/**
 * Set this true to indicate that this Decimal value is a currency value.
 */
protected boolean isCurrency;

/**
 * Returns if this Decimal value is considered a currency value.
 */
public boolean isCurrency()
{
	return this.isCurrency;
}

public String outputFormat = "#.####";

/**
 * This is the default value for the ThousandGrouping on newly
 * created Decimal values - it is false by default.
 */
public static boolean defaultFormatNoThousandGrouping = false;

/**
 * These are LocaleFormat option bits to set, overriding the default
 * options for the locale.
 */
public int localeFormatOptionsToSet = defaultFormatNoThousandGrouping ? 0 : LocaleFormat.OPTION_SHOW_GROUPINGS;
/**
 * These are LocaleFormat option bits to clear, overriding the default
 * options for the locale.
 */
public int localeFormatOptionsToClear = !defaultFormatNoThousandGrouping ? 0 : LocaleFormat.OPTION_SHOW_GROUPINGS;

//===================================================================
public Object getCopy()
//===================================================================
{
	return new Decimal(bd);
}
//===================================================================
public void copyFrom(Object other)
//===================================================================
{
	if (other instanceof Decimal)
		bd = ((Decimal)other).bd;
	super.copyFrom(other);
}
//===================================================================
public int compareTo(Object other)
//===================================================================
{
	if (!(other instanceof Decimal)) return super.compareTo(other);
	return bd.compareTo(((Decimal)other).bd);
}
//===================================================================
public Decimal()
//===================================================================
{
	this(BigDecimal.valueOf(0));
}
//===================================================================
public Decimal(double value)
//===================================================================
{
	this(value == 0 ? BigDecimal.valueOf(0) : new BigDecimal(value));
}
//===================================================================
public Decimal(BigDecimal bd)
//===================================================================
{
	setBigDecimal(bd);
}
//===================================================================
public Decimal(java.math.BigDecimal jbd)
//===================================================================
{
	setBigDecimal(BigDecimal.toEveBigDecimal(jbd));
}
//===================================================================
public Decimal(String str)
//===================================================================
{
	fromString(str);
}

//===================================================================
public String toString()
//===================================================================
{
	return bd.toString();
}
//===================================================================
public void fromString(String value)
//===================================================================
{
	bd = new BigDecimal(value);
}
//===================================================================
public BigDecimal getBigDecimal()
//===================================================================
{
	return bd;
}
//===================================================================
public java.math.BigDecimal getJavaBigDecimal()
//===================================================================
{
	return BigDecimal.toJavaBigDecimal(bd);
}
//===================================================================
public void setBigDecimal(BigDecimal bd)
//===================================================================
{
	if (bd == null) bd = BigDecimal.valueOf(0);
	this.bd = bd;
}
//===================================================================
public void setJavaBigDecimal(java.math.BigDecimal jbd)
//===================================================================
{
	if (jbd == null) bd = BigDecimal.valueOf(0);
	this.bd = BigDecimal.toEveBigDecimal(jbd);
}
//===================================================================
public int encodeBytes(ByteArray dest)
//===================================================================
{
	int need = bd.write(null,0);
	if (dest == null) return need;
	dest.makeSpace(dest.length,need);
	bd.write(dest.data,dest.length-need);
	return need;
}
//===================================================================
public int decodeBytes(byte[] source,int offset,int length)
//===================================================================
{
	bd = new BigDecimal(source,offset,length);
	return length;
}
//===================================================================
public Decimal setDouble(double value)
//===================================================================
{
	setBigDecimal(new BigDecimal(value));
	return this;
}
//##################################################################
/* (non-Javadoc)
 * @see eve.util.Stringable#toString(eve.util.CharArray)
 */
public CharArray toString(CharArray dest) {
	if (dest == null) dest = new CharArray();
	return bd.toString(dest);
}
/* (non-Javadoc)
 * @see eve.util.Stringable#fromString(char[], int, int)
 */
public void fromString(char[] src, int offset, int length) {
	fromString(new String(src,offset,length));
}
public void format(LocaleFormat locale, CharArray dest) {
	if (outputFormat != null){
		LocaleFormat lc = locale.getCachedCopy();
		lc.format = outputFormat;
		try{
			dest.append(bd.format(lc, this));
		}finally{
			lc.cache();
		}
	}else{
		dest.append(bd.format(locale, this));
	}
}
public void parse(LocaleFormat locale, char[] data, int offset, int length)
		throws ParseException {
	try{
		bd = new BigDecimal(new String(data,offset,length),locale,this instanceof Currency );
	}catch(NumberFormatException e){
		bd = BigDecimal.valueOf(0);
		throw new ParseException(new String(data,offset,length),0);
	}
}
}
//##################################################################

