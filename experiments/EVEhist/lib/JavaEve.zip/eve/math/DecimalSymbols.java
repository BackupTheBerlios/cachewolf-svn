/**
 * 
 */
package eve.math;

import java.util.Hashtable;

import eve.sys.Convert;
import eve.sys.Locale;
import eve.util.IntArray;
import eve.util.mString;
/**
 * This contains the decimal symbols and format for a particular Locale for
 * either currency or non-currency decimal values. Use getFor(Locale locale, boolean isCurrency)
 * to get a cached version of a DecimalSymbols object for that Locale. Alternatively
 * you could create one yourself and set the values appropriately.
 */
public class DecimalSymbols implements Cloneable{
	
	public Object clone()
	{
		try{
			return super.clone();
		}catch(CloneNotSupportedException e){
			return null;
		}
	}
	private static String numberFormats [] = 
		{"($.)","-$.","$-.","$.-","(.$)",
		"-.$",".-$",".$-","-. $","-$ .",
		". $-","$ .-","$ -.",".- $","($ .)","(. $)"};
	private static final int inegMap [] = {0,1,9,6,10};
	private static final int icurMap [] = {1,5,9,8}; 
	
	public String 
		currencySymbol, groupSymbol, decimalSymbol,
		negativeSymbol, positiveSymbol, positiveFormat, negativeFormat;
	/**
	 * The number of digits to be grouped starting with the least significant
	 * going up. If there are more groups in the digit sequence than are in
	 * this array, then the last group length of this array should be used.
	 */
	public int [] groupings = {3};
	/**
	 * The native decimal digits.
	 */
	public char[] digits;
	
	protected Locale myLocale;
	protected boolean amCurrency;
	
	private String getString(int normal, int currency, String defaultValue)
	{
		String r = amCurrency && currency != 0 ? myLocale.getString(currency) : null;
		if (r != null) return r;
		if (normal != 0) r = myLocale.getString(normal);
		if (r != null) return r;
		return defaultValue;
	}
	private String getNotEmptyString(int normal, int currency, String defaultValue)
	{
		String r = amCurrency && currency != 0 ? myLocale.getString(currency) : null;
		if (r != null && r.length() != 0) return r;
		if (normal != 0) r = myLocale.getString(normal);
		if (r != null && r.length() != 0) return r;
		return defaultValue;
	}
	private String getNumberFormat(boolean negative)
	{
		if (!negative && !amCurrency) return ".";
		int[] map = null;
		if (amCurrency && !negative) map = icurMap;
		if (!amCurrency && negative) map = inegMap;
		int v = Convert.toInt(getString(negative ? Locale.NegativeNumberMode : 0, negative ? Locale.NegativeCurrencyMode : Locale.PositiveCurrencyMode,"0")); 
		if (map != null && v < map.length && v >= 0)
			v = map[v];
		if (v >= 0 && v < numberFormats.length) return numberFormats[v];
		else return numberFormats[0];
	}
	private static Hashtable decimal, currency;
	/**
	 * This uses a Hashtable to keep DecimalSymbols for Locales so that you
	 * don't need to keep creating new DecimalSymbols.
	 * @param loc the Locale. If it is null the default Locale is used.
	 * @param isCurrency true for currency symbols, false for decimal symbols.
	 * @return a possibly used DecimalSymbols for the Locale.
	 */
	public synchronized static DecimalSymbols getFor(Locale loc, boolean isCurrency)
	{
		if (loc == null) loc = Locale.getDefault();
		if (decimal == null) {
			decimal = new Hashtable();
			currency = new Hashtable();
		}
		Hashtable h = isCurrency ? currency : decimal;
		DecimalSymbols ds = (DecimalSymbols)h.get(loc);
		if (ds == null){
			ds = new DecimalSymbols(loc,isCurrency);
			h.put(loc,ds);
		}
		return ds;
	}
	/**
	 * Create a new DecimalSymbols with values retrieved from the specified locale.
	 * @param loc the Locale to use. If it is null the default Locale is used.
	 * @param isCurrency true to get symbols for currency, false for decimal symbols.
	 */
	public DecimalSymbols(Locale loc, boolean isCurrency)
	{
		if (loc == null) loc = Locale.getDefault();
		myLocale = loc;
		amCurrency = isCurrency;
		currencySymbol = getString(Locale.CurrencySymbol,0,"$");
		String groups =  getString(Locale.DigitGrouping, Locale.CurrencyGrouping, "3;0");
		IntArray ia = new IntArray();
		String[] all = mString.split(groups,';');
		for (int i = 0; i<all.length; i++){
			int num = Convert.toInt(all[i]);
			if (num == 0) break;
			ia.append(num);
		}
		if (ia.length == 0) ia.append(3);
		groupings = ia.toIntArray();
		decimalSymbol = getNotEmptyString(Locale.DecimalSeparator,Locale.CurrencyDecimalSeparator,".");
		String dg = getString(Locale.NativeDigits,Locale.CurrencyDigits,"0123456789");
		if (dg.length() != 10) dg = "0123456789";
		digits = dg.toCharArray();
		positiveFormat = getNumberFormat(false);
		negativeFormat = getNumberFormat(true);
		positiveSymbol = getNotEmptyString(Locale.PositiveSign,Locale.PositiveSign,"+");
		negativeSymbol = getNotEmptyString(Locale.NegativeSign,Locale.NegativeSign,"-");
		groupSymbol = getString(Locale.ThousandsSeparator,Locale.CurrencyThousandsSeparator,",");
		if (groupSymbol.length() != 0 && groupSymbol.charAt(0) == decimalSymbol.charAt(0))
			groupSymbol = "";
	}
	/**
	 * Convert a possible native digit to the equivalent English digit.
	 * @param nativeDigit the possible native digit.
	 * @return the English digit between '0' and '9' inclusive, or (char)0
	 * if it is not a native digit.
	 */
	public char toEnglishDigit(char nativeDigit)
	{
		for (int i = 0; i<digits.length; i++)
			if (digits[i] == nativeDigit) return (char)('0'+i);
		return 0;
	}
}