package eve.math;

import eve.sys.Cache;
import eve.sys.LocaleFormat;
import eve.util.CharArray;

/**
 * This class is used to format or parse a decimal value (NOT in 
 * scientific notation) according to the format and symbols defined in
 * DecimalSymbols.
 * It is used by the eve.math classes BigDecimal, Decimal and Currency to
 * format and parse decimal values.
 */
public class FormattedDecimal 
{
	private StringBuilder temp;
	private CharArray buffer;
	/**
	 * When building a decimal value, put the part before the decimal point
	 * here. When parsing, the part before the decimal will be put here.
	 */
	public StringBuilder integerPart = new StringBuilder();
	/**
	 * When building a decimal value, put the part after the decimal point
	 * here. When parsing, the part after the decimal goes here.
	 */
	public StringBuilder fractionalPart = new StringBuilder();
	/**
	 * If a formatString is used during format/parse operations, then place it
	 * here.
	 */
	//public String format = null;
	/**
	 * If the value you are formatting is negative, set this true. On parsing
	 * if the value was negative, this will be set true.
	 */
	public boolean isNegative = false;
	/**
	 * If during formatting you wish to place the currency Symbol then set 
	 * this true. On parsing, if the value had a currency symbol then this is set true.
	 */
	//public boolean useCurrencySymbol = false;
	/**
	 * If the value you are formatting has a currencySymbol then set this true
	 * (or you can have a '$' symbol in the format string). On parsing, if
	 * the value had a currency symbol then this is set true.
	 */
	//public boolean useGrouping = false;
	/**
	 * Use LocaleFormat.OPTION_XXX values here. For example LocaleFormat.OPTION_SHOW_CURRENCY_SYMBOL
	 * to have the currency symbol be placed in the output during format().
	 */
	public int formatOptions = 0;
	
	/**
	 * Place the String to parse here, or when the number is formatted, it
	 * is placed here.
	 */
	public StringBuilder formattedNumber = new StringBuilder();
	
	/**
	 * By default FormattedDecimal is lenient during parsing, ignoring the placement of
	 * currency marks and positive/negative signs. If isStrict is set true
	 * then a parsed string must strictly conform to what the DecimalSymbols
	 * specify should be the form of the foramtted string.
	 */
	public boolean isStrict = false;
	/**
	 * Sets the isStrict value and returns this FormattedDecimal.
	 * @param strict the value to set to isStrict.
	 * @return this FormattedDecimal object.
	 */
	public FormattedDecimal setStrict(boolean strict)
	{
		this.isStrict = strict;
		return this;
	}
	/**
	 * Clear all fields.
	 */
	public void clear()
	{
		if (integerPart == null) integerPart = new StringBuilder();
		if (fractionalPart == null) fractionalPart = new StringBuilder();
		if (formattedNumber == null) formattedNumber = new StringBuilder();
		//format = null;
		integerPart.setLength(0);
		fractionalPart.setLength(0);
		formattedNumber.setLength(0);
		isNegative = false;
		formatOptions = 0;
	}
	/**
	 * Get a FormattedDecimal Object from the Cache. Call cache() on the
	 * Object to return it to the cache.
	 * @return a FormattedDecimal Object.
	 */
	public static FormattedDecimal getCached()
	{
		FormattedDecimal fd = (FormattedDecimal)Cache.get(FormattedDecimal.class);
		fd.clear();
		return fd;
	}
	/**
	 * Place a FormattedDecimal Object retrieved from getCached() back into
	 * the Cache.
	 */
	public void cache()
	{
		Cache.put(this);
	}
	/**
	 * A convenience method to set some of the values. Call clear()
	 * before calling this.
	 * @param integerPart
	 * @param fractionalPart
	 * @param isNegative
	 * @param showCurrencySymbol
	 * @param showGroupings
	 * @return this FormattedDecimal.
	 */
	public FormattedDecimal set(String integerPart,String fractionalPart,boolean isNegative,boolean showCurrencySymbol, boolean showGroupings)
	{
		if (integerPart != null) this.integerPart.append(integerPart);
		if (fractionalPart != null) this.fractionalPart.append(fractionalPart);
		//this.format = format;
		this.isNegative = isNegative;
		setOption(LocaleFormat.OPTION_SHOW_CURRENCY_SYMBOL, showCurrencySymbol);
		setOption(LocaleFormat.OPTION_SHOW_GROUPINGS, showGroupings);
		return this;
	}
	/**
	 * Apply grouping separators to the string of digits.
	 * @param digits a sequence of digits only.
	 * @param the start of the first digit.
	 * @parem the number of digits.
	 * @return the digits grouped appropriately.
	 */
	private void group(DecimalSymbols symbols)
	{
		StringBuilder toGroup = integerPart;
		int length = toGroup.length();
		if (buffer == null) buffer = new CharArray();
		buffer.ensureCapacity(length*3);
		char[] grouper = buffer.data;
		toGroup.getChars(0, length, grouper, 0);
		int offset = 0;
		char[] digits = grouper;
		if (symbols.groupSymbol.length() == 0) return;
		char s = symbols.groupSymbol.charAt(0);
		int g = grouper.length;
		int curGroup = 0;
		int[] groupings = symbols.groupings;
		int leftInGroup = groupings[0];
		offset += length;
		for (int cd = 0; cd<length; cd++){
			if (leftInGroup == 0) {
				grouper[--g] = s;
				if (curGroup < groupings.length-1)
					curGroup++;
				leftInGroup = groupings[curGroup];
			}
			grouper[--g] = digits[--offset];
			leftInGroup--;
		}
		toGroup.setLength(0);
		toGroup.append(grouper,g,grouper.length-g);
	}
	/**
	 * Format this integerPart and fractionalPart of this FormattedDecimal and place
	 * it into formattedNumber.
	 * @param symbols the DecimalSymbols to use for formatting.
	 * @return this FormattedDecimal.
	 */
	public FormattedDecimal format(DecimalSymbols symbols)
	{
		//int fractionDigits = -1;
		//int intDigits = -1;
		//
		if (formattedNumber == null) formattedNumber = new StringBuilder();
		StringBuilder dest = formattedNumber;
		dest.setLength(0);
		//
		boolean showCurrencySymbol = (formatOptions & LocaleFormat.OPTION_SHOW_CURRENCY_SYMBOL) != 0;
		boolean doGroup = (formatOptions & LocaleFormat.OPTION_SHOW_GROUPINGS) != 0;
		/*
		if (format != null && format.indexOf('$') != -1)
			showCurrencySymbol = true;
		boolean doGroup = (format != null && format.indexOf(',') != -1);
		*/ 
		if (doGroup) group(symbols);
		String fm = isNegative ? symbols.negativeFormat:symbols.positiveFormat;
		int len = fm.length();
		for (int i = 0; i<len; i++){
			char c = fm.charAt(i);
			switch(c){
			case '$':
				if (showCurrencySymbol) dest.append(symbols.currencySymbol); break;
			case '+':
				if (!isNegative) dest.append(symbols.positiveSymbol); break;
			case '-':
				if (isNegative) dest.append(symbols.negativeSymbol); break;
			case '.':
				if (integerPart == null || integerPart.length() == 0)
					dest.append("0");
				else
					dest.append(integerPart);
				if (fractionalPart != null && fractionalPart.length() != 0){
					dest.append(symbols.decimalSymbol);
					dest.append(fractionalPart);
				}
				break;
			default:
				dest.append(c);
			}
		}
		return this;
	}
	/**
	 * Parse the String in formattedNumber and separate it into its integer
	 * and fractional parts, convert them to English digits, 
	 * and place them in integerPart and fractionalPart
	 * respectively. The isNegative and currencySymbols are set depending on
	 * if the value is considered negative and if the currencySymbol was found.
	 * @param ds The DecimalSymbols to use for parsing.
	 * @return this FormattedDecimal
	 * @throws NumberFormatException
	 */
	public FormattedDecimal parse(DecimalSymbols ds) throws NumberFormatException
	{
		//System.out.println("Parse: "+formattedNumber);
		//useCurrencySymbol = false;
		isNegative = false;
		if (integerPart == null) integerPart = new StringBuilder();
		if (fractionalPart == null) fractionalPart = new StringBuilder();
		if (formattedNumber == null) throw new NullPointerException();
		integerPart.setLength(0);
		fractionalPart.setLength(0);
		if (temp == null) temp = new StringBuilder();
		if (buffer == null) buffer = new CharArray();
		int len = formattedNumber.length();
		buffer.ensureCapacity(len);
		temp.setLength(0);
		char[] src = buffer.data;
		formattedNumber.getChars(0, len, src, 0);
		boolean haveInteger = false;
		boolean haveFractional = false;
		boolean haveDecimalPoint = false;
		char sign = 0;
		boolean haveCurrency = false;
		boolean noMoreDigits = false;
		char gc = ds.groupSymbol.length() == 0 ? 0 : ds.groupSymbol.charAt(0);
		char dc = ds.decimalSymbol.charAt(0);
		//char gs = ds.groupSymbol.charAt(0);
		char ps = ds.positiveSymbol.charAt(0);
		char ns = ds.negativeSymbol.charAt(0);
		//System.out.println(gc+"("+Integer.toHexString(gc)+"):"+dc+":"+ps+":"+ns);
		char substituteGroup = 0;
		
		if (Character.isSpaceChar(gc))
			substituteGroup = ' ';
		for (int i = 0; i<len; i++){
			char c = src[i];
			if (c == dc){
				if (haveDecimalPoint || noMoreDigits) throw new NumberFormatException();
				haveDecimalPoint = true;
				if (!haveInteger) {
					integerPart.append('0');
					haveInteger = true;
				}
				haveFractional = true;
				continue;
			}else if (c == gc || c == substituteGroup){
				if (noMoreDigits || haveDecimalPoint || !haveInteger) throw new NumberFormatException();
				continue;
			}else if (c == ns || c == ps || c == '('){
				if (sign != 0 || (haveInteger && c == '(')) throw new NumberFormatException();
				sign = c;
				//
				// If the negative/positive sign is after.
				//
				if (haveInteger) noMoreDigits = true;
				if (c == ns || c == '(') isNegative = true;
				continue;
			}else if (c == ')'){
				if (sign != '(') throw new NumberFormatException();
				sign = c;
				noMoreDigits = true;
				continue;
			}else{
				if (c > '9'){
					char nc = ds.toEnglishDigit(c);
					if (nc != 0) c = nc;
				}
				if (c >= '0' && c <= '9'){
					if (noMoreDigits) throw new NumberFormatException();
					haveInteger = true;
					if (!haveFractional){
						integerPart.append(c);
					}else{
						fractionalPart.append(c);
					}
					continue;
				}
				if (Character.isWhitespace(c)){
					if (haveInteger) noMoreDigits = true;
					continue;
				}
				temp.append(c);
			}
		}
		int tl = temp.length();
		if (tl != 0){
			if (tl == ds.currencySymbol.length()){
				for (int i = 0; i<tl; i++){
					if (Character.toUpperCase(temp.charAt(i)) != Character.toUpperCase(ds.currencySymbol.charAt(i)))
						throw new NumberFormatException();
				}
				//useCurrencySymbol = true;
			}
		}
		return this;
	}
	public static String format(DecimalSymbols ds,String integerPart,String fractionalPart,boolean isNegative,LocaleFormat optionalFormat,int optionsToSet,int optionsToClear)
	{
		FormattedDecimal fd = (FormattedDecimal)Cache.get(FormattedDecimal.class);
		try{
			fd.clear();
			fd.integerPart.append(integerPart);
			if (fractionalPart != null) fd.fractionalPart.append(fractionalPart);
			fd.isNegative = isNegative;
			if (optionalFormat != null) fd.optionsFromLocale(optionalFormat);
			fd.modifyOptions(optionsToSet, optionsToClear);
			fd.format(ds);
			return fd.formattedNumber.toString();
		}finally{
			Cache.put(fd);
		}
	}
	/**
	 * After a successful parse operation, this will rebuild the parsed 
	 * String into formattedNumber as a plain English digit decimal number
	 * with an optional negative sign at the front (if negative) followed by
	 * the integer part, the decimal point and the fractional part. If the
	 * fractionalPart length is zero no decimal point is placed.
	 * <p>
	 * The resulting String can be parsed by BigDecimal or any standard simple
	 * decimal conversion.
	 * @return this FormattedDecimal.
	 */
	public FormattedDecimal reformatAfterParse()
	{
		formattedNumber.setLength(0);
		if (isNegative) formattedNumber.append('-');
		formattedNumber.append(integerPart);
		if (fractionalPart.length() != 0){
			formattedNumber.append('.');
			formattedNumber.append(fractionalPart);
		}
		return this;
	}
	/**
	 * Set the useCurrencySymbol and useGrouping values based
	 * on the options from the specified LocaleFormat.
	 * @param lf the LocaleFormat
	 * @return this FormattedDecimal.
	 */
	public FormattedDecimal optionsFromLocale(LocaleFormat lf)
	{
		formatOptions = lf.options;
		if (lf.format instanceof String){
			try{
				DecimalFormat df = DecimalFormat.getFor((String)lf.format);
				applyFormat(df);
			}catch(Exception e){
			}
		}else if (lf.format instanceof DecimalFormat){
			applyFormat((DecimalFormat)lf.format);
		}
		return this;
	}
	/**
	 * Modify specified option bits.
	 * @param optionsToSet the option bits to set.
	 * @param optionsToClear the option bits to clear.
	 * @return a value that can be used to restore the changed option bits.
	 */
	public long modifyOptions(int optionsToSet, int optionsToClear)
	{
		int mask = optionsToSet|optionsToClear;
		int ret = formatOptions & mask;
		formatOptions |= optionsToSet;
		formatOptions &= ~optionsToClear;
		return ((long)mask << 32)|(((long)ret)& 0xffffffffL);
	}
	/**
	 * Restore option bits changed by modifyOptions.
	 * @param fromModifyOptions the value returned from the modifyOptions()
	 * call that modified the options.
	 */
	public void restoreOptions(long fromModifyOptions)
	{
		int mask = (int)(fromModifyOptions >> 32);
		formatOptions &= ~mask;
		formatOptions |= (int)fromModifyOptions;
	}
	/**
	 * Set or clear option bits depending on the value of setOrClear.
	 * @param optionToSetOrClear the bits to set or clear.
	 * @param setOrClear true to set the bits, false to clear them.
	 * @return a value that can be used with restoreOptions to restore
	 * these bits to their original setting.
	 */
	public long setOption(int optionsToSetOrClear,boolean setOrClear)
	{
		return modifyOptions(setOrClear ? optionsToSetOrClear : 0, setOrClear ? 0 : optionsToSetOrClear);
	}
	/**
	 * Call this before doing a format() but after setting the integer/fractional
	 * parts. This will truncate/extend the integer/fractional parts as necessary
	 * to keep with the formatting specified in the format String.
	 * @param f the format String in the form "##00.00##". A '0' indicates
	 * that a digit must be placed there. A '#' indicates that if the digit
	 * value there is insignificant it may be left out.  The total number
	 * before or after the decimal point indicate the maximum number of allowed
	 * digits for that portion.
	 * A ',' in the format indicates that Thousand groupings should be used.
	 * A '$' indicates that currency symbol should be shown.
	 * @return this FormattedDecimal.
	 */
	public FormattedDecimal applyFormat(String format) 
	{
		return applyFormat(DecimalFormat.getFor(format));
	}
	/**
	 * Call this before doing a format() but after setting the integer/fractional
	 * parts. This will truncate/extend the integer/fractional parts as necessary
	 * to keep with the formatting specified in the DecimalFormat object.
	 * @return this FormattedDecimal.
	 */
	public FormattedDecimal applyFormat(DecimalFormat format)
	{
		if (format.maxInt >= 0 && integerPart.length() > format.maxInt)
				integerPart.setLength(format.maxInt);
		if (format.maxFrac >= 0 && fractionalPart.length() > format.maxFrac)
			fractionalPart.setLength(format.maxFrac);
		int toAdd = format.minInt > 0 ? format.minInt-integerPart.length() : 0;
		for (int i = 0; i<toAdd; i++) integerPart.insert(0,'0');
		toAdd = format.minFrac > 0 ? format.minFrac-fractionalPart.length() : 0;
		for (int i = 0; i<toAdd; i++) fractionalPart.append('0');
		if (format.showCurrency) formatOptions |= LocaleFormat.OPTION_SHOW_CURRENCY_SYMBOL;
		if (format.showThousands) formatOptions |= LocaleFormat.OPTION_SHOW_GROUPINGS;
		return this;
	}
}
