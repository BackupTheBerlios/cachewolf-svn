package eve.math;

import java.util.Hashtable;

import eve.sys.Vm;

/**
 * This is an immutable Decimal Format specifier.
 *
 */
public class DecimalFormat 
{
	int maxInt = -1, minInt, maxFrac = 0, minFrac = 0;
	boolean showCurrency = false;
	boolean showThousands = false;
	//
	public int getMaxIntegerDigits(){return maxInt;}
	public int getMaxFractionDigits(){return maxFrac;}
	public int getMinIntegerDigits(){return minInt;}
	public int getMinFractionDigits(){return minFrac;}
	
	void badFormat(String format)
	{
		throw new IllegalArgumentException("Bad decimal format string: "+format);
	}
	/**
	 * 
	 * @param maxInteger the maximum number of integer digits, use -1 to indicate
	 * no maximium.
	 * @param minInteger the minimum number of integer digts.
	 * @param maxFraction the maximum number of fractional digits, use -1 to indicate
	 * no maximium. 
	 * @param minFraction the minimum number of factional digits.
	 * @param showThousands true to show thousand groupings.
	 * @param showCurrency true to show the currency character.
	 */
	public DecimalFormat(int maxInteger, int minInteger, int maxFraction, int minFraction, boolean showThousands, boolean showCurrency)
	{
		maxInt = maxInteger;
		minInt = minInteger;
		maxFrac = maxFraction;
		minFrac = minFraction;
		this.showCurrency = showCurrency;
		this.showThousands = showThousands;
	}
	//
	private static Hashtable formats;
	//
	/**
	 * Get a DecimalFormat for the provided format String.
	 * @param f the format String in the form "##00.00##". A '0' indicates
	 * that a digit must be placed there. A '#' indicates that if the digit
	 * value there is insignificant it may be left out.  The total number
	 * before or after the decimal point indicate the maximum number of allowed
	 * digits for that portion.
	 * A ',' in the format indicates that Thousand groupings should be used.
	 * A '$' indicates that currency symbol should be shown.
	 */
	public synchronized static DecimalFormat getFor(String format) throws IllegalArgumentException
	{
		if (formats == null) formats = new Hashtable();
		DecimalFormat f = (DecimalFormat)formats.get(format);
		if (f == null){
			f = new DecimalFormat(format);
			formats.put(format,f);
		}
		return f;
	}
	DecimalFormat(String format) throws IllegalArgumentException
	{
		char[] all = Vm.getStringChars(format);
		boolean haveDec = false;
		int state = 0;
		for (int i = 0; i<all.length; i++){
			char c = all[i];
			switch(c){
			case '#':
				if (state == 2) state = 3;
				if (state == 0) 
					;//maxInt++;
				else if (state == 3)
					maxFrac++;
				else 
					badFormat(format);
				break;
			case '0':
				if (state == 0) state = 1;
				if (state == 1) {
					//maxInt++; 
					minInt++;
				}else if (state == 2){
					maxFrac++; minFrac++;
				}else
					badFormat(format);
				break;
			case '.':
				if (state == 0 || state == 1){
					state = 2;
				}else
					badFormat(format);
				break;
			case ',':
			case '$':
				if (state == 0 || state == 1){
					if (c == ',') showThousands = true;
					else showCurrency = true;
				}else
					badFormat(format);
				break;
			default:
				badFormat(format);
			}
		}
	}
}
