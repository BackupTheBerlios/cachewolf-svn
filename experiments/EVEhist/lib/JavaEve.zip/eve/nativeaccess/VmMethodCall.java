/*
 * Created on May 26, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.nativeaccess;

import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;

import eve.reflect.Reflect;
import eve.reflect.Method;
//import eve.sys.Reflection;
import eve.sys.Wrapper;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class VmMethodCall implements Runnable{
	static VmMethodThread freeThread;
	// Don't move these 11.---------------------
	int nativeObject;
	Wrapper retValue = new Wrapper();
	Throwable error;
	boolean interrupt;
	Thread myThread;
	Class c;
	String name;
	String desc;
	Object target;
	Wrapper parameters[];
	Method method;
	//------------------------------
	//
	//
	private static native void complete(int nativeObject);
	//
	// Called from the VM.
	//
	public void execute(boolean declaredOnly) throws NoSuchMethodException
	{
		//if (name.charAt(0) == '<') method = NativeAccess.getNativeMethod(c,name+desc);
		//else method = Reflection.getMethod(c,name,desc,declaredOnly);
		if (method == null){
			Reflect r = new Reflect(c);
			method = r.getMethod(name,desc,Reflect.DECLARED|Reflect.CONSTRUCTOR_AS_METHOD);
		}else{
			//Vm.debug(method+" for:"+name+", "+desc);
		}
		//System.out.println("Execute: "+name+", "+desc+", "+mString.toString(parameters)+ " = "+method);
		if (method == null) throw new NoSuchMethodException();
		error = null;
		interrupt = false;
		myThread = null;
		retValue.zero();
		//
		// Under an Eve vm this is safe.
		VmMethodThread t = freeThread;
		if (t == null) t = new VmMethodThread();
		else freeThread = t.next;
		//
		synchronized(t){
			t.myCall = this;
			//t.interrupt();
			t.notifyAll();
		}
	}
	//
	public void run()
	{
		error = null;
		try{
			synchronized(this){
				if (interrupt) {
					error = new InterruptedException();
					interrupt = false;
					return;
				}
				myThread = Thread.currentThread();
			}
			//System.out.println("run()");
			try{
				method.modifiers |= method.FORCE_ACCESS_PUBLIC;
				method.invoke(target,parameters,retValue);
			}catch(InvocationTargetException e){
				throw e.getTargetException();
			}
		}catch(Throwable t){
			error = t;
			//t.printStackTrace();
		}finally{
			complete(nativeObject);
		}
	}
	
}
//####################################################

class VmMethodThread extends Thread{
	VmMethodCall myCall;
	VmMethodThread next;
	VmMethodThread()
	{
		start();
	}
	
	public void run()
	{
		while(true){
			synchronized(this){
				while(myCall == null){
					try{
						wait();
						//sleep(10000);
					}catch(Exception e){}
				}
			}
			interrupted();
			myCall.run();
			myCall = null;
			/* Under an Eve VM this is safe.*/
			next = VmMethodCall.freeThread;
			VmMethodCall.freeThread = this;
		}
	}
}
