/*
 * Created on Jan 9, 2006
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.nativeaccess;

import java.io.IOException;

import eve.io.RandomStream;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class NativeRandomStream extends RandomStream{
//####################################################

	private int nativeStream;
	
	private NativeRandomStream(int rs, String mode)
	{
		super(mode);
		nativeStream = rs;
	}
		public static RandomStream toRandomStream(int nativeStream,String mode)
		{
			return toRandomStream(nativeStream,null,mode);
		}
		private static RandomStream toRandomStream(int nativeStream,RandomStream dest,String mode)
		{
			if (nativeStream == 0) return null;
			if (dest != null) throw new IllegalArgumentException("Cannot set a RandomStream native stream in Java.");
			return new NativeRandomStream(nativeStream,mode);
		}
//	####################################################
		private long doInputOp(int op, byte[] data, int offset, long length)
		throws IOException
		{
			/*
			if (nativeStream == 0){
				AbstractMethodError e = new AbstractMethodError();
				Vm.fixFillInStackTrace(1);
				e.fillInStackTrace();
				throw e;
			}
			*/
			return NativeStream.streamOperation(nativeStream,op,data,offset,length);
		}
		private long doRandomOp(int op, long value)
		throws IOException
		{
			/*
			if (nativeStream == 0){
				AbstractMethodError e = new AbstractMethodError();
				Vm.fixFillInStackTrace(1);
				e.fillInStackTrace();
				throw e;
			}
			*/
			return NativeStream.streamOperation(nativeStream,op,null,0,value);
		}
		private long doOutputOp(int op, byte[] data, int offset, long length)
		throws IOException
		{
			/*
			if (nativeStream == 0){
				AbstractMethodError e = new AbstractMethodError();
				Vm.fixFillInStackTrace(1);
				e.fillInStackTrace();
				throw e;
			}
			*/
			return NativeStream.streamOperation(nativeStream,op,data,offset,length);
		}

		public int hashCode()
		{
			return nativeStream;
		}
		public int read() throws IOException
		{
			return (int)doInputOp(NativeStream.INPUT_OP_READ,null,0,1);
		}
		public int read(byte[] data, int offset, int count) throws IOException
		{
			if (nativeStream == 0) throw new AbstractMethodError();
			if (count == 0) return 0;
			if (data == null) throw new NullPointerException();
			if (count < 0) throw new IllegalArgumentException();
			if (offset < 0 ||  offset + count > data.length) throw new ArrayIndexOutOfBoundsException ();
			return (int)doInputOp(1,data,offset,count);
		}
		public void close() throws IOException
		{
		  	if (nativeStream == 0) return;
			doInputOp(NativeStream.INPUT_OP_CLOSE,null,0,0);
		}
		public long skip(long n) throws IOException
		{
			if (nativeStream != 0)
				return doInputOp(NativeStream.INPUT_OP_SKIP,null,0,n);
		  // Throw away n bytes by reading them into a temp byte[].
		  // Limit the temp array to 2Kb so we don't grab too much memory.
		  final int buflen = n > 2048 ? 2048 : (int) n;
		  byte[] tmpbuf = new byte[buflen];
		  final long origN = n;

		  while (n > 0L)
		    {
			int numread = read(tmpbuf, 0, n > buflen ? buflen : (int) n);
			if (numread <= 0)
			  break;
			n -= numread;
		    }

		  return origN - n;
		}

		protected void finalize()
		{
			NativeAccess.unref(nativeStream);
		}
		public long getLength() throws IOException
		{
			return doRandomOp(NativeStream.RANDOM_OP_GET_LENGTH,0);
		}
		public void setLength(long length) throws IOException
		{
			doRandomOp(NativeStream.RANDOM_OP_SET_LENGTH,length);
		}
		public long getPosition() throws IOException
		{
			return doRandomOp(NativeStream.RANDOM_OP_GET_POSITION,0);
		}
		public void setPosition(long newPosition) throws IOException
		{
			doRandomOp(NativeStream.RANDOM_OP_SET_POSITION,newPosition);
		}
		  public void write(int b) throws IOException
		  {
		  	doOutputOp(NativeStream.OUTPUT_OP_WRITE,null,0,b);
		  }
		  public void write (byte[] data, int offset, int count) throws IOException, NullPointerException, IndexOutOfBoundsException
		  {
			if (nativeStream == 0) throw new AbstractMethodError();
		  	if (count == 0) return;
		  	if (data == null) throw new NullPointerException();
		  	if (count < 0) throw new IllegalArgumentException();
		    if (offset < 0 ||  offset + count > data.length)
		      throw new ArrayIndexOutOfBoundsException ();
		  	doOutputOp(NativeStream.OUTPUT_OP_WRITE,data,offset,count);
		  }
		  public void flush () throws IOException
		  {
		  	if (nativeStream == 0) return;
		  	doOutputOp(NativeStream.OUTPUT_OP_FLUSH,null,0,0);
		  }
		  protected void throwCantWrite() throws IOException
		  {
		  	throw new IOException("Stream is not open for writing.");
		  }

}
//####################################################
