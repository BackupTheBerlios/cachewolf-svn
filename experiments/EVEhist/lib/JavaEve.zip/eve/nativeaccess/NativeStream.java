/*
 * Created on Mar 14, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.nativeaccess;

import java.io.IOException;

/**
 * @author Michael L Brereton
 */
//####################################################
public class NativeStream {
/*
	public static native int openFileStream(String fullName, char mode) throws IOException;
	
	public static int getNativeStreamFor(Object obj)
	{
		if (!(obj instanceof InputStream) && !(obj instanceof OutputStream))
			throw new IllegalArgumentException();
		return NativeAccess.getSetVariable(obj,0,true);
	}
	
	public static void setNativeStreamFor(Object obj, int nativeStream)
	{
		if (!(obj instanceof InputStream) && !(obj instanceof OutputStream))
			throw new IllegalArgumentException();
		NativeAccess.getSetVariable(obj,nativeStream,false);
	}
	
	private static native void nativeOutput(boolean isError, Object array,int offset,int length,boolean moveToNewLine);
	private static native int getNativeStream(int which);
	//private static native int getNativeInputStream();
	
	private static byte[] buff = new byte[1];
	
	private static class outputStream extends OutputStream{
		boolean isError;
		public outputStream(boolean isError){
			this.isError = isError;
		}
		public void write(int value) throws IOException
		{
			synchronized(buff){
				buff[0] = (byte)value;
				write(buff,0,1);
			}
		}
		public void write(byte[] data, int offset, int length) throws IOException
		{
			if (data == null) throw new NullPointerException();
			if (offset < 0 || offset+length > data.length) throw new ArrayIndexOutOfBoundsException();
			nativeOutput(isError,data,offset,length,false);
		}
	}
	public synchronized static PrintStream getSystemOutput(boolean isError)
	{
		int s = getNativeStream(isError ? 2 : 1);
		if (s == 0) return new PrintStream(new outputStream(isError));
		return new PrintStream(NativeOutputStream.toOutputStream(s));
	}
	public synchronized static InputStream getSystemInput()
	{
		int nis = getNativeStream(0);
		if (nis == 0) return null;
		return NativeInputStream.toInputStream(nis);
	}
	*/
	public static final int INPUT_OP_CLOSE = -1;
	public static final int INPUT_OP_SKIP = 0;
	public static final int INPUT_OP_READ = 1;
	public static final int OUTPUT_OP_CLOSE = -1;
	public static final int OUTPUT_OP_FLUSH = 10;
	public static final int OUTPUT_OP_WRITE = 11;
	public static final int RANDOM_OP_GET_POSITION = 20;
	public static final int RANDOM_OP_SET_POSITION = 21;
	public static final int RANDOM_OP_GET_LENGTH = 22;
	public static final int RANDOM_OP_SET_LENGTH = 23;
	
	public native static long streamOperation(int nativeStream, int operation, byte[] data, int offset, long length) throws IOException;
	
}
