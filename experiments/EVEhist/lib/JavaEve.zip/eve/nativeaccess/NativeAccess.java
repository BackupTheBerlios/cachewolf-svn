package eve.nativeaccess;

public class NativeAccess {
	
	public static native void unref(int nativeRef);

}
