/*
 * Created on Nov 21, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.nativeaccess;

import java.io.InputStream;

/**
 * @author Michael L Brereton
 */
//####################################################
public class NativeInputStream extends InputStream {
	
	public static InputStream toInputStream(int nativeStream)
	{
		return toInputStream(nativeStream,null);
	}
	public static InputStream toInputStream(int nativeStream,InputStream dest)
	{
		if (nativeStream == 0) return null;
		if (dest == null) dest = new NativeInputStream();
		NativeStream.setNativeStreamFor(dest,nativeStream);
		return dest;
	}
}

//####################################################
