/*
 * Created on Dec 24, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.nativeaccess;

import eve.fx.BufferedImageData;
import eve.sys.DeviceIcon;
import eve.sys.ImageData;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class nativeIcon extends DeviceIcon
{
	public BufferedImageData bi;
	
	public synchronized void free() 
	{
		bi.free();
		bi = null;
	}
	protected void finalize()
	{
		free();
	}
	public nativeIcon(ImageData[] images, int preferred)
	{
		if (preferred < 0 || preferred >= images.length) throw new IndexOutOfBoundsException();
		bi = new BufferedImageData(images[preferred]);
	}
	public Object getNativeIcon()
	{
		return bi.bi;
	}
	
}
//####################################################
