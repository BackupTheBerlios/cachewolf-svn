/*
 * Created on Nov 21, 2005
 *
 * Michael L Brereton - www.ewesoft.com
 * 
 * 
 */
package eve.nativeaccess;

import java.io.OutputStream;

/**
 * @author Michael L Brereton
 *
 */
//####################################################
public class NativeOutputStream extends OutputStream {

	public static OutputStream toOutputStream(int nativeStream)
	{
		return toOutputStream(nativeStream,null);
	}
	public static OutputStream toOutputStream(int nativeStream,OutputStream dest)
	{
		if (nativeStream == 0) return null;
		if (dest == null) dest = new NativeOutputStream();
		NativeStream.setNativeStreamFor(dest,nativeStream);
		return dest;
	}
}

//####################################################
