package eve.reflect;

//import java.lang.ref.WeakReference;
import eve.sys.Wrapper;
/**
* This is used to access static and instance fields in objects.
**/
//##################################################################
public class Field implements Member{
//##################################################################
//..................................................................
// These are all used by the VM. Do not move.
int _field_; // This holds a WClassField * value - Do not use this field.
public int wrapperType;
public String fullType;
protected int modifiers;
protected Class declaringClass;
public Reflect reflect;
protected String fieldName;
//......................................................
// You may alter from here.
//......................................................
//public static Wrapper wrapper = new Wrapper();
//
protected Class fieldType;
//private WeakReference lastRead, lastWrote;

//===================================================================
Field(Reflect from)
//===================================================================
{
	reflect = from;
}
//===================================================================
public String getName() {return fieldName;}
//===================================================================
public String toString() //{return getName();}
//===================================================================
{
	return Modifier.toString(getModifiers())+" "+getFieldType().getName()+" "+getDeclaringClass().getName()+"."+getName();
}
/**
 * Return the type of the field as a Java encoded type string.
 */
//===================================================================
public String getType() {return fullType;}
//===================================================================
/**
 * Return the type of the field as a Class.
 */
//===================================================================
public Class getFieldType() 
//===================================================================
{
	if (fieldType == null) fieldType = Reflect.typeToClass(fullType);
	return fieldType;
}
public Wrapper getValueDontCheckObject(Object from, Wrapper dest) throws IllegalArgumentException, IllegalAccessException
{
	dest.zero(wrapperType);
	return nativeGetValue(from,dest).setType(wrapperType);
}
/**
 * Get the value of the field.
 * @param from The object to retrieve the field value from, or null for static fields.
 * @param dest An optional destination wrapper value. If it is null then a new one will be
	created and returned.
 * @return A wrapper containing the value in the Field. If this returns null then the Field
	was not public.
 */
//===================================================================
public Wrapper getValue(Object from,Wrapper dest)
throws IllegalArgumentException, IllegalAccessException
//===================================================================
{
	synchronized(this){
		if (true){//from == null || lastRead == null || lastRead.get() != from){
			int m = modifiers;
			if (!Modifier.isPublic(m)) return null;
			if (!Modifier.isStatic(m) && from == null) return null;
			if (from != null && !declaringClass.isInstance(from)) 
					//!Reflect.isTypeOf(from.getClass().getName(),getDeclaringClass().getName())){
				//eve.sys.Vm.debug(this+" - "+from.getClass().getName()+" - "+getDeclaringClass().getName());
				throw new IllegalArgumentException("Object "+from.getClass().getName()+" is not of correct class for field: "+this);
			//lastRead = new WeakReference(from);
		}
	}
	if (dest == null) dest = new Wrapper();
	return getValueDontCheckObject(from, dest);
}
public void setValueDontCheckObject(Object to, Wrapper value) throws IllegalArgumentException, IllegalAccessException
{
	if (!value.isCompatibleWith(wrapperType)) throw new IllegalArgumentException("Bad wrapper type. Should be: "+(char)wrapperType+", is: "+(char)value.getType());
	if (wrapperType == '[' || wrapperType == 'L'){
		Object toStore = value.getObject();
		if (toStore != null){
			Class c = toStore.getClass();
			Class dest = getFieldType();
			if (!dest.isAssignableFrom(c)){
				throw new IllegalArgumentException(c+" is not of type: "+dest);
			}
			/*
			String vt = Reflect.getType(c);
			if (!Reflect.isTypeOf(vt,fullType))
				throw new IllegalArgumentException(vt+" is not of type: "+fullType);
				*/
		}
	}
	nativeSetValue(to,value);
}
/**
 * Set the value of the field. This throws a RuntimeException is the field is not public.
 * @param to The object to set the field value to, or null for static fields.
 * @param value The value to set.
 */
//===================================================================
public void setValue(Object to,Wrapper value)
	throws IllegalArgumentException, IllegalAccessException
//===================================================================
{
	synchronized(this){
		if (true){//to == null || lastWrote == null || lastWrote.get() != to){
			int m = modifiers;
			if (to != null && !declaringClass.isInstance(to))//!Reflect.isTypeOf(to.getClass().getName(),getDeclaringClass().getName()))
				throw new IllegalArgumentException("Object is not of correct class.");
			if (!Modifier.isPublic(m))  throw new RuntimeException("Field is not public: "+fieldName);
			if (!Modifier.isStatic(m) && to == null) throw new NullPointerException();
			//lastWrote = new WeakReference(to);
		}
	}
	if (value == null) throw new NullPointerException();
	setValueDontCheckObject(to, value);
}
//===================================================================
public void copyValue(Object from,Object to)
//===================================================================
{
	try{
		setValue(to,getValue(from,new Wrapper()));
	}catch(Exception e){}
}

//===================================================================
private native Wrapper nativeGetValue(Object from,Wrapper dest)
	throws IllegalArgumentException, IllegalAccessException;
private native Wrapper nativeSetValue(Object to,Wrapper value)
	throws IllegalArgumentException, IllegalAccessException;
//===================================================================

//===================================================================
public void makeWrapperCompatible(Wrapper w)
//===================================================================
{
	w.setType(wrapperType);
}

//===================================================================
public int getModifiers() {return modifiers;}
//===================================================================

//===================================================================
public Class getDeclaringClass() {return declaringClass;}
//===================================================================

//-------------------------------------------------------------------
//private java.lang.reflect.Field field;
//-------------------------------------------------------------------
/*
//===================================================================
public java.lang.reflect.Field toJavaField()
//===================================================================
{
	if (field == null) field = new java.lang.reflect.Field(this);
	return field;
}
*/
//##################################################################
}
//##################################################################

