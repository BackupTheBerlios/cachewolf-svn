package eve.reflect;
//import eve.sys.Wrapper;

//##################################################################
public class Array{
//##################################################################

//===================================================================
public static boolean isArray(Object array)
//===================================================================
{
	if (array == null) return false;
	return array.getClass().isArray();
}
//===================================================================
public static Class getComponentType(Object array)
//===================================================================
{
	if (array == null) return null;
	return array.getClass().getComponentType();
}
//===================================================================
public static int getLength(Object array)
//===================================================================
{
	if (!isArray(array)) return -1;
	return Reflect.arrayLength(array);
}
//===================================================================
public static Object newInstance(Class type,int len)
//===================================================================
{
	try{
		return Reflect.newArrayInstance(type,len);
	}catch(Throwable t){
		return null;
	}
}
/**
 * Create a new instance of a particular class - which cannot be a primitive value, but
 * can be of an array or object type. All active class loaders are searched to resolve the
 * class if necessary.
 * @param className A class or array name.
 * @param len The number of elements.
 * @return An array if it could be created.
 */
//===================================================================
public static Object newInstance(String className,int len)
//===================================================================
{
	try{
		if (className.charAt(0) == '[')
			return Reflect.newArrayInstance(className,len);
		else
			return Reflect.newArrayInstance('L'+className.replace('.','/')+';',len);
	}catch(Throwable t){
	}
	Class c = Reflect.loadClass(className);
	if (c == null) return null;
	return Reflect.newArrayInstance(c,len);
}
/*
//-------------------------------------------------------------------
private static native void getSetElement(Object array,int index,Wrapper w,boolean isGet);
//-------------------------------------------------------------------

//===================================================================
public static void setElement(Object array,int index,Wrapper value)
//===================================================================
{
	getSetElement(array,index,value,false);
}
//===================================================================
public static Wrapper getElement(Object array,int index,Wrapper dest)
//===================================================================
{
	if (dest == null) dest = new Wrapper();
	getSetElement(array,index,dest,true);
	return dest;
}
*/
//##################################################################
}
//##################################################################

