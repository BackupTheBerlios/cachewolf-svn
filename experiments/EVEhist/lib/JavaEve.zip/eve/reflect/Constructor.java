package eve.reflect;
import java.lang.reflect.InvocationTargetException;

import eve.sys.Wrapper;

//##################################################################
public class Constructor extends MethodConstructor{
//##################################################################

/**
* If the method call newInstance() returns null, then this will be set to be
* the exception that caused the newInstance() call to fail.
**/
public Throwable instantiationErrorNotUsed; //The most recent instantiation error.

//public Throwable invocationError; //The most recent invocation error.

//===================================================================
Constructor(Reflect from)
//===================================================================
{
	reflect = from;
}


/**
 * Use the Constructor to create a new instance of the Object.
 * Additional verbose 
 * @param params  an array of parameters which must be of the correct length.
 * @return The newly created Object. If this is not null then the call was successful and the
	instantiationError variable should be ignored. If it is null, then the instantiationError will
	be the exception that caused the failure.
 */
//===================================================================
public Object newInstance(Wrapper [] params)
throws IllegalAccessException, IllegalArgumentException, InstantiationException, InvocationTargetException
//===================================================================
{
	//instantiationError = null;
	if (params == null) params = Wrapper.noParameter;
	try{
		Object ret =  nativeNewInstance(params);
		return ret;
	}catch(Throwable t){
		if (t instanceof InstantiationException)
			throw (InstantiationException)t;
		throw new InvocationTargetException(t);
	}
	/*
	try{
		Object got = nativeNewInstance(params);
		if (got == null) instantiationError = new InstantiationException(getDeclaringClass().toString());
		return got;
	}catch(Throwable t){
		instantiationError = t;
		return null;
	}
	*/
}

//-------------------------------------------------------------------
private native Object nativeNewInstance(Wrapper [] params)
throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException
;
//-------------------------------------------------------------------

//===================================================================
public String getName() {return getDeclaringClass().getName();}
//===================================================================

private java.lang.reflect.Constructor constructor;
/*
//===================================================================
public java.lang.reflect.Constructor toJavaConstructor()
//===================================================================
{
	if (constructor == null) constructor = new java.lang.reflect.Constructor(this);
	return constructor;
}
*/
//##################################################################
}
//##################################################################

