package eve.reflect;
import eve.sys.Wrapper;
//import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

/**
* This is used to invoke methods on objects. It works on static and instance methods.
**/
//##################################################################
public class Method extends MethodConstructor {
//##################################################################
public Throwable dontUseInvocationError; //The most recent invocation error.
//private WeakReference lastInvoked;
boolean isFinalize;
//===================================================================
Method(Reflect from)
//===================================================================
{
	//new Exception().printStackTrace();
	reflect = from;
}

/**
 * Invoke the method on the specified target object.
 * @param target The object to invoke the method on, or null in the case of static methods.
 * @param parameters an array of parameters which must be of the correct length.
 * @param results an optional Wrapper provided to retrieve the results. If it is null then a
	new one will be created and returned.
 * @return A wrapper containing the returned value. If the method type is void then the value
	stored in the wrapper should be ignored. If the returned value is null then an error occured
	and the invocationError variable will hold the exception that caused it.
 */
//===================================================================
public Wrapper invoke(Object target,Wrapper [] parameters,Wrapper result)
throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
//===================================================================
{
	if (isFinalize){
		nativeInvoke(target,parameters,result);
		return null;
	}
	//
	Class c = getDeclaringClass();
	//
	//
	// Fix this - should check package access, etc.
	//
	if ((modifiers & FORCE_ACCESS_PUBLIC) == 0)
		if (!Modifier.isPublic(c.getModifiers())){
			System.out.println(this+" is not public!");
			throw new IllegalAccessException("The class is not public.");
		}
	synchronized(this){
		if (target == null){// || lastInvoked == null || lastInvoked.get() != target){
			if (target != null){
				if (!Reflect.isTypeOf(target.getClass().getName(),c.getName()))
					throw new IllegalArgumentException("Object is not of correct class.");
			}else{
				if (!Modifier.isStatic(getModifiers()))
					throw new NullPointerException("Method is not static");
			}
			if (!Modifier.isPublic(getModifiers())) {
				//invocationError = 
				throw new IllegalAccessException("Method: "+getName()+" is not public");
				//return null;
			}
			//lastInvoked = new WeakReference(target);
		}
	}
	if (result == null) result = new Wrapper();
	result.zero(wrapperType);
	try{
		nativeInvoke(target,parameters,result);
	}catch(Throwable t){
		throw new InvocationTargetException(t);
	}
	return result.setType(wrapperType);
	/*
	try{
		Wrapper w = 
		return w;
	}catch(Throwable t){
		t.printStackTrace();
		invocationError = t;
		return null;
	}
	*/
}
//-------------------------------------------------------------------
private native Wrapper nativeInvoke(Object target,Wrapper [] parameters,Wrapper result);
//-------------------------------------------------------------------

/**
* Returns true if the method is not of type void.
**/
//===================================================================
public boolean returnsValue()
//===================================================================
{
	int l = methodSpecs.length();
	return (methodSpecs.charAt(l-1) != 'V');
}
//===================================================================
public String toString() //{return getName();}
//===================================================================
{
	Class[] all = getParameterTypes();
	String ret = Modifier.toString(getModifiers())+" "+getReturnType().getName()+" "+getDeclaringClass().getName()+"."+getName()+"(";
	for (int i = 0; i<all.length; i++){
		if (i != 0) ret += ",";
		ret += all[i].getName();
	}
	ret += ")";
	return ret;
}

//private java.lang.reflect.Method method;
/*
//===================================================================
public java.lang.reflect.Method toJavaMethod()
//===================================================================
{
	if (method == null) method = new java.lang.reflect.Method(this);
	return method;
}
*/
//##################################################################
}
//##################################################################

